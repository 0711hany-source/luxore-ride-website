Public source export. Base commit: 6926c50b20f6cf5bf91e1b9edfb02f13e948ceb3
Personal operator email has been replaced with operator@example.com. Configure LUXORE_ADMIN_EMAIL in the protected runtime environment. Runtime secrets, databases, APK signing keys and local generated files are excluded. Booking data stays on the original running service.
