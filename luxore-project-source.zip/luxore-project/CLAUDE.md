# LUXORÉ RIDE – Arbeitsanweisung für Claude

Antworte auf Deutsch. Auftraggeber: Hanan (Technik/Buchhaltung im Betrieb; das Unternehmen gehört der Inhaberin).
Lies zuerst diese Datei, dann `docs/PROBLEMLISTE.md`, und bei Next.js-Fragen `AGENTS.md` (Next 16 weicht vom Gewohnten ab).

## Ziel
Größter und bester Chauffeurdienst Deutschlands. Start Frankfurt/Rhein-Main, Wachstum über Partnerflotten.
Aktueller Wunsch: ein einheitliches, modernes, handyoptimiertes Design mit Gesten für Website, Web-App und beide Android-Apps; alles zuerst lokal auf dem Mac ansehen, bis es funktioniert; dann neue APKs; hochladen erst nach ausdrücklicher Freigabe.

## Was das Projekt ist
- Web (Next.js 16.4.6, React 19.2.9): Startseite `app/page.tsx`, SEO `app/layout.tsx`, Stile `app/globals.css`, `app/portal.css`, `app/mobility/app-design.css`; Web-Apps `/mobile/customer`, `/mobile/driver`; Portale `/betreiber`, `/disposition`, `/team`; API `app/api/mobility/*`.
- Apps (Expo/React Native, Mapbox): `mobile/`. Test-APKs bauen: `cd mobile && bash scripts/build-android-preview.sh customer` (danach `driver`), Toolchain in `mobile/.toolchain`. Fertige APKs zusätzlich nach `~/Documents/Ablage/06 Projekte und Code/LUXORE Apps/` kopieren. Stand: Kunde 0.6.9, Fahrer 0.8.6 (noch alte Markenschreibweise in den installierten APKs).
- Datenbank Turso/libSQL (Drizzle, `db/schema.ts`), Hosting Vercel (Hobby) über GitHub-Repo `luxore-ride-website` per Quell-Archiv-Upload (`scripts/package-vercel.mjs`, `vercel-bootstrap.mjs`), E-Mail-Codes Resend, Karten Mapbox + Geoapify. Details: `README.md`, `docs/INDEPENDENT-DEPLOYMENT.md`, `docs/ACTIVATION.md`, `docs/ROADMAP.md`.
- Lokal starten: `pnpm install --frozen-lockfile && pnpm db:migrate && pnpm dev` (oder Doppelklick `LUXORE lokal starten.command`). `.env.local` nutzt die lokale Testdatenbank `work/luxore-local.db`; kein Mail-Zugang lokal; Geoapify-Schlüssel steht seit 14.11.2026 in `.env.local` (von Hanan geliefert, nicht committen, nicht ausgeben).
- Prüfen vor jedem Commit: `pnpm exec tsc --noEmit`, `node --experimental-transform-types --test tests/*.test.ts tests/*.test.mjs`, `pnpm build`. Mit Node 22 schlägt genau 1 Test fehl (`tests/database-import.test.mjs`, „64-bit integers…“); das Projekt ist für Node 24 gedacht. Jeder andere Fehlschlag muss behoben werden.

## Regeln
- Markenschreibweise: LUXORÉ RIDE (Marke/Website), LUXORÉ Ride (Kunden-App), LUXORÉ Driver (Fahrer-App).
- Nichts Unbestätigtes behaupten: keine erfundenen Bewertungen, Stores bleiben „bald verfügbar“, Anfrage ist erst nach Bestätigung eine Buchung.
- Ohne ausdrückliche Freigabe von Hanan: nichts veröffentlichen oder hochladen (GitHub, Vercel, Stores), Production-Datenbank und Live-Einstellungen nicht anfassen, keine kostenpflichtigen Tarife, keine Nachrichten versenden. Preise, Buchungs-/Zahlungslogik, Kostenbudgets (Mapbox-Dauersuche) und Rechtstexte nicht nebenbei ändern.
- Commits: gezielt `git add <pfade>`, nie `-A`; `*.command` und „docs/ROADMAP 2.md“ nicht committen. Nach Commits Sicherung erneuern: `git bundle create "$HOME/Documents/Ablage/06 Projekte und Code/LuxoreRide-Sicherung-<Datum>.bundle" --all`.
- APKs (Wunsch von Hanan, 14.11.2026): Nach jedem neuen Bau die alten APKs in `~/Documents/Ablage/06 Projekte und Code/LUXORE Apps/` in den Papierkorb legen, sodass dort nur die neuesten zwei liegen, und die neuen zusätzlich in den Google-Drive-Ordner „LUXORE Apps“ laden (https://drive.google.com/drive/folders/1-wBNEUu1W0IS9eZhaQM9nyOw61Q29Hk-). Der Drive-Upload ist hiermit freigegeben; alles andere Hochladen weiterhin nicht. Weg: Google Drive für Desktop ist eingerichtet – einfach nach `~/Library/CloudStorage/GoogleDrive-*/Meine Ablage/LUXORE Apps/` kopieren und dort alte Versionen ebenfalls in den Papierkorb legen.
- GitHub/Vercel (Wunsch von Hanan, 14.11.2026): Nur hochladen, wenn es wirklich nötig ist, und dann Änderungen gesammelt in EINEM Upload – jeder Upload löst einen Vercel-Bau aus, und der Tarif erlaubt nur wenige. Weiterhin nur nach ausdrücklicher Freigabe.
- `docs/PROBLEMLISTE.md` laufend führen: neues Problem sofort eintragen; Status Offen → Lokal behoben (nur auf dem Mac) → Behoben (wirkt live bzw. endgültig erledigt).

## Design-Programm (Reihenfolge, je Schritt klein halten und ansehen)
1. Designsystem Web: gemeinsame CSS-Variablen (Tinte #151719, Papier #f9f8f5, Gold #b99a60, wenige Grautöne, zwei Schriftfamilien, feste Radien/Abstände); Startseite darauf umstellen und im Handyformat (375 px) optimieren.
2. Web-App Kunde/Fahrer (`app/mobility/*`, `.app-native`) angleichen, Wischgesten und feste Fenster einheitlich.
3. Betreiber-/Flottenportal angleichen.
4. Native Apps (`mobile/src`) auf dieselben Farben/Typografie (nur Darstellung).
5. Feinschliff: leere Zustände, Kontraste, Barrierefreiheit, Englisch vorbereiten.
Danach beide APKs bauen, alles lokal durchspielen (Buchung bis Kassieren), dann Freigabe zum Hochladen einholen.

## Bisher erledigt (14.11.2026, alles lokal committet, nichts veröffentlicht)
- 6985ff9 Startseite: SEO, OpenGraph, JSON-LD, FAQ, Buchungshinweis am Hauptknopf.
- bebb417 Markenschreibweise in 22 Dateien vereinheitlicht.
- 02ee3bc Next.js 16.4.6 / React 19.2.9 (Sicherheitsupdates; die Live-Seite läuft noch mit 16.4.0!).
- f7a7d4b „Jetzt“/„Später“ in der Kunden-Startansicht bündig.
- 6e4cf95 Adresseingabe: Meldung verschwindet nach Kartenwahl, Karte öffnet an der getippten Adresse, Nähe/Europa-Bevorzugung bei Vorschlägen, ruhiger Hinweis statt Fehler.
- Design-Programm Punkt 1 erledigt: `app/design-tokens.css` (Variablen `--lx-*`: Farben, zwei Schriften, Radien, 4er-Abstände, Tipp-Größe 48 px; in `app/layout.tsx` zuerst geladen). Startseite (`.lux-*` in `globals.css` und `portal.css`) nutzt nur noch diese Variablen. Handy (375 px): einzeilige wischbare Navigation, Hauptknopf volle Breite, Leistungen/Fahrzeuge/Plattformen als Wischkarten, alle Tipp-Ziele ≥ 40 px, Seite 8262 → 5781 px lang. Alte Namen `--lux-ink/gold/paper` bleiben als Verweis bestehen.
- Design-Programm Punkte 2 und 3 erledigt (Web-App, Portale): alle Farbwerte in `app/globals.css`, `app/portal.css`, `app/mobility/app-design.css` per Skript auf den nach Helligkeit nächsten `--lx-*`-Token umgestellt (vorher 529 verschiedene Farben in globals.css, jetzt 0 feste Werte außer Schatten mit Transparenz), Schriften auf `--lx-font-sans/serif`, 318 Radius-Angaben auf `--lx-radius-s/m/l/xl/pill`. Kacheln „Jetzt/Später“ jetzt wirklich bündig. Angesehen in 375 px und 1280 px: Startseite, Kunden-App (Start, Zieleingabe), Fahrer-App (Profil), /betreiber, /team, /konto. Nicht angesehen: alles hinter der Anmeldung.
- Design-Programm Punkt 4 erledigt (nur Darstellung): `mobile/src/theme.ts` mit denselben Werten; 24 Dateien in `mobile/src` nutzen `colors.*`; Goldschrift auf hellem Grund = `colors.goldText`. Karten-/SVG-Farben bleiben Literale mit Token-Wert. Noch nicht auf einem Gerät angesehen; Radien/Abstände der Apps noch nicht umgestellt.
- Design-Programm Punkt 5 erledigt (Web): 106 graue Nebentexte auf `--lx-text-muted` (Kontrast ≥ 5,5:1), Goldschrift hell/dunkel getrennt (`--lx-gold-text` / `--lx-gold-light`), Fokusrahmen über `--lx-focus`, Bewegungsreduzierung für App-Sheets; `docs/ENGLISH-PREP.md` beschreibt den Weg zur englischen Fassung (kein Code).
- Punkt 6 erledigt: Ride 0.7.0 (Code 24) und Driver 0.8.7 (Code 41) gebaut, geprüft (Paketname, Rechte, Version, Bundle, ARM64, Signatur) und nach `~/Documents/Ablage/06 Projekte und Code/LUXORE Apps/` kopiert. Noch auf keinem Handy installiert.
- Punkt 7 nur teilweise möglich: Ohne Anmeldung geprüft und in Ordnung: Gerätesitzung, Konfiguration, Kartenpunkt, Preis (Hbf → Flughafen 11,5 km, Business 28,78 € = km × 2,50 €), Buchung anlegen, Stornieren. Blockiert: Anmeldung per E-Mail-Code (lokal 503, kein Mailversand), dadurch Fahrerfreigabe, Annahme, Fahrt, Kassieren. Braucht Entscheidung von Hanan: lokaler Testzugang (siehe Problemliste).
- Lokaler Testzugang (von Hanan freigegeben): `node scripts/seed-local-test-accounts.mjs` (nur `file:`-Datenbank, bricht sonst ab; App-Code unverändert). Legt Betreiber, Flottenbesitzer, Fahrer (freigegeben, Test-Flotte, E-Klasse) und Kunde an; Anmeldung im Browser über die Zeile `browserKonsole` aus `work/local-test-sessions.json` (nicht committen, nicht ausgeben).
- Punkt 7 erledigt (über die Schnittstellen): Buchung → Annahme → Fahrt → Barzahlung, Mindestpreis, Reservierung/Storno und Rechte geprüft; /betreiber und /disposition mit Testkonto angesehen. Offen: per Hand in der Oberfläche und auf Handys durchspielen.
- Gerätetest Hanan (14.11.2026): Fehler in Ride/Driver behoben bzw. entschärft (Commit d558ab2, APKs Ride 0.7.1 / Driver 0.8.8) – Details in der Problemliste. „Online gehen“ noch ohne gesicherte Ursache.
- Neudesign „Apple-like“ (Wunsch von Hanan): Konzept und Etappenplan in `docs/REDESIGN-KONZEPT.md`. Umsetzung erst nach den fünf Entscheidungen von Hanan (Kunden-Start mit Karte, Dunkelmodus, neue Pakete, Reihenfolge, Apple-Konto). App-Symbole: eigene Entwürfe abgelehnt; Richtungen mit echten Schriften liegen in `work/icon-richtungen.png`, Auswahl offen.
- Neudesign Etappe 0 erledigt (Commit 1e5a0ae; „weiter“ von Hanan als Start gewertet, Annahmen: Karte zuerst, Dunkelmodus später, neue Pakete ja, Kunden-App zuerst; Apple-Konto offen): Pakete reanimated/worklets/gesture-handler/expo-haptics/expo-blur, `theme.ts` um `radii`, `typography`, `springs`, `layout`, `shadow` erweitert, Bausteine in `mobile/src/ui/` (Sheet mit 3 Rastpunkten, SwipeToConfirm 90 %, Button, ListRow, CodeField usw.), Musterseite nur im Testbau (Menü → „Design-Muster (Test)“). APKs Ride 0.7.2 (Code 26) / Driver 0.8.9 (Code 43) gebaut, geprüft, in Ablage und Drive. Nächste Etappe: 1 Navigation (`App.tsx` zerlegen, Stapel + Tabs, `GestureHandlerRootView` an die Wurzel).
- Store-Vorbereitung (Wunsch von Hanan „ready zum Hochladen“): Store-Pakete (AAB) per `mobile/scripts/build-android-store.sh <customer|driver>` + `verify-android-store.sh`; Ride 0.7.3 / Driver 0.8.10 gebaut, geprüft, in Ablage „LUXORE Store-Pakete“. Upload-Schlüssel in `mobile/.toolchain/store-signing/` (nicht committen, nicht ausgeben). Offene Voraussetzungen (Play-/Apple-Konto, „Online gehen“, Gerätetest, Live-Server, Symbole/Screenshots, Recht) in `docs/STORE-EINREICHUNG.md`. Nichts hochgeladen.
- Fehlerrunde (Wunsch von Hanan „alle Fehler erst mal beheben“, Commit 4927188): Anmeldecode-Antwort wartet max. 3 s auf Mail und braucht weniger Datenbank-Runden; Kartenpunkt liefert einen Treffer; Betreiber-Kachel „Fahrer online“ (45-s-Fenster); gesperrte Datenbank → 503; Fokusrahmen-Kontrast; Driver „Online gehen“ mit Schrittanzeige 1/4–4/4, Abbrechen, Gesamtfrist 3 Min. (Ursache am Gerät weiter unbewiesen); Kassieren-Ladezustand; Screenreader-Aktion am Wischknopf. Test-APKs Ride 0.7.3 (Code 27) / Driver 0.8.10 (Code 44) in Ablage und Drive. Server-Änderungen wirken erst nach dem gesammelten Upload. Node-22-Testfehlschlag: Ursache `node:sqlite` (Text mit Nullzeichen), kein Projektfehler.
- 15.11.2026: Apple-Vorbereitung (160608c, `docs/APPLE-VORBEREITUNG.md`; kein Xcode auf dem Mac, nie gebaut). Electric Class EQE 300 2,80 €/km (Preis von Hanan), First Class „nur auf Anfrage“, „besetzt“-Chip mit weiter möglicher Anfrage, Weck-Push für Fahrer vorbereitet (c4cc246; Migration 0019 `mobility_push_tokens`; `docs/PUSH-EINRICHTUNG.md`; inaktiv ohne Firebase). Web-App nach kompletter Testfahrt bei 375 px korrigiert (cb902aa, 63f221c). Apps: Kontolöschung, Wischknopf-Freigabe, Abschlussansicht (f293070). Pakete Ride 0.7.5 (Code 29) / Driver 0.8.12 (Code 46). Preisliste jetzt: Business 2,50 · Electric 2,80 · Van 3,00 · First 3,50 (auf Anfrage). Alles Serverseitige wirkt erst nach dem gesammelten Upload (inkl. Migration 0019 auf der Live-Datenbank).
- 15.11.2026 (Fortsetzung): Neudesign Etappe 1 Navigation (`mobile/src/navigation/`, `screens/`, `use-session.ts`; Verlauf, Tabs, Titel) und Etappe 2 Anmeldung in 3 Schritten + einheitliche Maße (4a65abc). Betreiberplattform nur Server/Web (bfee04e, Migration 0020, `docs/BETREIBERPLATTFORM.md`): 15 % Servicepauschale mit Wochenabrechnung je Flotte (Entscheidung Hanan: wöchentlich), Einnahmen für Flotte und Fahrer, Flottenantrag `/partner`, Papiere mit Fotos in der Datenbank (Entscheidung Hanan: Fotos), Wochenkontrolle mit Auto-Sperre (Entscheidung Hanan: wöchentlich; Prüfpflicht standardmäßig AUS, Betreiber schaltet ein), Sperren. Noch offen: dieselben Funktionen in den nativen Apps; größere Umbauten (Buchung Karte-zuerst, Fahrer-Bereich) erst nach Gerätetest. APKs Ride 0.7.7 (Code 31) / Driver 0.8.14 (Code 48); Stand ohne neue Navigation (0.7.5 / 0.8.12) in Ablage „LUXORE Apps Stand ohne neue Navigation“. Live-Upload braucht Migrationen 0019 und 0020 auf der Production-Datenbank.
- 15.11.2026 (Abschluss der Runde): Betreiberplattform auch in der Fahrer-App (c154d97: `mobile/src/platform/`, `operator-platform.ts`, `ShiftReadiness.tsx`, Tab „Umsatz“); Web-Seite `/pruefung` mit strenger Zielprüfung der Sitzungsübergabe (3c25422). Pakete Ride 0.7.8 (Code 32) / Driver 0.8.15 (Code 49): Test-APKs in Ablage + Drive, Store-Pakete in Ablage. NACH dem Website-Upload: App-Ziel für Fotos auf `/pruefung` umstellen (siehe Problemliste). Größere Umbauten (Buchung Karte-zuerst, Fahrer-Bereich Etappe 5, Flotte Etappe 6) erst nach Gerätetest von Hanan.
- Nächster Schritt: APKs auf einem Handy ansehen; offene Punkte der Problemliste; dann Freigabe zum Hochladen einholen (ein gesammelter Upload).
- Hinweis lokaler Test: In dieser Umgebung fehlt `pnpm` im Pfad; `./node_modules/.bin/tsc`, `./node_modules/.bin/next build` und `node node_modules/next/dist/bin/next start -p 3100` funktionieren. Ein seit Stunden laufender `next dev` übernahm CSS-Änderungen nicht mehr; dann neu starten.

Ausführlicher Plan (online): https://claude.ai/artifact/W8HBTU3ZQRudxT1GiF2BHJ · Aufgaben: TickTick-Projekt „LUXORÉ RIDE“.

## Produkt und Ideen (aus Projektdoku und Chat)
- Plattform im Stil von Uber, aber für Premium-Chauffeurfahrten und mit mehreren Flotten unter einer Marke.
- Klassen und Preise (seit 15.11.2026 zusätzlich Electric Class, Mercedes EQE 300, 4 Gäste, 2 Koffer, 2,80 €/km; First Class nur auf Anfrage): Business Class (Mercedes E-Klasse / Audi A6, 4 Gäste, 2 Koffer) 2,50 €/km · First Class (Mercedes S-Klasse, 3 Gäste, 2 Koffer) 3,50 €/km · First Class Van (Mercedes V-Klasse, 6 Gäste, 6 Koffer) 3,00 €/km. Mindestpreis 15 €, Preis nach Straßenroute, keine zusätzliche Pauschale.
- Sofortfahrt und Reservierung, europaweit wählbare Adressen, Abholpunkt per Karte oder GPS, Live-Karte mit Fahrerposition, Stornierung per Wischgeste.
- Zwei Apps: LUXORÉ Ride (Fahrgäste) und LUXORÉ Driver (Chauffeure: Schicht, GPS, Fahrtangebote mit Alarm, Statusgesten, Kassieren, Tagesumsatz).
- Flottenmodell: Plattformbetreiber gründet Flotten und bestimmt Besitzer; Besitzer/Stellvertreter verwalten Fahrzeuge, Team, Fahrerfreigaben und sehen nur ihren Umsatz. Grundlage für Partnerflotten in anderen Städten.
- Women to Women: weibliche Fahrgäste können eine Chauffeurin anfragen (Anfrage mit Bestätigung, keine Garantie).
- Bordservice: Getränke/Produkte mit Bestand je Fahrzeug, Gratis-Kontingent pro Fahrt, Bestellung aus der Kunden-App.
- Kassieren: bar oder separates Kartenterminal; keine Online-Zahlung, keine Belege, kein Trinkgeld.
- Wichtige Aktionen nur per vollständiger Wischgeste; ruhiges Design in Schwarz, Papierweiß, Gold.
- Kontakt: booking@luxoreride.de · +49 160 5083829 · Gerhart-Hauptmann-Ring 224, 60439 Frankfurt am Main.
- Entwürfe, noch NICHT freigegeben: kostenfreie Stornierung bis 24 h vor Abholung; Wartezeit 60 Min. am Flughafen, sonst 15 Min., danach 40 € je angefangene halbe Stunde.

## Was Hanan im Chat gesagt hat (14.11.2026)
- Ziel: der größte und beste Chauffeurdienst Deutschlands.
- Website und Apps wurden von GPT (Codex) gebaut; alles liegt auf diesem Laptop.
- Die bestehende Website optimieren; alles aus dem Projekt holen, die Ideen verstehen und festhalten; einen Plan machen, wie alles zuverlässig und cloud-basiert funktioniert.
- Ein einheitliches, modernes Design mit Gesten, für Handys optimiert, für alles; danach beide APKs neu, mit allen Verbesserungen.
- Erst alles auf dem Mac zeigen und die APKs auf dem Mac speichern; ansehen, bis alles perfekt funktioniert; dann hochladen.
- Eine Liste führen: Problem erkannt / Problem behoben (→ `docs/PROBLEMLISTE.md`).
- Möglichst selbständig arbeiten, wenig Rückfragen, nur fragen, wenn wirklich etwas gebraucht wird; sparsam mit Tokens umgehen, Subagenten gezielt einsetzen.
- Die vier Punkte der Adresseingabe verbessern (erledigt in Commit 6e4cf95, einer davon nur teilweise – siehe Problemliste).
- Der aktuelle Mapbox-Schlüssel wurde von Hanan geliefert und steht in `.env.local` (nicht committen, nicht ausgeben).

## Offene Entscheidungen für Hanan
- Code in ein privates GitHub-Repository sichern? (bisher nur lokal + Git-Bundle)
- Sicherheitsupdate vorab allein veröffentlichen? (Live-Seite läuft noch mit Next.js 16.4.0)
- Budget für bezahlte Tarife (Hosting, Datenbank, Karten, Zahlungsanbieter) – braucht die Inhaberin.
- Gibt es die S-Klasse der First Class wirklich? Laut Hanan besteht die Flotte aus V-Klasse, Audi A6 und E-Klasse.
- Verbindliche Stornoregeln und Wartezeiten; Termin Fachanwalt/Behörde zum Plattformmodell.

## Größere Lücken für den Betrieb (Details in der Problemliste)
Vercel Hobby nicht kommerziell · keine Push-Benachrichtigung für Fahrer · kein Zeitgeber für Reservierungen (`/api/mobility/tick`) · keine Backups/Überwachung · keine Online-Zahlung · noch keine echte Probefahrt auf Handys · kein iOS · nicht im Play Store.
