# Flotten, Disposition und Kassieren

Stand: 24. September 2026.

## Bedienung

- Unter `/team` reichen Mitarbeiter auf ihrem eigenen Gerät ein Profil ein. Bestehende Fahrerprofile stehen bereits in der Zuordnungsliste.
- Der Plattformbetreiber legt unter `/disposition` eine Flotte an und wählt ihren Besitzer. Dieser erhält automatisch Dispositionsrechte für seine Flotte. Pro Besitzer ist derzeit eine Flotte vorgesehen.
- Der Plattformbetreiber ordnet Mitarbeiter und Fahrer zu. Der Besitzer wählt aus seinen Mitarbeitern einen Stellvertreter oder hebt die Stellvertretung auf. Beide sehen nur Fahrer, Fahrten und Umsätze ihrer Flotte. Nur Besitzer bzw. Plattformbetreiber können die Stellvertretung ändern.
- Fahrerfreigaben bleiben separat erforderlich. Flottenzuordnung verändert die bestehende Freigabe nicht; beim Wechsel wird der Fahrer offline gesetzt. Besitzer und Stellvertreter können ihre eigenen Fahrer freigeben.
- Flottenumsätze lassen sich insgesamt, für die letzten sieben oder dreißig Tage anzeigen, jeweils mit Fahreraufteilung und getrennten Summen für Fahrpreise, bestätigte Eingänge und offene Beträge.
- Beim Annehmen einer Fahrt wird die Flottenzugehörigkeit festgehalten. Ein späterer Flottenwechsel verschiebt keine historischen Umsätze.
- Nach Abschluss sieht der Fahrer den vollständigen vereinbarten Fahrpreis und bestätigt den Erhalt als Bargeld oder über ein separates Kartenterminal. Doppelte Bestätigung erzeugt keine doppelte Buchung. Bis zur Bestätigung werden keine weiteren Angebote vermittelt.
- Die App belastet keine Karte. Es gibt derzeit keine Teilzahlungen, Trinkgeldbuchung, Steuer-/Lohnabrechnung, Belege oder automatische Bankabstimmung. Historische Abschlüsse ohne das neu eingeführte Abschlussdatum werden nicht rückwirkend als offene Forderungen behandelt und fehlen in der neuen Umsatzstatistik.

## Oberfläche

Kunden können den genauen Abholpunkt auf der Karte bestätigen und zuletzt verwendete Ziele auswählen. Die mobile Ansicht zeigt kompakte Fahrzeugklassen und Buchungsaktionen. Die Fahreransicht bietet eine dunkle Karte, einen großen Online-/Pause-Schalter und eigene Umsatzübersicht.

Diese Weboberflächen werden auch in den vorhandenen Android-WebView-Apps geladen: App erneut öffnen, keine neue APK für diese Änderungen nötig. GPS weiterhin nur im Vordergrund. Gerätegebundene Zugänge müssen nach dem Löschen der App-/Browserdaten neu zugeordnet werden.

## Prüfung

- `node --experimental-strip-types --test tests/mobility.test.ts`: 12 Tests, einschließlich Zahlungsbesitz, Abschlussbedingung, Wiederholbarkeit, Angebotsblockierung und Flottenhistorie.
- `python3 tests/mobile-api-local.py`: getrennte Geräte, Mehrklassenfahrer und kompletter Fahrtenablauf.
- `python3 tests/fleet-api-local.py`: Besitzer/Stellvertreter, Rechteentzug, fremde Flotten gesperrt, Umsatz und Kassieren mit serverseitigem Preis, Flottenwechsel.
- API-Tests verwenden nur lokale, eindeutig markierte Testdaten und entfernen sie anschließend.
- Neue Migrationen 0007/0008 ändern ausschließlich das Schema. Bestehende Fahrerfreigaben und Buchungen werden nicht überschrieben.

## App-Bedienung und Fahrzeuge (24. September, Folgeupdate)

- Die mobilen Ansichten verwenden eine volle Kartenfläche, aufziehbare Detailflächen und feste Navigation unten. Fahrer wechseln durch horizontales Wischen über Inhalte oder über die drei Schaltflächen zwischen Fahren, Umsatz und Auto. Kartenbewegungen und Eingabefelder lösen keinen Seitenwechsel aus. Kunden wechseln zwischen Fahren, Fahrten und Service.
- Fahrtannahme und nächste Fahrtphase lassen sich am Schieber bestätigen, alternativ per beschrifteter Schaltfläche. Wischen zwischen Seiten löst keine Buchung oder Zahlung aus.
- Tagesumsatz: Fahreransicht und Flottenauswertung zählen ab 00:00 in Europe/Berlin; Sommer-/Winterzeit werden berücksichtigt. Fahrpreise, kassierte und offene Beträge bleiben getrennt.
- Besitzer und Stellvertreter legen Autos mit Modell, Kennzeichen und einer oder mehreren freigegebenen Fahrzeugklassen an. Fahrer wählen unter Auto ein freies Fahrzeug ihrer eigenen Flotte. Die Auswahl gilt bis zum Wechsel bzw. zur Freigabe und ist exklusiv, auch wenn der Fahrer offline ist.
- Fahrzeugwechsel ist nur offline und ohne laufende Fahrt/offenen Kassiervorgang möglich. Neue Angebote verwenden die Klassen des gewählten Autos. Ein Flottenwechsel entfernt die Fahrzeugauswahl.
- Verkaufte/ausgeschiedene Autos werden archiviert. Archivierung blockiert solange das Auto online oder in einer unabgerechneten Fahrt ist. Frühere Fahrten behalten Kennzeichen und Modell als Snapshot, auch nach Wechsel/Verkauf.
- Vorhandene Profilfahrzeuge funktionieren unverändert, bis die Flotte das erste Fahrzeug im neuen Bestand anlegt. Ab dann müssen Flottenfahrer ein aktives Bestandsfahrzeug auswählen.
- Kartenfehler: Einzelne Kachelfehler verdecken eine bereits geladene Karte nicht mehr. Fehler verschwinden nach erfolgreichem Laden; Verbindungsrückkehr lädt die Karte erneut, initiale temporäre Fehler werden begrenzt automatisch wiederholt. Manuelles Neuverbinden erhält die Buchung. Ungültige Tokens oder Kontolimits müssen weiterhin beim Anbieter korrigiert werden.
- Validierung erweitert: 14 Domänentests, darunter Mitternacht/Sommerzeit, gesperrte Fahrzeuge und bisherige Fahrtenlogik. Lokaler Flotten-API-Test prüft zusätzlich exklusiven Fahrzeugwechsel, fremde Flotte, Klassen, Archivierung, Tagesumsatz und unveränderte Fahrzeughistorie. Keine physischen Android-/iOS-Gerätetests in diesem Durchlauf.

## Überarbeiteter Buchungsablauf und Ansichtsseite

- Kunden starten auf einem ruhigen Startbildschirm mit Sofortfahrt, Planung und letzten Zielen. Adressen werden auf einem eigenen Bildschirm eingegeben. Die Fahrzeugauswahl zeigt Klassen und Preise, ohne gleichzeitig Kontaktfelder einzublenden. Name und Telefon folgen im Bestätigungsschritt; erst dessen eindeutige Schaltfläche stellt die Fahrtanfrage.
- Tagesumsatz, Fahrzeugauswahl und Kassieren verwenden dieselbe reduzierte App-Gestaltung.
- `/app-ansichten` zeigt diese produktiv verwendeten Komponenten mit ausdrücklich gekennzeichneten Beispieldaten. Die Seite legt keine Datensätze an. Fahreraktionen und Zahlungsspeicherung sind in der Ansicht gesperrt, die Kunden-Bestätigung bleibt rein lokal. Karten werden dort nicht vorgetäuscht.
- Android 0.3.0 / versionCode 3 entfernt den nativen Kopfbereich und verwendet einen hellen Systemrahmen. Dieses Rahmenupdate braucht einmal die neue Test-APK. Danach laden Änderungen an den Weboberflächen weiterhin online.
- TypeScript-Prüfungen für Web und Mobile sowie Web-Build bestanden. Die APK-Prüfung kontrolliert Paketkennung, Variante, Signatur, enthaltenes Bundle und Berechtigungen; sie ersetzt keinen physischen Gerätetest.

## Korrektur des mobilen Dialogs (25. September)

- Der Checkout wird auf kleinen Bildschirmen über die gesamte Breite unten verankert. Neben `transform` wird `translate` zurückgesetzt: Die Tailwind-Dialogklassen hatten die zusätzliche Verschiebung um eine halbe Breite verursacht.
- Mobile Seiten erhalten feste Skalierung und 16-px-Eingaben. Der native Rahmen 0.3.1 / versionCode 4 deaktiviert Seitenzoom und Overscroll. Mapbox bedient seine Karte weiterhin selbst.
- Weiße Flächen ersetzen graue Kästen und dekorative Trennlinien in Start, Buchung, Navigation, Umsatz und Fahrzeugauswahl. Der unscharfe Dialoghintergrund entfällt.
- HTTP-Prüfung bestätigt die festen Viewport-Metadaten für beide mobilen Routen; die öffentliche Startseite bleibt normal zoombar. Keine Aussage über einen physischen Geräte- oder visuellen Browsertest.

## Kartenrückkehr, Fahrtwünsche und App-Menü (25. September)

- Alle interaktiven Karten kehren drei Sekunden nach der letzten Bedienung zur Standardansicht zurück. Berührung und nachlaufende Bewegung verlängern die Pause. Fahrtrouten werden wieder vollständig eingepasst; ohne Route wird die verfügbare Position bzw. Frankfurt zentriert. Im Abholpunkt-Editor bleibt der gewählte Punkt erhalten, nur Zoom und Ausrichtung werden zurückgesetzt. Timer werden beim Schließen oder Karten-Neustart entfernt.
- Optionale Fahrtwünsche: kühl/warm, Ruhe/Unterhaltung und keine/leise Musik. Die Buchung speichert eine serverseitig validierte Auswahl. Kunde, angebotener/zugewiesener Fahrer und berechtigte Disposition sehen dieselben Wünsche; Wiederholungen einer Buchung überschreiben sie nicht. Alte Buchungen haben keine Vorgaben.
- Migration 0010 ergänzt ausschließlich die nullable Spalte `rider_preferences`; bestehende Fahrerfreigaben und Buchungen bleiben erhalten.
- Das seitliche App-Menü öffnet Fahrerbereich bzw. Fahrten, Service und für Berechtigte die Disposition im selben App-Rahmen. Besitzer, Stellvertreter und Plattformadmin behalten die bisherigen serverseitigen Rechte. Fahreransicht und Standortübertragung bleiben beim Wechsel zur Disposition in der Fahrer-App gemountet; weiterhin kein nativer Hintergrundbetrieb.
- Validierung: 22 automatisierte Tests für Kamera-Timer, Präferenzen und bestehende Fahrtenlogik; lokaler kompletter API-Fahrtenablauf einschließlich Wunschvalidierung, Speicherung und Fahrer-/Dispositionsanzeige; lokaler Flottenrechte-/Umsatz-/Fahrzeugtest. Kein physischer Gerätetest.
- Nächster Schritt: beide Rollen auf realen Android-Geräten prüfen, insbesondere Tastatur im Checkout, Kartengesten und Fahrerstandort während des Dispositionswechsels.

## Einheitlicher App-Kopf und Vollbild-Bestätigung (25. September)

- Die Kunden-App verwendet den oberen Luxóre-Ride-Kopf mit Menü an Stelle des Support-Knopfs. Die untere Navigation entfällt; Fahrten, Hilfe und berechtigte Disposition sind über das obere Menü erreichbar. Der Fahrerbereich verwendet denselben Kopf; Fahren/Umsatz/Auto sitzen direkt darunter.
- Nach der Fahrzeugklasse folgt eine eigenständige, weiß hinterlegte Vollbild-Bestätigung im Dialog-Portal. Sie verwendet keine Zentrierungs-/Translate-Klassen des bisherigen Dialogs. Kopf und Preisleiste bleiben stehen, die Strecke, Kontaktfelder und Fahrtwünsche scrollen dazwischen. Die sichtbare Viewport-Höhe und Position reagieren auf die Bildschirmtastatur; initialer Fokus liegt auf der Ansicht statt im Eingabefeld.
- Gemeinsame Schrift, Abstände, dunkle Hauptaktionen und dezente Goldakzente stimmen Start, Fahrzeugwahl und Bestätigung aufeinander ab. Klassen, serverseitiger Preis, Fahrtwünsche und Buchungsberechtigungen bleiben unverändert.
- Validierung: TypeScript, Lint und Produktions-Build; keine visuelle Browser- oder physische Geräteprüfung. Nächster Geräteschritt: Klasse wählen → Bestätigung → Tastatur öffnen/schließen → Fahrtwünsche → Zurück, auf schmalem Android-Bildschirm und im Querformat.

## Fahreransicht: Start, Fahrtangebot und aktive Fahrt

- Der Fahrerstart zeigt einen eindeutigen Status, aktuelles Fahrzeug, freigegebene Klassen und einen breiten Online-/Pause-Schalter. „Online“ erfordert neben dem laufenden Standortkanal einen aktuellen serverseitigen Standort; ohne zugewiesenes Fahrzeug bleibt der Start gesperrt, wenn die Flotte eine Fahrzeugwahl verlangt.
- Tagesumsatz und Fahrzeug oben verwenden eine einheitliche Anzeige. Während Angebot, Fahrt oder Kassieren bleiben die Fahrzeug-/Umsatz-Unterseiten gesperrt und die Navigation markiert die tatsächliche Fahrtansicht. Dies ersetzt die zuvor wirkungslosen Wechsel während aktiver Fahrten; serverseitige Fahrzeugrechte bleiben unverändert.
- Fahrtangebote zeigen Fahrpreis, Klasse, tatsächliche Fahrstrecke/-dauer, getrennte Abhol-/Zieladresse, optionale Fahrgastwünsche und verbleibende Annahmezeit. Angaben zur Strecke sind keine erfundene Ankunftszeit. Annahme und Ablehnung bleiben an dieselben APIs gebunden und nach Ablauf gesperrt.
- Aktive Fahrten heben aktuelle Phase, nächsten Halt, Fahrgast, Navigation und nächste Bestätigung hervor. Sicherheit bleibt direkt erreichbar. Die Bestätigungsaktion bleibt am unteren Rand der aufziehbaren Fläche erreichbar.
- `/app-ansichten` ergänzt Fahrerstart und Fahrtangebot mit ausdrücklich gekennzeichneten Beispieldaten und denselben Komponenten. Beispielaktionen schreiben keine Buchung, Zahlung oder Verfügbarkeit; der Beispiel-Countdown ist statisch.
- TypeScript, Lint, Produktionsbuild und bestehende Fahrten-/Fristtests prüfen die Änderung. Keine visuelle Browser- oder physische Geräteprüfung. Nächster Schritt: Fahrerstart, Angebot, Abholung und Kassieren gemeinsam auf zwei echten Geräten testen.
