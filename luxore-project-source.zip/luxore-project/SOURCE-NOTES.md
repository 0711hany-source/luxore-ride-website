Independent source snapshot. Base commit: 7501836db6ed6f91bddf7590619b15310e23c06b
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
