Independent source snapshot. Base commit: 0b41741a16d0c8e865708d241654880b26fa5cbf
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
