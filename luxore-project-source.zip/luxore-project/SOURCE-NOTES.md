Independent source snapshot. Base commit: 70ffecdc8cb18fc72355f7829daccad7d57e25bf
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
