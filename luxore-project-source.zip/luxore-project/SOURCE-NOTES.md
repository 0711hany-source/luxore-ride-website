Independent source snapshot. Base commit: 9b506fd19c67e26b449c17c324c80c236d09677b
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
