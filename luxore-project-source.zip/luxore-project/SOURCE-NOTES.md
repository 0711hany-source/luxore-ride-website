Independent source snapshot. Base commit: 52c6edcc838dae4170073f8643477d1e586a83e3
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
