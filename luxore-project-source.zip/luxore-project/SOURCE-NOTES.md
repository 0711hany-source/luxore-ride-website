Independent source snapshot. Base commit: 59942a952a28ed4ed9c33196cc60e85345738185
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
