Independent source snapshot. Base commit: 65e7f76eebdb25a0edba6034182e8027294cee07
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
