Independent source snapshot. Base commit: 92490b679c07a8e9c6cec96af76b10596e08498f
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
