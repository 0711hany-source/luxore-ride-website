Independent source snapshot. Base commit: c8b7eafe14c6464be76ab2fa4d0a28cc009babcd
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
