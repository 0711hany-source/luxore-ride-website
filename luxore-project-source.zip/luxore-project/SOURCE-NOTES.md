Independent source snapshot. Base commit: 2d3557b83335421ae3d5c3d3e5de38b582be98da
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
