Independent source snapshot. Base commit: b24b12f20fcfc8dd6eb9b202f57cf8efc82aa828
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
