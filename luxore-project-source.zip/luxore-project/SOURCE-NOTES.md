Independent source snapshot. Base commit: 4cb948f8576fb9bdc2d4ea129d8b68bfc29ad022
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
