Independent source snapshot. Base commit: 71bda3ba8fd01586241e9be6fbb305387e4cae18
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
