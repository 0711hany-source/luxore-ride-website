Independent source snapshot. Base commit: 884e26670988b8843ae03daee42939c4a3188ba1
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
