Independent source snapshot. Base commit: eba98c3ea2b8dcba8907979af0bb24ab64b76f30
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
