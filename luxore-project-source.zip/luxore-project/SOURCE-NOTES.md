Independent source snapshot. Base commit: 125538b6052e5e4fc8fcdfae2bca492ed87b10bf
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
