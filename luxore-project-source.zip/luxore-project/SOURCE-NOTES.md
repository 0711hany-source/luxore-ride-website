Independent source snapshot. Base commit: 30690533b1e93ee1d7f96344933d5aa1d1360af6
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
