Independent source snapshot. Base commit: e3978addc911619366eaf91561281b1477c27a52
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
