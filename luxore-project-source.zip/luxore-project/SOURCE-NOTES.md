Independent source snapshot. Base commit: cd5cac5445624381bd0d96a631758d97832a5bef
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
