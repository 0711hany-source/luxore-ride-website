Independent source snapshot. Base commit: ff268d206e8e02cf4853850b3ab1332e9fad91e0
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
