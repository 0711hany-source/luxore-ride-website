Independent source snapshot. Base commit: 051cdc4de033cc0d9aba948e763580ce8fcbcfa6
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
