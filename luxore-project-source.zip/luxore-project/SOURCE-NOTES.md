Independent source snapshot. Base commit: f84d5ef80529979519cc4624d5dcfdf27fdeec35
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
