Independent source snapshot. Base commit: 6856fb949bac65550aae1bc6aceb9be526f37449
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
