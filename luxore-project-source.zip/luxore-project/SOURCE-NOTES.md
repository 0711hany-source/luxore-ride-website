Independent source snapshot. Base commit: 143099cc86b09189eeddad0a1399b57f2de785d6
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
