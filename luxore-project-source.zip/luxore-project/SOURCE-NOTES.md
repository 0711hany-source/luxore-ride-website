Independent source snapshot. Base commit: f0da5a76ca0dd30b45bbe28e8662e711bc01f63a
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
