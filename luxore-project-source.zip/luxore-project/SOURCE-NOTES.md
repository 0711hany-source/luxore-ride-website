Independent source snapshot. Base commit: 25b865dd5bb55a67f9ef005df14df5d990494ac1
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
