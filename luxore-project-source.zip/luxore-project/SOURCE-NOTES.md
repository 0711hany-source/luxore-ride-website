Independent source snapshot. Base commit: 460f7b1391bf8e5e8960e38eae895cc60eed884a
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
