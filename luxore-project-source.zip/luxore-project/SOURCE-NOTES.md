Independent source snapshot. Base commit: e70741685c0e691d54d60f02fc800e52b3708c7e
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
