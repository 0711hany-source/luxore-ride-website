Independent source snapshot. Base commit: d161e8e00ec604218df6112177f66bb266322cd7
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
