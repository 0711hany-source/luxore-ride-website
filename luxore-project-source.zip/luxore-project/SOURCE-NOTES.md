Independent source snapshot. Base commit: c87d82b4ae3bab1abcfd13333e8c6da8fe58fbf0
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
