Independent source snapshot. Base commit: d6afa38c0c063cc0ba4fb246272222f356c0eead
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
