Independent source snapshot. Base commit: d0b9bb33efd3f43166423d4bbe02c8ab6f2f73a3
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
