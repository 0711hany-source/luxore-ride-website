Independent source snapshot. Base commit: 78f74df80a1bb91167ebde28975c15586742c690
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
