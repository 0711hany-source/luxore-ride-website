Independent source snapshot. Base commit: 4974aabcc56d86335bc23767e92b6fc4f0c85dcb
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
