Independent source snapshot. Base commit: 0e7471cc99c00e5ce806f93470c449694a54ab2b
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
