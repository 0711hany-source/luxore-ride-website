Independent source snapshot. Base commit: 8a99765a1e0f89d553161ce2cdf5d94149ff0f5a
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
