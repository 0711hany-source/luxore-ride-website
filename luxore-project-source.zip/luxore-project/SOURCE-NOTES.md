Independent source snapshot. Base commit: 190e50f4c43ae1853dba886ec9abe35f0deeb7cb
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
