Independent source snapshot. Base commit: 8a2e4f17594d5652f93c1fef444ea5ff57de1056
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
