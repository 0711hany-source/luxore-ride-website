Independent source snapshot. Base commit: a460f70cc294afddfb5fe1a772f6cc2412ff9380
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
