Independent source snapshot. Base commit: 7e111d03402e42adb832a1a06698eb994b8feca0
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
