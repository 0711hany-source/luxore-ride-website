Independent source snapshot. Base commit: 7173712684e9827ad8d4784a5533ac2d12024c2e
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
