Independent source snapshot. Base commit: bb457dd70cf2fb44afb98fa6b223ccb97ca822b6
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
