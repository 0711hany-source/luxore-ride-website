Independent source snapshot. Base commit: 347d6a5fa5faeae87ccd3b609d49293e327ec1e4
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
