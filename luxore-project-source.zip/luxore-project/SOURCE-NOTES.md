Independent source snapshot. Base commit: 41c95e239427c65cd9f90f1a3d85ec1313bfa8ef
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
