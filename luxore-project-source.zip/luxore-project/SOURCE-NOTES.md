Independent source snapshot. Base commit: c4a3f5a981e2d6be83c49503760d092b2c921253
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
