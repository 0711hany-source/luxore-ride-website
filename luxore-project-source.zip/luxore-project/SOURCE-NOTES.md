Independent source snapshot. Base commit: 525d8ed70990c46ddcc319ede8673f536634e600
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
