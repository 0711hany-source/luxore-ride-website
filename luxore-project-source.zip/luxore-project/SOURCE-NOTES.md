Independent source snapshot. Base commit: 2efb2ac2e0e7c876cb3f91d2ff0dc1513ff194b8
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
