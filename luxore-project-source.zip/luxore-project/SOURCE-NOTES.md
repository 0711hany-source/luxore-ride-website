Independent source snapshot. Base commit: c03560b2d878ba67727648e627eb52b1968ad993
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
