Independent source snapshot. Base commit: 5d763c2351b83d69e2820925fbe979eff9ad315f
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
