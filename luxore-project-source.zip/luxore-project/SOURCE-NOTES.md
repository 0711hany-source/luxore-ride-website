Independent source snapshot. Base commit: f414350e04de561f4d69c90e60ed29da9ecaa66b
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
