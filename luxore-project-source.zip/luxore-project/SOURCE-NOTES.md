Independent source snapshot. Base commit: be2e94fbcb146bb5ccaf52ae1676f52a2a2a4f9e
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
