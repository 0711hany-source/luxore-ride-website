Independent source snapshot. Base commit: 735a3ef6fe87b3d3f28de8688bbb10f610a5d948
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
