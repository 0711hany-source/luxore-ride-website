Independent source snapshot. Base commit: 1a8e868d36816f5e6509d80e8d4f59c550acbb89
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
