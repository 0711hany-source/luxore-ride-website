Independent source snapshot. Base commit: e0e67f3605889f05abf1df20859cde805a4287d9
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
