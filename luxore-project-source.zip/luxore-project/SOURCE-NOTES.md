Independent source snapshot. Base commit: 88a0d82d95228e90b563820c6504e223fc3af7c8
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
