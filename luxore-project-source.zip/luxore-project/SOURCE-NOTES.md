Independent source snapshot. Base commit: 742e175d4dd672e313468974f3bcbfae60384f11
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
