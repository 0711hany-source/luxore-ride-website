Independent source snapshot. Base commit: 5efd39ef6bb87ea75ed68d432a3f3114ba6da6d2
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
