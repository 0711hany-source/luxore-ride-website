Independent source snapshot. Base commit: 6944faeae4bd75ef0a67bab552e58f831b9703a9
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
