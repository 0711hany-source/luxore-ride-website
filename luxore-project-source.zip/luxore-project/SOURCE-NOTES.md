Independent source snapshot. Base commit: fab201b6200bca1b55af725047c9efbc51217c5d
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
