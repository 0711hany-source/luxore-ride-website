Independent source snapshot. Base commit: 6ceff5b16c905bc8c4cc0c6c7f9a396b4a8d93c1
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
