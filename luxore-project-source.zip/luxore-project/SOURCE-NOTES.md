Independent source snapshot. Base commit: f4371de32cce65cc9d987866b9534b19111b4f36
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
