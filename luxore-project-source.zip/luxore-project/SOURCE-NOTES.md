Independent source snapshot. Base commit: 0ef2989648ab5ee0d7d2e315e5001639408bef75
The private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.
