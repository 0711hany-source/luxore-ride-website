import PartnerScreen from './screen';
export { viewport } from '@/app/mobile/layout';
export const dynamic = 'force-dynamic';
export const metadata = {
  title: 'Partnerflotte werden | LUXORÉ RIDE',
  robots: { index: false, follow: false },
};
export default function Page() {
  return <PartnerScreen />;
}
