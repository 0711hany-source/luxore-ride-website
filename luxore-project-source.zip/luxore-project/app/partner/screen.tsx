'use client';
import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { api, MobilityApiError } from '@/app/mobility/api';
import Papers from '@/app/mobility/papers';

type Application = {
  id: string;
  fleet_id: string;
  company: string;
  legal_form: string;
  status: 'submitted' | 'approved' | 'rejected' | 'withdrawn';
  reason: string | null;
  created_at: number;
};
type State = {
  applications: Application[];
  fleet: { id: string; name: string } | null;
  signedIn: boolean;
};
const empty = {
  company: '',
  legalForm: '',
  address: '',
  contact: '',
  phone: '',
  taxId: '',
};
/** Application as a partner fleet: form, papers, status. */
export default function PartnerScreen() {
  const [data, setData] = useState<State | null>(null),
    [guest, setGuest] = useState(false),
    [form, setForm] = useState(empty),
    [accepted, setAccepted] = useState(false),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    try {
      setData(await api<State>('fleet-applications'));
      setError('');
    } catch (e) {
      if (e instanceof MobilityApiError && e.status === 401) setGuest(true);
      else setError((e as Error).message);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  const set = (key: keyof typeof empty) => (e: { target: { value: string } }) =>
    setForm((v) => ({ ...v, [key]: e.target.value }));
  async function send(body: Record<string, unknown>) {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      await api('fleet-applications', body);
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const current = data?.applications.find((a) => a.status === 'submitted');
  const last = data?.applications[0];
  const signIn = (
    <Link className="pf-btn primary wide" href="/konto?weiter=%2Fpartner">
      Mit LUXORÉ-Konto anmelden
    </Link>
  );
  return (
    <main className="partner-page">
      <div className="pf">
        <Link href="/" className="lux-logo">
          LUXORÉ <span>RIDE</span>
        </Link>
        <div>
          <h1>Partnerflotte werden</h1>
          <p className="pf-muted">
            Bewirb dich mit deinem Unternehmen. Wir prüfen deine Angaben und
            Unterlagen und melden uns. Erst nach unserer Annahme wird deine
            Flotte angelegt.
          </p>
        </div>
        {error && (
          <p className="pf-error" role="alert">
            {error}
          </p>
        )}
        {guest || (data && !data.signedIn) ? (
          <div className="pf-card">
            <p>Für den Antrag brauchst du ein angemeldetes LUXORÉ-Konto.</p>
            {signIn}
          </div>
        ) : !data ? (
          <p className="pf-muted">Einen Moment …</p>
        ) : data.fleet ? (
          <div className="pf-card">
            <p className="pf-notice good">
              Dein Konto gehört zur Flotte „{data.fleet.name}“.
            </p>
            <Link className="pf-btn primary wide" href="/disposition">
              Zur Flottenverwaltung
            </Link>
          </div>
        ) : current ? (
          <>
            <div className="pf-card attention">
              <div className="pf-row">
                <strong>
                  {current.company} ({current.legal_form})
                </strong>
                <span className="pf-chip warn">wird geprüft</span>
              </div>
              <p className="pf-muted">
                Antrag vom{' '}
                {new Date(current.created_at).toLocaleDateString('de-DE', {
                  timeZone: 'Europe/Berlin',
                })}
                . Bitte lade jetzt deine Gewerbeanmeldung oder Genehmigung hoch –
                ohne Unterlagen können wir nicht prüfen.
              </p>
            </div>
            <Papers subjectType="fleet" subjectId={current.fleet_id} />
            <button
              type="button"
              className="pf-btn"
              disabled={busy}
              onClick={() => void send({ action: 'withdraw', id: current.id })}
            >
              Antrag zurückziehen
            </button>
          </>
        ) : (
          <>
            {last?.status === 'rejected' && (
              <p className="pf-notice danger">
                Dein Antrag für „{last.company}“ wurde abgelehnt
                {last.reason ? ': ' + last.reason : '.'} Du kannst einen neuen
                Antrag stellen.
              </p>
            )}
            <form
              className="pf-card pf-form"
              onSubmit={(e) => {
                e.preventDefault();
                void send({ action: 'apply', ...form, accepted });
              }}
            >
              <label className="pf-field">
                Firmenname
                <input value={form.company} required maxLength={100} onChange={set('company')} />
              </label>
              <div className="pf-grid2">
                <label className="pf-field">
                  Rechtsform
                  <input
                    value={form.legalForm}
                    required
                    maxLength={60}
                    placeholder="z. B. GmbH, Einzelunternehmen"
                    onChange={set('legalForm')}
                  />
                </label>
                <label className="pf-field">
                  Steuernummer oder USt-ID (freiwillig)
                  <input value={form.taxId} maxLength={40} onChange={set('taxId')} />
                </label>
              </div>
              <label className="pf-field">
                Anschrift
                <input
                  value={form.address}
                  required
                  maxLength={200}
                  autoComplete="street-address"
                  placeholder="Straße, Hausnummer, PLZ, Ort"
                  onChange={set('address')}
                />
              </label>
              <div className="pf-grid2">
                <label className="pf-field">
                  Ansprechpartner
                  <input
                    value={form.contact}
                    required
                    maxLength={80}
                    autoComplete="name"
                    onChange={set('contact')}
                  />
                </label>
                <label className="pf-field">
                  Telefon
                  <input
                    value={form.phone}
                    required
                    type="tel"
                    maxLength={30}
                    autoComplete="tel"
                    onChange={set('phone')}
                  />
                </label>
              </div>
              <label className="pf-check">
                <input
                  type="checkbox"
                  checked={accepted}
                  onChange={(e) => setAccepted(e.target.checked)}
                />
                <span>
                  Mir ist bekannt: Für jede abgeschlossene und kassierte Fahrt
                  berechnet LUXORÉ RIDE der Flotte eine Servicepauschale von
                  15 % des Fahrpreises. Abgerechnet wird wöchentlich (Montag bis
                  Sonntag). Ich bestätige das.
                </span>
              </label>
              <button type="submit" className="pf-btn primary wide" disabled={busy || !accepted}>
                {busy ? 'Wird gesendet …' : 'Antrag senden'}
              </button>
              <p className="pf-muted">
                Der Antrag ist noch keine Zusage. Nach dem Senden lädst du deine
                Gewerbeanmeldung oder Genehmigung als Foto hoch.
              </p>
            </form>
          </>
        )}
      </div>
    </main>
  );
}
