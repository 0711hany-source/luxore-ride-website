'use client';
import { useCallback, useEffect, useState } from 'react';
import { api, MobilityApiError } from '@/app/mobility/api';
import DriverCompliance from '@/app/mobility/driver-compliance';
import FleetCompliance from '@/app/mobility/fleet-compliance';
import type { ReviewArea } from '@/lib/mobility/app-targets';

type Own = {
  driver: { vehicle: { id: string; plate: string } | null } | null;
};
type Fleet = {
  fleet: { id: string; name: string };
  vehicles: { id: string }[];
  drivers: { id: string }[];
};
type State =
  | { step: 'loading' }
  | { step: 'error'; message: string }
  | { step: 'guest' }
  | {
      step: 'ready';
      accountId: string;
      own: Own['driver'];
      fleet: Fleet | null;
      operator: boolean;
    };

/**
 * Papers and weekly check only — no shift switch, map or menu. Shows what the
 * signed-in role may do; every right is still decided by the API routes.
 */
export default function ReviewScreen({
  area,
  vehicleId,
  driverId,
  invalidLink,
}: {
  area: ReviewArea | null;
  vehicleId: string | null;
  driverId: string | null;
  invalidLink: boolean;
}) {
  const [state, setState] = useState<State>({ step: 'loading' });
  const load = useCallback(async () => {
    try {
      const { account } = await api<{ account: { id: string } | null }>('account');
      if (!account) return setState({ step: 'guest' });
      let operator = false;
      const [own, fleet] = await Promise.all([
        api<Own>('compliance'),
        api<Fleet>('compliance?scope=fleet').catch((e) => {
          // 403: not a fleet lead. 404: the operator, who has no single fleet.
          if (e instanceof MobilityApiError && [403, 404].includes(e.status)) {
            operator = e.status === 404;
            return null;
          }
          throw e;
        }),
      ]);
      setState({
        step: 'ready',
        accountId: account.id,
        own: own.driver,
        fleet,
        operator,
      });
    } catch (e) {
      if (e instanceof MobilityApiError && e.status === 401)
        return setState({ step: 'guest' });
      setState({ step: 'error', message: (e as Error).message });
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);

  let body;
  if (state.step === 'loading')
    body = <p className="pf-muted">Wird geladen …</p>;
  else if (state.step === 'error')
    body = (
      <>
        <p className="pf-error" role="alert">
          {state.message}
        </p>
        <button
          type="button"
          className="pf-btn wide"
          onClick={() => {
            setState({ step: 'loading' });
            void load();
          }}
        >
          Erneut versuchen
        </button>
      </>
    );
  else if (state.step === 'guest')
    body = (
      <>
        <p className="pf-notice">
          Bitte melde dich mit deinem LUXORÉ-Konto an. Danach kannst du hier
          Papiere hochladen und die Wochenkontrolle durchführen.
        </p>
        <a className="pf-btn primary wide" href="/konto?weiter=/pruefung">
          Zur Anmeldung
        </a>
      </>
    );
  else {
    const { own, fleet, accountId } = state;
    const fleetVehicle =
      vehicleId && fleet?.vehicles.some((v) => v.id === vehicleId)
        ? vehicleId
        : null;
    const fleetDriver =
      driverId && fleet?.drivers.some((d) => d.id === driverId)
        ? driverId
        : null;
    // A requested vehicle or driver must be the caller's own or in the own fleet.
    const foreignVehicle =
      !!vehicleId && !fleetVehicle && own?.vehicle?.id !== vehicleId;
    const foreignDriver =
      !!driverId && !fleetDriver && !(own && driverId === accountId);
    body = (
      <>
        {(invalidLink || foreignVehicle || foreignDriver) && (
          <p className="pf-notice warn" role="status">
            {invalidLink
              ? 'Dieser Link ist ungültig.'
              : foreignVehicle
                ? 'Dieses Fahrzeug gehört nicht zu deinem Zugang.'
                : 'Dieser Fahrer gehört nicht zu deinem Zugang.'}{' '}
            Angezeigt wird dein eigener Bereich.
          </p>
        )}
        {own && (
          <section className="pf-page-section" aria-label="Mein Bereich">
            <DriverCompliance
              driverId={accountId}
              vehicleId={own.vehicle?.id || null}
              focus={fleetVehicle || fleetDriver ? null : area}
            />
          </section>
        )}
        {fleet && (
          <section className="pf-page-section">
            <div className="pf">
              <h3>Flotte · {fleet.fleet.name}</h3>
              <p className="pf-muted">
                Fahrzeug oder Fahrer antippen, dann Papiere hochladen oder die
                Wochenkontrolle durchführen.
              </p>
            </div>
            <FleetCompliance
              fleetId={fleet.fleet.id}
              focusVehicleId={fleetVehicle}
              focusDriverId={fleetDriver}
              uploadsOnly
            />
          </section>
        )}
        {!own && !fleet && (
          <p className="pf-notice">
            {state.operator
              ? 'Als Betreiber prüfst du Papiere und Kontrollen im Betreiberbereich.'
              : 'Für dieses Konto gibt es hier nichts zu erledigen. Papiere und Wochenkontrolle sind für Fahrer und Flottenleitung gedacht.'}
          </p>
        )}
        {!own && !fleet && state.operator && (
          <a className="pf-btn wide" href="/betreiber">
            Zum Betreiberbereich
          </a>
        )}
      </>
    );
  }
  return (
    <main className="pf-page">
      <header>
        <span className="pf-page-brand">LUXORÉ RIDE</span>
        <h1>Papiere und Wochenkontrolle</h1>
      </header>
      {body}
    </main>
  );
}
