import { databaseConfigured } from '@/db/sqlite';
import ServiceUnavailable from '@/components/service-unavailable';
import { reviewQuery } from '@/lib/mobility/app-targets';
import ReviewScreen from './screen';

export const dynamic = 'force-dynamic';
export const metadata = {
  title: 'Papiere und Wochenkontrolle | LUXORÉ RIDE',
  robots: { index: false, follow: false },
};
// Zoom stays allowed here: papers and photos must be readable.
export const viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
};

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  if (!databaseConfigured()) return <ServiceUnavailable />;
  const pairs = Object.entries(await searchParams).flatMap(([name, value]) =>
    (Array.isArray(value) ? value : [value ?? '']).map((v) => name + '=' + v),
  );
  // Same strict rules as the session handover: unknown names, repeated or
  // malformed values are not used at all.
  const query = reviewQuery(pairs.join('&'));
  return (
    <ReviewScreen
      area={query?.bereich ?? null}
      vehicleId={query?.fahrzeug ?? null}
      driverId={query?.fahrer ?? null}
      invalidLink={!query}
    />
  );
}
