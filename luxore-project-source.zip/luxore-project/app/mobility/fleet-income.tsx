'use client';
import { useCallback, useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Download } from 'lucide-react';
import { api } from './api';
import { money } from '@/lib/ride-domain';
import type {
  Settlement,
  Totals,
  WeekSummary,
} from '@/lib/mobility/settlement';

const SERVICES: Record<string, string> = {
  premium: 'Business Class',
  electric: 'Electric Class',
  van: 'First Class Van',
  first: 'First Class',
};
const day = (at: number) =>
  new Date(at).toLocaleDateString('de-DE', {
    timeZone: 'Europe/Berlin',
    day: '2-digit',
    month: '2-digit',
  });
const stamp = (at: number) =>
  new Date(at).toLocaleString('de-DE', {
    timeZone: 'Europe/Berlin',
    weekday: 'short',
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
export const weekLabel = (start: number, end: number) =>
  `${day(start)} – ${day(end - 1)}`;
const shift = (week: string, days: number) => {
  const [y, m, d] = week.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + days, 12)).toISOString().slice(0, 10);
};
type WeekData = Settlement & {
  notice: string;
  week: string;
  currentWeek: string;
  canSettle: boolean;
};
export function WeekNav({
  week,
  current,
  label,
  onChange,
}: {
  week: string;
  current: string;
  label: string;
  onChange: (week: string) => void;
}) {
  return (
    <div className="pf-weeknav">
      <button
        type="button"
        className="pf-btn"
        aria-label="Vorherige Woche"
        onClick={() => onChange(shift(week, -7))}
      >
        <ChevronLeft size={20} />
      </button>
      <div>
        <strong>{label}</strong>
        <small className="pf-muted">
          Montag bis Sonntag{week === current ? ' · laufende Woche' : ''}
        </small>
      </div>
      <button
        type="button"
        className="pf-btn"
        aria-label="Nächste Woche"
        disabled={week >= current}
        onClick={() => onChange(shift(week, 7))}
      >
        <ChevronRight size={20} />
      </button>
    </div>
  );
}
/** One fleet week: sums, each driver, each trip. The operator may settle it. */
export function WeekDetail({
  fleetId,
  week,
  onWeek,
  onChanged,
}: {
  fleetId: string;
  week: string;
  onWeek: (week: string) => void;
  onChanged?: () => void;
}) {
  const [data, setData] = useState<WeekData | null>(null),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [confirm, setConfirm] = useState(false);
  const load = useCallback(async () => {
    try {
      setData(
        await api<WeekData>(
          `settlements?week=${week}&fleetId=${encodeURIComponent(fleetId)}`,
        ),
      );
      setError('');
    } catch (e) {
      setError((e as Error).message);
    }
  }, [fleetId, week]);
  useEffect(() => {
    setConfirm(false);
    void load();
  }, [load]);
  async function settle(action: 'mark_paid' | 'reopen') {
    if (busy) return;
    setBusy(true);
    try {
      await api('settlements', { action, fleetId, week });
      setConfirm(false);
      await load();
      onChanged?.();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  if (!data || data.week !== week)
    return <p className="pf-muted">{error || 'Abrechnung wird geladen …'}</p>;
  const s = data.statement;
  return (
    <div className="pf">
      <WeekNav
        week={week}
        current={data.currentWeek}
        label={weekLabel(s.start, s.end)}
        onChange={onWeek}
      />
      <p className="pf-notice">{data.notice}. Zuordnung nach Kassierzeitpunkt.</p>
      {error && (
        <p className="pf-error" role="alert">
          {error}
        </p>
      )}
      <div className="pf-row">
        <strong>{s.fleetName}</strong>
        <span className={'pf-chip ' + (data.status === 'paid' ? 'good' : 'warn')}>
          {data.status === 'paid'
            ? 'bezahlt am ' +
              new Date(data.paidAt!).toLocaleDateString('de-DE', {
                timeZone: 'Europe/Berlin',
              })
            : data.closed
              ? 'offen'
              : 'Woche läuft noch'}
        </span>
      </div>
      <div className="pf-stats">
        <div className="pf-stat">
          <small>Fahrten</small>
          <strong>{s.trips}</strong>
        </div>
        <div className="pf-stat">
          <small>Umsatz (Fahrpreise)</small>
          <strong>{money(s.revenue)}</strong>
        </div>
        <div className="pf-stat dark">
          <small>Servicepauschale 15 %</small>
          <strong>{money(s.fee)}</strong>
        </div>
        <div className="pf-stat">
          <small>Rest für die Flotte</small>
          <strong>{money(s.net)}</strong>
        </div>
      </div>
      <p className="pf-muted">
        Kassiert bar {money(s.cash)} · über Terminal {money(s.terminal)}.
        Bordprodukte sind nicht Teil der Pauschale.
      </p>
      {s.drivers.length ? (
        <div className="pf-list">
          {s.drivers.map((d) => (
            <details key={d.driverId}>
              <summary>
                <span>
                  {d.name}
                  <small>
                    {d.trips} {d.trips === 1 ? 'Fahrt' : 'Fahrten'} ·{' '}
                    {money(d.revenue)} · Pauschale {money(d.fee)}
                  </small>
                </span>
              </summary>
              <div className="pf-details-body">
                {d.rides.map((r) => (
                  <div className="pf-trip" key={r.id}>
                    <span>
                      {r.from} → {r.to}
                    </span>
                    <b>{money(r.fare)}</b>
                    <small>
                      {stamp(r.completedAt)} · {SERVICES[r.service] || r.service}{' '}
                      · {r.method === 'terminal' ? 'Terminal' : 'Bar'} · Pauschale{' '}
                      {money(r.fee)}
                    </small>
                  </div>
                ))}
              </div>
            </details>
          ))}
        </div>
      ) : (
        <p className="pf-muted">Keine kassierten Fahrten in dieser Woche.</p>
      )}
      <div className="pf-actions">
        <a
          className="pf-btn"
          href={`/api/mobility/settlements?week=${week}&fleetId=${encodeURIComponent(fleetId)}&format=csv`}
        >
          <Download size={18} /> CSV herunterladen
        </a>
        {data.canSettle &&
          (data.status === 'paid' ? (
            <button
              type="button"
              className="pf-btn"
              disabled={busy}
              onClick={() => (confirm ? void settle('reopen') : setConfirm(true))}
            >
              {confirm ? 'Wirklich zurücknehmen' : 'Zahlung zurücknehmen'}
            </button>
          ) : (
            <button
              type="button"
              className="pf-btn primary"
              disabled={busy || !data.closed}
              title={data.closed ? undefined : 'Erst nach Sonntag 24:00 Uhr möglich'}
              onClick={() => (confirm ? void settle('mark_paid') : setConfirm(true))}
            >
              {confirm
                ? `Eingang von ${money(s.fee)} bestätigen`
                : 'Zahlungseingang vermerken'}
            </button>
          ))}
      </div>
      {data.canSettle && data.status !== 'paid' && confirm && (
        <p className="pf-notice warn">
          Mit der Bestätigung werden die Summen dieser Woche festgeschrieben.
          Spätere Änderungen an Fahrten verändern sie nicht mehr.
        </p>
      )}
    </div>
  );
}
type Income = {
  notice: string;
  currentWeek: string;
  weeks: WeekSummary[];
  months: ({ month: string } & Totals)[];
  openFee: number;
  currentFee: number;
};
/** "Einnahmen" of one fleet: open fee, weeks and months, down to each trip. */
export default function FleetIncome({ fleetId }: { fleetId: string }) {
  const [data, setData] = useState<Income | null>(null),
    [error, setError] = useState(''),
    [mode, setMode] = useState<'weeks' | 'months'>('weeks'),
    [week, setWeek] = useState<string | null>(null);
  const load = useCallback(async () => {
    try {
      setData(
        await api<Income>(
          'settlements?view=income&fleetId=' + encodeURIComponent(fleetId),
        ),
      );
      setError('');
    } catch (e) {
      setError((e as Error).message);
    }
  }, [fleetId]);
  useEffect(() => {
    void load();
  }, [load]);
  if (!data) return <p className="pf-muted">{error || 'Einnahmen werden geladen …'}</p>;
  if (week)
    return (
      <div className="pf">
        <button type="button" className="pf-btn" onClick={() => setWeek(null)}>
          <ChevronLeft size={18} /> Zur Übersicht
        </button>
        <WeekDetail fleetId={fleetId} week={week} onWeek={setWeek} onChanged={load} />
      </div>
    );
  return (
    <div className="pf">
      <p className="pf-notice">{data.notice}</p>
      <div className="pf-stats">
        <div className="pf-stat dark">
          <small>Offene Servicepauschale · abgeschlossene Wochen</small>
          <strong>{money(data.openFee)}</strong>
        </div>
        <div className="pf-stat">
          <small>Laufende Woche · Pauschale bisher</small>
          <strong>{money(data.currentFee)}</strong>
        </div>
      </div>
      <p className="pf-muted">
        Für jede kassierte Fahrt fallen 15 % des Fahrpreises als
        Servicepauschale an. Abgerechnet wird wöchentlich, Montag bis Sonntag.
      </p>
      <div className="pf-segment" role="group" aria-label="Zeitraum">
        <button type="button" aria-pressed={mode === 'weeks'} onClick={() => setMode('weeks')}>
          Wochen
        </button>
        <button type="button" aria-pressed={mode === 'months'} onClick={() => setMode('months')}>
          Monate
        </button>
      </div>
      {mode === 'weeks' ? (
        <div className="pf-list">
          {data.weeks.map((w) => (
            <button
              type="button"
              className="pf-card"
              style={{ textAlign: 'left', cursor: 'pointer' }}
              key={w.week}
              onClick={() => setWeek(w.week)}
            >
              <div className="pf-row">
                <strong>{weekLabel(w.start, w.end)}</strong>
                <span
                  className={
                    'pf-chip ' +
                    (w.status === 'paid' ? 'good' : w.closed && w.fee ? 'warn' : '')
                  }
                >
                  {w.status === 'paid'
                    ? 'bezahlt'
                    : !w.closed
                      ? 'läuft'
                      : w.fee
                        ? 'offen'
                        : 'keine Fahrten'}
                </span>
              </div>
              <span className="pf-muted">
                {w.trips} {w.trips === 1 ? 'Fahrt' : 'Fahrten'} · Umsatz{' '}
                {money(w.revenue)} · Pauschale {money(w.fee)} · Rest {money(w.net)}
              </span>
            </button>
          ))}
        </div>
      ) : (
        <div className="pf-list">
          {data.months.map((m) => (
            <div className="pf-card" key={m.month}>
              <strong>
                {new Date(m.month + '-15T12:00:00Z').toLocaleDateString('de-DE', {
                  month: 'long',
                  year: 'numeric',
                })}
              </strong>
              <span className="pf-muted">
                {m.trips} {m.trips === 1 ? 'Fahrt' : 'Fahrten'} · Umsatz{' '}
                {money(m.revenue)} · Pauschale {money(m.fee)} · Rest {money(m.net)}
                <br />
                bar {money(m.cash)} · Terminal {money(m.terminal)}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
