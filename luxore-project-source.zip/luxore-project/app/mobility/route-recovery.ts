import type { RouteData } from '../../lib/mobility/domain';
import { reliableCourse } from '../../lib/mobility/gps-telemetry.ts';
import { distanceMeters, type GpsFix } from './gps-quality.ts';
import { navigationFixUsable } from './navigation-progress.ts';
import { projectRoad } from './navigation-motion.ts';
import { bearingBetween } from './map-camera.ts';
export type RecoveryReason = 'off-route' | 'wrong-direction';
export type RouteRecovery = {
  route: RouteData;
  reason: RecoveryReason;
  first: GpsFix;
  latest: GpsFix;
  confirmed: boolean;
};
export function routeDeviation(
  route: RouteData,
  fix: GpsFix,
): RecoveryReason | null {
  const line = route.geometry.coordinates;
  const projection = projectRoad(fix, line);
  if (!projection) return null;
  if (projection.distance > Math.max(40, fix.accuracy * 1.5))
    return 'off-route';
  const course = reliableCourse(fix);
  if (course === null || (fix.speed ?? 0) < 3 || fix.accuracy > 25) return null;
  const end = line.at(-1)!;
  // Parking manoeuvres at the destination must not trigger a wrong-direction reroute.
  if (distanceMeters(fix, { lng: end[0], lat: end[1] }) < 25) return null;
  // Consider nearby branches as well: a lagging course at a bend must not label a legal turn wrong.
  const nearby = projection.distance + 8;
  const latMargin = nearby / 111000,
    lngMargin = latMargin / Math.max(0.01, Math.cos((fix.lat * Math.PI) / 180));
  for (let i = 1; i < line.length; i++) {
    if (
      fix.lat < Math.min(line[i - 1][1], line[i][1]) - latMargin ||
      fix.lat > Math.max(line[i - 1][1], line[i][1]) + latMargin ||
      fix.lng < Math.min(line[i - 1][0], line[i][0]) - lngMargin ||
      fix.lng > Math.max(line[i - 1][0], line[i][0]) + lngMargin
    )
      continue;
    const a = { lng: line[i - 1][0], lat: line[i - 1][1] },
      b = { lng: line[i][0], lat: line[i][1] };
    if (distanceMeters(a, b) < 1) continue;
    const difference = Math.abs(
      ((bearingBetween(a, b) - course + 540) % 360) - 180,
    );
    if (
      difference <= 120 &&
      projectRoad(fix, [line[i - 1], line[i]])!.distance <=
        projection.distance + 8
    )
      return null;
  }
  return 'wrong-direction';
}
export function observeRouteRecovery(
  previous: RouteRecovery | null,
  route: RouteData | null,
  fix: GpsFix | null,
  now: number,
): RouteRecovery | null {
  if (
    !route ||
    !navigationFixUsable(fix, now) ||
    now < route.calculatedAt ||
    now - route.calculatedAt > 90000
  )
    return null;
  const prior = previous?.route === route ? previous : null;
  // Re-reading the same cached position is not additional evidence.
  if (prior && fix.timestamp <= prior.latest.timestamp) return prior;
  const reason = routeDeviation(route, fix);
  if (!reason) return null;
  if (
    !prior ||
    prior.reason !== reason ||
    fix.timestamp - prior.latest.timestamp > 10000
  )
    return { route, reason, first: fix, latest: fix, confirmed: false };
  return {
    route,
    reason,
    first: prior.first,
    latest: fix,
    confirmed:
      fix.timestamp - prior.first.timestamp >= 3000 &&
      (reason === 'off-route' || distanceMeters(prior.first, fix) >= 6),
  };
}
export function confirmedRecovery(
  evidence: RouteRecovery | null,
  route: RouteData | null,
  now: number,
): RecoveryReason | null {
  return evidence?.confirmed &&
    evidence.route === route &&
    navigationFixUsable(evidence.latest, now)
    ? evidence.reason
    : null;
}
