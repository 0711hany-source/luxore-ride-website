'use client';
import { useRef, useState } from 'react';
import { Slider } from '@/components/ui/slider';
import { completedSwipe } from './swipe-confirmation';
export default function SwipeAction({
  label,
  disabled,
  onConfirm,
}: {
  label: string;
  disabled: boolean;
  onConfirm: () => void;
}) {
  const [value, setValue] = useState([0]);
  const gesture = useRef<{
    id: number;
    start: number;
    distance: number;
  } | null>(null);
  const keyboard = useRef(false);
  return (
    <div className="swipe-confirm">
      <div className="swipe-confirm-track">
        <span>{label} →</span>
        <Slider
          aria-label={'Zum Bestätigen nach rechts ziehen: ' + label}
          min={0}
          max={100}
          value={value}
          disabled={disabled}
          onPointerDownCapture={(e) => {
            keyboard.current = false;
            if (
              disabled ||
              !(e.target as HTMLElement).closest(
                '[data-slot="slider-thumb"]',
              ) ||
              gesture.current
            ) {
              e.preventDefault();
              e.stopPropagation();
              return;
            }
            gesture.current = {
              id: e.pointerId,
              start: e.clientX,
              distance: 0,
            };
          }}
          onTouchStartCapture={(e) => {
            if (
              disabled ||
              !(e.target as HTMLElement).closest('[data-slot="slider-thumb"]')
            )
              e.stopPropagation();
          }}
          onTouchMoveCapture={(e) => {
            const g = gesture.current;
            if (g && e.touches[0]) g.distance = e.touches[0].clientX - g.start;
          }}
          onTouchCancelCapture={() => {
            gesture.current = null;
            setValue([0]);
          }}
          onPointerMoveCapture={(e) => {
            const g = gesture.current;
            if (g?.id === e.pointerId) g.distance = e.clientX - g.start;
          }}
          onPointerUpCapture={(e) => {
            const g = gesture.current;
            if (g?.id === e.pointerId) g.distance = e.clientX - g.start;
          }}
          onPointerCancelCapture={() => {
            gesture.current = null;
            setValue([0]);
          }}
          onKeyDownCapture={(e) => {
            // Arrow navigation remains available to keyboard users; no click/tap or End-key shortcut.
            if (!['ArrowRight', 'ArrowLeft', 'Tab'].includes(e.key)) {
              e.preventDefault();
              e.stopPropagation();
            }
            keyboard.current = e.key === 'ArrowRight' || e.key === 'ArrowLeft';
          }}
          onValueChange={(v) => setValue(Array.isArray(v) ? v : [v])}
          onValueCommitted={(v) => {
            const n = Array.isArray(v) ? v[0] : v;
            const g = gesture.current;
            const confirm =
              completedSwipe(!!g, g?.distance || 0, n, disabled) ||
              (keyboard.current && n >= 95 && !disabled);
            gesture.current = null;
            if (!keyboard.current || confirm) setValue([0]);
            keyboard.current = false;
            if (confirm) onConfirm();
          }}
        />
      </div>
    </div>
  );
}
