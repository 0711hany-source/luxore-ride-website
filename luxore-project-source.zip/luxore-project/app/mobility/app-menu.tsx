'use client';
import type { CSSProperties } from 'react';
import { useBackLayer } from './use-back-layer';
import { useDismissGesture } from './use-dismiss-gesture';
import {
  CarFront,
  Clock3,
  Headphones,
  LayoutDashboard,
  Settings2,
  PhoneCall,
  X,
  UserRound,
} from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetTitle,
  SheetDescription,
  SheetClose,
} from '@/components/ui/sheet';
import { AppBrand } from './app-header';

export default function AppMenu({
  open,
  onOpenChange,
  driver,
  canDispatch,
  onNavigate,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  driver: boolean;
  canDispatch: boolean;
  onNavigate: (view: string) => void;
}) {
  useBackLayer(open, () => onOpenChange(false), 60);
  const drag = useDismissGesture(() => onOpenChange(false), 'left');
  const items = [
    {
      view: driver ? 'driver' : 'guest',
      label: driver ? 'Chauffeur-Cockpit' : 'Fahrt anfragen',
      detail: driver
        ? 'Status, Aufträge, Navigation & Auto'
        : 'Sofort oder im Voraus terminieren',
      icon: CarFront,
    },
    ...(!driver
      ? [
          {
            view: 'reservations',
            label: 'Meine Fahrten',
            detail: 'Aktuelle & vergangene Buchungen',
            icon: Clock3,
          },
        ]
      : []),
    ...(canDispatch
      ? [
          {
            view: 'operations',
            label: 'Disposition & Flotte',
            detail: 'Flottenverwaltung, Fahrerfreigaben & Fahrten',
            icon: LayoutDashboard,
          },
        ]
      : []),
    {
      view: 'navigation-settings',
      label: 'Einstellungen',
      detail: driver
        ? 'Navigation & automatisches Öffnen'
        : 'Temperatur, Ruhe & Musik',
      icon: Settings2,
    },
    {
      view: 'services',
      label: 'Hilfe & Concierge',
      detail: '24/7 Chauffeur-Hotline & Leistungen',
      icon: Headphones,
    },
  ];

  const roleLabel = canDispatch
    ? 'Disposition & Leitung'
    : driver
      ? 'Fahrerbereich'
      : 'Fahrgast';

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="left"
        className="app-menu-sheet"
        showCloseButton={false}
        style={
          { '--dismiss-x': `${open ? -drag.offset : 0}px` } as CSSProperties
        }
      >
        <div
          className="menu-dismiss-handle"
          {...drag.handlers}
          aria-hidden="true"
        >
          <i />
        </div>
        <div className="app-menu-header">
          <SheetClose className="app-menu-close" aria-label="Menü schließen">
            <X size={19} />
          </SheetClose>
          <div className="app-menu-brand">
            <AppBrand variant={driver ? 'driver' : 'customer'} />
          </div>
          <div className="app-menu-role-chip">
            <span>{roleLabel}</span>
          </div>
          <SheetTitle className="sr-only">
            Luxóre {driver ? 'Driver' : 'Ride'} Menü
          </SheetTitle>
          <SheetDescription className="app-menu-caption">
            Frankfurt am Main
          </SheetDescription>
        </div>

        <nav className="app-menu-nav" aria-label="Hauptnavigation">
          {items.map(({ view, label, detail, icon: Icon }) => (
            <button
              key={view}
              type="button"
              className="app-menu-item"
              onClick={() => {
                onNavigate(view);
                onOpenChange(false);
              }}
            >
              <div className="menu-item-icon">
                <Icon size={21} strokeWidth={1.8} />
              </div>
              <div className="menu-item-text">
                <div className="menu-item-headline">
                  <strong>{label}</strong>
                </div>
                <small>{detail}</small>
              </div>
            </button>
          ))}
        </nav>

        <a
          className="app-menu-item"
          href={`/konto?weiter=${driver ? '%2Fmobile%2Fdriver' : '%2Fmobile%2Fcustomer'}`}
        >
          <div className="menu-item-icon">
            <UserRound size={21} strokeWidth={1.8} />
          </div>
          <div className="menu-item-text">
            <strong>Mein Konto</strong>
            <small>Profil, Anmeldung & Datenschutz</small>
          </div>
        </a>

        <div className="app-menu-footer">
          <a href="tel:+491605083829" className="menu-footer-phone">
            <PhoneCall size={16} />
            <span>+49 160 5083829</span>
          </a>
          <span className="menu-footer-city">
            Frankfurt am Main · 24/7 Service
          </span>
        </div>
      </SheetContent>
    </Sheet>
  );
}
