'use client';
import { useState } from 'react';
import { MapPin } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import type { Booking, Point } from '@/lib/mobility/domain';
import { money } from '@/lib/ride-domain';
import { api } from './api';
import Address from './address';

type Offer = {
  destination: { id: string; label: string };
  distanceMeters: number;
  fare: number;
  currentFare: number;
  price: number;
  currentPrice: number;
  expiresAt: number;
};
/**
 * New destination during the ride. The customer first sees the new price and
 * only the confirmation of exactly that amount changes ride and price
 * (server: destination-offer / destination-confirm).
 */
export default function DestinationChange({
  booking,
  mapsReady,
  refresh,
}: {
  booking: Booking;
  mapsReady: boolean;
  refresh: () => Promise<unknown> | void;
}) {
  const [open, setOpen] = useState(false),
    [place, setPlace] = useState<Point | null>(null),
    [offer, setOffer] = useState<Offer | null>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  if (!['accepted', 'arrived', 'riding'].includes(booking.status)) return null;
  function reset() {
    setPlace(null);
    setOffer(null);
    setError('');
  }
  async function ask(next: Point | null) {
    setPlace(next);
    setOffer(null);
    setError('');
    if (!next) return;
    setBusy(true);
    try {
      setOffer(
        await api<Offer>('bookings', {
          action: 'destination-offer',
          id: booking.id,
          destinationId: next.id,
        }),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function confirm() {
    if (!offer) return;
    setBusy(true);
    setError('');
    try {
      await api('bookings', {
        action: 'destination-confirm',
        id: booking.id,
        fare: offer.fare,
      });
      await refresh();
      reset();
      setOpen(false);
    } catch (e) {
      setError((e as Error).message);
      setOffer(null);
    } finally {
      setBusy(false);
    }
  }
  const difference = offer ? offer.price - offer.currentPrice : 0;
  return (
    <>
      <button
        type="button"
        className="ride-chat-button"
        onClick={() => {
          reset();
          setOpen(true);
        }}
      >
        <MapPin size={19} aria-hidden="true" />
        <span>Ziel ändern</span>
      </button>
      <Dialog
        open={open}
        onOpenChange={(next) => {
          if (!busy) setOpen(next);
        }}
      >
        <DialogContent className="ride-chat-dialog destination-change">
          <DialogHeader>
            <DialogTitle>Ziel ändern</DialogTitle>
            <DialogDescription>
              Wähle das neue Ziel. Du siehst zuerst den neuen Preis – geändert
              wird erst, wenn du ihn bestätigst.
            </DialogDescription>
          </DialogHeader>
          <p className="destination-change-current">
            Bisheriges Ziel: <strong>{booking.route.destination.label}</strong>
          </p>
          <Address
            label="Neues Ziel"
            value={place}
            onChange={(p) => void ask(p)}
            mapsReady={mapsReady}
            near={booking.route.pickup}
          />
          {busy && !offer && (
            <p className="destination-change-note" aria-live="polite">
              Preis wird berechnet …
            </p>
          )}
          {error && (
            <p className="ride-chat-error" role="alert">
              {error}
            </p>
          )}
          {offer && (
            <div className="destination-change-offer" aria-live="polite">
              <div>
                <span>Neuer Gesamtpreis</span>
                <strong>{money(offer.price)}</strong>
              </div>
              <p>
                Bisher {money(offer.currentPrice)}
                {difference === 0
                  ? ' – der Preis bleibt gleich.'
                  : difference > 0
                    ? ` – ${money(difference)} mehr.`
                    : ` – ${money(-difference)} weniger.`}{' '}
                Strecke ab Abholort:{' '}
                {(offer.distanceMeters / 1000).toLocaleString('de-DE', {
                  maximumFractionDigits: 1,
                })}{' '}
                km.
              </p>
              <button
                type="button"
                className="portal-primary"
                disabled={busy}
                onClick={() => void confirm()}
              >
                {busy
                  ? 'Wird geändert …'
                  : `Neues Ziel für ${money(offer.price)} bestätigen`}
              </button>
              <button
                type="button"
                className="portal-secondary"
                disabled={busy}
                onClick={() => setOpen(false)}
              >
                Beim bisherigen Ziel bleiben
              </button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
