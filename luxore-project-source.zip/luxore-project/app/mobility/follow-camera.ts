export type CameraFrame = {
  center: [number, number];
  zoom: number;
  pitch: number;
  bearing: number;
  padding: { top: number; bottom: number; left: number; right: number };
};
const blend = (from: number, to: number, progress: number) =>
  from + (to - from) * progress;
const angle = (from: number, to: number, progress: number) =>
  from + (((to - from + 540) % 360) - 180) * progress;
/** Blend from the visible camera to the moving marker, without a second animation owner. */
export class FollowCamera {
  private origin: CameraFrame | null = null;
  private start = 0;
  private duration = 0;
  begin(from: CameraFrame, now: number, duration = 850) {
    this.origin = {
      ...from,
      center: [...from.center],
      padding: { ...from.padding },
    };
    this.start = now;
    this.duration = Math.max(0, duration);
  }
  cancel() {
    this.origin = null;
  }
  active(now: number) {
    return !!this.origin && now < this.start + this.duration;
  }
  sample(target: CameraFrame, now: number): CameraFrame {
    const from = this.origin;
    if (!from) return target;
    if (!this.duration || now >= this.start + this.duration) {
      this.cancel();
      return target;
    }
    const t = Math.max(0, (now - this.start) / this.duration);
    const progress = t * t * (3 - 2 * t);
    return {
      center: [
        angle(from.center[0], target.center[0], progress),
        blend(from.center[1], target.center[1], progress),
      ],
      zoom: blend(from.zoom, target.zoom, progress),
      pitch: blend(from.pitch, target.pitch, progress),
      bearing: angle(from.bearing, target.bearing, progress),
      padding: {
        top: blend(from.padding.top, target.padding.top, progress),
        bottom: blend(from.padding.bottom, target.padding.bottom, progress),
        left: blend(from.padding.left, target.padding.left, progress),
        right: blend(from.padding.right, target.padding.right, progress),
      },
    };
  }
}
