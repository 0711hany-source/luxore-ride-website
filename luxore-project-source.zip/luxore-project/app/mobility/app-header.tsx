'use client';
import { ArrowLeft } from 'lucide-react';

export function AppBrand({
  variant = 'customer',
}: {
  variant?: 'customer' | 'driver';
}) {
  return (
    <span
      className="luxore-app-brand"
      aria-label={variant === 'driver' ? 'LUXORÉ DRIVER' : 'LUXORÉ RIDE'}
    >
      <span className="brand-main">LUXORÉ</span>
      <span className="brand-suffix">
        {variant === 'driver' ? 'DRIVER' : 'RIDE'}
      </span>
    </span>
  );
}

export interface AppHeaderProps {
  onMenu: () => void;
  showBack?: boolean;
  onBack?: () => void;
  variant?: 'customer' | 'driver';
  title?: string;
  subtitle?: string;
  badge?: string;
}

export default function AppHeader({
  onMenu,
  showBack = false,
  onBack,
  variant = 'customer',
  title,
  subtitle,
  badge,
}: AppHeaderProps) {
  return (
    <header className="app-topbar">
      <div className="app-topbar-left">
        {showBack ? (
          <button
            type="button"
            className="app-topbar-back-btn"
            aria-label="Zurück"
            onClick={onBack}
          >
            <ArrowLeft size={18} strokeWidth={2.2} />
          </button>
        ) : (
          <button
            type="button"
            className="app-topbar-menu-btn"
            aria-label="Menü öffnen"
            onClick={onMenu}
          >
            <div className="menu-bars-icon" aria-hidden="true">
              <span className="bar bar-1" />
              <span className="bar bar-2" />
              <span className="bar bar-3" />
            </div>
          </button>
        )}
      </div>

      <div className="app-topbar-center">
        <AppBrand variant={variant} />
        {title && (
          <span className="app-topbar-context" title={subtitle}>
            {title}
          </span>
        )}
      </div>

      <div className="app-topbar-right">
        {badge && <span className="app-topbar-badge">{badge}</span>}
      </div>
    </header>
  );
}
