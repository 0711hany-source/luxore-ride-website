import type { DriverPosition } from './use-driver-location';
export type NativeStatus = {
  active: boolean;
  alerts?: { enabled: boolean; sound: boolean };
  sessionId?: string;
  expiresAt?: number;
};
export type NativeReply = {
  requestId?: string;
  status?: NativeStatus;
  position?: DriverPosition | null;
  error?: string;
};
declare global {
  interface Window {
    LuxoreNativeLocation?: boolean;
    ReactNativeWebView?: { postMessage(message: string): void };
  }
}
export const nativeLocationAvailable = () =>
  typeof window !== 'undefined' &&
  !!window.LuxoreNativeLocation &&
  !!window.ReactNativeWebView;
let startsInFlight = 0;
export function nativeLocation(
  action:
    | 'start'
    | 'stop'
    | 'status'
    | 'locate'
    | 'test-alert'
    | 'alert-settings',
  credential?: { sessionId: string; nativeToken: string; expiresAt: number },
): Promise<NativeReply> {
  return new Promise((resolve, reject) => {
    if (!nativeLocationAvailable()) {
      reject(new Error('Neue Fahrer-APK erforderlich.'));
      return;
    }
    // Older APKs perform cleanup inside status(). Do not poll while start()
    // is between saving its credential and registering the background task.
    if (action === 'status' && startsInFlight > 0) {
      reject(new Error('Hintergrundstandort wird noch eingerichtet.'));
      return;
    }
    if (action === 'start') startsInFlight++;
    const requestId = crypto.randomUUID();
    let settled = false;
    const done = () => {
      if (settled) return;
      settled = true;
      if (action === 'start') startsInFlight--;
      window.removeEventListener('luxore-location', receive);
      clearTimeout(timer);
    };
    const receive = (event: Event) => {
      const data = (event as CustomEvent<NativeReply>).detail;
      if (settled || data.requestId !== requestId) return;
      done();
      if (data.error) reject(new Error(data.error));
      else resolve(data);
    };
    const timer = setTimeout(
      () => {
        done();
        reject(
          new Error(
            'Standortfreigabe dauert zu lange. Bitte App erneut öffnen.',
          ),
        );
      },
      action === 'start' || action === 'locate' ? 30000 : 15000,
    );
    window.addEventListener('luxore-location', receive);
    try {
      window.ReactNativeWebView!.postMessage(
        JSON.stringify({
          type: 'luxore-location',
          action,
          requestId,
          credential,
        }),
      );
    } catch (error) {
      done();
      reject(error);
    }
  });
}
