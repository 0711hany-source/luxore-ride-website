'use client';
import { useEffect, useId, useRef, type ReactNode } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import type { SheetStop } from './sheet-motion';
import { useSheetMotion } from './use-sheet-motion';
export default function DriverSheet({
  children,
  title,
  subtitle,
  peekSubtitle,
  className = '',
  initialStop = 'half',
  reservedTop = 0,
  collapseRequest = 0,
  onHeightChange,
}: {
  children: ReactNode;
  title: string;
  subtitle: string;
  peekSubtitle?: string;
  className?: string;
  initialStop?: SheetStop;
  reservedTop?: number;
  collapseRequest?: number;
  onHeightChange: (height: number) => void;
}) {
  const root = useRef<HTMLElement>(null);
  const motion = useSheetMotion(
      root,
      collapseRequest,
      initialStop,
      reservedTop,
    ),
    id = useId();
  useEffect(
    () => onHeightChange(motion.height),
    [motion.height, onHeightChange],
  );
  return (
    <section
      ref={root}
      className={`driver-action-sheet driver-swipe-sheet ${className}`}
      data-stop={motion.stop}
      data-dragging={motion.dragging || undefined}
      style={{ height: motion.height }}
    >
      <button
        type="button"
        className="driver-sheet-grip"
        {...motion.handlers}
        aria-expanded={motion.stop !== 'peek'}
        aria-controls={id}
        aria-label={
          motion.stop === 'peek'
            ? 'Fahrtfläche öffnen'
            : 'Fahrtfläche verkleinern'
        }
      >
        <i aria-hidden="true" />
        <div className="driver-sheet-grip-content">
          <span className="driver-sheet-grip-text">
            <strong>{title}</strong>
            <small>
              {motion.stop === 'peek'
                ? peekSubtitle || (subtitle.includes('wischen') ? '' : subtitle)
                : subtitle}
            </small>
          </span>
          <span className="driver-sheet-toggle-badge" aria-hidden="true">
            {motion.stop === 'peek' ? (
              <ChevronUp size={18} />
            ) : (
              <ChevronDown size={18} />
            )}
          </span>
        </div>
      </button>
      <div
        id={id}
        className="driver-sheet-body"
        hidden={motion.stop === 'peek' && !motion.dragging}
        inert={motion.stop === 'peek' && !motion.dragging}
      >
        {children}
      </div>
    </section>
  );
}
