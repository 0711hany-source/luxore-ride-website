import { LoaderCircle } from 'lucide-react';
export function AppLoading({
  label = 'Verbindung wird aufgebaut',
}: {
  label?: string;
}) {
  return (
    <div className="app-loading" role="status" aria-live="polite">
      <LoaderCircle size={30} aria-hidden="true" />
      <p>{label}</p>
    </div>
  );
}
