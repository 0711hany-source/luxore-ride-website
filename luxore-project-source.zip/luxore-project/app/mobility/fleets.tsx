'use client';
import Link from 'next/link';
import { useState, useEffect, useCallback, useId, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import {
  Copy,
  Check,
  Share2,
  UserPlus,
  CarFront,
  Users,
  Wallet,
  Package,
  Pencil,
  UserMinus,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { api } from './api';
import { useBackLayer } from './use-back-layer';
import FleetVehicles from './vehicles';
import Inventory from './inventory';
import { money } from '@/lib/ride-domain';
import type { Fleet, Employee } from '@/lib/mobility/domain';
type Revenue = {
  fleet_id: string | null;
  driver_id: string;
  driver_name: string;
  trips: number;
  gross: number;
  collected: number;
  outstanding: number;
};
type State = {
  fleets: (Fleet & { inviteCode?: string })[];
  employees: (Employee & {
    driver_id?: string;
    approved?: number;
    online?: number;
    vehicle_id?: string;
    plate?: string;
    can_remove?: number;
  })[];
  canManage: boolean;
  userId: string;
  revenue: Revenue[];
  period?: string;
};
export function Choice({
  value,
  onChange,
  items,
  label,
  id,
  disabled = false,
}: {
  value: string;
  onChange: (v: string) => void;
  items: { value: string; label: string }[];
  label: string;
  id?: string;
  disabled?: boolean;
}) {
  return (
    <Select
      value={value}
      disabled={disabled}
      onValueChange={(v) => v && onChange(v)}
    >
      <SelectTrigger id={id} aria-label={label}>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {items.map((i) => (
          <SelectItem key={i.value} value={i.value}>
            {i.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
export default function Fleets({
  onChanged,
}: {
  onChanged?: () => Promise<void>;
}) {
  const [data, setData] = useState<State | null>(null),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [name, setName] = useState('Luxóre Ride'),
    [owner, setOwner] = useState('self'),
    [period, setPeriod] = useState('today'),
    [section, setSection] = useState<
      'vehicles' | 'team' | 'revenue' | 'inventory'
    >('vehicles'),
    [selectedFleet, setSelectedFleet] = useState(''),
    [saved, setSaved] = useState(''),
    [rename, setRename] = useState<Fleet | null>(null),
    [fleetName, setFleetName] = useState(''),
    [removal, setRemoval] = useState<{
      fleet: Fleet;
      employee: Employee;
    } | null>(null);
  const saving = useRef(false),
    revision = useRef({ value: 0 });
  useBackLayer(
    !!rename || !!removal,
    () => {
      if (!saving.current) {
        setRename(null);
        setRemoval(null);
      }
    },
    80,
  );
  const periodLabel =
    period === 'all'
      ? 'Gesamter Zeitraum'
      : period === 'today'
        ? 'Heute · Frankfurt'
        : 'Letzte ' + period + ' Tage';
  const refresh = useCallback(async () => {
    const request = ++revision.current.value;
    const value = await api<State>('fleets?period=' + period);
    if (request === revision.current.value) {
      setData({ ...value, period });
      setSelectedFleet((current) =>
        value.fleets.some((f) => f.id === current)
          ? current
          : value.fleets[0]?.id || '',
      );
      setError('');
    }
  }, [period]);
  useEffect(() => {
    let active = true;
    const reads = revision.current;
    async function run() {
      try {
        if (saving.current || document.visibilityState === 'hidden') return;
        await refresh();
      } catch (e) {
        if (active) setError((e as Error).message);
      }
    }
    void run();
    const timer = setInterval(() => void run(), 15000);
    return () => {
      active = false;
      reads.value++;
      clearInterval(timer);
    };
  }, [period, refresh]);
  async function change(body: unknown) {
    if (saving.current) return false;
    saving.current = true;
    setBusy(true);
    setError('');
    setSaved('');
    try {
      const reply = await api<{ id?: string }>('fleets', body);
      if (reply.id) setSelectedFleet(reply.id);
      revision.current.value++;
      setSaved('Änderung gespeichert.');
      await refresh().catch(() =>
        setError('Gespeichert. Bitte die Flottenansicht aktualisieren.'),
      );
      await onChanged?.().catch(() => {});
      return true;
    } catch (e) {
      setError((e as Error).message);
      return false;
    } finally {
      saving.current = false;
      setBusy(false);
    }
  }
  return (
    <section className="fleet-panel">
      <div className="flow-heading">
        <div>
          <div className="eyebrow">UNTERNEHMEN & TEAM</div>
          <h2>Meine Flotte</h2>
        </div>
        <Button
          variant="outline"
          onClick={() => void refresh().catch((e) => setError(e.message))}
        >
          Aktualisieren
        </Button>
      </div>
      {error && (
        <p className="notice error" role="alert">
          {error}
        </p>
      )}
      {saved && (
        <output className="vehicle-saved">
          <Check size={18} />
          {saved}
        </output>
      )}
      <p>Verwalte Fahrzeuge, Team, Umsätze und Bordbestand deiner Flotte.</p>
      {data?.canManage && (
        <form
          className="fleet-create"
          onSubmit={(e) => {
            e.preventDefault();
            void change({
              action: 'create',
              name,
              ownerId: owner === 'self' ? undefined : owner,
            });
          }}
        >
          <label htmlFor="fleet-name">
            Flottenname
            <Input
              id="fleet-name"
              value={name}
              required
              maxLength={100}
              onChange={(e) => setName(e.target.value)}
            />
          </label>
          <label htmlFor="fleet-owner">
            Flottenbesitzer
            <Choice
              id="fleet-owner"
              label="Flottenbesitzer"
              value={owner}
              onChange={setOwner}
              items={[
                { value: 'self', label: 'Ich selbst' },
                ...data.employees
                  .filter((e) => !e.fleet_id && e.user_id !== data.userId)
                  .map((e) => ({ value: e.user_id, label: e.name })),
              ]}
            />
          </label>
          <Button type="submit" disabled={busy}>
            Flotte anlegen
          </Button>
        </form>
      )}
      {section === 'revenue' && (
        <label className="fleet-period" htmlFor="fleet-period">
          Zeitraum
          <Choice
            id="fleet-period"
            label="Zeitraum für Flottenumsätze"
            disabled={busy}
            value={period}
            onChange={setPeriod}
            items={[
              { value: 'today', label: 'Heute · Frankfurt' },
              { value: 'all', label: 'Gesamter Zeitraum' },
              { value: '7', label: 'Letzte 7 Tage' },
              { value: '30', label: 'Letzte 30 Tage' },
            ]}
          />
        </label>
      )}
      {data && data.fleets.length > 1 && (
        <label className="fleet-selector" htmlFor="selected-fleet">
          Flotte auswählen
          <Choice
            label="Aktive Flotte"
            disabled={busy}
            id="selected-fleet"
            value={
              data.fleets.some((f) => f.id === selectedFleet)
                ? selectedFleet
                : data.fleets[0].id
            }
            onChange={setSelectedFleet}
            items={data.fleets.map((f) => ({ value: f.id, label: f.name }))}
          />
        </label>
      )}
      {!data && <p>Flotten werden geladen …</p>}
      {data?.fleets.length === 0 && <p>Noch keine Flotte angelegt.</p>}
      {data?.fleets
        .filter(
          (f) =>
            f.id ===
            (data.fleets.some((item) => item.id === selectedFleet)
              ? selectedFleet
              : data.fleets[0]?.id),
        )
        .map((f) => {
          const members = data.employees.filter((e) => e.fleet_id === f.id),
            rows = data.revenue.filter((r) => r.fleet_id === f.id);
          const sum = (field: 'gross' | 'collected' | 'outstanding') =>
            rows.reduce((s, r) => s + r[field], 0);
          return (
            <article className="fleet-card" key={f.id}>
              <div className="fleet-profile-heading">
                <div>
                  <h3>{f.name}</h3>
                  <span>
                    {members.length} Mitarbeiter · eigene Fahrzeugflotte
                  </span>
                </div>
                {(data.canManage || f.owner_id === data.userId) && (
                  <Button
                    variant="ghost"
                    aria-label="Flottennamen bearbeiten"
                    onClick={() => {
                      setError('');
                      setRename(f);
                      setFleetName(f.name);
                    }}
                  >
                    <Pencil size={18} />
                  </Button>
                )}
              </div>
              <p>
                Besitzer:{' '}
                {members.find((e) => e.user_id === f.owner_id)?.name ||
                  'Nicht zugeordnet'}
              </p>
              <nav className="fleet-sections" aria-label="Flottenbereiche">
                {[
                  { id: 'vehicles', label: 'Fahrzeuge', icon: CarFront },
                  { id: 'team', label: 'Team', icon: Users },
                  { id: 'revenue', label: 'Umsätze', icon: Wallet },
                  { id: 'inventory', label: 'Bestand', icon: Package },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    aria-pressed={section === item.id}
                    onClick={() => setSection(item.id as typeof section)}
                  >
                    <item.icon size={20} />
                    <span>{item.label}</span>
                  </button>
                ))}
              </nav>
              {section === 'revenue' && data.period !== period && (
                <output>Umsätze werden aktualisiert …</output>
              )}
              <div hidden={section !== 'revenue' || data.period !== period}>
                <div className="revenue-cards">
                  <div>
                    <small>Fahrtenumsatz · {periodLabel}</small>
                    <strong>{money(sum('gross'))}</strong>
                  </div>
                  <div>
                    <small>Eingang für diese Fahrten bestätigt</small>
                    <strong>{money(sum('collected'))}</strong>
                  </div>
                  <div>
                    <small>Noch offen für diese Fahrten</small>
                    <strong>{money(sum('outstanding'))}</strong>
                  </div>
                </div>
                <p className="small-note">
                  Fahrpreise vor Kosten und Vergütung; keine Gewinn- oder
                  Lohnauswertung.
                </p>
                <div className="table-scroll">
                  <table className="fleet-table">
                    <caption>Umsatz je Fahrer · {periodLabel}</caption>
                    <thead>
                      <tr>
                        <th>Fahrer</th>
                        <th>Fahrten</th>
                        <th>Fahrpreise</th>
                        <th>Kassiert</th>
                        <th>Offen</th>
                      </tr>
                    </thead>
                    <tbody>
                      {rows.map((r) => (
                        <tr key={r.driver_id}>
                          <td>{r.driver_name}</td>
                          <td>{r.trips}</td>
                          <td>{money(r.gross)}</td>
                          <td>{money(r.collected)}</td>
                          <td>{money(r.outstanding)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {!rows.length && (
                    <p>
                      Noch keine abgeschlossenen Fahrten in diesem Zeitraum.
                    </p>
                  )}
                </div>
              </div>
              <div hidden={section !== 'team'}>
                {data.canManage && (
                  <OwnerTransfer
                    key={f.id + f.owner_id}
                    fleet={f}
                    members={members}
                    busy={busy}
                    save={change}
                  />
                )}
                {data.canManage || f.owner_id === data.userId ? (
                  <Deputy
                    key={f.id + f.deputy_id}
                    fleet={f}
                    members={members}
                    busy={busy}
                    save={change}
                  />
                ) : (
                  <p>
                    Stellvertretung:{' '}
                    {members.find((e) => e.user_id === f.deputy_id)?.name ||
                      'Keine'}
                  </p>
                )}
                {(f.owner_id === data.userId ||
                  f.deputy_id === data.userId) && <FleetInviteCard fleet={f} />}
                <h4>Mitarbeiter & Fahrer ({members.length})</h4>
                <div className="fleet-members-list">
                  {members.map((e) => (
                    <div key={e.user_id} className="fleet-member-row">
                      <div>
                        <strong>{e.name}</strong>
                        <span className="member-role-badge">
                          {e.user_id === f.owner_id
                            ? 'Besitzer / Disposition'
                            : e.user_id === f.deputy_id
                              ? 'Stellvertretung'
                              : e.role === 'driver'
                                ? 'Chauffeur'
                                : 'Mitarbeiter'}
                        </span>
                        {e.phone && <small>{e.phone}</small>}
                        {e.driver_id && (
                          <small>
                            {e.approved ? 'Freigegeben' : 'Freigabe ausstehend'}{' '}
                            · {e.vehicle_id ? e.plate : 'Kein Fahrzeug gewählt'}
                            {e.online ? ' · Online' : ''}
                          </small>
                        )}
                      </div>
                      {e.user_id !== f.owner_id &&
                        e.user_id !== f.deputy_id && (
                          <Button
                            variant="ghost"
                            disabled={busy || !e.can_remove}
                            title={
                              !e.can_remove
                                ? 'Erst offline gehen und offene Fahrten abrechnen'
                                : undefined
                            }
                            onClick={() => {
                              setError('');
                              setRemoval({ fleet: f, employee: e });
                            }}
                          >
                            <UserMinus size={16} />
                            Entfernen
                          </Button>
                        )}
                      {e.driver_id &&
                        (data.canManage ||
                          f.owner_id === data.userId ||
                          f.deputy_id === data.userId) && (
                          <DriverApprovalButton
                            driverId={e.user_id}
                            approved={!!e.approved}
                            onDone={async () => {
                              await refresh();
                              await onChanged?.();
                            }}
                          />
                        )}
                    </div>
                  ))}
                </div>
              </div>
              <div hidden={section !== 'vehicles'}>
                <p className="small-note">
                  Alle Fahrzeuge gehören dieser Flotte. Freigegebene Fahrer
                  können ein freies Auto vor ihrer Schicht selbst auswählen.
                </p>
                <FleetVehicles key={f.id} fleetId={f.id} />
              </div>
              {section === 'inventory' && <Inventory fleetId={f.id} />}
            </article>
          );
        })}
      {data?.canManage && section === 'team' && (
        <>
          <h3>Mitarbeiter zuordnen</h3>
          <p>
            Neue Mitarbeiter reichen ihr Profil unter{' '}
            <Link href="/team">Teamzugang</Link> ein. Fahrerprofile erscheinen
            hier ebenfalls. Die Zuordnung gibt einen Fahrer noch nicht für
            Fahrten frei.
          </p>
          {data.employees
            .filter(
              (e) =>
                !data.fleets.some(
                  (f) => f.owner_id === e.user_id || f.deputy_id === e.user_id,
                ),
            )
            .map((e) => (
              <Assignment
                key={e.user_id + e.fleet_id + e.role}
                employee={e}
                fleets={data.fleets}
                busy={busy}
                save={change}
              />
            ))}
        </>
      )}
      <Dialog
        open={!!rename}
        onOpenChange={(open) => {
          if (!open && !busy) setRename(null);
        }}
      >
        <DialogContent className="fleet-vehicle-dialog" showCloseButton={!busy}>
          <DialogHeader>
            <DialogTitle>Flottenname</DialogTitle>
            <DialogDescription>
              So sehen deine Mitarbeiter das Unternehmen in der App.
            </DialogDescription>
          </DialogHeader>
          <form
            className="vehicle-form"
            onSubmit={(e) => {
              e.preventDefault();
              void change({
                action: 'rename',
                fleetId: rename!.id,
                name: fleetName,
              }).then((ok) => {
                if (ok) setRename(null);
              });
            }}
          >
            <label htmlFor="rename-fleet">
              Name
              <Input
                id="rename-fleet"
                value={fleetName}
                onChange={(e) => setFleetName(e.target.value)}
                required
                maxLength={100}
                disabled={busy}
              />
            </label>
            {error && (
              <p role="alert" className="field-error">
                {error}
              </p>
            )}
            <Button type="submit" disabled={busy || !fleetName.trim()}>
              Namen speichern
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <Dialog
        open={!!removal}
        onOpenChange={(open) => {
          if (!open && !busy) setRemoval(null);
        }}
      >
        <DialogContent className="fleet-vehicle-dialog" showCloseButton={!busy}>
          <DialogHeader>
            <DialogTitle>Mitarbeiter aus Flotte entfernen?</DialogTitle>
            <DialogDescription>
              {removal?.employee.name} verliert die Fahrzeugauswahl und
              Fahrerfreigabe bei {removal?.fleet.name}. Vergangene Fahrten und
              Umsätze bleiben erhalten. Ein späterer Beitritt ist per Einladung
              möglich.
            </DialogDescription>
          </DialogHeader>
          {error && (
            <p role="alert" className="field-error">
              {error}
            </p>
          )}
          <Button
            disabled={busy}
            onClick={() =>
              void change({
                action: 'remove_member',
                fleetId: removal!.fleet.id,
                userId: removal!.employee.user_id,
              }).then((ok) => {
                if (ok) setRemoval(null);
              })
            }
          >
            Aus dieser Flotte entfernen
          </Button>
          <Button
            variant="outline"
            disabled={busy}
            onClick={() => setRemoval(null)}
          >
            Abbrechen
          </Button>
        </DialogContent>
      </Dialog>
    </section>
  );
}
function OwnerTransfer({
  fleet,
  members,
  busy,
  save,
}: {
  fleet: Fleet;
  members: State['employees'];
  busy: boolean;
  save: (b: unknown) => Promise<boolean>;
}) {
  const [owner, setOwner] = useState(''),
    [confirmed, setConfirmed] = useState(false);
  const id = useId();
  const eligible = members.filter(
    (e) =>
      e.user_id !== fleet.owner_id && e.driver_id && e.approved && e.can_remove,
  );
  return (
    <div className="fleet-owner-transfer">
      <h4>Flottenbesitzer übertragen</h4>
      <p>
        Die neue Leitung erhält die Disposition dieser Flotte. Der bisherige
        Besitzer bleibt Mitarbeiter. Beide Fahrer müssen offline sein und offene
        Fahrten abgerechnet haben.
      </p>
      <label htmlFor={id}>
        Neue Leitung
        <select
          id={id}
          value={owner}
          disabled={busy}
          onChange={(e) => {
            setOwner(e.target.value);
            setConfirmed(false);
          }}
        >
          <option value="">Freigegebenen Mitarbeiter wählen</option>
          {eligible.map((e) => (
            <option key={e.user_id} value={e.user_id}>
              {e.name}
            </option>
          ))}
        </select>
      </label>
      <label className="account-consent">
        <input
          type="checkbox"
          disabled={!owner || busy}
          checked={confirmed}
          onChange={(e) => setConfirmed(e.target.checked)}
        />
        <span>
          Ich bestätige die Übergabe der Flottenleitung an diesen Mitarbeiter.
        </span>
      </label>
      <Button
        disabled={!owner || !confirmed || busy}
        onClick={() =>
          void save({
            action: 'transfer_owner',
            fleetId: fleet.id,
            previousOwnerId: fleet.owner_id,
            ownerId: owner,
            confirmed: true,
          })
        }
      >
        Flottenleitung übertragen
      </Button>
      {!eligible.length && (
        <p>
          Kein anderer freigegebener, abgerechneter Fahrer dieser Flotte
          verfügbar.
        </p>
      )}
    </div>
  );
}
function Deputy({
  fleet,
  members,
  busy,
  save,
}: {
  fleet: Fleet;
  members: Employee[];
  busy: boolean;
  save: (b: unknown) => Promise<boolean>;
}) {
  const [value, setValue] = useState(fleet.deputy_id || 'none');
  const choiceId = useId();
  return (
    <div className="fleet-create">
      <label htmlFor={choiceId}>
        Stellvertreter
        <Choice
          id={choiceId}
          label={'Stellvertretung ' + fleet.name}
          value={value}
          onChange={setValue}
          items={[
            { value: 'none', label: 'Keine Stellvertretung' },
            ...members
              .filter((e) => e.user_id !== fleet.owner_id)
              .map((e) => ({ value: e.user_id, label: e.name })),
          ]}
        />
      </label>
      <Button
        disabled={busy}
        onClick={() =>
          void save({
            action: 'deputy',
            fleetId: fleet.id,
            deputyId: value === 'none' ? null : value,
          })
        }
      >
        Stellvertretung speichern
      </Button>
    </div>
  );
}
function Assignment({
  employee: e,
  fleets,
  busy,
  save,
}: {
  employee: Employee;
  fleets: Fleet[];
  busy: boolean;
  save: (b: unknown) => Promise<boolean>;
}) {
  const [fleet, setFleet] = useState(e.fleet_id || 'none'),
    [role, setRole] = useState(e.role);
  return (
    <div className="fleet-create">
      <strong>{e.name}</strong>
      <Choice
        label={'Flotte für ' + e.name}
        value={fleet}
        onChange={setFleet}
        items={[
          { value: 'none', label: 'Noch keine Flotte' },
          ...fleets.map((f) => ({ value: f.id, label: f.name })),
        ]}
      />
      <Choice
        label={'Rolle für ' + e.name}
        value={role}
        onChange={(v) => setRole(v as Employee['role'])}
        items={[
          { value: 'driver', label: 'Fahrer' },
          { value: 'staff', label: 'Mitarbeiter' },
        ]}
      />
      <Button
        disabled={busy}
        onClick={() =>
          void save({
            action: 'assign',
            userId: e.user_id,
            fleetId: fleet === 'none' ? null : fleet,
            role,
          })
        }
      >
        Zuordnen
      </Button>
    </div>
  );
}

function DriverApprovalButton({
  driverId,
  approved,
  onDone,
}: {
  driverId: string;
  approved: boolean;
  onDone: () => Promise<void>;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const toggle = async (approved: boolean) => {
    setBusy(true);
    setError('');
    try {
      await api('operations', { driverId, approved });
      await onDone();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="driver-approval-toggle-group">
      {error && <span role="alert">{error}</span>}
      <Button
        variant={approved ? 'ghost' : 'outline'}
        size="sm"
        disabled={busy}
        onClick={() => toggle(!approved)}
      >
        {!approved && <Check size={14} />}
        {busy ? '…' : approved ? 'Freigabe zurücknehmen' : 'Fahrer freigeben'}
      </Button>
    </div>
  );
}

function FleetInviteCard({ fleet }: { fleet: Fleet }) {
  const [invitation, setInvitation] = useState<{
    code: string;
    shareText: string;
    expiresAt: number;
  } | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  async function createInvite() {
    setBusy(true);
    setMessage('');
    try {
      setInvitation(
        await api('fleets', { action: 'invite_driver', fleetId: fleet.id }),
      );
    } catch (e) {
      setMessage((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function share(copy = false) {
    if (!invitation) return;
    try {
      if (!copy && navigator.share)
        await navigator.share({
          title: `Einladung zu ${fleet.name}`,
          text: invitation.shareText,
        });
      else {
        await navigator.clipboard.writeText(invitation.shareText);
        setMessage('Einladung kopiert.');
      }
    } catch (e) {
      if ((e as Error).name !== 'AbortError')
        setMessage(
          'Einladung konnte nicht geteilt werden. Bitte den Code markieren und kopieren.',
        );
    }
  }
  return (
    <div className="fleet-invite-box">
      <div className="fleet-invite-header">
        <h4>Fahrer einladen</h4>
      </div>
      <p className="fleet-invite-desc">
        Ein persönlicher Code verbindet das Fahrerprofil mit deiner Flotte.
        Danach prüfst du die Angaben und gibst den Fahrer frei. Das Fahrzeug
        wählt er anschließend selbst.
      </p>
      {invitation && (
        <div className="invite-result-box">
          <pre>{invitation.code}</pre>
          <small>
            Gültig bis {new Date(invitation.expiresAt).toLocaleString('de-DE')}
          </small>
        </div>
      )}
      <div className="fleet-invite-actions">
        <Button disabled={busy} onClick={() => void createInvite()}>
          <UserPlus size={16} />
          {busy ? 'Wird erstellt …' : 'Einladung erstellen'}
        </Button>
        {invitation && (
          <>
            <Button variant="outline" onClick={() => void share(true)}>
              <Copy size={16} />
              Kopieren
            </Button>
            <Button variant="outline" onClick={() => void share()}>
              <Share2 size={16} />
              Teilen
            </Button>
          </>
        )}
      </div>
      {message && <p aria-live="polite">{message}</p>}
    </div>
  );
}
