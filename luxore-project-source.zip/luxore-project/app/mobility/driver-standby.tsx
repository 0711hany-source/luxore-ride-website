'use client';
import Image from 'next/image';
import {
  ArrowRight,
  Power,
  Pause,
  BellRing,
  BellOff,
  LoaderCircle,
} from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import type { Driver } from '@/lib/mobility/domain';
import { driverServices } from '@/lib/mobility/domain';
import { classes, className } from '@/lib/ride-domain';
export default function DriverStandby({
  driver,
  backgroundActive = false,
  backgroundNotice,
  alerts,
  alertMessage,
  testingAlert,
  onTestAlert,
  onAlertSettings,
  vehicleRequired,
  tracking,
  locationFresh,
  busy,
  progress,
  error,
  preview = false,
  onAvailability,
  onVehicle,
}: {
  driver: Driver;
  backgroundActive?: boolean;
  backgroundNotice?: string;
  alerts?: { enabled: boolean; sound: boolean };
  alertMessage?: string;
  testingAlert?: boolean;
  onTestAlert?: () => void;
  onAlertSettings?: () => void;
  vehicleRequired: boolean;
  tracking: boolean;
  locationFresh: boolean;
  busy: boolean;
  progress?: string;
  error?: string;
  preview?: boolean;
  onAvailability: () => void;
  onVehicle: () => void;
}) {
  const assigned = !!driver.vehicle_id || !vehicleRequired;
  const online = tracking && driver.online === 1 && locationFresh;
  const car = classes.find((item) => item.id === driver.service)!;
  return (
    <div className="driver-standby">
      <div className="driver-availability-label">
        <i className={online ? 'is-online' : tracking ? 'is-locating' : ''} />
        <span>
          {online
            ? 'Online · bereit für Anfragen'
            : tracking
              ? 'Standort wird aktualisiert'
              : 'Du bist offline'}
        </span>
      </div>
      <h2>
        {online
          ? 'Bereit für die nächste Fahrt.'
          : tracking
            ? 'Einen Moment.'
            : `Guten Tag, ${driver.name.split(' ')[0]}.`}
      </h2>
      <p>
        {online
          ? 'Neue Fahrtangebote erscheinen direkt hier.'
          : tracking
            ? 'Sobald dein Standort aktuell ist, können Fahrten ankommen.'
            : 'Dein Fahrzeug wählen und online gehen.'}
      </p>
      <button className="driver-current-vehicle" onClick={onVehicle}>
        <Image src={car.image} width={112} height={82} unoptimized alt="" />
        <span>
          <strong>{assigned ? driver.vehicle : 'Fahrzeug auswählen'}</strong>
          <small>{assigned ? driver.plate : 'Aus deiner Flotte'}</small>
        </span>
        <ArrowRight size={18} />
      </button>
      <div className="driver-class-list">
        {driverServices(driver).map((service) => (
          <span key={service}>{className(service)}</span>
        ))}
      </div>
      <div className="driver-sheet-actions">
        {preview ? (
          <Link className="driver-availability-action" href="/mobile/driver">
            Fahrer-App öffnen <ArrowRight size={19} />
          </Link>
        ) : (
          <>
            <Button
              type="button"
              className="driver-availability-action"
              disabled={busy}
              aria-pressed={tracking}
              aria-busy={busy}
              onClick={assigned || tracking ? onAvailability : onVehicle}
            >
              {busy ? (
                <LoaderCircle size={19} className="animate-spin" />
              ) : tracking ? (
                <Pause size={19} />
              ) : (
                <Power size={19} />
              )}
              {busy
                ? progress || 'Wird verbunden …'
                : tracking
                  ? 'Pause machen'
                  : assigned
                    ? 'Online gehen'
                    : 'Fahrzeug wählen'}
            </Button>
            {error ? (
              <p className="driver-start-feedback is-error" role="alert">
                {error}
              </p>
            ) : (
              <p
                className="driver-start-feedback"
                role="status"
                aria-live="polite"
              >
                {busy
                  ? progress
                  : online
                    ? 'Du kannst jetzt Fahrtangebote erhalten.'
                    : tracking
                      ? 'Schicht gestartet. Noch keine Fahrten: Ein genauer Standort wird gesucht.'
                      : ''}
              </p>
            )}
          </>
        )}
        {alerts && (
          <div className="driver-alert-control">
            <div>
              {alerts.enabled ? <BellRing size={18} /> : <BellOff size={18} />}
              <span>
                <strong>
                  {alerts.enabled
                    ? alerts.sound
                      ? 'Fahrtalarme erlaubt'
                      : 'Fahrtalarme sind stumm'
                    : 'Fahrtalarme deaktiviert'}
                </strong>
                <small>
                  {alerts.enabled
                    ? 'Ton und Hinweise in Android steuerbar'
                    : 'Bitte aktivieren oder App geöffnet lassen'}
                </small>
              </span>
            </div>
            <div className="driver-alert-buttons">
              <button disabled={testingAlert} onClick={onTestAlert}>
                {testingAlert ? 'Wird geprüft …' : 'Alarm testen'}
              </button>
              <button onClick={onAlertSettings}>Einstellungen</button>
            </div>
            {alertMessage && <output>{alertMessage}</output>}
          </div>
        )}
        <p className="driver-foreground-note" role="status" aria-live="polite">
          {backgroundActive
            ? alerts?.enabled
              ? 'Standort und Fahrtalarme laufen während deiner Online-Schicht im Hintergrund.'
              : 'Standort läuft im Hintergrund. Für neue Fahrtangebote die App öffnen.'
            : backgroundNotice ||
              'Standort und Fahrtangebote in der geöffneten App. Hintergrundstandort mit Fahrer-APK 0.4.'}
        </p>
      </div>
    </div>
  );
}
