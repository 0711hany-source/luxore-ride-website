export type BackLayer = { id: string; priority: number; back: () => void };
/** One owner for each Back press. Keeping lower layers open avoids skipped screens. */
export class BackLayers {
  layers = new Map<string, BackLayer>();
  set(layer: BackLayer) {
    this.layers.delete(layer.id);
    this.layers.set(layer.id, layer);
  }
  remove(id: string) {
    this.layers.delete(id);
  }
  get size() {
    return this.layers.size;
  }
  back() {
    const layer = [...this.layers.values()]
      .sort((a, b) => a.priority - b.priority)
      .at(-1);
    if (!layer) return false;
    layer.back();
    return true;
  }
}

export type BackHistory = {
  hasGuard: () => boolean;
  pushGuard: () => void;
  back: () => void;
};
/** One temporary history entry, shared by all nested app surfaces. */
export class BackNavigation {
  armed: boolean;
  internal = false;
  layers: BackLayers;
  history: BackHistory;
  constructor(layers: BackLayers, history: BackHistory) {
    this.layers = layers;
    this.history = history;
    this.armed = history.hasGuard();
  }
  sync() {
    if (this.internal) return;
    if (this.layers.size && !this.armed) {
      this.history.pushGuard();
      this.armed = true;
    } else if (!this.layers.size && this.armed) {
      this.armed = false;
      if (this.history.hasGuard()) {
        this.internal = true;
        this.history.back();
      }
    }
  }
  pop(hasGuard: boolean) {
    if (this.internal) {
      this.internal = false;
      return;
    }
    if (hasGuard) {
      this.armed = true;
      return;
    }
    if (this.armed) {
      this.armed = false;
      this.layers.back();
    }
  }
}
