'use client';
import { BoardPicker } from './refreshments';
import { cartPrice, type Cart } from '@/lib/mobility/refreshments';
import { useEffect, useRef, type CSSProperties } from 'react';
import { useBackLayer } from './use-back-layer';
import { useDismissGesture } from './use-dismiss-gesture';
import { Dialog as DialogPrimitive } from '@base-ui/react/dialog';
import { ArrowLeft, ArrowRight, Clock3 } from 'lucide-react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogPortal,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import type { Quote, Service } from '@/lib/mobility/domain';
import { classes, className, money } from '@/lib/ride-domain';
import { RidePreferencesPicker } from './ride-preferences';
import type { RidePreferences } from '@/lib/mobility/ride-preferences';
import { AppBrand } from './app-header';
import { useClock } from './use-clock';
export default function BookingCheckout({
  refreshments,
  setRefreshments,
  preferences,
  setPreferences,
  checkout,
  setCheckout,
  quote,
  service,
  riderName,
  setRiderName,
  riderPhone,
  setRiderPhone,
  error,
  busy,
  book,
}: {
  refreshments: Cart;
  setRefreshments: (v: Cart) => void;
  preferences: RidePreferences;
  setPreferences: (value: RidePreferences) => void;
  checkout: boolean;
  setCheckout: (v: boolean) => void;
  quote: Quote | null;
  service: Service;
  riderName: string;
  setRiderName: (v: string) => void;
  riderPhone: string;
  setRiderPhone: (v: string) => void;
  error: string;
  busy: boolean;
  book: () => void;
}) {
  const now = useClock();
  const screen = useRef<HTMLDivElement>(null);
  const open = checkout && !!quote;
  const close = () => {
    if (!busy) setCheckout(false);
  };
  useBackLayer(open, close, 80);
  const drag = useDismissGesture(close, 'down', busy);
  useEffect(() => {
    if (!open) return;
    const viewport = window.visualViewport;
    const resize = () => {
      // Keep the full-screen form inside the visible area when a keyboard opens.
      screen.current?.style.setProperty(
        '--checkout-height',
        `${viewport?.height ?? window.innerHeight}px`,
      );
      screen.current?.style.setProperty(
        '--checkout-top',
        `${viewport?.offsetTop ?? 0}px`,
      );
    };
    const frame = requestAnimationFrame(resize);
    viewport?.addEventListener('resize', resize);
    viewport?.addEventListener('scroll', resize);
    window.addEventListener('resize', resize);
    return () => {
      cancelAnimationFrame(frame);
      viewport?.removeEventListener('resize', resize);
      viewport?.removeEventListener('scroll', resize);
      window.removeEventListener('resize', resize);
    };
  }, [open]);
  const expired = !!quote && now > quote.expiresAt;
  const canBook =
    !busy && !expired && !!riderName.trim() && !!riderPhone.trim();
  const vehicle = classes.find((item) => item.id === service)!;
  return (
    <Dialog
      open={open}
      onOpenChange={(value) => {
        if (!value) close();
      }}
    >
      <DialogPortal>
        <DialogPrimitive.Popup
          ref={screen}
          className="ride-checkout-screen"
          initialFocus={screen}
          style={
            { '--dismiss-y': `${open ? drag.offset : 0}px` } as CSSProperties
          }
        >
          <div
            className="sheet-dismiss-handle checkout-dismiss"
            {...drag.handlers}
            aria-hidden="true"
          >
            <i />
          </div>
          <header className="checkout-topbar">
            <button
              type="button"
              disabled={busy}
              onClick={close}
              aria-label="Zurück zur Fahrzeugauswahl"
            >
              <ArrowLeft size={23} />
            </button>
            <AppBrand />
            <span aria-hidden="true" />
          </header>
          {quote && (
            <>
              <div className="checkout-scroll">
                <div className="checkout-inner">
                  <div className="checkout-heading">
                    <span className="app-kicker">DEINE FAHRT</span>
                    <DialogTitle>Fahrt bestätigen</DialogTitle>
                    <DialogDescription>
                      Prüfe deine Strecke und ergänze deine Kontaktdaten.
                    </DialogDescription>
                  </div>
                  <div className="checkout-vehicle">
                    <Image
                      src={vehicle.image}
                      width={132}
                      height={92}
                      unoptimized
                      alt=""
                    />
                    <div>
                      <strong>{className(service)}</strong>
                      <span>
                        <Clock3 size={14} />
                        {quote.traffic?.unpaved && (
                          <span>Unbefestigter Abschnitt · </span>
                        )}
                        {Math.ceil(quote.durationSeconds / 60)} Min. Fahrt ·{' '}
                        {(quote.distanceMeters / 1000).toLocaleString('de-DE', {
                          maximumFractionDigits: 1,
                        })}{' '}
                        km
                      </span>
                    </div>
                  </div>
                  <div className="checkout-itinerary">
                    <div>
                      <i aria-hidden="true" />
                      <span>
                        <small>Abholung</small>
                        {quote.pickup.label}
                      </span>
                    </div>
                    <div>
                      <i aria-hidden="true" />
                      <span>
                        <small>Ziel</small>
                        {quote.destination.label}
                      </span>
                    </div>
                  </div>
                  <form
                    id="ride-checkout-form"
                    onSubmit={(event) => {
                      event.preventDefault();
                      if (canBook) book();
                    }}
                  >
                    <label htmlFor="rider-name">
                      Dein Name
                      <Input
                        id="rider-name"
                        required
                        value={riderName}
                        autoComplete="name"
                        placeholder="Vor- und Nachname"
                        maxLength={80}
                        onChange={(e) => setRiderName(e.target.value)}
                      />
                    </label>
                    <label htmlFor="rider-phone">
                      Telefonnummer
                      <Input
                        id="rider-phone"
                        required
                        type="tel"
                        value={riderPhone}
                        autoComplete="tel"
                        placeholder="Für deine Abholung"
                        maxLength={30}
                        onChange={(e) => setRiderPhone(e.target.value)}
                      />
                    </label>
                    <details className="board-checkout">
                      <summary>
                        Snacks & Getränke{' '}
                        <span>
                          {cartPrice(refreshments, service)
                            ? `+ ${money(cartPrice(refreshments, service))}`
                            : 'Freimengen inklusive'}
                        </span>
                      </summary>
                      <BoardPicker
                        service={service}
                        value={refreshments}
                        onChange={setRefreshments}
                        disabled={busy}
                      />
                    </details>
                    <RidePreferencesPicker
                      value={preferences}
                      onChange={setPreferences}
                    />
                    <p className="checkout-contact-note">
                      Deine Telefonnummer wird deinem zugewiesenen Fahrer für
                      die Abholung angezeigt.
                    </p>
                    {error && (
                      <p role="alert" className="field-error">
                        {error}
                      </p>
                    )}
                    {expired && (
                      <p role="alert" className="field-error">
                        Preisangebot abgelaufen. Bitte gehe zurück und berechne
                        die Route erneut.
                      </p>
                    )}
                  </form>
                </div>
              </div>
              <footer className="checkout-bottom">
                <div className="checkout-inner">
                  <div className="checkout-total">
                    <span>
                      Voraussichtlicher Gesamtpreis
                      <small>
                        Inkl. gewählter Bordartikel · Zahlung beim Fahrer
                      </small>
                    </span>
                    <strong>
                      {money(
                        quote.prices[service] +
                          cartPrice(refreshments, service),
                      )}
                    </strong>
                  </div>
                  <Button
                    type="submit"
                    form="ride-checkout-form"
                    className="checkout-submit"
                    disabled={!canBook}
                  >
                    {busy
                      ? 'Wird angefragt …'
                      : quote.mode === 'reservation'
                        ? 'Reservierung vormerken'
                        : 'Fahrt anfragen'}
                    <ArrowRight size={19} />
                  </Button>
                </div>
              </footer>
            </>
          )}
        </DialogPrimitive.Popup>
      </DialogPortal>
    </Dialog>
  );
}
