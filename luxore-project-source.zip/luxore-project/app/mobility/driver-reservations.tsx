'use client';
import { useCallback, useEffect, useState } from 'react';
import { api } from './api';
import SwipeAction from './swipe-action';
import { RatingBadge } from './rating';
import { money } from '@/lib/ride-domain';
import type {
  OwnReservation,
  ReservationCard,
} from '@/lib/mobility/reservations';

type Board = {
  ready: boolean;
  reason: string | null;
  needsVehicle?: boolean;
  open: ReservationCard[];
  mine: OwnReservation[];
  rules: { releaseMinutes: number; bufferMinutes: number };
  serverTime: number;
};
const when = (at: number) =>
  new Date(at).toLocaleString('de-DE', {
    timeZone: 'Europe/Berlin',
    weekday: 'short',
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  }) + ' Uhr';
const km = (metres: number) =>
  (metres / 1000).toLocaleString('de-DE', { maximumFractionDigits: 1 }) + ' km';
const minutes = (seconds: number) => {
  const total = Math.max(1, Math.round(seconds / 60));
  return total < 60
    ? total + ' Min.'
    : `${Math.floor(total / 60)} Std. ${total % 60} Min.`;
};
function Facts({ r }: { r: ReservationCard }) {
  return (
    <>
      <div className="pf-row">
        <strong>{when(r.scheduledAt)}</strong>
        <span className="pf-price">{money(r.price)}</span>
      </div>
      <div className="pf-route">
        <strong>{r.pickup}</strong>
        <span>nach {r.destination}</span>
      </div>
      <dl className="pf-facts">
        <div>
          <dt>Strecke · Fahrzeit</dt>
          <dd>
            {km(r.distanceMeters)} · {minutes(r.durationSeconds)}
          </dd>
        </div>
        <div>
          <dt>Klasse</dt>
          <dd>{r.className}</dd>
        </div>
        <div>
          <dt>Bis zu</dt>
          <dd>{r.capacity}</dd>
        </div>
        {!!r.wishes.length && (
          <div>
            <dt>Fahrtwünsche</dt>
            <dd>{r.wishes.join(' · ')}</dd>
          </div>
        )}
        {r.boardOrder && (
          <div>
            <dt>Bordwünsche</dt>
            <dd>{r.boardOrder}</dd>
          </div>
        )}
      </dl>
    </>
  );
}
/**
 * Driver app: open reservations that fit the current vehicle, taking one
 * over by a full swipe, and the driver's own reservations.
 */
export default function DriverReservations({
  onVehicle,
}: {
  onVehicle?: () => void;
}) {
  const [data, setData] = useState<Board | null>(null),
    [tab, setTab] = useState<'open' | 'mine'>('open'),
    [detail, setDetail] = useState<string | null>(null),
    [returning, setReturning] = useState<string | null>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [saved, setSaved] = useState('');
  const load = useCallback(async () => {
    try {
      setData(await api<Board>('reservations'));
    } catch (e) {
      setError((e as Error).message);
    }
  }, []);
  useEffect(() => {
    void load();
    const timer = setInterval(() => void load(), 30000);
    return () => clearInterval(timer);
  }, [load]);
  async function act(action: 'claim' | 'release', id: string, done: string) {
    setBusy(true);
    setError('');
    setSaved('');
    try {
      await api('reservations', { action, id });
      setSaved(done);
      setDetail(null);
      setReturning(null);
      if (action === 'claim') setTab('mine');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      await load();
      setBusy(false);
    }
  }
  if (!data)
    return (
      <div className="pf">
        <p className={error ? 'pf-error' : 'pf-muted'} role="status">
          {error || 'Reservierungen werden geladen …'}
        </p>
        {error && (
          <button type="button" className="pf-btn wide" onClick={() => void load()}>
            Erneut versuchen
          </button>
        )}
      </div>
    );
  // The server decides the deadline; its clock is the reference here too.
  const now = data.serverTime;
  return (
    <div className="pf">
      <div className="pf-segment" role="group" aria-label="Ansicht">
        <button
          type="button"
          aria-pressed={tab === 'open'}
          onClick={() => setTab('open')}
        >
          Offen ({data.open.length})
        </button>
        <button
          type="button"
          aria-pressed={tab === 'mine'}
          onClick={() => setTab('mine')}
        >
          Meine ({data.mine.length})
        </button>
      </div>
      {error && (
        <p className="pf-error" role="alert">
          {error}
        </p>
      )}
      {saved && (
        <p className="pf-saved" role="status">
          {saved}
        </p>
      )}
      {tab === 'open' && (
        <div className="pf-list">
          {!data.ready && data.reason && (
            <div className="pf-notice warn">
              <p>{data.reason}</p>
              {onVehicle && data.needsVehicle && (
                <button
                  type="button"
                  className="pf-btn wide"
                  style={{ marginTop: 12 }}
                  onClick={onVehicle}
                >
                  Fahrzeug wählen
                </button>
              )}
            </div>
          )}
          {data.ready && !data.open.length && (
            <p className="pf-muted">
              Gerade gibt es keine offene Reservierung, die zu deinem Fahrzeug
              passt. Neue Reservierungen erscheinen hier von selbst.
            </p>
          )}
          {data.open.map((r) => (
            <article
              key={r.id}
              className={'pf-card' + (r.conflict ? ' attention' : '')}
            >
              <Facts r={r} />
              {r.conflict ? (
                <p className="pf-notice warn">
                  Überschneidet sich mit einer Reservierung, die du schon
                  übernommen hast (Fahrzeit plus {data.rules.bufferMinutes}{' '}
                  Minuten Abstand).
                </p>
              ) : detail === r.id ? (
                <>
                  <p className="pf-muted">
                    Mit dem Übernehmen ist diese Fahrt fest dir zugeteilt. Der
                    Fahrgast sieht deinen Namen, dein Fahrzeug und dein
                    Profilbild. Abgeben kannst du bis{' '}
                    {data.rules.releaseMinutes} Minuten vor der Abholung.
                  </p>
                  <SwipeAction
                    label="Reservierung übernehmen"
                    disabled={busy}
                    onConfirm={() =>
                      void act(
                        'claim',
                        r.id,
                        'Übernommen. Die Reservierung steht jetzt unter „Meine“.',
                      )
                    }
                  />
                  <button
                    type="button"
                    className="pf-btn wide"
                    disabled={busy}
                    onClick={() => setDetail(null)}
                  >
                    Doch nicht
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  className="pf-btn primary wide"
                  onClick={() => {
                    setDetail(r.id);
                    setError('');
                    setSaved('');
                  }}
                >
                  Ansehen und übernehmen
                </button>
              )}
            </article>
          ))}
          <p className="pf-muted">
            Name und Telefonnummer des Fahrgasts siehst du erst nach dem
            Übernehmen.
          </p>
        </div>
      )}
      {tab === 'mine' && (
        <div className="pf-list">
          {!data.mine.length && (
            <p className="pf-muted">
              Du hast zurzeit keine Reservierung übernommen.
            </p>
          )}
          {data.mine.map((r) => {
            const mayReturn = now < r.releaseUntil;
            return (
              <article
                key={r.id}
                className={'pf-card' + (r.check ? ' attention' : '')}
              >
                <Facts r={r} />
                {r.check && (
                  <p className="pf-notice warn" role="status">
                    <strong>Zuteilung prüfen.</strong> {r.check}
                  </p>
                )}
                {r.contactHidden ? (
                  <p className="pf-muted">
                    Name und Telefonnummer des Fahrgasts siehst du wieder,
                    sobald das geklärt ist.
                  </p>
                ) : (
                  <div className="pf-row">
                    <div className="pf-route">
                      <span>Fahrgast</span>
                      <strong>{r.riderName || 'Fahrgast'}</strong>
                    </div>
                    <RatingBadge
                      rating={r.riderRating}
                      emptyLabel="Noch keine Bewertung"
                    />
                  </div>
                )}
                {r.riderPhone && (
                  <a
                    className="pf-btn wide"
                    href={'tel:' + r.riderPhone.replace(/[^+\d]/g, '')}
                  >
                    Fahrgast anrufen · {r.riderPhone}
                  </a>
                )}
                {!r.check && (
                  <p className="pf-muted">
                    15 Minuten vor der Abholung bekommst du das Fahrtangebot
                    zuerst. Sei dann online – sonst geht die Fahrt an einen
                    anderen Fahrer.
                  </p>
                )}
                {!mayReturn ? (
                  <p className="pf-notice">
                    Abgeben ist nur bis {data.rules.releaseMinutes} Minuten vor
                    der Abholung möglich. Bitte wende dich an deine
                    Flottenleitung.
                  </p>
                ) : returning === r.id ? (
                  <div className="pf-actions">
                    <button
                      type="button"
                      className="pf-btn danger"
                      disabled={busy}
                      onClick={() =>
                        void act(
                          'release',
                          r.id,
                          'Abgegeben. Die Reservierung ist wieder offen.',
                        )
                      }
                    >
                      Ja, abgeben
                    </button>
                    <button
                      type="button"
                      className="pf-btn"
                      disabled={busy}
                      onClick={() => setReturning(null)}
                    >
                      Behalten
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    className="pf-btn wide"
                    onClick={() => setReturning(r.id)}
                  >
                    Reservierung abgeben
                  </button>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
