import type { NativeReply } from './native-location';
import { matchesNativeShift } from './native-status.ts';

/** Background permission must never hold the foreground shift controls hostage. */
export async function startShiftBackground({
  sessionId,
  currentSession,
  isCurrent,
  start,
  stop,
  ready,
  unavailable,
}: {
  sessionId: string;
  currentSession: () => string | null;
  isCurrent: () => boolean;
  start: () => Promise<NativeReply>;
  stop: () => Promise<unknown>;
  ready: (reply: NativeReply) => void;
  unavailable: (message: string) => void;
}) {
  try {
    const reply = await start();
    if (!isCurrent()) {
      // A late start after Pause may still have activated the native service.
      // Never stop a newer shift. The server already revoked the old session.
      if (currentSession() === null) await stop().catch(() => {});
      return;
    }
    if (
      !reply.status ||
      !matchesNativeShift(reply.status, sessionId, null, Date.now())
    )
      throw new Error('Hintergrundstandort wurde noch nicht bestätigt.');
    ready(reply);
  } catch (error) {
    if (!isCurrent()) return;
    unavailable(
      error instanceof Error
        ? error.message.replace('Du bleibst offline.', '').trim()
        : 'Hintergrundstandort wurde noch nicht bestätigt.',
    );
  }
}
