'use client';
import { useEffect } from 'react';
/** Portalled sheets share the same visible frame as the app when the keyboard opens. */
export function useAppViewport(enabled: boolean) {
  useEffect(() => {
    if (!enabled) return;
    const style = document.documentElement.style;
    const keys = [
      '--app-visible-height',
      '--app-visible-top',
      '--app-visible-width',
      '--app-visible-left',
    ];
    const previous = keys.map((key) => [key, style.getPropertyValue(key)]);
    const viewport = window.visualViewport;
    let frame = 0;
    const update = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        style.setProperty(
          keys[0],
          `${viewport?.height ?? window.innerHeight}px`,
        );
        style.setProperty(keys[1], `${viewport?.offsetTop ?? 0}px`);
        style.setProperty(keys[2], `${viewport?.width ?? window.innerWidth}px`);
        style.setProperty(keys[3], `${viewport?.offsetLeft ?? 0}px`);
        // A keyboard can shrink the form after focus was placed. Reveal only
        // that field inside its own scroller; never move the modal or page.
        const focused = document.activeElement;
        if (
          focused instanceof HTMLElement &&
          focused.matches(
            'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]), textarea, select',
          )
        ) {
          const scroll = focused.closest<HTMLElement>(
            '.vehicle-form-fields, .checkout-scroll, .settings-scroll',
          );
          if (scroll) {
            const field = focused.getBoundingClientRect();
            const frame = scroll.getBoundingClientRect();
            if (field.bottom > frame.bottom - 8)
              scroll.scrollTop += field.bottom - frame.bottom + 8;
            else if (field.top < frame.top + 8)
              scroll.scrollTop -= frame.top + 8 - field.top;
          }
        }
      });
    };
    update();
    viewport?.addEventListener('resize', update);
    viewport?.addEventListener('scroll', update);
    window.addEventListener('resize', update);
    return () => {
      cancelAnimationFrame(frame);
      viewport?.removeEventListener('resize', update);
      viewport?.removeEventListener('scroll', update);
      window.removeEventListener('resize', update);
      previous.forEach(([key, value]) =>
        value ? style.setProperty(key, value) : style.removeProperty(key),
      );
    };
  }, [enabled]);
}
