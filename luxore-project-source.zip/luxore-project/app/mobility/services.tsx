import Image from 'next/image';
import {
  ArrowUpRight,
  Plane,
  BriefcaseBusiness,
  Route,
  Clock3,
  ShieldCheck,
  Mail,
} from 'lucide-react';
import { classes, money } from '@/lib/ride-domain';
import AppSupport from './app-support';
export default function Services({ compact = false }: { compact?: boolean }) {
  if (compact) return <AppSupport />;
  return (
    <>
      <div className="page-intro">
        <div>
          <div className="eyebrow">MEHR ALS EINE FAHRT</div>
          <h1>
            Auf deinen <span>Anspruch abgestimmt.</span>
          </h1>
        </div>
        <a
          className="contact-link"
          href="https://luxoreride.de"
          target="_blank"
          rel="noreferrer"
        >
          Unsere Website <ArrowUpRight size={18} />
        </a>
      </div>
      <div className="service-banner">
        <Image
          unoptimized
          src="/brand/frankfurt.png"
          alt="Frankfurter Skyline aus dem Fenster einer Limousine"
          width="1024"
          height="1024"
        />
        <div>
          <span className="eyebrow">FRANKFURT. UND DARÜBER HINAUS.</span>
          <h2>Eleganz in Bewegung.</h2>
          <p>
            Für deinen nächsten Flug, deinen Geschäftstermin oder einen
            besonderen Tag.
          </p>
        </div>
      </div>
      <div className="service-grid">
        {[
          {
            icon: Plane,
            title: 'Flughafentransfer',
            text: 'Persönliche Abholung und Gepäckservice für deinen Transfer rund um Frankfurt Airport.',
          },
          {
            icon: BriefcaseBusiness,
            title: 'Business & Corporate',
            text: 'Diskrete Fahrten für Geschäftstermine, Hotels, Unternehmen und ihre Gäste.',
          },
          {
            icon: Route,
            title: 'Langstrecken',
            text: 'Privat und komfortabel unterwegs – auch über Frankfurt hinaus und europaweit.',
          },
          {
            icon: Clock3,
            title: 'Daytrips',
            text: 'Dein Chauffeur für Shopping, Ausflüge und individuell geplante Tagesfahrten.',
          },
        ].map((x) => (
          <article key={x.title}>
            <x.icon size={23} />
            <h3>{x.title}</h3>
            <p>{x.text}</p>
          </article>
        ))}
      </div>
      <div className="women-service">
        <ShieldCheck size={28} />
        <div>
          <span className="eyebrow">PERSÖNLICHES VERTRAUEN</span>
          <h2>Women to Women</h2>
          <p>
            Eine Chauffeurin für deine Fahrt. Auf Anfrage und nach bestätigter
            Verfügbarkeit.
          </p>
        </div>
        <a href="mailto:booking@luxoreride.de?subject=Women%20to%20Women%20Anfrage">
          Per E-Mail anfragen <ArrowUpRight size={18} />
        </a>
      </div>
      <section className="pricing-section">
        <div className="section-title">
          <div>
            <div className="eyebrow">TRANSPARENT UNTERWEGS</div>
            <h2>Unsere Tarifübersicht</h2>
          </div>
          <a
            href="https://luxoreride.de/#preise"
            target="_blank"
            rel="noreferrer"
          >
            Quelle: luxoreride.de <ArrowUpRight size={16} />
          </a>
        </div>
        <div className="price-grid">
          {classes.map((c) => (
            <article key={c.id}>
              <h3>{c.name}</h3>
              <p>{c.detail}</p>
              <div>
                <strong>{money(c.perKm)}</strong>
                <span>pro Kilometer</span>
              </div>
              <footer>15,00 € Mindestpreis</footer>
            </article>
          ))}
        </div>
        <p className="fineprint">
          Preis = tatsächlich berechnete Straßenroute × Kilometerpreis.
          Mindestpreis 15 €. Keine zusätzliche Transferpauschale. Reservierungen
          und Sofortfahrten verwenden dieselben Kilometerpreise. Die
          Straßenroute wird vor der Anfrage berechnet.
        </p>
      </section>
      <div className="terms-grid">
        <article>
          <Clock3 />
          <h3>Wartezeit inklusive</h3>
          <p>
            60 Minuten nach Landung bei Linienflügen. 15 Minuten bei anderen
            Abholorten. Danach laut Website 40 € je angefangene halbe Stunde.
          </p>
        </article>
        <article>
          <ShieldCheck />
          <h3>Flexibel planen</h3>
          <p>
            Laut Website bis 24 Stunden vor Fahrtantritt kostenfrei stornieren.
            Danach wird der vereinbarte Fahrpreis berechnet. Für Testfahrten
            fallen keine Kosten an.
          </p>
        </article>
        <article>
          <Mail />
          <h3>Direkt in Kontakt</h3>
          <p>
            <a href="mailto:booking@luxoreride.de">booking@luxoreride.de</a>
            <br />
            <a href="tel:+491605083829">+49 160 5083829</a>
            <br />
            Erreichbarkeit laut Website: 24/7
          </p>
        </article>
      </div>
    </>
  );
}
