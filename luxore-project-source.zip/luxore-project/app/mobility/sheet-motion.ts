export type SheetStop = 'peek' | 'half' | 'full';
export function sheetHeights(available: number) {
  const full = Math.max(96, available - 12);
  return {
    peek: Math.min(80, full),
    half: Math.min(full, Math.max(200, available * 0.62)),
    full,
  };
}
export function settleSheet(
  height: number,
  velocity: number,
  heights: Record<SheetStop, number>,
): SheetStop {
  const entries = (['peek', 'half', 'full'] as const).map((key) => ({
    key,
    height: heights[key],
  }));
// Velocity is positive upwards. A quick flick advances one stop, not three.
  if (Math.abs(velocity) > 0.2) {
    const next =
      velocity > 0
        ? entries.find((entry) => entry.height > height + 12)
        : [...entries].reverse().find((entry) => entry.height < height - 12);
    return next?.key ?? (velocity > 0 ? 'full' : 'peek');
  }
  const halfH = heights.half;
  const peekH = heights.peek;
  const fullH = heights.full;
  if (height < peekH + (halfH - peekH) * 0.45) return 'peek';
  if (height > halfH + (fullH - halfH) * 0.55) return 'full';
  return 'half';
}
