'use client';
import { useMemo, useState } from 'react';
import type { RouteData } from '@/lib/mobility/domain';
import type { GpsFix } from './gps-quality';
import {
  advanceNavigation,
  compileNavigation,
  navigationFixUsable,
  type NavigationProgress,
  type NavigationTrack,
} from './navigation-progress';
type ProgressState = {
  track: NavigationTrack | null;
  fix: GpsFix | null;
  progress: NavigationProgress | null;
  last: NavigationProgress | null;
};
export function useNavigationProgress(
  route: RouteData | null,
  fix: GpsFix | null,
  now: number,
) {
  const track = useMemo(() => compileNavigation(route), [route]);
  const [state, setState] = useState<ProgressState>({
    track: null,
    fix: null,
    progress: null,
    last: null,
  });
  let progress = state.progress;
  if (state.track !== track || state.fix !== fix) {
    const previous = state.track === track ? state.last : null;
    progress =
      track && fix ? advanceNavigation(track, fix, now, previous) : null;
    // Synchronously derive state before commit; no second effect-driven paint of an old turn.
    // Keep the last trustworthy anchor across a single ambiguous GPS sample.
    setState({ track, fix, progress, last: progress || previous });
  }
  return navigationFixUsable(fix, now) ? progress : null;
}
