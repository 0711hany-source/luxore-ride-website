'use client';
import {
  useRef,
  useState,
  useId,
  type ReactNode,
  type CSSProperties,
} from 'react';
import { ChevronDown, ChevronUp, ArrowLeft, ArrowRight } from 'lucide-react';
import {
  gestureAxis,
  gestureControls,
  swipeDirection,
  type Axis,
} from './gesture-policy';
import { useSheetMotion } from './use-sheet-motion';
export function SwipePages({
  children,
  onSwipe,
  disabled = false,
  canPrevious = true,
  canNext = true,
  className = '',
}: {
  children: ReactNode;
  onSwipe: (direction: 1 | -1) => void;
  disabled?: boolean;
  canPrevious?: boolean;
  canNext?: boolean;
  className?: string;
}) {
  const start = useRef<{
    id: number;
    x: number;
    y: number;
    at: number;
    axis: Axis;
  } | null>(null);
  const [offset, setOffset] = useState(0);
  const reset = () => {
    start.current = null;
    setOffset(0);
  };
  return (
    <div
      className={'swipe-pages ' + className}
      data-swipe-root=""
      data-swiping={offset !== 0 || undefined}
      style={{ '--page-swipe': `${offset * 0.16}px` } as CSSProperties}
      onTouchStart={(e) => {
        reset();
        const target = e.target as HTMLElement;
        if (
          disabled ||
          e.touches.length !== 1 ||
          !e.currentTarget.contains(target) ||
          target.closest('[data-swipe-root]') !== e.currentTarget ||
          target.closest(gestureControls)
        )
          return;
        // Leave the OS/browser screen-edge gesture to its native Back handler.
        const t = e.touches[0];
        if (t.clientX < 24 || t.clientX > window.innerWidth - 24) return;
        start.current = {
          id: t.identifier,
          x: t.clientX,
          y: t.clientY,
          at: e.timeStamp,
          axis: 'pending',
        };
      }}
      onTouchMove={(e) => {
        const g = start.current;
        if (!g) return;
        if (disabled || e.touches.length !== 1) {
          reset();
          return;
        }
        const t = e.touches[0];
        if (t.identifier !== g.id) {
          reset();
          return;
        }
        const dx = t.clientX - g.x,
          dy = t.clientY - g.y;
        g.axis = gestureAxis(dx, dy, g.axis);
        if (g.axis === 'vertical') {
          reset();
          return;
        }
        if (g.axis === 'horizontal')
          setOffset(
            (dx > 0 ? canPrevious : canNext)
              ? Math.max(-110, Math.min(110, dx))
              : 0,
          );
      }}
      onTouchEnd={(e) => {
        const g = start.current;
        if (!g) return;
        const t = Array.from(e.changedTouches).find(
          (t) => t.identifier === g.id,
        );
        reset();
        if (disabled || !t || e.touches.length) return;
        const direction = swipeDirection(
          t.clientX - g.x,
          t.clientY - g.y,
          e.timeStamp - g.at,
          g.axis,
        );
        if (direction && (direction === 1 ? canNext : canPrevious)) {
          e.stopPropagation();
          onSwipe(direction);
        }
      }}
      onTouchCancel={reset}
    >
      {offset !== 0 && (
        <span
          className={'page-swipe-cue ' + (offset > 0 ? 'previous' : 'next')}
          aria-hidden="true"
        >
          {offset > 0 ? <ArrowLeft size={20} /> : <ArrowRight size={20} />}
        </span>
      )}
      {children}
    </div>
  );
}
export function RidePanel({
  children,
  className,
  title = 'Fahrtdetails',
  subtitle = 'Nach oben ziehen für mehr Details',
  staticPanel = false,
}: {
  children: ReactNode;
  className: string;
  title?: string;
  subtitle?: string;
  staticPanel?: boolean;
}) {
  if (staticPanel) return <section className={className}>{children}</section>;
  return (
    <SnapRidePanel className={className} title={title} subtitle={subtitle}>
      {children}
    </SnapRidePanel>
  );
}
function SnapRidePanel({
  children,
  className,
  title,
  subtitle,
}: {
  children: ReactNode;
  className: string;
  title: string;
  subtitle: string;
}) {
  const root = useRef<HTMLElement>(null);
  const motion = useSheetMotion(root);
  const id = useId();
  return (
    <section
      ref={root}
      className={className + ' ride-sheet shared-snap-sheet'}
      data-stop={motion.stop}
      data-dragging={motion.dragging || undefined}
      style={{ '--sheet-height': `${motion.height}px` } as CSSProperties}
    >
      <button
        type="button"
        className="ride-panel-grip"
        {...motion.handlers}
        aria-controls={id}
        aria-expanded={motion.stop !== 'peek'}
        aria-label={
          motion.stop === 'peek'
            ? 'Fahrtfläche öffnen'
            : 'Fahrtfläche verkleinern'
        }
      >
        <i aria-hidden="true" />
        <span>
          <strong>{title}</strong>
          <small>
            {motion.stop === 'peek' ? 'Nach oben ziehen' : subtitle}
          </small>
        </span>
        {motion.stop === 'peek' ? (
          <ChevronUp size={19} />
        ) : (
          <ChevronDown size={19} />
        )}
      </button>
      <div
        id={id}
        className="ride-panel-body"
        inert={motion.stop === 'peek' && !motion.dragging}
      >
        {children}
      </div>
    </section>
  );
}
