'use client';
import { useState, type CSSProperties } from 'react';
import { useBackLayer } from './use-back-layer';
import { useDismissGesture } from './use-dismiss-gesture';
import { ShieldCheck, Phone, Share2, X } from 'lucide-react';
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogClose,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import type { Booking } from '@/lib/mobility/domain';
export default function Safety({ booking }: { booking: Booking }) {
  const [message, setMessage] = useState('');
  const [open, setOpen] = useState(false);
  useBackLayer(open, () => setOpen(false), 90);
  const drag = useDismissGesture(() => setOpen(false));
  async function share() {
    const text = `LUXORÉ RIDE · Fahrt ${booking.id}\nAbholung: ${booking.route.pickup.label}\nZiel: ${booking.route.destination.label}\nFahrer: ${booking.driver?.name || 'Noch nicht zugewiesen'}\nKennzeichen: ${booking.driver?.plate || 'Noch nicht zugewiesen'}`;
    try {
      if (navigator.share)
        await navigator.share({ title: 'Meine Fahrtdaten', text });
      else {
        await navigator.clipboard.writeText(text);
        setMessage(
          'Fahrtdaten kopiert. Du kannst sie an eine Vertrauensperson senden.',
        );
      }
    } catch (e) {
      if ((e as Error).name !== 'AbortError')
        setMessage('Teilen ist in diesem Browser nicht verfügbar.');
    }
  }
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger render={<Button variant="outline" />}>
        <ShieldCheck />
        Sicherheit
      </DialogTrigger>
      <DialogContent
        showCloseButton={false}
        className="safety-dialog app-detail-sheet"
        style={
          { '--dismiss-y': `${open ? drag.offset : 0}px` } as CSSProperties
        }
      >
        <div
          className="sheet-dismiss-handle"
          {...drag.handlers}
          aria-hidden="true"
        >
          <i />
        </div>
        <DialogClose
          render={<Button variant="ghost" className="absolute top-2 right-2" />}
          aria-label="Sicherheit schließen"
        >
          <X size={20} />
        </DialogClose>
        <DialogTitle>Deine Sicherheit</DialogTitle>
        <DialogDescription>
          Fahrtdaten, persönlicher Kontakt und Hilfe während deiner Fahrt.
        </DialogDescription>
        <a className="emergency-call" href="tel:112">
          <Phone />
          Notruf 112 wählen
        </a>
        <p>
          Bei unmittelbarer Gefahr. Der Anruf öffnet die Telefonfunktion deines
          Geräts; die App übermittelt dabei keinen Standort automatisch.
        </p>
        <div className="safety-location">
          <strong>Abholadresse</strong>
          <p>{booking.route.pickup.label}</p>
          <span>
            {booking.route.pickup.lat.toFixed(5)},{' '}
            {booking.route.pickup.lng.toFixed(5)}
          </span>
        </div>
        <a className="support-call" href="tel:+491605083829">
          <Phone size={17} />
          LUXORÉ RIDE kontaktieren
        </a>
        <Button variant="outline" onClick={share}>
          <Share2 />
          Fahrtdaten teilen
        </Button>
        <p>
          Geteilt werden Textdaten, kein öffentlich zugänglicher Live-Standort.
        </p>
        {message && <output>{message}</output>}
      </DialogContent>
    </Dialog>
  );
}
