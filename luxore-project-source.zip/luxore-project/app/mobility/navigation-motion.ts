import { distanceMeters, type GpsFix } from './gps-quality.ts';
import { bearingBetween } from './map-camera.ts';
import { reliableCourse } from '../../lib/mobility/gps-telemetry.ts';
export type Position = { lat: number; lng: number };
export type Pose = Position & { bearing: number };
export type RoadLine = number[][];
type Projection = Position & {
  distance: number;
  along: number;
  segment: number;
};
export function projectRoad(
  point: Position,
  line: RoadLine,
): Projection | null {
  let best: Projection | null = null,
    along = 0;
  const scale = Math.cos((point.lat * Math.PI) / 180);
  for (let i = 1; i < line.length; i++) {
    const a = { lng: line[i - 1][0], lat: line[i - 1][1] },
      b = { lng: line[i][0], lat: line[i][1] };
    const dx = (b.lng - a.lng) * scale,
      dy = b.lat - a.lat,
      denom = dx * dx + dy * dy;
    const t = denom
      ? Math.max(
          0,
          Math.min(
            1,
            ((point.lng - a.lng) * scale * dx + (point.lat - a.lat) * dy) /
              denom,
          ),
        )
      : 0;
    const p = {
      lng: a.lng + (b.lng - a.lng) * t,
      lat: a.lat + (b.lat - a.lat) * t,
    };
    const length = distanceMeters(a, b),
      distance = distanceMeters(point, p);
    if (!best || distance < best.distance)
      best = { ...p, distance, along: along + length * t, segment: i - 1 };
    along += length;
  }
  return best;
}
export function roadPath(
  from: Position,
  to: Position,
  line: RoadLine,
  accuracy: number,
): Position[] | null {
  const a = projectRoad(from, line),
    b = projectRoad(to, line);
  const tolerance = Math.max(8, Math.min(25, accuracy));
  if (!a || !b || a.distance > tolerance || b.distance > tolerance) return null;
  const direct = distanceMeters(from, to),
    traveled = b.along - a.along;
  // Do not pull an off-route fix backwards or take a long loop at an intersection.
  if (traveled < -3 || traveled > direct * 2.8 + 35) return null;
  // Clamping beyond the end would falsely pin the vehicle to the destination.
  if (
    (b.along < 1 ||
      (b.segment === line.length - 2 &&
        distanceMeters(b, { lng: line.at(-1)![0], lat: line.at(-1)![1] }) <
          1)) &&
    b.distance > 6
  )
    return null;
  return [
    from,
    { lat: a.lat, lng: a.lng },
    ...line
      .slice(a.segment + 1, b.segment + 1)
      .map(([lng, lat]) => ({ lng, lat })),
    { lng: b.lng, lat: b.lat },
  ];
}
export function pathPose(
  path: Position[],
  progress: number,
  previousBearing: number,
): Pose {
  const lengths = path
    .slice(1)
    .map((point, i) => distanceMeters(path[i], point));
  const total = lengths.reduce((a, b) => a + b, 0);
  if (total < 0.1) return { ...path.at(-1)!, bearing: previousBearing };
  let remaining = total * Math.max(0, Math.min(1, progress));
  for (let i = 0; i < lengths.length; i++) {
    if (remaining <= lengths[i] || i === lengths.length - 1) {
      const t = lengths[i] ? Math.min(1, remaining / lengths[i]) : 1;
      return {
        lat: path[i].lat + (path[i + 1].lat - path[i].lat) * t,
        lng: path[i].lng + (path[i + 1].lng - path[i].lng) * t,
        bearing:
          lengths[i] > 1
            ? bearingBetween(path[i], path[i + 1])
            : previousBearing,
      };
    }
    remaining -= lengths[i];
  }
  return { ...path.at(-1)!, bearing: previousBearing };
}
export function turnTowards(from: number, to: number, fraction: number) {
  return (
    (from +
      (((to - from + 540) % 360) - 180) * Math.max(0, Math.min(1, fraction)) +
      360) %
    360
  );
}
export class NavigationMotion {
  private readonly lowLatency: boolean;
  constructor(lowLatency = false) {
    this.lowLatency = lowLatency;
  }
  private headingAnchor: Position | null = null;
  private targetBearing = 0;
  private fix: GpsFix | null = null;
  private pose: Pose | null = null;
  private movementAnchor: Position | null = null;
  private path: Position[] = [];
  private start = 0;
  private duration = 0;
  private renderedAt = 0;
  private lastInterval = 1000;
  private prediction: {
    path: Position[];
    speed: number;
    until: number;
  } | null = null;
  reset() {
    this.fix = null;
    this.pose = null;
    this.movementAnchor = null;
    this.headingAnchor = null;
    this.targetBearing = 0;
    this.path = [];
    this.duration = 0;
    this.prediction = null;
  }
  get timestamp() {
    return this.fix?.timestamp ?? 0;
  }
  get position() {
    return this.pose;
  }
  push(
    fix: GpsFix,
    now: number,
    line?: RoadLine | null,
    forwardLine?: RoadLine | null,
  ): boolean {
    if (this.fix && fix.timestamp < this.fix.timestamp) return false;
    const previous = this.fix;
    const sameFix = previous?.timestamp === fix.timestamp;
    if (!this.pose || !previous || fix.timestamp - previous.timestamp > 15000) {
      this.pose = {
        lat: fix.lat,
        lng: fix.lng,
        bearing: reliableCourse(fix) ?? this.pose?.bearing ?? 0,
      };
      this.fix = fix;
      this.movementAnchor = fix;
      this.headingAnchor = fix;
      this.targetBearing = this.pose.bearing;
      this.path = [this.pose, this.pose];
      this.start = now;
      this.duration = 0;
      this.renderedAt = now;
      this.prediction = null;
      return true;
    }
    if (
      !sameFix &&
      distanceMeters(previous, fix) >
        (70 * (fix.timestamp - previous.timestamp)) / 1000 +
          previous.accuracy +
          fix.accuracy
    )
      return false;
    const moved = distanceMeters(this.movementAnchor || previous, fix);
    if (!sameFix) {
      this.lastInterval = Math.max(
        650,
        Math.min(6000, fix.timestamp - previous.timestamp),
      );
      this.fix = fix;
    }
    const wasPredicted = this.prediction !== null;
    // Hold parked noise; after road prediction a measured stop corrects the displayed pose.
    if (
      !sameFix &&
      moved < Math.max(2, Math.min(8, fix.accuracy * 0.25)) &&
      !wasPredicted
    )
      return false;
    const remaining = this.start + this.duration - now;
    const from = this.sample(now)!;
    if (!sameFix) this.prediction = null;
    if (this.lowLatency && !sameFix) {
      const course = reliableCourse(fix);
      const anchor = this.headingAnchor || previous;
      // Tiny sideways GPS corrections must not rotate a car driving straight.
      if (course !== null) {
        this.targetBearing = course;
        this.headingAnchor = fix;
      } else if (
        distanceMeters(anchor, fix) >=
        Math.max(6, Math.min(15, fix.accuracy * 0.75))
      ) {
        this.targetBearing = bearingBetween(anchor, fix);
        this.headingAnchor = fix;
      }
    }
    const path = line ? roadPath(from, fix, line, fix.accuracy) : null;
    if (sameFix && !path) return false;
    this.path = path || [from, { lat: fix.lat, lng: fix.lng }];
    if (distanceMeters(from, this.path.at(-1)!) < 0.3) return false;
    this.movementAnchor = fix;
    this.start = now;
    this.duration = this.lowLatency
      ? sameFix
        ? Math.max(120, Math.min(280, remaining))
        : Math.min(280, this.lastInterval * 0.22)
      : sameFix
        ? Math.max(500, remaining)
        : this.lastInterval;
    // Bridge only a short one-second native GPS cadence on a verified future road.
    // The real GPS fix remains unchanged for dispatch, billing and route progress.
    if (
      this.lowLatency &&
      !sameFix &&
      forwardLine &&
      this.lastInterval <= 1500 &&
      fix.accuracy <= 15 &&
      reliableCourse(fix) !== null
    ) {
      const endpoint = this.path.at(-1)!;
      const projection = projectRoad(endpoint, forwardLine);
      if (projection && projection.distance <= 2) {
        const a = forwardLine[projection.segment],
          b = forwardLine[projection.segment + 1];
        const bearing = bearingBetween(
          { lng: a[0], lat: a[1] },
          { lng: b[0], lat: b[1] },
        );
        const delta = Math.abs(
          ((bearing - reliableCourse(fix)! + 540) % 360) - 180,
        );
        if (delta <= 60) {
          const path = [endpoint];
          let length = 0;
          for (let i = projection.segment + 1; i < forwardLine.length; i++) {
            const [lng, lat] = forwardLine[i];
            const p = { lng, lat };
            length += distanceMeters(path.at(-1)!, p);
            path.push(p);
            if (length >= 30) break;
          }
          this.prediction = {
            path,
            speed: Math.min(25, fix.speed!),
            until: now + Math.min(1200, this.lastInterval * 1.1),
          };
        }
      }
    }
    return true;
  }
  sample(now: number): Pose | null {
    if (!this.pose) return null;
    const progress = this.duration
      ? Math.min(1, (now - this.start) / this.duration)
      : 1;
    let next = pathPose(this.path, progress, this.pose.bearing);
    const prediction = this.prediction;
    if (prediction && now > this.start + this.duration) {
      const traveled =
        (prediction.speed *
          Math.max(
            0,
            Math.min(now, prediction.until) - this.start - this.duration,
          )) /
        1000;
      const length = prediction.path
        .slice(1)
        .reduce(
          (total, p, i) => total + distanceMeters(prediction.path[i], p),
          0,
        );
      if (length > 0)
        next = pathPose(
          prediction.path,
          Math.min(1, traveled / length),
          this.pose.bearing,
        );
    }
    const dt = Math.max(0, Math.min(100, now - this.renderedAt));
    this.renderedAt = now;
    this.pose = {
      lat: next.lat,
      lng: next.lng,
      bearing: turnTowards(
        this.pose.bearing,
        this.lowLatency && !(prediction && progress === 1)
          ? this.targetBearing
          : next.bearing,
        1 - Math.exp(-dt / (this.lowLatency ? 120 : 220)),
      ),
    };
    return this.pose;
  }
  active(now: number) {
    return (
      !!this.pose &&
      now <
        Math.max(this.start + this.duration, this.prediction?.until || 0) + 900
    );
  }
}
