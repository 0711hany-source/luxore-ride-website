'use client';
import AddressAttribution from './address-attribution';
import Image from 'next/image';
import {
  ArrowUpRight,
  CalendarDays,
  Clock3,
  MapPin,
  Search,
} from 'lucide-react';
import AppHeader from './app-header';
import type { Booking } from '@/lib/mobility/domain';
export default function CustomerHome({
  bookings,
  onStart,
  onRecent,
  onMenu,
  showHeader = true,
}: {
  bookings: Booking[];
  onStart: (mode: 'now' | 'reservation') => void;
  onRecent: (b: Booking) => void;
  onMenu: () => void;
  showHeader?: boolean;
}) {
  const recent = bookings
    .filter(
      (b, i, all) =>
        all.findIndex(
          (x) => x.route.destination.label === b.route.destination.label,
        ) === i,
    )
    .slice(0, 3);
  return (
    <div className="ride-home">
      {showHeader && <AppHeader onMenu={onMenu} />}
      <div className="home-location">
        <MapPin size={14} />
        Frankfurt am Main
      </div>
      <h1>Wohin geht’s?</h1>
      <button className="destination-launch" onClick={() => onStart('now')}>
        <Search size={24} />
        <span>Ziel eingeben</span>
        <ArrowUpRight size={23} />
      </button>
      <div className="home-ride-options">
        <button onClick={() => onStart('now')}>
          <span className="home-option-kicker">JETZT</span>
          <Image
            src="/brand/business.png"
            alt=""
            width={220}
            height={140}
            unoptimized
          />
          <strong>Fahrt buchen</strong>
          <span>Los, wenn du bereit bist.</span>
          <ArrowUpRight className="option-arrow" size={19} />
        </button>
        <button onClick={() => onStart('reservation')}>
          <span className="home-option-kicker">
            <CalendarDays size={13} />
            SPÄTER
          </span>
          <Image
            src="/brand/first-class.png"
            alt=""
            width={220}
            height={140}
            unoptimized
          />
          <strong>Fahrt planen</strong>
          <span>Deine Abholzeit wählen.</span>
          <ArrowUpRight className="option-arrow" size={19} />
        </button>
      </div>
      {recent.length > 0 ? (
        <section className="home-recents">
          <h2>Letzte Ziele</h2>
          {recent.map((b) => (
            <button key={b.id} onClick={() => onRecent(b)}>
              <span className="recent-icon">
                <Clock3 size={20} />
              </span>
              <span>
                <strong>{b.route.destination.label.split(',')[0]}</strong>
                <small>
                  {b.route.destination.label.split(',').slice(1).join(',') ||
                    'Erneut als Ziel verwenden'}
                </small>
              </span>
              <ArrowUpRight size={18} />
            </button>
          ))}
          <AddressAttribution points={recent.map((b) => b.route.destination)} />
        </section>
      ) : (
        <div className="home-first-ride">
          <span className="recent-icon">
            <MapPin size={20} />
          </span>
          <p>
            <strong>Überall einsteigen.</strong>
            <span>Wähle deine Adresse oder deinen Standort.</span>
          </p>
        </div>
      )}
      <div className="home-service-line">
        <span>Business</span>
        <i />
        <span>First Class</span>
        <i />
        <span>Van</span>
      </div>
    </div>
  );
}
