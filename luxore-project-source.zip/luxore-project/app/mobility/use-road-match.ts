'use client';
import { useEffect, useRef, useState } from 'react';
import { api } from './api';
import { distanceMeters, usableFix, type GpsFix } from './gps-quality';
import type { RoadMatch } from '@/lib/mobility/road-matching';
import { roadMatchForFix } from './road-match-policy';
import { useClock } from './use-clock';

export function useRoadMatch(
  fix: GpsFix | null,
  enabled: boolean,
  identity: string | undefined,
) {
  const now = useClock();
  const [match, setMatch] = useState<{
    identity: string | undefined;
    value: RoadMatch;
  } | null>(null);
  const history = useRef<GpsFix[]>([]),
    lastRequest = useRef(0),
    latest = useRef(0);
  const controller = useRef<AbortController | null>(null);
  useEffect(() => {
    history.current = [];
    latest.current = 0;
    lastRequest.current = 0;
    return () => {
      controller.current?.abort();
    };
  }, [identity, enabled]);
  const lat = fix?.lat,
    lng = fix?.lng,
    accuracy = fix?.accuracy,
    timestamp = fix?.timestamp;
  useEffect(() => {
    if (
      !enabled ||
      lat == null ||
      lng == null ||
      accuracy == null ||
      timestamp == null ||
      document.visibilityState === 'hidden'
    )
      return;
    const point = { lat, lng, accuracy, timestamp };
    if (
      !usableFix(point, Date.now()) ||
      accuracy > 50 ||
      timestamp <= latest.current
    )
      return;
    latest.current = timestamp;
    let trace = history.current.filter((p) => timestamp - p.timestamp < 60000);
    const last = trace.at(-1);
    if (
      last &&
      (timestamp - last.timestamp < 3000 || distanceMeters(last, point) < 4)
    )
      return;
    if (last && timestamp - last.timestamp > 15000) trace = [];
    trace = [...trace, point].slice(-10);
    history.current = trace;
    if (trace.length < 3 || Date.now() - lastRequest.current < 6000) return;
    controller.current?.abort();
    const request = new AbortController();
    controller.current = request;
    lastRequest.current = Date.now();
    void api<{ match: RoadMatch | null }>(
      'navigation',
      { points: trace },
      request.signal,
    )
      .then((reply) => {
        // A one-second GPS stream must not discard every slower provider response.
        if (
          !request.signal.aborted &&
          latest.current - timestamp <= 6000 &&
          reply.match?.timestamp === timestamp
        )
          setMatch({ identity, value: reply.match });
      })
      .catch(() => {});
  }, [enabled, identity, lat, lng, accuracy, timestamp]);
  return enabled && match?.identity === identity
    ? roadMatchForFix(match?.value || null, fix, now)
    : null;
}
