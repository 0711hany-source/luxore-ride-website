'use client';
import { useEffect, useRef, useState, type CSSProperties } from 'react';
import type mapboxgl from 'mapbox-gl';
import type { RouteData, Driver } from '@/lib/mobility/domain';
import { MapPin, RefreshCw, LocateFixed, Route, Box } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { mapErrorMessage } from './map-recovery';
import { attachMapAutoReturn } from './map-auto-return';
import { drivingCameraInsets } from './map-camera';
import { NavigationMotion, type Pose } from './navigation-motion';
import { useRoadMatch } from './use-road-match';
import { FollowCamera } from './follow-camera';
import AddressAttribution from './address-attribution';
import { EUROPE_MAP_VIEW } from '@/lib/mobility/map-region';

function startCameraReturn(camera: FollowCamera, map: mapboxgl.Map) {
  map.stop();
  const center = map.getCenter();
  const padding = map.getPadding();
  camera.begin(
    {
      center: [center.lng, center.lat],
      bearing: map.getBearing(),
      zoom: map.getZoom(),
      pitch: map.getPitch(),
      padding: {
        top: padding.top ?? 0,
        bottom: padding.bottom ?? 0,
        left: padding.left ?? 0,
        right: padding.right ?? 0,
      },
    },
    performance.now(),
    window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 850,
  );
}

function createDriverMarkerElement(label: string) {
  const root = document.createElement('div');
  root.className = 'luxore-driver-puck';
  root.setAttribute('aria-label', label);
  root.innerHTML = `
    <div class="puck-ground-halo"></div>
    <svg class="puck-navigation-arrow" width="56" height="64" viewBox="0 0 56 64" fill="none" aria-hidden="true">
      <path d="M28 4L50 53L28 44L6 53L28 4Z" fill="#fff" stroke="#fff" stroke-width="6" stroke-linejoin="round"/>
      <path d="M28 5L49 53L28 43L7 53L28 5Z" fill="#232730" stroke="#232730" stroke-width="2" stroke-linejoin="round"/>
      <path d="M28 8L28 39L11 48L28 8Z" fill="#e8d19b"/>
      <path d="M28 8L45 48L28 39V8Z" fill="#b78c43"/>
      <path d="M28 8L28 39" stroke="#fff4d3" stroke-width="1.5"/>
    </svg>`;
  return root;
}

function createRiderMarkerElement() {
  const root = document.createElement('div');
  root.className = 'luxore-rider-puck';
  root.setAttribute('aria-label', 'Kundenstandort');
  root.innerHTML = `
    <div class="rider-pulse"></div>
    <div class="rider-core">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#d5b77b" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="8" r="4"/>
        <path d="M5 20c0-3.5 3-6 7-6s7 2.5 7 6"/>
      </svg>
    </div>
  `;
  return root;
}

function createWaypointElement(label: string, isEnd = false) {
  const root = document.createElement('div');
  root.className = `luxore-waypoint-puck ${isEnd ? 'is-destination' : 'is-pickup'}`;
  root.setAttribute('aria-label', label);
  root.innerHTML = `<span>${isEnd ? 'B' : 'A'}</span>`;
  return root;
}

export default function RideMap({
  token,
  route,
  driver,
  rider,
  nearby = [],
  theme = 'light',
  self = false,
  bottomInset,
  topInset,
  followRoute = false,
  guidanceTarget,
  roadMatching = true,
}: {
  followRoute?: boolean;
  guidanceTarget?: string;
  roadMatching?: boolean;
  theme?: 'light' | 'dark';
  bottomInset?: number;
  topInset?: number;
  self?: boolean;
  nearby?: { lat: number; lng: number }[];
  token: string | null;
  route: RouteData | null;
  driver?: Driver | null;
  rider?: { lat: number; lng: number } | null;
}) {
  const container = useRef<HTMLDivElement>(null),
    map = useRef<mapboxgl.Map | null>(null),
    driverMarker = useRef<mapboxgl.Marker | null>(null),
    driverMarkerElement = useRef<HTMLDivElement | null>(null),
    riderMarker = useRef<mapboxgl.Marker | null>(null),
    nearbyMarkers = useRef<mapboxgl.Marker[]>([]),
    routeMarkers = useRef<mapboxgl.Marker[]>([]),
    lastRoute = useRef(''),
    currentFollowPaused = useRef(false),
    driverAnimation = useRef<number | null>(null);
  const motion = useRef(new NavigationMotion(self));
  const followCamera = useRef(new FollowCamera());
  const trackedDriver = useRef<string | undefined>(undefined);
  const animateDriver = useRef<() => void>(() => {});
  const cameraFollow = useRef<(pose: Pose, time: number) => void>(() => {});
  const road = useRoadMatch(
    driver?.lat != null && driver.lng != null && driver.location_at != null
      ? {
          lat: driver.lat,
          lng: driver.lng,
          accuracy: driver.accuracy ?? 100,
          timestamp: driver.location_at,
        }
      : null,
    self && roadMatching,
    driver?.id,
  );
  const [viewMode, setViewMode] = useState<'overview' | 'navigation'>(
    self ? 'navigation' : 'overview',
  );
  const [ready, setReady] = useState(false),
    [error, setError] = useState(''),
    [attempt, setAttempt] = useState(0);
  const retries = useRef(0);
  const hasRoute = !!route;
  const riderLat = rider?.lat,
    riderLng = rider?.lng;
  const autoReturn = useRef<ReturnType<typeof attachMapAutoReturn> | null>(
    null,
  );
  const restoreView = useRef<() => void>(() => {});
  useEffect(() => {
    restoreView.current = () => {
      const current = map.current;
      if (!current) return;
      currentFollowPaused.current = false;
      if (
        (viewMode === 'navigation' || (self && !route)) &&
        driver?.lat != null &&
        driver.lng != null
      ) {
        startCameraReturn(followCamera.current, current);
        animateDriver.current();
        return;
      }
      followCamera.current.cancel();
      if (route?.geometry.coordinates.length) {
        const coordinates = route.geometry.coordinates;
        const [west, south, east, north] = coordinates.reduce(
          ([w, s, e, n], [lng, lat]) => [
            Math.min(w, lng),
            Math.min(s, lat),
            Math.max(e, lng),
            Math.max(n, lat),
          ],
          [Infinity, Infinity, -Infinity, -Infinity],
        );
        const height = current.getContainer().clientHeight;
        current.fitBounds(
          [
            [west, south],
            [east, north],
          ],
          {
            padding: container.current?.closest('.app-native')
              ? {
                  top: Math.min(topInset ?? 80, height * 0.4),
                  left: 40,
                  right: 40,
                  bottom: Math.max(
                    0,
                    Math.min(
                      bottomInset ?? height * 0.6,
                      height - Math.min(topInset ?? 80, height * 0.4) - 80,
                    ),
                  ),
                }
              : 65,
            maxZoom: 15,
            bearing: 0,
            pitch: 0,
            duration: 600,
          },
        );
      } else {
        const point =
          driver?.lat != null && driver.lng != null ? driver : rider;
        current.easeTo({
          center: point ? [point.lng!, point.lat!] : EUROPE_MAP_VIEW.center,
          zoom: point ? 15 : EUROPE_MAP_VIEW.zoom,
          bearing: 0,
          pitch: 0,
          padding:
            self && bottomInset !== undefined
              ? {
                  top: 100,
                  left: 30,
                  right: 30,
                  bottom: Math.max(
                    0,
                    Math.min(
                      bottomInset,
                      current.getContainer().clientHeight - 160,
                    ),
                  ),
                }
              : 0,
          duration: 600,
        });
      }
    };
  }, [route, driver, rider, self, bottomInset, topInset, viewMode]);
  useEffect(() => {
    if (ready && map.current) {
      if (self)
        map.current.setConfigProperty(
          'basemap',
          'show3dObjects',
          viewMode === 'navigation',
        );
      currentFollowPaused.current = false;
      restoreView.current();
    }
  }, [viewMode, ready, self]);
  useEffect(() => {
    if (!ready || (bottomInset === undefined && topInset === undefined)) return;
    const timer = setTimeout(() => {
      if (!currentFollowPaused.current) restoreView.current();
    }, 250);
    return () => clearTimeout(timer);
  }, [ready, bottomInset, topInset]);
  function retry() {
    retries.current = 0;
    setAttempt((v) => v + 1);
  }
  useEffect(() => {
    if (!token || !container.current) return;
    const motionController = motion.current;
    const cameraController = followCamera.current;
    setReady(false);
    setError('');
    let disposed = false,
      loaded = false;
    let retryTimer: ReturnType<typeof setTimeout> | undefined;
    let observer: ResizeObserver | undefined;
    function failed(error: unknown) {
      if (disposed) return;
      const issue = mapErrorMessage(error);
      setError(issue.message);
      if (issue.retry && !loaded && retries.current < 2 && !retryTimer) {
        retries.current++;
        retryTimer = setTimeout(() => {
          if (!disposed) setAttempt((v) => v + 1);
        }, retries.current * 2500);
      }
    }
    const timeout = setTimeout(() => {
      if (!loaded) failed(undefined);
    }, 18000);
    function online() {
      if (!disposed) {
        retries.current = 0;
        setAttempt((v) => v + 1);
      }
    }
    window.addEventListener('online', online);
    let instance: mapboxgl.Map | undefined;
    void import('mapbox-gl')
      .then(({ default: m }) => {
        if (disposed || !container.current) return;
        instance = new m.Map({
          container: container.current,
          accessToken: token,
          attributionControl: false,
          style: self
            ? 'mapbox://styles/mapbox/standard'
            : theme === 'dark'
              ? 'mapbox://styles/mapbox/dark-v11'
              : 'mapbox://styles/mapbox/streets-v12',
          center: EUROPE_MAP_VIEW.center,
          zoom: EUROPE_MAP_VIEW.zoom,
          maxPitch: 65,
          projection: 'mercator',
          config: self
            ? {
                basemap: {
                  lightPreset: theme === 'dark' ? 'night' : 'day',
                  show3dObjects: true,
                  show3dBuildings: true,
                  show3dTrees: false,
                  show3dFacades: false,
                  show3dLandmarks: false,
                  showPointOfInterestLabels: false,
                  showTransitLabels: false,
                  showRoadLabels: true,
                },
              }
            : undefined,
        });
        map.current = instance;
        currentFollowPaused.current = false;
        autoReturn.current = attachMapAutoReturn(
          instance,
          () => restoreView.current(),
          () => {
            currentFollowPaused.current = true;
            cameraController.cancel();
          },
        );
        instance.addControl(
          new m.NavigationControl({ visualizePitch: true, showZoom: !self }),
          'top-right',
        );
        instance.addControl(
          new m.AttributionControl({ compact: true }),
          'bottom-right',
        );
        instance.on('load', () => {
          if (disposed) return;
          loaded = true;
          clearTimeout(timeout);
          clearTimeout(retryTimer);
          retryTimer = undefined;
          setReady(true);
          setError('');
          retries.current = 0;
        });
        instance.on('idle', () => {
          if (!disposed && loaded) setError('');
        });
        instance.on('error', (e) => failed(e.error));
        instance.on('webglcontextlost', () => {
          loaded = false;
          setReady(false);
          failed(undefined);
        });
        instance.on('webglcontextrestored', () => {
          if (!disposed) {
            loaded = true;
            clearTimeout(retryTimer);
            retryTimer = undefined;
            setReady(true);
            setError('');
          }
        });
        observer = new ResizeObserver(() => instance?.resize());
        observer.observe(container.current);
      })
      .catch((e) => failed(e));
    return () => {
      disposed = true;
      clearTimeout(timeout);
      clearTimeout(retryTimer);
      observer?.disconnect();
      window.removeEventListener('online', online);
      autoReturn.current?.dispose();
      autoReturn.current = null;
      if (driverAnimation.current !== null)
        cancelAnimationFrame(driverAnimation.current);
      instance?.remove();
      map.current = null;
      driverMarker.current = null;
      driverMarkerElement.current = null;
      riderMarker.current = null;
      routeMarkers.current = [];
      nearbyMarkers.current = [];
      lastRoute.current = '';
      motionController.reset();
      cameraController.cancel();
      animateDriver.current = () => {};
    };
  }, [token, theme, self, attempt]);
  useEffect(() => {
    if (!ready || !map.current) return;
    const current = map.current;
    if (!route) {
      if (current.getLayer('journey-line')) current.removeLayer('journey-line');
      if (current.getLayer('journey-line-casing'))
        current.removeLayer('journey-line-casing');
      if (current.getSource('journey')) current.removeSource('journey');
      routeMarkers.current.forEach((m) => m.remove());
      routeMarkers.current = [];
      lastRoute.current = '';
      return;
    }
    const key = route.pickup.id + route.destination.id + route.calculatedAt;
    if (lastRoute.current === key) return;
    let cancelled = false;
    void import('mapbox-gl').then(({ default: m }) => {
      if (cancelled || map.current !== current) return;
      lastRoute.current = key;
      const data = {
        type: 'Feature' as const,
        properties: {},
        geometry: route.geometry,
      };
      const source = current.getSource('journey') as
        | mapboxgl.GeoJSONSource
        | undefined;
      if (source) source.setData(data);
      else {
        current.addSource('journey', { type: 'geojson', data });
        current.addLayer({
          id: 'journey-line-casing',
          type: 'line',
          source: 'journey',
          ...(self ? { slot: 'middle' } : {}),
          layout: { 'line-cap': 'round', 'line-join': 'round' },
          paint: {
            'line-color': '#0d1015',
            'line-width': ['interpolate', ['linear'], ['zoom'], 12, 8, 18, 14],
            'line-opacity': 0.85,
          },
        });
        current.addLayer({
          id: 'journey-line',
          type: 'line',
          source: 'journey',
          ...(self ? { slot: 'middle' } : {}),
          layout: { 'line-cap': 'round', 'line-join': 'round' },
          paint: {
            'line-color': '#cbb27a',
            'line-width': ['interpolate', ['linear'], ['zoom'], 12, 4, 18, 8],
            'line-opacity': 0.95,
          },
        });
      }
      routeMarkers.current.forEach((x) => x.remove());
      routeMarkers.current = [
        ...(!guidanceTarget
          ? [
              new m.Marker({
                element: createWaypointElement('Abholung', false),
              })
                .setLngLat([route.pickup.lng, route.pickup.lat])
                .setPopup(
                  new m.Popup().setText('Abholung: ' + route.pickup.label),
                )
                .addTo(current),
            ]
          : []),
        new m.Marker({
          element: createWaypointElement(guidanceTarget || 'Ziel', true),
        })
          .setLngLat([route.destination.lng, route.destination.lat])
          .setPopup(
            new m.Popup().setText(
              (guidanceTarget || 'Ziel') + ': ' + route.destination.label,
            ),
          )
          .addTo(current),
      ];
      if (!currentFollowPaused.current) restoreView.current();
    });
    return () => {
      cancelled = true;
    };
  }, [ready, route, self, guidanceTarget]);
  useEffect(() => {
    cameraFollow.current = (pose, time) => {
      const current = map.current;
      if (!current || currentFollowPaused.current) return;
      const height = current.getContainer().clientHeight;
      if (viewMode !== 'navigation' && !(self && !hasRoute)) return;
      const navigation = viewMode === 'navigation';
      const target = {
        center: [pose.lng, pose.lat] as [number, number],
        bearing: navigation ? pose.bearing : 0,
        zoom: navigation ? 17 : 15,
        pitch: navigation ? 58 : 0,
        padding: navigation
          ? drivingCameraInsets(height, bottomInset, topInset).padding
          : {
              top: Math.min(100, height * 0.3),
              left: 30,
              right: 30,
              bottom: Math.max(0, Math.min(bottomInset ?? 0, height * 0.6)),
            },
      };
      current.jumpTo(followCamera.current.sample(target, time));
    };
  }, [viewMode, self, hasRoute, bottomInset, topInset]);
  useEffect(() => {
    if (!ready || !map.current) return;
    let cancelled = false;
    const current = map.current;
    void import('mapbox-gl').then(({ default: m }) => {
      if (cancelled || map.current !== current) return;
      if (driver?.lat != null && driver.lng != null) {
        if (trackedDriver.current !== driver.id) {
          if (driverAnimation.current !== null)
            cancelAnimationFrame(driverAnimation.current);
          driverAnimation.current = null;
          motion.current.reset();
          followCamera.current.cancel();
          trackedDriver.current = driver.id;
        }
        if (!driverMarker.current) {
          const el = createDriverMarkerElement(
            self ? 'Dein Standort' : 'Dein Fahrer',
          );
          driverMarkerElement.current = el;
          driverMarker.current = new m.Marker({
            element: el,
            rotationAlignment: 'map',
            pitchAlignment: 'map',
            rotation: 0,
          })
            .setLngLat([driver.lng, driver.lat])
            .setPopup(
              new m.Popup().setText(self ? 'Dein Standort' : 'Dein Fahrer'),
            )
            .addTo(current);
        }
        const marker = driverMarker.current;
        const fix = {
          heading: driver.heading,
          speed: driver.speed,
          lat: driver.lat,
          lng: driver.lng,
          accuracy: driver.accuracy ?? 30,
          timestamp: driver.location_at ?? Date.now(),
        };
        const firstPosition = !motion.current.position;
        const changed = motion.current.push(
          fix,
          performance.now(),
          road?.coordinates ||
            (followRoute ? route?.geometry.coordinates : null),
          followRoute ? route?.geometry.coordinates : null,
        );
        if (
          firstPosition &&
          !currentFollowPaused.current &&
          (viewMode === 'navigation' || (self && !hasRoute))
        )
          startCameraReturn(followCamera.current, current);
        const frame = (time: number) => {
          driverAnimation.current = null;
          if (
            driverMarker.current !== marker ||
            map.current !== current ||
            document.visibilityState === 'hidden'
          )
            return;
          const pose = motion.current.sample(time);
          if (!pose) return;
          marker.setLngLat([pose.lng, pose.lat]);
          marker.setRotation(pose.bearing);
          cameraFollow.current(pose, time);
          if (motion.current.active(time) || followCamera.current.active(time))
            driverAnimation.current = requestAnimationFrame(frame);
        };
        animateDriver.current = () => {
          if (driverAnimation.current !== null)
            cancelAnimationFrame(driverAnimation.current);
          driverAnimation.current = requestAnimationFrame(frame);
        };
        if (changed) animateDriver.current();
      } else {
        if (driverAnimation.current !== null)
          cancelAnimationFrame(driverAnimation.current);
        driverAnimation.current = null;
        driverMarker.current?.remove();
        driverMarker.current = null;
        driverMarkerElement.current = null;
        motion.current.reset();
        followCamera.current.cancel();
        animateDriver.current = () => {};
      }
      if (riderLat != null && riderLng != null) {
        if (!riderMarker.current) {
          const el = createRiderMarkerElement();
          riderMarker.current = new m.Marker({ element: el })
            .setLngLat([riderLng, riderLat])
            .setPopup(new m.Popup().setText('Aktueller Kundenstandort'))
            .addTo(map.current);
        } else {
          riderMarker.current.setLngLat([riderLng, riderLat]);
        }
      } else {
        riderMarker.current?.remove();
        riderMarker.current = null;
      }
    });
    return () => {
      cancelled = true;
    };
  }, [
    ready,
    driver?.lat,
    driver?.lng,
    driver?.accuracy,
    driver?.heading,
    driver?.speed,
    driver?.location_at,
    driver?.id,
    road,
    followRoute,
    route,
    riderLat,
    riderLng,
    self,
    hasRoute,
    viewMode,
  ]);
  useEffect(() => {
    const wake = () => {
      if (document.visibilityState === 'visible') animateDriver.current();
    };
    document.addEventListener('visibilitychange', wake);
    return () => document.removeEventListener('visibilitychange', wake);
  }, []);
  useEffect(() => {
    if (!ready || !map.current) return;
    const current = map.current;
    let cancelled = false;
    void import('mapbox-gl').then(({ default: m }) => {
      if (cancelled || map.current !== current) return;
      nearbyMarkers.current.forEach((marker) => marker.remove());
      nearbyMarkers.current = nearby.map((point) => {
        const element = document.createElement('div');
        element.className = 'nearby-car';
        element.innerHTML = `
          <div class="nearby-car-halo"></div>
          <svg class="nearby-car-svg" width="28" height="28" viewBox="0 0 32 32" fill="none">
            <circle cx="16" cy="16" r="14" fill="#14171d" stroke="#cbb27a" stroke-width="1.8"/>
            <path d="M12 9.5L13.5 13H18.5L20 9.5C18.8 9.2 17.4 9 16 9C14.6 9 13.2 9.2 12 9.5Z" fill="#d5b77b"/>
            <rect x="12" y="13.5" width="8" height="6.5" rx="1.2" fill="#f5eedb"/>
            <rect x="13.2" y="14.5" width="5.6" height="4.5" rx="0.8" fill="#14171d" opacity="0.8"/>
            <path d="M12 20.5L12.5 22.5C13.5 22.8 14.8 23 16 23C17.2 23 18.5 22.8 19.5 22.5L20 20.5H12Z" fill="#cbb27a"/>
            <circle cx="12.5" cy="9.8" r="0.7" fill="#ffffff"/>
            <circle cx="19.5" cy="9.8" r="0.7" fill="#ffffff"/>
          </svg>
        `;
        element.setAttribute(
          'aria-label',
          'Verfügbarer Chauffeur, ungefährer Standort',
        );
        return new m.Marker({ element })
          .setLngLat([point.lng, point.lat])
          .setPopup(
            new m.Popup().setText(
              'Verfügbarer Chauffeur · ungefährer Standort',
            ),
          )
          .addTo(current);
      });
    });
    return () => {
      cancelled = true;
    };
  }, [ready, nearby]);
  return (
    <div
      className="live-map"
      data-theme={theme}
      data-driving={self || undefined}
      style={{ '--map-bottom-inset': `${bottomInset ?? 0}px` } as CSSProperties}
    >
      <div
        ref={container}
        className="map-canvas"
        aria-label="Karte mit Abholung, Ziel und Fahrerposition"
      />
      {ready &&
        (self || route) &&
        driver?.lat != null &&
        driver.lng != null && (
          <button
            type="button"
            className={`map-nav-toggle ${viewMode === 'navigation' ? 'is-nav' : 'is-overview'}`}
            style={
              bottomInset !== undefined
                ? { bottom: bottomInset + 46 }
                : undefined
            }
            aria-label={
              viewMode === 'navigation'
                ? 'Zur 2D-Übersicht wechseln'
                : '3D-Fahransicht mit Fahrtrichtung öffnen'
            }
            onClick={() => {
              currentFollowPaused.current = false;
              setViewMode((v) =>
                v === 'navigation' ? 'overview' : 'navigation',
              );
            }}
          >
            {viewMode === 'navigation' ? (
              <>
                <Route size={16} />
                <span>2D · Übersicht</span>
              </>
            ) : (
              <>
                <Box size={16} />
                <span>3D · Fahransicht</span>
              </>
            )}
          </button>
        )}
      {ready && self && driver?.lat != null && driver.lng != null && (
        <Button
          className="map-recenter"
          style={
            bottomInset !== undefined
              ? { top: 'auto', bottom: bottomInset + 46 }
              : undefined
          }
          size="icon"
          variant="outline"
          aria-label="Karte zur Standardansicht zurücksetzen"
          onClick={() => {
            autoReturn.current?.reset();
          }}
        >
          <LocateFixed size={21} />
        </Button>
      )}
      {(!token || (error && !ready)) && (
        <div className="map-empty">
          <MapPin size={34} />
          <h2>{error ? 'Karte nicht erreichbar' : 'Deine Fahrt im Blick'}</h2>
          <p>
            {error ||
              'Die Kartenanbindung wird eingerichtet. Danach erscheinen hier deine Route und die freigegebene Fahrerposition.'}
          </p>
          {token && (
            <Button onClick={retry}>
              <RefreshCw size={16} />
              Karte neu verbinden
            </Button>
          )}
        </div>
      )}
      {error && ready && (
        <output className="map-connection-note">
          <span>Karte teilweise geladen</span>
          <Button variant="ghost" size="sm" onClick={retry}>
            Neu verbinden
          </Button>
        </output>
      )}
      <div className="map-address-attribution">
        <AddressAttribution points={[route?.pickup, route?.destination]} />
      </div>
    </div>
  );
}
