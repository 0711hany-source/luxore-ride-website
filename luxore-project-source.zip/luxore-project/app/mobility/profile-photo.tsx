'use client';
import { useState } from 'react';
import { uploadPhoto } from './photo';
import { Avatar } from './rating';

/** The driver's profile picture: show, upload, replace. */
export default function ProfilePhoto({
  driverId,
  name,
  photoId,
  onChanged,
}: {
  driverId: string;
  name: string;
  photoId: string | null;
  onChanged?: () => void;
}) {
  const [current, setCurrent] = useState<string | null>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const shown = current || photoId;
  async function choose(file: File | undefined) {
    if (!file) return;
    setBusy(true);
    setError('');
    try {
      setCurrent(await uploadPhoto('driver', driverId, file, 'profile'));
      onChanged?.();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="pf-card">
      <div className="pf-person">
        <Avatar name={name || 'F'} photoId={shown} large />
        <div>
          <strong>Profilbild</strong>
          <span className={'pf-chip ' + (shown ? 'good' : 'danger')}>
            {shown ? 'vorhanden' : 'fehlt'}
          </span>
        </div>
      </div>
      <p className="pf-muted">
        Fahrgäste sehen dein Bild, sobald dir ihre Fahrt oder Reservierung
        zugeteilt ist. Bitte ein aktuelles Foto: Gesicht gut erkennbar, ohne
        Sonnenbrille.
      </p>
      <label className="pf-btn primary wide pf-upload">
        {busy
          ? 'Wird hochgeladen …'
          : shown
            ? 'Profilbild ersetzen'
            : 'Profilbild aufnehmen oder wählen'}
        <input
          type="file"
          accept="image/*"
          disabled={busy}
          aria-label="Profilbild auswählen"
          onChange={(e) => {
            void choose(e.target.files?.[0]);
            e.target.value = '';
          }}
        />
      </label>
      {error && (
        <p className="pf-error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
