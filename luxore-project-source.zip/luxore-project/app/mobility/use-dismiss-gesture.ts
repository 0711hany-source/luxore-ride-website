'use client';
import { useRef, useState, type PointerEvent } from 'react';
import { dismissDistance } from './gesture-policy';
/** Only a dedicated handle owns this drag; form fields and map gestures never dismiss a screen. */
export function useDismissGesture(
  onDismiss: () => void,
  axis: 'down' | 'left' | 'right' = 'down',
  disabled = false,
) {
  const [offset, setOffset] = useState(0);
  const gesture = useRef<{
    id: number;
    x: number;
    y: number;
    at: number;
  } | null>(null);
  const reset = () => {
    gesture.current = null;
    setOffset(0);
  };
  return {
    offset,
    handlers: {
      onPointerDown(e: PointerEvent<HTMLElement>) {
        if (disabled || !e.isPrimary || e.button !== 0 || gesture.current) {
          reset();
          return;
        }
        e.stopPropagation();
        e.currentTarget.setPointerCapture(e.pointerId);
        gesture.current = {
          id: e.pointerId,
          x: e.clientX,
          y: e.clientY,
          at: e.timeStamp,
        };
      },
      onPointerMove(e: PointerEvent<HTMLElement>) {
        const g = gesture.current;
        if (!g || g.id !== e.pointerId) return;
        const main =
          axis === 'down'
            ? e.clientY - g.y
            : (e.clientX - g.x) * (axis === 'left' ? -1 : 1);
        const cross = axis === 'down' ? e.clientX - g.x : e.clientY - g.y;
        if (Math.abs(cross) > Math.abs(main) + 16) {
          reset();
          return;
        }
        setOffset(Math.max(0, Math.min(200, main)));
      },
      onPointerUp(e: PointerEvent<HTMLElement>) {
        const g = gesture.current;
        if (!g || g.id !== e.pointerId) return;
        const main =
          axis === 'down'
            ? e.clientY - g.y
            : (e.clientX - g.x) * (axis === 'left' ? -1 : 1);
        const cross = axis === 'down' ? e.clientX - g.x : e.clientY - g.y;
        const dismiss =
          !disabled &&
          Math.abs(cross) < Math.abs(main) * 0.6 &&
          dismissDistance(main, e.timeStamp - g.at);
        reset();
        if (dismiss) onDismiss();
      },
      onPointerCancel: reset,
      onLostPointerCapture: reset,
    },
  };
}
