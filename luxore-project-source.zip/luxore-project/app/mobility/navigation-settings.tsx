'use client';
import { useEffect, useState, useId, type CSSProperties } from 'react';
import {
  Navigation,
  Check,
  Compass,
  Route,
  Map,
  MapPin,
  X,
  SlidersHorizontal,
  Zap,
} from 'lucide-react';
import { useBackLayer } from './use-back-layer';
import { useDismissGesture } from './use-dismiss-gesture';
import { RidePreferencesFields } from './ride-preferences';
import {
  defaultPreferences,
  type RidePreferences,
} from '@/lib/mobility/ride-preferences';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Switch } from '@/components/ui/switch';
import {
  defaultNavigation,
  navigationProviders,
  parseNavigation,
  type NavigationPreferences,
} from './navigation-preferences';
const key = 'luxore-navigation-device-v1';
const changed = 'luxore-navigation-settings';
export function useNavigationPreferences() {
  const [preferences, setPreferences] = useState(defaultNavigation);
  const [error, setError] = useState('');
  useEffect(() => {
    const read = () => {
      try {
        setPreferences(
          parseNavigation(JSON.parse(localStorage.getItem(key) || 'null')),
        );
      } catch {
        setPreferences(defaultNavigation);
      }
    };
    read();
    window.addEventListener(changed, read);
    window.addEventListener('storage', read);
    return () => {
      window.removeEventListener(changed, read);
      window.removeEventListener('storage', read);
    };
  }, []);
  function save(value: NavigationPreferences) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      setPreferences(value);
      setError('');
      window.dispatchEvent(new Event(changed));
    } catch {
      setError(
        'Einstellung konnte auf diesem Gerät nicht gespeichert werden. Bitte Speicherzugriff erlauben.',
      );
    }
  }
  return { preferences, save, error };
}
const providerIcons = [Compass, Route, Map, MapPin];
export default function NavigationSettings({
  open,
  onOpenChange,
  mode = 'driver',
  ridePreferences = defaultPreferences,
  onRidePreferencesChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  mode?: 'driver' | 'customer';
  ridePreferences?: RidePreferences;
  onRidePreferencesChange?: (value: RidePreferences) => void;
}) {
  const { preferences, save, error } = useNavigationPreferences();
  const autoId = useId();
  const driver = mode === 'driver';
  const close = () => onOpenChange(false);
  useBackLayer(open, close, 70);
  const drag = useDismissGesture(close);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="navigation-settings app-settings"
        showCloseButton={false}
        style={
          { '--dismiss-y': `${open ? drag.offset : 0}px` } as CSSProperties
        }
      >
        <div
          className="sheet-dismiss-handle"
          {...drag.handlers}
          aria-hidden="true"
        >
          <i />
        </div>
        <div className="settings-heading">
          <DialogHeader>
            <span className="app-kicker">DEIN LUXÓRE</span>
            <DialogTitle>Einstellungen</DialogTitle>
            <DialogDescription>
              {driver
                ? 'So navigierst du am liebsten.'
                : 'Deine Wünsche für die nächste Fahrtanfrage.'}
            </DialogDescription>
          </DialogHeader>
          <button
            type="button"
            className="settings-close"
            onClick={close}
            aria-label="Einstellungen schließen"
          >
            <X size={21} />
          </button>
        </div>
        <div className="settings-scroll">
          <h3 className="settings-section-title">
            {driver ? (
              <Navigation size={20} />
            ) : (
              <SlidersHorizontal size={20} />
            )}{' '}
            {driver ? 'Navigation' : 'Fahrtkomfort'}
          </h3>
          {driver ? (
            <>
              <RadioGroup
                aria-label="Navigations-App"
                value={preferences.provider}
                onValueChange={(v) =>
                  save({
                    ...preferences,
                    provider: parseNavigation({ provider: v }).provider,
                  })
                }
              >
                {navigationProviders.map((p, index) => {
                  const Icon = providerIcons[index];
                  return (
                    <label
                      key={p.id}
                      className={
                        'navigation-provider ' +
                        (preferences.provider === p.id ? 'selected' : '')
                      }
                    >
                      <RadioGroupItem
                        value={p.id}
                        aria-label={p.name}
                        className="provider-radio"
                      />
                      <span className="provider-icon">
                        <Icon size={23} strokeWidth={1.7} />
                      </span>
                      <span className="provider-copy">
                        <strong>{p.name}</strong>
                        <small>{p.description}</small>
                      </span>
                      <span className="provider-check" aria-hidden="true">
                        {preferences.provider === p.id && <Check size={16} />}
                      </span>
                    </label>
                  );
                })}
              </RadioGroup>
              <label className="navigation-auto" htmlFor={autoId}>
                <Zap className="setting-row-icon" size={22} />
                <span>
                  <strong>Automatisch öffnen</strong>
                  <small>
                    Bei Fahrtannahme zur Abholung. Bei Fahrtstart zum Ziel.
                  </small>
                </span>
                <Switch
                  id={autoId}
                  checked={preferences.autoStart}
                  onCheckedChange={(autoStart) =>
                    save({ ...preferences, autoStart })
                  }
                  aria-label="Navigation automatisch öffnen"
                />
              </label>
              <p className="small-note">
                Auf diesem Gerät gespeichert. Standard bleibt in Luxóre. Andere
                Apps öffnen sich per Link; den Navigationsstart musst du dort je
                nach Anbieter noch bestätigen.
              </p>
              {error && (
                <p role="alert" className="field-error">
                  {error}
                </p>
              )}
            </>
          ) : (
            <>
              <RidePreferencesFields
                value={ridePreferences}
                onChange={(value) => onRidePreferencesChange?.(value)}
              />
              <p className="small-note">
                Dein Fahrer erhält diese Wünsche mit deiner nächsten Anfrage.
                Vor dem Buchen kannst du sie nochmals anpassen.
              </p>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
// Reserve the browser tab during the swipe gesture; redirect only after the server confirms.
// Existing driver APKs intercept HTTPS navigation and hand it to the installed app.
export function prepareNavigation(
  url: string | null,
): { complete: () => boolean; cancel: () => void } | null {
  if (!url) return null;
  if (window.LuxoreNativeLocation)
    return {
      complete: () => {
        window.location.assign(url);
        return true;
      },
      cancel: () => {},
    };
  const tab = window.open('', '_blank');
  if (tab) tab.opener = null;
  return {
    complete: () => {
      if (!tab || tab.closed) return false;
      tab.location.replace(url);
      return true;
    },
    cancel: () => tab?.close(),
  };
}
