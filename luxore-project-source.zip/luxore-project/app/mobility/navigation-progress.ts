import type { RouteData } from '../../lib/mobility/domain';
import type { NavigationStep } from '../../lib/mobility/navigation-steps';
import { reliableCourse } from '../../lib/mobility/gps-telemetry.ts';
import { distanceMeters, usableFix, type GpsFix } from './gps-quality.ts';
import { projectRoad } from './navigation-motion.ts';
import { bearingBetween } from './map-camera.ts';
type Segment = {
  a: [number, number];
  b: [number, number];
  start: number;
  length: number;
  step: number;
  bearing: number;
};
type Step = NavigationStep & { start: number; length: number };
export type NavigationTrack = {
  route: RouteData;
  steps: Step[];
  segments: Segment[];
  length: number;
};
export type NavigationProgress = {
  track: NavigationTrack;
  fix: GpsFix;
  along: number;
  nextIndex: number;
  distanceToTurn: number;
  remainingMeters: number;
  remainingSeconds: number;
  next: NavigationStep;
  following: NavigationStep | null;
  nearDestination: boolean;
};
export function compileNavigation(
  route: RouteData | null,
): NavigationTrack | null {
  if (!route?.navigation?.length) return null;
  const segments: Segment[] = [],
    steps: Step[] = [];
  let along = 0;
  for (const [index, step] of route.navigation.entries()) {
    const start = along;
    for (let i = 1; i < step.coordinates.length; i++) {
      const a = step.coordinates[i - 1],
        b = step.coordinates[i];
      const from = { lng: a[0], lat: a[1] },
        to = { lng: b[0], lat: b[1] };
      const length = distanceMeters(from, to);
      if (length < 0.05) continue;
      segments.push({
        a,
        b,
        start: along,
        length,
        step: index,
        bearing: bearingBetween(from, to),
      });
      along += length;
    }
    steps.push({ ...step, start, length: along - start });
  }
  return segments.length && along > 0
    ? { route, steps, segments, length: along }
    : null;
}
export function navigationFixUsable(
  fix: GpsFix | null,
  now: number,
): fix is GpsFix {
  return (
    usableFix(fix, now) && fix.accuracy <= 35 && now - fix.timestamp <= 10000
  );
}
export function advanceNavigation(
  track: NavigationTrack,
  fix: GpsFix,
  now: number,
  previous: NavigationProgress | null,
): NavigationProgress | null {
  if (!navigationFixUsable(fix, now) || now - track.route.calculatedAt > 90000)
    return null;
  // A long GPS blackout invalidates the old progress anchor, especially after a detour.
  const prior =
    previous?.track === track && fix.timestamp - previous.fix.timestamp <= 15000
      ? previous
      : null;
  if (prior && fix.timestamp <= prior.fix.timestamp) return prior;
  const course = reliableCourse(fix);
  const tolerance = Math.max(12, Math.min(30, fix.accuracy * 1.3));
  const maxForward = prior
    ? 25 +
      Math.max(0, (fix.timestamp - prior.fix.timestamp) / 1000) *
        Math.max(30, (fix.speed || 0) + 12)
    : Infinity;
  const latitudeMargin = tolerance / 111000;
  const longitudeMargin =
    latitudeMargin / Math.max(0.1, Math.cos((fix.lat * Math.PI) / 180));
  const candidates = track.segments
    .flatMap((segment) => {
      // Limit expensive projections to nearby road segments, including on long routes.
      if (
        fix.lat < Math.min(segment.a[1], segment.b[1]) - latitudeMargin ||
        fix.lat > Math.max(segment.a[1], segment.b[1]) + latitudeMargin ||
        fix.lng < Math.min(segment.a[0], segment.b[0]) - longitudeMargin ||
        fix.lng > Math.max(segment.a[0], segment.b[0]) + longitudeMargin
      )
        return [];
      if (
        prior &&
        (segment.start + segment.length < prior.along - 12 ||
          segment.start > prior.along + maxForward)
      )
        return [];
      const projection = projectRoad(fix, [segment.a, segment.b])!;
      const along = segment.start + projection.along;
      const angle =
        course === null
          ? 0
          : Math.abs(((segment.bearing - course + 540) % 360) - 180);
      if (
        projection.distance > tolerance ||
        angle > 100 ||
        (prior &&
          (along < prior.along - 12 || along > prior.along + maxForward))
      )
        return [];
      return [
        {
          segment,
          along,
          distance: projection.distance,
          score:
            projection.distance +
            angle * 0.025 +
            (prior ? Math.abs(along - prior.along) * 0.012 : 0),
        },
      ];
    })
    .sort((a, b) => a.score - b.score || a.along - b.along);
  const best = candidates[0];
  if (!best) return null;
  // At an overlapping road/loop, don't jump to a distant future turn.
  if (
    candidates.some(
      (c) =>
        Math.abs(c.along - best.along) > 45 &&
        Math.abs(c.score - best.score) < 3,
    )
  )
    return null;
  const along = Math.max(prior?.along || 0, best.along);
  const found = track.steps.findIndex(
    (step, index) => index > 0 && step.start + 5 > along,
  );
  const nextIndex = Math.max(
    prior?.nextIndex || 1,
    found < 0 ? track.steps.length - 1 : found,
  );
  const next = track.steps[nextIndex];
  let remainingMeters = 0,
    remainingSeconds = 0;
  for (const step of track.steps) {
    const fraction =
      step.length > 0
        ? Math.max(
            0,
            Math.min(1, (step.start + step.length - along) / step.length),
          )
        : step.start >= along
          ? 1
          : 0;
    remainingMeters += step.distanceMeters * fraction;
    remainingSeconds += step.durationSeconds * fraction;
  }
  const toEnd = distanceMeters(fix, track.route.destination);
  return {
    track,
    fix,
    along,
    nextIndex,
    next,
    following: track.steps[nextIndex + 1] || null,
    distanceToTurn: Math.max(0, next.start - along),
    remainingMeters,
    remainingSeconds,
    nearDestination: remainingMeters <= 20 && toEnd <= 30,
  };
}
export function navigationDistance(meters: number) {
  if (meters < 15) return 'Jetzt';
  if (meters < 1000) return `${Math.max(10, Math.round(meters / 10) * 10)} m`;
  return `${(meters / 1000).toLocaleString('de-DE', { maximumFractionDigits: 1 })} km`;
}
export function remainingDistance(meters: number) {
  return meters < 1000
    ? `${Math.max(0, Math.round(meters / 10) * 10)} m`
    : `${(meters / 1000).toLocaleString('de-DE', { maximumFractionDigits: 1 })} km`;
}
