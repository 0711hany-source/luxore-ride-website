'use client';
import { useEffect, useRef, useState, type CSSProperties } from 'react';
import type mapboxgl from 'mapbox-gl';
import { MapPin, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogClose,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import type { Point } from '@/lib/mobility/domain';
import { api } from './api';
import { useBackLayer } from './use-back-layer';
import { useDismissGesture } from './use-dismiss-gesture';
import { mapErrorMessage } from './map-recovery';
import { attachMapAutoReturn } from './map-auto-return';
export default function PickupPicker({
  token,
  value,
  onChange,
}: {
  token: string | null;
  value: Point | null;
  onChange: (p: Point) => void;
}) {
  const [open, setOpen] = useState(false);
  useBackLayer(open, () => setOpen(false), 90);
  const drag = useDismissGesture(() => setOpen(false));
  return (
    <>
      <Button variant="outline" disabled={!token} onClick={() => setOpen(true)}>
        <MapPin />
        Abholpunkt auf Karte wählen
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent
          showCloseButton={false}
          className="pickup-dialog app-detail-sheet"
          style={
            { '--dismiss-y': `${open ? drag.offset : 0}px` } as CSSProperties
          }
        >
          <div
            className="sheet-dismiss-handle"
            {...drag.handlers}
            aria-hidden="true"
          >
            <i />
          </div>
          <DialogClose
            render={
              <Button variant="ghost" className="absolute top-2 right-2" />
            }
            aria-label="Abholortauswahl schließen"
          >
            <X size={20} />
          </DialogClose>
          <DialogHeader>
            <DialogTitle>Abholort bestätigen</DialogTitle>
            <DialogDescription>
              Verschiebe die Karte, bis die Markierung am gewünschten Abholpunkt
              steht.
            </DialogDescription>
          </DialogHeader>
          {open && token && (
            <PickerMap
              token={token}
              initial={value}
              done={(p) => {
                onChange(p);
                setOpen(false);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
function PickerMap({
  token,
  initial,
  done,
}: {
  token: string;
  initial: Point | null;
  done: (p: Point) => void;
}) {
  const container = useRef<HTMLDivElement>(null),
    revision = useRef(0),
    alive = useRef(true);
  const [point, setPoint] = useState({
      lat: initial?.lat ?? 50.1109,
      lng: initial?.lng ?? 8.6821,
    }),
    [ready, setReady] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [attempt, setAttempt] = useState(0);
  const centre = useRef(point);
  useEffect(() => {
    alive.current = true;
    let disposed = false;
    let instance: mapboxgl.Map | undefined;
    let autoReturn: ReturnType<typeof attachMapAutoReturn> | undefined;
    void import('mapbox-gl')
      .then(({ default: m }) => {
        if (disposed || !container.current) return;
        instance = new m.Map({
          container: container.current,
          accessToken: token,
          style: 'mapbox://styles/mapbox/light-v11',
          center: [centre.current.lng, centre.current.lat],
          zoom: 16,
        });
        autoReturn = attachMapAutoReturn(
          instance,
          () => {
            // Keep the newly chosen pickup point; only restore scale and orientation.
            instance?.easeTo({ zoom: 16, bearing: 0, pitch: 0, duration: 600 });
          },
          () => {},
        );
        instance.on('load', () => {
          if (!disposed) {
            setReady(true);
            setError('');
          }
        });
        instance.on('movestart', (event) => {
          if (event.originalEvent) {
            revision.current++;
            setBusy(false);
          }
        });
        instance.on('moveend', () => {
          const p = instance!.getCenter();
          centre.current = { lat: p.lat, lng: p.lng };
          setPoint(centre.current);
        });
        instance.on('idle', () => {
          if (!disposed) setError('');
        });
        instance.on('error', (e) => {
          if (!disposed) setError(mapErrorMessage(e.error).message);
        });
      })
      .catch(() => {
        if (!disposed) setError('Karte konnte nicht geladen werden.');
      });
    return () => {
      disposed = true;
      alive.current = false;
      autoReturn?.dispose();
      instance?.remove();
    };
  }, [token, attempt]);
  async function confirm() {
    const rev = ++revision.current;
    setBusy(true);
    setError('');
    try {
      const r = await api<{ results: Point[] }>('places', {
        kind: 'pin',
        ...point,
      });
      if (!alive.current || rev !== revision.current) return;
      if (!r.results[0])
        throw new Error('Keine Adresse gefunden. Wähle einen anderen Punkt.');
      done(r.results[0]);
    } catch (e) {
      if (alive.current && rev === revision.current)
        setError((e as Error).message);
    } finally {
      if (alive.current && rev === revision.current) setBusy(false);
    }
  }
  return (
    <>
      <div className="pickup-map">
        <div ref={container} />
        {!ready && !error && (
          <div className="pickup-map-loading" role="status">
            Karte wird geladen …
          </div>
        )}
        <div className="luxore-pickup-reticle" aria-hidden="true">
          <div className="reticle-badge">ABHOLORT</div>
          <div className="reticle-target">
            <span className="reticle-axis-y" />
            <span className="reticle-axis-x" />
            <span className="reticle-ring-outer" />
            <span className="reticle-ring-inner" />
            <span className="reticle-dot" />
          </div>
          <div className="reticle-shadow" />
        </div>
      </div>
      <p className="small-note">
        Die Markierung bestimmt den Abholpunkt. Achte auf einen erreichbaren,
        sicheren Halteort.
      </p>
      {error && (
        <div role="alert" className="field-error">
          {error}
          <Button
            variant="outline"
            onClick={() => {
              setReady(false);
              setError('');
              setAttempt((v) => v + 1);
            }}
          >
            Karte neu verbinden
          </Button>
        </div>
      )}
      <Button
        className="primary-action"
        disabled={!ready || busy}
        onClick={() => void confirm()}
      >
        {busy ? 'Adresse wird ermittelt …' : 'Diesen Abholpunkt bestätigen'}
      </Button>
    </>
  );
}
