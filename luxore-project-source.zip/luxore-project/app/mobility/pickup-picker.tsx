'use client';
import { useEffect, useRef, useState, type CSSProperties } from 'react';
import type mapboxgl from 'mapbox-gl';
import { MapPin, X, Globe2, ZoomIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogClose,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import type { Point } from '@/lib/mobility/domain';
import { api } from './api';
import { useBackLayer } from './use-back-layer';
import { useDismissGesture } from './use-dismiss-gesture';
import { mapErrorMessage } from './map-recovery';
import { attachMapAutoReturn } from './map-auto-return';
import { EUROPE_MAP_VIEW } from '@/lib/mobility/map-region';
export default function PickupPicker({
  token,
  value,
  onChange,
  purpose = 'pickup',
}: {
  purpose?: 'pickup' | 'destination';
  token: string | null;
  value: Point | null;
  onChange: (p: Point) => void;
}) {
  const [open, setOpen] = useState(false);
  useBackLayer(open, () => setOpen(false), 90);
  const drag = useDismissGesture(() => setOpen(false));
  return (
    <>
      <Button variant="outline" disabled={!token} onClick={() => setOpen(true)}>
        <MapPin />
        {purpose === 'pickup'
          ? 'Abholpunkt auf Karte wählen'
          : 'Zielpunkt auf Karte wählen'}
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent
          showCloseButton={false}
          className="pickup-dialog app-detail-sheet"
          style={
            { '--dismiss-y': `${open ? drag.offset : 0}px` } as CSSProperties
          }
        >
          <div
            className="sheet-dismiss-handle"
            {...drag.handlers}
            aria-hidden="true"
          >
            <i />
          </div>
          <DialogClose
            render={
              <Button variant="ghost" className="absolute top-2 right-2" />
            }
            aria-label={
              purpose === 'pickup'
                ? 'Abholortauswahl schließen'
                : 'Zielauswahl schließen'
            }
          >
            <X size={20} />
          </DialogClose>
          <DialogHeader>
            <DialogTitle>
              {purpose === 'pickup' ? 'Abholort bestätigen' : 'Ziel bestätigen'}
            </DialogTitle>
            <DialogDescription>
              Verschiebe die Karte, bis die Markierung am gewünschten Punkt
              steht.
            </DialogDescription>
          </DialogHeader>
          {open && token && (
            <PickerMap
              token={token}
              initial={value}
              purpose={purpose}
              done={(p) => {
                onChange(p);
                setOpen(false);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
function PickerMap({
  token,
  initial,
  purpose,
  done,
}: {
  token: string;
  purpose: 'pickup' | 'destination';
  initial: Point | null;
  done: (p: Point) => void;
}) {
  const container = useRef<HTMLDivElement>(null),
    revision = useRef(0),
    alive = useRef(true);
  const [point, setPoint] = useState({
      lat: initial?.lat ?? EUROPE_MAP_VIEW.center[1],
      lng: initial?.lng ?? EUROPE_MAP_VIEW.center[0],
    }),
    [ready, setReady] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [attempt, setAttempt] = useState(0);
  const centre = useRef(point);
  const map = useRef<mapboxgl.Map | null>(null);
  const returnZoom = useRef(initial ? 16 : EUROPE_MAP_VIEW.zoom);
  const [zoom, setZoom] = useState(initial ? 16 : EUROPE_MAP_VIEW.zoom);
  const [moving, setMoving] = useState(false);
  useEffect(() => {
    alive.current = true;
    let disposed = false;
    let instance: mapboxgl.Map | undefined;
    let observer: ResizeObserver | undefined;
    let autoReturn: ReturnType<typeof attachMapAutoReturn> | undefined;
    void import('mapbox-gl')
      .then(({ default: m }) => {
        if (disposed || !container.current) return;
        instance = new m.Map({
          container: container.current,
          accessToken: token,
          style: 'mapbox://styles/mapbox/light-v11',
          center: [centre.current.lng, centre.current.lat],
          zoom: returnZoom.current,
        });
        map.current = instance;
        observer = new ResizeObserver(() => {
          if (!disposed) instance?.resize();
        });
        observer.observe(container.current);
        autoReturn = attachMapAutoReturn(
          instance,
          () => {
            // Keep the newly chosen pickup point; only restore scale and orientation.
            instance?.easeTo({
              zoom: returnZoom.current,
              bearing: 0,
              pitch: 0,
              duration: 600,
            });
          },
          () => {},
        );
        instance.on('load', () => {
          if (!disposed) {
            setReady(true);
            setError('');
          }
        });
        instance.on('movestart', (event) => {
          if (disposed) return;
          setMoving(true);
          if (event.originalEvent) {
            revision.current++;
            setBusy(false);
          }
        });
        instance.on('moveend', () => {
          if (disposed) return;
          const p = instance!.getCenter();
          centre.current = { lat: p.lat, lng: p.lng };
          setPoint(centre.current);
          setZoom(instance!.getZoom());
          setMoving(false);
          // Once the user reaches street detail, return to street detail after gestures.
          if (instance!.getZoom() >= 13) returnZoom.current = 16;
        });
        instance.on('idle', () => {
          if (!disposed) setError('');
        });
        instance.on('error', (e) => {
          if (!disposed) setError(mapErrorMessage(e.error).message);
        });
      })
      .catch(() => {
        if (!disposed) setError('Karte konnte nicht geladen werden.');
      });
    return () => {
      disposed = true;
      alive.current = false;
      autoReturn?.dispose();
      observer?.disconnect();
      map.current = null;
      instance?.remove();
    };
  }, [token, attempt]);
  async function confirm() {
    if (zoom < 13 || moving || busy || !ready) return;
    const rev = ++revision.current;
    setBusy(true);
    setError('');
    try {
      const r = await api<{ results: Point[] }>('places', {
        kind: 'pin',
        ...point,
      });
      if (!alive.current || rev !== revision.current) return;
      if (!r.results[0])
        throw new Error('Keine Adresse gefunden. Wähle einen anderen Punkt.');
      done(r.results[0]);
    } catch (e) {
      if (alive.current && rev === revision.current)
        setError((e as Error).message);
    } finally {
      if (alive.current && rev === revision.current) setBusy(false);
    }
  }
  return (
    <>
      <div className="pickup-map">
        <div ref={container} />
        {!ready && !error && (
          <output className="pickup-map-loading">Karte wird geladen …</output>
        )}
        <div className="luxore-pickup-reticle" aria-hidden="true">
          <div className="reticle-badge">
            {purpose === 'pickup' ? 'ABHOLORT' : 'ZIEL'}
          </div>
          <div className="reticle-target">
            <span className="reticle-axis-y" />
            <span className="reticle-axis-x" />
            <span className="reticle-ring-outer" />
            <span className="reticle-ring-inner" />
            <span className="reticle-dot" />
          </div>
          <div className="reticle-shadow" />
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button
          variant="outline"
          disabled={!ready || busy}
          onClick={() => {
            returnZoom.current = EUROPE_MAP_VIEW.zoom;
            map.current?.easeTo({
              center: EUROPE_MAP_VIEW.center,
              zoom: EUROPE_MAP_VIEW.zoom,
              bearing: 0,
              pitch: 0,
              duration: 600,
            });
          }}
        >
          <Globe2 size={18} /> Europa
        </Button>
        <Button
          variant="outline"
          disabled={!ready || busy}
          onClick={() => {
            returnZoom.current = 16;
            map.current?.easeTo({
              zoom: 16,
              bearing: 0,
              pitch: 0,
              duration: 600,
            });
          }}
        >
          <ZoomIn size={18} /> Punkt vergrößern
        </Button>
      </div>
      <p className="small-note">
        {zoom < 13
          ? 'Wähle die Region und vergrößere den Punkt bis zur Straßenansicht. '
          : ''}
        Die Markierung bestimmt den gewählten Punkt. Achte auf einen
        erreichbaren, sicheren Halteort.
      </p>
      {error && (
        <div role="alert" className="field-error">
          {error}
          <Button
            variant="outline"
            onClick={() => {
              setReady(false);
              setError('');
              setAttempt((v) => v + 1);
            }}
          >
            Karte neu verbinden
          </Button>
        </div>
      )}
      <Button
        className="primary-action"
        disabled={!ready || busy || moving || zoom < 13}
        onClick={() => void confirm()}
      >
        {busy
          ? 'Punkt wird bestätigt …'
          : purpose === 'pickup'
            ? 'Diesen Abholpunkt bestätigen'
            : 'Dieses Ziel bestätigen'}
      </Button>
    </>
  );
}
