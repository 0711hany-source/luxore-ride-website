import { MAX_IMAGE_BYTES, MAX_IMAGE_EDGE } from '@/lib/mobility/images';

const toBlob = (canvas: HTMLCanvasElement, quality: number) =>
  new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, 'image/jpeg', quality),
  );
async function decode(file: Blob) {
  if ('createImageBitmap' in window) {
    try {
      // Applies the camera orientation stored in the photo.
      return await createImageBitmap(file, { imageOrientation: 'from-image' });
    } catch {}
  }
  const url = URL.createObjectURL(file);
  try {
    const image = new Image();
    image.src = url;
    await image.decode();
    return image;
  } finally {
    URL.revokeObjectURL(url);
  }
}
/**
 * Shrinks a photo in the browser before it leaves the device: longest edge
 * 1600 px, JPEG, at most 400 KB. Nothing larger is ever uploaded.
 */
export async function shrinkPhoto(file: Blob): Promise<Blob> {
  let source: ImageBitmap | HTMLImageElement;
  try {
    source = await decode(file);
  } catch {
    throw new Error('Dieses Foto kann nicht gelesen werden. Bitte ein JPEG- oder PNG-Foto wählen.');
  }
  let scale = Math.min(1, MAX_IMAGE_EDGE / Math.max(source.width, source.height));
  for (let attempt = 0; attempt < 5; attempt++) {
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(source.width * scale));
    canvas.height = Math.max(1, Math.round(source.height * scale));
    const context = canvas.getContext('2d');
    if (!context) break;
    // White ground: a transparent PNG must not turn black as JPEG.
    context.fillStyle = '#fff';
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(source, 0, 0, canvas.width, canvas.height);
    for (const quality of [0.82, 0.7, 0.58, 0.46]) {
      const blob = await toBlob(canvas, quality);
      if (blob && blob.size <= MAX_IMAGE_BYTES) return blob;
    }
    scale *= 0.75;
  }
  throw new Error('Das Foto konnte nicht verkleinert werden. Bitte erneut aufnehmen.');
}
export async function uploadPhoto(
  ownerType: 'document' | 'inspection',
  ownerId: string,
  file: Blob,
  slot = 'photo',
) {
  const blob = await shrinkPhoto(file);
  const response = await fetch(
    `/api/mobility/images?ownerType=${ownerType}&ownerId=${encodeURIComponent(ownerId)}&slot=${encodeURIComponent(slot)}`,
    { method: 'POST', headers: { 'Content-Type': 'image/jpeg' }, body: blob },
  ).catch(() => {
    throw new Error('Keine Verbindung. Bitte Internetverbindung prüfen und erneut versuchen.');
  });
  const value = (await response.json().catch(() => ({}))) as {
    id?: string;
    error?: string;
  };
  if (!response.ok || !value.id)
    throw new Error(value.error || 'Das Foto konnte nicht gespeichert werden.');
  return value.id;
}
export const photoUrl = (id: string) =>
  '/api/mobility/images?id=' + encodeURIComponent(id);
