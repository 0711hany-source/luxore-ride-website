'use client';
import {
  useEffect,
  useRef,
  useState,
  type KeyboardEvent,
  type PointerEvent,
  type RefObject,
} from 'react';
import { sheetHeights, settleSheet, type SheetStop } from './sheet-motion';
export function useSheetMotion(
  root: RefObject<HTMLElement | null>,
  collapseRequest = 0,
  initialStop: SheetStop = 'half',
  reservedTop = 0,
) {
  const [available, setAvailable] = useState(600);
  const [stop, setStop] = useState<SheetStop>(initialStop);
  const [dragHeight, setDragHeight] = useState<number | null>(null);
  const [previousCollapse, setPreviousCollapse] = useState(0);
  if (collapseRequest !== previousCollapse) {
    setPreviousCollapse(collapseRequest);
    setStop('peek');
    setDragHeight(null);
  }
  const gesture = useRef<{
    id: number;
    y: number;
    x: number;
    height: number;
    lastY: number;
    lastAt: number;
    velocity: number;
    dragged: boolean;
  } | null>(null);
  const suppressClick = useRef(false);
  const heights = sheetHeights(available);
  const height = dragHeight ?? heights[stop];
  useEffect(() => {
    const parent = root.current?.parentElement;
    if (!parent) return;
    const resize = () =>
      setAvailable(Math.max(96, parent.clientHeight - reservedTop));
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(parent);
    return () => observer.disconnect();
  }, [root, reservedTop]);
  const cancel = () => {
    gesture.current = null;
    setDragHeight(null);
    suppressClick.current = true;
  };
  const handlers = {
    onPointerDown(e: PointerEvent<HTMLButtonElement>) {
      if (!e.isPrimary || e.button !== 0 || gesture.current) {
        cancel();
        return;
      }
      e.stopPropagation();
      e.currentTarget.setPointerCapture(e.pointerId);
      suppressClick.current = false;
      gesture.current = {
        id: e.pointerId,
        y: e.clientY,
        x: e.clientX,
        height,
        lastY: e.clientY,
        lastAt: e.timeStamp,
        velocity: 0,
        dragged: false,
      };
    },
    onPointerMove(e: PointerEvent<HTMLButtonElement>) {
      const g = gesture.current;
      if (!g || g.id !== e.pointerId) return;
      if (
        !g.dragged &&
        Math.abs(e.clientX - g.x) > Math.abs(e.clientY - g.y) + 14
      ) {
        cancel();
        return;
      }
      const dt = e.timeStamp - g.lastAt;
      if (dt > 0)
        g.velocity = g.velocity * 0.35 + ((g.lastY - e.clientY) / dt) * 0.65;
      g.lastAt = e.timeStamp;
      g.lastY = e.clientY;
      if (Math.abs(e.clientY - g.y) > 8) g.dragged = true;
      if (g.dragged)
        setDragHeight(
          Math.max(
            heights.peek,
            Math.min(heights.full, g.height + g.y - e.clientY),
          ),
        );
    },
    onPointerUp(e: PointerEvent<HTMLButtonElement>) {
      const g = gesture.current;
      if (!g || g.id !== e.pointerId) return;
      gesture.current = null;
      suppressClick.current = g.dragged;
      if (g.dragged)
        setStop(
          settleSheet(
            Math.max(
              heights.peek,
              Math.min(heights.full, g.height + g.y - e.clientY),
            ),
            e.timeStamp - g.lastAt < 160 ? g.velocity : 0,
            heights,
          ),
        );
      setDragHeight(null);
    },
    onPointerCancel: cancel,
    onLostPointerCapture() {
      if (gesture.current) cancel();
    },
    onClick() {
      if (!suppressClick.current) setStop(stop === 'peek' ? 'half' : 'peek');
      suppressClick.current = false;
    },
    onKeyDown(e: KeyboardEvent<HTMLButtonElement>) {
      if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        e.preventDefault();
        setStop(
          e.key === 'ArrowUp'
            ? stop === 'peek'
              ? 'half'
              : 'full'
            : stop === 'full'
              ? 'half'
              : 'peek',
        );
      }
    },
  };
  return { stop, height, dragging: dragHeight !== null, handlers };
}
