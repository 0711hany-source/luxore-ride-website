'use client';
import { useState } from 'react';
import { api } from './api';
import { photoUrl } from './photo';
import {
  RATING_COMMENT_MAX,
  RATING_WINDOW_MS,
} from '@/lib/mobility/rating-rules';

export type ShownRating = { average: number; count: number } | null | undefined;
const comma = (value: number) => value.toFixed(1).replace('.', ',');
/** "★ 4,7 (12)" — or "Neu" while there are too few ratings to show. */
export function RatingBadge({
  rating,
  emptyLabel = 'Neu',
}: {
  rating: ShownRating;
  emptyLabel?: string;
}) {
  return rating ? (
    <span
      className="pf-rating"
      aria-label={`Bewertung ${comma(rating.average)} von 5 aus ${rating.count} Bewertungen`}
    >
      <b aria-hidden="true">★</b>
      {comma(rating.average)}
      <small>
        ({rating.count} {rating.count === 1 ? 'Bewertung' : 'Bewertungen'})
      </small>
    </span>
  ) : (
    <span className="pf-chip">{emptyLabel}</span>
  );
}
export function StarsShown({ stars }: { stars: number }) {
  return (
    <span className="pf-stars-shown" aria-label={`${stars} von 5 Sternen`}>
      {'★'.repeat(stars)}
      <i>{'★'.repeat(5 - stars)}</i>
    </span>
  );
}
/** Round picture of a driver, or the first letter while there is none. */
export function Avatar({
  name,
  photoId,
  large = false,
}: {
  name: string;
  photoId?: string | null;
  large?: boolean;
}) {
  return (
    <span className={'pf-avatar' + (large ? ' large' : '')}>
      {photoId ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={photoUrl(photoId)} alt={'Profilbild von ' + name} />
      ) : (
        <span aria-hidden="true">{name.slice(0, 1).toUpperCase()}</span>
      )}
    </span>
  );
}
/**
 * Stars after a finished ride. Shows what was given, or the input while the
 * 14 days run; afterwards nothing. A rating cannot be changed.
 */
export default function RideRating({
  bookingId,
  given,
  completedAt,
  who,
  onSaved,
}: {
  bookingId: string;
  /** Stars this person already gave for the ride. */
  given?: number;
  completedAt: number | null;
  who: 'chauffeur' | 'fahrgast';
  onSaved?: (stars: number) => void;
}) {
  const [stars, setStars] = useState(0),
    [comment, setComment] = useState(''),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [saved, setSaved] = useState<number | null>(null),
    [openedAt] = useState(() => Date.now());
  const done = saved ?? given;
  if (done)
    return (
      <div className="pf trip-rating">
        <div className="pf-row">
          <span className="pf-muted">Deine Bewertung</span>
          <StarsShown stars={done} />
        </div>
      </div>
    );
  if (!completedAt || openedAt - completedAt > RATING_WINDOW_MS) return null;
  async function send() {
    setBusy(true);
    setError('');
    try {
      await api('ratings', {
        bookingId,
        stars,
        comment: comment.trim() || undefined,
      });
      setSaved(stars);
      onSaved?.(stars);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const labels = ['', 'Schlecht', 'Mäßig', 'In Ordnung', 'Gut', 'Sehr gut'];
  return (
    <div className="pf trip-rating">
      <h4>
        {who === 'chauffeur'
          ? 'Wie war deine Fahrt?'
          : 'Wie war der Fahrgast?'}
      </h4>
      <div
        className="pf-stars"
        role="group"
        aria-label={
          who === 'chauffeur' ? 'Chauffeur bewerten' : 'Fahrgast bewerten'
        }
      >
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            type="button"
            aria-pressed={stars >= n}
            aria-label={`${n} ${n === 1 ? 'Stern' : 'Sterne'} – ${labels[n]}`}
            disabled={busy}
            onClick={() => setStars(n)}
          >
            ★
          </button>
        ))}
      </div>
      {stars > 0 && (
        <>
          <label className="pf-field">
            Kommentar (freiwillig)
            <textarea
              value={comment}
              maxLength={RATING_COMMENT_MAX}
              onChange={(e) => setComment(e.target.value)}
            />
            <small>
              Wird nie veröffentlicht. Nur Betreiber und Flottenleitung lesen
              ihn. {comment.length}/{RATING_COMMENT_MAX}
            </small>
          </label>
          <button
            type="button"
            className="pf-btn primary wide"
            disabled={busy}
            onClick={() => void send()}
          >
            {busy
              ? 'Wird gespeichert …'
              : `${stars} ${stars === 1 ? 'Stern' : 'Sterne'} abgeben`}
          </button>
          <p className="pf-muted">
            Die Bewertung kann danach nicht mehr geändert werden.
          </p>
        </>
      )}
      {error && (
        <p className="pf-error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
