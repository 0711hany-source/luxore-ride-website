'use client';
import { Clock3, Route, Timer } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Offer } from '@/lib/mobility/domain';
import { className, money } from '@/lib/ride-domain';
import { RidePreferencesSummary } from './ride-preferences';
import SwipeAction from './swipe-action';
import { BoardSummary } from './refreshments';
import AddressAttribution from './address-attribution';
export default function DriverOffer({
  offer,
  now,
  busy,
  onAccept,
  onReject,
}: {
  offer: Offer;
  now: number;
  busy: boolean;
  onAccept: () => void;
  onReject: () => void;
}) {
  const seconds = Math.max(0, Math.ceil((offer.expires_at - now) / 1000));
  const unavailable = busy || seconds === 0;
  const trip = offer.booking;
  return (
    <article className="driver-offer-card">
      <header className="driver-offer-heading">
        <span className="app-kicker">
          {trip.mode === 'reservation' ? 'RESERVIERTE FAHRT' : 'NEUE FAHRT'}
        </span>
        <span className="offer-countdown" role="timer">
          <Timer size={15} />
          {seconds ? `${seconds} s` : 'Abgelaufen'}
        </span>
      </header>
      <div className="driver-offer-fare">
        <div>
          <span>Fahrpreis</span>
          <strong>{money(trip.price)}</strong>
        </div>
        <span className="driver-class-label">{className(trip.service)}</span>
      </div>
      <div className="driver-route-metrics">
        <span>
          <Route size={16} />
          {(trip.route.distanceMeters / 1000).toLocaleString('de-DE', {
            maximumFractionDigits: 1,
          })}{' '}
          km Fahrt
        </span>
        <span>
          <Clock3 size={16} />
          ca. {Math.ceil(trip.route.durationSeconds / 60)} Min.
        </span>
      </div>
      {trip.scheduled_at && (
        <p className="driver-reservation-time">
          Abholung{' '}
          {new Date(trip.scheduled_at).toLocaleString('de-DE', {
            timeZone: 'Europe/Berlin',
            day: '2-digit',
            month: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
          })}
        </p>
      )}
      <div className="driver-route-stops">
        <div>
          <i aria-hidden="true" />
          <span>
            <small>Abholung</small>
            <strong>{trip.route.pickup.label}</strong>
          </span>
        </div>
        <div>
          <i aria-hidden="true" />
          <span>
            <small>Ziel</small>
            <strong>{trip.route.destination.label}</strong>
          </span>
        </div>
      </div>
      <BoardSummary booking={trip} />
      <AddressAttribution
        points={[trip.route.pickup, trip.route.destination]}
      />
      <RidePreferencesSummary value={trip.rider_preferences} />
      <div className="driver-sheet-actions">
        <SwipeAction
          label="Fahrt annehmen"
          disabled={unavailable}
          onConfirm={onAccept}
        />
        <Button
          className="offer-decline"
          variant="ghost"
          disabled={unavailable}
          onClick={onReject}
        >
          Fahrt ablehnen
        </Button>
      </div>
    </article>
  );
}
