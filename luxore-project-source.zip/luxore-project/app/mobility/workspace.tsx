'use client';
import { useEffect, useState, useRef, useCallback } from 'react';
import Link from 'next/link';
/* SIWC sign-in requires a full page navigation, never a prefetched framework Link. */
/* eslint-disable next/no-html-link-for-pages */
import {
  ArrowLeft,
  ArrowRight,
  MapPin,
  Clock3,
  LocateFixed,
  Phone,
  CalendarDays,
  CarFront,
  RefreshCw,
  ShieldCheck,
} from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { className, money } from '@/lib/ride-domain';
import {
  statusNames,
  driverServices,
  activeStatuses,
  type Point,
  type Quote,
  type Booking,
  type Driver,
  type Service,
} from '@/lib/mobility/domain';
import Address from './address';
import AddressAttribution from './address-attribution';
import RideMap from './map';
import Safety from './safety';
import DriverView, { type DriverState } from './driver';
import Services from './services';
import Fleets from './fleets';
import CustomerHome from './customer-home';
import VehicleArtwork from './vehicle-artwork';
import ClassPicker from './class-picker';
import BookingCheckout from './checkout';
import BoardOrder from './refreshments';
import type { Cart } from '@/lib/mobility/refreshments';
import PickupPicker from './pickup-picker';
import { useBackLayer } from './use-back-layer';
import { RidePanel, SwipePages } from './gesture';
import { api, advanceDispatch } from './api';
import { useClock } from './use-clock';
import AppMenu from './app-menu';
import NavigationSettings from './navigation-settings';
import AppHeader, { AppBrand } from './app-header';
import { defaultPreferences } from '@/lib/mobility/ride-preferences';
import { RidePreferencesSummary } from './ride-preferences';
import { AppLoading } from './app-loading';
import { useAppViewport } from './use-app-viewport';
type Config = {
  authenticated: boolean;
  name: string;
  userId: string;
  account?: { name: string; phone: string } | null;
  isAdmin: boolean;
  canDispatch: boolean;
  mapsReady: boolean;
  publicMapToken: string | null;
};
export default function MobilityWorkspace({
  appMode,
  initialView,
}: {
  appMode?: 'customer' | 'driver';
  initialView?: string;
}) {
  // Disposition and /ride share the same portalled dialogs as the installed apps.
  useAppViewport(true);
  const now = useClock();
  const [menuOpen, setMenuOpen] = useState(false);
  const [navigationSettings, setNavigationSettings] = useState(false);
  const [refreshments, setRefreshments] = useState<Cart>({});
  const [preferences, setPreferences] = useState(defaultPreferences);
  const [editingRoute, setEditingRoute] = useState(false);
  const [checkout, setCheckout] = useState(false);
  const [riderName, setRiderName] = useState('');
  const [riderPhone, setRiderPhone] = useState('');
  const [config, setConfig] = useState<Config | null>(null),
    [authPending, setAuthPending] = useState(true),
    [view, setView] = useState(
      initialView || (appMode === 'driver' ? 'driver' : 'guest'),
    ),
    [phase, setPhase] = useState<'search' | 'select' | 'trip'>('search');
  const [pickup, setPickup] = useState<Point | null>(null),
    [destination, setDestination] = useState<Point | null>(null),
    [mode, setMode] = useState<'now' | 'reservation'>('now'),
    [scheduled, setScheduled] = useState(''),
    [quote, setQuote] = useState<Quote | null>(null),
    [service, setService] = useState<Service>('premium');
  const [bookings, setBookings] = useState<Booking[]>([]),
    [selectedId, setSelectedId] = useState<string | null>(null),
    [driverState, setDriverState] = useState<DriverState | null>(null),
    [operations, setOperations] = useState<{
      drivers: (Driver & { fleet_id?: string; fleet_name?: string })[];
      bookings: Booking[];
    } | null>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [syncError, setSyncError] = useState(''),
    [syncedAt, setSyncedAt] = useState<number | null>(null),
    [sharingId, setSharingId] = useState<string | null>(null);
  const shareWatch = useRef<number | null>(null),
    shareLast = useRef(0),
    busyRef = useRef(false);

  const defaultView = appMode === 'driver' ? 'driver' : 'guest';
  useEffect(() => {
    if (appMode) window.scrollTo(0, 0);
  }, [appMode, view, phase, editingRoute]);
  const isSubPage = Boolean(
    appMode &&
    (view === 'operations' ||
      view === 'services' ||
      (appMode === 'customer' && view === 'reservations')),
  );
  const navigateBack = useCallback(() => {
    if (menuOpen) {
      setMenuOpen(false);
      return;
    }
    if (checkout) {
      setCheckout(false);
      return;
    }
    if (view !== defaultView) {
      setView(defaultView);
      return;
    }
    if (phase === 'select') {
      setPhase('search');
      setEditingRoute(true);
      setQuote(null);
      return;
    }
    if (editingRoute) {
      setEditingRoute(false);
      return;
    }
  }, [menuOpen, checkout, phase, editingRoute, view, defaultView]);

  useBackLayer(
    !!appMode && (isSubPage || phase === 'select' || editingRoute),
    navigateBack,
    20,
  );
  const refresh = useCallback(async () => {
    if (!config) return;
    await advanceDispatch();
    const data = await api<{ bookings: Booking[] }>('bookings');
    setBookings(data.bookings);
    if (view === 'driver' || appMode === 'driver')
      setDriverState(await api<DriverState>('driver'));
    if (view === 'operations' && config.canDispatch)
      setOperations(await api('operations'));
    setSyncedAt(Date.now());
    setSyncError('');
  }, [config, view, appMode]);
  useEffect(() => {
    const controller = new AbortController();
    api('session', {}, controller.signal)
      .then(() => api<Config>('config', undefined, controller.signal))
      .then((c) => {
        setConfig(c);
        if (c.account) {
          setRiderName(c.account.name);
          setRiderPhone(c.account.phone);
        }
      })
      .catch((e) => {
        if (!controller.signal.aborted) setError(e.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setAuthPending(false);
      });
    return () => controller.abort();
  }, []);
  useEffect(() => {
    if (!config) return;
    let active = true,
      running = false;
    let timer: ReturnType<typeof setTimeout>;
    async function run() {
      if (!active || running) return;
      clearTimeout(timer);
      if (document.visibilityState === 'hidden') return;
      running = true;
      try {
        await refresh();
      } catch (e) {
        if (active) setSyncError((e as Error).message);
      } finally {
        running = false;
        if (active && !document.hidden) timer = setTimeout(run, 3000);
      }
    }
    const visibility = () => {
      if (document.visibilityState !== 'hidden') void run();
    };
    document.addEventListener('visibilitychange', visibility);
    void run();
    return () => {
      active = false;
      clearTimeout(timer);
      document.removeEventListener('visibilitychange', visibility);
    };
  }, [refresh, config]);
  const selected =
    bookings.find((b) => b.id === selectedId) ||
    bookings.find((b) => activeStatuses.includes(b.status)) ||
    null;
  const [nearbyResult, setNearbyResult] = useState<{
    key: string;
    drivers: { lat: number; lng: number }[];
  }>({ key: '', drivers: [] });
  const nearbyBooking = selected?.status === 'requesting' ? selected : null;
  const nearbyQuote =
    phase === 'select' && quote?.mode === 'now' ? quote : null;
  const nearbyBookingId = nearbyBooking?.id;
  const nearbyQuoteId = nearbyQuote?.id;
  const nearbyService = nearbyBooking?.service || service;
  const nearbyKey = `${nearbyBookingId || ''}:${nearbyQuoteId || ''}:${nearbyService}`;
  const nearby = nearbyResult.key === nearbyKey ? nearbyResult.drivers : [];
  useEffect(() => {
    if (!nearbyBookingId && !nearbyQuoteId) return;
    let active = true;
    let timer: ReturnType<typeof setTimeout>;
    const controller = new AbortController();
    async function run() {
      try {
        const result = await api<{ drivers: { lat: number; lng: number }[] }>(
          'nearby',
          {
            bookingId: nearbyBookingId,
            quoteId: nearbyQuoteId,
            service: nearbyService,
          },
          controller.signal,
        );
        if (active)
          setNearbyResult({ key: nearbyKey, drivers: result.drivers });
      } catch {
        if (active) setNearbyResult({ key: nearbyKey, drivers: [] });
      } finally {
        if (active) timer = setTimeout(run, 5000);
      }
    }
    void run();
    return () => {
      active = false;
      clearTimeout(timer);
      controller.abort();
    };
  }, [nearbyBookingId, nearbyQuoteId, nearbyService, nearbyKey]);
  const sharing = Boolean(
    sharingId &&
    sharingId === selected?.id &&
    selected &&
    ['accepted', 'arrived', 'riding'].includes(selected.status),
  );
  const trip =
    phase === 'trip' ||
    (phase === 'search' &&
      mode === 'now' &&
      selected &&
      activeStatuses.includes(selected.status));
  useEffect(
    () => () => {
      if (shareWatch.current !== null)
        navigator.geolocation.clearWatch(shareWatch.current);
    },
    [],
  );
  useEffect(() => {
    if (
      !selected ||
      !['accepted', 'arrived', 'riding'].includes(selected.status)
    ) {
      if (shareWatch.current !== null) {
        navigator.geolocation.clearWatch(shareWatch.current);
        shareWatch.current = null;
      }
    }
  }, [selected]);
  async function perform(work: () => Promise<void>) {
    if (busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setError('');
    try {
      await work();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }
  async function search() {
    await perform(async () => {
      if (!pickup || !destination)
        throw new Error(
          'Bitte Abholort und Ziel aus der Adresssuche auswählen.',
        );
      if (mode === 'reservation' && !scheduled)
        throw new Error('Bitte eine Abholzeit auswählen.');
      const q = await api<Quote>('quote', {
        pickupId: pickup.id,
        destinationId: destination.id,
        mode,
        scheduledAt:
          mode === 'reservation' ? new Date(scheduled).getTime() : null,
      });
      setQuote(q);
      setPhase('select');
    });
  }
  async function book() {
    if (!quote) return;
    await perform(async () => {
      const booking = await api<Booking>('bookings', {
        quoteId: quote.id,
        service,
        riderName,
        riderPhone,
        preferences,
        refreshments,
      });
      setRefreshments({});
      setSelectedId(booking.id);
      setPhase('trip');
      setCheckout(false);
      await refresh();
    });
  }
  async function cancel(b: Booking) {
    await perform(async () => {
      await api('bookings', { action: 'cancel', id: b.id });
      await refresh();
    });
  }
  function showBooking(b: Booking) {
    setSelectedId(b.id);
    setPhase('trip');
    setView('guest');
  }
  async function shareLocation() {
    if (!selected) return;
    if (sharing) {
      if (shareWatch.current !== null)
        navigator.geolocation.clearWatch(shareWatch.current);
      shareWatch.current = null;
      setSharingId(null);
      await perform(async () => {
        await api('bookings', { action: 'stop-sharing', id: selected.id });
      });
      return;
    }
    if (!navigator.geolocation) {
      setError('Standortfreigabe wird nicht unterstützt.');
      return;
    }
    const id = selected.id;
    let shareId: string;
    try {
      shareId = (
        await api<{ shareId: string }>('bookings', {
          action: 'start-sharing',
          id,
        })
      ).shareId;
    } catch (e) {
      setError((e as Error).message);
      return;
    }
    setSharingId(selected.id);
    shareWatch.current = navigator.geolocation.watchPosition(
      (p) => {
        if (Date.now() - shareLast.current < 5000) return;
        shareLast.current = Date.now();
        void api('bookings', {
          action: 'position',
          id,
          shareId,
          lat: p.coords.latitude,
          lng: p.coords.longitude,
        }).catch((e) => setError(e.message));
      },
      () => {
        setError('Der Standort konnte nicht freigegeben werden.');
        setSharingId(null);
        if (shareWatch.current !== null)
          navigator.geolocation.clearWatch(shareWatch.current);
      },
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 },
    );
  }
  const freshDriver =
    selected?.driver?.lat != null && selected?.driver?.lng != null
      ? selected.driver
      : null;
  const token = config?.publicMapToken || null;
  return (
    <div
      className={'app-shell' + (appMode ? ' app-native app-' + appMode : '')}
    >
      {appMode && (
        <AppMenu
          open={menuOpen}
          onOpenChange={setMenuOpen}
          driver={appMode === 'driver'}
          canDispatch={!!config?.canDispatch}
          onNavigate={(v) =>
            v === 'navigation-settings'
              ? setNavigationSettings(true)
              : setView(v)
          }
        />
      )}
      <NavigationSettings
        open={navigationSettings}
        onOpenChange={setNavigationSettings}
        mode={appMode === 'customer' ? 'customer' : 'driver'}
        ridePreferences={preferences}
        onRidePreferencesChange={setPreferences}
      />
      {appMode && (
        <AppHeader
          onMenu={() => setMenuOpen(true)}
          showBack={isSubPage || (appMode === 'customer' && phase === 'select')}
          onBack={navigateBack}
          variant={appMode}
          title={
            view === 'operations'
              ? 'Disposition'
              : view === 'services'
                ? 'Hilfe & Service'
                : view === 'reservations'
                  ? 'Meine Fahrten'
                  : undefined
          }
          subtitle={
            view === 'operations'
              ? 'Flotte & Vermittlung'
              : view === 'services'
                ? 'Chauffeur Concierge'
                : view === 'reservations'
                  ? 'Buchungsübersicht'
                  : undefined
          }
        />
      )}
      <BookingCheckout
        refreshments={refreshments}
        setRefreshments={setRefreshments}
        preferences={preferences}
        setPreferences={setPreferences}
        checkout={checkout}
        setCheckout={setCheckout}
        quote={quote}
        service={service}
        riderName={riderName}
        setRiderName={setRiderName}
        riderPhone={riderPhone}
        setRiderPhone={setRiderPhone}
        error={error}
        busy={busy}
        book={book}
      />

      <header className="masthead">
        <Link href="/" className="wordmark">
          <AppBrand variant={appMode === 'driver' ? 'driver' : 'customer'} />
        </Link>
        <a className="company" href="tel:+491605083829">
          <Phone size={16} />
          +49 160 5083829
        </a>
      </header>
      <div className="development">
        <span>LUXORÉ · BETRIEBSTEST</span>
        <p>
          Buchung und Fahrerzuweisung online · Fahrer-App während des Tests
          geöffnet lassen
        </p>
      </div>
      <SwipePages
        disabled={
          !appMode ||
          appMode === 'driver' ||
          menuOpen ||
          checkout ||
          navigationSettings ||
          !!trip
        }
        canPrevious={
          isSubPage || editingRoute || phase === 'select' || view !== 'guest'
        }
        canNext={
          !isSubPage &&
          !editingRoute &&
          phase !== 'select' &&
          view !== 'services'
        }
        className="customer-pages"
        onSwipe={(direction) => {
          if (isSubPage || editingRoute || phase === 'select') {
            if (direction === -1) navigateBack();
            return;
          }
          const pages = ['guest', 'reservations', 'services'];
          const i = pages.indexOf(view);
          if (i >= 0) setView(pages[Math.max(0, Math.min(2, i + direction))]);
        }}
      >
        <Tabs
          value={view}
          onValueChange={(v) => setView(String(v))}
          className="workspace"
        >
          <div className="workspace-nav">
            <TabsList variant="line">
              {appMode !== 'driver' && (
                <TabsTrigger value="guest">
                  <CarFront size={21} />
                  Fahren
                </TabsTrigger>
              )}
              {appMode !== 'driver' && (
                <TabsTrigger value="reservations">
                  <Clock3 size={21} />
                  Fahrten
                </TabsTrigger>
              )}
              {appMode !== 'customer' && (
                <TabsTrigger value="driver">Fahrer</TabsTrigger>
              )}
              {!appMode && config?.canDispatch && (
                <TabsTrigger value="operations">Disposition</TabsTrigger>
              )}
              {!appMode && (
                <TabsTrigger value="services">
                  <Phone size={21} />
                  Service
                </TabsTrigger>
              )}
            </TabsList>
            <span className="sync-state">
              {syncError
                ? 'Verbindung unterbrochen'
                : syncedAt
                  ? 'Aktualisiert ' +
                    new Date(syncedAt).toLocaleTimeString('de-DE')
                  : 'Verbindung wird aufgebaut'}
            </span>
          </div>
          {error && (
            <div className="notice error" role="alert">
              {error}
            </div>
          )}
          {syncError && (
            <div className="notice error" role="alert">
              {syncError} Angezeigte Positionen können veraltet sein.
            </div>
          )}
          {authPending ? (
            <AppLoading />
          ) : !config ? (
            <div className="login-panel">
              <h1>Willkommen bei LUXORÉ RIDE.</h1>
              <p>
                Die Verbindung konnte nicht hergestellt werden. Prüfe deine
                Internetverbindung und öffne die App erneut.
              </p>
              <Button onClick={() => window.location.reload()}>
                Erneut verbinden
              </Button>
            </div>
          ) : (
            <>
              <TabsContent value="guest">
                <div className="flow-heading">
                  <div>
                    <div className="eyebrow">
                      DEINE FAHRT. SCHRITT FÜR SCHRITT.
                    </div>
                    <h1>
                      {trip
                        ? 'Deine Fahrt.'
                        : phase === 'select'
                          ? 'Deine Klasse wählen.'
                          : 'Wohin geht es?'}
                    </h1>
                  </div>
                  <div className="flow-steps">
                    <span
                      className={!trip && phase === 'search' ? 'current' : ''}
                    >
                      1 Route
                    </span>
                    <span className={phase === 'select' ? 'current' : ''}>
                      2 Fahrzeug
                    </span>
                    <span className={trip ? 'current' : ''}>3 Fahrt</span>
                  </div>
                </div>
                {trip && selected ? (
                  <div className="live-layout">
                    <RidePanel
                      className="trip-panel"
                      title={statusNames[selected.status]}
                      subtitle={selected.route.destination.label}
                    >
                      <span className="status">
                        {statusNames[selected.status]}
                      </span>
                      <h2>
                        {selected.mode === 'reservation'
                          ? 'Deine Reservierung'
                          : 'Deine Sofortfahrt'}
                      </h2>
                      {selected.scheduled_at && (
                        <p>
                          <CalendarDays size={16} />
                          {new Date(selected.scheduled_at).toLocaleString(
                            'de-DE',
                          )}
                        </p>
                      )}
                      {selected.status === 'requesting' && (
                        <p>
                          Die Karte zeigt bis zu drei passende freie Fahrer mit
                          ungefähren Standorten. Wir fragen nacheinander freie
                          Fahrer deiner Klasse in der Nähe an. Falls nach drei
                          Minuten niemand annimmt, endet die Suche.
                        </p>
                      )}
                      {selected.status === 'reserved' && (
                        <p>
                          Vorgemerkt für deine Abholzeit. Die Fahrersuche
                          beginnt 15 Minuten vorher; eine Reservierung ist erst
                          mit Fahrerzuweisung bestätigt.
                        </p>
                      )}
                      {selected.status === 'unavailable' && (
                        <p>
                          Aktuell hat kein Fahrer angenommen. Du kannst eine
                          neue Anfrage starten oder LUXORÉ RIDE kontaktieren.
                        </p>
                      )}
                      <RouteSummary booking={selected} />
                      <div className="trip-price">
                        {money(selected.price)}
                        <span>
                          {className(selected.service)} ·{' '}
                          {(
                            selected.route.distanceMeters / 1000
                          ).toLocaleString('de-DE', {
                            maximumFractionDigits: 2,
                          })}{' '}
                          km
                        </span>
                      </div>
                      {selected.status === 'completed' &&
                        selected.completed_at && (
                          <div className="payment-status">
                            <strong>
                              {selected.payment_status === 'paid'
                                ? 'Zahlung bestätigt'
                                : 'Beim Fahrer zu zahlen'}
                              : {money(selected.price)}
                            </strong>
                            <p>
                              {selected.payment_status === 'paid'
                                ? selected.payment_method === 'cash'
                                  ? 'Barzahlung'
                                  : 'Zahlung am separaten Kartenterminal'
                                : 'Es wurde nichts automatisch abgebucht.'}
                            </p>
                          </div>
                        )}
                      {selected.driver && (
                        <div className="luxore-chauffeur-live-card">
                          <div className="chauffeur-card-eta">
                            <span className="live-pulse-dot" />
                            <strong>
                              {selected.status === 'accepted'
                                ? 'Chauffeur auf dem Weg · ca. 3–5 Min.'
                                : selected.status === 'arrived'
                                  ? 'Chauffeur ist am Abholort vorgefahren'
                                  : selected.status === 'riding'
                                    ? 'Fahrt zum Ziel läuft'
                                    : 'Chauffeur zugewiesen'}
                            </strong>
                          </div>
                          <div className="chauffeur-card-body">
                            <div className="chauffeur-avatar-monogram">
                              <span>
                                {selected.driver.name.slice(0, 1).toUpperCase()}
                              </span>
                            </div>
                            <div className="chauffeur-details">
                              <div className="chauffeur-name-row">
                                <strong>{selected.driver.name}</strong>
                                <span
                                  className="verified-badge"
                                  title="Geprüfter Chauffeur"
                                >
                                  <ShieldCheck size={14} /> Verifiziert
                                </span>
                              </div>
                              <div className="chauffeur-vehicle-identity">
                                <VehicleArtwork
                                  model={selected.driver.vehicle}
                                />
                                <span className="chauffeur-vehicle-model">
                                  {selected.driver.vehicle}
                                </span>
                              </div>
                              <div className="number-plate">
                                {selected.driver.plate}
                              </div>
                            </div>
                            {selected.driver.phone && (
                              <a
                                href={
                                  'tel:' +
                                  selected.driver.phone.replace(/[^+\d]/g, '')
                                }
                                className="chauffeur-call-btn"
                                aria-label="Chauffeur anrufen"
                              >
                                <Phone size={18} />
                              </a>
                            )}
                          </div>
                          {selected.rider_preferences && (
                            <RidePreferencesSummary
                              value={selected.rider_preferences}
                            />
                          )}
                        </div>
                      )}
                      {selected.driver &&
                        activeStatuses.includes(selected.status) && (
                          <p className="small-note">
                            {freshDriver
                              ? 'Fahrerstandort wird alle drei Sekunden abgerufen.'
                              : 'Kein aktuelles GPS-Signal. Die letzte Position wird nicht als live angezeigt.'}
                          </p>
                        )}
                      <BoardOrder booking={selected} refresh={refresh} />
                      <div className="trip-actions">
                        <Safety booking={selected} />
                        {['accepted', 'arrived', 'riding'].includes(
                          selected.status,
                        ) && (
                          <Button variant="outline" onClick={shareLocation}>
                            <LocateFixed />
                            {sharing
                              ? 'Standortfreigabe stoppen'
                              : 'Meinen Standort teilen'}
                          </Button>
                        )}
                        {[
                          'requesting',
                          'reserved',
                          'accepted',
                          'arrived',
                        ].includes(selected.status) && (
                          <Button
                            variant="ghost"
                            disabled={busy}
                            onClick={() => cancel(selected)}
                          >
                            Fahrt stornieren
                          </Button>
                        )}
                        {[
                          'completed',
                          'cancelled',
                          'unavailable',
                          'reserved',
                        ].includes(selected.status) && (
                          <Button
                            onClick={() => {
                              setPhase('search');
                              setSelectedId(null);
                              setQuote(null);
                            }}
                          >
                            Weitere Fahrt planen
                            <ArrowRight />
                          </Button>
                        )}
                      </div>
                    </RidePanel>
                    <RideMap
                      token={token}
                      route={selected.route}
                      driver={freshDriver}
                      nearby={selected.status === 'requesting' ? nearby : []}
                    />
                  </div>
                ) : phase === 'select' && quote ? (
                  <div className="live-layout">
                    <RidePanel
                      className="selection-panel"
                      title="Deine Fahrzeugklasse"
                      subtitle={quote.destination.label}
                    >
                      <div className="selection-header-bar">
                        <button
                          type="button"
                          className="selection-back-action"
                          onClick={() => {
                            setPhase('search');
                            setEditingRoute(true);
                            setQuote(null);
                          }}
                        >
                          <ArrowLeft size={15} strokeWidth={2.2} />
                          <span>Route anpassen</span>
                        </button>
                        <div className="selection-route-pill">
                          <span className="route-pill-time">
                            ca. {Math.ceil(quote.durationSeconds / 60)} Min.
                          </span>
                          <span className="route-pill-dot" />
                          <span className="route-pill-dist">
                            {(quote.distanceMeters / 1000).toLocaleString(
                              'de-DE',
                              {
                                maximumFractionDigits: 1,
                              },
                            )}{' '}
                            km
                          </span>
                        </div>
                      </div>

                      {quote.pickup?.label && quote.destination?.label && (
                        <div className="selection-route-preview">
                          <div className="route-preview-stop">
                            <span className="stop-marker pickup" />
                            <span className="stop-text">
                              {quote.pickup.label}
                            </span>
                          </div>
                          <div className="route-preview-line" />
                          <div className="route-preview-stop">
                            <span className="stop-marker destination" />
                            <span className="stop-text">
                              {quote.destination.label}
                            </span>
                          </div>
                        </div>
                      )}

                      <ClassPicker
                        prices={quote.prices}
                        service={service}
                        onChange={setService}
                        onContinue={() => setCheckout(true)}
                        disabled={busy || now > quote.expiresAt}
                      />
                      <div className="fare-validity-box">
                        <span className="fare-validity-text">
                          Verbindlicher Festpreis inklusive MwSt.,
                          Chauffeur-Empfang & 15 Min. Wartezeit.
                        </span>
                      </div>
                      {now > quote.expiresAt && (
                        <p className="field-error">
                          Angebot abgelaufen. Bitte Route erneut berechnen.
                        </p>
                      )}
                    </RidePanel>
                    <RideMap token={token} route={quote} nearby={nearby} />
                  </div>
                ) : appMode === 'customer' && !editingRoute ? (
                  <CustomerHome
                    showHeader={false}
                    bookings={bookings}
                    onStart={(m) => {
                      setMode(m);
                      setEditingRoute(true);
                    }}
                    onMenu={() => setMenuOpen(true)}
                    onRecent={(b) => {
                      setEditingRoute(true);
                      setDestination(b.route.destination);
                    }}
                  />
                ) : (
                  <div className="live-layout route-editor">
                    {appMode === 'customer' && (
                      <Button
                        className="route-back"
                        variant="outline"
                        size="icon"
                        aria-label="Zurück zum Start"
                        onClick={() => setEditingRoute(false)}
                      >
                        <ArrowLeft />
                      </Button>
                    )}
                    <RidePanel
                      className="search-panel"
                      staticPanel={appMode === 'customer'}
                      title="Deine Strecke"
                    >
                      <h2 className="app-search-title">Wohin möchtest du?</h2>
                      <p className="small-note">
                        Abholung und Ziel europaweit wählen. Sofortfahrten
                        benötigen einen verfügbaren Fahrer in deiner Nähe.
                        Reservierungen sind erst mit Fahrerzusage bestätigt.
                      </p>
                      <Tabs
                        value={mode}
                        onValueChange={(v) =>
                          setMode(v as 'now' | 'reservation')
                        }
                      >
                        <TabsList>
                          <TabsTrigger value="now">
                            <CarFront size={16} />
                            Jetzt fahren
                          </TabsTrigger>
                          <TabsTrigger value="reservation">
                            <CalendarDays size={16} />
                            Reservieren
                          </TabsTrigger>
                        </TabsList>
                      </Tabs>
                      <Address
                        label="Abholort"
                        value={pickup}
                        onChange={setPickup}
                        location
                        mapsReady={Boolean(config?.mapsReady)}
                      />
                      <PickupPicker
                        token={token}
                        value={pickup}
                        onChange={setPickup}
                      />
                      <Address
                        label="Ziel"
                        value={destination}
                        onChange={setDestination}
                        mapsReady={Boolean(config?.mapsReady)}
                      />
                      <PickupPicker
                        purpose="destination"
                        token={token}
                        value={destination}
                        onChange={setDestination}
                      />
                      {mode === 'reservation' && (
                        <label className="reserve-time" htmlFor="reserve-time">
                          Abholzeit
                          <Input
                            id="reserve-time"
                            type="datetime-local"
                            value={scheduled}
                            onChange={(e) => setScheduled(e.target.value)}
                          />
                          <span>
                            30 Minuten bis 90 Tage im Voraus · Ortszeit deines
                            Geräts
                          </span>
                        </label>
                      )}
                      <Button
                        className="primary-action"
                        disabled={
                          busy || !pickup || !destination || !config?.mapsReady
                        }
                        onClick={search}
                      >
                        {busy
                          ? 'Route wird berechnet …'
                          : 'Route & Preise anzeigen'}
                        <ArrowRight />
                      </Button>
                      {!!bookings.length && (
                        <div className="recent-destinations">
                          <h3>Letzte Ziele</h3>
                          {bookings
                            .filter(
                              (b, i, all) =>
                                all.findIndex(
                                  (other) =>
                                    other.route.destination.label ===
                                    b.route.destination.label,
                                ) === i,
                            )
                            .slice(0, 3)
                            .map((b) => (
                              <button
                                key={b.id}
                                disabled={busy}
                                onClick={() =>
                                  setDestination(b.route.destination)
                                }
                              >
                                <Clock3 size={18} />
                                <span>{b.route.destination.label}</span>
                              </button>
                            ))}
                        </div>
                      )}
                      <p className="small-note">
                        Business 2,50 €/km · First Class 3,50 €/km · Van 3,00
                        €/km. Mindestpreis 15 €.
                      </p>
                      {config && !config.mapsReady && (
                        <div className="setup-note">
                          <MapPin size={20} />
                          <div>
                            <strong>Kartenkonto noch nicht verbunden</strong>
                            <p>
                              Adressen können eingegeben werden. Adresssuche,
                              Routenberechnung und Buchung werden nach der
                              Kartenaktivierung verfügbar.
                            </p>
                          </div>
                        </div>
                      )}
                    </RidePanel>
                    {appMode !== 'customer' && (
                      <RideMap token={token} route={null} />
                    )}
                  </div>
                )}
                <section className="compact-history">
                  <h2>Letzte Fahrten</h2>
                  {bookings.filter((b) => b.mode === 'now').length ? (
                    bookings
                      .filter((b) => b.mode === 'now')
                      .map((b) => (
                        <BookingRow
                          key={b.id}
                          booking={b}
                          open={() => showBooking(b)}
                        />
                      ))
                  ) : (
                    <p className="small-note">
                      Noch keine Sofortfahrten angefragt.
                    </p>
                  )}
                </section>
              </TabsContent>
              <TabsContent value="reservations" className="activity-page">
                <div className="flow-heading">
                  <div>
                    <div className="eyebrow">VORAUSPLANEN</div>
                    <h1>
                      {appMode === 'customer'
                        ? 'Deine Fahrten.'
                        : 'Deine Reservierungen.'}
                    </h1>
                  </div>
                  <Button
                    onClick={() => {
                      setEditingRoute(true);
                      setMode('reservation');
                      setSelectedId(null);
                      setPhase('search');
                      setView('guest');
                    }}
                  >
                    <CalendarDays />
                    Neue Reservierung
                  </Button>
                </div>
                <p className="foreground-note">
                  Aktuelle Fahrten, geplante Abholungen und vergangene Fahrten
                  an einem Ort.
                </p>
                {bookings.filter(
                  (b) => appMode === 'customer' || b.mode === 'reservation',
                ).length ? (
                  bookings
                    .filter(
                      (b) => appMode === 'customer' || b.mode === 'reservation',
                    )
                    .map((b) => (
                      <BookingRow
                        key={b.id}
                        booking={b}
                        open={() => showBooking(b)}
                      />
                    ))
                ) : (
                  <div className="empty">
                    <CalendarDays />
                    <h2>
                      {appMode === 'customer'
                        ? 'Noch keine Fahrten'
                        : 'Noch keine Reservierung'}
                    </h2>
                    <p>Deine gebuchten Fahrten erscheinen hier.</p>
                  </div>
                )}
              </TabsContent>
              <TabsContent value="driver" keepMounted={appMode === 'driver'}>
                <DriverView
                  active={view === 'driver' && !menuOpen && !navigationSettings}
                  state={driverState}
                  token={token}
                  refresh={refresh}
                  onMenu={appMode ? () => setMenuOpen(true) : undefined}
                  onNavigate={(v) => setView(v)}
                />
              </TabsContent>
              {view === 'operations' && config && !config.canDispatch && (
                <div className="login-panel app-operations-locked">
                  <div className="locked-icon-badge">
                    <ShieldCheck size={36} strokeWidth={1.6} />
                  </div>
                  <h1>Disposition & Flotte</h1>
                  <p className="locked-lead">
                    Flottenverwaltung, Fahrerfreigaben und Echtzeit-Vermittlung
                    für autorisierte Flottenpartner in Frankfurt am Main.
                  </p>
                  <p className="locked-note">
                    Dein Gerät wird nach der Freigabe als Flottenleiter oder
                    Stellvertreter automatisch erkannt. Eine Anmeldung ist in
                    der App nicht nötig.
                  </p>
                  <div className="locked-actions">
                    <a className="locked-secondary-btn" href="/team">
                      Mitarbeiter- oder Fahrerprofil einreichen
                    </a>
                    {appMode && (
                      <button
                        type="button"
                        className="locked-back-btn"
                        onClick={() =>
                          setView(appMode === 'driver' ? 'driver' : 'guest')
                        }
                      >
                        Zurück zum{' '}
                        {appMode === 'driver'
                          ? 'Chauffeur-Cockpit'
                          : 'Buchungsbereich'}
                      </button>
                    )}
                  </div>
                </div>
              )}
              {config?.canDispatch && (
                <TabsContent value="operations" className="app-operations">
                  {appMode && (
                    <div className="app-section-header">
                      <h1>Disposition</h1>
                    </div>
                  )}
                  <div className="flow-heading">
                    <div>
                      <div className="eyebrow">LUXORÉ OPERATIONS</div>
                      <h1>Fahrer & Fahrten.</h1>
                    </div>
                    <Button variant="outline" onClick={() => perform(refresh)}>
                      <RefreshCw />
                      Aktualisieren
                    </Button>
                  </div>
                  <Fleets onChanged={refresh} />
                  {config.isAdmin && (
                    <>
                      <h2>Noch keiner Flotte zugeordnet</h2>
                      <p className="small-note">
                        Vor Freigabe Identität, Fahrerlaubnis, Fahrzeug und
                        betriebliche Nachweise außerhalb der App prüfen.
                      </p>
                      <div className="operator-drivers">
                        {operations?.drivers
                          .filter((d) => !d.fleet_id)
                          .map((d) => (
                            <article key={d.id}>
                              <CarFront />
                              <div>
                                <strong>{d.name}</strong>
                                <p>
                                  {d.vehicle} · {d.plate} ·{' '}
                                  {driverServices(d).map(className).join(' · ')}
                                </p>
                                <span>{d.phone}</span>
                              </div>
                              <Button
                                disabled={busy}
                                variant={d.approved ? 'outline' : 'default'}
                                onClick={() =>
                                  perform(async () => {
                                    await api('operations', {
                                      driverId: d.id,
                                      approved: !d.approved,
                                    });
                                    await refresh();
                                  })
                                }
                              >
                                {d.approved
                                  ? 'Freigabe zurücknehmen'
                                  : 'Fahrer freigeben'}
                              </Button>
                            </article>
                          ))}
                      </div>
                    </>
                  )}
                  <h2>Sofortfahrten</h2>
                  {operations?.bookings
                    .filter((b) => b.mode === 'now')
                    .map((b) => (
                      <div key={b.id} className="booking-row">
                        <span>
                          {b.route.pickup.label} → {b.route.destination.label}
                        </span>
                        <span className="status">{statusNames[b.status]}</span>
                        <RidePreferencesSummary value={b.rider_preferences} />
                        <AddressAttribution
                          points={[b.route.pickup, b.route.destination]}
                        />
                      </div>
                    ))}
                  <h2>Reservierungen</h2>
                  {operations?.bookings
                    .filter((b) => b.mode === 'reservation')
                    .map((b) => (
                      <div key={b.id} className="booking-row">
                        <span>
                          {b.scheduled_at &&
                            new Date(b.scheduled_at).toLocaleString(
                              'de-DE',
                            )}{' '}
                          · {b.route.pickup.label}
                        </span>
                        <span className="status">{statusNames[b.status]}</span>
                        <RidePreferencesSummary value={b.rider_preferences} />
                        <AddressAttribution
                          points={[b.route.pickup, b.route.destination]}
                        />
                      </div>
                    ))}
                </TabsContent>
              )}
              <TabsContent value="services" className="app-service-page">
                <Services compact={!!appMode} />
              </TabsContent>
            </>
          )}
        </Tabs>
      </SwipePages>
      <footer className="footer">
        <span>LUXORÉ RIDE</span>
        <span>Frankfurt am Main</span>
        <div className="footer-links">
          <a
            href="https://luxoreride.de/impressum.html"
            target="_blank"
            rel="noreferrer"
          >
            Impressum
          </a>
          <a
            href="https://luxoreride.de/datenschutz.html"
            target="_blank"
            rel="noreferrer"
          >
            Datenschutz
          </a>
          <span>Unternehmenstest · Online-Buchung</span>
        </div>
      </footer>
    </div>
  );
}
function RouteSummary({ booking }: { booking: Booking }) {
  return (
    <div className="trip-route">
      <div>
        <MapPin size={17} />
        <span>{booking.route.pickup.label}</span>
      </div>
      <div>
        <ArrowRight size={17} />
        <span>{booking.route.destination.label}</span>
      </div>
      <RidePreferencesSummary value={booking.rider_preferences} />
      <p>
        <Clock3 size={15} />
        Geschätzte Fahrtdauer: {Math.ceil(
          booking.route.durationSeconds / 60,
        )}{' '}
        Minuten
      </p>
    </div>
  );
}
function BookingRow({
  booking: b,
  open,
}: {
  booking: Booking;
  open: () => void;
}) {
  return (
    <button className="booking-row" onClick={open}>
      <div>
        <strong>{b.route.destination.label}</strong>
        <span>
          Ab {b.route.pickup.label}
          {b.scheduled_at
            ? ' · ' + new Date(b.scheduled_at).toLocaleString('de-DE')
            : ''}
        </span>
      </div>
      <span className="status">{statusNames[b.status]}</span>
      <b>{money(b.price)}</b>
      <ArrowRight size={18} />
    </button>
  );
}
