import type { GpsFix } from './gps-quality.ts';
import {
  currentGuidance,
  guidanceDue,
  type Guidance,
} from './guidance-policy.ts';
import { observeRouteRecovery, type RouteRecovery } from './route-recovery.ts';

type RequestGuidance = (
  bookingId: string,
  position: GpsFix,
  signal: AbortSignal,
) => Promise<Guidance>;
type Request = { controller: AbortController; startedAt: number };
type Snapshot = {
  value: Guidance | null;
  recovery: RouteRecovery | null;
  failed: boolean;
  pendingSince: number | null;
};
const empty: Snapshot = {
  value: null,
  recovery: null,
  failed: false,
  pendingSince: null,
};

// One trip phase owns its route and request cadence across temporary menu/background pauses.
export class TrafficGuidanceSession {
  private state: Snapshot = empty;
  private listeners = new Set<() => void>();
  private request: Request | null = null;
  private lastAttempt: number | null = null;
  private retry = false;
  private active = false;
  private bookingId: string;
  private phase: string;
  private fetchGuidance: RequestGuidance;
  private clock: () => number;

  constructor(
    bookingId: string,
    phase: string,
    fetchGuidance: RequestGuidance,
    clock: () => number = Date.now,
  ) {
    this.bookingId = bookingId;
    this.phase = phase;
    this.fetchGuidance = fetchGuidance;
    this.clock = clock;
  }
  getSnapshot = () => this.state;
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  private publish(changes: Partial<Snapshot>) {
    this.state = { ...this.state, ...changes };
    for (const listener of this.listeners) listener();
  }
  resume() {
    this.active = true;
  }
  pause() {
    this.active = false;
    this.cancelRequest();
  }
  private cancelRequest() {
    const request = this.request;
    if (!request) return;
    this.request = null;
    this.retry = true;
    request.controller.abort();
    this.publish({ pendingSince: null });
  }
  update(fix: GpsFix | null, online: boolean, visible: boolean) {
    if (!this.active) return;
    const now = this.clock();
    if (
      !online ||
      !visible ||
      (this.request && now - this.request.startedAt >= 15000)
    )
      this.cancelRequest();
    if (!visible) return;
    const route = currentGuidance(
      this.state.value,
      this.bookingId,
      this.phase,
      now,
    );
    const recovery = observeRouteRecovery(this.state.recovery, route, fix, now);
    if (recovery !== this.state.recovery) this.publish({ recovery });
    if (
      !online ||
      this.request ||
      !guidanceDue(fix, route, this.lastAttempt, now, recovery, this.retry)
    )
      return;
    // guidanceDue validates the fix, including its age and accuracy.
    const request = { controller: new AbortController(), startedAt: now };
    this.request = request;
    this.lastAttempt = now;
    this.retry = false;
    this.publish({ pendingSince: now });
    void this.fetchGuidance(this.bookingId, fix!, request.controller.signal)
      .then((reply) => {
        // Aborted requests may still resolve, including after a newer request has started.
        if (!this.active || this.request !== request) return;
        const receivedAt = this.clock();
        if (
          receivedAt - request.startedAt >= 15000 ||
          !currentGuidance(reply, this.bookingId, this.phase, receivedAt)
        ) {
          this.retry = true;
          this.publish({ failed: true });
          return;
        }
        this.publish({ value: reply, recovery: null, failed: false });
      })
      .catch(() => {
        if (!this.active || this.request !== request) return;
        this.retry = true;
        this.publish({ failed: true });
      })
      .finally(() => {
        if (this.request !== request) return;
        this.request = null;
        this.publish({ pendingSince: null });
      });
  }
}
