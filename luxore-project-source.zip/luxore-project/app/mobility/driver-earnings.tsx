'use client';
import { useCallback, useEffect, useState } from 'react';
import { api } from './api';
import { money } from '@/lib/ride-domain';
import type { EarningsTotals } from '@/lib/mobility/settlement';

type Period = 'today' | 'week' | 'month';
type State = {
  periods: Record<Period, EarningsTotals>;
  since: Record<Period, number>;
  rides: {
    id: string;
    completedAt: number;
    service: string;
    from: string;
    to: string;
    price: number;
    extras: number;
    method: 'cash' | 'terminal' | null;
  }[];
};
const LABELS: Record<Period, string> = {
  today: 'Heute',
  week: 'Diese Woche',
  month: 'Dieser Monat',
};
/** "Meine Einnahmen": the driver's own trips, cash and terminal apart. */
export default function DriverEarnings() {
  const [open, setOpen] = useState(false),
    [data, setData] = useState<State | null>(null),
    [error, setError] = useState(''),
    [period, setPeriod] = useState<Period>('today');
  const load = useCallback(async () => {
    try {
      setData(await api<State>('earnings'));
      setError('');
    } catch (e) {
      setError((e as Error).message);
    }
  }, []);
  useEffect(() => {
    if (open) void load();
  }, [open, load]);
  if (!open)
    return (
      <div className="pf">
        <button type="button" className="pf-btn wide" onClick={() => setOpen(true)}>
          Meine Einnahmen – heute, Woche, Monat
        </button>
      </div>
    );
  if (!data)
    return (
      <div className="pf">
        <p className="pf-muted">{error || 'Einnahmen werden geladen …'}</p>
      </div>
    );
  const t = data.periods[period],
    rides = data.rides.filter((r) => r.completedAt >= data.since[period]);
  return (
    <div className="pf">
      <div className="pf-row">
        <h3>Meine Einnahmen</h3>
        <button type="button" className="pf-btn" onClick={() => setOpen(false)}>
          Schließen
        </button>
      </div>
      <div className="pf-segment" role="group" aria-label="Zeitraum">
        {(Object.keys(LABELS) as Period[]).map((p) => (
          <button
            type="button"
            key={p}
            aria-pressed={period === p}
            onClick={() => setPeriod(p)}
          >
            {LABELS[p]}
          </button>
        ))}
      </div>
      <div className="pf-stats">
        <div className="pf-stat dark">
          <small>
            {LABELS[period]} · {t.trips} {t.trips === 1 ? 'Fahrt' : 'Fahrten'}
          </small>
          <strong>{money(t.total)}</strong>
        </div>
        <div className="pf-stat">
          <small>Bar kassiert</small>
          <strong>{money(t.cash)}</strong>
        </div>
        <div className="pf-stat">
          <small>Über Terminal kassiert</small>
          <strong>{money(t.terminal)}</strong>
        </div>
        {t.open > 0 && (
          <div className="pf-stat">
            <small>Noch nicht kassiert</small>
            <strong>{money(t.open)}</strong>
          </div>
        )}
      </div>
      <p className="pf-muted">
        Von dir kassierte Beträge deiner eigenen Fahrten (Woche ab Montag,
        deutscher Zeit). Dein Lohn oder Anteil wird hier nicht berechnet – das
        regelt deine Flotte.
      </p>
      <div>
        {rides.map((r) => (
          <div className="pf-trip" key={r.id}>
            <span>
              {r.from} → {r.to}
            </span>
            <b>{money(r.price)}</b>
            <small>
              {new Date(r.completedAt).toLocaleString('de-DE', {
                timeZone: 'Europe/Berlin',
                weekday: 'short',
                day: '2-digit',
                month: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
              })}{' '}
              ·{' '}
              {r.method === 'cash'
                ? 'Bar'
                : r.method === 'terminal'
                  ? 'Terminal'
                  : 'noch offen'}
              {r.extras ? ` · davon Bordprodukte ${money(r.extras)}` : ''}
            </small>
          </div>
        ))}
        {!rides.length && (
          <p className="pf-muted">Keine abgeschlossenen Fahrten in diesem Zeitraum.</p>
        )}
      </div>
    </div>
  );
}
