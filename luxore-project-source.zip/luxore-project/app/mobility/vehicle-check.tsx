'use client';
import { useCallback, useEffect, useState } from 'react';
import { api } from './api';
import { photoUrl, uploadPhoto } from './photo';
import type { InspectionState } from '@/lib/mobility/compliance';

type Item = { ok: boolean; note: string };
type Inspection = {
  id: string;
  inspectorName: string;
  result: 'ok' | 'defect';
  items: Record<string, Item>;
  odometer: number | null;
  createdAt: number;
  images: { id: string; slot: string }[];
};
type State = {
  vehicle: { id: string; model: string; plate: string };
  state: InspectionState;
  items: Record<string, string>;
  slots: Record<string, string>;
  inspections: Inspection[];
};
const when = (at: number) =>
  new Date(at).toLocaleString('de-DE', {
    timeZone: 'Europe/Berlin',
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
export function inspectionChip(s: InspectionState) {
  if (s.state === 'never') return { tone: 'danger', text: 'Kontrolle fehlt' };
  if (s.state === 'due') return { tone: 'danger', text: 'Kontrolle fällig' };
  return s.daysLeft !== null && s.daysLeft < 3
    ? {
        tone: 'warn',
        text:
          s.daysLeft === 0
            ? 'Kontrolle heute fällig'
            : `Kontrolle in ${s.daysLeft} ${s.daysLeft === 1 ? 'Tag' : 'Tagen'} fällig`,
      }
    : { tone: 'good', text: 'Kontrolle gültig' };
}
/** Weekly vehicle check: simple list, photos of four sides and interior, history. */
export default function VehicleCheck({
  vehicleId,
  onChanged,
}: {
  vehicleId: string;
  onChanged?: () => void;
}) {
  const [data, setData] = useState<State | null>(null),
    [error, setError] = useState(''),
    [saved, setSaved] = useState(''),
    [busy, setBusy] = useState(false),
    [open, setOpen] = useState(false),
    [items, setItems] = useState<Record<string, Item | undefined>>({}),
    [photos, setPhotos] = useState<
      Record<string, { file: File; url: string } | undefined>
    >({}),
    [odometer, setOdometer] = useState('');
  const load = useCallback(async () => {
    try {
      setData(
        await api<State>('inspections?vehicleId=' + encodeURIComponent(vehicleId)),
      );
    } catch (e) {
      setError((e as Error).message);
    }
  }, [vehicleId]);
  useEffect(() => {
    void load();
  }, [load]);
  async function submit() {
    if (!data || busy) return;
    const missing = Object.keys(data.items).find((k) => !items[k]);
    if (missing)
      return setError(`Bitte „${data.items[missing]}“ als in Ordnung oder Mangel markieren.`);
    setBusy(true);
    setError('');
    try {
      const created = await api<{ id: string; result: string }>('inspections', {
        action: 'create',
        vehicleId,
        items,
        odometer: odometer ? Number(odometer) : undefined,
      });
      let failed = 0;
      for (const [slot, photo] of Object.entries(photos))
        if (photo)
          await uploadPhoto('inspection', created.id, photo.file, slot).catch(
            () => failed++,
          );
      Object.values(photos).forEach((p) => p && URL.revokeObjectURL(p.url));
      setOpen(false);
      setItems({});
      setPhotos({});
      setOdometer('');
      setSaved(
        (created.result === 'ok'
          ? 'Kontrolle ohne Mangel gespeichert.'
          : 'Kontrolle mit Mangel gespeichert. Flottenleitung und Betreiber sehen den Mangel.') +
          (failed ? ` ${failed} Foto(s) konnten nicht gespeichert werden.` : ''),
      );
      await load();
      onChanged?.();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  if (!data)
    return <p className="pf-muted">{error || 'Kontrolle wird geladen …'}</p>;
  const chip = inspectionChip(data.state);
  const defects = Object.values(items).filter((i) => i && !i.ok).length;
  return (
    <div className="pf">
      <div className="pf-row">
        <div>
          <strong>Wochenkontrolle · {data.vehicle.plate}</strong>
          <p className="pf-muted">
            {data.state.lastPassedAt
              ? 'Zuletzt ohne Mangel: ' + when(data.state.lastPassedAt) + '.'
              : 'Noch keine Kontrolle ohne Mangel.'}{' '}
            Alle 7 Tage fällig.
          </p>
        </div>
        <span className={'pf-chip ' + chip.tone}>{chip.text}</span>
      </div>
      {data.state.latestResult === 'defect' && (
        <p className="pf-notice danger">
          Die letzte Kontrolle ({when(data.state.latestAt!)}) hat einen Mangel
          gemeldet.
        </p>
      )}
      {error && (
        <p className="pf-error" role="alert">
          {error}
        </p>
      )}
      {saved && <output className="pf-saved">{saved}</output>}
      {!open ? (
        <button
          type="button"
          className="pf-btn primary wide"
          onClick={() => {
            setOpen(true);
            setSaved('');
            setError('');
          }}
        >
          Kontrolle jetzt durchführen
        </button>
      ) : (
        <div className="pf-card">
          <div>
            {Object.entries(data.items).map(([key, label]) => {
              const value = items[key];
              return (
                <div className="pf-toggle" key={key}>
                  <span>{label}</span>
                  <div role="group" aria-label={label}>
                    <button
                      type="button"
                      data-tone="good"
                      aria-pressed={value?.ok === true}
                      onClick={() =>
                        setItems((v) => ({ ...v, [key]: { ok: true, note: '' } }))
                      }
                    >
                      In Ordnung
                    </button>
                    <button
                      type="button"
                      data-tone="bad"
                      aria-pressed={value?.ok === false}
                      onClick={() =>
                        setItems((v) => ({
                          ...v,
                          [key]: { ok: false, note: v[key]?.note || '' },
                        }))
                      }
                    >
                      Mangel
                    </button>
                  </div>
                  {value?.ok === false && (
                    <label className="pf-field">
                      Was ist der Mangel?
                      <input
                        value={value.note}
                        maxLength={200}
                        placeholder="z. B. Kratzer an der Tür hinten links"
                        onChange={(e) =>
                          setItems((v) => ({
                            ...v,
                            [key]: { ok: false, note: e.target.value },
                          }))
                        }
                      />
                    </label>
                  )}
                </div>
              );
            })}
          </div>
          <div>
            <strong>Fotos</strong>
            <p className="pf-muted">
              Vier Seiten und Innenraum. Tippe auf ein Feld, um ein Foto aufzunehmen oder aus der Galerie zu wählen.
            </p>
          </div>
          <div className="pf-photos">
            {Object.entries(data.slots).map(([slot, label]) => (
              <label className={'pf-photo' + (photos[slot] ? ' done' : '')} key={slot}>
                {photos[slot] && <img src={photos[slot]!.url} alt="" />}
                <span>{label}</span>
                <input
                  type="file"
                  accept="image/*"
                  aria-label={'Foto ' + label}
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    setPhotos((v) => {
                      if (v[slot]) URL.revokeObjectURL(v[slot]!.url);
                      return {
                        ...v,
                        [slot]: file
                          ? { file, url: URL.createObjectURL(file) }
                          : undefined,
                      };
                    });
                  }}
                />
              </label>
            ))}
          </div>
          <label className="pf-field">
            Kilometerstand (freiwillig)
            <input
              inputMode="numeric"
              value={odometer}
              onChange={(e) => setOdometer(e.target.value.replace(/\D/g, '').slice(0, 7))}
            />
          </label>
          <div className="pf-actions">
            <button
              type="button"
              className="pf-btn"
              disabled={busy}
              onClick={() => setOpen(false)}
            >
              Abbrechen
            </button>
            <button
              type="button"
              className="pf-btn primary"
              disabled={busy}
              onClick={() => void submit()}
            >
              {busy
                ? 'Wird gespeichert …'
                : defects
                  ? `Mit ${defects} ${defects === 1 ? 'Mangel' : 'Mängeln'} abschließen`
                  : 'Kontrolle abschließen'}
            </button>
          </div>
        </div>
      )}
      {!!data.inspections.length && (
        <details>
          <summary>
            <span>Verlauf ({data.inspections.length})</span>
          </summary>
          <div className="pf-details-body">
            {data.inspections.map((i) => (
              <div className="pf-card" key={i.id}>
                <div className="pf-row">
                  <span>
                    {when(i.createdAt)} · {i.inspectorName}
                    {i.odometer !== null ? ` · ${i.odometer.toLocaleString('de-DE')} km` : ''}
                  </span>
                  <span className={'pf-chip ' + (i.result === 'ok' ? 'good' : 'danger')}>
                    {i.result === 'ok' ? 'ohne Mangel' : 'mit Mangel'}
                  </span>
                </div>
                {Object.entries(i.items)
                  .filter(([, v]) => !v.ok)
                  .map(([key, v]) => (
                    <p className="pf-notice danger" key={key}>
                      {data.items[key] || key}: {v.note}
                    </p>
                  ))}
                {!!i.images.length && (
                  <div className="pf-thumbs">
                    {i.images.map((image) => (
                      <a
                        key={image.id}
                        href={photoUrl(image.id)}
                        target="_blank"
                        rel="noreferrer"
                        aria-label={'Foto ' + (data.slots[image.slot] || '') + ' öffnen'}
                      >
                        <img src={photoUrl(image.id)} alt="" loading="lazy" />
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </details>
      )}
    </div>
  );
}
