'use client';
import { Check, Banknote, CreditCard, ReceiptText } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
} from '@/components/ui/alert-dialog';
import type { Booking } from '@/lib/mobility/domain';
import { money } from '@/lib/ride-domain';
import { api } from './api';
import { cartLabel, countCart } from '@/lib/mobility/refreshments';
import { useBackLayer } from './use-back-layer';

export default function Payment({
  booking,
  refresh,
  preview = false,
}: {
  preview?: boolean;
  booking: Booking;
  refresh: () => Promise<void>;
}) {
  const [method, setMethod] = useState<'cash' | 'terminal'>('cash');
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useBackLayer(
    confirm,
    () => {
      if (!busy) setConfirm(false);
    },
    80,
  );

  const totalAmount = booking.price;

  async function collect() {
    if (preview) {
      setConfirm(false);
      setError('Beispielansicht. Es wurde keine Zahlung gespeichert.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      await api('payments', { id: booking.id, method });
      setConfirm(false);
      await refresh();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="collection-panel">
      <div className="collection-check">
        <Check size={25} />
      </div>
      <div className="eyebrow">FAHRT ERFOLGREICH ABGESCHLOSSEN</div>
      <h2>Jetzt kassieren</h2>

      <div className="collection-receipt-card">
        <div className="receipt-route">
          <strong>{booking.route.destination.label}</strong>
          <small>Von {booking.route.pickup.label}</small>
        </div>

        {!!countCart(booking.refreshments?.delivered || {}) && (
          <p className="board-note">
            An Bord erhalten: {cartLabel(booking.refreshments!.delivered)}
          </p>
        )}
        <div className="receipt-breakdown">
          <div className="breakdown-row">
            <span>Fahrpreis</span>
            <strong>{money(booking.fare_price ?? booking.price)}</strong>
          </div>
          {booking.fare_price != null && booking.price > booking.fare_price && (
            <div className="breakdown-row">
              <span>Snacks & Getränke · übergeben</span>
              <strong>{money(booking.price - booking.fare_price)}</strong>
            </div>
          )}
          <div className="breakdown-total">
            <span>Zu kassieren</span>
            <strong>{money(totalAmount)}</strong>
          </div>
        </div>
      </div>

      <div className="collection-method-wrap">
        <span className="method-label">Zahlungsweg beim Fahrgast:</span>
        <RadioGroup
          value={method}
          onValueChange={(v) => setMethod(v as 'cash' | 'terminal')}
          className="payment-method-radios"
        >
          <label
            className={
              'class-check ' + (method === 'cash' ? 'is-selected' : '')
            }
            htmlFor="collect-cash"
          >
            <RadioGroupItem id="collect-cash" value="cash" />
            <Banknote size={21} />
            <span>Barzahlung</span>
          </label>
          <label
            className={
              'class-check ' + (method === 'terminal' ? 'is-selected' : '')
            }
            htmlFor="collect-terminal"
          >
            <RadioGroupItem id="collect-terminal" value="terminal" />
            <CreditCard size={21} />
            <span>Kartenterminal</span>
          </label>
        </RadioGroup>
      </div>

      <Button className="primary-action" onClick={() => setConfirm(true)}>
        <ReceiptText size={18} />
        Zahlung von {money(totalAmount)} bestätigen
      </Button>

      <p className="small-note">
        Erst bestätigen, wenn der Betrag vollständig übergeben oder vom Terminal
        autorisiert wurde.
      </p>

      {error && (
        <p role="alert" className="field-error">
          {error}
        </p>
      )}

      <AlertDialog
        open={confirm}
        onOpenChange={(value) => {
          if (!busy) setConfirm(value);
        }}
      >
        <AlertDialogContent className="app-payment-dialog">
          <AlertDialogHeader>
            <AlertDialogTitle>{money(totalAmount)} erhalten?</AlertDialogTitle>
            <AlertDialogDescription>
              {method === 'cash'
                ? `Bestätige den erhaltenen Barbetrag in Höhe von ${money(totalAmount)}.`
                : `Bestätige die erfolgreiche Zahlung von ${money(totalAmount)} am separaten Kartenterminal. Es erfolgt keine automatische Kartenabbuchung über diese Schaltfläche.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Noch nicht</AlertDialogCancel>
            <Button disabled={busy} onClick={() => void collect()}>
              Ja, vollständig erhalten
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
