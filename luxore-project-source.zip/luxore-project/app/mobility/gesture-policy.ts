export type Axis = 'pending' | 'horizontal' | 'vertical';
export function gestureAxis(
  dx: number,
  dy: number,
  previous: Axis = 'pending',
): Axis {
  if (previous !== 'pending') return previous;
  if (Math.max(Math.abs(dx), Math.abs(dy)) < 10) return 'pending';
  if (Math.abs(dx) > Math.abs(dy) * 1.35) return 'horizontal';
  if (Math.abs(dy) > Math.abs(dx) * 1.35) return 'vertical';
  return 'pending';
}
export function swipeDirection(
  dx: number,
  dy: number,
  elapsed: number,
  axis: Axis,
): 1 | -1 | null {
  if (
    axis !== 'horizontal' ||
    elapsed > 1200 ||
    Math.abs(dx) < 72 ||
    Math.abs(dx) < Math.abs(dy) * 1.5
  )
    return null;
  return dx < 0 ? 1 : -1;
}
export function dismissDistance(distance: number, elapsed: number) {
  return distance >= 96 || (distance >= 48 && elapsed > 0 && elapsed < 220);
}
export const gestureControls =
  'button,a,input,textarea,select,label,summary,[role="slider"],[role="switch"],[role="radio"],[role="combobox"],[contenteditable="true"],[data-no-swipe],.mapboxgl-map,.live-map,.pickup-map,.table-scroll';
