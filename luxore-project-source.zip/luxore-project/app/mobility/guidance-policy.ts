import type { RouteData } from '../../lib/mobility/domain';
import { usableFix, type GpsFix } from './gps-quality.ts';
import { confirmedRecovery, type RouteRecovery } from './route-recovery.ts';
export type Guidance = { bookingId: string; phase: string; route: RouteData };
export function currentGuidance(
  value: Guidance | null,
  bookingId: string | undefined,
  phase: string | undefined,
  now: number,
) {
  return value &&
    value.bookingId === bookingId &&
    value.phase === phase &&
    now >= value.route.calculatedAt &&
    now - value.route.calculatedAt <= 90000
    ? value.route
    : null;
}
export function guidanceDue(
  fix: GpsFix | null,
  route: RouteData | null,
  lastAttempt: number | null,
  now: number,
  recovery: RouteRecovery | null = null,
  retry = false,
) {
  if (!usableFix(fix, now) || fix.accuracy > 50) return false;
  if (lastAttempt === null) return true;
  const elapsed = now - lastAttempt;
  if (elapsed < 15000) return false;
  if (retry) return true;
  if (elapsed >= 45000) return true;
  if (!route) return false;
  return confirmedRecovery(recovery, route, now) !== null;
}
