'use client';
import { useId, useLayoutEffect, useRef } from 'react';
import { BackLayers, BackNavigation } from './back-stack';
const layers = new BackLayers();
const guard = 'luxore-app-back-v2';
let navigation: BackNavigation | undefined;
let timer: ReturnType<typeof setTimeout> | undefined;
function schedule() {
  clearTimeout(timer);
  timer = setTimeout(() => navigation?.sync(), 0);
}
function attach() {
  if (navigation) return;
  navigation = new BackNavigation(layers, {
    hasGuard: () => !!window.history.state?.[guard],
    pushGuard: () =>
      window.history.pushState({ ...window.history.state, [guard]: true }, ''),
    back: () => window.history.back(),
  });
  window.addEventListener('popstate', (event) => {
    navigation!.pop(!!event.state?.[guard]);
    schedule();
  });
}
export function useBackLayer(
  active: boolean,
  onBack: () => void,
  priority = 20,
) {
  const id = useId(),
    callback = useRef(onBack);
  useLayoutEffect(() => {
    callback.current = onBack;
  });
  useLayoutEffect(() => {
    if (!active) return;
    attach();
    layers.set({ id, priority, back: () => callback.current() });
    schedule();
    return () => {
      layers.remove(id);
      schedule();
    };
  }, [active, id, priority]);
}
