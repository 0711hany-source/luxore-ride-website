export type GpsFix = {
  heading?: number;
  speed?: number;
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
};
export function distanceMeters(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
) {
  const rad = Math.PI / 180;
  const x =
    Math.sin(((b.lat - a.lat) * rad) / 2) ** 2 +
    Math.cos(a.lat * rad) *
      Math.cos(b.lat * rad) *
      Math.sin(((b.lng - a.lng) * rad) / 2) ** 2;
  return 12742000 * Math.asin(Math.sqrt(Math.min(1, x)));
}
export function usableFix(p: GpsFix | null, now: number): p is GpsFix {
  return (
    !!p &&
    [p.lat, p.lng, p.accuracy, p.timestamp].every(Number.isFinite) &&
    Math.abs(p.lat) <= 90 &&
    Math.abs(p.lng) <= 180 &&
    p.accuracy >= 0 &&
    p.accuracy <= 100 &&
    now - p.timestamp <= 30000 &&
    p.timestamp <= now + 5000
  );
}
// Keep raw measurements for dispatch; only reject stale, inaccurate or implausible samples.
export function acceptFix(previous: GpsFix | null, next: GpsFix, now: number) {
  if (
    !usableFix(next, now) ||
    (previous && next.timestamp <= previous.timestamp)
  )
    return false;
  if (!previous || next.timestamp - previous.timestamp > 30000) return true;
  return (
    distanceMeters(previous, next) <=
    (70 * (next.timestamp - previous.timestamp)) / 1000 +
      previous.accuracy +
      next.accuracy
  );
}
// A small accuracy-aware dead band is only for the displayed marker, never server coordinates.
export function displayMoved(
  previous: { lat: number; lng: number } | null,
  next: { lat: number; lng: number },
  accuracy = 10,
) {
  return (
    !previous ||
    distanceMeters(previous, next) >= Math.max(3, Math.min(12, accuracy / 2))
  );
}
