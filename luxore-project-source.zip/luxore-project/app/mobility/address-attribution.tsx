import type { Point } from '@/lib/mobility/domain';
export default function AddressAttribution({
  points,
}: {
  points: (Point | null | undefined)[];
}) {
  const credits = [
    ...new Set(
      points.map((p) => p?.attribution).filter((s): s is string => Boolean(s)),
    ),
  ];
  if (!credits.length) return null;
  return (
    <small className="address-attribution">
      <a
        href="https://www.geoapify.com/"
        target="_blank"
        rel="noopener noreferrer"
      >
        Powered by Geoapify
      </a>
      {' · '}
      <a
        href="https://www.openstreetmap.org/copyright"
        target="_blank"
        rel="noopener noreferrer"
      >
        © OpenStreetMap contributors
      </a>
      {credits
        .filter(
          (s) =>
            !/^Powered by Geoapify · © OpenStreetMap contributors\.?$/.test(s),
        )
        .map((s) => (
          <span key={s}> · {s.replace(/^Powered by Geoapify · /, '')}</span>
        ))}
    </small>
  );
}
