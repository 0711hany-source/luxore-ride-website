'use client';
import { useEffect, useState } from 'react';
import { Info } from 'lucide-react';
import type { Point } from '@/lib/mobility/domain';

/** OpenStreetMap's guideline: the credit may collapse after five seconds. */
const VISIBLE_MS = 5000;
/**
 * Data sources of the shown addresses. The line is shown in full first and
 * then folds into a small info button in the same place; a tap opens it
 * again. It is never removed: Geoapify (free plan) and OpenStreetMap require
 * the credit near the information.
 */
export default function AddressAttribution({
  points,
}: {
  points: (Point | null | undefined)[];
}) {
  const credits = [
    ...new Set(
      points.map((p) => p?.attribution).filter((s): s is string => Boolean(s)),
    ),
  ];
  const shown = credits.length > 0;
  const [open, setOpen] = useState(true);
  useEffect(() => {
    if (!shown || !open) return;
    const timer = setTimeout(() => setOpen(false), VISIBLE_MS);
    return () => clearTimeout(timer);
  }, [shown, open]);
  if (!shown) return null;
  if (!open)
    return (
      <button
        type="button"
        className="address-attribution-toggle"
        aria-label="Datenquellen der Adressen anzeigen"
        aria-expanded={false}
        onClick={() => setOpen(true)}
      >
        <Info size={13} aria-hidden="true" />
      </button>
    );
  return (
    <small className="address-attribution">
      <a
        href="https://www.geoapify.com/"
        target="_blank"
        rel="noopener noreferrer"
      >
        Powered by Geoapify
      </a>
      {' · '}
      <a
        href="https://www.openstreetmap.org/copyright"
        target="_blank"
        rel="noopener noreferrer"
      >
        © OpenStreetMap contributors
      </a>
      {credits
        .filter(
          (s) =>
            !/^Powered by Geoapify · © OpenStreetMap contributors\.?$/.test(s),
        )
        .map((s) => (
          <span key={s}> · {s.replace(/^Powered by Geoapify · /, '')}</span>
        ))}
    </small>
  );
}
