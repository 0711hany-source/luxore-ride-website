export class MobilityApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'MobilityApiError';
    this.status = status;
  }
}
export async function api<T>(
  path: string,
  body?: unknown,
  signal?: AbortSignal,
): Promise<T> {
  const controller = new AbortController();
  let timedOut = false;
  const cancel = () => controller.abort(signal?.reason);
  if (signal?.aborted) cancel();
  else signal?.addEventListener('abort', cancel, { once: true });
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, 15000);
  try {
    const response = await fetch('/api/mobility/' + path, {
      method: body === undefined ? 'GET' : 'POST',
      headers:
        body === undefined ? undefined : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: controller.signal,
    });
    const value = (await response.json().catch(() => {
      throw new Error(
        'Der Server ist gerade nicht erreichbar. Bitte erneut versuchen.',
      );
    })) as T & { error?: string };
    if (!response.ok)
      throw new MobilityApiError(
        value?.error ||
          'Die Verbindung ist unterbrochen. Bitte erneut versuchen.',
        response.status,
      );
    return value;
  } catch (error) {
    if (timedOut)
      throw new Error(
        'Die Verbindung dauert zu lange. Bitte Internetverbindung prüfen und erneut versuchen.',
      );
    if (signal?.aborted) throw error;
    if (error instanceof TypeError)
      throw new Error(
        'Keine Verbindung zum Fahrdienst. Bitte Internetverbindung prüfen und erneut versuchen.',
      );
    throw error;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener('abort', cancel);
  }
}

/** Another open tab may already have advanced dispatch. Reads must still refresh. */
export async function advanceDispatch() {
  try {
    await api('tick', {});
  } catch (error) {
    if (!(error instanceof MobilityApiError && error.status === 429))
      throw error;
  }
}
