'use client';
import { useEffect, useRef, useState } from 'react';
import {
  CarFront,
  Package,
  ShoppingBag as ShoppingBagIcon,
  Navigation,
  Wallet,
  Home,
  Phone,
  ChevronRight,
  ArrowLeft,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import Link from 'next/link';
import { useBackLayer } from './use-back-layer';
import { SwipePages } from './gesture';
import SwipeAction from './swipe-action';
import { VehicleChoices } from './vehicles';
import { money } from '@/lib/ride-domain';
import {
  statusNames,
  driverNext,
  type Booking,
  type Driver,
  type Offer,
  type FleetVehicle,
} from '@/lib/mobility/domain';
import { api } from './api';
import RideMap from './map';
import Payment from './payment';
import BoardOrder from './refreshments';
import Inventory from './inventory';
import { countCart } from '@/lib/mobility/refreshments';
import Safety from './safety';
import { useClock } from './use-clock';
import DriverOffer from './driver-offer';
import DriverStandby from './driver-standby';
import DriverSheet from './driver-sheet';
import { useDriverLocation } from './use-driver-location';
import NavigationPanel from './navigation-panel';
import { useNavigationProgress } from './use-navigation-progress';
import { useTrafficGuidance } from './use-traffic-guidance';
import { usableFix } from './gps-quality';
import { AppLoading } from './app-loading';
import {
  nativeLocation,
  nativeLocationAvailable,
  type NativeReply,
} from './native-location';
import { RidePreferencesSummary } from './ride-preferences';
import { NativeStatusRequests, matchesNativeShift } from './native-status';
import { startShiftBackground } from './background-start';
import {
  useNavigationPreferences,
  prepareNavigation,
} from './navigation-settings';
import {
  navigationTarget,
  navigationUrl,
  navigationProviders,
} from './navigation-preferences';
export type DriverState = {
  inventory?: { initialized: boolean; urgent: number; missing: number } | null;
  driver: Driver | null;
  offers: Offer[];
  bookings: Booking[];
  payments?: Booking[];
  history?: Booking[];
  vehicles?: FleetVehicle[];
  fleet?: { id: string; name: string } | null;
  vehicleRequired?: boolean;
  today?: {
    trips: number;
    gross: number;
    collected: number;
    outstanding: number;
  };
  todaySince?: number;
  revenue?: {
    trips: number;
    gross: number;
    collected: number;
    outstanding: number;
  };
};
export default function DriverView({
  state,
  token,
  refresh,
  preview = false,
  initialSection = 'home',
  active = true,
  onMenu,
  onNavigate,
}: {
  active?: boolean;
  onMenu?: () => void;
  onNavigate?: (view: string) => void;
  preview?: boolean;
  initialSection?: 'home' | 'revenue' | 'vehicles';
  state: DriverState | null;
  token: string | null;
  refresh: () => Promise<void>;
}) {
  const now = useClock();
  const { preferences: navigation } = useNavigationPreferences();
  const [navigationNotice, setNavigationNotice] = useState('');
  const [section, setSection] = useState<
    'home' | 'revenue' | 'vehicles' | 'stock'
  >(initialSection);
  const previousSection = useRef(section);
  useEffect(() => {
    if (!preview && active && previousSection.current !== section) {
      window.scrollTo(0, 0);
      previousSection.current = section;
    }
  }, [active, section, preview]);
  useBackLayer(
    active &&
      section !== 'home' &&
      !state?.bookings.length &&
      !state?.offers.length &&
      !state?.payments?.length,
    () => setSection('home'),
    10,
  );
  const [revenuePeriod, setRevenuePeriod] = useState<'today' | 'week'>('today');
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [tracking, setTracking] = useState(false),
    [name, setName] = useState(''),
    [phone, setPhone] = useState(''),
    [inviteCode, setInviteCode] = useState(''),
    [joinBusy, setJoinBusy] = useState(false),
    [joinMsg, setJoinMsg] = useState('');
  const session = useRef<string | null>(null);
  const sending = useRef(false);
  const trackingMode = useRef<'off' | 'starting' | 'native' | 'foreground'>(
    'off',
  );
  const [trackingNotice, setTrackingNotice] = useState('');
  const [availabilityProgress, setAvailabilityProgress] = useState('');
  const availabilityPending = useRef(false);
  const nativeStatusRequests = useRef(new NativeStatusRequests());
  const restoreNativeShift = useRef(true);
  const shiftGeneration = useRef(0);
  useEffect(
    () => () => {
      shiftGeneration.current++;
    },
    [],
  );
  const [backgroundActive, setBackgroundActive] = useState(false);
  const [alerts, setAlerts] = useState<{ enabled: boolean; sound: boolean }>();
  const [alertMessage, setAlertMessage] = useState('');
  const [testingAlert, setTestingAlert] = useState(false);
  const [sheetHeight, setSheetHeight] = useState(260);
  const [navigationHeight, setNavigationHeight] = useState(220);
  const [collapseRequest, setCollapseRequest] = useState(0);
  const location = useDriverLocation(!preview);
  const guidance = useTrafficGuidance(
    state?.bookings[0],
    location.position,
    !preview && active,
    now,
  );
  const maneuverProgress = useNavigationProgress(
    guidance.route,
    location.position,
    now,
  );
  const latest = useRef(location.position);
  useEffect(() => {
    latest.current = location.position;
  }, [location.position]);
  const driverId = state?.driver?.id,
    driverSession = state?.driver?.session_id;
  useEffect(() => {
    if (preview || !driverId || !nativeLocationAvailable()) return;
    let active = true;
    let pending = false;
    const requests = nativeStatusRequests.current;
    const update = (reply: NativeReply) => {
      if (!active || !reply.status) return;
      const status = reply.status;
      setAlerts(status.alerts);
      if (
        trackingMode.current === 'starting' ||
        (trackingMode.current === 'off' && !restoreNativeShift.current)
      )
        return;
      const matches = matchesNativeShift(
        status,
        session.current,
        driverSession,
        Date.now(),
      );
      if (matches) {
        session.current = status.sessionId!;
        trackingMode.current = 'native';
        setTrackingNotice('');
      } else if (trackingMode.current === 'native') {
        // The foreground channel is independent of native background permission.
        trackingMode.current = session.current ? 'foreground' : 'off';
        setTrackingNotice(
          'Hintergrundstandort ist nicht aktiv. Bitte die Fahrer-App geöffnet lassen.',
        );
      }
      setBackgroundActive(!!matches);
      if (matches || trackingMode.current !== 'foreground')
        setTracking(!!matches);
      // The location endpoint rejects superseded sessions; a stale UI poll must never stop a new one.
    };
    // Only apply our own correlated status reads. Other native replies may have
    // started before Online/Pause and arrive after that transition has finished.
    const poll = async () => {
      if (
        !active ||
        pending ||
        document.visibilityState === 'hidden' ||
        trackingMode.current === 'starting'
      )
        return;
      pending = true;
      try {
        await requests.read(() => nativeLocation('status'), update);
      } catch {
        // Missing status is not evidence that the native service stopped.
      } finally {
        pending = false;
      }
    };
    const receive = (event: Event) => {
      const reply = (event as CustomEvent<NativeReply>).detail;
      if (reply.status && !reply.requestId) void poll();
    };
    const wake = () => void poll();
    window.addEventListener('luxore-location', receive);
    window.addEventListener('focus', wake);
    document.addEventListener('visibilitychange', wake);
    const timer = setInterval(wake, 4000);
    void poll();
    return () => {
      active = false;
      requests.invalidate();
      clearInterval(timer);
      window.removeEventListener('luxore-location', receive);
      window.removeEventListener('focus', wake);
      document.removeEventListener('visibilitychange', wake);
    };
  }, [preview, driverId, driverSession]);
  useEffect(() => {
    // Keep foreground GPS delivery alive even when the native service reports active.
    // Native task registration alone is not proof of a successful location upload.
    if (!tracking || preview) return;
    let closed = false;
    async function send() {
      const p = latest.current;
      if (
        closed ||
        document.visibilityState === 'hidden' ||
        sending.current ||
        !session.current ||
        !p ||
        Date.now() - p.timestamp > 30000 ||
        p.accuracy > 100
      )
        return;
      sending.current = true;
      try {
        await api('driver', {
          action: 'heartbeat',
          sessionId: session.current,
          lat: p.lat,
          lng: p.lng,
          accuracy: p.accuracy,
          timestamp: p.timestamp,
        });
      } catch (e) {
        if (!closed) setError((e as Error).message);
      } finally {
        sending.current = false;
      }
    }
    void send();
    const timer = setInterval(() => void send(), 5000);
    return () => {
      closed = true;
      clearInterval(timer);
    };
  }, [tracking, preview]);
  async function driverApi<T = unknown>(
    path: string,
    body?: unknown,
  ): Promise<T> {
    if (preview)
      throw new Error(
        'Ansicht mit Beispieldaten. Es werden keine Fahrten oder Fahrzeugwechsel gespeichert.',
      );
    return api<T>(path, body);
  }
  async function action(body: {
    action: string;
    offerId?: string;
    status?: string;
    [key: string]: unknown;
  }) {
    if (busy) return;
    const trip =
      body.action === 'accept'
        ? state?.offers.find((o) => o.id === body.offerId)?.booking
        : state?.bookings[0];
    const target = navigationTarget(body, trip?.route);
    let confirmed = false;
    const launch =
      !preview && navigation.autoStart && target
        ? prepareNavigation(navigationUrl(navigation.provider, target))
        : null;
    setBusy(true);
    setError('');
    try {
      await driverApi('driver', body);
      confirmed = true;
      if (navigation.autoStart && target && navigation.provider === 'standard')
        setCollapseRequest((v) => v + 1);
      if (launch && !launch.complete())
        setNavigationNotice(
          'Dein Browser hat das automatische Öffnen blockiert. Bitte „Navigation öffnen“ verwenden.',
        );
      await refresh();
    } catch (e) {
      if (!confirmed) launch?.cancel();
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function availability(on: boolean) {
    if (preview) {
      setError('Ansicht mit Beispieldaten. Die Standortfreigabe bleibt aus.');
      return;
    }
    if (busy || availabilityPending.current) return;
    availabilityPending.current = true;
    const generation = ++shiftGeneration.current;
    restoreNativeShift.current = false;
    nativeStatusRequests.current.invalidate();
    setBusy(true);
    setAvailabilityProgress(
      on ? 'Schicht wird gestartet …' : 'Schicht wird beendet …',
    );
    setError('');
    const native = nativeLocationAvailable();
    trackingMode.current = 'starting';
    setTrackingNotice('');
    let started: string | undefined;
    try {
      if (!on) {
        const activeSession = session.current || state?.driver?.session_id;
        setTracking(false);
        setBackgroundActive(false);
        // Revoke on the server first, even if Android is still showing a permission dialog.
        if (activeSession)
          await driverApi('driver', {
            action: 'offline',
            sessionId: activeSession,
          });
        session.current = null;
        trackingMode.current = 'off';
        if (native)
          void nativeLocation('stop').catch(() => {
            // Late startup is cleaned up separately; revoked credentials cannot upload.
          });
      } else {
        if (!native && !navigator.geolocation)
          throw new Error('Dieses Gerät unterstützt keinen Standortzugriff.');
        const result = await driverApi<{
          sessionId: string;
          nativeToken: string;
          expiresAt: number;
        }>('driver', { action: 'online', native });
        started = result.sessionId;
        session.current = result.sessionId;
        setTracking(true);
        setBackgroundActive(false);
        trackingMode.current = 'foreground';
        if (native) {
          setTrackingNotice(
            'Hintergrundfreigabe wird geprüft. Du kannst die App bereits nutzen und jederzeit Pause machen. Bis zur Bestätigung bitte geöffnet lassen.',
          );
          void startShiftBackground({
            sessionId: result.sessionId,
            currentSession: () => session.current,
            isCurrent: () =>
              generation === shiftGeneration.current &&
              session.current === result.sessionId,
            start: () => nativeLocation('start', result),
            stop: () => nativeLocation('stop'),
            ready: (reply) => {
              nativeStatusRequests.current.invalidate();
              setBackgroundActive(true);
              trackingMode.current = 'native';
              setTrackingNotice('');
              if (reply.status?.alerts) setAlerts(reply.status.alerts);
            },
            unavailable: (message) => {
              // A newer status response may already have confirmed the service.
              if (trackingMode.current === 'native') return;
              setBackgroundActive(false);
              trackingMode.current = 'foreground';
              setTrackingNotice(
                'Standort nur in der geöffneten App. ' + message,
              );
            },
          });
        } else {
          location.retry();
        }
        setTracking(true);
      }
      // A failed refresh must not undo a successfully started shift.
      void refresh().catch((e) => setError((e as Error).message));
    } catch (e) {
      trackingMode.current = !on && session.current ? 'foreground' : 'off';
      if (!on && session.current) setTracking(true);
      setError((e as Error).message);
      if (started) {
        setTracking(false);
        setBackgroundActive(false);
        session.current = null;
        await driverApi('driver', {
          action: 'offline',
          sessionId: started,
        }).catch(() => {});
        if (native) await nativeLocation('stop').catch(() => {});
      }
    } finally {
      nativeStatusRequests.current.invalidate();
      availabilityPending.current = false;
      setAvailabilityProgress('');
      setBusy(false);
    }
  }
  async function checkAlert() {
    if (preview || testingAlert) return;
    setTestingAlert(true);
    setAlertMessage('');
    try {
      const reply = await nativeLocation('test-alert');
      if (reply.status?.alerts) setAlerts(reply.status.alerts);
      setAlertMessage(
        reply.status?.alerts?.sound
          ? 'Testalarm gesendet. Bitte Ton am Handy prüfen.'
          : 'Testalarm gesendet. Der Benachrichtigungskanal ist stumm.',
      );
    } catch (e) {
      setAlertMessage((e as Error).message);
    } finally {
      setTestingAlert(false);
    }
  }
  if (!state) return <AppLoading label="Fahrerbereich wird geladen" />;
  const driver = state.driver;
  const booking = state.bookings[0];
  const payment = state.payments?.[0];
  const fleetJoin = (
    <div className="fleet-join-card">
      <div className="fleet-join-header">
        <span className="eyebrow">SCHNELLZUGANG</span>
        <h3>Flotte beitreten</h3>
        <p>
          Gib den persönlichen Einladungscode deiner Flottenleitung ein. Danach
          kann sie dein Profil prüfen und freigeben.
        </p>
      </div>
      <div className="fleet-join-form">
        <Input
          placeholder="Persönlicher Einladungscode"
          value={inviteCode}
          onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
        />
        <Button
          disabled={joinBusy || !inviteCode.trim()}
          onClick={async () => {
            setJoinBusy(true);
            setError('');
            setJoinMsg('');
            try {
              const res = await driverApi<{ ok: boolean; message?: string }>(
                'fleets',
                {
                  action: 'join',
                  code: inviteCode.trim(),
                },
              );
              setJoinMsg(res.message || 'Flotte erfolgreich beigetreten!');
              await refresh();
            } catch (e) {
              setError((e as Error).message);
            } finally {
              setJoinBusy(false);
            }
          }}
        >
          {joinBusy ? 'Wird geprüft …' : 'Flotte beitreten'}
        </Button>
      </div>
      {joinMsg && <p className="notice success">{joinMsg}</p>}
    </div>
  );
  const tripActive = !!booking || !!payment || state.offers.length > 0;
  const displaySection = tripActive ? 'home' : section;
  return (
    <section className="driver-view">
      {error && (
        <div className="notice error" role="alert">
          {error}
        </div>
      )}
      {!driver ? (
        <form
          className="driver-register"
          onSubmit={(e) => {
            e.preventDefault();
            void action({
              action: 'register',
              name,
              phone,
            });
          }}
        >
          <h2>Fahrerprofil einreichen</h2>
          <p>
            Die Disposition prüft deine Angaben und schaltet dich anschließend
            frei.
          </p>
          <label htmlFor="driver-name">
            Vollständiger Name
            <Input
              id="driver-name"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="name"
            />
          </label>
          <label htmlFor="driver-phone">
            Telefonnummer
            <Input
              id="driver-phone"
              required
              value={phone}
              type="tel"
              onChange={(e) => setPhone(e.target.value)}
              autoComplete="tel"
            />
          </label>
          <p className="small-note">
            Dein Fahrzeug und seine Klassen wählst du nach dem Flottenbeitritt
            aus. Die Flottenleitung verwaltet alle Autos zentral.
          </p>
          <Button disabled={busy} type="submit">
            Zur Freigabe einreichen
          </Button>
        </form>
      ) : driver.approved !== 1 ? (
        <div className="driver-pending-wrap">
          <div className="empty">
            <CarFront size={44} strokeWidth={1.5} />
            <h2>Freigabe ausstehend</h2>
            <p>{driver.name}</p>
            <span>
              Tritt deiner Flotte bei. Anschließend gibt die Flottenleitung dein
              Profil für Fahrten frei.
            </span>
          </div>

          {state.fleet ? (
            <p className="notice">
              {state.fleet.name} · Deine Flottenleitung prüft deine Freigabe.
            </p>
          ) : (
            fleetJoin
          )}
        </div>
      ) : (
        <>
          <nav className="driver-dock" aria-label="Fahrermenü">
            <Button
              variant="ghost"
              aria-current={displaySection === 'home' ? 'page' : undefined}
              onClick={() => setSection('home')}
            >
              <Home size={23} />
              <span>Fahren</span>
            </Button>
            <Button
              variant="ghost"
              aria-current={displaySection === 'revenue' ? 'page' : undefined}
              disabled={tripActive || !active}
              title={tripActive ? 'Nach der Fahrt verfügbar' : undefined}
              onClick={() => setSection('revenue')}
            >
              <Wallet size={23} />
              <span>Umsatz</span>
            </Button>
            <Button
              variant="ghost"
              aria-current={displaySection === 'vehicles' ? 'page' : undefined}
              disabled={tripActive || !active}
              title={tripActive ? 'Nach der Fahrt verfügbar' : undefined}
              onClick={() => setSection('vehicles')}
            >
              <CarFront size={23} />
              <span>Auto</span>
            </Button>
            <Button
              variant="ghost"
              aria-current={displaySection === 'stock' ? 'page' : undefined}
              disabled={tripActive || !active}
              title={tripActive ? 'Nach der Fahrt verfügbar' : undefined}
              onClick={() => setSection('stock')}
            >
              <Package size={23} />
              <span>Bestand{state.inventory?.urgent ? ' · !' : ''}</span>
            </Button>
          </nav>
          <SwipePages
            canPrevious={section !== 'home'}
            canNext={section !== 'stock'}
            disabled={tripActive || !active}
            onSwipe={(direction) => {
              const order = ['home', 'revenue', 'vehicles', 'stock'] as const;
              setSection(
                order[
                  Math.max(0, Math.min(3, order.indexOf(section) + direction))
                ],
              );
            }}
          >
            {payment ? (
              <Payment key={payment.id} booking={payment} refresh={refresh} />
            ) : section === 'stock' && !booking && !state.offers.length ? (
              <div className="driver-subpage">
                <div className="driver-subpage-topbar">
                  <button
                    type="button"
                    className="subpage-back-btn"
                    onClick={() => setSection('home')}
                  >
                    <ArrowLeft size={18} />
                    <span>Zurück zum Cockpit</span>
                  </button>
                  <span className="subpage-badge">BORDKARTE</span>
                </div>
                <Inventory
                  key={driver.vehicle_id || 'none'}
                  vehicleId={driver.vehicle_id}
                />
              </div>
            ) : section === 'vehicles' && !booking && !state.offers.length ? (
              <div className="driver-subpage">
                <div className="driver-subpage-topbar">
                  <button
                    type="button"
                    className="subpage-back-btn"
                    onClick={() => setSection('home')}
                  >
                    <ArrowLeft size={18} />
                    <span>Zurück zum Cockpit</span>
                  </button>
                  <span className="subpage-badge">FAHRZEUG</span>
                </div>
                <div className="app-page-title">
                  <span>LUXORÉ DRIVER</span>
                  <h1>Bereit für die Schicht.</h1>
                </div>
                {error && <p role="alert">{error}</p>}
                {!state.fleet && fleetJoin}
                <p className="driver-fleet-context">
                  {state.fleet
                    ? state.fleet.name + ' · gemeinsamer Fuhrpark'
                    : 'Noch keiner Flotte zugeordnet. Bitte Einladung deiner Flottenleitung verwenden.'}
                </p>
                <VehicleChoices
                  vehicles={state.vehicles || []}
                  current={driver.vehicle_id || null}
                  driverId={driver.id}
                  disabled={busy || tracking || driver.online === 1}
                  onSelect={(id) => {
                    void (async () => {
                      setBusy(true);
                      setError('');
                      try {
                        await driverApi('vehicles', {
                          action: 'select',
                          vehicleId: id,
                        });
                        await refresh();
                      } catch (e) {
                        setError((e as Error).message);
                      } finally {
                        setBusy(false);
                      }
                    })();
                  }}
                />
                {(tracking || driver.online === 1) && (
                  <Button
                    variant="outline"
                    onClick={() => void availability(false)}
                  >
                    Offline gehen zum Wechseln
                  </Button>
                )}
                {onNavigate ? (
                  <button
                    type="button"
                    className="fleet-entry-link"
                    onClick={() => onNavigate('operations')}
                  >
                    Flotte & Disposition öffnen →
                  </button>
                ) : onMenu ? (
                  <button
                    type="button"
                    className="fleet-entry-link"
                    onClick={onMenu}
                  >
                    Flottenmenü öffnen →
                  </button>
                ) : (
                  <Link className="fleet-entry-link" href="/disposition">
                    Flotte verwalten →
                  </Link>
                )}
              </div>
            ) : section === 'revenue' && !booking && !state.offers.length ? (
              <div className="driver-subpage">
                <div className="driver-subpage-topbar">
                  <button
                    type="button"
                    className="subpage-back-btn"
                    onClick={() => setSection('home')}
                  >
                    <ArrowLeft size={18} />
                    <span>Zurück zum Cockpit</span>
                  </button>
                  <span className="subpage-badge">FINANZEN</span>
                </div>
                <div className="app-page-title">
                  <span>DEIN ÜBERBLICK</span>
                  <h1>Umsatz.</h1>
                </div>
                <div className="period-segment">
                  <Button
                    variant={revenuePeriod === 'today' ? 'default' : 'ghost'}
                    onClick={() => setRevenuePeriod('today')}
                  >
                    Heute
                  </Button>
                  <Button
                    variant={revenuePeriod === 'week' ? 'default' : 'ghost'}
                    onClick={() => setRevenuePeriod('week')}
                  >
                    7 Tage
                  </Button>
                </div>
                <div className="earnings-hero">
                  <small>
                    {revenuePeriod === 'today'
                      ? 'Heute · ab 00:00 Uhr in Frankfurt'
                      : 'Letzte 7 Tage'}
                  </small>
                  <strong>
                    {money(
                      (revenuePeriod === 'today' ? state.today : state.revenue)
                        ?.gross || 0,
                    )}
                  </strong>
                  <span>
                    {(revenuePeriod === 'today' ? state.today : state.revenue)
                      ?.trips || 0}{' '}
                    abgeschlossene Fahrten
                  </span>
                </div>
                <div className="earnings-split">
                  <div>
                    <small>Kassiert</small>
                    <strong>
                      {money(
                        (revenuePeriod === 'today'
                          ? state.today
                          : state.revenue
                        )?.collected || 0,
                      )}
                    </strong>
                  </div>
                  <div>
                    <small>Offen</small>
                    <strong>
                      {money(
                        (revenuePeriod === 'today'
                          ? state.today
                          : state.revenue
                        )?.outstanding || 0,
                      )}
                    </strong>
                  </div>
                </div>
                <p className="small-note">
                  Fahrpreise vor Kosten und Vergütung.
                </p>
                <h3>Letzte Fahrten</h3>
                {state.history
                  ?.filter(
                    (b) =>
                      revenuePeriod !== 'today' ||
                      (b.completed_at || 0) >= (state.todaySince || 0),
                  )
                  .map((b) => (
                    <article key={b.id} className="earnings-trip">
                      <div>
                        <strong>{b.route.destination.label}</strong>
                        <small>
                          {new Date(b.completed_at!).toLocaleString('de-DE', {
                            timeZone: 'Europe/Berlin',
                            day: '2-digit',
                            month: '2-digit',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}{' '}
                          · {b.payment_status === 'paid' ? 'Kassiert' : 'Offen'}
                        </small>
                      </div>
                      <b>{money(b.price)}</b>
                    </article>
                  ))}
                {!(revenuePeriod === 'today' ? state.today : state.revenue)
                  ?.trips && <p>Dein erster Abschluss erscheint hier.</p>}
              </div>
            ) : (
              <div
                className={`driver-canvas ${booking && tripActive ? 'has-navigation' : ''}`}
                style={
                  {
                    '--navigation-panel-height': `${navigationHeight}px`,
                  } as React.CSSProperties
                }
              >
                <RideMap
                  token={token}
                  route={
                    guidance.route ||
                    booking?.route ||
                    state.offers[0]?.booking.route ||
                    null
                  }
                  driver={
                    usableFix(location.position, now)
                      ? {
                          ...driver,
                          lat: location.position.lat,
                          lng: location.position.lng,
                          accuracy: location.position.accuracy,
                          heading: location.position.heading,
                          speed: location.position.speed,
                          location_at: location.position.timestamp,
                        }
                      : driver.lat != null &&
                          driver.lng != null &&
                          driver.location_at != null &&
                          now - driver.location_at < 30000
                        ? driver
                        : null
                  }
                  bottomInset={sheetHeight}
                  topInset={
                    booking && tripActive ? navigationHeight + 26 : undefined
                  }
                  theme="light"
                  followRoute={!!guidance.route || booking?.status === 'riding'}
                  guidanceTarget={
                    guidance.route
                      ? booking?.status === 'accepted'
                        ? 'Abholung'
                        : 'Ziel'
                      : undefined
                  }
                  roadMatching={!preview}
                  self
                  rider={
                    booking?.rider_lat != null &&
                    booking?.rider_lng != null &&
                    booking.rider_location_at &&
                    now - booking.rider_location_at < 45000
                      ? { lat: booking.rider_lat, lng: booking.rider_lng }
                      : null
                  }
                />
                {booking && tripActive ? (
                  <NavigationPanel
                    phase={booking.status}
                    destination={
                      booking.status === 'riding'
                        ? booking.route.destination.label
                        : booking.route.pickup.label
                    }
                    route={guidance.route}
                    progress={maneuverProgress}
                    fix={location.position}
                    now={now}
                    online={guidance.online}
                    failed={guidance.failed}
                    pending={guidance.pending}
                    recovery={guidance.recovery}
                    onHeightChange={setNavigationHeight}
                    locationError={location.error}
                    onLocate={location.retry}
                  />
                ) : (
                  <div className="driver-map-top">
                    <button
                      className="daily-pill"
                      onClick={() => setSection('revenue')}
                    >
                      <Wallet size={17} />
                      <span>
                        <small>Tagesumsatz</small>
                        <strong>{money(state.today?.gross || 0)}</strong>
                      </span>
                      <ChevronRight size={16} />
                    </button>
                    <button
                      className="car-pill"
                      onClick={() => setSection('vehicles')}
                      aria-label="Fahrzeug wechseln"
                    >
                      <CarFront size={20} />
                      <span>
                        <small>Fahrzeug</small>
                        <strong>
                          {driver.vehicle_id || !state.vehicleRequired
                            ? driver.plate
                            : 'Auto wählen'}
                        </strong>
                      </span>
                      <ChevronRight size={16} />
                    </button>
                  </div>
                )}
                {!(booking && tripActive) &&
                  (location.error ||
                    (tracking && !usableFix(location.position, now))) && (
                    <button
                      className="driver-gps-notice"
                      onClick={location.retry}
                    >
                      {location.error ||
                        'Warte auf ein genaues GPS-Signal. Bitte Standort am Handy erlauben.'}{' '}
                      <span>Erneut suchen</span>
                    </button>
                  )}
                {booking ? (
                  <DriverSheet
                    key={booking.id + booking.status}
                    initialStop={
                      booking.status === 'accepted' ||
                      booking.status === 'riding'
                        ? 'peek'
                        : 'half'
                    }
                    reservedTop={tripActive ? navigationHeight + 24 : 0}
                    collapseRequest={collapseRequest}
                    title={statusNames[booking.status]}
                    subtitle={
                      booking.status === 'riding'
                        ? booking.route.destination.label
                        : booking.route.pickup.label
                    }
                    peekSubtitle={`${countCart(booking.refreshments?.requested || {}) ? countCart(booking.refreshments!.requested) + ' Bordartikel · ' : ''}${statusNames[booking.status]} · ${money(booking.price)}`}
                    onHeightChange={setSheetHeight}
                    className="driver-active-trip"
                  >
                    <div className="driver-trip-heading">
                      <span className="trip-stage">
                        {booking.status === 'accepted'
                          ? 'ZUR ABHOLUNG'
                          : booking.status === 'arrived'
                            ? 'AM ABHOLORT'
                            : 'ZUM FAHRTZIEL'}
                      </span>
                      <span>{statusNames[booking.status]}</span>
                    </div>
                    <h2>
                      {booking.status === 'riding'
                        ? booking.route.destination.label
                        : booking.route.pickup.label}
                    </h2>
                    <p>
                      {booking.status === 'riding'
                        ? 'Ziel'
                        : 'Danach: ' + booking.route.destination.label}
                    </p>
                    {!guidance.route && booking.route.traffic?.unpaved && (
                      <output className="traffic-guidance-status">
                        Unbefestigter Abschnitt auf der gebuchten Strecke
                      </output>
                    )}
                    <div className="trip-compact-meta">
                      <span>
                        <small>Fahrgast</small>
                        <strong>{booking.rider_name || 'Gast'}</strong>
                      </span>
                      <span>
                        <small>Fahrpreis</small>
                        <strong>{money(booking.price)}</strong>
                      </span>
                    </div>
                    <BoardOrder
                      booking={booking}
                      driver
                      refresh={refresh}
                      preview={preview}
                    />
                    <RidePreferencesSummary value={booking.rider_preferences} />
                    <div className="trip-quick-actions">
                      {navigation.provider === 'standard' ? (
                        <button
                          type="button"
                          onClick={() => setCollapseRequest((v) => v + 1)}
                        >
                          <Navigation size={20} />
                          Luxóre Karte
                        </button>
                      ) : (
                        <a
                          href={
                            navigationUrl(
                              navigation.provider,
                              booking.status === 'riding'
                                ? booking.route.destination
                                : booking.route.pickup,
                            ) || undefined
                          }
                          target="_blank"
                          rel="noreferrer"
                          onClick={() => setNavigationNotice('')}
                        >
                          <Navigation size={20} />
                          {
                            navigationProviders.find(
                              (p) => p.id === navigation.provider,
                            )?.name
                          }{' '}
                          öffnen
                        </a>
                      )}
                      {booking.rider_phone && (
                        <a
                          href={
                            'tel:' + booking.rider_phone.replace(/[^+\d]/g, '')
                          }
                        >
                          <Phone size={19} />
                          Anrufen
                        </a>
                      )}
                    </div>
                    {navigationNotice && (
                      <output className="small-note">{navigationNotice}</output>
                    )}
                    <div className="driver-safety-action">
                      <Safety booking={booking} />
                    </div>
                    <div className="driver-sheet-actions">
                      {driverNext[booking.status] && (
                        <SwipeAction
                          key={booking.status}
                          label={
                            booking.status === 'accepted'
                              ? 'Angekommen'
                              : booking.status === 'arrived'
                                ? 'Fahrt starten'
                                : 'Fahrt abschließen'
                          }
                          disabled={busy}
                          onConfirm={() =>
                            void action({
                              action: 'status',
                              id: booking.id,
                              from: booking.status,
                              status: driverNext[booking.status],
                            })
                          }
                        />
                      )}
                    </div>
                  </DriverSheet>
                ) : state.offers.length ? (
                  <DriverSheet
                    key={state.offers[0].id}
                    title={`Neue Fahrt · ${Math.max(0, Math.ceil((state.offers[0].expires_at - now) / 1000))} s`}
                    subtitle={`${money(state.offers[0].booking.price)} · ${state.offers[0].booking.route.pickup.label}`}
                    peekSubtitle={`Angebot · ${money(state.offers[0].booking.price)}`}
                    onHeightChange={setSheetHeight}
                    className="offer-sheet"
                  >
                    {state.offers.map((offer) => (
                      <DriverOffer
                        key={offer.id}
                        offer={offer}
                        now={now}
                        busy={busy}
                        onAccept={() =>
                          void action({ action: 'accept', offerId: offer.id })
                        }
                        onReject={() =>
                          void action({ action: 'reject', offerId: offer.id })
                        }
                      />
                    ))}
                  </DriverSheet>
                ) : (
                  <DriverSheet
                    title={
                      availabilityProgress ||
                      (tracking
                        ? driver.online === 1 &&
                          !!driver.location_at &&
                          now - driver.location_at < 45000
                          ? 'Online · bereit für Fahrten'
                          : 'GPS wird gesucht …'
                        : 'Bereit für deine Schicht?')
                    }
                    subtitle={
                      backgroundActive
                        ? 'Standort auch im Hintergrund aktiv'
                        : 'Nach unten wischen für mehr Karte'
                    }
                    peekSubtitle={
                      tracking
                        ? driver.online === 1
                          ? 'Online · ' + (driver.plate || 'Fahrbereit')
                          : 'GPS wird gesucht …'
                        : 'Offline · ' + (driver.plate || 'Schicht starten')
                    }
                    onHeightChange={setSheetHeight}
                    className="idle-sheet"
                  >
                    {state.inventory &&
                      (!state.inventory.initialized ||
                        state.inventory.urgent > 0) && (
                        <button
                          className="stock-reminder"
                          onClick={() => setSection('stock')}
                        >
                          <ShoppingBagIcon />
                          <span>
                            <strong>
                              {state.inventory.initialized
                                ? 'Bitte jetzt einkaufen'
                                : 'Bordbestand erfassen'}
                            </strong>
                            <small>
                              {state.inventory.initialized
                                ? `${state.inventory.missing} Stück auf deiner Einkaufsliste`
                                : 'Einmal zählen für zuverlässige Nachfüllhinweise'}
                            </small>
                          </span>
                          <ChevronRight size={20} />
                        </button>
                      )}
                    <DriverStandby
                      preview={preview}
                      progress={availabilityProgress}
                      error={error || (tracking ? location.error : '')}
                      backgroundNotice={trackingNotice}
                      driver={driver}
                      vehicleRequired={!!state.vehicleRequired}
                      tracking={tracking}
                      backgroundActive={backgroundActive}
                      alerts={alerts}
                      alertMessage={alertMessage}
                      testingAlert={testingAlert}
                      onTestAlert={alerts ? () => void checkAlert() : undefined}
                      onAlertSettings={
                        alerts
                          ? () =>
                              void nativeLocation('alert-settings').catch((e) =>
                                setAlertMessage(e.message),
                              )
                          : undefined
                      }
                      locationFresh={
                        !!driver.location_at && now - driver.location_at < 45000
                      }
                      busy={busy}
                      onAvailability={() => void availability(!tracking)}
                      onVehicle={() => setSection('vehicles')}
                    />
                  </DriverSheet>
                )}
              </div>
            )}
          </SwipePages>
        </>
      )}
    </section>
  );
}
