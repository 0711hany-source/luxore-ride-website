'use client';
import { useEffect, useRef } from 'react';
import {
  ArrowUp,
  ArrowDownLeft,
  ArrowDownRight,
  ArrowUpLeft,
  ArrowUpRight,
  CornerUpLeft,
  CornerUpRight,
  CornerDownLeft,
  CornerDownRight,
  Undo2,
  RotateCcw,
  GitFork,
  Navigation,
  MapPin,
  WifiOff,
  LocateFixed,
  RefreshCw,
  Route,
  Flag,
} from 'lucide-react';
import type { NavigationStep } from '@/lib/mobility/navigation-steps';
import type { RouteData } from '@/lib/mobility/domain';
import type { RecoveryReason } from './route-recovery';
import type { GpsFix } from './gps-quality';
import {
  navigationDistance,
  remainingDistance,
  navigationFixUsable,
  type NavigationProgress,
} from './navigation-progress';
export function ManeuverIcon({
  step,
}: {
  step: Pick<NavigationStep, 'type' | 'modifier'> | null;
}) {
  const size = 40,
    type = step?.type,
    modifier = step?.modifier;
  const Icon =
    type === 'arrive'
      ? MapPin
      : type === 'roundabout' || type === 'rotary'
        ? RotateCcw
        : type === 'exit roundabout' || type === 'exit rotary'
          ? ArrowUpRight
          : modifier === 'uturn'
            ? Undo2
            : modifier === 'sharp left'
              ? CornerDownLeft
              : modifier === 'sharp right'
                ? CornerDownRight
                : modifier === 'left'
                  ? CornerUpLeft
                  : modifier === 'right'
                    ? CornerUpRight
                    : modifier === 'slight left'
                      ? ArrowUpLeft
                      : modifier === 'slight right'
                        ? ArrowUpRight
                        : type === 'fork'
                          ? GitFork
                          : type === 'off ramp'
                            ? modifier?.includes('left')
                              ? ArrowDownLeft
                              : ArrowDownRight
                            : type === 'depart' || !type
                              ? Navigation
                              : modifier === 'straight' ||
                                  type === 'continue' ||
                                  type === 'new name'
                                ? ArrowUp
                                : Route;
  return <Icon size={size} strokeWidth={2.25} aria-hidden="true" />;
}
export type NavigationPanelProps = {
  phase: string;
  destination: string;
  route: RouteData | null;
  progress: NavigationProgress | null;
  fix: GpsFix | null;
  now: number;
  online: boolean;
  failed: boolean;
  pending: boolean;
  recovery?: RecoveryReason | null;
  onHeightChange?: (height: number) => void;
  locationError?: string;
  onLocate?: () => void;
};
export default function NavigationPanel({
  phase,
  destination,
  route,
  progress,
  fix,
  now,
  online,
  failed,
  pending,
  recovery,
  onHeightChange,
  locationError,
  onLocate,
}: NavigationPanelProps) {
  const root = useRef<HTMLElement>(null);
  useEffect(() => {
    if (!root.current || !onHeightChange) return;
    const update = () =>
      onHeightChange(root.current?.getBoundingClientRect().height || 0);
    update();
    const observer = new ResizeObserver(update);
    observer.observe(root.current);
    return () => {
      observer.disconnect();
      onHeightChange(0);
    };
  }, [onHeightChange]);
  const arrived = phase === 'arrived';
  const gps = navigationFixUsable(fix, now);
  const fresh =
    !!route &&
    now - route.calculatedAt >= 0 &&
    now - route.calculatedAt <= 90000;
  const current = !arrived && gps && fresh && !recovery ? progress : null;
  const near = current?.nearDestination;
  const status = !online
    ? current
      ? 'Offline · Route gespeichert'
      : 'Keine Internetverbindung'
    : !gps && !arrived
      ? 'Standort wird gesucht'
      : recovery && !arrived
        ? recovery === 'off-route'
          ? 'Route verlassen'
          : 'Fahrtrichtung abgleichen'
        : failed
          ? 'Verkehr nicht aktuell'
          : pending
            ? 'Verkehr wird aktualisiert'
            : current
              ? 'Verkehr berücksichtigt'
              : arrived
                ? 'Abholung erreicht'
                : 'Route wird abgeglichen';
  const title = arrived
    ? 'Fahrgast einsteigen lassen'
    : near
      ? phase === 'accepted'
        ? 'Abholung in der Nähe'
        : 'Fahrtziel in der Nähe'
      : current
        ? current.next.instruction
        : !gps
          ? 'Warte auf genaues GPS'
          : recovery
            ? online
              ? 'Neue Route wird gesucht'
              : 'Neue Route benötigt'
            : !online
              ? 'Verbindung wird wiederhergestellt'
              : failed
                ? 'Route derzeit nicht verfügbar'
                : route && !route.navigation
                  ? 'Abbiegehinweise nicht verfügbar'
                  : route?.navigation && !pending
                    ? 'Standort wird der Route zugeordnet'
                    : 'Route wird aktualisiert';
  const time = current
    ? Math.max(1, Math.ceil(current.remainingSeconds / 60))
    : null;
  const eta = current
    ? new Date(now + current.remainingSeconds * 1000).toLocaleTimeString(
        'de-DE',
        { timeZone: 'Europe/Berlin', hour: '2-digit', minute: '2-digit' },
      )
    : null;
  const NoticeIcon = !online ? WifiOff : !gps ? LocateFixed : RefreshCw;
  return (
    <section
      ref={root}
      className="driver-navigation-panel"
      aria-label="Fahrtnavigation"
      data-state={current ? 'guiding' : arrived ? 'arrived' : 'waiting'}
    >
      <div className="navigation-phase">
        <span>
          {phase === 'accepted' || arrived ? 'Zur Abholung' : 'Zum Fahrtziel'}
        </span>
        <span className="navigation-status">
          <i data-current={(!!current && online && !failed) || undefined} />
          {status}
        </span>
      </div>
      <div className="navigation-maneuver">
        <div className="navigation-symbol">
          {arrived || near ? (
            <Flag size={38} aria-hidden="true" />
          ) : current ? (
            <ManeuverIcon step={current.next} />
          ) : (
            <NoticeIcon size={32} aria-hidden="true" />
          )}
          {current?.next.exit && !near && <b>{current.next.exit}</b>}
        </div>
        <div className="navigation-instruction">
          {current && !near && (
            <strong className="navigation-turn-distance">
              {navigationDistance(current.distanceToTurn)}
            </strong>
          )}
          <h2 aria-live="polite" aria-atomic="true">
            {title}
          </h2>
        </div>
      </div>
      <p className="navigation-destination">
        <MapPin size={14} aria-hidden="true" />
        {destination}
      </p>
      {current?.following &&
        current.next.type !== 'arrive' &&
        current.distanceToTurn < 80 &&
        current.next.distanceMeters <= 200 && (
          <div className="navigation-then">
            <span>
              Danach · {remainingDistance(current.next.distanceMeters)}
            </span>
            <ManeuverIcon step={current.following} />
            <span>{current.following.instruction}</span>
          </div>
        )}
      {!gps && !arrived && locationError && (
        <p className="navigation-road-notice">{locationError}</p>
      )}
      {!gps && !arrived && onLocate && (
        <button type="button" className="navigation-locate" onClick={onLocate}>
          Standort prüfen
        </button>
      )}
      {!arrived && (
        <dl className="navigation-summary">
          <div>
            <dt>Ankunft · ca.</dt>
            <dd>{eta || '—'}</dd>
          </div>
          <div>
            <dt>Restzeit</dt>
            <dd>
              {time === null ? (
                '—'
              ) : (
                <>
                  {time}
                  <small> Min</small>
                </>
              )}
            </dd>
          </div>
          <div>
            <dt>Reststrecke</dt>
            <dd>
              {current ? remainingDistance(current.remainingMeters) : '—'}
            </dd>
          </div>
        </dl>
      )}
      {route?.traffic?.unpaved && (
        <p className="navigation-road-notice">
          <Route size={14} aria-hidden="true" />
          Unbefestigter Abschnitt voraus
        </p>
      )}
    </section>
  );
}
