export const navigationProviders = [
  {
    id: 'standard',
    name: 'Standard',
    description: 'Luxóre Karte · direkt in der App',
  },
  { id: 'waze', name: 'Waze', description: 'Route in Waze öffnen' },
  {
    id: 'apple',
    name: 'Apple Maps',
    description: 'Apple Karten · auf iPhone und iPad',
  },
  {
    id: 'google',
    name: 'Google Maps',
    description: 'Route in Google Maps öffnen',
  },
] as const;
export type NavigationProvider = (typeof navigationProviders)[number]['id'];
export type NavigationPreferences = {
  provider: NavigationProvider;
  autoStart: boolean;
};
export const defaultNavigation: NavigationPreferences = {
  provider: 'standard',
  autoStart: true,
};
export function parseNavigation(value: unknown): NavigationPreferences {
  const v = value as Partial<NavigationPreferences> | null;
  return {
    provider: navigationProviders.some((p) => p.id === v?.provider)
      ? v!.provider!
      : 'standard',
    autoStart: typeof v?.autoStart === 'boolean' ? v.autoStart : true,
  };
}
export function navigationUrl(
  provider: NavigationProvider,
  point: { lat: number; lng: number },
): string | null {
  if (
    !Number.isFinite(point.lat) ||
    !Number.isFinite(point.lng) ||
    Math.abs(point.lat) > 90 ||
    Math.abs(point.lng) > 180
  )
    return null;
  const destination = `${point.lat},${point.lng}`;
  if (provider === 'waze')
    return (
      'https://waze.com/ul?' +
      new URLSearchParams({
        ll: destination,
        navigate: 'yes',
        utm_source: 'luxore_ride',
      })
    );
  if (provider === 'apple')
    return (
      'https://maps.apple.com/?' +
      new URLSearchParams({ daddr: destination, dirflg: 'd' })
    );
  if (provider === 'google')
    return (
      'https://www.google.com/maps/dir/?' +
      new URLSearchParams({
        api: '1',
        destination,
        travelmode: 'driving',
        dir_action: 'navigate',
      })
    );
  return null;
}
// Only confirmed driver actions launch a route, never polling, returning to the app or reloading.
export function navigationTarget(
  action: { action?: string; status?: string },
  route?: {
    pickup: { lat: number; lng: number };
    destination: { lat: number; lng: number };
  },
) {
  if (!route) return null;
  if (action.action === 'accept') return route.pickup;
  if (action.action === 'status' && action.status === 'riding')
    return route.destination;
  return null;
}
