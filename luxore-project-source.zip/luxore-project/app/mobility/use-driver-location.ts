'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { acceptFix, usableFix } from './gps-quality';
import {
  travelTelemetry,
  type TravelTelemetry,
} from '@/lib/mobility/gps-telemetry';
import {
  nativeLocation,
  nativeLocationAvailable,
  type NativeReply,
} from './native-location';
export type DriverPosition = TravelTelemetry & {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
};
function getCachedPosition(): DriverPosition | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw =
      sessionStorage.getItem('luxore_driver_pos') ||
      localStorage.getItem('luxore_driver_pos');
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (usableFix(parsed, Date.now())) {
      return parsed;
    }
  } catch {}
  return null;
}

function saveCachedPosition(pos: DriverPosition) {
  if (typeof window === 'undefined') return;
  try {
    const json = JSON.stringify(pos);
    sessionStorage.setItem('luxore_driver_pos', json);
    localStorage.setItem('luxore_driver_pos', json);
  } catch {}
}

export function useDriverLocation(enabled: boolean) {
  const [position, setPosition] = useState<DriverPosition | null>(
    getCachedPosition,
  );
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  const latest = useRef<DriverPosition | null>(position);
  const retry = useCallback(() => setAttempt((value) => value + 1), []);
  useEffect(() => {
    if (!enabled) return;
    if (nativeLocationAvailable()) {
      let active = true;
      const update = (value: NativeReply) => {
        if (!active) return;
        if (value.position) {
          if (!usableFix(value.position, Date.now())) {
            setError(
              'Standort noch ungenau oder veraltet. GPS wird weiter gesucht.',
            );
          } else if (acceptFix(latest.current, value.position, Date.now())) {
            latest.current = value.position;
            setPosition(value.position);
            saveCachedPosition(value.position);
            setError('');
          }
        } else if (value.error) setError(value.error);
      };
      const receive = (event: Event) =>
        update((event as CustomEvent<NativeReply>).detail);
      window.addEventListener('luxore-location', receive);
      void nativeLocation('status')
        .then(update)
        .catch(() => {});
      let locating = false;
      let lastLocate = 0;
      const locate = () => {
        if (!active || locating || document.visibilityState === 'hidden')
          return;
        locating = true;
        lastLocate = Date.now();
        void nativeLocation('locate')
          .then(update)
          .catch((error) => {
            if (active) setError(error.message);
          })
          .finally(() => {
            locating = false;
          });
      };
      locate();
      const poll = setInterval(() => {
        if (!active) return;
        if (
          !usableFix(latest.current, Date.now()) &&
          Date.now() - lastLocate > 15000
        )
          locate();
        void nativeLocation('status')
          .then(update)
          .catch(() => {});
      }, 4000);
      const onWake = () => {
        if (!active) return;
        if (
          !usableFix(latest.current, Date.now()) &&
          Date.now() - lastLocate > 15000
        )
          locate();
        void nativeLocation('status')
          .then(update)
          .catch(() => {});
        locate();
      };
      document.addEventListener('visibilitychange', onWake);
      window.addEventListener('focus', onWake);
      return () => {
        active = false;
        clearInterval(poll);
        document.removeEventListener('visibilitychange', onWake);
        window.removeEventListener('focus', onWake);
        window.removeEventListener('luxore-location', receive);
      };
    }
    if (!navigator.geolocation) return;
    let active = true;
    let denied = false;
    const success = (value: GeolocationPosition) => {
      if (
        !active ||
        (latest.current && value.timestamp < latest.current.timestamp)
      )
        return;
      const point = {
        ...travelTelemetry(value.coords),
        lat: value.coords.latitude,
        lng: value.coords.longitude,
        accuracy: value.coords.accuracy,
        timestamp: value.timestamp,
      };
      if (!usableFix(point, Date.now())) {
        setError(
          'Standort noch ungenau oder veraltet. GPS wird weiter gesucht.',
        );
        return;
      }
      if (!acceptFix(latest.current, point, Date.now())) return;
      latest.current = point;
      setPosition(point);
      saveCachedPosition(point);
      setError(
        point.accuracy > 100
          ? 'Standort noch ungenau. GPS wird weiter gesucht.'
          : '',
      );
    };
    const failed = (issue: GeolocationPositionError) => {
      if (!active) return;
      denied = issue.code === 1;
      setError(
        denied
          ? 'Bitte Standortzugriff für die Fahrer-App erlauben.'
          : 'GPS-Signal fehlt. Die Standortsuche läuft weiter.',
      );
    };
    const locate = () => {
      if (!active || denied || document.visibilityState === 'hidden') return;
      navigator.geolocation.getCurrentPosition(success, failed, {
        enableHighAccuracy: true,
        maximumAge: 3000,
        timeout: 15000,
      });
    };
    // Cached fix immediately displays map position on mount; watchPosition refines continuously.
    navigator.geolocation.getCurrentPosition(success, failed, {
      enableHighAccuracy: false,
      maximumAge: 10000,
      timeout: 5000,
    });
    const watch = navigator.geolocation.watchPosition(success, failed, {
      enableHighAccuracy: true,
      maximumAge: 2000,
      timeout: 15000,
    });
    const timer = setInterval(locate, 15000);
    document.addEventListener('visibilitychange', locate);
    window.addEventListener('focus', locate);
    window.addEventListener('online', locate);
    return () => {
      active = false;
      clearInterval(timer);
      navigator.geolocation.clearWatch(watch);
      document.removeEventListener('visibilitychange', locate);
      window.removeEventListener('focus', locate);
      window.removeEventListener('online', locate);
    };
  }, [enabled, attempt]);
  const unavailable =
    enabled &&
    typeof navigator !== 'undefined' &&
    !navigator.geolocation &&
    !nativeLocationAvailable();
  return {
    position,
    error: unavailable
      ? 'Dieses Gerät unterstützt keinen Standortzugriff.'
      : error,
    retry,
  };
}
