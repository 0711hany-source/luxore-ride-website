import type { RoadMatch } from '../../lib/mobility/road-matching';
import { usableFix, type GpsFix, distanceMeters } from './gps-quality.ts';
import { projectRoad } from './navigation-motion.ts';
export function roadMatchForFix(
  match: RoadMatch | null,
  fix: GpsFix | null,
  now: number,
) {
  if (
    !match ||
    !usableFix(fix, now) ||
    fix.timestamp < match.timestamp ||
    fix.timestamp - match.timestamp > 6000 ||
    now - match.timestamp > 6000
  )
    return null;
  const projection = projectRoad(fix, match.coordinates);
  if (
    !projection ||
    projection.distance > Math.max(8, Math.min(25, fix.accuracy))
  )
    return null;
  const end = match.coordinates.at(-1)!;
  // An older match can describe the road behind us, but must never hold us at its end.
  if (
    distanceMeters(projection, { lng: end[0], lat: end[1] }) < 1 &&
    projection.distance > 3
  )
    return null;
  return match;
}
