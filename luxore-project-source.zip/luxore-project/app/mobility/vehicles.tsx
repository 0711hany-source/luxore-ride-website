'use client';
import { useEffect, useState, useCallback, useRef } from 'react';
import {
  Plus,
  Archive,
  Check,
  ArrowRightLeft,
  KeyRound,
  Pencil,
  RotateCcw,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { VehicleCreateForm } from './vehicle-form';
import VehicleArtwork from './vehicle-artwork';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import type { FleetVehicle, Service } from '@/lib/mobility/domain';
import { className } from '@/lib/ride-domain';
import { api, MobilityApiError } from './api';
import { useBackLayer } from './use-back-layer';
export function VehicleChoices({
  vehicles,
  current,
  driverId,
  disabled,
  onSelect,
}: {
  vehicles: FleetVehicle[];
  current: string | null;
  driverId: string;
  disabled: boolean;
  onSelect: (id: string | null) => void;
}) {
  return (
    <div className="vehicle-choices">
      <h2>Dein Fahrzeug</h2>
      <p>Vor der Schicht auswählen. Zum Wechseln zuerst offline gehen.</p>
      {!vehicles.length && (
        <p className="notice">
          Deine Flottenleitung kann Fahrzeuge in der Disposition hinzufügen.
        </p>
      )}
      {vehicles.map((v) => {
        const mine = v.id === current,
          occupied = !!v.driver_id && v.driver_id !== driverId;
        return (
          <button
            key={v.id}
            className={'vehicle-choice ' + (mine ? 'is-selected' : '')}
            disabled={disabled || occupied || mine}
            onClick={() => onSelect(v.id)}
          >
            <VehicleArtwork model={v.model} />
            <span>
              <strong>{v.model}</strong>
              <b className="number-plate">{v.plate}</b>
              <small>
                {(JSON.parse(v.services) as Service[])
                  .map(className)
                  .join(' · ')}
              </small>
              <small>
                {mine
                  ? 'Dein aktuelles Auto'
                  : occupied
                    ? 'Belegt · ' + v.driver_name
                    : 'Verfügbar'}
              </small>
            </span>
            {mine ? <Check /> : <ArrowRightLeft size={20} />}
          </button>
        );
      })}
      {current && (
        <Button
          variant="outline"
          disabled={disabled}
          onClick={() => onSelect(null)}
        >
          Fahrzeug freigeben
        </Button>
      )}
    </div>
  );
}
export default function FleetVehicles({ fleetId }: { fleetId: string }) {
  const [vehicles, setVehicles] = useState<FleetVehicle[]>([]),
    [open, setOpen] = useState(false),
    [archive, setArchive] = useState<FleetVehicle | null>(null),
    [release, setRelease] = useState<FleetVehicle | null>(null),
    [editing, setEditing] = useState<FleetVehicle | null>(null),
    [restore, setRestore] = useState<FleetVehicle | null>(null),
    [archiveReason, setArchiveReason] = useState('Verkauft'),
    [model, setModel] = useState(''),
    [plate, setPlate] = useState(''),
    [services, setServices] = useState<Service[]>(['premium']),
    [busy, setBusy] = useState(false),
    [loadingLatest, setLoadingLatest] = useState(false),
    [conflict, setConflict] = useState(false),
    [error, setError] = useState(''),
    [listError, setListError] = useState(''),
    [saved, setSaved] = useState(''),
    [showArchive, setShowArchive] = useState(false);
  const saving = useRef(false);
  const createAttempt = useRef<{ fingerprint: string; id: string } | null>(
    null,
  );
  const revision = useRef(0);
  const close = () => {
    if (saving.current) return;
    setOpen(false);
    setArchive(null);
    setRelease(null);
    setRestore(null);
    setEditing(null);
    setConflict(false);
  };
  useBackLayer(open || !!archive || !!release || !!restore, close, 80);
  const refresh = useCallback(async () => {
    const request = ++revision.current;
    const r = await api<{ vehicles: FleetVehicle[] }>(
      'vehicles?fleetId=' + encodeURIComponent(fleetId),
    );
    if (request === revision.current) {
      setVehicles(r.vehicles.filter((v) => v.fleet_id === fleetId));
      setListError('');
    }
  }, [fleetId]);
  useEffect(() => {
    let alive = true;
    const load = () =>
      refresh().catch((e) => {
        if (alive) setListError(e.message);
      });
    void load();
    const timer = setInterval(() => {
      if (document.visibilityState !== 'hidden') void load();
    }, 10000);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [refresh]);
  async function save(body: { action: string; [key: string]: unknown }) {
    if (saving.current) return;
    saving.current = true;
    setBusy(true);
    setError('');
    setConflict(false);
    setSaved('');
    try {
      let payload = body;
      if (body.action === 'create') {
        const fingerprint = JSON.stringify(body);
        if (createAttempt.current?.fingerprint !== fingerprint)
          createAttempt.current = { fingerprint, id: crypto.randomUUID() };
        payload = { ...body, requestId: createAttempt.current.id };
      }
      await api('vehicles', payload);
      // Creation succeeded even if the subsequent list request is interrupted.
      revision.current++;
      setSaved(
        body.action === 'create'
          ? `${String(body.plate).trim().toUpperCase()} wurde zur Flotte hinzugefügt.`
          : 'Fahrzeug aktualisiert.',
      );
      setOpen(false);
      setArchive(null);
      setRelease(null);
      setRestore(null);
      setEditing(null);
      createAttempt.current = null;
      setModel('');
      setPlate('');
      setServices(['premium']);
      await refresh().catch(() =>
        setListError(
          'Gespeichert. Die Fahrzeugliste konnte noch nicht aktualisiert werden.',
        ),
      );
    } catch (e) {
      setError((e as Error).message);
      setConflict(
        body.action === 'update' &&
          e instanceof MobilityApiError &&
          e.status === 409,
      );
      if (
        body.action === 'release' &&
        e instanceof MobilityApiError &&
        e.status === 409
      )
        await refresh().catch((failure: Error) =>
          setListError(failure.message),
        );
    } finally {
      saving.current = false;
      setBusy(false);
    }
  }
  async function reloadEditing() {
    if (saving.current || !editing) return;
    saving.current = true;
    setBusy(true);
    setLoadingLatest(true);
    try {
      const result = await api<{ vehicles: FleetVehicle[] }>(
        'vehicles?fleetId=' + encodeURIComponent(fleetId),
      );
      const latest = result.vehicles.find(
        (v) => v.id === editing.id && v.fleet_id === fleetId,
      );
      if (!latest || latest.status !== 'active')
        throw new Error(
          'Das Fahrzeug ist nicht mehr aktiv. Bitte das Formular schließen und die Fahrzeugliste aktualisieren.',
        );
      setEditing(latest);
      setModel(latest.model);
      setPlate(latest.plate);
      setServices(JSON.parse(latest.services));
      setError('');
      setConflict(false);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      saving.current = false;
      setBusy(false);
      setLoadingLatest(false);
    }
  }
  return (
    <section className="fleet-vehicles">
      <div className="vehicle-section-title">
        <h4>
          Fahrzeuge · {vehicles.filter((v) => v.status === 'active').length}
        </h4>
        <Button
          variant="outline"
          disabled={busy}
          onClick={() => {
            setError('');
            setConflict(false);
            setEditing(null);
            setModel('');
            setPlate('');
            setServices(['premium']);
            createAttempt.current = null;
            setOpen(true);
          }}
        >
          <Plus size={18} />
          Auto hinzufügen
        </Button>
      </div>
      {saved && (
        <output className="vehicle-saved">
          <Check size={18} />
          {saved}
        </output>
      )}
      {listError && (
        <div aria-live="polite" className="vehicle-list-error">
          <p>{listError}</p>
          <Button
            variant="outline"
            disabled={busy}
            onClick={() => void refresh().catch((e) => setListError(e.message))}
          >
            Liste aktualisieren
          </Button>
        </div>
      )}
      {error && !open && !archive && !release && !restore && (
        <p role="alert" className="field-error">
          {error}
        </p>
      )}
      {vehicles
        .filter((v) => showArchive || v.status === 'active')
        .map((v) => (
          <article className="fleet-vehicle-row" key={v.id}>
            <VehicleArtwork model={v.model} />
            <div>
              <strong>{v.model}</strong>
              <span>
                {v.plate} ·{' '}
                {(JSON.parse(v.services) as Service[])
                  .map(className)
                  .join(' · ')}
              </span>
              <small>
                {v.status === 'archived'
                  ? 'Archiviert · ' + v.archived_reason
                  : v.driver_name
                    ? 'Zugeordnet: ' + v.driver_name
                    : 'Frei'}
              </small>
              {v.blocking_reason && (
                <small className="vehicle-blocked">{v.blocking_reason}</small>
              )}
            </div>
            <div className="fleet-vehicle-actions">
              {v.status === 'active' && (
                <Button
                  variant="outline"
                  disabled={busy || !!v.blocking_reason}
                  onClick={() => {
                    setError('');
                    setConflict(false);
                    setEditing(v);
                    setModel(v.model);
                    setPlate(v.plate);
                    setServices(JSON.parse(v.services));
                    setOpen(true);
                  }}
                >
                  <Pencil size={16} />
                  Bearbeiten
                </Button>
              )}
              {v.status === 'active' && v.driver_id && (
                <Button
                  variant="outline"
                  disabled={busy || !!v.blocking_reason}
                  onClick={() => {
                    setError('');
                    setRelease(v);
                  }}
                >
                  <KeyRound size={16} />
                  Freigeben
                </Button>
              )}
              {v.status === 'active' && (
                <Button
                  variant="ghost"
                  aria-label={v.plate + ' archivieren'}
                  disabled={busy || !!v.blocking_reason}
                  onClick={() => {
                    setError('');
                    setArchiveReason('Verkauft');
                    setArchive(v);
                  }}
                >
                  <Archive size={18} />
                  Archivieren
                </Button>
              )}
              {v.status === 'archived' && (
                <Button
                  variant="outline"
                  disabled={busy}
                  onClick={() => {
                    setError('');
                    setRestore(v);
                  }}
                >
                  <RotateCcw size={16} />
                  Wieder aktivieren
                </Button>
              )}
            </div>
          </article>
        ))}
      {!vehicles.length && (
        <p>
          Noch keine Fahrzeuge in dieser Flotte. Füge zuerst ein Auto hinzu,
          damit deine freigegebenen Fahrer es auswählen können.
        </p>
      )}
      <Button variant="ghost" onClick={() => setShowArchive(!showArchive)}>
        {showArchive ? 'Archiv ausblenden' : 'Archivierte Autos anzeigen'}
      </Button>
      <Dialog
        open={!!release}
        onOpenChange={(v) => {
          if (!v) close();
        }}
      >
        <DialogContent className="fleet-vehicle-dialog" showCloseButton={!busy}>
          <DialogHeader>
            <DialogTitle>Fahrzeug freigeben?</DialogTitle>
            <DialogDescription>
              {release?.plate} ist {release?.driver_name} zugeordnet. Nach der
              Freigabe kann ein anderer Mitarbeiter dieser Flotte das Auto
              wählen. Das ist nur offline und ohne offene Fahrt oder Zahlung
              möglich.
            </DialogDescription>
          </DialogHeader>
          {error && (
            <p className="field-error" role="alert">
              {error}
            </p>
          )}
          <Button
            disabled={busy}
            onClick={() =>
              void save({
                action: 'release',
                id: release!.id,
                expectedDriverId: release!.driver_id,
              })
            }
          >
            Für die Flotte freigeben
          </Button>
          <Button variant="outline" disabled={busy} onClick={close}>
            Abbrechen
          </Button>
        </DialogContent>
      </Dialog>
      <Dialog
        open={open}
        onOpenChange={(v) => {
          if (!v) close();
        }}
      >
        <DialogContent className="fleet-vehicle-dialog" showCloseButton={!busy}>
          <DialogHeader>
            <DialogTitle>
              {editing ? 'Fahrzeug bearbeiten' : 'Neues Flottenfahrzeug'}
            </DialogTitle>
            <DialogDescription>
              Die Fahrzeugklassen bestimmen, welche Anfragen dieses Auto
              erhalten kann.
            </DialogDescription>
          </DialogHeader>
          <VehicleCreateForm
            fleetId={fleetId}
            model={model}
            setModel={setModel}
            plate={plate}
            setPlate={setPlate}
            services={services}
            setServices={setServices}
            busy={busy}
            loadingLatest={loadingLatest}
            error={error}
            editing={!!editing}
            onCancel={close}
            onReload={
              editing && conflict ? () => void reloadEditing() : undefined
            }
            onSave={(body) =>
              void save(
                editing
                  ? {
                      ...body,
                      id: editing.id,
                      expected: {
                        model: editing.model,
                        plate: editing.plate,
                        services: editing.services,
                      },
                    }
                  : body,
              )
            }
          />
        </DialogContent>
      </Dialog>
      <Dialog
        open={!!archive}
        onOpenChange={(v) => {
          if (!v) close();
        }}
      >
        <DialogContent className="fleet-vehicle-dialog" showCloseButton={!busy}>
          <DialogHeader>
            <DialogTitle>Fahrzeug aus der Flotte nehmen?</DialogTitle>
            <DialogDescription>
              {archive?.model} · {archive?.plate}. Frühere Fahrten und Umsätze
              bleiben erhalten. Der Fahrer muss offline sein und die letzte
              Fahrt abgerechnet haben.
            </DialogDescription>
          </DialogHeader>
          <label className="vehicle-archive-reason">
            Grund
            <select
              value={archiveReason}
              disabled={busy}
              onChange={(e) => setArchiveReason(e.target.value)}
            >
              <option>Verkauft</option>
              <option>Vorübergehend außer Betrieb</option>
              <option>Aus Flotte ausgeschieden</option>
            </select>
          </label>
          {error && (
            <p role="alert" className="field-error">
              {error}
            </p>
          )}
          <Button
            disabled={busy}
            onClick={() =>
              void save({
                action: 'archive',
                id: archive!.id,
                reason: archiveReason,
              })
            }
          >
            Archivieren
          </Button>
          <Button variant="outline" disabled={busy} onClick={close}>
            Abbrechen
          </Button>
        </DialogContent>
      </Dialog>
      <Dialog
        open={!!restore}
        onOpenChange={(v) => {
          if (!v) close();
        }}
      >
        <DialogContent className="fleet-vehicle-dialog" showCloseButton={!busy}>
          <DialogHeader>
            <DialogTitle>Fahrzeug wieder aktivieren?</DialogTitle>
            <DialogDescription>
              {restore?.model} · {restore?.plate}. Das Auto wird wieder für die
              Fahrer dieser Flotte auswählbar. Ein bereits aktives Kennzeichen
              kann nicht doppelt angelegt werden.
            </DialogDescription>
          </DialogHeader>
          {error && (
            <p role="alert" className="field-error">
              {error}
            </p>
          )}
          <Button
            disabled={busy}
            onClick={() => void save({ action: 'restore', id: restore!.id })}
          >
            Wieder aktivieren
          </Button>
          <Button variant="outline" disabled={busy} onClick={close}>
            Abbrechen
          </Button>
        </DialogContent>
      </Dialog>
    </section>
  );
}
