import type { Map } from 'mapbox-gl';

// Wait until the last gesture (including momentum) ends, never while a finger is held.
export function attachMapAutoReturn(
  map: Map,
  restore: () => void,
  pause: () => void,
) {
  const element = map.getContainer();
  const outside = element.ownerDocument.defaultView!;
  const pointers = new Set<number>();
  let timer: ReturnType<typeof setTimeout> | undefined;
  let pending = false;
  let disposed = false;
  function clear() {
    clearTimeout(timer);
    timer = undefined;
  }
  function reset() {
    clear();
    pending = false;
    if (!disposed) restore();
  }
  function schedule() {
    clear();
    if (disposed || !pending || pointers.size) return;
    timer = setTimeout(reset, 3000);
  }
  function interaction() {
    clear();
    pending = true;
    pause();
  }
  function down(event: PointerEvent) {
    pointers.add(event.pointerId);
    interaction();
  }
  function up(event: PointerEvent) {
    if (!pointers.delete(event.pointerId)) return;
    schedule();
  }
  function wheel() {
    interaction();
    schedule();
  }
  function key(event: KeyboardEvent) {
    if (
      [
        'ArrowUp',
        'ArrowDown',
        'ArrowLeft',
        'ArrowRight',
        '+',
        '-',
        '=',
        'Enter',
        ' ',
      ].includes(event.key)
    ) {
      interaction();
      schedule();
    }
  }
  function moving(event: { originalEvent?: unknown }) {
    if (event.originalEvent) interaction();
    // Momentum extends the delay, but our own return animation must not restart it.
    if (pending) schedule();
  }
  element.addEventListener('pointerdown', down, true);
  outside.addEventListener('pointerup', up, true);
  outside.addEventListener('pointercancel', up, true);
  element.addEventListener('wheel', wheel, { passive: true, capture: true });
  element.addEventListener('keydown', key, true);
  map.on('move', moving);
  map.on('moveend', schedule);
  return {
    reset,
    dispose() {
      disposed = true;
      clear();
      pointers.clear();
      element.removeEventListener('pointerdown', down, true);
      outside.removeEventListener('pointerup', up, true);
      outside.removeEventListener('pointercancel', up, true);
      element.removeEventListener('wheel', wheel, true);
      element.removeEventListener('keydown', key, true);
      map.off('move', moving);
      map.off('moveend', schedule);
    },
  };
}
