import { PhoneCall, Mail, Globe, MapPin } from 'lucide-react';
import { classes, money } from '@/lib/ride-domain';
export default function AppSupport() {
  return (
    <section className="app-support">
      <span className="app-kicker">PERSÖNLICH FÜR DICH DA</span>
      <h1>Wie können wir helfen?</h1>
      <p>Unser Team unterstützt dich bei deiner Fahrt.</p>
      <div className="app-support-links">
        <a href="tel:+491605083829">
          <PhoneCall />
          <span>
            <strong>Anrufen</strong>
            <small>+49 160 5083829</small>
          </span>
        </a>
        <a href="mailto:booking@luxoreride.de">
          <Mail />
          <span>
            <strong>E-Mail schreiben</strong>
            <small>booking@luxoreride.de</small>
          </span>
        </a>
        <a href="https://luxoreride.de" target="_blank" rel="noreferrer">
          <Globe />
          <span>
            <strong>Unsere Website</strong>
            <small>Leistungen und Unternehmensinformationen</small>
          </span>
        </a>
      </div>
      <div className="app-support-location">
        <MapPin size={18} /> Frankfurt am Main & Rhein-Main
      </div>
      <section className="app-tariff-list" aria-labelledby="app-tariffs">
        <h2 id="app-tariffs">Unsere Kilometerpreise</h2>
        {classes.map((item) => (
          <div key={item.id}>
            <span>{item.name}</span>
            <strong>
              {money(item.perKm)}
              <small> / km</small>
            </strong>
          </div>
        ))}
        <p>Mindestens 15 €. Deinen Fahrpreis siehst du vor der Buchung.</p>
      </section>
    </section>
  );
}
