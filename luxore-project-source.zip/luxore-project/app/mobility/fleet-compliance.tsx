'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from './api';
import Papers, { paperChip } from './papers';
import ProfilePhoto from './profile-photo';
import VehicleCheck, { inspectionChip } from './vehicle-check';
import type {
  InspectionState,
  PaperState,
  SubjectType,
} from '@/lib/mobility/compliance';

type Hold = { id: string; level: 'operator' | 'fleet'; reason: string; by: string; at: number };
type State = {
  enforcedSince: number | null;
  operator: boolean;
  fleet: { id: string; name: string; papers: PaperState[]; suspensions: Hold[] };
  vehicles: {
    id: string;
    model: string;
    plate: string;
    papers: PaperState[];
    inspection: InspectionState;
    suspensions: Hold[];
  }[];
  drivers: {
    id: string;
    name: string;
    approved: number;
    papers: PaperState[];
    profilePhotoId?: string | null;
    suspensions: Hold[];
  }[];
};
type History = {
  id: string;
  subject_type: SubjectType;
  subject_name: string | null;
  level: string;
  reason: string;
  created_by_name: string;
  created_at: number;
  lifted_by_name: string | null;
  lifted_at: number | null;
};
const when = (at: number) =>
  new Date(at).toLocaleString('de-DE', {
    timeZone: 'Europe/Berlin',
    dateStyle: 'short',
    timeStyle: 'short',
  });
const open = (papers: PaperState[]) =>
  papers.filter((p) => p.required && p.state !== 'approved').length;
/** One button to place a hold with a reason, one to lift it. */
export function HoldControl({
  subjectType,
  subjectId,
  holds,
  operator,
  onChanged,
}: {
  subjectType: SubjectType;
  subjectId: string;
  holds: Hold[];
  operator: boolean;
  onChanged: () => void;
}) {
  const [asking, setAsking] = useState(false),
    [reason, setReason] = useState(''),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const own = holds.find((h) => h.level === (operator ? 'operator' : 'fleet'));
  async function send(body: Record<string, unknown>) {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      await api('suspensions', body);
      setAsking(false);
      setReason('');
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="pf-form">
      {holds.map((h) => (
        <div className="pf-notice danger" key={h.id}>
          <strong>
            Gesperrt durch {h.level === 'operator' ? 'den Betreiber' : 'die Flottenleitung'}
          </strong>
          : {h.reason}
          <br />
          {h.by} · {when(h.at)}
          {(operator || h.level === 'fleet') && (
            <button
              type="button"
              className="pf-btn wide"
              style={{ marginTop: 8 }}
              disabled={busy}
              onClick={() => void send({ action: 'lift', id: h.id })}
            >
              Wieder freigeben
            </button>
          )}
        </div>
      ))}
      {error && (
        <p className="pf-error" role="alert">
          {error}
        </p>
      )}
      {!own &&
        (asking ? (
          <form
            className="pf-form"
            onSubmit={(e) => {
              e.preventDefault();
              void send({ action: 'suspend', subjectType, subjectId, reason });
            }}
          >
            <label className="pf-field">
              Grund der Sperre
              <input
                value={reason}
                required
                maxLength={200}
                placeholder="z. B. Schaden vorne rechts"
                onChange={(e) => setReason(e.target.value)}
              />
              <small>
                Eine laufende Fahrt wird nicht abgebrochen. Ohne laufende Fahrt
                endet die Schicht sofort.
              </small>
            </label>
            <div className="pf-actions">
              <button
                type="button"
                className="pf-btn"
                disabled={busy}
                onClick={() => setAsking(false)}
              >
                Abbrechen
              </button>
              <button type="submit" className="pf-btn danger" disabled={busy}>
                Jetzt sperren
              </button>
            </div>
          </form>
        ) : (
          <button type="button" className="pf-btn danger" onClick={() => setAsking(true)}>
            {subjectType === 'fleet' ? 'Ganze Flotte sperren' : 'Sperren'}
          </button>
        ))}
    </div>
  );
}
/** Fleet section "Prüfung": papers, weekly checks and holds of one fleet. */
export default function FleetCompliance({
  fleetId,
  focusVehicleId,
  focusDriverId,
  uploadsOnly,
}: {
  fleetId: string;
  /** Opens and scrolls to this vehicle or driver (page /pruefung). */
  focusVehicleId?: string | null;
  focusDriverId?: string | null;
  /** Papers and checks only: holds are shown, but not placed or lifted. */
  uploadsOnly?: boolean;
}) {
  const jumped = useRef(false);
  const jump = (node: HTMLDetailsElement | null) => {
    if (!node || jumped.current) return;
    jumped.current = true;
    node.scrollIntoView({ block: 'start' });
  };
  const hold = (
    subjectType: SubjectType,
    subjectId: string,
    holds: Hold[],
    operator: boolean,
  ) =>
    uploadsOnly ? (
      holds.map((h) => (
        <p className="pf-notice danger" key={h.id}>
          Gesperrt durch{' '}
          {h.level === 'operator' ? 'den Betreiber' : 'die Flottenleitung'}:{' '}
          {h.reason}
        </p>
      ))
    ) : (
      <HoldControl
        subjectType={subjectType}
        subjectId={subjectId}
        holds={holds}
        operator={operator}
        onChanged={load}
      />
    );
  const [data, setData] = useState<State | null>(null),
    [history, setHistory] = useState<History[]>([]),
    [error, setError] = useState('');
  const load = useCallback(async () => {
    try {
      const [state, holds] = await Promise.all([
        api<State>('compliance?scope=fleet&fleetId=' + encodeURIComponent(fleetId)),
        api<{ suspensions: History[] }>(
          'suspensions?fleetId=' + encodeURIComponent(fleetId),
        ),
      ]);
      setData(state);
      setHistory(holds.suspensions);
      setError('');
    } catch (e) {
      setError((e as Error).message);
    }
  }, [fleetId]);
  useEffect(() => {
    void load();
  }, [load]);
  if (!data) return <p className="pf-muted">{error || 'Prüfung wird geladen …'}</p>;
  const fleetOpen = open(data.fleet.papers);
  return (
    <div className="pf">
      {error && (
        <p className="pf-error" role="alert">
          {error}
        </p>
      )}
      <p className={'pf-notice' + (data.enforcedSince ? ' warn' : '')}>
        {data.enforcedSince
          ? `Prüfpflicht aktiv seit ${when(data.enforcedSince)}: Ohne geprüfte Pflichtpapiere und gültige Wochenkontrolle kann nicht online gegangen werden.`
          : 'Die Prüfpflicht ist noch nicht aktiv. Fehlende Papiere und Kontrollen sind derzeit nur Hinweise. Bitte jetzt vorbereiten.'}
      </p>
      <details open={!!fleetOpen || !!data.fleet.suspensions.length}>
        <summary>
          <span>
            Flotte · {data.fleet.name}
            <small>
              {fleetOpen ? `${fleetOpen} Pflichtpapier offen` : 'Papiere in Ordnung'}
            </small>
          </span>
        </summary>
        <div className="pf-details-body">
          <Papers subjectType="fleet" subjectId={data.fleet.id} onChanged={load} />
          {(data.operator || !!data.fleet.suspensions.length) &&
            (data.operator && !uploadsOnly ? (
              <HoldControl
                subjectType="fleet"
                subjectId={data.fleet.id}
                holds={data.fleet.suspensions}
                operator
                onChanged={load}
              />
            ) : (
              data.fleet.suspensions.map((h) => (
                <p className="pf-notice danger" key={h.id}>
                  Die Flotte ist durch den Betreiber gesperrt: {h.reason}
                </p>
              ))
            ))}
        </div>
      </details>
      <h4>Fahrzeuge</h4>
      {!data.vehicles.length && <p className="pf-muted">Keine aktiven Fahrzeuge.</p>}
      {data.vehicles.map((v) => {
        const chip = inspectionChip(v.inspection),
          missing = open(v.papers);
        return (
          <details
            key={v.id}
            open={v.id === focusVehicleId || undefined}
            ref={v.id === focusVehicleId ? jump : undefined}
          >
            <summary>
              <span>
                {v.model} · {v.plate}
                <span className="pf-chips">
                  {!!v.suspensions.length && <i className="pf-chip danger">gesperrt</i>}
                  <i className={'pf-chip ' + chip.tone}>{chip.text}</i>
                  {v.inspection.latestResult === 'defect' && (
                    <i className="pf-chip danger">Mangel gemeldet</i>
                  )}
                  <i className={'pf-chip ' + (missing ? 'danger' : 'good')}>
                    {missing ? `${missing} Papier${missing === 1 ? '' : 'e'} offen` : 'Papiere geprüft'}
                  </i>
                </span>
              </span>
            </summary>
            <div className="pf-details-body">
              {hold('vehicle', v.id, v.suspensions, data.operator)}
              <VehicleCheck vehicleId={v.id} onChanged={load} />
              <h4>Papiere</h4>
              <Papers subjectType="vehicle" subjectId={v.id} onChanged={load} />
            </div>
          </details>
        );
      })}
      <h4>Fahrer</h4>
      {!data.drivers.length && <p className="pf-muted">Noch keine Fahrer in dieser Flotte.</p>}
      {data.drivers.map((d) => {
        const missing = open(d.papers);
        const soon = d.papers
          .map(paperChip)
          .find((c) => c.tone === 'warn' && c.text.startsWith('läuft'));
        return (
          <details
            key={d.id}
            open={d.id === focusDriverId || undefined}
            ref={d.id === focusDriverId ? jump : undefined}
          >
            <summary>
              <span>
                {d.name}
                <span className="pf-chips">
                  {!!d.suspensions.length && <i className="pf-chip danger">gesperrt</i>}
                  {!d.approved && <i className="pf-chip warn">nicht freigegeben</i>}
                  <i className={'pf-chip ' + (missing ? 'danger' : 'good')}>
                    {missing ? `${missing} Papier${missing === 1 ? '' : 'e'} offen` : 'Papiere geprüft'}
                  </i>
                  {soon && <i className="pf-chip warn">{soon.text}</i>}
                  {!d.profilePhotoId && (
                    <i className="pf-chip danger">Profilbild fehlt</i>
                  )}
                </span>
              </span>
            </summary>
            <div className="pf-details-body">
              {hold('driver', d.id, d.suspensions, data.operator)}
              <ProfilePhoto
                driverId={d.id}
                name={d.name}
                photoId={d.profilePhotoId || null}
                onChanged={load}
              />
              <Papers subjectType="driver" subjectId={d.id} onChanged={load} />
            </div>
          </details>
        );
      })}
      {!uploadsOnly && !!history.length && (
        <details>
          <summary>
            <span>Verlauf der Sperren ({history.length})</span>
          </summary>
          <div className="pf-details-body">
            {history.map((h) => (
              <div className="pf-trip" key={h.id}>
                <span>
                  {h.subject_type === 'driver'
                    ? 'Fahrer'
                    : h.subject_type === 'vehicle'
                      ? 'Fahrzeug'
                      : 'Flotte'}{' '}
                  · {h.subject_name || '–'}
                </span>
                <b>{h.lifted_at ? 'aufgehoben' : 'aktiv'}</b>
                <small>
                  {h.reason} · gesperrt von {h.created_by_name} (
                  {h.level === 'operator' ? 'Betreiber' : 'Flottenleitung'}) am{' '}
                  {when(h.created_at)}
                  {h.lifted_at
                    ? ` · freigegeben von ${h.lifted_by_name} am ${when(h.lifted_at)}`
                    : ''}
                </small>
              </div>
            ))}
          </div>
        </details>
      )}
    </div>
  );
}
