'use client';
import {
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import { api } from './api';
import type { Booking } from '@/lib/mobility/domain';
import type { GpsFix } from './gps-quality';
import { currentGuidance, type Guidance } from './guidance-policy';
import { confirmedRecovery } from './route-recovery';
import { TrafficGuidanceSession } from './traffic-guidance-session';

function requestGuidance(
  bookingId: string,
  position: GpsFix,
  signal: AbortSignal,
) {
  return api<Guidance>('guidance', { bookingId, position }, signal);
}

export function useTrafficGuidance(
  booking: Booking | undefined,
  position: GpsFix | null,
  enabled: boolean,
  now: number,
) {
  const [online, setOnline] = useState(true);
  const latest = useRef(position);
  useEffect(() => {
    latest.current = position;
  }, [position]);
  const bookingId = booking?.id,
    phase = booking?.status;
  const session = useMemo(
    () =>
      new TrafficGuidanceSession(bookingId || '', phase || '', requestGuidance),
    [bookingId, phase],
  );
  const snapshot = useSyncExternalStore(
    session.subscribe,
    session.getSnapshot,
    session.getSnapshot,
  );
  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    update();
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    return () => {
      window.removeEventListener('online', update);
      window.removeEventListener('offline', update);
    };
  }, []);
  useEffect(() => {
    if (!enabled || !bookingId || (phase !== 'accepted' && phase !== 'riding'))
      return;
    session.resume();
    const update = () =>
      session.update(
        latest.current,
        navigator.onLine,
        document.visibilityState !== 'hidden',
      );
    update();
    const timer = setInterval(update, 3000);
    document.addEventListener('visibilitychange', update);
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    return () => {
      session.pause();
      clearInterval(timer);
      document.removeEventListener('visibilitychange', update);
      window.removeEventListener('online', update);
      window.removeEventListener('offline', update);
    };
  }, [bookingId, phase, enabled, session]);
  // Pausing requests for a menu must not replace the map route or reset maneuver progress.
  const route = currentGuidance(snapshot.value, bookingId, phase, now);
  return {
    route,
    online,
    pending:
      enabled &&
      snapshot.pendingSince !== null &&
      now - snapshot.pendingSince < 15000,
    recovery: confirmedRecovery(snapshot.recovery, route, now),
    failed: snapshot.failed,
    stale: snapshot.failed || !route,
  };
}
