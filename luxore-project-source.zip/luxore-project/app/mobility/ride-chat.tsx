'use client';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { MessageCircle } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { MobilityApiError, api } from './api';

// Mirrors lib/mobility/chat.ts, which is server-only.
const CHAT_BODY_MAX = 500;
type ChatMessage = { id: string; mine: boolean; body: string; created_at: number };
type ChatFeed = { serverTime: number; open?: boolean; messages: ChatMessage[] };
/** Window open: every 4 s. Closed: every 15 s, for the counter only. */
const OPEN_POLL_MS = 4000;
const CLOSED_POLL_MS = 15000;
// Read mark per ride for this page session, so the counter survives remounts.
const seenByBooking = new Map<string, number>();
const clock = (at: number) =>
  new Date(at).toLocaleTimeString('de-DE', {
    hour: '2-digit',
    minute: '2-digit',
  });

/**
 * Chat between rider and chauffeur of one ride (server: /api/mobility/chat).
 * A button with the unread counter; a tap opens the conversation.
 * `onIncoming` reports a new foreign message while the window is closed.
 */
export default function RideChat({
  bookingId,
  active,
  title,
  label,
  onIncoming,
}: {
  bookingId: string;
  /** true while the ride is accepted, arrived or riding. */
  active: boolean;
  title: string;
  label: string;
  onIncoming?: (text: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [unread, setUnread] = useState(0);
  const [available, setAvailable] = useState(true);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const store = useRef<ChatMessage[]>([]);
  const cursor = useRef(0);
  const loaded = useRef(false);
  const openRef = useRef(open);
  const incoming = useRef(onIncoming);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => {
    openRef.current = open;
    incoming.current = onIncoming;
  });

  const merge = (fresh: ChatMessage[]) => {
    const known = new Set(store.current.map((m) => m.id));
    const added = fresh.filter((m) => m && !known.has(m.id));
    if (added.length) {
      store.current = [...store.current, ...added].sort(
        (a, b) => a.created_at - b.created_at,
      );
      setMessages(store.current);
    }
    return added;
  };
  const count = () => {
    const last = store.current.at(-1)?.created_at ?? 0;
    if (openRef.current) {
      seenByBooking.set(bookingId, last);
      setUnread(0);
    } else {
      const seen = seenByBooking.get(bookingId) ?? 0;
      setUnread(
        store.current.filter((m) => !m.mine && m.created_at > seen).length,
      );
    }
  };

  useEffect(() => {
    store.current = [];
    cursor.current = 0;
    loaded.current = false;
    setMessages([]);
    setUnread(0);
    setDraft('');
    setError('');
  }, [bookingId]);

  useEffect(() => {
    if (!active) return;
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout> | undefined;
    const load = async () => {
      try {
        const feed = await api<ChatFeed>(
          `chat?bookingId=${encodeURIComponent(bookingId)}&after=${cursor.current}`,
          undefined,
          controller.signal,
        );
        setAvailable(true);
        const added = merge(feed.messages || []);
        for (const m of feed.messages || [])
          cursor.current = Math.max(cursor.current, m.created_at);
        if (loaded.current && !openRef.current) {
          const foreign = added.filter((m) => !m.mine).at(-1);
          if (foreign) incoming.current?.(foreign.body);
        }
        loaded.current = true;
        count();
      } catch (e) {
        if (controller.signal.aborted) return;
        // An older server without the chat: the window says so, nothing breaks.
        if (
          e instanceof MobilityApiError &&
          (e.status === 404 || e.status === 503)
        )
          setAvailable(false);
      }
      if (!controller.signal.aborted)
        timer = setTimeout(
          load,
          openRef.current ? OPEN_POLL_MS : CLOSED_POLL_MS,
        );
    };
    void load();
    return () => {
      controller.abort();
      clearTimeout(timer);
    };
    // Reopening restarts the loop at the faster pace.
    // oxlint-disable-next-line react-hooks/exhaustive-deps
  }, [active, bookingId, open]);

  useEffect(() => {
    if (open) end.current?.scrollIntoView({ block: 'end' });
  }, [open, messages]);

  if (!active) return null;
  const text = draft.trim().slice(0, CHAT_BODY_MAX);
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!text || sending || !available) return;
    setSending(true);
    setError('');
    try {
      const sent = await api<{ message: ChatMessage }>('chat', {
        bookingId,
        body: text,
      });
      merge([sent.message]);
      setDraft('');
      count();
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : 'Die Nachricht wurde nicht gesendet. Bitte erneut versuchen.',
      );
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      <button
        type="button"
        className="ride-chat-button"
        onClick={() => setOpen(true)}
        aria-label={
          unread
            ? `${label}. ${unread} ungelesene ${unread === 1 ? 'Nachricht' : 'Nachrichten'}.`
            : label
        }
      >
        <MessageCircle size={19} aria-hidden="true" />
        <span>{label}</span>
        {unread > 0 && (
          <b className="ride-chat-badge" aria-hidden="true">
            {unread > 99 ? '99+' : unread}
          </b>
        )}
      </button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="ride-chat-dialog">
          <DialogHeader>
            <DialogTitle>{title}</DialogTitle>
            <DialogDescription>
              Die Nachricht läuft über LUXORÉ. Deine Telefonnummer bleibt
              privat.
            </DialogDescription>
          </DialogHeader>
          <div className="ride-chat-list" aria-live="polite">
            {!available ? (
              <p className="ride-chat-empty">
                Der Chat ist auf diesem Server noch nicht verfügbar.
              </p>
            ) : messages.length === 0 ? (
              <p className="ride-chat-empty">
                Noch keine Nachrichten. Schreib kurz, was wichtig ist – zum
                Beispiel, wo genau du wartest.
              </p>
            ) : (
              messages.map((m) => (
                <p key={m.id} className="ride-chat-bubble" data-mine={m.mine}>
                  <span>{m.body}</span>
                  <small>{clock(m.created_at)}</small>
                </p>
              ))
            )}
            <div ref={end} />
          </div>
          {error && (
            <p className="ride-chat-error" role="alert">
              {error}
            </p>
          )}
          <form className="ride-chat-compose" onSubmit={submit}>
            <label className="sr-only" htmlFor={'chat-' + bookingId}>
              Deine Nachricht
            </label>
            <textarea
              id={'chat-' + bookingId}
              value={draft}
              maxLength={CHAT_BODY_MAX}
              rows={2}
              placeholder="Deine Nachricht"
              disabled={!available}
              onChange={(e) => {
                setDraft(e.target.value);
                if (error) setError('');
              }}
            />
            <button type="submit" disabled={!text || sending || !available}>
              {sending ? 'Sendet …' : 'Senden'}
            </button>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
