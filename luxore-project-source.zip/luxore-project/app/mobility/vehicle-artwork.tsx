'use client';
/* oxlint-disable jsx-a11y/prefer-tag-over-role -- Inline SVG needs an image role; HTML img cannot contain its paths. */
import Image from 'next/image';
import { useId } from 'react';
import { vehicleArtwork } from '@/lib/mobility/vehicle-artwork';
export default function VehicleArtwork({
  model,
  className = '',
}: {
  model: string;
  className?: string;
}) {
  const art = vehicleArtwork(model);
  const id = useId().replaceAll(':', '');
  const css = 'vehicle-artwork ' + className;
  if (art.image)
    return (
      <Image
        className={css}
        src={art.image}
        alt={'Modellabbildung: ' + art.label}
        width={260}
        height={160}
        unoptimized
      />
    );
  const tall = art.body === 'van' || art.body === 'suv';
  const roof =
    art.body === 'van'
      ? 'M46 98L55 53Q58 44 70 44H183Q195 44 206 64L229 99'
      : art.body === 'suv' || art.body === 'wagon'
        ? 'M40 99L59 66Q64 53 83 53H169Q181 53 202 81L231 99'
        : art.body === 'coupe'
          ? 'M40 99L79 74Q103 51 140 60Q166 65 199 91L231 99'
          : 'M40 99L66 87Q87 56 112 56H150Q168 56 198 88L231 99';
  const tint = ['#202a34', '#252526', '#283437', '#2d2d37'][art.seed % 4];
  const wheel = (x: number) => (
    <g transform={`translate(${x} 112)`}>
      <circle r="20" fill="#161a1f" />
      <circle r="13" fill="#8b949e" />
      <circle r="10" fill="#343c45" />
      {[0, 72, 144, 216, 288].map((a) => (
        <path
          key={a}
          transform={`rotate(${a})`}
          d="M-2-3L-1-11H2L3-3Z"
          fill="#ced3d8"
        />
      ))}
      <circle r="3" fill="#acb3bb" />
    </g>
  );
  return (
    <svg
      className={css}
      viewBox="0 0 260 160"
      role="img"
      aria-labelledby={id + '-title'}
    >
      <title
        id={id + '-title'}
      >{`Schematische Fahrzeugdarstellung: ${art.label}`}</title>
      <defs>
        <linearGradient id={id + '-body'} x2="0" y2="1">
          <stop stopColor="#78828a" />
          <stop offset=".35" stopColor={tint} />
          <stop offset=".8" stopColor="#11181f" />
          <stop offset="1" stopColor="#414b54" />
        </linearGradient>
        <linearGradient id={id + '-glass'} x2="0" y2="1">
          <stop stopColor="#929eaa" />
          <stop offset="1" stopColor="#263341" />
        </linearGradient>
      </defs>
      <ellipse cx="132" cy="139" rx="108" ry="5" fill="#111820" opacity=".12" />
      <path
        d={roof}
        fill={`url(#${id}-body)`}
        stroke="#68747e"
        strokeWidth="1.5"
      />
      <path
        d={
          tall
            ? 'M65 59H167L190 87H61Z'
            : 'M90 71Q101 62 114 62H148Q160 62 184 88H78Z'
        }
        fill={`url(#${id}-glass)`}
        stroke="#a6afb7"
      />
      <path d="M124 58V95M164 71L176 94" stroke="#202a34" strokeWidth="4" />
      <path
        d="M25 97Q33 90 58 90H198L235 100Q243 102 243 110V120H216Q211 88 193 89Q172 89 168 121H83Q80 88 61 89Q43 89 38 119H22V105Q22 101 25 97Z"
        fill={`url(#${id}-body)`}
        stroke="#46525e"
      />
      <path
        d="M32 103L41 100H217L233 105M86 117H164"
        fill="none"
        stroke="#a5afb7"
        strokeWidth="1"
        opacity=".65"
      />
      <path d="M111 95V121M176 95L169 116" stroke="#141c24" />
      <path d="M122 100H136M181 99H190" stroke="#b4bdc6" strokeWidth="2" />
      <path d="M225 99L239 103V108L225 105Z" fill="#e1e9ed" />
      <path d="M24 99H35V106H23Z" fill="#8c332e" />
      {wheel(61)}
      {wheel(193)}
      <text
        x="130"
        y="155"
        textAnchor="middle"
        fontFamily="sans-serif"
        fontSize="9"
        letterSpacing="1"
        fill="#65717c"
      >
        {art.label.toUpperCase().slice(0, 22)}
      </text>
    </svg>
  );
}
