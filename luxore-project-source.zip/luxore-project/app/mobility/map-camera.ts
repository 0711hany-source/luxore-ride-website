import { distanceMeters } from './gps-quality.ts';
type Position = { lat: number; lng: number };
export function bearingBetween(from: Position, to: Position) {
  const rad = Math.PI / 180;
  const y = Math.sin((to.lng - from.lng) * rad) * Math.cos(to.lat * rad);
  const x =
    Math.cos(from.lat * rad) * Math.sin(to.lat * rad) -
    Math.sin(from.lat * rad) *
      Math.cos(to.lat * rad) *
      Math.cos((to.lng - from.lng) * rad);
  return (Math.atan2(y, x) / rad + 360) % 360;
}
export function drivingHeading(
  anchor: Position | null,
  next: Position,
  accuracy: number,
  previous: number | null,
) {
  if (!anchor) return { anchor: next, bearing: previous };
  // Accumulate small real movements; holding still must not spin the map.
  const threshold = Math.max(
    15,
    Math.min(100, Number.isFinite(accuracy) ? accuracy * 1.2 : 36),
  );
  if (distanceMeters(anchor, next) < threshold)
    return { anchor, bearing: previous };
  const target = bearingBetween(anchor, next);
  const delta = previous === null ? 0 : ((target - previous + 540) % 360) - 180;
  return {
    anchor: next,
    bearing: previous === null ? target : (previous + delta * 0.6 + 360) % 360,
  };
}
export function drivingCameraInsets(
  height: number,
  bottomInset = 0,
  topInset = 0,
) {
  const h = Math.max(1, height);
  const bottom = Math.max(0, Math.min(bottomInset + 20, h * 0.72));
  const visible = h - bottom;
  const top = Math.max(
    Math.min(115, visible * 0.32),
    Math.min(topInset, visible * 0.65),
  );
  // jumpTo has no animation offset. Encode the same lower-screen anchor in padding
  // for every frame, including recentering, so the arrow never hops vertically.
  const lookAhead = Math.min(65, (visible - top) * 0.18);
  return { padding: { top: top + lookAhead * 2, bottom, left: 24, right: 24 } };
}
