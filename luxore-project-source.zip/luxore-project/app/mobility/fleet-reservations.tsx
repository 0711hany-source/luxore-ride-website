'use client';
import { useCallback, useEffect, useState } from 'react';
import { api } from './api';
import { RatingBadge } from './rating';
import { money } from '@/lib/ride-domain';
import type { StaffReservation } from '@/lib/mobility/reservations';

type State = { operator: boolean; reservations: StaffReservation[] };
const when = (at: number) =>
  new Date(at).toLocaleString('de-DE', {
    timeZone: 'Europe/Berlin',
    weekday: 'short',
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  }) + ' Uhr';
/** Disposition: who has taken which reservation; lifting an assignment. */
export default function FleetReservations() {
  const [data, setData] = useState<State | null>(null),
    [error, setError] = useState(''),
    [saved, setSaved] = useState(''),
    [confirm, setConfirm] = useState<string | null>(null),
    [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    try {
      setData(await api<State>('reservations?scope=staff'));
      setError('');
    } catch (e) {
      setError((e as Error).message);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  async function unassign(id: string) {
    setBusy(true);
    setSaved('');
    try {
      await api('reservations', { action: 'unassign', id });
      setConfirm(null);
      setSaved('Zuteilung aufgehoben. Die Reservierung ist wieder offen.');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      await load();
      setBusy(false);
    }
  }
  return (
    <div className="pf">
      <div className="pf-row">
        <h3>Reservierungen und Fahrer</h3>
        <button type="button" className="pf-btn" onClick={() => void load()}>
          Aktualisieren
        </button>
      </div>
      <p className="pf-muted">
        {data?.operator
          ? 'Alle kommenden Reservierungen: offen oder von einem Fahrer übernommen.'
          : 'Reservierungen, die Fahrer deiner Flotte übernommen haben.'}{' '}
        Eine Zuteilung kannst du jederzeit aufheben; die Reservierung ist dann
        wieder offen.
      </p>
      {error && (
        <p className="pf-error" role="alert">
          {error}
        </p>
      )}
      {saved && (
        <p className="pf-saved" role="status">
          {saved}
        </p>
      )}
      <div className="pf-list">
        {!data && !error && (
          <p className="pf-muted">Reservierungen werden geladen …</p>
        )}
        {data && !data.reservations.length && (
          <p className="pf-muted">
            {data.operator
              ? 'Es gibt keine kommenden Reservierungen.'
              : 'Zurzeit hat kein Fahrer deiner Flotte eine Reservierung übernommen.'}
          </p>
        )}
        {data?.reservations.map((r) => (
          <article
            key={r.id}
            className={'pf-card' + (r.assigned?.check ? ' attention' : '')}
          >
            <div className="pf-row">
              <strong>{when(r.scheduledAt)}</strong>
              <span
                className={
                  'pf-chip ' +
                  (r.assigned?.check ? 'danger' : r.assigned ? 'good' : 'warn')
                }
              >
                {r.assigned?.check
                  ? 'Zuteilung prüfen'
                  : r.assigned
                    ? 'übernommen'
                    : 'offen'}
              </span>
            </div>
            {r.assigned?.check && (
              <p className="pf-notice warn" role="status">
                {r.assigned.check} Die Zuteilung bleibt bestehen, bis du sie
                aufhebst. Ohne Klärung geht die Fahrt 15 Minuten vor der
                Abholung in die normale Suche.
              </p>
            )}
            <div className="pf-route">
              <strong>{r.pickup}</strong>
              <span>nach {r.destination}</span>
            </div>
            <dl className="pf-facts">
              <div>
                <dt>Klasse · Preis</dt>
                <dd>
                  {r.className} · {money(r.price)}
                </dd>
              </div>
              <div>
                <dt>Fahrgast</dt>
                <dd>
                  {r.riderName || 'Fahrgast'}{' '}
                  <RatingBadge
                    rating={r.riderRating}
                    emptyLabel="ohne Bewertung"
                  />
                </dd>
              </div>
              {r.assigned && (
                <>
                  <div>
                    <dt>Fahrer</dt>
                    <dd>
                      {r.assigned.driverName}
                      {r.assigned.fleetName ? ' · ' + r.assigned.fleetName : ''}
                    </dd>
                  </div>
                  <div>
                    <dt>Fahrzeug · übernommen</dt>
                    <dd>
                      {[r.assigned.vehicle, r.assigned.plate]
                        .filter(Boolean)
                        .join(' · ') || '–'}{' '}
                      · {when(r.assigned.at)}
                    </dd>
                  </div>
                </>
              )}
            </dl>
            {r.assigned &&
              (confirm === r.id ? (
                <div className="pf-actions">
                  <button
                    type="button"
                    className="pf-btn danger"
                    disabled={busy}
                    onClick={() => void unassign(r.id)}
                  >
                    Ja, Zuteilung aufheben
                  </button>
                  <button
                    type="button"
                    className="pf-btn"
                    disabled={busy}
                    onClick={() => setConfirm(null)}
                  >
                    Abbrechen
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  className="pf-btn wide"
                  onClick={() => setConfirm(r.id)}
                >
                  Zuteilung aufheben
                </button>
              ))}
          </article>
        ))}
      </div>
    </div>
  );
}
