import type { NativeStatus } from './native-location';

/** Invalidate requests at both ends of a shift transition, and when its view is disposed. */
export class NativeStatusRequests {
  private revision = 0;
  private request = 0;

  invalidate() {
    this.revision++;
  }

  async read<T>(work: () => Promise<T>, apply: (value: T) => void) {
    const revision = this.revision;
    const request = ++this.request;
    const value = await work();
    if (revision === this.revision && request === this.request) apply(value);
  }
}

export function matchesNativeShift(
  status: NativeStatus,
  currentSession: string | null,
  serverSession: string | null | undefined,
  now: number,
) {
  const expected = currentSession || serverSession;
  return Boolean(
    expected &&
    status.active &&
    status.sessionId === expected &&
    (status.expiresAt === undefined ||
      (Number.isFinite(status.expiresAt) && status.expiresAt > now)),
  );
}
