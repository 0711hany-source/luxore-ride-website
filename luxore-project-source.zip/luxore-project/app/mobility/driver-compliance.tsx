'use client';
import { useCallback, useEffect, useState } from 'react';
import { api } from './api';
import Papers from './papers';
import VehicleCheck from './vehicle-check';
import ProfilePhoto from './profile-photo';
import type { DriverCompliance as Compliance } from '@/lib/mobility/compliance';

type State = {
  enforcedSince: number | null;
  driver: Compliance | null;
  profilePhotoId?: string | null;
};
/** Driver app: what is needed before the shift — papers and weekly check. */
export default function DriverCompliance({
  driverId,
  driverName,
  vehicleId,
  focus,
}: {
  driverId: string;
  driverName?: string;
  vehicleId: string | null;
  /** Opens this section right away (jump target of the page /pruefung). */
  focus?: 'papiere' | 'kontrolle' | null;
}) {
  const [data, setData] = useState<State | null>(null);
  const load = useCallback(async () => {
    try {
      setData(await api<State>('compliance'));
    } catch {}
  }, []);
  useEffect(() => {
    void load();
  }, [load, vehicleId]);
  const d = data?.driver;
  const stops = d ? [...d.holds, ...(data!.enforcedSince ? d.requirements : [])] : [];
  const hints = d ? [...(data!.enforcedSince ? [] : d.requirements), ...d.warnings] : [];
  return (
    <div className="pf">
      <h3>Vor der Schicht</h3>
      {!!stops.length && (
        <div className="pf-notice danger" role="alert">
          <strong>Online gehen ist gerade nicht möglich:</strong>
          <ul>
            {stops.map((s) => (
              <li key={s}>{s}</li>
            ))}
          </ul>
        </div>
      )}
      {!!hints.length && (
        <div className="pf-notice warn">
          <strong>
            {data?.enforcedSince ? 'Bitte bald erledigen:' : 'Bitte erledigen:'}
          </strong>
          <ul>
            {hints.map((s) => (
              <li key={s}>{s}</li>
            ))}
          </ul>
        </div>
      )}
      {d && !stops.length && !hints.length && (
        <p className="pf-notice good">Papiere und Wochenkontrolle sind in Ordnung.</p>
      )}
      {vehicleId ? (
        <details
          open={
            focus ? focus === 'kontrolle' : d?.inspection?.state !== 'ok'
          }
        >
          <summary>
            <span>Wochenkontrolle des Fahrzeugs</span>
          </summary>
          <div className="pf-details-body">
            <VehicleCheck key={vehicleId} vehicleId={vehicleId} onChanged={load} />
          </div>
        </details>
      ) : (
        <p className="pf-muted">
          Wähle zuerst ein Fahrzeug, um die Wochenkontrolle durchzuführen.
        </p>
      )}
      <details
        open={
          focus === 'papiere' ||
          (data && !data.profilePhotoId) ||
          undefined
        }
      >
        <summary>
          <span>
            Meine Papiere
            {data && !data.profilePhotoId && <small>Profilbild fehlt</small>}
          </span>
        </summary>
        <div className="pf-details-body">
          {data && (
            <ProfilePhoto
              driverId={driverId}
              name={driverName || ''}
              photoId={data.profilePhotoId || null}
              onChanged={load}
            />
          )}
          <Papers subjectType="driver" subjectId={driverId} onChanged={load} />
        </div>
      </details>
    </div>
  );
}
