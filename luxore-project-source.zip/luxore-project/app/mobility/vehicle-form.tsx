'use client';
import { useState, type Dispatch, type SetStateAction } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { classes } from '@/lib/ride-domain';
import type { Service } from '@/lib/mobility/domain';
import {
  validateVehicleInput,
  type VehicleErrors,
  type VehicleInput,
} from '@/lib/mobility/vehicle-input';
export function VehicleCreateForm({
  fleetId,
  model,
  setModel,
  plate,
  setPlate,
  services,
  setServices,
  busy,
  loadingLatest = false,
  error,
  onSave,
  editing = false,
  onCancel,
  onReload,
}: {
  fleetId: string;
  model: string;
  setModel: (v: string) => void;
  plate: string;
  setPlate: (v: string) => void;
  services: Service[];
  setServices: Dispatch<SetStateAction<Service[]>>;
  busy: boolean;
  loadingLatest?: boolean;
  error: string;
  editing?: boolean;
  onCancel?: () => void;
  onReload?: () => void;
  onSave: (body: VehicleInput & { action: string; fleetId: string }) => void;
}) {
  const [errors, setErrors] = useState<VehicleErrors>({});
  return (
    <form
      className="vehicle-form"
      noValidate
      onSubmit={(e) => {
        e.preventDefault();
        if (busy) return;
        const checked = validateVehicleInput({ model, plate, services });
        setErrors(checked.errors);
        if (!checked.value) {
          const field = Object.keys(checked.errors)[0];
          e.currentTarget
            .querySelector<HTMLElement>(`[data-field="${field}"]`)
            ?.focus();
          return;
        }
        onSave({
          action: editing ? 'update' : 'create',
          fleetId,
          ...checked.value,
        });
      }}
    >
      <div className="vehicle-form-fields">
        <label htmlFor={'model-' + fleetId}>
          Modell
          <Input
            id={'model-' + fleetId}
            data-field="model"
            value={model}
            disabled={busy}
            onChange={(e) => setModel(e.target.value)}
            required
            maxLength={80}
            aria-invalid={!!errors.model}
            aria-describedby={
              errors.model ? 'model-error-' + fleetId : undefined
            }
            autoComplete="off"
            placeholder="Mercedes-Benz E-Klasse"
          />
          {errors.model && (
            <span
              id={'model-error-' + fleetId}
              className="field-error"
              role="alert"
            >
              {errors.model}
            </span>
          )}
        </label>
        <label htmlFor={'plate-' + fleetId}>
          Kennzeichen
          <Input
            id={'plate-' + fleetId}
            data-field="plate"
            value={plate}
            disabled={busy}
            autoCapitalize="characters"
            autoComplete="off"
            spellCheck={false}
            onChange={(e) => setPlate(e.target.value)}
            required
            maxLength={20}
            aria-invalid={!!errors.plate}
            aria-describedby={
              errors.plate ? 'plate-error-' + fleetId : undefined
            }
            placeholder="F LR 123"
          />
          {errors.plate && (
            <span
              id={'plate-error-' + fleetId}
              className="field-error"
              role="alert"
            >
              {errors.plate}
            </span>
          )}
        </label>
        <fieldset disabled={busy} className="vehicle-service-options">
          <legend>Freigegebene Klassen</legend>
          <p>Mehrere Klassen sind möglich.</p>
          {classes.map((c) => (
            <label
              htmlFor={fleetId + c.id}
              className={
                'vehicle-service-choice ' +
                (services.includes(c.id) ? 'is-selected' : '')
              }
              key={c.id}
            >
              <Checkbox
                id={fleetId + c.id}
                data-field="services"
                checked={services.includes(c.id)}
                onCheckedChange={(checked) =>
                  setServices((s) =>
                    checked
                      ? [...new Set([...s, c.id])]
                      : s.filter((v) => v !== c.id),
                  )
                }
              />
              <span>
                <strong>{c.name}</strong>
                <small>{c.detail}</small>
              </span>
            </label>
          ))}
        </fieldset>
        {(errors.services || !services.length) && (
          <p className="field-error" role="alert">
            {errors.services || 'Bitte mindestens eine Fahrzeugklasse wählen.'}
          </p>
        )}
        {error && (
          <div className="vehicle-save-error">
            <p role="alert" className="field-error">
              {error}
            </p>
            {onReload && (
              <>
                <p>
                  Beim Laden werden deine ungespeicherten Eingaben durch die
                  aktuellen Fahrzeugdaten ersetzt.
                </p>
                <Button
                  type="button"
                  variant="outline"
                  disabled={busy}
                  onClick={() => {
                    setErrors({});
                    onReload();
                  }}
                >
                  Aktuelle Daten laden
                </Button>
              </>
            )}
          </div>
        )}
      </div>
      <div className="vehicle-form-actions">
        <Button type="submit" disabled={busy}>
          {busy
            ? loadingLatest
              ? 'Daten werden geladen …'
              : 'Wird gespeichert …'
            : editing
              ? 'Änderungen speichern'
              : 'Fahrzeug hinzufügen'}
        </Button>
        {onCancel && (
          <Button
            type="button"
            variant="ghost"
            disabled={busy}
            onClick={onCancel}
          >
            Abbrechen
          </Button>
        )}
      </div>
    </form>
  );
}
