/** Mapbox reports individual tile failures as errors too; they are not fatal map failures. */
export function mapErrorMessage(error: unknown) {
  const status = (error as { status?: number } | undefined)?.status;
  if (status === 401 || status === 403)
    return {
      message:
        'Kartenzugriff abgelehnt. Die Kartenfreigabe muss geprüft werden.',
      retry: false,
    };
  if (status === 429)
    return {
      message: 'Kartendienst momentan ausgelastet. Bitte kurz warten.',
      retry: false,
    };
  return {
    message: 'Kartenverbindung unterbrochen. Erneuter Verbindungsversuch …',
    retry: true,
  };
}
