'use client';
import Image from 'next/image';
import { ArrowRight, CreditCard, Check, Wifi, Sparkles } from 'lucide-react';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Button } from '@/components/ui/button';
import {
  BUSY_HINT,
  BUSY_LABEL,
  classes,
  className,
  isOnRequest,
  money,
  ON_REQUEST_HINT,
  ON_REQUEST_LABEL,
} from '@/lib/ride-domain';
import type { Service } from '@/lib/mobility/domain';

export default function ClassPicker({
  prices,
  service,
  onChange,
  onContinue,
  disabled = false,
  availability,
}: {
  // Immediate rides only: is a free chauffeur of the class online right now?
  availability?: Record<Service, boolean>;
  prices: Record<Service, number>;
  service: Service;
  onChange: (s: Service) => void;
  onContinue: () => void;
  disabled?: boolean;
}) {
  // „besetzt“ never blocks the choice: the request can still be sent.
  const busy = (id: Service) =>
    !isOnRequest(id) && !!availability && availability[id] === false;
  const hint = isOnRequest(service)
    ? ON_REQUEST_HINT
    : busy(service)
      ? BUSY_HINT
      : '';
  // A busy or on-request class is only ever a request until a chauffeur accepts.
  const actionVerb = isOnRequest(service) || busy(service) ? 'anfragen' : 'buchen';
  return (
    <div className="ride-class-picker">
      <div className="picker-header">
        <span className="app-kicker">FAHRZEUGKLASSE</span>
        <h2>Wähle deinen Komfort</h2>
      </div>

      <RadioGroup
        value={service}
        onValueChange={(v) => onChange(v as Service)}
        className="ride-class-list"
      >
        {classes.map((c) => {
          const isSelected = service === c.id;
          return (
            <label
              key={c.id}
              htmlFor={'ride-class-' + c.id}
              className={'ride-class ' + (isSelected ? 'selected' : '')}
            >
              <RadioGroupItem id={'ride-class-' + c.id} value={c.id} className="sr-only" />
              <div className="ride-class-vehicle-visual">
                <Image
                  src={c.image}
                  width={112}
                  height={72}
                  unoptimized
                  alt={c.name}
                  className="vehicle-img"
                />
              </div>

              <div className="ride-class-content">
                <div className="ride-class-headline">
                  <div className="class-name-box">
                    <strong>{c.name}</strong>
                    {c.id === 'first' && (
                      <span className="class-luxury-badge">
                        <Sparkles size={11} /> Flaggschiff
                      </span>
                    )}
                    {c.onRequest ? (
                      <span className="class-state-chip">
                        {ON_REQUEST_LABEL}
                      </span>
                    ) : (
                      busy(c.id) && (
                        <span className="class-state-chip">{BUSY_LABEL}</span>
                      )
                    )}
                  </div>
                  <span className="ride-class-price">
                    {prices[c.id] ? money(prices[c.id]) : '—'}
                  </span>
                </div>

                <span className="ride-class-model">{c.detail}</span>

                <div className="ride-class-tags">
                  <span className="tag-capacity">{c.capacity}</span>
                  <span className="tag-feature">
                    <Wifi size={11} /> Highspeed WLAN
                  </span>
                </div>
              </div>

              <div className="ride-class-check">
                <Check size={16} strokeWidth={2.5} />
              </div>
            </label>
          );
        })}
      </RadioGroup>
      {hint && (
        <p className="class-state-hint" role="status">
          {hint}
        </p>
      )}

      <div className="ride-payment-line">
        <CreditCard size={18} />
        <div>
          <span>Zahlung beim Chauffeur</span>
          <small>Bargeldlos per Terminal oder Bar</small>
        </div>
      </div>

      <Button
        className="primary-action"
        disabled={disabled}
        onClick={onContinue}
      >
        <span>{className(service)} {actionVerb}</span>
        <span className="action-price-cta">
          {prices[service] ? money(prices[service]) : ''}
          <ArrowRight size={19} />
        </span>
      </Button>
    </div>
  );
}
