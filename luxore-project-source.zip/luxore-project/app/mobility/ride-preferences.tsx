'use client';
import { Thermometer, VolumeX, Music2, SlidersHorizontal } from 'lucide-react';
import {
  preferenceOptions,
  preferenceLabels,
  type RidePreferences,
} from '@/lib/mobility/ride-preferences';
const groups = [
  { key: 'temperature', title: 'Temperatur', icon: Thermometer },
  { key: 'conversation', title: 'Unterhaltung', icon: VolumeX },
  { key: 'music', title: 'Musik', icon: Music2 },
] as const;
export function RidePreferencesPicker({
  value,
  onChange,
}: {
  value: RidePreferences;
  onChange: (value: RidePreferences) => void;
}) {
  return (
    <details className="ride-preferences-picker">
      <summary>
        <SlidersHorizontal size={19} />
        <span>
          Fahrtwünsche
          <small>
            {preferenceLabels(value).join(' · ') ||
              'Optional · so fährst du am liebsten'}
          </small>
        </span>
      </summary>
      <RidePreferencesFields value={value} onChange={onChange} />
      <p>Dein Fahrer erhält die Wünsche mit der Fahrtanfrage.</p>
    </details>
  );
}
export function RidePreferencesFields({
  value,
  onChange,
}: {
  value: RidePreferences;
  onChange: (value: RidePreferences) => void;
}) {
  return (
    <div className="ride-preferences-picker ride-preferences-fields">
      {' '}
      {groups.map(({ key, title, icon: Icon }) => (
        <fieldset key={key}>
          <legend>
            <Icon size={16} />
            {title}
          </legend>
          <div>
            {Object.entries(preferenceOptions[key]).map(([option, label]) => (
              <button
                key={option}
                type="button"
                aria-pressed={value[key] === option}
                onClick={() => onChange({ ...value, [key]: option })}
              >
                {label}
              </button>
            ))}
          </div>
        </fieldset>
      ))}
    </div>
  );
}
export function RidePreferencesSummary({
  value,
}: {
  value?: RidePreferences | null;
}) {
  const labels = preferenceLabels(value);
  return labels.length ? (
    <div className="ride-preferences-summary ride-preferences-vip">
      <div className="vip-kicker-line">
        <SlidersHorizontal size={14} />
        <span>VIP GASTWÜNSCHE</span>
      </div>
      <div className="vip-chips">
        {labels.map((lbl, idx) => (
          <span key={idx} className="vip-chip">
            {lbl}
          </span>
        ))}
      </div>
    </div>
  ) : null;
}
