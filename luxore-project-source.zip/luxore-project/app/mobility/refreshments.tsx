'use client';
import { useState } from 'react';
import Image from 'next/image';
import { Minus, Plus, ShoppingBag, Check, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { money, className } from '@/lib/ride-domain';
import type { Booking, Service } from '@/lib/mobility/domain';
import {
  allowance,
  menu,
  cartPrice,
  combined,
  countCart,
  cartLabel,
  emptyOrder,
  type Cart,
} from '@/lib/mobility/refreshments';
import { api } from './api';
import Inventory from './inventory';
function ItemImage({ id }: { id: (typeof menu)[number]['id'] }) {
  return (
    <Image
      src={`/board-products/${id}.png`}
      alt=""
      width={480}
      height={480}
      unoptimized
      loading="lazy"
      decoding="async"
      draggable={false}
    />
  );
}
export function BoardPicker({
  service,
  value,
  onChange,
  delivered = {},
  disabled = false,
}: {
  service: Service;
  value: Cart;
  onChange: (v: Cart) => void;
  delivered?: Cart;
  disabled?: boolean;
}) {
  const included = allowance[service];
  const used = (group: 'drink' | 'snack') =>
    menu
      .filter((item) => item.group === group)
      .reduce((n, item) => n + (delivered[item.id] || 0), 0);
  const additional =
    cartPrice(combined(delivered, value), service) -
    cartPrice(delivered, service);
  const selected = combined(delivered, value);
  const remaining = (group: 'drink' | 'snack') =>
    Math.max(
      0,
      included[group] -
        used(group) -
        menu
          .filter((item) => item.group === group)
          .reduce((n, item) => n + (value[item.id] || 0), 0),
    );
  return (
    <section className="board-menu" aria-label="Snacks und Getränke auswählen">
      <div className="board-intro">
        <span className="app-kicker">{className(service)} · AN BORD</span>
        <h3>Bordkarte</h3>
        <div className="board-benefits">
          <Gift size={21} aria-hidden="true" />
          <span>
            <strong>
              {included.drink} Getränke
              {included.snack
                ? ` + ${included.snack} ${included.snack === 1 ? 'Snack' : 'Snacks'}`
                : ''}
            </strong>
            <small>pro Fahrt inklusive</small>
          </span>
        </div>
        <p>Weitere Getränke 2,50 € · Snacks 1,50 €</p>
        {!!countCart(delivered) && (
          <p>
            Bereits erhalten: {countCart(delivered)} Artikel. Dein restliches
            Kontingent steht bei der jeweiligen Auswahl.
          </p>
        )}
      </div>
      {(['drink', 'snack'] as const).map((group) => (
        <div className="board-group" key={group}>
          <div className="board-group-heading">
            <h4>{group === 'drink' ? 'Getränke' : 'Snacks'}</h4>
            <span>
              {remaining(group)
                ? `${remaining(group)} noch inklusive`
                : group === 'drink'
                  ? 'Je weiteres 2,50 €'
                  : 'Je weiterer 1,50 €'}
            </span>
          </div>
          <div className="board-grid">
            {menu
              .filter((item) => item.group === group)
              .map((item) => (
                <div
                  className="board-item"
                  data-selected={!!value[item.id] || undefined}
                  key={item.id}
                >
                  <div className="board-item-top">
                    <span className="board-item-image" data-item={item.id}>
                      <ItemImage id={item.id} />
                    </span>
                    {!!value[item.id] && (
                      <span className="board-selected">
                        <Check size={13} aria-hidden="true" />
                        {value[item.id]}
                      </span>
                    )}
                  </div>
                  <div className="board-item-label">
                    <strong>{item.name}</strong>
                    <small>{item.detail}</small>
                  </div>
                  <span className="board-item-price">
                    {remaining(group)
                      ? 'Nächstes inklusive'
                      : `Nächstes + ${money(item.cents)}`}
                  </span>
                  <div className="board-quantity">
                    <button
                      type="button"
                      aria-label={`${item.name} entfernen`}
                      disabled={disabled || !value[item.id]}
                      onClick={() =>
                        onChange({
                          ...value,
                          [item.id]: (value[item.id] || 0) - 1,
                        })
                      }
                    >
                      <Minus size={16} />
                    </button>
                    <output aria-label={`Menge ${item.name}`}>
                      {value[item.id] || 0}
                    </output>
                    <button
                      type="button"
                      aria-label={`${item.name} hinzufügen`}
                      disabled={
                        disabled ||
                        (value[item.id] || 0) + (delivered[item.id] || 0) >=
                          12 ||
                        countCart(selected) >= 24
                      }
                      onClick={() =>
                        onChange({
                          ...value,
                          [item.id]: (value[item.id] || 0) + 1,
                        })
                      }
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      ))}
      <div className="board-total">
        <span>
          <ShoppingBag size={20} aria-hidden="true" />
          <span>
            <strong>{countCart(value)} Artikel</strong>
            <small>Deine Auswahl</small>
          </span>
        </span>
        <span className="board-total-price">
          <strong>
            {additional
              ? `+ ${money(additional)}`
              : countCart(value)
                ? 'Inklusive'
                : money(0)}
          </strong>
          <small>
            {additional ? 'bei Übergabe zusätzlich' : 'kein Aufpreis'}
          </small>
        </span>
      </div>
      <p className="board-note">
        Nach Verfügbarkeit an Bord. Berechnet werden nur übergebene Artikel.
        Zutaten und Allergene bitte auf der jeweiligen Packung prüfen.
      </p>
    </section>
  );
}
export function BoardSummary({ booking }: { booking: Booking }) {
  const order = booking.refreshments || emptyOrder();
  if (!countCart(order.requested) && !countCart(order.delivered)) return null;
  return (
    <div className="board-summary" aria-live="polite">
      <ShoppingBag size={19} />
      <div>
        <strong>Bordbestellung</strong>
        {!!countCart(order.requested) && (
          <p>Gewünscht: {cartLabel(order.requested)}</p>
        )}
        {!!countCart(order.delivered) && (
          <p>Übergeben: {cartLabel(order.delivered)}</p>
        )}
      </div>
    </div>
  );
}
export default function BoardOrder({
  booking,
  driver = false,
  refresh,
  preview = false,
}: {
  booking: Booking;
  driver?: boolean;
  refresh: () => Promise<void>;
  preview?: boolean;
}) {
  const order = booking.refreshments || emptyOrder();
  const [editing, setEditing] = useState(false),
    [draft, setDraft] = useState<Cart>({}),
    [revision, setRevision] = useState(0),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const open = [
    'reserved',
    'requesting',
    'accepted',
    'arrived',
    'riding',
  ].includes(booking.status);
  const currentCost = cartPrice(order.delivered, booking.service);
  async function change(action: string, extra: object = {}) {
    if (preview) {
      setError('Beispielansicht. Es wird keine Bestellung gespeichert.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      await api('refreshments', {
        id: booking.id,
        action,
        revision: action === 'request' ? revision : order.revision,
        ...extra,
      });
      setEditing(false);
      await refresh();
    } catch (e) {
      setError((e as Error).message);
      await refresh().catch(() => {});
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="board-order">
      <div className="board-order-heading">
        <ShoppingBag size={20} />
        <h3>{driver ? 'Bestellung des Fahrgasts' : 'Snacks & Getränke'}</h3>
        <span>
          {countCart(order.requested)
            ? `${countCart(order.requested)} offen`
            : 'Bordkarte'}
        </span>
      </div>
      {driver && !preview && (
        <details>
          <summary>Bordbestand bearbeiten / Eigenverbrauch</summary>
          <Inventory vehicleId={booking.vehicle_id} />
        </details>
      )}
      {!!countCart(order.requested) && (
        <div aria-live="polite">
          {menu
            .filter((i) => order.requested[i.id])
            .map((item) => (
              <div className="board-request" key={item.id}>
                <div className="board-request-product">
                  <span className="board-item-image" data-item={item.id}>
                    <ItemImage id={item.id} />
                  </span>
                  <strong>
                    {order.requested[item.id]} × {item.name}
                  </strong>
                </div>
                {driver && open && (
                  <div>
                    <Button
                      size="sm"
                      disabled={busy}
                      onClick={() =>
                        void change('deliver', { itemId: item.id, quantity: 1 })
                      }
                    >
                      1 übergeben
                    </Button>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() =>
                        void change('unavailable', {
                          itemId: item.id,
                          quantity: order.requested[item.id],
                        })
                      }
                    >
                      Nicht verfügbar
                    </button>
                  </div>
                )}
              </div>
            ))}
        </div>
      )}
      {!!countCart(order.requested) && (
        <p className="board-note">
          Bei vollständiger Übergabe zusätzlich:{' '}
          {money(
            cartPrice(
              combined(order.delivered, order.requested),
              booking.service,
            ) - currentCost,
          )}
          .
        </p>
      )}
      {!!countCart(order.delivered) && (
        <p className="board-note">
          Übergeben: {cartLabel(order.delivered)} ·{' '}
          {currentCost ? money(currentCost) : 'inklusive'}
        </p>
      )}
      {!!countCart(order.unavailable) && (
        <p className="board-note">
          Nicht verfügbar: {cartLabel(order.unavailable)}. Dafür wird nichts
          berechnet.
        </p>
      )}
      {!open && !!countCart(order.requested) && (
        <p className="board-note">
          Fahrt beendet. Nicht übergebene Artikel werden nicht berechnet.
        </p>
      )}
      {!driver && open && !editing && (
        <Button
          variant="outline"
          onClick={() => {
            setDraft({ ...order.requested });
            setRevision(order.revision);
            setError('');
            setEditing(true);
          }}
        >
          Bordkarte öffnen
        </Button>
      )}
      {!driver && editing && open && (
        <>
          <BoardPicker
            service={booking.service}
            value={draft}
            onChange={setDraft}
            delivered={order.delivered}
            disabled={busy}
          />
          <div className="board-order-actions">
            <Button
              disabled={busy}
              onClick={() => void change('request', { cart: draft })}
            >
              {busy
                ? 'Wird gesendet …'
                : `Bestellung bestätigen · ${money(cartPrice(combined(order.delivered, draft), booking.service) - currentCost)} zusätzlich`}
            </Button>
            <button
              type="button"
              disabled={busy}
              onClick={() => setEditing(false)}
            >
              Schließen
            </button>
          </div>
        </>
      )}
      {driver && !countCart(order.requested) && (
        <p className="board-note">Keine offene Bordbestellung.</p>
      )}
      {error && (
        <p role="alert" className="field-error">
          {error}
          {editing && (
            <button
              type="button"
              onClick={() => {
                setDraft({ ...order.requested });
                setRevision(order.revision);
                setError('');
              }}
            >
              Aktuelle Bestellung übernehmen
            </button>
          )}
        </p>
      )}
    </section>
  );
}
