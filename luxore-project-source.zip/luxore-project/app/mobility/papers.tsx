'use client';
import { useCallback, useEffect, useState } from 'react';
import { api } from './api';
import { photoUrl, uploadPhoto } from './photo';
import { MAX_DOCUMENT_IMAGES } from '@/lib/mobility/images';
import type { KindRule, PaperState, SubjectType } from '@/lib/mobility/compliance';

type Doc = {
  id: string;
  kind: string;
  number: string | null;
  expires_on: string | null;
  status: 'submitted' | 'approved' | 'rejected';
  reason: string | null;
  created_at: number;
  images: { id: string }[];
};
type State = {
  papers: PaperState[];
  documents: Doc[];
  kinds: Record<string, KindRule>;
  canReview: boolean;
};
export const germanDate = (date: string | null) =>
  date ? date.split('-').reverse().join('.') : '';
export function paperChip(p: PaperState) {
  if (p.state === 'approved')
    return {
      tone: p.daysLeft !== null && p.daysLeft <= 14 ? 'warn' : 'good',
      text:
        p.daysLeft !== null && p.daysLeft <= 14
          ? p.daysLeft === 0
            ? 'läuft heute ab'
            : `läuft in ${p.daysLeft} ${p.daysLeft === 1 ? 'Tag' : 'Tagen'} ab`
          : p.expiresOn
            ? 'geprüft · bis ' + germanDate(p.expiresOn)
            : 'geprüft',
    };
  if (p.state === 'submitted') return { tone: 'warn', text: 'wird geprüft' };
  if (p.state === 'rejected') return { tone: 'danger', text: 'abgelehnt' };
  if (p.state === 'expired')
    return { tone: 'danger', text: 'abgelaufen am ' + germanDate(p.expiresOn) };
  return { tone: p.required ? 'danger' : '', text: p.required ? 'fehlt' : 'freiwillig' };
}
/** Papers of one driver, vehicle or fleet: state, upload with photo, history. */
export default function Papers({
  subjectType,
  subjectId,
  onChanged,
}: {
  subjectType: SubjectType;
  subjectId: string;
  onChanged?: () => void;
}) {
  const [data, setData] = useState<State | null>(null),
    [error, setError] = useState(''),
    [saved, setSaved] = useState(''),
    [busy, setBusy] = useState(false),
    [open, setOpen] = useState<string | null>(null),
    [number, setNumber] = useState(''),
    [expires, setExpires] = useState(''),
    [files, setFiles] = useState<File[]>([]);
  const load = useCallback(async () => {
    try {
      setData(
        await api<State>(
          `documents?subjectType=${subjectType}&subjectId=${encodeURIComponent(subjectId)}`,
        ),
      );
    } catch (e) {
      setError((e as Error).message);
    }
  }, [subjectType, subjectId]);
  useEffect(() => {
    void load();
  }, [load]);
  function start(kind: string) {
    setOpen(open === kind ? null : kind);
    setNumber('');
    setExpires('');
    setFiles([]);
    setError('');
    setSaved('');
  }
  async function submit(kind: string) {
    if (busy) return;
    if (!files.length) return setError('Bitte mindestens ein Foto wählen.');
    setBusy(true);
    setError('');
    try {
      const created = await api<{ id: string }>('documents', {
        action: 'create',
        subjectType,
        subjectId,
        kind,
        number: number || undefined,
        expiresOn: expires || undefined,
      });
      try {
        for (const file of files) await uploadPhoto('document', created.id, file);
      } catch (e) {
        // No half-finished entry without a readable photo.
        await api('documents', { action: 'delete', id: created.id }).catch(() => {});
        throw e;
      }
      setOpen(null);
      setSaved('Eingereicht. Der Betreiber prüft das Papier.');
      await load();
      onChanged?.();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function remove(id: string) {
    if (busy) return;
    setBusy(true);
    try {
      await api('documents', { action: 'delete', id });
      await load();
      onChanged?.();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  if (!data)
    return <p className="pf-muted">{error || 'Papiere werden geladen …'}</p>;
  return (
    <div className="pf">
      {error && (
        <p className="pf-error" role="alert">
          {error}
        </p>
      )}
      {saved && <output className="pf-saved">{saved}</output>}
      <div className="pf-list">
        {data.papers.map((p) => {
          const chip = paperChip(p),
            rule = data.kinds[p.kind],
            docs = data.documents.filter((d) => d.kind === p.kind);
          return (
            <div className="pf-card" key={p.kind}>
              <div className="pf-row">
                <strong>{p.label}</strong>
                <span className={'pf-chip ' + chip.tone}>{chip.text}</span>
              </div>
              {p.state === 'rejected' && p.reason && (
                <p className="pf-notice danger">Grund: {p.reason}</p>
              )}
              {docs.slice(0, 3).map((d) => (
                <div className="pf-row" key={d.id}>
                  <div className="pf-thumbs">
                    {d.images.map((i) => (
                      <a
                        key={i.id}
                        href={photoUrl(i.id)}
                        target="_blank"
                        rel="noreferrer"
                        aria-label={p.label + ' – Foto öffnen'}
                      >
                        <img src={photoUrl(i.id)} alt="" loading="lazy" />
                      </a>
                    ))}
                  </div>
                  <span className="pf-muted">
                    {d.status === 'approved'
                      ? 'geprüft'
                      : d.status === 'rejected'
                        ? 'abgelehnt'
                        : 'eingereicht'}{' '}
                    ·{' '}
                    {new Date(d.created_at).toLocaleDateString('de-DE', {
                      timeZone: 'Europe/Berlin',
                    })}
                    {d.expires_on ? ' · gültig bis ' + germanDate(d.expires_on) : ''}
                    {d.number ? ' · Nr. ' + d.number : ''}
                  </span>
                  {(d.status !== 'approved' || data.canReview) && (
                    <button
                      type="button"
                      className="pf-btn"
                      disabled={busy}
                      onClick={() => void remove(d.id)}
                    >
                      Entfernen
                    </button>
                  )}
                </div>
              ))}
              {open === p.kind ? (
                <form
                  className="pf-form"
                  onSubmit={(e) => {
                    e.preventDefault();
                    void submit(p.kind);
                  }}
                >
                  <label className="pf-field">
                    Foto(s) – bis zu {MAX_DOCUMENT_IMAGES}
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={(e) =>
                        setFiles(
                          Array.from(e.target.files || []).slice(
                            0,
                            MAX_DOCUMENT_IMAGES,
                          ),
                        )
                      }
                    />
                    <small>
                      Wird auf dem Gerät verkleinert. Bitte gut lesbar und
                      vollständig fotografieren.
                    </small>
                  </label>
                  <div className="pf-grid2">
                    {rule?.expiry !== 'none' && (
                      <label className="pf-field">
                        Gültig bis{rule?.expiry === 'optional' ? ' (freiwillig)' : ''}
                        <input
                          type="date"
                          value={expires}
                          required={rule?.expiry === 'required'}
                          onChange={(e) => setExpires(e.target.value)}
                        />
                      </label>
                    )}
                    <label className="pf-field">
                      Nummer (freiwillig)
                      <input
                        value={number}
                        maxLength={60}
                        onChange={(e) => setNumber(e.target.value)}
                      />
                    </label>
                  </div>
                  <div className="pf-actions">
                    <button
                      type="button"
                      className="pf-btn"
                      disabled={busy}
                      onClick={() => setOpen(null)}
                    >
                      Abbrechen
                    </button>
                    <button type="submit" className="pf-btn primary" disabled={busy}>
                      {busy ? 'Wird hochgeladen …' : 'Zur Prüfung einreichen'}
                    </button>
                  </div>
                </form>
              ) : (
                <button
                  type="button"
                  className="pf-btn"
                  disabled={busy}
                  onClick={() => start(p.kind)}
                >
                  {p.state === 'missing' ? 'Foto hochladen' : 'Neues Foto hochladen'}
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
