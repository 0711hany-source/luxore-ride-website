export function completedSwipe(
  startedOnThumb: boolean,
  displacement: number,
  value: number,
  disabled: boolean,
) {
  return startedOnThumb && !disabled && displacement >= 60 && value >= 95;
}
