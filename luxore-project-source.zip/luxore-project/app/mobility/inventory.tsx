'use client';
import { useCallback, useEffect, useState } from 'react';
import Image from 'next/image';
import {
  ShoppingBag,
  Clipboard,
  Download,
  Package,
  RefreshCw,
} from 'lucide-react';
import { api } from './api';
import { menu } from '@/lib/mobility/refreshments';
import { shoppingList, stockUsage, type Stock } from '@/lib/mobility/inventory';

type View = {
  vehicleId: string;
  vehicles: { id: string; plate: string; model: string; fleet_id: string }[];
  initialized: boolean;
  revision: number;
  stock: Stock;
  movements: {
    actor_name: string;
    kind: string;
    note: string;
    details: string;
    created_at: number;
  }[];
};
const kinds: Record<string, string> = {
  initial: 'Anfangsbestand',
  correction: 'Bestandskorrektur',
  personal: 'Eigenverbrauch',
  restock: 'Nachgefüllt',
  delivery: 'Fahrgast',
};
type InventoryProps = { vehicleId?: string | null; fleetId?: string };
export default function Inventory(props: InventoryProps) {
  return (
    <InventoryPanel
      key={props.vehicleId || props.fleetId || 'current'}
      {...props}
    />
  );
}
function InventoryPanel({
  vehicleId,
  fleetId,
}: {
  vehicleId?: string | null;
  fleetId?: string;
}) {
  const [selected, setSelected] = useState(vehicleId || '');
  const [data, setData] = useState<View | null>(null),
    [draft, setDraft] = useState<Stock | null>(null);
  const [mode, setMode] = useState<'stock' | 'shop' | 'edit'>('stock');
  const [error, setError] = useState(''),
    [message, setMessage] = useState(''),
    [busy, setBusy] = useState(false);
  const [note, setNote] = useState(''),
    [itemId, setItemId] = useState('water'),
    [amount, setAmount] = useState(1);
  const [bought, setBought] = useState<Record<string, number>>({});
  const refresh = useCallback(async () => {
    const q = new URLSearchParams();
    if (vehicleId || selected) q.set('vehicleId', vehicleId || selected);
    if (fleetId) q.set('fleetId', fleetId);
    const view = await api<View>('inventory?' + q);
    setData(view);
    setError('');
    return view;
  }, [vehicleId, selected, fleetId]);
  useEffect(() => {
    let active = true;
    const run = async () => {
      try {
        const q = new URLSearchParams();
        if (vehicleId || selected) q.set('vehicleId', vehicleId || selected);
        if (fleetId) q.set('fleetId', fleetId);
        const view = await api<View>('inventory?' + q);
        if (active) {
          setData(view);
          setError('');
        }
      } catch (e) {
        if (active) setError((e as Error).message);
      }
    };
    void run();
    return () => {
      active = false;
    };
  }, [vehicleId, selected, fleetId]);
  async function change(action: string, values: Record<string, unknown>) {
    if (!data || busy) return;
    setBusy(true);
    setError('');
    setMessage('');
    try {
      const next = await api<View>('inventory', {
        action,
        vehicleId: data.vehicleId,
        revision: data.revision,
        ...values,
      });
      setData(next);
      setDraft(null);
      setMode('stock');
      setBought({});
      setNote('');
      setMessage(
        action === 'personal'
          ? 'Eigenverbrauch dokumentiert.'
          : action === 'restock'
            ? 'Einkauf eingeräumt und Bestand erhöht.'
            : 'Bestand gespeichert.',
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const list = data ? shoppingList(data.stock) : [];
  const urgent = list.some((i) => i.urgent);
  const listText = data
    ? `Luxóre Ride · Einkaufsliste\n${data.vehicles.find((v) => v.id === data.vehicleId)?.plate || ''}\n${new Date().toLocaleDateString('de-DE')}\n\n${list.map((i) => `☐ ${i.quantity} × ${i.name}`).join('\n')}\n\nNach dem Einkauf die eingeräumten Mengen in der App bestätigen.`
    : '';
  const used = data ? stockUsage(data.stock, 'count') : { drink: 0, snack: 0 };
  function edit() {
    if (data) {
      setDraft(structuredClone(data.stock));
      setNote(data.initialized ? '' : 'Erstzählung');
      setMode('edit');
    }
  }
  async function copyList() {
    try {
      await navigator.clipboard.writeText(listText);
      setMessage('Einkaufsliste kopiert.');
    } catch {
      setError('Kopieren nicht möglich. Bitte die Liste herunterladen.');
    }
  }
  function download() {
    const url = URL.createObjectURL(
      new Blob([listText], { type: 'text/plain;charset=utf-8' }),
    );
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Luxore-Einkaufsliste.txt';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  return (
    <section className="stock-panel" aria-label="Bordbestand">
      <header className="stock-heading">
        <div>
          <span className="app-kicker">AN BORD</span>
          <h2>Vorrat & Einkauf</h2>
        </div>
        <button
          type="button"
          disabled={busy}
          aria-label="Bestand aktualisieren"
          onClick={() => {
            setDraft(null);
            setBought({});
            setMode('stock');
            void refresh().catch((e) => setError(e.message));
          }}
        >
          <RefreshCw size={20} />
        </button>
      </header>
      {error && (
        <p className="notice error" role="alert">
          {error}
        </p>
      )}
      {message && (
        <p className="notice success" aria-live="polite">
          {message}
        </p>
      )}
      {!data ? (
        <p>
          {error
            ? 'Nach Fahrzeugauswahl erneut öffnen.'
            : 'Bestand wird geladen …'}
        </p>
      ) : (
        <>
          {!vehicleId && (
            <label className="stock-vehicle">
              Fahrzeug
              <select
                value={data.vehicleId}
                disabled={busy}
                onChange={(e) => {
                  setData(null);
                  setDraft(null);
                  setBought({});
                  setMode('stock');
                  setMessage('');
                  setSelected(e.target.value);
                }}
              >
                {data.vehicles
                  .filter((v) => !fleetId || v.fleet_id === fleetId)
                  .map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.plate} · {v.model}
                    </option>
                  ))}
              </select>
            </label>
          )}
          <div className="stock-capacity">
            <span>
              <strong>
                {used.drink}
                <small> / 24</small>
              </strong>
              Kühlplätze
            </span>
            <span>
              <strong>
                {used.snack}
                <small> / {data.stock.snackCapacity}</small>
              </strong>
              Snackplätze
            </span>
          </div>
          {!data.initialized ? (
            <div className="stock-alert">
              <Package size={24} />
              <div>
                <strong>Einmal zählen, dann behalten wir den Überblick.</strong>
                <p>
                  Trage ein, was tatsächlich im Fahrzeug liegt. Danach werden
                  Übergaben und Eigenverbrauch abgezogen.
                </p>
                <button onClick={edit} disabled={busy}>
                  Anfangsbestand erfassen
                </button>
              </div>
            </div>
          ) : (
            urgent && (
              <div className="stock-alert" aria-live="polite">
                <ShoppingBag size={24} />
                <div>
                  <strong>Bitte jetzt einkaufen.</strong>
                  <p>
                    Mindestens ein Artikel hat die Meldeschwelle erreicht. Deine
                    Liste ergänzt den Vorrat bis zum Sollbestand.
                  </p>
                  <button disabled={busy} onClick={() => setMode('shop')}>
                    Einkaufsliste öffnen ·{' '}
                    {list.reduce((n, i) => n + i.quantity, 0)} Stück
                  </button>
                </div>
              </div>
            )
          )}
          <div className="stock-tabs" aria-label="Bestandsansicht">
            <button
              disabled={busy}
              aria-pressed={mode === 'stock'}
              onClick={() => setMode('stock')}
            >
              Bestand
            </button>
            <button
              disabled={busy || !data.initialized}
              aria-pressed={mode === 'shop'}
              onClick={() => setMode('shop')}
            >
              Einkaufsliste
            </button>
            <button
              disabled={busy}
              aria-pressed={mode === 'edit'}
              onClick={edit}
            >
              Bearbeiten
            </button>
          </div>
          {mode === 'edit' && draft ? (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                void change('save', { stock: draft, note });
              }}
            >
              <p className="stock-help">
                Ist = gezählte Stückzahl. Soll = voller Vorrat. Melden bei =
                Einkaufshinweis ab dieser Restmenge. Eine 0,5-l-Flasche ist
                zunächst mit zwei Kühlplätzen eingeplant; bitte an die
                tatsächliche Passform anpassen.
              </p>
              <label>
                Snackplätze insgesamt
                <input
                  type="number"
                  min={1}
                  max={30}
                  required
                  value={draft.snackCapacity}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      snackCapacity: Number(e.target.value),
                    })
                  }
                />
              </label>
              <div className="stock-edit-list">
                {menu.map((item) => (
                  <fieldset key={item.id} disabled={busy}>
                    <legend>{item.name}</legend>
                    <div>
                      {(
                        [
                          ['count', 'Ist'],
                          ['target', 'Soll'],
                          ['minimum', 'Melden bei'],
                          ['slots', 'Plätze / Stück'],
                        ] as const
                      ).map(([field, label]) => (
                        <label key={field}>
                          {label}
                          <input
                            type="number"
                            min={field === 'slots' ? 1 : 0}
                            max={field === 'slots' ? 4 : 100}
                            required
                            value={draft.items[item.id][field]}
                            onChange={(e) =>
                              setDraft({
                                ...draft,
                                items: {
                                  ...draft.items,
                                  [item.id]: {
                                    ...draft.items[item.id],
                                    [field]: Number(e.target.value),
                                  },
                                },
                              })
                            }
                          />
                        </label>
                      ))}
                    </div>
                  </fieldset>
                ))}
              </div>
              <label>
                Grund der Änderung
                <input
                  required
                  maxLength={160}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="z. B. gezählt, beschädigt oder abgelaufen"
                />
              </label>
              <button className="stock-primary" disabled={busy}>
                {busy
                  ? 'Wird gespeichert …'
                  : 'Bestand und Sollmengen speichern'}
              </button>
            </form>
          ) : mode === 'shop' ? (
            <div>
              <div className="stock-list-actions">
                <button onClick={() => void copyList()}>
                  <Clipboard size={17} />
                  Kopieren
                </button>
                <button onClick={download}>
                  <Download size={17} />
                  Mitnehmen
                </button>
              </div>
              {!list.length ? (
                <p>Alles aufgefüllt. Zurzeit brauchst du nichts einzukaufen.</p>
              ) : (
                <>
                  <p className="stock-help">
                    Abhaken oder die tatsächlich gekaufte Menge eintragen. Erst
                    beim Bestätigen wird sie zum Fahrzeugbestand addiert.
                  </p>
                  {list.map((i) => (
                    <div className="stock-shopping-row" key={i.id}>
                      <label
                        aria-label={`${i.name} auf der Einkaufsliste abhaken`}
                      >
                        <input
                          type="checkbox"
                          disabled={busy}
                          checked={!!bought[i.id]}
                          onChange={(e) =>
                            setBought({
                              ...bought,
                              [i.id]: e.target.checked ? i.quantity : 0,
                            })
                          }
                        />
                        <span>
                          <strong>{i.name}</strong>
                          <small>
                            {i.quantity} Stück fehlen
                            {i.urgent ? ' · knapp' : ''}
                          </small>
                        </span>
                      </label>
                      <input
                        type="number"
                        aria-label={`Gekaufte Menge ${i.name}`}
                        min={0}
                        max={100}
                        disabled={busy}
                        value={bought[i.id] || 0}
                        onChange={(e) =>
                          setBought({
                            ...bought,
                            [i.id]: Number(e.target.value),
                          })
                        }
                      />
                    </div>
                  ))}
                  <button
                    className="stock-primary"
                    disabled={busy || !Object.values(bought).some((n) => n > 0)}
                    onClick={() =>
                      void change('restock', {
                        quantities: Object.fromEntries(
                          Object.entries(bought).filter(([, n]) => n > 0),
                        ),
                      })
                    }
                  >
                    {busy
                      ? 'Wird gespeichert …'
                      : 'Gekauft & eingeräumt bestätigen'}
                  </button>
                </>
              )}
            </div>
          ) : (
            <>
              <div className="stock-grid">
                {menu.map((item) => {
                  const s = data.stock.items[item.id];
                  return (
                    <article
                      key={item.id}
                      data-low={
                        (data.initialized &&
                          s.target > 0 &&
                          s.count <= s.minimum) ||
                        undefined
                      }
                    >
                      <Image
                        src={`/board-products/${item.id}.png`}
                        alt=""
                        width={80}
                        height={80}
                        unoptimized
                      />
                      <div>
                        <strong>{item.name}</strong>
                        <span>
                          {data.initialized
                            ? `${s.count} / ${s.target} Stück`
                            : `Soll: ${s.target} Stück`}
                        </span>
                        <small>
                          {data.initialized &&
                          s.target > 0 &&
                          s.count <= s.minimum
                            ? 'Nachkaufen'
                            : `Melden bei ${s.minimum}`}
                        </small>
                      </div>
                    </article>
                  );
                })}
              </div>
              {data.initialized && (
                <form
                  className="stock-personal"
                  onSubmit={(e) => {
                    e.preventDefault();
                    void change('personal', {
                      quantities: { [itemId]: amount },
                      note,
                    });
                  }}
                >
                  <h3>Für mich entnommen</h3>
                  <p>
                    Wird als Eigenverbrauch dokumentiert und nicht dem Fahrgast
                    berechnet.
                  </p>
                  <label>
                    Artikel
                    <select
                      value={itemId}
                      disabled={busy}
                      onChange={(e) => setItemId(e.target.value)}
                    >
                      {menu.map((i) => (
                        <option key={i.id} value={i.id}>
                          {i.name} · {data.stock.items[i.id].count} da
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Stück
                    <input
                      type="number"
                      min={1}
                      max={100}
                      required
                      value={amount}
                      disabled={busy}
                      onChange={(e) => setAmount(Number(e.target.value))}
                    />
                  </label>
                  <label>
                    Notiz (optional)
                    <input
                      maxLength={160}
                      value={note}
                      disabled={busy}
                      onChange={(e) => setNote(e.target.value)}
                    />
                  </label>
                  <button
                    className="stock-primary"
                    disabled={
                      busy ||
                      amount < 1 ||
                      amount > data.stock.items[itemId].count
                    }
                  >
                    {busy ? 'Wird gespeichert …' : 'Entnahme dokumentieren'}
                  </button>
                </form>
              )}
            </>
          )}
          {!!data.movements.length && (
            <details className="stock-history">
              <summary>Letzte Bestandsbewegungen</summary>
              {data.movements.map((m, index) => {
                const details = JSON.parse(m.details);
                return (
                  <article key={index}>
                    <strong>
                      {kinds[m.kind] || m.kind} · {m.actor_name}
                    </strong>
                    <small>
                      {new Date(m.created_at).toLocaleString('de-DE')}
                    </small>
                    {details.quantities && (
                      <p>
                        {Object.entries(details.quantities)
                          .map(
                            ([id, n]) =>
                              `${typeof n === 'number' ? n : 0} × ${menu.find((i) => i.id === id)?.name || id}`,
                          )
                          .join(', ')}
                      </p>
                    )}
                    {m.note && <p>{m.note}</p>}
                    {!details.quantities && details.after && (
                      <p>
                        {menu
                          .flatMap((item) => {
                            const before =
                              details.before?.items?.[item.id]?.count;
                            const after = details.after.items[item.id].count;
                            return before !== after
                              ? [`${item.name}: ${before ?? '–'} → ${after}`]
                              : [];
                          })
                          .join(', ') ||
                          'Sollmengen oder Einstellungen angepasst.'}
                      </p>
                    )}
                  </article>
                );
              })}
            </details>
          )}
        </>
      )}
    </section>
  );
}
