'use client';
/* oxlint-disable jsx-a11y/prefer-tag-over-role -- Custom inline ARIA combobox needs a listbox with clickable options; native select cannot preserve editable typeahead. */
import { useEffect, useId, useRef, useState } from 'react';
import { LocateFixed, Search, Check, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Point } from '@/lib/mobility/domain';
import { api } from './api';
import AddressAttribution from './address-attribution';
export default function Address({
  label,
  value,
  onChange,
  location = false,
  mapsReady,
}: {
  label: string;
  value: Point | null;
  onChange: (p: Point | null) => void;
  location?: boolean;
  mapsReady: boolean;
}) {
  const [query, setQuery] = useState(value?.label || ''),
    [items, setItems] = useState<Point[]>([]),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [editing, setEditing] = useState(false),
    [open, setOpen] = useState(false);
  const inputId = useId();
  const [highlighted, setHighlighted] = useState(-1);
  const revision = useRef(0);
  const pending = useRef<AbortController | null>(null);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);
  const focused = useRef(false);
  function cancelSearch() {
    if (debounce.current) clearTimeout(debounce.current);
    debounce.current = null;
    pending.current?.abort();
    pending.current = null;
  }
  const searchRef = useRef<() => Promise<void>>(async () => {});
  useEffect(() => {
    if (!editing || value || !mapsReady || query.trim().length < 3) return;
    debounce.current = setTimeout(() => void searchRef.current(), 600);
    return () => {
      if (debounce.current) clearTimeout(debounce.current);
    };
  }, [query, editing, mapsReady, value]);
  useEffect(
    () => () => {
      revision.current++;
      cancelSearch();
    },
    [],
  );
  async function search(automatic = false) {
    if (busy) return;
    if (!mapsReady) {
      setError('Die Adresssuche wird mit dem Kartenkonto aktiviert.');
      return;
    }
    if (query.trim().length < 3) {
      setError('Bitte mindestens drei Zeichen eingeben.');
      return;
    }
    cancelSearch();
    const controller = new AbortController();
    pending.current = controller;
    const current = ++revision.current;
    setBusy(true);
    setError('');
    try {
      const result = await api<{ results: Point[] }>(
        'places',
        {
          kind: 'search',
          query,
        },
        controller.signal,
      );
      if (current !== revision.current) return;
      setItems(result.results);
      setHighlighted(-1);
      if ((!automatic || focused.current) && result.results.length)
        setOpen(true);
      if (!result.results.length)
        setError(
          'Keine Adresse gefunden. Bitte Straße, Hausnummer und Ort eingeben.',
        );
    } catch (e) {
      if (current === revision.current && !controller.signal.aborted)
        setError((e as Error).message);
    } finally {
      if (current === revision.current) setBusy(false);
    }
  }
  useEffect(() => {
    searchRef.current = () => search(true);
  });
  async function choose(point: Point | null) {
    if (busy) return;
    cancelSearch();
    setEditing(false);
    setOpen(false);
    const current = ++revision.current;
    if (!point) {
      onChange(null);
      setBusy(false);
      setError('');
      return;
    }
    onChange(null);
    setBusy(true);
    setError('');
    try {
      // Only the chosen address obtains permanent storage rights for quotes/rides.
      const result = await api<{ results: Point[] }>('places', {
        kind: 'selected',
        query,
        lat: point.lat,
        lng: point.lng,
      });
      if (current !== revision.current) return;
      const confirmed = result.results[0];
      if (!confirmed)
        throw new Error(
          'Adresse konnte nicht bestätigt werden. Bitte erneut suchen.',
        );
      setItems([confirmed]);
      setQuery(confirmed.label);
      onChange(confirmed);
    } catch (e) {
      if (current === revision.current) setError((e as Error).message);
    } finally {
      if (current === revision.current) setBusy(false);
    }
  }
  function locate() {
    if (busy) return;
    if (!navigator.geolocation) {
      setError('Standortbestimmung wird von diesem Browser nicht unterstützt.');
      return;
    }
    if (!mapsReady) {
      setError('Die Standortauflösung wird mit dem Kartenkonto aktiviert.');
      return;
    }
    cancelSearch();
    setEditing(false);
    setOpen(false);
    const current = ++revision.current;
    setBusy(true);
    setError('');
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          if (current !== revision.current) return;
          const result = await api<{ results: Point[] }>('places', {
            kind: 'location',
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          if (current !== revision.current) return;
          if (!result.results[0])
            throw new Error('Keine Abholadresse für deinen Standort gefunden.');
          setItems(result.results);
          setQuery(result.results[0].label);
          onChange(result.results[0]);
        } catch (e) {
          if (current === revision.current) setError((e as Error).message);
        } finally {
          if (current === revision.current) setBusy(false);
        }
      },
      (e) => {
        if (current === revision.current) {
          setError(
            e.code === 1
              ? 'Standortzugriff nicht erlaubt. Du kannst die Adresse manuell eingeben.'
              : 'Standort nicht verfügbar. Bitte die Adresse eingeben.',
          );
          setBusy(false);
        }
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 },
    );
  }
  return (
    <div className="address-control">
      <div className="address-label">
        <label htmlFor={inputId}>{label}</label>
        {value && (
          <span>
            <Check size={13} />
            Ausgewählt
          </span>
        )}
      </div>
      <div className="address-row">
        <input
          id={inputId}
          className="address-input"
          role="combobox"
          aria-autocomplete="list"
          aria-expanded={open && items.length > 0 && !value}
          aria-controls={inputId + '-results'}
          aria-activedescendant={
            open && highlighted >= 0
              ? inputId + '-result-' + highlighted
              : undefined
          }
          aria-invalid={Boolean(error)}
          aria-describedby={error ? inputId + '-error' : undefined}
          autoComplete="off"
          placeholder="Straße, Hausnummer, Ort"
          value={value?.label || query}
          onChange={(event) => {
            cancelSearch();
            revision.current++;
            setBusy(false);
            setItems([]);
            setHighlighted(-1);
            onChange(null);
            setQuery(event.target.value);
            setEditing(true);
            setError('');
            setOpen(false);
          }}
          onFocus={() => {
            focused.current = true;
            if (items.length && !value) setOpen(true);
          }}
          onBlur={() => {
            focused.current = false;
          }}
          onKeyDown={(event) => {
            if (
              (event.key === 'ArrowDown' || event.key === 'ArrowUp') &&
              items.length &&
              !value
            ) {
              event.preventDefault();
              setOpen(true);
              const direction = event.key === 'ArrowDown' ? 1 : -1;
              setHighlighted((previous) =>
                previous < 0
                  ? direction === 1
                    ? 0
                    : items.length - 1
                  : (previous + direction + items.length) % items.length,
              );
            } else if (event.key === 'Enter') {
              event.preventDefault();
              if (open && highlighted >= 0) void choose(items[highlighted]);
              else if (items.length && !value) {
                setOpen(true);
                setHighlighted(0);
              } else void search();
            } else if (event.key === 'Escape') {
              setOpen(false);
              setHighlighted(-1);
            }
          }}
        />
        <Button
          aria-label={label + ' suchen'}
          variant="outline"
          disabled={busy}
          onClick={() => void search()}
        >
          <Search size={18} />
        </Button>
        {location && (
          <Button
            aria-label="Aktuellen Standort als Abholung auswählen"
            variant="outline"
            disabled={busy}
            onClick={locate}
          >
            <LocateFixed size={18} />
          </Button>
        )}
      </div>
      {open && items.length > 0 && !value && (
        <div
          id={inputId + '-results'}
          role="listbox"
          aria-label={label + ': Adressvorschläge'}
          className="address-results"
        >
          {items.map((point, index) => (
            <button
              key={point.id}
              id={inputId + '-result-' + index}
              type="button"
              role="option"
              aria-selected={highlighted === index}
              disabled={busy}
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => void choose(point)}
            >
              <MapPin size={18} aria-hidden="true" />
              <span>{point.label}</span>
            </button>
          ))}
        </div>
      )}
      <AddressAttribution points={value ? [value] : items} />
      {busy && <output className="small-note">Adresse wird gesucht …</output>}
      {items.length > 0 && !value && !error && !open && (
        <p className="small-note">
          {items.length} Treffer gefunden. Tippe ins Adressfeld, um eine Adresse
          auszuwählen.
        </p>
      )}
      {error && (
        <p id={inputId + '-error'} className="field-error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
