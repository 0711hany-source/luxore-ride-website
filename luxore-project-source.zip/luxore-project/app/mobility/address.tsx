'use client';
import { useRef, useState } from 'react';
import { LocateFixed, Search, Check, MapPin } from 'lucide-react';
import {
  Combobox,
  ComboboxInput,
  ComboboxContent,
  ComboboxList,
  ComboboxItem,
} from '@/components/ui/combobox';
import { Button } from '@/components/ui/button';
import type { Point } from '@/lib/mobility/domain';
import { api } from './api';
export default function Address({
  label,
  value,
  onChange,
  location = false,
  mapsReady,
}: {
  label: string;
  value: Point | null;
  onChange: (p: Point | null) => void;
  location?: boolean;
  mapsReady: boolean;
}) {
  const [query, setQuery] = useState(value?.label || ''),
    [items, setItems] = useState<Point[]>([]),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const revision = useRef(0);
  async function search() {
    if (busy) return;
    if (!mapsReady) {
      setError('Die Adresssuche wird mit dem Kartenkonto aktiviert.');
      return;
    }
    if (query.trim().length < 3) {
      setError('Bitte mindestens drei Zeichen eingeben.');
      return;
    }
    const current = ++revision.current;
    setBusy(true);
    setError('');
    try {
      const result = await api<{ results: Point[] }>('places', {
        kind: 'search',
        query,
      });
      if (current !== revision.current) return;
      setItems(result.results);
      if (!result.results.length)
        setError(
          'Keine Adresse gefunden. Bitte Straße, Hausnummer und Ort eingeben.',
        );
    } catch (e) {
      if (current === revision.current) setError((e as Error).message);
    } finally {
      if (current === revision.current) setBusy(false);
    }
  }
  async function choose(point: Point | null) {
    const current = ++revision.current;
    if (!point) {
      onChange(null);
      setBusy(false);
      return;
    }
    onChange(null);
    setBusy(true);
    setError('');
    try {
      // Only the chosen address obtains permanent storage rights for quotes/rides.
      const result = await api<{ results: Point[] }>('places', {
        kind: 'selected',
        query,
        lat: point.lat,
        lng: point.lng,
      });
      if (current !== revision.current) return;
      const confirmed = result.results[0];
      if (!confirmed)
        throw new Error(
          'Adresse konnte nicht bestätigt werden. Bitte erneut suchen.',
        );
      setItems([confirmed]);
      setQuery(confirmed.label);
      onChange(confirmed);
    } catch (e) {
      if (current === revision.current) setError((e as Error).message);
    } finally {
      if (current === revision.current) setBusy(false);
    }
  }
  function locate() {
    if (busy) return;
    if (!navigator.geolocation) {
      setError('Standortbestimmung wird von diesem Browser nicht unterstützt.');
      return;
    }
    if (!mapsReady) {
      setError('Die Standortauflösung wird mit dem Kartenkonto aktiviert.');
      return;
    }
    const current = ++revision.current;
    setBusy(true);
    setError('');
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          if (current !== revision.current) return;
          const result = await api<{ results: Point[] }>('places', {
            kind: 'location',
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          if (current !== revision.current) return;
          if (!result.results[0])
            throw new Error('Keine Abholadresse für deinen Standort gefunden.');
          setItems(result.results);
          setQuery(result.results[0].label);
          onChange(result.results[0]);
        } catch (e) {
          setError((e as Error).message);
        } finally {
          if (current === revision.current) setBusy(false);
        }
      },
      (e) => {
        if (current === revision.current) {
          setError(
            e.code === 1
              ? 'Standortzugriff nicht erlaubt. Du kannst die Adresse manuell eingeben.'
              : 'Standort nicht verfügbar. Bitte die Adresse eingeben.',
          );
          setBusy(false);
        }
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 },
    );
  }
  return (
    <div className="address-control">
      <div className="address-label">
        <label htmlFor={label}>{label}</label>
        {value && (
          <span>
            <Check size={13} />
            Ausgewählt
          </span>
        )}
      </div>
      <Combobox<Point>
        items={items}
        value={value}
        inputValue={value?.label || query}
        itemToStringLabel={(p) => p.label}
        isItemEqualToValue={(a, b) => a.id === b.id}
        onValueChange={(p) => void choose(p)}
        onInputValueChange={(v, details) => {
          if (details.reason === 'input-change') {
            revision.current++;
            setBusy(false);
            setItems([]);
            onChange(null);
            setQuery(v);
          }
        }}
        filter={null}
      >
        <div className="address-row">
          <ComboboxInput
            id={label}
            placeholder="Straße, Hausnummer, Ort"
            showTrigger={items.length > 0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !items.length) {
                e.preventDefault();
                void search();
              }
            }}
          />
          <Button
            aria-label={label + ' suchen'}
            variant="outline"
            disabled={busy}
            onClick={search}
          >
            <Search size={18} />
          </Button>
          {location && (
            <Button
              aria-label="Aktuellen Standort als Abholung auswählen"
              variant="outline"
              disabled={busy}
              onClick={locate}
            >
              <LocateFixed size={18} />
            </Button>
          )}
        </div>
        <ComboboxContent>
          <ComboboxList>
            {(p: Point) => (
              <ComboboxItem key={p.id} value={p}>
                <MapPin size={16} />
                {p.label}
              </ComboboxItem>
            )}
          </ComboboxList>
        </ComboboxContent>
      </Combobox>
      {busy && <output className="small-note">Adresse wird gesucht …</output>}
      {items.length > 0 && !value && (
        <p className="small-note">
          {items.length} Treffer gefunden. Bitte die passende Adresse im
          Auswahlmenü wählen.
        </p>
      )}
      {error && (
        <p className="field-error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
