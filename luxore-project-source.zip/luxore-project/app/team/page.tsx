'use client';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { api } from '@/app/mobility/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
export default function Team() {
  const [name, setName] = useState(''),
    [phone, setPhone] = useState(''),
    [message, setMessage] = useState(''),
    [busy, setBusy] = useState(false),
    [ready, setReady] = useState(false);
  useEffect(() => {
    api('session', {})
      .then(() =>
        api<{
          employee: {
            name: string;
            phone: string;
            fleet_name: string | null;
          } | null;
        }>('team'),
      )
      .then((v) => {
        if (v.employee) {
          setName(v.employee.name);
          setPhone(v.employee.phone);
          setMessage(
            v.employee.fleet_name
              ? 'Deine Flotte: ' + v.employee.fleet_name
              : 'Dein Profil wartet auf die Flottenzuordnung.',
          );
        }
        setReady(true);
      })
      .catch((e) => setMessage(e.message));
  }, []);
  return (
    <main className="team-entry">
      <Link href="/">LUXORÉ RIDE</Link>
      <h1>Dein Teamzugang</h1>
      <p>
        Profil auf diesem Gerät einreichen. Der Betreiber ordnet dich deiner
        Flotte zu. Besitzer und Stellvertreter erhalten anschließend Zugriff auf
        ihre Disposition.
      </p>
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          try {
            await api('team', { name, phone });
            setMessage(
              'Profil gespeichert. Der Betreiber kann dich jetzt deiner Flotte zuordnen.',
            );
          } catch (e) {
            setMessage((e as Error).message);
          } finally {
            setBusy(false);
          }
        }}
      >
        <label htmlFor="team-name">
          Name
          <Input
            id="team-name"
            value={name}
            required
            maxLength={80}
            onChange={(e) => setName(e.target.value)}
          />
        </label>
        <label htmlFor="team-phone">
          Telefon
          <Input
            id="team-phone"
            value={phone}
            required
            maxLength={30}
            type="tel"
            onChange={(e) => setPhone(e.target.value)}
          />
        </label>
        <Button type="submit" disabled={busy || !ready}>
          Profil einreichen
        </Button>
      </form>
      <output>{message}</output>
      <Link href="/disposition">Zur Disposition</Link>
      <p className="small-note">
        Der Zugang ist an dieses Gerät gebunden. Beim Löschen der Browser- oder
        App-Daten ist eine neue Zuordnung nötig.
      </p>
    </main>
  );
}
