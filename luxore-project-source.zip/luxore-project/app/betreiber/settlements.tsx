'use client';
import { useCallback, useEffect, useState } from 'react';
import { ChevronLeft } from 'lucide-react';
import { api } from '@/app/mobility/api';
import { money } from '@/lib/ride-domain';
import { WeekDetail, WeekNav, weekLabel } from '@/app/mobility/fleet-income';

type Row = {
  fleetId: string;
  fleetName: string;
  rateBps: number;
  trips: number;
  revenue: number;
  fee: number;
  net: number;
  status: 'open' | 'paid';
  paidAt: number | null;
  closed: boolean;
};
type State = { notice: string; week: string; currentWeek: string; fleets: Row[] };
const range = (week: string) => {
  const [y, m, d] = week.split('-').map(Number);
  const start = Date.UTC(y, m - 1, d, 12);
  // Monday noon to Sunday noon: safe on days with a clock change.
  return weekLabel(start, start + 6 * 86400000 + 1);
};
const pct = (bps: number) => String(bps / 100).replace('.', ',');
/** One fleet's rate: 0 % for the own fleet, any other rate up to 50 %. */
function RateRow({ row, onSaved }: { row: Row; onSaved: () => void }) {
  const [value, setValue] = useState(pct(row.rateBps)),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState('');
  useEffect(() => setValue(pct(row.rateBps)), [row.rateBps]);
  const parsed = Number(value.trim().replace(',', '.'));
  const bps = Math.round(parsed * 100);
  const valid =
    value.trim() !== '' &&
    Number.isFinite(parsed) &&
    parsed >= 0 &&
    parsed <= 50 &&
    Math.abs(parsed * 100 - bps) < 1e-6;
  const save = async (next: number) => {
    setBusy(true);
    setMessage('');
    try {
      await api('settlements', { action: 'set_rate', fleetId: row.fleetId, rateBps: next });
      setMessage('Gespeichert.');
      onSaved();
    } catch (e) {
      setMessage((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="pf-card">
      <div className="pf-row">
        <strong>{row.fleetName}</strong>
        <span className={'pf-chip' + (row.rateBps === 0 ? ' good' : '')}>
          {row.rateBps === 0 ? 'ohne Pauschale' : pct(row.rateBps) + ' %'}
        </span>
      </div>
      <label className="pf-field">
        Servicepauschale in Prozent
        <input
          inputMode="decimal"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          aria-invalid={!valid}
        />
        <small>0 bis 50, zum Beispiel 15 oder 12,5. Für die eigene Flotte 0.</small>
      </label>
      <div className="pf-actions">
        <button
          type="button"
          className="pf-btn primary"
          disabled={busy || !valid || bps === row.rateBps}
          onClick={() => save(bps)}
        >
          Satz speichern
        </button>
        <button
          type="button"
          className="pf-btn"
          disabled={busy || row.rateBps === 0}
          onClick={() => save(0)}
        >
          Eigene Flotte (0 %)
        </button>
      </div>
      {message && (
        <p className="pf-muted" role="status">
          {message}
        </p>
      )}
    </div>
  );
}
/** Operator: every fleet of one week, then the single fleet down to each trip. */
export default function OperatorSettlements() {
  const [week, setWeek] = useState(''),
    [data, setData] = useState<State | null>(null),
    [fleet, setFleet] = useState<string | null>(null),
    [error, setError] = useState('');
  const load = useCallback(async () => {
    try {
      const result = await api<State>('settlements' + (week ? '?week=' + week : ''));
      setData(result);
      if (!week) setWeek(result.week);
      setError('');
    } catch (e) {
      setError((e as Error).message);
    }
  }, [week]);
  useEffect(() => {
    void load();
  }, [load]);
  if (!data) return <p className="pf-muted">{error || 'Abrechnung wird geladen …'}</p>;
  if (fleet)
    return (
      <div className="pf">
        <button type="button" className="pf-btn" onClick={() => setFleet(null)}>
          <ChevronLeft size={18} /> Alle Flotten
        </button>
        <WeekDetail fleetId={fleet} week={week} onWeek={setWeek} onChanged={load} />
      </div>
    );
  const sum = (key: 'trips' | 'revenue' | 'fee' | 'net') =>
    data.fleets.reduce((s, r) => s + r[key], 0);
  const open = data.fleets
    .filter((r) => r.status === 'open' && r.closed)
    .reduce((s, r) => s + r.fee, 0);
  return (
    <div className="pf">
      <WeekNav
        week={data.week}
        current={data.currentWeek}
        label={range(data.week)}
        onChange={setWeek}
      />
      <p className="pf-notice">
        {data.notice}. Servicepauschale je kassierter Fahrt nach dem Satz der
        Flotte (Standard 15 %), ohne Bordprodukte; Zuordnung nach
        Kassierzeitpunkt.
      </p>
      {error && (
        <p className="pf-error" role="alert">
          {error}
        </p>
      )}
      <div className="pf-stats">
        <div className="pf-stat">
          <small>Fahrten</small>
          <strong>{sum('trips')}</strong>
        </div>
        <div className="pf-stat">
          <small>Umsatz aller Flotten</small>
          <strong>{money(sum('revenue'))}</strong>
        </div>
        <div className="pf-stat dark">
          <small>Servicepauschale gesamt</small>
          <strong>{money(sum('fee'))}</strong>
        </div>
        <div className="pf-stat">
          <small>Davon noch offen</small>
          <strong>{money(open)}</strong>
        </div>
      </div>
      <div className="pf-list">
        {data.fleets.map((r) => (
          <button
            type="button"
            className={'pf-card' + (r.status === 'open' && r.closed && r.fee ? ' attention' : '')}
            style={{ textAlign: 'left', cursor: 'pointer' }}
            key={r.fleetId}
            onClick={() => setFleet(r.fleetId)}
          >
            <div className="pf-row">
              <strong>{r.fleetName}</strong>
              <span
                className={
                  'pf-chip ' + (r.status === 'paid' ? 'good' : r.closed && r.fee ? 'warn' : '')
                }
              >
                {r.status === 'paid'
                  ? 'bezahlt'
                  : !r.closed
                    ? 'Woche läuft'
                    : r.fee
                      ? 'offen'
                      : 'keine Fahrten'}
              </span>
            </div>
            <span className="pf-muted">
              {r.trips} {r.trips === 1 ? 'Fahrt' : 'Fahrten'} · Umsatz{' '}
              {money(r.revenue)} · Pauschale{' '}
              {r.status === 'paid' ? '' : pct(r.rateBps) + ' % = '}
              {money(r.fee)} · Rest für die Flotte{' '}
              {money(r.net)}
            </span>
          </button>
        ))}
        {!data.fleets.length && <p className="pf-muted">Noch keine Flotte angelegt.</p>}
      </div>
      {data.fleets.length > 0 && (
        <details>
          <summary>
            <strong>Servicepauschale je Flotte einstellen</strong>
          </summary>
          <p className="pf-muted" style={{ padding: '0 var(--lx-space-4)' }}>
            Der Satz gilt für alle Wochen, die noch nicht als bezahlt vermerkt
            sind. Bezahlte Wochen bleiben unverändert. Der Fahrpreis für den
            Kunden ändert sich dadurch nicht.
          </p>
          <div className="pf-list" style={{ padding: 'var(--lx-space-4)' }}>
            {data.fleets.map((r) => (
              <RateRow key={r.fleetId} row={r} onSaved={load} />
            ))}
          </div>
        </details>
      )}
    </div>
  );
}
