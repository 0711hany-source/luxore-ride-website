'use client';
import { useCallback, useEffect, useState } from 'react';
import { api } from '@/app/mobility/api';
import { photoUrl } from '@/app/mobility/photo';
import Papers, { germanDate } from '@/app/mobility/papers';
import FleetCompliance, { HoldControl } from '@/app/mobility/fleet-compliance';
import type { KindRule, SubjectType } from '@/lib/mobility/compliance';

type Overview = {
  enforcedSince: number | null;
  counts: { review: number; applications: number; suspensions: number; defects: number };
  defects: {
    id: string;
    vehicle_id: string;
    model: string;
    plate: string;
    fleet_name: string | null;
    inspector_name: string;
    created_at: number;
    suspended: number;
    items: Record<string, { ok: boolean; note: string }>;
  }[];
  fleets: { id: string; name: string }[];
};
type Application = {
  id: string;
  fleet_id: string;
  company: string;
  legal_form: string;
  address: string;
  contact: string;
  phone: string;
  tax_id: string | null;
  email: string | null;
  status: string;
  reason: string | null;
  created_at: number;
  papers: number;
  papers_approved: number;
};
type ReviewDoc = {
  id: string;
  subject_type: SubjectType;
  subject_name: string | null;
  fleet_name: string | null;
  kind: string;
  number: string | null;
  expires_on: string | null;
  created_at: number;
  images: { id: string }[];
};
type Hold = {
  id: string;
  subject_type: SubjectType;
  subject_name: string | null;
  fleet_name: string | null;
  level: string;
  reason: string;
  created_by_name: string;
  created_at: number;
  lifted_at: number | null;
};
const when = (at: number) =>
  new Date(at).toLocaleString('de-DE', {
    timeZone: 'Europe/Berlin',
    dateStyle: 'short',
    timeStyle: 'short',
  });
const SUBJECTS: Record<SubjectType, string> = {
  driver: 'Fahrer',
  vehicle: 'Fahrzeug',
  fleet: 'Flotte',
};
function Decision({
  approveLabel,
  busy,
  onApprove,
  onReject,
}: {
  approveLabel: string;
  busy: boolean;
  onApprove: () => void;
  onReject: (reason: string) => void;
}) {
  const [mode, setMode] = useState<'idle' | 'approve' | 'reject'>('idle'),
    [reason, setReason] = useState('');
  if (mode === 'reject')
    return (
      <form
        className="pf-form"
        onSubmit={(e) => {
          e.preventDefault();
          onReject(reason);
        }}
      >
        <label className="pf-field">
          Grund der Ablehnung
          <input
            value={reason}
            required
            maxLength={300}
            placeholder="z. B. Foto unleserlich"
            onChange={(e) => setReason(e.target.value)}
          />
        </label>
        <div className="pf-actions">
          <button type="button" className="pf-btn" disabled={busy} onClick={() => setMode('idle')}>
            Abbrechen
          </button>
          <button type="submit" className="pf-btn danger" disabled={busy}>
            Ablehnen
          </button>
        </div>
      </form>
    );
  return (
    <div className="pf-actions">
      <button type="button" className="pf-btn danger" disabled={busy} onClick={() => setMode('reject')}>
        Ablehnen …
      </button>
      <button
        type="button"
        className="pf-btn primary"
        disabled={busy}
        onClick={() => (mode === 'approve' ? onApprove() : setMode('approve'))}
      >
        {mode === 'approve' ? 'Wirklich ' + approveLabel.toLowerCase() : approveLabel}
      </button>
    </div>
  );
}
/** Operator: enforcement switch, applications, papers to review, defects, holds. */
export default function OperatorReview() {
  const [overview, setOverview] = useState<Overview | null>(null),
    [applications, setApplications] = useState<Application[]>([]),
    [documents, setDocuments] = useState<ReviewDoc[]>([]),
    [kinds, setKinds] = useState<Record<string, Record<string, KindRule>>>({}),
    [holds, setHolds] = useState<Hold[]>([]),
    [expiry, setExpiry] = useState<Record<string, string>>({}),
    [fleet, setFleet] = useState(''),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [confirmSwitch, setConfirmSwitch] = useState(false);
  const load = useCallback(async () => {
    try {
      const [o, a, d, h] = await Promise.all([
        api<Overview>('compliance?scope=operator'),
        api<{ all?: Application[] }>('fleet-applications'),
        api<{ documents: ReviewDoc[]; kinds: Record<string, Record<string, KindRule>> }>(
          'documents?scope=review',
        ),
        api<{ suspensions: Hold[] }>('suspensions'),
      ]);
      setOverview(o);
      setApplications(a.all || []);
      setDocuments(d.documents);
      setKinds(d.kinds);
      setHolds(h.suspensions.filter((s) => !s.lifted_at));
      setError('');
    } catch (e) {
      setError((e as Error).message);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  async function act(path: string, body: Record<string, unknown>) {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      await api(path, body);
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  if (!overview) return <p className="pf-muted">{error || 'Prüfung wird geladen …'}</p>;
  const pending = applications.filter((a) => a.status === 'submitted');
  return (
    <div className="pf">
      {error && (
        <p className="pf-error" role="alert">
          {error}
        </p>
      )}
      <div className={'pf-card' + (overview.enforcedSince ? ' attention' : '')}>
        <div className="pf-switch">
          <div>
            <h3>Prüfpflicht</h3>
            <p className="pf-muted">
              {overview.enforcedSince
                ? `Aktiv seit ${when(overview.enforcedSince)}. Ohne geprüfte Pflichtpapiere und gültige Wochenkontrolle kann niemand online gehen.`
                : 'Ausgeschaltet. Fehlende Papiere und Kontrollen werden nur als Hinweis gezeigt; niemand wird automatisch gesperrt.'}
            </p>
          </div>
          <span className={'pf-chip ' + (overview.enforcedSince ? 'good' : '')}>
            {overview.enforcedSince ? 'AN' : 'AUS'}
          </span>
        </div>
        {confirmSwitch && !overview.enforcedSince && (
          <p className="pf-notice warn">
            Ab dem Einschalten können Fahrer ohne geprüften Führerschein und
            Personenbeförderungsschein, Fahrzeuge ohne geprüfte Papiere oder
            ohne Wochenkontrolle der letzten 7 Tage sowie Flotten ohne geprüfte
            Gewerbeanmeldung keine neue Schicht mehr beginnen. Laufende Fahrten
            und Schichten werden nicht beendet. Bitte vorher unter „Flotte
            ansehen“ prüfen, ob alle vorbereitet sind.
          </p>
        )}
        <div className="pf-actions">
          {confirmSwitch && (
            <button type="button" className="pf-btn" onClick={() => setConfirmSwitch(false)}>
              Abbrechen
            </button>
          )}
          <button
            type="button"
            className={'pf-btn ' + (overview.enforcedSince ? '' : 'primary')}
            disabled={busy}
            onClick={() => {
              if (!confirmSwitch) return setConfirmSwitch(true);
              setConfirmSwitch(false);
              void act('compliance', {
                action: 'enforcement',
                enabled: !overview.enforcedSince,
              });
            }}
          >
            {overview.enforcedSince
              ? confirmSwitch
                ? 'Wirklich ausschalten'
                : 'Prüfpflicht ausschalten'
              : confirmSwitch
                ? 'Jetzt verbindlich einschalten'
                : 'Prüfpflicht einschalten …'}
          </button>
        </div>
      </div>
      <div className="pf-stats">
        <div className="pf-stat">
          <small>Flottenanträge offen</small>
          <strong>{overview.counts.applications}</strong>
        </div>
        <div className="pf-stat">
          <small>Papiere zu prüfen</small>
          <strong>{overview.counts.review}</strong>
        </div>
        <div className="pf-stat">
          <small>Fahrzeuge mit Mangel</small>
          <strong>{overview.counts.defects}</strong>
        </div>
        <div className="pf-stat">
          <small>Aktive Sperren</small>
          <strong>{overview.counts.suspensions}</strong>
        </div>
      </div>

      <h3>Flottenanträge</h3>
      {!pending.length && <p className="pf-muted">Kein offener Antrag.</p>}
      {pending.map((a) => (
        <div className="pf-card attention" key={a.id}>
          <div className="pf-row">
            <strong>
              {a.company} ({a.legal_form})
            </strong>
            <span className="pf-chip warn">Antrag vom {when(a.created_at)}</span>
          </div>
          <p className="pf-muted">
            {a.address}
            <br />
            {a.contact} · <a href={'tel:' + a.phone}>{a.phone}</a>
            {a.email ? ' · ' + a.email : ''}
            {a.tax_id ? ' · Steuernr./USt-ID: ' + a.tax_id : ''}
            <br />
            Servicepauschale 15 % und wöchentliche Abrechnung bestätigt.
          </p>
          <details>
            <summary>
              <span>
                Unterlagen ({a.papers_approved} von {a.papers} geprüft)
              </span>
            </summary>
            <div className="pf-details-body">
              <Papers subjectType="fleet" subjectId={a.fleet_id} onChanged={load} />
            </div>
          </details>
          <Decision
            approveLabel="Annehmen und Flotte anlegen"
            busy={busy}
            onApprove={() => void act('fleet-applications', { action: 'approve', id: a.id })}
            onReject={(reason) =>
              void act('fleet-applications', { action: 'reject', id: a.id, reason })
            }
          />
        </div>
      ))}
      {applications.some((a) => a.status !== 'submitted') && (
        <details>
          <summary>
            <span>Bearbeitete Anträge</span>
          </summary>
          <div className="pf-details-body">
            {applications
              .filter((a) => a.status !== 'submitted')
              .map((a) => (
                <div className="pf-trip" key={a.id}>
                  <span>{a.company}</span>
                  <b>
                    {a.status === 'approved'
                      ? 'angenommen'
                      : a.status === 'rejected'
                        ? 'abgelehnt'
                        : 'zurückgezogen'}
                  </b>
                  <small>
                    {a.contact} · {when(a.created_at)}
                    {a.reason ? ' · Grund: ' + a.reason : ''}
                  </small>
                </div>
              ))}
          </div>
        </details>
      )}

      <h3>Prüfung offen</h3>
      {!documents.length && <p className="pf-muted">Keine Papiere zu prüfen.</p>}
      {documents.map((d) => {
        const rule = kinds[d.subject_type]?.[d.kind];
        return (
          <div className="pf-card" key={d.id}>
            <div className="pf-row">
              <strong>{rule?.label || d.kind}</strong>
              <span className="pf-chip">
                {SUBJECTS[d.subject_type]} · {d.subject_name || '–'}
              </span>
            </div>
            <p className="pf-muted">
              {d.fleet_name ? d.fleet_name + ' · ' : ''}eingereicht {when(d.created_at)}
              {d.number ? ' · Nr. ' + d.number : ''}
              {d.expires_on ? ' · gültig bis ' + germanDate(d.expires_on) : ''}
            </p>
            {d.images.length ? (
              <div className="pf-thumbs large">
                {d.images.map((i) => (
                  <a
                    key={i.id}
                    href={photoUrl(i.id)}
                    target="_blank"
                    rel="noreferrer"
                    aria-label="Foto in voller Größe öffnen"
                  >
                    <img src={photoUrl(i.id)} alt="" loading="lazy" />
                  </a>
                ))}
              </div>
            ) : (
              <p className="pf-notice danger">Kein Foto vorhanden.</p>
            )}
            {rule && rule.expiry !== 'none' && (
              <label className="pf-field">
                Gültig bis{rule.expiry === 'optional' ? ' (freiwillig)' : ''} – vom
                Foto prüfen
                <input
                  type="date"
                  value={expiry[d.id] ?? d.expires_on ?? ''}
                  onChange={(e) => setExpiry((v) => ({ ...v, [d.id]: e.target.value }))}
                />
              </label>
            )}
            <Decision
              approveLabel="Freigeben"
              busy={busy}
              onApprove={() =>
                void act('documents', {
                  action: 'review',
                  id: d.id,
                  decision: 'approved',
                  expiresOn: (expiry[d.id] ?? d.expires_on) || undefined,
                })
              }
              onReject={(reason) =>
                void act('documents', {
                  action: 'review',
                  id: d.id,
                  decision: 'rejected',
                  reason,
                })
              }
            />
          </div>
        );
      })}

      <h3>Fahrzeuge mit Mangel</h3>
      {!overview.defects.length && (
        <p className="pf-muted">Keine Kontrolle mit Mangel offen.</p>
      )}
      {overview.defects.map((d) => (
        <div className="pf-card blocked" key={d.id}>
          <div className="pf-row">
            <strong>
              {d.model} · {d.plate}
            </strong>
            <span className={'pf-chip ' + (d.suspended ? 'danger' : 'warn')}>
              {d.suspended ? 'gesperrt' : 'nicht gesperrt'}
            </span>
          </div>
          <p className="pf-muted">
            {d.fleet_name || 'Ohne Flotte'} · Kontrolle {when(d.created_at)} durch{' '}
            {d.inspector_name}
          </p>
          {Object.entries(d.items)
            .filter(([, v]) => !v.ok)
            .map(([key, v]) => (
              <p className="pf-notice danger" key={key}>
                {v.note}
              </p>
            ))}
          {!d.suspended && (
            <HoldControl
              subjectType="vehicle"
              subjectId={d.vehicle_id}
              holds={[]}
              operator
              onChanged={load}
            />
          )}
        </div>
      ))}

      <h3>Aktive Sperren</h3>
      {!holds.length && <p className="pf-muted">Niemand ist gesperrt.</p>}
      {holds.map((h) => (
        <div className="pf-card blocked" key={h.id}>
          <div className="pf-row">
            <strong>
              {SUBJECTS[h.subject_type]} · {h.subject_name || '–'}
            </strong>
            <span className="pf-chip danger">
              {h.level === 'operator' ? 'Betreiber-Sperre' : 'Sperre der Flotte'}
            </span>
          </div>
          <p className="pf-muted">
            {h.reason} · {h.created_by_name} · {when(h.created_at)}
            {h.fleet_name ? ' · ' + h.fleet_name : ''}
          </p>
          <button
            type="button"
            className="pf-btn"
            disabled={busy}
            onClick={() => void act('suspensions', { action: 'lift', id: h.id })}
          >
            Wieder freigeben
          </button>
        </div>
      ))}

      <h3>Flotte ansehen: Papiere, Kontrollen, Sperren</h3>
      <label className="pf-field">
        Flotte
        <select value={fleet} onChange={(e) => setFleet(e.target.value)}>
          <option value="">Bitte wählen</option>
          {overview.fleets.map((f) => (
            <option key={f.id} value={f.id}>
              {f.name}
            </option>
          ))}
        </select>
      </label>
      {fleet && <FleetCompliance key={fleet} fleetId={fleet} />}
    </div>
  );
}
