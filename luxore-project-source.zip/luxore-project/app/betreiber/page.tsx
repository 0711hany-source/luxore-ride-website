import { headers } from 'next/headers';
import Link from 'next/link';
import { LockKeyhole } from 'lucide-react';
import { accountUser } from '@/lib/mobility/accounts';
import { accountsConfigured } from '@/db/sqlite';
import { isAdmin } from '@/lib/mobility/server';
import OperatorConsole from './console';
export { viewport } from '@/app/mobile/layout';
export const dynamic = 'force-dynamic';
export const metadata = {
  title: 'Betreiber | LUXORÉ RIDE',
  robots: { index: false, follow: false },
};
export default async function Page() {
  const user = accountsConfigured() ? await accountUser(await headers()) : null;
  if (user && isAdmin(user)) return <OperatorConsole name={user.displayName} />;
  return (
    <main className="operator-locked">
      <Link href="/" className="lux-logo">
        LUXORÉ <span>RIDE</span>
      </Link>
      <div className="account-card">
        <LockKeyhole size={30} />
        <h1>Betreiberbereich</h1>
        <p>
          Diese Übersicht ist ausschließlich für das freigegebene Betreiberkonto
          zugänglich.
        </p>
        <Link className="portal-primary" href="/konto?weiter=%2Fbetreiber">
          Mit Luxóre-Konto anmelden
        </Link>
        <p className="portal-muted">
          Ein Flottenleiterkonto hat keinen Zugriff auf die Gesamtverwaltung.
        </p>
      </div>
    </main>
  );
}
