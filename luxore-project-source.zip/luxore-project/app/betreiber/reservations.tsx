'use client';
import { useCallback, useEffect, useState } from 'react';
import { api } from '@/app/mobility/api';
import FleetReservations from '@/app/mobility/fleet-reservations';
import { StarsShown } from '@/app/mobility/rating';

type Settings = {
  ownFleetId: string | null;
  fleets: { id: string; name: string }[];
  rules: {
    foreignFleetAfterMinutes: number;
    foreignFleetBeforePickupMinutes: number;
  };
};
type Comment = { stars: number; comment: string; createdAt: number };
type Rated = {
  id: string;
  name: string;
  fleetName?: string | null;
  count: number;
  average: number | null;
  comments: Comment[];
};
type Overview = { drivers: Rated[]; customers: Rated[] };
const comma = (v: number) => v.toFixed(1).replace('.', ',');
const day = (at: number) =>
  new Date(at).toLocaleDateString('de-DE', { timeZone: 'Europe/Berlin' });
function RatedList({ list, empty }: { list: Rated[]; empty: string }) {
  if (!list.length) return <p className="pf-muted">{empty}</p>;
  return (
    <div className="pf-list">
      {list.map((p) => (
        <details key={p.id}>
          <summary>
            <span>
              {p.name}
              <small>
                {p.fleetName ? p.fleetName + ' · ' : ''}
                {p.count
                  ? `Ø ${comma(p.average ?? 0)} aus ${p.count} ${p.count === 1 ? 'Bewertung' : 'Bewertungen'}`
                  : 'Noch keine Bewertung'}
              </small>
            </span>
          </summary>
          <div className="pf-details-body">
            {p.comments.length ? (
              p.comments.map((c) => (
                <div className="pf-trip" key={c.createdAt + c.comment}>
                  <span style={{ whiteSpace: 'normal' }}>{c.comment}</span>
                  <StarsShown stars={c.stars} />
                  <small>{day(c.createdAt)}</small>
                </div>
              ))
            ) : (
              <p className="pf-muted">Keine Kommentare.</p>
            )}
          </div>
        </details>
      ))}
    </div>
  );
}
/** Operator: own fleet (priority on the board), reservations, ratings. */
export default function OperatorReservations() {
  const [settings, setSettings] = useState<Settings | null>(null),
    [ratings, setRatings] = useState<Overview | null>(null),
    [choice, setChoice] = useState(''),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [saved, setSaved] = useState('');
  const load = useCallback(async () => {
    try {
      const s = await api<Settings>('reservations?scope=settings');
      setSettings(s);
      setChoice(s.ownFleetId || '');
      setRatings(await api<Overview>('ratings?scope=staff'));
      setError('');
    } catch (e) {
      setError((e as Error).message);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  async function save() {
    setBusy(true);
    setSaved('');
    try {
      await api('reservations', { action: 'own-fleet', fleetId: choice || null });
      setSaved('Gespeichert.');
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="pf">
      {error && (
        <p className="pf-error" role="alert">
          {error}
        </p>
      )}
      <div className="pf-card">
        <h3>Eigene Flotte</h3>
        <p className="pf-muted">
          Fahrer der eigenen Flotte sehen jede passende Reservierung sofort.
          Fahrer anderer Flotten sehen sie erst, wenn sie seit{' '}
          {(settings?.rules.foreignFleetAfterMinutes ?? 120) / 60} Stunden
          angelegt ist oder die Abholung in weniger als{' '}
          {(settings?.rules.foreignFleetBeforePickupMinutes ?? 180) / 60}{' '}
          Stunden liegt. Ohne eigene Flotte sehen alle sofort alles Passende.
        </p>
        <label className="pf-field">
          Eigene Flotte
          <select
            value={choice}
            disabled={!settings || busy}
            onChange={(e) => setChoice(e.target.value)}
          >
            <option value="">Keine – alle Flotten gleich</option>
            {settings?.fleets.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>
        </label>
        <button
          type="button"
          className="pf-btn primary"
          disabled={!settings || busy || choice === (settings.ownFleetId || '')}
          onClick={() => void save()}
        >
          Speichern
        </button>
        {saved && (
          <p className="pf-saved" role="status">
            {saved}
          </p>
        )}
      </div>
      <FleetReservations />
      <h3>Bewertungen der Fahrer</h3>
      <p className="pf-muted">
        Fahrgäste sehen den Durchschnitt erst ab 3 Bewertungen. Kommentare
        sehen nur Betreiber und Flottenleitung.
      </p>
      <RatedList
        list={ratings?.drivers || []}
        empty="Noch keine Fahrer vorhanden."
      />
      <h3>Bewertungen der Fahrgäste</h3>
      <RatedList
        list={ratings?.customers || []}
        empty="Fahrer haben noch keinen Fahrgast bewertet."
      />
    </div>
  );
}
