'use client';
import { useCallback, useEffect, useState, useRef } from 'react';
import Link from 'next/link';
import {
  LayoutDashboard,
  UserRound,
  ShieldCheck,
  CarFront,
  ClipboardCheck,
  RefreshCw,
  Search,
  Check,
  LockKeyhole,
  FileClock,
  Trash2,
  Menu,
  X,
} from 'lucide-react';
import { api, MobilityApiError } from '@/app/mobility/api';
import { money } from '@/lib/ride-domain';
import Fleets from '@/app/mobility/fleets';
import { useAppViewport } from '@/app/mobility/use-app-viewport';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
type Profile = {
  id: string;
  name: string;
  email: string;
  phone: string;
  kind: string;
  status: string;
  created_at: number;
  approved: number | null;
  fleet_name: string | null;
};
type Pending = {
  id: string;
  name: string;
  phone: string;
  fleet_name: string | null;
  plate: string;
};
type State = {
  summary: Record<string, number>;
  profiles: Profile[];
  total: { total: number };
  page: number;
  pending: Pending[];
  audit: {
    action: string;
    subject_id: string;
    subject_name: string;
    actor_name: string;
    created_at: number;
  }[];
  readiness: Record<string, boolean>;
  refreshedAt: number;
};
const sections = [
  { id: 'overview', label: 'Übersicht', Icon: LayoutDashboard },
  { id: 'profiles', label: 'Profile', Icon: UserRound },
  { id: 'approvals', label: 'Genehmigungen', Icon: ShieldCheck },
  { id: 'fleet', label: 'Flotten & Fahrzeuge', Icon: CarFront },
  { id: 'launch', label: 'Startvorbereitung', Icon: ClipboardCheck },
  { id: 'audit', label: 'Aktivitäten', Icon: FileClock },
];
const kinds: Record<string, string> = {
  customer: 'Fahrgast',
  driver: 'Chauffeur',
  fleet: 'Flottenbewerbung',
};
const date = (n: number) =>
  new Date(n).toLocaleString('de-DE', {
    timeZone: 'Europe/Berlin',
    dateStyle: 'short',
    timeStyle: 'short',
  });
export default function OperatorConsole({ name }: { name: string }) {
  useAppViewport(true);
  const [view, setView] = useState('overview'),
    [nav, setNav] = useState(false);
  const [data, setData] = useState<State | null>(null),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  const [query, setQuery] = useState(''),
    [q, setQ] = useState(''),
    [filter, setFilter] = useState('all'),
    [page, setPage] = useState(0);
  const [checked, setChecked] = useState<Record<string, boolean>>({});
  const [confirm, setConfirm] = useState<{
    profile: Profile;
    action: string;
  } | null>(null);
  const requestRef = useRef<AbortController | null>(null);
  const refresh = useCallback(async () => {
    requestRef.current?.abort();
    const controller = new AbortController();
    requestRef.current = controller;
    try {
      const result = await api<State>(
        `operator?q=${encodeURIComponent(q)}&filter=${filter}&page=${page}`,
        undefined,
        controller.signal,
      );
      if (!controller.signal.aborted) {
        setData(result);
        setError('');
      }
    } catch (e) {
      if (controller.signal.aborted) return;
      if (
        e instanceof MobilityApiError &&
        (e.status === 401 || e.status === 403)
      ) {
        setData(null);
        window.location.replace('/betreiber');
        return;
      }
      setError((e as Error).message);
    }
  }, [q, filter, page]);
  useEffect(() => {
    void refresh();
    const timer = setInterval(() => {
      if (!document.hidden) void refresh();
    }, 30000);
    return () => {
      clearInterval(timer);
      requestRef.current?.abort();
    };
  }, [refresh]);
  async function approval(driver: Pending) {
    if (busy || !checked[driver.id]) return;
    setBusy(true);
    try {
      await api('operations', { driverId: driver.id, approved: true });
      await refresh();
      setChecked((v) => ({ ...v, [driver.id]: false }));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function manage() {
    if (!confirm || busy) return;
    setBusy(true);
    try {
      await api('operator', {
        action: confirm.action,
        accountId: confirm.profile.id,
        confirmation: confirm.action === 'erase' ? 'LÖSCHEN' : undefined,
      });
      setConfirm(null);
      await refresh();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  function navigate(next: string) {
    setView(next);
    setNav(false);
    setQuery('');
    setQ('');
    setFilter('all');
    setPage(0);
  }
  const s = data?.summary;
  const profileCards = (profiles: Profile[]) =>
    profiles.length ? (
      <div className="operator-profiles">
        {profiles.map((p) => (
          <article key={p.id}>
            <div className="operator-avatar">
              {p.name.trim().slice(0, 1).toUpperCase()}
            </div>
            <div className="operator-profile-text">
              <strong>{p.name}</strong>
              <span>{p.email}</span>
              <small>
                {kinds[p.kind]} · {p.fleet_name || 'Keine Flotte'} ·{' '}
                {date(p.created_at)}
              </small>
              <a href={`tel:${p.phone}`}>{p.phone}</a>
            </div>
            <div className="operator-profile-actions">
              <span
                className={`operator-chip ${p.status === 'active' ? '' : 'attention'}`}
              >
                {p.status === 'active'
                  ? p.approved === 0
                    ? 'Fahrerprüfung offen'
                    : 'Konto aktiv'
                  : p.status === 'blocked'
                    ? 'Gesperrt'
                    : 'Löschung angefragt'}
              </span>
              <button
                type="button"
                disabled={busy}
                onClick={() =>
                  setConfirm({
                    profile: p,
                    action:
                      p.status === 'blocked'
                        ? 'restore'
                        : p.status === 'deletion_pending'
                          ? 'erase'
                          : 'block',
                  })
                }
              >
                {p.status === 'blocked'
                  ? 'Entsperren'
                  : p.status === 'deletion_pending'
                    ? 'Löschung bearbeiten'
                    : 'Konto sperren'}
              </button>
            </div>
          </article>
        ))}
      </div>
    ) : (
      <div className="operator-empty">
        <UserRound size={25} />
        <h3>Keine Profile gefunden</h3>
        <p>Neue bestätigte Registrierungen erscheinen hier automatisch.</p>
      </div>
    );
  return (
    <main className="operator-page">
      <aside className={'operator-sidebar' + (nav ? ' open' : '')}>
        <div className="operator-sidebar-brand">
          <Link href="/" className="lux-logo">
            LUXORÉ <span>RIDE</span>
          </Link>
          <button
            type="button"
            aria-label="Menü schließen"
            onClick={() => setNav(false)}
          >
            <X size={20} />
          </button>
        </div>
        <span className="operator-access-label">
          <LockKeyhole size={14} /> Betreiberzugang
        </span>
        <nav aria-label="Betreiberverwaltung">
          {sections.map(({ id, label, Icon }) => (
            <button
              type="button"
              className={view === id ? 'active' : ''}
              key={id}
              onClick={() => {
                navigate(id);
                setNav(false);
              }}
            >
              <Icon size={20} />
              {label}
              {id === 'approvals' && !!s?.pending && <span>{s.pending}</span>}
            </button>
          ))}
        </nav>
        <div className="operator-sidebar-bottom">
          <strong>{name}</strong>
          <Link href="/konto">Mein Konto</Link>
          <Link href="/mobile/driver">Zur Fahrer-App</Link>
        </div>
      </aside>
      {nav && (
        <button
          type="button"
          className="operator-nav-overlay"
          aria-label="Menü schließen"
          onClick={() => setNav(false)}
        />
      )}
      <div className="operator-main">
        <header className="operator-header">
          <button
            className="operator-menu-button"
            type="button"
            aria-label="Menü öffnen"
            onClick={() => setNav(true)}
          >
            <Menu size={23} />
          </button>
          <div>
            <span className="portal-eyebrow">LUXORÉ CONTROL</span>
            <h1>{sections.find((v) => v.id === view)?.label}</h1>
          </div>
          <button
            className="operator-refresh"
            type="button"
            disabled={busy}
            onClick={() => void refresh()}
            aria-label="Übersicht aktualisieren"
          >
            <RefreshCw size={18} />
            <span>Aktualisieren</span>
          </button>
        </header>
        {error && (
          <p className="portal-error" role="alert">
            {error}
          </p>
        )}
        {!data ? (
          <p role="status">Die Übersicht wird geladen …</p>
        ) : (
          <>
            <div className="operator-sync">
              Stand: {date(data.refreshedAt)} · Gesamtübersicht aller Flotten
            </div>
            {view === 'overview' && (
              <>
                <div className="operator-stats">
                  {[
                    {
                      label: 'Tagesumsatz',
                      value: money(s!.todayRevenue),
                      detail: 'Abgeschlossene Fahrten · Berlin-Zeit',
                    },
                    {
                      label: 'Im Einsatz',
                      value: s!.online,
                      detail: 'Fahrer mit aktuellem Standort',
                    },
                    {
                      label: 'Offene Freigaben',
                      value: s!.pending,
                      detail: 'Neue und noch nicht aktivierte Fahrer',
                    },
                    {
                      label: 'Offene Beträge',
                      value: money(s!.outstanding),
                      detail: 'Abgeschlossene, noch nicht kassierte Fahrten',
                    },
                  ].map((t) => (
                    <article key={t.label}>
                      <span>{t.label}</span>
                      <strong>{t.value}</strong>
                      <small>{t.detail}</small>
                    </article>
                  ))}
                </div>
                <div className="operator-summary-row">
                  <span>
                    <strong>{s!.fleets}</strong> Flotten
                  </span>
                  <span>
                    <strong>{s!.vehicles}</strong> aktive Fahrzeuge
                  </span>
                  <span>
                    <strong>{s!.accounts}</strong> Konten
                  </span>
                  <span>
                    <strong>{s!.activeTrips}</strong> laufende Fahrten
                  </span>
                  <span>
                    <strong>{s!.reservations}</strong> Reservierungen
                  </span>
                </div>
                <div className="operator-section-title">
                  <h2>Neue Profile</h2>
                  <button type="button" onClick={() => navigate('profiles')}>
                    Alle Profile
                  </button>
                </div>
                {profileCards(data.profiles.slice(0, 5))}
                <div className="operator-quick-actions">
                  <Link href="/disposition">Disposition öffnen</Link>
                  <button type="button" onClick={() => navigate('approvals')}>
                    Fahrer prüfen
                  </button>
                  <button type="button" onClick={() => navigate('launch')}>
                    Startvorbereitung ansehen
                  </button>
                </div>
              </>
            )}
            {view === 'profiles' && (
              <>
                <form
                  className="operator-filters"
                  onSubmit={(e) => {
                    e.preventDefault();
                    setQ(query);
                    setPage(0);
                  }}
                >
                  <label className="operator-search">
                    <Search size={18} />
                    <input
                      aria-label="Profile nach Name oder E-Mail suchen"
                      placeholder="Name oder E-Mail suchen"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                    />
                  </label>
                  <select
                    aria-label="Profile filtern"
                    value={filter}
                    onChange={(e) => {
                      setFilter(e.target.value);
                      setPage(0);
                    }}
                  >
                    <option value="all">Alle Profile</option>
                    <option value="pending">Fahrerprüfung offen</option>
                    <option value="blocked">Gesperrte Konten</option>
                    <option value="deletion">Löschanfragen</option>
                  </select>
                  <button type="submit">Suchen</button>
                </form>
                {profileCards(data.profiles)}
                <div className="operator-pagination">
                  <button
                    type="button"
                    disabled={page === 0}
                    onClick={() => setPage(page - 1)}
                  >
                    Zurück
                  </button>
                  <span>
                    {data.total.total} Profile · Seite {page + 1}
                  </span>
                  <button
                    type="button"
                    disabled={(page + 1) * 20 >= data.total.total}
                    onClick={() => setPage(page + 1)}
                  >
                    Weiter
                  </button>
                </div>
              </>
            )}
            {view === 'approvals' && (
              <>
                <p className="operator-intro">
                  Prüfe Identität, Fahrerlaubnis zur Fahrgastbeförderung und die
                  Zuordnung zur richtigen Flotte. Eine Freigabe ersetzt keine
                  behördliche Genehmigung.
                </p>
                {data.pending.length ? (
                  <div className="operator-approvals">
                    {data.pending.map((d) => (
                      <article key={d.id}>
                        <div className="operator-approval-heading">
                          <div>
                            <h2>{d.name}</h2>
                            <span>
                              {d.fleet_name || 'Noch keiner Flotte zugeordnet'}
                            </span>
                            <a href={`tel:${d.phone}`}>{d.phone}</a>
                          </div>
                          <span className="operator-chip attention">
                            Prüfung offen
                          </span>
                        </div>
                        <label className="account-consent">
                          <input
                            type="checkbox"
                            checked={!!checked[d.id]}
                            onChange={(e) =>
                              setChecked((v) => ({
                                ...v,
                                [d.id]: e.target.checked,
                              }))
                            }
                          />
                          <span>
                            Ich habe die erforderlichen Unterlagen und die
                            Fahrerberechtigung geprüft.
                          </span>
                        </label>
                        <button
                          className="portal-primary"
                          type="button"
                          disabled={busy || !checked[d.id]}
                          onClick={() => void approval(d)}
                        >
                          Fahrerprofil freigeben
                        </button>
                      </article>
                    ))}
                  </div>
                ) : (
                  <div className="operator-empty">
                    <ShieldCheck size={28} />
                    <h2>Keine offenen Fahrerfreigaben</h2>
                    <p>Neue Chauffeurprofile erscheinen hier zur Prüfung.</p>
                  </div>
                )}
              </>
            )}
            {view === 'fleet' && <Fleets />}
            {view === 'launch' && (
              <>
                <p className="operator-intro">
                  Die Website kann veröffentlicht werden. Diese Übersicht zeigt
                  getrennt, welche Voraussetzungen für die öffentliche
                  App-Veröffentlichung noch fehlen.
                </p>
                <div className="operator-readiness">
                  {[
                    {
                      label: 'Eigene Konten & E-Mail-Codes',
                      done: data.readiness.accounts,
                      text: 'Resend-Konto, verifizierte Absenderdomain und Versandzugang hinterlegen. Erst danach ist die öffentliche Registrierung aktiv.',
                    },
                    {
                      label: 'Karte & Straßenrouten',
                      done: data.readiness.maps,
                      text: 'Mapbox ist angebunden. Verbrauch überwachen und Navigation auf dem echten Fahrerhandy prüfen.',
                    },
                    {
                      label: 'Kartenzahlungen',
                      done: data.readiness.cardPayments,
                      text: 'Noch kein Zahlungsanbieter verbunden. Die App verarbeitet keine Karten- oder Wallet-Zahlungen.',
                    },
                    {
                      label: 'Android-Betriebstest',
                      done: data.readiness.backgroundDeviceTest,
                      text: 'Kunden- und Fahrergerät, Vermittlung, Sperrbildschirm, Hintergrundortung und Wiederanlauf praktisch prüfen.',
                    },
                    {
                      label: 'Google Play & App Store',
                      done: data.readiness.stores,
                      text: 'Entwicklerkonten, Release-Signierung, Datenschutzangaben, Screenshots und Store-Prüfung stehen aus.',
                    },
                  ].map((r) => (
                    <article key={r.label}>
                      <span
                        className={
                          'operator-readiness-icon' + (r.done ? ' done' : '')
                        }
                      >
                        {r.done ? (
                          <Check size={22} />
                        ) : (
                          <ClipboardCheck size={22} />
                        )}
                      </span>
                      <div>
                        <h2>{r.label}</h2>
                        <p>{r.text}</p>
                      </div>
                      <span className="operator-chip">
                        {r.done ? 'Verbunden' : 'Offen'}
                      </span>
                    </article>
                  ))}
                </div>
                <div className="operator-section-title">
                  <h2>Für die offizielle Freigabe</h2>
                </div>
                <ul className="operator-launch-list">
                  <li>
                    Vollständige Betreiberangaben, Beförderungsbedingungen und
                    Datenschutzprüfung bestätigen.
                  </li>
                  <li>
                    Fahrer, Flotten, Fahrzeuge und betriebliche Genehmigungen
                    prüfen.
                  </li>
                  <li>
                    Reservierungen ohne offene App zuverlässig auslösen;
                    Überwachung und Datensicherung nachweisen.
                  </li>
                  <li>
                    Produktionsschlüssel und Entwicklerkonten im Besitz des
                    Unternehmens einrichten.
                  </li>
                </ul>
                <Link className="portal-secondary" href="/hilfe">
                  Öffentliche Hilfe ansehen
                </Link>
              </>
            )}
            {view === 'audit' && (
              <>
                <p className="operator-intro">
                  Kontoanmeldungen, Kontosperren, Löschanfragen und
                  Fahrerfreigaben werden protokolliert.
                </p>
                <div className="operator-audit">
                  {data.audit.length ? (
                    data.audit.map((a, i) => (
                      <article key={i}>
                        <FileClock size={19} />
                        <div>
                          <strong>
                            {{
                              'account.signin': 'Konto angemeldet',
                              'account.restored': 'Konto entsperrt',
                              'account.blocked': 'Konto gesperrt',
                              'account.deletion_requested':
                                'Löschung angefragt',
                              'account.erased': 'Kontodaten gelöscht',
                              'fleet.owner_transferred':
                                'Flottenleitung übertragen',
                              'driver.approved': 'Fahrer freigegeben',
                              'driver.unapproved':
                                'Fahrerfreigabe zurückgenommen',
                            }[a.action] || a.action}
                          </strong>
                          <small>
                            {a.subject_name} · {a.actor_name}
                          </small>
                        </div>
                        <time>{date(a.created_at)}</time>
                      </article>
                    ))
                  ) : (
                    <div className="operator-empty">
                      <FileClock size={26} />
                      <p>Noch keine Aktivitäten protokolliert.</p>
                    </div>
                  )}
                </div>
              </>
            )}
          </>
        )}
      </div>
      <Dialog
        open={!!confirm}
        onOpenChange={(open) => {
          if (!open && !busy) setConfirm(null);
        }}
      >
        <DialogContent className="fleet-vehicle-dialog operator-confirm-dialog">
          <DialogHeader>
            <DialogTitle>
              {confirm?.action === 'erase'
                ? 'Kontodaten löschen'
                : confirm?.action === 'restore'
                  ? 'Konto entsperren'
                  : 'Konto sperren'}
            </DialogTitle>
            <DialogDescription>
              {confirm?.profile.name} · {confirm?.profile.email}
            </DialogDescription>
          </DialogHeader>
          <div className="app-dialog-scroll">
            <p>
              {confirm?.action === 'erase'
                ? 'Profil- und Kontodaten werden entfernt. Gesetzlich aufzubewahrende Fahrt- und Zahlungsbelege bleiben erhalten. Diese Aktion kann nicht rückgängig gemacht werden.'
                : confirm?.action === 'restore'
                  ? 'Das Konto kann sich anschließend erneut anmelden. Eine Fahrerfreigabe muss gesondert geprüft werden.'
                  : 'Alle Anmeldungen werden beendet. Ein Fahrer darf erst nach beendeter und abgerechneter Schicht gesperrt werden.'}
            </p>
            {error && (
              <p className="portal-error" role="alert">
                {error}
              </p>
            )}
          </div>
          <div className="app-dialog-actions">
            <button
              className="portal-secondary"
              type="button"
              disabled={busy}
              onClick={() => setConfirm(null)}
            >
              Abbrechen
            </button>
            <button
              className={
                confirm?.action === 'erase' ? 'portal-danger' : 'portal-primary'
              }
              type="button"
              disabled={busy}
              onClick={() => void manage()}
            >
              {busy ? 'Wird gespeichert …' : 'Bestätigen'}
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </main>
  );
}
