'use client';
import { useState, useSyncExternalStore, type SyntheticEvent } from 'react';
import { ArrowRight, Copy, Mail } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  berlinMinute,
  inquiryClasses,
  prepareInquiry,
  type InquiryClass,
} from '@/lib/inquiry';

function subscribeDate(onChange: () => void) {
  const timer = setInterval(onChange, 60_000);
  return () => clearInterval(timer);
}
const dateSnapshot = () => berlinMinute(new Date()).slice(0, 10);
const serverDateSnapshot = () => '';

export default function InquiryForm({
  initialService,
}: {
  initialService: InquiryClass;
}) {
  const [service, setService] = useState<InquiryClass>(initialService);
  const minimumDate = useSyncExternalStore(
    subscribeDate,
    dateSnapshot,
    serverDateSnapshot,
  );
  const ready = minimumDate !== '';
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [draft, setDraft] = useState<ReturnType<typeof prepareInquiry> | null>(
    null,
  );
  function submit(event: SyntheticEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    setNotice('');
    const data = new FormData(event.currentTarget);
    const field = (key: string) => {
      const value = data.get(key);
      return typeof value === 'string' ? value : '';
    };
    try {
      setDraft(
        prepareInquiry({
          pickup: field('pickup'),
          destination: field('destination'),
          date: field('date'),
          time: field('time'),
          guests: Number(field('guests')),
          service,
          name: field('name'),
          phone: field('phone'),
          notes: field('notes'),
        }),
      );
    } catch (e) {
      setDraft(null);
      setError(e instanceof Error ? e.message : 'Bitte prüfe deine Angaben.');
    }
  }
  async function copy() {
    if (!draft) return;
    try {
      await navigator.clipboard.writeText(`${draft.subject}\n\n${draft.body}`);
      setNotice(
        'Anfragetext kopiert. Du kannst ihn jetzt in deine E-Mail einfügen.',
      );
    } catch {
      setNotice(
        'Kopieren ist hier nicht möglich. Markiere den Anfragetext unten und kopiere ihn manuell.',
      );
    }
  }
  function invalidate() {
    setDraft(null);
    setNotice('');
    setError('');
  }
  return (
    <div className="lux-inquiry-panel">
      <form onSubmit={submit} onChange={invalidate}>
        <div className="lux-form-grid">
          <div>
            <label htmlFor="pickup">Abholort *</label>
            <Input
              id="pickup"
              name="pickup"
              placeholder="Straße, Hausnummer und Ort"
              required
              maxLength={180}
            />
          </div>
          <div>
            <label htmlFor="destination">Ziel *</label>
            <Input
              id="destination"
              name="destination"
              placeholder="Adresse oder Flughafen / Terminal"
              required
              maxLength={180}
            />
          </div>
          <div>
            <label htmlFor="date">Datum *</label>
            <Input
              id="date"
              name="date"
              type="date"
              min={minimumDate}
              required
            />
          </div>
          <div>
            <label htmlFor="time">Uhrzeit in Frankfurt *</label>
            <Input id="time" name="time" type="time" required />
          </div>
          <div>
            <label htmlFor="inquiry-class">Fahrzeugklasse *</label>
            <Select
              value={service}
              onValueChange={(value) => {
                if (value && value in inquiryClasses) {
                  setService(value as InquiryClass);
                  invalidate();
                }
              }}
            >
              <SelectTrigger id="inquiry-class">
                <SelectValue>{inquiryClasses[service].label}</SelectValue>
              </SelectTrigger>
              <SelectContent>
                {Object.entries(inquiryClasses).map(([id, tier]) => (
                  <SelectItem key={id} value={id}>
                    {tier.label} · bis {tier.capacity} Gäste
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label htmlFor="guests">Anzahl Gäste *</label>
            <Input
              id="guests"
              name="guests"
              type="number"
              min={1}
              max={inquiryClasses[service].capacity}
              defaultValue={1}
              required
              aria-describedby="guests-help"
            />
            <p id="guests-help" className="lux-field-help">
              Maximal {inquiryClasses[service].capacity} Gäste in dieser Klasse.
            </p>
          </div>
          <div>
            <label htmlFor="name">Dein Name *</label>
            <Input
              id="name"
              name="name"
              autoComplete="name"
              required
              maxLength={180}
            />
          </div>
          <div>
            <label htmlFor="phone">Telefonnummer (optional)</label>
            <Input
              id="phone"
              name="phone"
              type="tel"
              autoComplete="tel"
              maxLength={180}
            />
          </div>
          <div className="lux-form-wide">
            <label htmlFor="notes">Wünsche oder Flugnummer (optional)</label>
            <Textarea
              id="notes"
              name="notes"
              maxLength={600}
              rows={3}
              placeholder="Zum Beispiel Gepäck, Flugnummer oder besondere Wünsche"
            />
          </div>
        </div>
        <p className="lux-inquiry-explanation">
          Hier bereitest du eine unverbindliche Anfrage vor. Deine Angaben
          werden beim Ausfüllen nicht an uns übertragen. Erst wenn du die E-Mail
          in deinem E-Mail-Programm absendest, erhalten wir deine Anfrage.
        </p>
        {error && (
          <p role="alert" className="lux-inquiry-error">
            {error}
          </p>
        )}
        <button className="lux-button" type="submit" disabled={!ready}>
          Anfrage vorbereiten <ArrowRight size={18} />
        </button>
        <noscript>
          Bitte aktiviere JavaScript oder schreibe direkt an
          booking@luxoreride.de.
        </noscript>
      </form>
      {draft && (
        <section
          className="lux-inquiry-draft"
          aria-label="Vorbereitete Anfrage"
        >
          <h2>Prüfen und per E-Mail senden</h2>
          <p>
            Es wurde noch nichts versendet. Öffne dein E-Mail-Programm oder
            kopiere den Text und sende ihn an{' '}
            <a href="mailto:booking@luxoreride.de">booking@luxoreride.de</a>.
          </p>
          <label htmlFor="draft-text">Deine Anfrage</label>
          <Textarea id="draft-text" readOnly value={draft.body} rows={14} />
          <div className="lux-actions">
            <a className="lux-button" href={draft.mailto}>
              <Mail size={18} /> E-Mail öffnen
            </a>
            <button className="lux-copy-button" type="button" onClick={copy}>
              <Copy size={17} /> Text kopieren
            </button>
          </div>
          <output aria-live="polite">{notice}</output>
        </section>
      )}
    </div>
  );
}
