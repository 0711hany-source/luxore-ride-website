import MobilityWorkspace from '@/app/mobility/workspace';
export const metadata = { title: 'Fahrt buchen | LUXORÉ RIDE' };
export default function Page() {
  return <MobilityWorkspace appMode="customer" />;
}
