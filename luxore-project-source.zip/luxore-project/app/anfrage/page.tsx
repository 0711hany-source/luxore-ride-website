import MobilityWorkspace from '@/app/mobility/workspace';
export const metadata = {
  title: 'Fahrt buchen | LUXORÉ RIDE',
  description:
    'Fahrt mit persönlichem Chauffeur online buchen: Abholort, Ziel und Fahrzeugklasse wählen, Preis vorab sehen.',
  alternates: { canonical: '/anfrage' },
};
export default function Page() {
  return <MobilityWorkspace appMode="customer" />;
}
