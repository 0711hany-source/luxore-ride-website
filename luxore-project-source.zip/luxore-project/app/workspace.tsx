'use client';
import { useEffect, useState, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
/* SIWC requires a top-level anchor navigation; a framework Link would prefetch its reserved route. */
/* eslint-disable next/no-html-link-for-pages */
import {
  ArrowRight,
  ArrowUpRight,
  CarFront,
  Check,
  ChevronRight,
  Crown,
  Phone,
  Mail,
  BriefcaseBusiness,
  Route,
  Clock3,
  Wifi,
  Luggage,
  MapPin,
  Plane,
  ShieldCheck,
  Users,
  RefreshCw,
} from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  classes,
  locations,
  labels,
  money,
  quote,
  className,
  type Ride,
  type RideClass,
  type Status,
} from '@/lib/ride-domain';
function Place({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (s: string) => void;
}) {
  return (
    <div className="place">
      <label htmlFor={label}>{label}</label>
      <Select value={value} onValueChange={(v) => v && onChange(v)}>
        <SelectTrigger id={label} aria-label={label}>
          <MapPin size={17} />
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {locations.map((l) => (
            <SelectItem key={l} value={l}>
              {l}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
export default function Workspace() {
  const [pickup, setPickup] = useState<string>(locations[0]),
    [destination, setDestination] = useState<string>(locations[2]),
    [service, setService] = useState<RideClass>('premium'),
    [scheduled, setScheduled] = useState('');
  const [rides, setRides] = useState<Ride[]>([]),
    [loading, setLoading] = useState(true),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [message, setMessage] = useState(''),
    [auth, setAuth] = useState(false),
    [view, setView] = useState('guest');
  const requestId = useRef('');
  const selectedClass = classes.find((c) => c.id === service)!;
  const total =
    pickup === destination ? null : quote(pickup, destination, service);
  async function refresh() {
    setLoading(true);
    try {
      const r = await fetch('/api/rides');
      if (r.status === 401) {
        setAuth(false);
        return;
      }
      if (!r.ok) throw new Error('Fahrten konnten nicht geladen werden.');
      setAuth(true);
      setRides(await r.json());
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    let mounted = true;
    fetch('/api/rides')
      .then(async (r) => {
        if (!mounted) return;
        if (r.status === 401) {
          setAuth(false);
          return;
        }
        if (!r.ok) throw new Error('Fahrten konnten nicht geladen werden.');
        const data = (await r.json()) as Ride[];
        if (mounted) {
          setAuth(true);
          setRides(data);
        }
      })
      .catch((e) => {
        if (mounted) setError(e.message);
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, []);
  async function book() {
    if (busy) return;
    if (!requestId.current) requestId.current = crypto.randomUUID();
    setBusy(true);
    setError('');
    setMessage('');
    try {
      const r = await fetch('/api/rides', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pickup,
          destination,
          service,
          scheduledAt: scheduled ? new Date(scheduled).toISOString() : null,
          id: requestId.current,
        }),
      });
      const data = (await r.json()) as { error?: string };
      if (!r.ok) throw new Error(data.error || 'Buchung fehlgeschlagen.');
      requestId.current = '';
      setMessage(
        'Testfahrt gespeichert. Du kannst sie jetzt in der Fahreransicht annehmen.',
      );
      await refresh();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function update(ride: Ride, status: Status) {
    setBusy(true);
    setError('');
    setMessage('');
    try {
      const r = await fetch('/api/rides', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: ride.id, from: ride.status, status }),
      });
      const d = (await r.json()) as { error?: string };
      if (!r.ok) throw new Error(d.error || 'Änderung fehlgeschlagen.');
      await refresh();
      setMessage('Fahrtstatus aktualisiert.');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const active = rides.filter(
    (r) => !['completed', 'cancelled'].includes(r.status),
  );
  return (
    <div className="app-shell">
      <header className="masthead">
        <Link href="/" className="wordmark">
          LUXORÉ<span>R I D E</span>
        </Link>
        <div className="city">
          <span className="dot" />
          Frankfurt am Main
        </div>
        <a className="company" href="tel:+491605083829">
          <Phone size={16} /> +49 160 5083829 <ArrowUpRight size={15} />
        </a>
      </header>
      <div className="development">
        <span>PRIVATE PREVIEW</span>
        <p>Testumgebung · keine echten Buchungen oder Zahlungen</p>
      </div>
      <Tabs
        value={view}
        onValueChange={(v) => setView(String(v))}
        className="workspace"
      >
        <div className="workspace-nav">
          <TabsList variant="line">
            <TabsTrigger value="guest">Fahrt buchen</TabsTrigger>
            <TabsTrigger value="driver">Fahreransicht</TabsTrigger>
            <TabsTrigger value="dispatch">Disposition</TabsTrigger>
            <TabsTrigger value="services">Service & Preise</TabsTrigger>
          </TabsList>
          <span className="edition">
            CHAUFFEUR SERVICE <span>FRANKFURT</span>
          </span>
        </div>
        {error && (
          <div className="notice error" role="alert">
            {error}
          </div>
        )}
        {message && <output className="notice">{message}</output>}
        <TabsContent value="guest">
          <div className="page-intro">
            <div>
              <div className="eyebrow">LUXORÉ RIDE · FRANKFURT AM MAIN</div>
              <h1>
                Deine Zeit. <span>Deine Fahrt.</span>
              </h1>
            </div>
            <p>
              Einsteigen. Zurücklehnen.
              <br />
              Den Rest übernehmen wir.
            </p>
          </div>
          <div className="booking-layout">
            <section className="booking">
              <div className="booking-title">
                <h2>Wohin darf es gehen?</h2>
                <span className="step-badge">01 — 03</span>
              </div>
              <p className="intro">Plane deine Fahrt in wenigen Schritten.</p>
              <div className="route-inputs">
                <Place label="ABHOLORT" value={pickup} onChange={setPickup} />
                <Place
                  label="ZIELORT"
                  value={destination}
                  onChange={setDestination}
                />
              </div>
              <label className="schedule" htmlFor="pickup-time">
                Abholzeit{' '}
                <span>Leer lassen für sofort · Ortszeit deines Geräts</span>
                <Input
                  id="pickup-time"
                  aria-label="Abholzeit"
                  type="datetime-local"
                  value={scheduled}
                  onChange={(e) => setScheduled(e.target.value)}
                />
              </label>
              <div className="tier-heading">
                Fahrzeugklasse <span>Transfer-Richtwerte</span>
              </div>
              <div className="tiers">
                {classes.map((c) => (
                  <button
                    key={c.id}
                    className={'tier ' + (service === c.id ? 'selected' : '')}
                    aria-pressed={service === c.id}
                    onClick={() => setService(c.id)}
                  >
                    <div className="tier-image">
                      <Image
                        unoptimized
                        src={c.image}
                        alt=""
                        width="1024"
                        height="1024"
                      />
                    </div>
                    <div>
                      <strong>{c.name}</strong>
                      <span>{c.detail}</span>
                      <small>{c.capacity}</small>
                    </div>
                    <div className="tier-price">
                      {pickup !== destination
                        ? money(quote(pickup, destination, c.id))
                        : '—'}
                      <span className="choice">
                        {service === c.id && <Check size={13} />}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
              {pickup === destination && (
                <p role="alert" className="field-error">
                  Start und Ziel müssen unterschiedlich sein.
                </p>
              )}
              <div className="booking-footer">
                <div>
                  <span>Unverbindlicher Testpreis</span>
                  <strong>{total === null ? '—' : money(total)}</strong>
                </div>
                {auth ? (
                  <Button
                    className="primary-action"
                    disabled={busy || total === null}
                    onClick={book}
                  >
                    {busy ? 'Wird gespeichert …' : 'Testfahrt anfragen'}
                    <ArrowRight />
                  </Button>
                ) : (
                  <a
                    className="primary-action"
                    href="/signin-with-chatgpt?return_to=%2F"
                    target="_top"
                  >
                    Zum Test anmelden <ArrowUpRight size={18} />
                  </a>
                )}
              </div>
              <p className="fineprint">
                Richtwert laut Website, kein berechneter Streckenpreis. Deine
                Testanfrage löst keine Buchung oder Zahlung aus.
              </p>
            </section>
            <aside className="journey-panel">
              <div className="vehicle-stage">
                <div className="journey-top">
                  <span>THE LUXORÉ COLLECTION</span>
                  <Crown size={21} />
                </div>
                <div className="vehicle-heading">
                  <h2>{selectedClass.name}</h2>
                  <p>{selectedClass.note}</p>
                </div>
                <div className="vehicle-visual">
                  <span aria-hidden="true" className="vehicle-number">
                    {service === 'premium'
                      ? '01'
                      : service === 'first'
                        ? '02'
                        : '03'}
                  </span>
                  <Image
                    unoptimized
                    key={selectedClass.image}
                    src={selectedClass.image}
                    alt={selectedClass.detail}
                    width="1024"
                    height="1024"
                  />
                </div>
                <div className="vehicle-model">
                  <strong>{selectedClass.detail}</strong>
                  <span>oder vergleichbar</span>
                </div>
                <div className="vehicle-specs">
                  <span>
                    <Users size={16} />
                    {selectedClass.capacity.split(' · ')[0]}
                  </span>
                  <span>
                    <Luggage size={16} />
                    {selectedClass.capacity.split(' · ')[1]}
                  </span>
                  <span>
                    <Wifi size={16} /> WLAN
                  </span>
                </div>
              </div>
              <div className="journey-summary">
                <div className="summary-heading">
                  <span>DEINE ROUTE</span>
                  <span>Frankfurt am Main</span>
                </div>
                <div className="journey-route">
                  <div className="journey-stop">
                    <span className="stop-icon">
                      <MapPin size={17} />
                    </span>
                    <div>
                      <small>ABHOLORT</small>
                      <strong>{pickup}</strong>
                    </div>
                  </div>
                  <div className="journey-line" />
                  <div className="journey-stop">
                    <span className="stop-icon end">
                      <ArrowUpRight size={17} />
                    </span>
                    <div>
                      <small>ZIELORT</small>
                      <strong>{destination}</strong>
                    </div>
                  </div>
                </div>
                <div className="route-note">
                  <ShieldCheck size={16} /> Persönlicher Chauffeurservice
                </div>
              </div>
              <div className="concierge-card">
                <div>
                  <span>WIR SIND FÜR DICH DA</span>
                  <strong>Dein persönlicher Kontakt.</strong>
                </div>
                <a href="tel:+491605083829" aria-label="LUXORÉ RIDE anrufen">
                  <Phone size={20} />
                </a>
              </div>
            </aside>
          </div>
          <section className="history">
            <div className="section-title">
              <div>
                <div className="eyebrow">DEIN TESTKONTO</div>
                <h2>Deine Fahrten</h2>
              </div>
              <Button variant="outline" disabled={loading} onClick={refresh}>
                <RefreshCw /> Aktualisieren
              </Button>
            </div>
            {loading ? (
              <p>Fahrten werden geladen …</p>
            ) : !rides.length ? (
              <div className="empty">
                <CarFront />
                <p>Noch keine Testfahrten.</p>
                <span>Deine erste Anfrage erscheint hier.</span>
              </div>
            ) : (
              <RideTable
                rides={rides}
                busy={busy}
                onUpdate={update}
                mode="guest"
              />
            )}
          </section>
        </TabsContent>
        <TabsContent value="driver">
          <div className="section-title large">
            <div>
              <div className="eyebrow">LUXORÉ DRIVER · TESTANSICHT</div>
              <h1>Dein nächster Auftrag.</h1>
              <p>Teste hier den Fahrtablauf deiner eigenen Buchungen.</p>
            </div>
            <Button variant="outline" onClick={refresh} disabled={loading}>
              <RefreshCw />
              Aktualisieren
            </Button>
          </div>
          <div className="metrics">
            <Metric
              label="Offene Anfragen"
              value={rides.filter((r) => r.status === 'requested').length}
            />
            <Metric label="Aktive Testfahrten" value={active.length} />
            <Metric
              label="Abgeschlossen"
              value={rides.filter((r) => r.status === 'completed').length}
            />
          </div>
          {!active.length ? (
            <div className="empty">
              <CarFront />
              <p>Keine offenen Aufträge.</p>
              <Button onClick={() => setView('guest')}>
                Testfahrt erstellen <ArrowRight />
              </Button>
            </div>
          ) : (
            <div className="driver-grid">
              {active.map((r) => (
                <article className="driver-card" key={r.id}>
                  <div className="card-head">
                    <span className="status">{labels[r.status]}</span>
                    <strong>{money(r.price)}</strong>
                  </div>
                  <h2>{className(r.service)}</h2>
                  <p>
                    <MapPin size={16} />
                    {r.pickup}
                  </p>
                  <p>
                    <ArrowRight size={16} />
                    {r.destination}
                  </p>
                  <div className="card-bottom">
                    <small>
                      {r.scheduled_at
                        ? new Date(r.scheduled_at).toLocaleString('de-DE')
                        : 'Sofortfahrt'}
                    </small>
                    <NextAction ride={r} busy={busy} onUpdate={update} />
                  </div>
                </article>
              ))}
            </div>
          )}
        </TabsContent>
        <TabsContent value="dispatch">
          <div className="section-title large">
            <div>
              <div className="eyebrow">LUXORÉ OPERATIONS</div>
              <h1>Alles im Blick.</h1>
              <p>
                Eigene Flotte in Frankfurt. Partnerbetriebe sind für einen
                späteren Ausbau vorgesehen.
              </p>
            </div>
            <Button variant="outline" onClick={refresh} disabled={loading}>
              <RefreshCw />
              Aktualisieren
            </Button>
          </div>
          <div className="metrics">
            <Metric label="Testfahrten gesamt" value={rides.length} />
            <Metric label="Aktive Fahrten" value={active.length} />
            <Metric
              label="First Class"
              value={rides.filter((r) => r.service === 'first').length}
            />
          </div>
          <div className="operations-note">
            <Users />
            <div>
              <strong>Dein Unternehmen zuerst.</strong>
              <p>
                Diese Disposition zeigt nur Fahrten deines Testkontos. Separate
                Fahrerzugänge, Partnerfreigaben und Abrechnung sind noch nicht
                angebunden.
              </p>
            </div>
          </div>
          <RideTable
            rides={rides}
            busy={busy}
            onUpdate={update}
            mode="dispatch"
          />
        </TabsContent>
        <TabsContent value="services">
          <div className="page-intro">
            <div>
              <div className="eyebrow">MEHR ALS EINE FAHRT</div>
              <h1>
                Auf deinen <span>Anspruch abgestimmt.</span>
              </h1>
            </div>
            <a
              className="contact-link"
              href="https://luxoreride.de"
              target="_blank"
              rel="noreferrer"
            >
              Unsere Website <ArrowUpRight size={18} />
            </a>
          </div>
          <div className="service-banner">
            <Image
              unoptimized
              src="/brand/frankfurt.png"
              alt="Frankfurter Skyline aus dem Fenster einer Limousine"
              width="1024"
              height="1024"
            />
            <div>
              <span className="eyebrow">FRANKFURT. UND DARÜBER HINAUS.</span>
              <h2>Eleganz in Bewegung.</h2>
              <p>
                Für deinen nächsten Flug, deinen Geschäftstermin oder einen
                besonderen Tag.
              </p>
            </div>
          </div>
          <div className="service-grid">
            {[
              {
                icon: Plane,
                title: 'Flughafentransfer',
                text: 'Persönliche Abholung und Gepäckservice für deinen Transfer rund um Frankfurt Airport.',
              },
              {
                icon: BriefcaseBusiness,
                title: 'Business & Corporate',
                text: 'Diskrete Fahrten für Geschäftstermine, Hotels, Unternehmen und ihre Gäste.',
              },
              {
                icon: Route,
                title: 'Langstrecken',
                text: 'Privat und komfortabel unterwegs – auch über Frankfurt hinaus und europaweit.',
              },
              {
                icon: Clock3,
                title: 'Daytrips',
                text: 'Dein Chauffeur für Shopping, Ausflüge und individuell geplante Tagesfahrten.',
              },
            ].map((x) => (
              <article key={x.title}>
                <x.icon size={23} />
                <h3>{x.title}</h3>
                <p>{x.text}</p>
              </article>
            ))}
          </div>
          <div className="women-service">
            <ShieldCheck size={28} />
            <div>
              <span className="eyebrow">PERSÖNLICHES VERTRAUEN</span>
              <h2>Women to Women</h2>
              <p>
                Eine Chauffeurin für deine Fahrt. Auf Anfrage und nach
                bestätigter Verfügbarkeit.
              </p>
            </div>
            <a href="mailto:booking@luxoreride.de?subject=Women%20to%20Women%20Anfrage">
              Per E-Mail anfragen <ArrowUpRight size={18} />
            </a>
          </div>
          <section className="pricing-section">
            <div className="section-title">
              <div>
                <div className="eyebrow">TRANSPARENT UNTERWEGS</div>
                <h2>Unsere Tarifübersicht</h2>
              </div>
              <a
                href="https://luxoreride.de/#preise"
                target="_blank"
                rel="noreferrer"
              >
                Quelle: luxoreride.de <ArrowUpRight size={16} />
              </a>
            </div>
            <div className="price-grid">
              {classes.map((c) => (
                <article key={c.id}>
                  <h3>{c.name}</h3>
                  <p>{c.detail}</p>
                  <div>
                    <strong>{money(c.transfer)}</strong>
                    <span>Transferangabe</span>
                  </div>
                  <footer>{money(c.perKm)} / km</footer>
                </article>
              ))}
            </div>
            <p className="fineprint">
              Veröffentlichte Website-Angaben. Die Anwendbarkeit der
              Transferpauschale auf deine Strecke muss bestätigt werden. Der
              Kilometerrechner der Website nennt 15 € Mindestpreis. Transfer-
              und Kilometerpreis werden hier nicht addiert.
            </p>
          </section>
          <div className="terms-grid">
            <article>
              <Clock3 />
              <h3>Wartezeit inklusive</h3>
              <p>
                60 Minuten nach Landung bei Linienflügen. 15 Minuten bei anderen
                Abholorten. Danach laut Website 40 € je angefangene halbe
                Stunde.
              </p>
            </article>
            <article>
              <ShieldCheck />
              <h3>Flexibel planen</h3>
              <p>
                Laut Website bis 24 Stunden vor Fahrtantritt kostenfrei
                stornieren. Danach wird der vereinbarte Fahrpreis berechnet. Für
                Testfahrten fallen keine Kosten an.
              </p>
            </article>
            <article>
              <Mail />
              <h3>Direkt in Kontakt</h3>
              <p>
                <a href="mailto:booking@luxoreride.de">booking@luxoreride.de</a>
                <br />
                <a href="tel:+491605083829">+49 160 5083829</a>
                <br />
                Erreichbarkeit laut Website: 24/7
              </p>
            </article>
          </div>
        </TabsContent>
      </Tabs>
      <footer className="footer">
        <span>LUXORÉ RIDE</span>
        <span>Frankfurt am Main</span>
        <div className="footer-links">
          <a
            href="https://luxoreride.de/impressum.html"
            target="_blank"
            rel="noreferrer"
          >
            Impressum
          </a>
          <a
            href="https://luxoreride.de/datenschutz.html"
            target="_blank"
            rel="noreferrer"
          >
            Datenschutz
          </a>
          <span>Private Preview · Kein Fahrbetrieb</span>
        </div>
      </footer>
    </div>
  );
}
function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div className="metric">
      <span>{label}</span>
      <strong>{String(value).padStart(2, '0')}</strong>
    </div>
  );
}
function NextAction({
  ride,
  busy,
  onUpdate,
}: {
  ride: Ride;
  busy: boolean;
  onUpdate: (r: Ride, s: Status) => void;
}) {
  const next: Partial<Record<Status, [Status, string]>> = {
    requested: ['accepted', 'Annehmen'],
    accepted: ['arrived', 'Ankunft melden'],
    arrived: ['riding', 'Fahrt starten'],
    riding: ['completed', 'Abschließen'],
  };
  const n = next[ride.status];
  return n ? (
    <Button disabled={busy} onClick={() => onUpdate(ride, n[0])}>
      {n[1]}
      <ChevronRight />
    </Button>
  ) : null;
}
function RideTable({
  rides,
  busy,
  onUpdate,
  mode,
}: {
  rides: Ride[];
  busy: boolean;
  onUpdate: (r: Ride, s: Status) => void;
  mode: string;
}) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Strecke</TableHead>
          <TableHead>Klasse</TableHead>
          <TableHead>Abholung</TableHead>
          <TableHead>Testpreis</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Aktion</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {rides.map((r) => (
          <TableRow key={r.id}>
            <TableCell>
              <strong>{r.pickup}</strong>
              <div className="table-destination">→ {r.destination}</div>
            </TableCell>
            <TableCell>{className(r.service)}</TableCell>
            <TableCell>
              {r.scheduled_at
                ? new Date(r.scheduled_at).toLocaleString('de-DE')
                : 'Sofort'}
            </TableCell>
            <TableCell>{money(r.price)}</TableCell>
            <TableCell>
              <span className={'status ' + r.status}>{labels[r.status]}</span>
            </TableCell>
            <TableCell>
              <div className="table-actions">
                {mode === 'dispatch' && (
                  <NextAction ride={r} busy={busy} onUpdate={onUpdate} />
                )}
                {['requested', 'accepted', 'arrived'].includes(r.status) && (
                  <Button
                    variant="ghost"
                    disabled={busy}
                    onClick={() => onUpdate(r, 'cancelled')}
                  >
                    Stornieren
                  </Button>
                )}
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
