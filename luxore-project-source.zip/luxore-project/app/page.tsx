import Image from 'next/image';
import Link from 'next/link';
import {
  ArrowUpRight,
  ArrowRight,
  Plane,
  BriefcaseBusiness,
  Route,
  Phone,
  Mail,
  MapPin,
  Smartphone,
  Apple,
  Play,
  UserRound,
} from 'lucide-react';
import { classes, money } from '@/lib/ride-domain';
import { databaseConfigured } from '@/db/sqlite';

const faqs = [
  {
    q: 'Wie wird der Fahrpreis berechnet?',
    a: 'Der Preis richtet sich nach der berechneten Straßenroute und dem Kilometerpreis deiner Fahrzeugklasse. Der Mindestpreis beträgt 15 € pro Fahrt, eine zusätzliche Transferpauschale gibt es nicht.',
  },
  {
    q: 'Ist eine Anfrage schon eine feste Buchung?',
    a: 'Nein. Wir prüfen die Verfügbarkeit und bestätigen deine Fahrt persönlich. Erst mit unserer Bestätigung ist die Fahrt gebucht.',
  },
  {
    q: 'Bietet ihr Flughafentransfers ab Frankfurt Airport an?',
    a: 'Ja. Wir fahren dich von deiner Wunschadresse zum Frankfurt Airport und nach der Landung entspannt weiter, auch im gesamten Rhein-Main-Gebiet.',
  },
  {
    q: 'Welche Fahrzeugklassen gibt es?',
    a: 'Business Class (Mercedes E-Klasse oder Audi A6), Electric Class (Mercedes EQE 300), First Class Van (Mercedes V-Klasse) für bis zu 6 Gäste und 6 Koffer sowie First Class (Mercedes S-Klasse) nur auf Anfrage.',
  },
  {
    q: 'Was kosten die Fahrzeugklassen pro Kilometer?',
    a: classes
      .map(
        (c) =>
          `${c.name} ${money(c.perKm)} pro Kilometer${c.onRequest ? ' (nur auf Anfrage)' : ''}`,
      )
      .join(', ')
      .concat('. Der Mindestpreis beträgt 15 € pro Fahrt.'),
  },
];

const jsonLd = {
  '@context': 'https://schema.org',
  '@graph': [
    {
      '@type': 'LocalBusiness',
      '@id': 'https://luxoreride.de/#business',
      name: 'LUXORÉ RIDE',
      description: 'Chauffeurservice und Flughafentransfer in Frankfurt am Main und Rhein-Main.',
      url: 'https://luxoreride.de/',
      telephone: '+49 160 5083829',
      email: 'booking@luxoreride.de',
      image: 'https://luxoreride.de/brand/frankfurt.png',
      address: {
        '@type': 'PostalAddress',
        streetAddress: 'Gerhart-Hauptmann-Ring 224',
        postalCode: '60439',
        addressLocality: 'Frankfurt am Main',
        addressCountry: 'DE',
      },
      areaServed: ['Frankfurt am Main', 'Rhein-Main'],
      knowsAbout: ['Flughafentransfer', 'Chauffeurservice', 'Business-Fahrten'],
      // Per-kilometre prices as published in the class list below.
      makesOffer: classes.map((c) => ({
        '@type': 'Offer',
        name: c.name,
        description: `${c.detail} · ${c.capacity}${c.onRequest ? ' · nur auf Anfrage' : ''}`,
        priceSpecification: {
          '@type': 'UnitPriceSpecification',
          price: (c.perKm / 100).toFixed(2),
          priceCurrency: 'EUR',
          unitCode: 'KMT',
        },
      })),
    },
    {
      '@type': 'FAQPage',
      mainEntity: faqs.map((f) => ({
        '@type': 'Question',
        name: f.q,
        acceptedAnswer: { '@type': 'Answer', text: f.a },
      })),
    },
  ],
};

export default function Home() {
  const bookingReady = databaseConfigured();
  const bookingHref = bookingReady ? '/mobile/customer' : '#kontakt';
  return (
    <main className="lux-site">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <a className="lux-skip" href="#inhalt">
        Zum Inhalt
      </a>
      <header className="lux-header">
        <Link href="/" className="lux-logo" aria-label="LUXORÉ RIDE Startseite">
          LUXORÉ <span>RIDE</span>
        </Link>
        <nav aria-label="Hauptnavigation">
          <a href="#leistungen">Leistungen</a>
          <a href="#fahrzeuge">Fahrzeuge & Preise</a>
          <a href="#app">Die App</a>
          <a href="#faq">FAQ</a>
          <Link href="/konto" className="lux-account-link">
            <UserRound size={16} /> Mein Konto
          </Link>
        </nav>
        <Link href={bookingHref} className="lux-button lux-button-small">
          {bookingReady ? 'Fahrt buchen' : 'Fahrt anfragen'} <ArrowUpRight size={17} />
        </Link>
      </header>
      <section className="lux-hero" id="inhalt">
        <div className="lux-hero-copy">
          <p className="lux-kicker">CHAUFFEURSERVICE & FLUGHAFENTRANSFER · FRANKFURT</p>
          <h1>
            Deine Zeit.
            <br />
            Dein Anspruch.
            <br />
            <em>Deine Fahrt.</em>
          </h1>
          <p className="lux-lead">
            Dein Chauffeurservice in Frankfurt und Rhein-Main: Flughafentransfer,
            Business-Fahrten und Events. LUXORÉ RIDE bringt dich mit
            persönlichem Chauffeur an dein Ziel.
          </p>
          <div className="lux-actions">
            <Link href={bookingHref} className="lux-button">
              {bookingReady ? 'Online Fahrt buchen' : 'Fahrt anfragen'} <ArrowUpRight size={18} />
            </Link>
            <a href="#fahrzeuge" className="lux-text-link">
              Unsere Fahrzeugklassen <ArrowRight size={18} />
            </a>
          </div>
          <p className="lux-cta-note">Eine Anfrage ist erst mit unserer Bestätigung eine feste Buchung.</p>
          <div className="lux-hero-note">
            <MapPin size={16} /> Frankfurt · Rhein-Main · Fahrten darüber hinaus
          </div>
          {!bookingReady && <p className="lux-footnote">Die Online-Buchung wird gerade eingerichtet. Für aktuelle Fahrtanfragen erreichst du uns persönlich.</p>}
        </div>
        <div className="lux-hero-image">
          <Image
            src="/brand/frankfurt.png"
            alt="Illustration: Blick aus einer Limousine auf die Frankfurter Skyline"
            width={1024}
            height={1024}
            unoptimized
            priority
          />
          <div className="lux-image-caption">
            <span>UNTERWEGS MIT LUXORÉ</span>
            <p>
              Einsteigen.
              <br />
              Den Rest übernehmen wir.
            </p>
          </div>
        </div>
      </section>
      <div className="lux-strip">
        <span>Business Class</span>
        <i />
        <span>Electric Class</span>
        <i />
        <span>First Class Van</span>
        <i />
        <span>First Class</span>
      </div>
      <section id="leistungen" className="lux-section">
        <div className="lux-section-heading">
          <div>
            <p className="lux-kicker">FÜR DAS, WAS DU VORHAST</p>
            <h2>
              Jeder Anlass.
              <br />
              Ein persönlicher Service.
            </h2>
          </div>
          <p>
            Allein unterwegs, mit Geschäftspartnern oder gemeinsam mit der
            Familie. Wähle die Fahrt, die zu deinem Tag passt.
          </p>
        </div>
        <div className="lux-services">
          {[
            {
              Icon: Plane,
              n: '01',
              title: 'Flughafentransfer',
              text: 'Von deiner Wunschadresse zum Frankfurt Airport – und nach der Landung entspannt weiter.',
            },
            {
              Icon: BriefcaseBusiness,
              n: '02',
              title: 'Business & Events',
              text: 'Zum Meeting, zur Messe oder zum Hotel. Persönlicher Chauffeurservice für dich und deine Gäste.',
            },
            {
              Icon: Route,
              n: '03',
              title: 'Private Fahrten',
              text: 'Ein besonderer Abend, eine längere Strecke oder ein Tagesausflug. Wir besprechen deine Wünsche persönlich.',
            },
          ].map(({ Icon, n, title, text }) => (
            <article key={n}>
              <div>
                <Icon size={26} strokeWidth={1.3} />
                <span>{n}</span>
              </div>
              <h3>{title}</h3>
              <p>{text}</p>
              <a href={bookingHref}>
                {bookingReady ? 'Fahrt buchen' : 'Fahrt anfragen'} <ArrowUpRight size={16} />
              </a>
            </article>
          ))}
        </div>
      </section>
      <section id="fahrzeuge" className="lux-fleet lux-section">
        <div className="lux-section-heading">
          <div>
            <p className="lux-kicker">VIER KLASSEN. DEIN KOMFORT.</p>
            <h2>Stil hat viele Wege.</h2>
          </div>
          <p>
            Unsere Kilometerpreise für deine Route. Mindestens 15 € pro Fahrt,
            ohne zusätzliche Transferpauschale.
          </p>
        </div>
        <div className="lux-cars">
          {classes.map((c) => (
            <article key={c.id}>
              <div className="lux-car-title">
                <h3>{c.name}</h3>
                {c.onRequest && <span>NUR AUF ANFRAGE</span>}
              </div>
              <p>{c.detail}</p>
              <Image
                src={c.image}
                alt={`${c.name}: ${c.detail}, beispielhafte Fahrzeugdarstellung`}
                width={700}
                height={420}
                unoptimized
              />
              <div className="lux-car-capacity">{c.capacity}</div>
              <div className="lux-car-price">
                <span>
                  <strong>{money(c.perKm)}</strong> / km
                </span>
                <Link
                  href={bookingHref}
                  aria-label={`${c.name} ${bookingReady ? 'online buchen' : 'anfragen'}`}
                >
                  <ArrowUpRight size={23} />
                </Link>
              </div>
            </article>
          ))}
        </div>
        <p className="lux-footnote">
          Der Streckenpreis richtet sich nach der berechneten Straßenroute – den genauen Preis siehst du vor deiner Anfrage in der Web-App. Die Van-Klasse bietet Platz für bis zu 6 Gäste und 6 Koffer. Die First Class ist nur auf Anfrage erhältlich.
          Zusätzliche Leistungen und mögliche Wartezeiten klären wir bei deiner
          Anfrage. Die Fahrzeugbilder zeigen Beispiele der jeweiligen Klasse.
        </p>
      </section>
      <section id="app" className="lux-app lux-section">
        <div className="lux-section-heading">
          <div>
            <p className="lux-kicker">LUXORÉ RIDE FÜR DEIN SMARTPHONE</p>
            <h2>
              Deine nächste Fahrt.
              <br />
              {bookingReady ? 'Direkt online planen.' : 'Bald auch in der App.'}
            </h2>
          </div>
          <p>
            Dein Chauffeurservice für unterwegs. In der App kannst du künftig
            deine Route planen, deinen Komfort wählen und eine Fahrt anfragen. Die Apps für Android
            und iPhone folgen nach Fertigstellung und Store-Freigabe.
          </p>
        </div>
        <ol className="lux-steps">
          <li>
            <span>01</span>
            <h3>Ziel wählen</h3>
            <p>Abholort und Ziel eingeben. Strecke und Preis siehst du, bevor du anfragst.</p>
          </li>
          <li>
            <span>02</span>
            <h3>Klasse bestimmen</h3>
            <p>Business, Electric oder Van – die First Class gibt es auf Anfrage.</p>
          </li>
          <li>
            <span>03</span>
            <h3>Chauffeur anfragen</h3>
            <p>Wir prüfen die Verfügbarkeit. Erst mit unserer Bestätigung ist die Fahrt gebucht.</p>
          </li>
        </ol>
        <div className="lux-platforms">
          <article>
            <div className="lux-platform-head">
              <Play size={24} />
              <h3>Android</h3>
            </div>
            <span className="lux-status">Bald verfügbar</span>
            <p>
              LUXORÉ Ride für Fahrgäste und LUXORÉ Driver für Chauffeure. Die
              Veröffentlichung bei Google Play wird vorbereitet.
            </p>
            <div className="lux-store-coming">
              <Play size={22} />
              <span>
                <small>BALD BEI</small>Google Play
              </span>
            </div>
          </article>
          <article>
            <div className="lux-platform-head">
              <Apple size={24} />
              <h3>iPhone</h3>
            </div>
            <span className="lux-status">Bald verfügbar</span>
            <p>
              Dein LUXORÉ RIDE auf dem iPhone. Die iOS-Version folgt im Anschluss an
              Android. Aktuell gibt es noch keinen App-Store-Download.
            </p>
            <div className="lux-store-coming">
              <Apple size={24} />
              <span>
                <small>BALD IM</small>App Store
              </span>
            </div>
          </article>
          <article>
            <div className="lux-platform-head">
              <Smartphone size={24} />
              <h3>Web-App</h3>
            </div>
            <span className="lux-status">{bookingReady ? 'Direkt im Browser' : 'Online-Buchung in Vorbereitung'}</span>
            <p>
              {bookingReady ? 'Strecke und Preis berechnen, eine Klasse wählen und eine Fahrt anfragen. Die Verfügbarkeit wird bei deiner Anfrage geprüft.' : 'Die Online-Buchung wird gerade eingerichtet. Unser Team unterstützt dich persönlich bei deiner Fahrtanfrage.'}
            </p>
            <Link href={bookingHref}>
              {bookingReady ? 'Fahrt buchen' : 'Fahrt anfragen'} <ArrowRight size={16} />
            </Link>
          </article>
        </div>
      </section>
      <section id="faq" className="lux-faq lux-section">
        <div className="lux-section-heading">
          <div>
            <p className="lux-kicker">HÄUFIGE FRAGEN</p>
            <h2>Gut zu wissen.</h2>
          </div>
        </div>
        <div className="lux-faq-list">
          {faqs.map((f) => (
            <details key={f.q}>
              <summary>{f.q}</summary>
              <p>{f.a}</p>
            </details>
          ))}
        </div>
      </section>
      <section id="kontakt" className="lux-contact lux-section">
        <div>
          <p className="lux-kicker">WIR FREUEN UNS AUF DEINE PLÄNE</p>
          <h2>
            Wohin darf
            <br />
            <em>es gehen?</em>
          </h2>
          <p>
            {bookingReady ? 'Buche deine Fahrt online oder besprich besondere Wünsche direkt mit unserem Team.' : 'Frage deine Fahrt direkt bei unserem Team an. Wir besprechen deine Wünsche und bestätigen die Verfügbarkeit persönlich.'} Für Firmen, Hotels und individuelle Fahrten stimmen
            wir die Details persönlich mit dir ab.
          </p>
        </div>
        <div className="lux-contact-links">
          <a href="tel:+491605083829">
            <Phone size={21} />
            <span>
              <small>Ruf uns an</small>+49 160 5083829
            </span>
            <ArrowUpRight />
          </a>
          <a href="mailto:booking@luxoreride.de?subject=Fahrtanfrage">
            <Mail size={21} />
            <span>
              <small>Schreib uns</small>booking@luxoreride.de
            </span>
            <ArrowUpRight />
          </a>
          <p>Eine Anfrage ist noch keine bestätigte Buchung.</p>
        </div>
      </section>
      <footer className="lux-footer">
        <div>
          <Link href="/" className="lux-logo">
            LUXORÉ <span>RIDE</span>
          </Link>
          <p>Chauffeurservice aus Frankfurt am Main.</p>
        </div>
        <nav aria-label="Weitere Informationen">
          <Link href="/impressum">Impressum</Link>
          <Link href="/datenschutz">Datenschutz</Link>
          <Link href="/hilfe">Hilfe</Link>
          <Link href="/mobile/customer">Web-App</Link>
          <a href="#kontakt">Kontakt</a>
        </nav>
        <p className="lux-footer-note">
          LUXORÉ RIDE · Frankfurt am Main · App Store & Google Play: bald
          verfügbar.
        </p>
      </footer>
    </main>
  );
}
