import Image from 'next/image';
import Link from 'next/link';
import {
  ArrowUpRight,
  ArrowRight,
  Plane,
  BriefcaseBusiness,
  Route,
  Phone,
  Mail,
  MapPin,
  Smartphone,
  Apple,
  Play,
  UserRound,
} from 'lucide-react';
import { classes, money } from '@/lib/ride-domain';
import { databaseConfigured } from '@/db/sqlite';

export default function Home() {
  const bookingReady = databaseConfigured();
  return (
    <main className="lux-site">
      <a className="lux-skip" href="#inhalt">
        Zum Inhalt
      </a>
      <header className="lux-header">
        <Link href="/" className="lux-logo" aria-label="LUXORÉ RIDE Startseite">
          LUXORÉ <span>RIDE</span>
        </Link>
        <nav aria-label="Hauptnavigation">
          <a href="#leistungen">Leistungen</a>
          <a href="#fahrzeuge">Fahrzeuge & Preise</a>
          <a href="#app">Die App</a>
          <Link href="/konto" className="lux-account-link">
            <UserRound size={16} /> Mein Konto
          </Link>
        </nav>
        <Link href="/mobile/customer" className="lux-button lux-button-small">
          {bookingReady ? 'Fahrt buchen' : 'Fahrt anfragen'} <ArrowUpRight size={17} />
        </Link>
      </header>
      <section className="lux-hero" id="inhalt">
        <div className="lux-hero-copy">
          <p className="lux-kicker">CHAUFFEURSERVICE · FRANKFURT AM MAIN</p>
          <h1>
            Deine Zeit.
            <br />
            Dein Anspruch.
            <br />
            <em>Deine Fahrt.</em>
          </h1>
          <p className="lux-lead">
            Vom ersten Geschäftstermin bis zum letzten Flug. LUXORÉ RIDE bringt
            dich mit persönlichem Chauffeur an dein Ziel.
          </p>
          <div className="lux-actions">
            <Link href="/mobile/customer" className="lux-button">
              {bookingReady ? 'Online Fahrt buchen' : 'Fahrt anfragen'} <ArrowUpRight size={18} />
            </Link>
            <a href="#fahrzeuge" className="lux-text-link">
              Unsere Fahrzeugklassen <ArrowRight size={18} />
            </a>
          </div>
          <div className="lux-hero-note">
            <MapPin size={16} /> Frankfurt · Rhein-Main · Fahrten darüber hinaus
          </div>
          {!bookingReady && <p className="lux-footnote">Die Online-Buchung wird gerade eingerichtet. Für aktuelle Fahrtanfragen erreichst du uns persönlich.</p>}
        </div>
        <div className="lux-hero-image">
          <Image
            src="/brand/frankfurt.png"
            alt="Illustration: Blick aus einer Limousine auf die Frankfurter Skyline"
            width={1024}
            height={1024}
            unoptimized
            priority
          />
          <div className="lux-image-caption">
            <span>UNTERWEGS MIT LUXORÉ</span>
            <p>
              Einsteigen.
              <br />
              Den Rest übernehmen wir.
            </p>
          </div>
        </div>
      </section>
      <div className="lux-strip">
        <span>Business Class</span>
        <i />
        <span>First Class</span>
        <i />
        <span>First Class Van</span>
      </div>
      <section id="leistungen" className="lux-section">
        <div className="lux-section-heading">
          <div>
            <p className="lux-kicker">FÜR DAS, WAS DU VORHAST</p>
            <h2>
              Jeder Anlass.
              <br />
              Ein persönlicher Service.
            </h2>
          </div>
          <p>
            Allein unterwegs, mit Geschäftspartnern oder gemeinsam mit der
            Familie. Wähle die Fahrt, die zu deinem Tag passt.
          </p>
        </div>
        <div className="lux-services">
          {[
            {
              Icon: Plane,
              n: '01',
              title: 'Flughafentransfer',
              text: 'Von deiner Wunschadresse zum Frankfurt Airport – und nach der Landung entspannt weiter.',
            },
            {
              Icon: BriefcaseBusiness,
              n: '02',
              title: 'Business & Events',
              text: 'Zum Meeting, zur Messe oder zum Hotel. Persönlicher Chauffeurservice für dich und deine Gäste.',
            },
            {
              Icon: Route,
              n: '03',
              title: 'Private Fahrten',
              text: 'Ein besonderer Abend, eine längere Strecke oder ein Tagesausflug. Wir besprechen deine Wünsche persönlich.',
            },
          ].map(({ Icon, n, title, text }) => (
            <article key={n}>
              <div>
                <Icon size={26} strokeWidth={1.3} />
                <span>{n}</span>
              </div>
              <h3>{title}</h3>
              <p>{text}</p>
              <a href="/mobile/customer">
                Fahrt buchen <ArrowUpRight size={16} />
              </a>
            </article>
          ))}
        </div>
      </section>
      <section className="lux-personal-service lux-section">
        <div>
          <p className="lux-kicker">WOMEN TO WOMEN</p>
          <h2>Mit einem guten Gefühl unterwegs.</h2>
        </div>
        <div>
          <p>
            Weibliche Fahrgäste können eine Chauffeurin anfragen. Wir besprechen
            deinen Wunsch persönlich und bestätigen die Möglichkeit nach
            Verfügbarkeit.
          </p>
          <a className="lux-button" href="tel:+491605083829">
            Wunsch persönlich besprechen
          </a>
        </div>
      </section>
      <section id="fahrzeuge" className="lux-fleet lux-section">
        <div className="lux-section-heading">
          <div>
            <p className="lux-kicker">DREI KLASSEN. DEIN KOMFORT.</p>
            <h2>Stil hat viele Wege.</h2>
          </div>
          <p>
            Unsere Kilometerpreise für deine Route. Mindestens 15 € pro Fahrt,
            ohne zusätzliche Transferpauschale.
          </p>
        </div>
        <div className="lux-cars">
          {classes.map((c) => (
            <article key={c.id}>
              <div className="lux-car-title">
                <h3>{c.name}</h3>
                {c.id === 'first' && <span>PREMIUM</span>}
              </div>
              <p>{c.detail}</p>
              <Image
                src={c.image}
                alt={`${c.name}: ${c.detail}, beispielhafte Fahrzeugdarstellung`}
                width={700}
                height={420}
                unoptimized
              />
              <div className="lux-car-capacity">{c.capacity}</div>
              <div className="lux-car-price">
                <span>
                  <strong>{money(c.perKm)}</strong> / km
                </span>
                <Link
                  href="/mobile/customer"
                  aria-label={`${c.name} online buchen`}
                >
                  <ArrowUpRight size={23} />
                </Link>
              </div>
            </article>
          ))}
        </div>
        <p className="lux-footnote">
          Der Streckenpreis richtet sich nach der berechneten Straßenroute.
          Zusätzliche Leistungen und mögliche Wartezeiten klären wir bei deiner
          Anfrage. Die Fahrzeugbilder zeigen Beispiele der jeweiligen Klasse.
        </p>
      </section>
      <section id="app" className="lux-app lux-section">
        <div className="lux-section-heading">
          <div>
            <p className="lux-kicker">LUXORÉ RIDE FÜR DEIN SMARTPHONE</p>
            <h2>
              Deine nächste Fahrt.
              <br />
              Direkt online planen.
            </h2>
          </div>
          <p>
            Dein Chauffeurservice für unterwegs. Plane deine Route, wähle deinen
            Komfort und frage eine Fahrt direkt online an. Die Apps für Android
            und iPhone folgen nach Fertigstellung und Store-Freigabe.
          </p>
        </div>
        <div className="lux-app-intro">
          <span>01 · Ziel wählen</span>
          <span>02 · Klasse bestimmen</span>
          <span>03 · Chauffeur anfragen</span>
        </div>
        <div className="lux-platforms">
          <article>
            <Play size={24} />
            <h3>Android</h3>
            <span className="lux-status">Bald verfügbar</span>
            <p>
              LUXORÉ Ride für Fahrgäste und LUXORÉ Driver für Chauffeure. Die
              Veröffentlichung bei Google Play wird vorbereitet.
            </p>
            <div className="lux-store-coming">
              <Play size={22} />
              <span>
                <small>BALD BEI</small>Google Play
              </span>
            </div>
          </article>
          <article>
            <Apple size={24} />
            <h3>iPhone</h3>
            <span className="lux-status">Bald verfügbar</span>
            <p>
              Dein Luxóre auf dem iPhone. Die iOS-Version folgt im Anschluss an
              Android. Aktuell gibt es noch keinen App-Store-Download.
            </p>
            <div className="lux-store-coming">
              <Apple size={24} />
              <span>
                <small>BALD IM</small>App Store
              </span>
            </div>
          </article>
          <article>
            <ArrowUpRight size={24} />
            <h3>Web-App</h3>
            <span className="lux-status">{bookingReady ? 'Direkt im Browser' : 'Online-Buchung in Vorbereitung'}</span>
            <p>
              {bookingReady ? 'Strecke und Preis berechnen, eine Klasse wählen und eine Fahrt anfragen. Die Verfügbarkeit wird bei deiner Anfrage geprüft.' : 'Die Online-Buchung wird gerade eingerichtet. Unser Team unterstützt dich persönlich bei deiner Fahrtanfrage.'}
            </p>
            <Link href="/mobile/customer">
              Fahrt buchen <ArrowRight size={16} />
            </Link>
          </article>
        </div>
      </section>
      <section id="kontakt" className="lux-contact lux-section">
        <div>
          <p className="lux-kicker">WIR FREUEN UNS AUF DEINE PLÄNE</p>
          <h2>
            Wohin darf
            <br />
            <em>es gehen?</em>
          </h2>
          <p>
            Buche deine Fahrt online oder besprich besondere Wünsche direkt mit
            unserem Team. Für Firmen, Hotels und individuelle Fahrten stimmen
            wir die Details persönlich mit dir ab.
          </p>
        </div>
        <div className="lux-contact-links">
          <a href="tel:+491605083829">
            <Phone size={21} />
            <span>
              <small>Ruf uns an</small>+49 160 5083829
            </span>
            <ArrowUpRight />
          </a>
          <a href="mailto:booking@luxoreride.de?subject=Fahrtanfrage">
            <Mail size={21} />
            <span>
              <small>Schreib uns</small>booking@luxoreride.de
            </span>
            <ArrowUpRight />
          </a>
          <p>Eine Anfrage ist noch keine bestätigte Buchung.</p>
        </div>
      </section>
      <footer className="lux-footer">
        <div>
          <Link href="/" className="lux-logo">
            LUXORÉ <span>RIDE</span>
          </Link>
          <p>Chauffeurservice aus Frankfurt am Main.</p>
        </div>
        <nav aria-label="Weitere Informationen">
          <Link href="/impressum">Impressum</Link>
          <Link href="/datenschutz">Datenschutz</Link>
          <Link href="/hilfe">Hilfe</Link>
          <Link href="/mobile/customer">Web-App</Link>
          <a href="#kontakt">Kontakt</a>
        </nav>
        <p className="lux-footer-note">
          LUXORÉ RIDE · Frankfurt am Main · App Store & Google Play: bald
          verfügbar.
        </p>
      </footer>
    </main>
  );
}
