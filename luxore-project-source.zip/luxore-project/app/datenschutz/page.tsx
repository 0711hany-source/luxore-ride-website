import Link from 'next/link';
export const metadata = { title: 'Datenschutz | LUXORÉ RIDE' };
export default function Page() {
  return (
    <main className="legal-page">
      <header className="portal-header">
        <Link href="/" className="lux-logo">
          LUXORÉ <span>RIDE</span>
        </Link>
        <Link href="/" className="portal-back">
          Zur Startseite
        </Link>
      </header>
      <article className="legal-content">
        <span className="portal-eyebrow">
          WEBSITE & ONLINE-APPS · STAND 06.10.2026
        </span>
        <h1>Datenschutzhinweise</h1>
        <p>
          Diese Hinweise beschreiben die Verarbeitung in der neuen
          Online-Oberfläche von LUXORÉ RIDE. Ergänzend gelten die{' '}
          <a href="https://luxoreride.de/datenschutz.html">
            Unternehmenshinweise
          </a>{' '}
          für persönliche Kontaktanfragen.
        </p>
        <h2>Kontakt und Verantwortlichkeit</h2>
        <p>
          LUXORÉ RIDE, Gerhart-Hauptmann-Ring 224, 60439 Frankfurt am Main. Bei
          Fragen zu deinen Daten:{' '}
          <a href="mailto:booking@luxoreride.de">booking@luxoreride.de</a>,
          Telefon <a href="tel:+491605083829">+49 160 5083829</a>. Die
          Unternehmensangaben findest du im{' '}
          <Link href="/impressum">Impressum</Link>.
        </p>
        <h2>Fahrten und persönliche Angaben</h2>
        <p>
          Für deine Fahrt verarbeiten wir Abholort, Ziel, berechnete
          Straßenroute und Preis, Fahrzeugklasse, Termin, Buchungsstatus sowie
          deinen Namen und deine Telefonnummer, soweit du diese angibst.
          Freiwillige Fahrtpräferenzen und Bordbestellungen werden an den
          zugewiesenen Chauffeur übermittelt. Die Verarbeitung dient der
          Anbahnung und Durchführung der gewünschten Fahrt (Art. 6 Abs. 1
          Buchst. b DSGVO).
        </p>
        <h2>Konto und Anmeldung</h2>
        <p>
          Ein Konto speichert E-Mail-Adresse, Name, Telefonnummer, Profilart und
          Bestätigungszeitpunkt. Die Anmeldung erfolgt per einmaligem
          E-Mail-Code. Codes werden gehasht gespeichert, gelten zehn Minuten und
          erlauben höchstens fünf Bestätigungsversuche. Fahrer- und
          Flottenregistrierungen werden zusätzlich betrieblich geprüft. Der
          E-Mail-Versand wird gerade eingerichtet; bis dahin ist keine
          Registrierung aktiv.
        </p>
        <p>
          Bei aktiviertem Versand erhält der Transaktions-E-Mail-Dienst Resend
          die E-Mail-Adresse und den Inhalt der Anmelde-E-Mail. Weitere
          Informationen:{' '}
          <a href="https://resend.com/legal/privacy-policy">
            Resend Datenschutz
          </a>
          . Wir verwenden diese E-Mails zur Kontoanmeldung, nicht für
          Werbenachrichten.
        </p>
        <h2>Standort</h2>
        <p>
          Dein Standort wird nur nach Freigabe über die Geräteberechtigung
          verwendet. Als Fahrgast kannst du damit den Abholort bestimmen; eine
          zusätzliche Standortfreigabe während der Fahrt ist freiwillig.
          Fahrerstandorte werden während einer gestarteten Schicht verarbeitet,
          um geeignete Fahrzeuge zu vermitteln, die Anfahrt zu zeigen und die
          Fahrt zu begleiten. Die Fahrer-App benötigt für die laufende Schicht
          im Hintergrund eine gesonderte Berechtigung. Du kannst diese in den
          Geräteeinstellungen entziehen und die Schicht in der App beenden.
        </p>
        <p>
          Kunden sehen bei der Suche bis zu drei geeignete Fahrer als
          Kartenpositionen ohne persönliche Fahrerdaten. Nach Annahme erhält der
          jeweilige Fahrgast Angaben zum zugewiesenen Fahrer und Fahrzeug. Die
          Disposition sieht nur ihre Flotte; die Betreiberverwaltung benötigt
          einen gesondert geschützten Betreiberzugang.
        </p>
        <h2>Karten und Adresssuche</h2>
        <p>
          Für Karten, Adressen, Straßenrouten und Verkehrsinformationen nutzen
          wir Mapbox. Beim Laden der Karte können IP-Adresse und technische
          Nutzungsdaten an Mapbox übermittelt werden; eingegebene Adressen und
          ausgewählte Koordinaten werden für die Adress- und Routenberechnung
          verarbeitet. Vorläufige Suchvorschläge werden nicht in unserer
          Datenbank gespeichert. Bestätigte Adressen werden für die Fahrt
          gespeichert; lizenzierte Geokodierungsergebnisse können bis zu 30 Tage
          wiederverwendet werden. Weitere Informationen:{' '}
          <a href="https://www.mapbox.com/legal/privacy">Mapbox Datenschutz</a>.
        </p>
        <h2>Sitzungen, Geräte und Sicherheit</h2>
        <p>
          Die Online-Oberfläche wird über OpenAI Sites und Cloudflare
          bereitgestellt. Dabei fallen technische Verbindungsdaten wie
          IP-Adresse und Serverprotokolle an. Eine notwendige Gerätesitzung
          ermöglicht Gastfahrten ohne Anmeldung. Sie verwendet ein geschütztes
          Sitzungscookie mit bis zu 180 Tagen Laufzeit. Kontositzungen verwenden
          ein gesondertes Cookie mit bis zu 30 Tagen Laufzeit. Sitzungsschlüssel
          werden serverseitig nur gehasht gespeichert. Geräteinstellungen für
          Navigation und Bedienung können lokal gespeichert werden.
        </p>
        <p>
          Die Fahrer-App speichert den Schlüssel der laufenden Standortsession
          geschützt auf dem Gerät. Eine kürzlich ermittelte GPS-Position wird
          dort für die Wiederherstellung der laufenden Schicht
          zwischengespeichert und beim Beenden der Ortung entfernt.
          Sicherheitsbegrenzungen und ein Betreiberprotokoll schützen vor
          Missbrauch (Art. 6 Abs. 1 Buchst. f DSGVO). Diese Oberfläche enthält
          keine eingebauten Werbe- oder Marketing-Tracker.
        </p>
        <h2>Speicherung und Löschung</h2>
        <p>
          Du kannst die Löschung deines Kontos unter{' '}
          <Link href="/konto">Mein Konto → Konto löschen</Link> direkt
          anfordern. Die Anfrage wird in der Betreiberverwaltung bearbeitet;
          Kontositzungen werden beendet. Kontaktdaten und nicht mehr benötigte
          Profil- und Adressdaten werden im Löschablauf entfernt. Fahrt- und
          Zahlungsbelege können aufgrund gesetzlicher Pflichten weiter
          aufbewahrt werden (Art. 6 Abs. 1 Buchst. c DSGVO). Zugang und genaue
          Aufbewahrungsfristen der Betriebsunterlagen sind vor dem öffentlichen
          App-Start verbindlich festzulegen.
        </p>
        <h2>Deine Rechte</h2>
        <p>
          Du hast nach Maßgabe der DSGVO Rechte auf Auskunft, Berichtigung,
          Löschung, Einschränkung und Datenübertragbarkeit sowie Widerspruch
          gegen Verarbeitungen auf Grundlage berechtigter Interessen.
          Einwilligungen kannst du für die Zukunft widerrufen. Für diese
          Anliegen kontaktiere{' '}
          <a href="mailto:booking@luxoreride.de">booking@luxoreride.de</a>. Du
          kannst dich zudem bei einer Datenschutzaufsichtsbehörde beschweren,
          insbesondere beim{' '}
          <a href="https://datenschutz.hessen.de/">
            Hessischen Beauftragten für Datenschutz und Informationsfreiheit
          </a>
          .
        </p>
        <h2>Öffentlicher App-Start</h2>
        <p>
          Die Store-Versionen sind noch nicht veröffentlicht. Die endgültigen
          Betreiberangaben, Aufbewahrungsfristen, Vereinbarungen mit
          Dienstleistern und gegebenenfalls internationale Datenübermittlungen
          sind vor deren Freigabe zu bestätigen.
        </p>
      </article>
    </main>
  );
}
