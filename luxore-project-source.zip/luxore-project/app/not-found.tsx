import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
export const metadata = { title: 'Seite nicht gefunden | LUXORÉ RIDE' };
/** Shown for every unknown address instead of the bare framework page. */
export default function NotFound() {
  return (
    <main className="legal-page">
      <header className="portal-header">
        <Link className="lux-logo" href="/">
          LUXORÉ <span>RIDE</span>
        </Link>
        <Link className="portal-back" href="/">
          <ArrowLeft size={18} /> Zur Startseite
        </Link>
      </header>
      <article className="legal-content">
        <span className="portal-eyebrow">FEHLER 404</span>
        <h1>Diese Seite gibt es nicht</h1>
        <p>
          Die Adresse ist falsch geschrieben oder die Seite wurde verschoben.
        </p>
        <p>
          <Link href="/">Zur Startseite</Link>
          {' · '}
          <Link href="/mobile/customer">Fahrt buchen</Link>
          {' · '}
          <Link href="/hilfe">Hilfe & Kontakt</Link>
        </p>
      </article>
    </main>
  );
}
