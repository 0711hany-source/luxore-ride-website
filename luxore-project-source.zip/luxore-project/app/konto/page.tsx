import AccountScreen from './screen';
export { viewport } from '@/app/mobile/layout';
export const metadata = {
  title: 'Dein Konto | LUXORÉ RIDE',
  robots: { index: false, follow: false },
};
export default function Page() {
  return <AccountScreen />;
}
