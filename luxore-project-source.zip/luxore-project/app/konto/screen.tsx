'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  ArrowLeft,
  CarFront,
  Check,
  Mail,
  ShieldCheck,
  UserRound,
  Users,
  LogOut,
  Trash2,
} from 'lucide-react';
import { api } from '@/app/mobility/api';
type Profile = {
  id: string;
  email: string;
  name: string;
  phone: string;
  kind: string;
};
export default function AccountScreen() {
  const [returnPath, setReturnPath] = useState('/mobile/customer');
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loaded, setLoaded] = useState(false),
    [ready, setReady] = useState(false);
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState(''),
    [name, setName] = useState(''),
    [phone, setPhone] = useState('');
  const [kind, setKind] = useState('customer'),
    [privacy, setPrivacy] = useState(false);
  const [challenge, setChallenge] = useState(''),
    [code, setCode] = useState('');
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [message, setMessage] = useState('');
  const [deleting, setDeleting] = useState(false),
    [confirmation, setConfirmation] = useState('');
  useEffect(() => {
    const wanted = new URLSearchParams(window.location.search).get('weiter');
    if (wanted === '/mobile/driver') setReturnPath(wanted);
    let active = true;
    api<{ account: Profile | null; registrationReady: boolean }>('account')
      .then((r) => {
        if (!active) return;
        setProfile(r.account);
        setReady(r.registrationReady);
        if (r.account) {
          setName(r.account.name);
          setPhone(r.account.phone);
        }
      })
      .catch((e) => {
        if (active) setError(e.message);
      })
      .finally(() => {
        if (active) setLoaded(true);
      });
    return () => {
      active = false;
    };
  }, []);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError('');
    setMessage('');
    try {
      if (profile) {
        await api('account', { action: 'profile', name, phone });
        setMessage('Dein Profil wurde gespeichert.');
      } else if (challenge) {
        const r = await api<{ account: Profile; isAdmin: boolean }>('account', {
          action: 'verify',
          challengeId: challenge,
          code,
        });
        const desired = new URLSearchParams(window.location.search).get(
          'weiter',
        );
        const allowed = [
          '/mobile/customer',
          '/mobile/driver',
          '/disposition',
          '/betreiber',
        ];
        const target =
          desired && allowed.includes(desired)
            ? desired
            : r.account.kind === 'customer'
              ? '/mobile/customer'
              : '/mobile/driver';
        window.location.assign(
          target === '/betreiber' && !r.isAdmin ? '/mobile/customer' : target,
        );
      } else {
        const r = await api<{ challengeId: string }>('account', {
          action: 'code',
          mode,
          email,
          name,
          phone,
          kind,
          privacy,
        });
        setChallenge(r.challengeId);
        setMessage(
          'Dein Code wurde per E-Mail angefordert. Er ist 10 Minuten gültig.',
        );
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function leave(action: 'logout' | 'delete') {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      await api('account', { action, confirmation });
      if (action === 'logout') window.location.assign('/konto');
      else {
        setProfile(null);
        setDeleting(false);
        setChallenge('');
        setMessage(
          'Deine Löschanfrage ist eingegangen. Dein Konto wurde gesperrt und alle Anmeldungen beendet. Zukünftige Reservierungen wurden storniert. Wir bearbeiten die Löschung; gesetzlich aufzubewahrende Fahrt- und Zahlungsbelege bleiben erhalten.',
        );
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <main className="account-page">
      <header className="portal-header">
        <Link href="/" className="lux-logo">
          LUXORÉ <span>RIDE</span>
        </Link>
        <Link
          href={
            profile?.kind && profile.kind !== 'customer'
              ? '/mobile/driver'
              : returnPath
          }
          className="portal-back"
        >
          <ArrowLeft size={18} /> Zur Fahrt
        </Link>
      </header>
      <div className="account-layout">
        <aside className="account-story">
          <span className="portal-eyebrow">DEIN PERSÖNLICHER ZUGANG</span>
          <h1>
            Dein Konto.
            <br />
            <em>Dein Luxóre.</em>
          </h1>
          <p>
            Auf jedem Gerät zu Hause. Mit einem persönlichen Profil für deine
            Fahrten und deinen Chauffeurservice.
          </p>
          <div className="account-assurance">
            <ShieldCheck size={22} />
            <span>
              Anmeldung per E-Mail-Code.
              <br />
              Ohne Passwort und ohne ChatGPT-Konto.
            </span>
          </div>
        </aside>
        <section className="account-card" aria-busy={busy || !loaded}>
          {!loaded ? (
            <p role="status">Dein Zugang wird geladen …</p>
          ) : (
            <>
              <div className="account-card-icon">
                {profile ? <UserRound /> : <Mail />}
              </div>
              <h2>
                {profile
                  ? 'Dein Profil'
                  : challenge
                    ? 'Prüfe dein Postfach'
                    : mode === 'register'
                      ? 'Willkommen bei Luxóre'
                      : 'Schön, dich wiederzusehen'}
              </h2>
              {!profile && !challenge && (
                <div className="account-tabs" aria-label="Kontozugang">
                  <button
                    type="button"
                    aria-pressed={mode === 'login'}
                    onClick={() => {
                      setMode('login');
                      setError('');
                    }}
                  >
                    Anmelden
                  </button>
                  <button
                    type="button"
                    aria-pressed={mode === 'register'}
                    onClick={() => {
                      setMode('register');
                      setError('');
                    }}
                  >
                    Registrieren
                  </button>
                </div>
              )}
              {!profile && !ready && (
                <div className="account-notice">
                  <Mail size={20} />
                  <p>
                    Die Kontoanmeldung wird gerade eingerichtet. Bis dahin
                    kannst du deine Fahrt als Gast anfragen.
                  </p>
                  <Link href="/mobile/customer">Als Gast weiter</Link>
                </div>
              )}
              <form onSubmit={submit}>
                {profile ? (
                  <>
                    <p className="account-email">
                      <Check size={16} />
                      {profile.email}
                    </p>
                    <label>
                      Dein Name
                      <input
                        autoComplete="name"
                        required
                        value={name}
                        maxLength={80}
                        onChange={(e) => setName(e.target.value)}
                      />
                    </label>
                    <label>
                      Telefon
                      <input
                        autoComplete="tel"
                        type="tel"
                        required
                        value={phone}
                        maxLength={30}
                        onChange={(e) => setPhone(e.target.value)}
                      />
                    </label>
                  </>
                ) : challenge ? (
                  <>
                    <p>
                      Gib den sechsstelligen Code für <strong>{email}</strong>{' '}
                      ein.
                    </p>
                    <label>
                      Anmeldecode
                      <input
                        className="account-code"
                        autoComplete="one-time-code"
                        inputMode="numeric"
                        pattern="[0-9]{6}"
                        maxLength={6}
                        required
                        autoFocus
                        value={code}
                        onChange={(e) =>
                          setCode(e.target.value.replace(/\D/g, ''))
                        }
                      />
                    </label>
                    <button
                      className="portal-text-button"
                      type="button"
                      disabled={busy}
                      onClick={() => {
                        setChallenge('');
                        setCode('');
                        setMessage('');
                      }}
                    >
                      Adresse ändern oder neuen Code anfordern
                    </button>
                  </>
                ) : (
                  <>
                    {mode === 'register' && (
                      <>
                        <fieldset className="account-kinds">
                          <legend>Ich möchte</legend>
                          {[
                            {
                              id: 'customer',
                              label: 'Fahrten buchen',
                              Icon: UserRound,
                            },
                            {
                              id: 'driver',
                              label: 'Chauffeur werden',
                              Icon: CarFront,
                            },
                            {
                              id: 'fleet',
                              label: 'Eine Flotte anmelden',
                              Icon: Users,
                            },
                          ].map(({ id, label, Icon }) => (
                            <label
                              key={id}
                              className={kind === id ? 'selected' : ''}
                            >
                              <input
                                type="radio"
                                name="kind"
                                value={id}
                                checked={kind === id}
                                onChange={() => setKind(id)}
                              />
                              <Icon size={20} />
                              <span>{label}</span>
                            </label>
                          ))}
                        </fieldset>
                        <label>
                          Dein Name
                          <input
                            autoComplete="name"
                            required
                            value={name}
                            maxLength={80}
                            onChange={(e) => setName(e.target.value)}
                          />
                        </label>
                        <label>
                          Telefon
                          <input
                            autoComplete="tel"
                            type="tel"
                            required
                            value={phone}
                            maxLength={30}
                            onChange={(e) => setPhone(e.target.value)}
                          />
                        </label>
                      </>
                    )}
                    <label>
                      E-Mail-Adresse
                      <input
                        autoComplete="email"
                        type="email"
                        required
                        value={email}
                        maxLength={254}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="name@beispiel.de"
                      />
                    </label>
                    {mode === 'register' && (
                      <>
                        <label className="account-consent">
                          <input
                            type="checkbox"
                            required
                            checked={privacy}
                            onChange={(e) => setPrivacy(e.target.checked)}
                          />
                          <span>
                            Ich habe die{' '}
                            <Link href="/datenschutz">Datenschutzhinweise</Link>{' '}
                            gelesen.
                          </span>
                        </label>
                        {kind !== 'customer' && (
                          <p className="portal-muted">
                            Fahrer und Flotten werden persönlich geprüft und
                            anschließend freigegeben. Die Registrierung allein
                            berechtigt nicht zur Annahme von Fahrten.
                          </p>
                        )}
                      </>
                    )}
                  </>
                )}
                {error && (
                  <p className="portal-error" role="alert">
                    {error}
                  </p>
                )}
                {message && (
                  <p className="portal-success" role="status">
                    {message}
                  </p>
                )}
                <button
                  className="portal-primary"
                  disabled={busy || (!profile && !ready)}
                >
                  {busy
                    ? 'Einen Moment …'
                    : profile
                      ? 'Profil speichern'
                      : challenge
                        ? 'Code bestätigen'
                        : 'Code per E-Mail erhalten'}
                </button>
              </form>
              {profile && (
                <div className="account-secondary">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void leave('logout')}
                  >
                    <LogOut size={17} /> Abmelden
                  </button>
                  <button type="button" onClick={() => setDeleting(!deleting)}>
                    <Trash2 size={17} /> Konto löschen
                  </button>
                  {deleting && (
                    <div className="account-deletion">
                      <p>
                        Dein Konto wird gesperrt und zur Löschung vorgemerkt.
                        Fahrt- und Zahlungsbelege mit gesetzlicher
                        Aufbewahrungspflicht bleiben erhalten. Bitte beende
                        zuerst laufende Fahrten und pausiere deine Schicht.
                      </p>
                      <label>
                        Zur Bestätigung LÖSCHEN eingeben
                        <input
                          value={confirmation}
                          onChange={(e) => setConfirmation(e.target.value)}
                          autoComplete="off"
                        />
                      </label>
                      <button
                        type="button"
                        className="portal-danger"
                        disabled={busy || confirmation !== 'LÖSCHEN'}
                        onClick={() => void leave('delete')}
                      >
                        Löschung anfordern
                      </button>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
          <div className="account-legal">
            <Link href="/datenschutz">Datenschutz</Link>
            <Link href="/impressum">Impressum</Link>
            <Link href="/hilfe">Hilfe</Link>
          </div>
        </section>
      </div>
    </main>
  );
}
