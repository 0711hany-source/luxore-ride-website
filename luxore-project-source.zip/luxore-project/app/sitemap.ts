import type { MetadataRoute } from 'next';

const site = 'https://luxoreride.de';

/** The public pages search engines should know about. */
export default function sitemap(): MetadataRoute.Sitemap {
  return [
    { url: site + '/', changeFrequency: 'weekly', priority: 1 },
    { url: site + '/anfrage', changeFrequency: 'monthly', priority: 0.8 },
    { url: site + '/hilfe', changeFrequency: 'monthly', priority: 0.5 },
    { url: site + '/impressum', changeFrequency: 'yearly', priority: 0.2 },
    { url: site + '/datenschutz', changeFrequency: 'yearly', priority: 0.2 },
  ];
}
