import Link from 'next/link';
export const metadata = { title: 'Impressum | LUXORÉ RIDE' };
export default function Page() {
  return (
    <main className="legal-page">
      <header className="portal-header">
        <Link href="/" className="lux-logo">
          LUXORÉ <span>RIDE</span>
        </Link>
        <Link href="/" className="portal-back">
          Zur Startseite
        </Link>
      </header>
      <article className="legal-content">
        <h1>Impressum</h1>
        <p>
          <strong>LUXORÉ RIDE</strong>
          <br />
          Gerhart-Hauptmann-Ring 224
          <br />
          60439 Frankfurt am Main
        </p>
        <p>
          Telefon: <a href="tel:+491605083829">+49 160 5083829</a>
          <br />
          E-Mail:{' '}
          <a href="mailto:booking@luxoreride.de">booking@luxoreride.de</a>
        </p>
        <p>
          Die veröffentlichten Unternehmensangaben findest du im{' '}
          <a href="https://luxoreride.de/impressum.html">
            Impressum der Unternehmenswebsite
          </a>
          .
        </p>
        <h2>Website und Apps</h2>
        <p>
          Diese Website stellt die neue Online-Oberfläche von LUXORÉ RIDE
          bereit. Apps für Google Play und den App Store werden vorbereitet und
          sind dort noch nicht erhältlich.
        </p>
        <p>
          <Link href="/datenschutz">
            Datenschutzhinweise zur Online-Oberfläche
          </Link>{' '}
          · <Link href="/hilfe">Hilfe & Kontakt</Link>
        </p>
      </article>
    </main>
  );
}
