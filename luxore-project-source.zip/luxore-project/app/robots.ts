import type { MetadataRoute } from 'next';

/** Search engines may read the public pages; apps, portals and the API stay out. */
export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: '*',
      allow: '/',
      disallow: [
        '/api/',
        '/mobile/',
        '/betreiber',
        '/disposition',
        '/betrieb',
        '/konto',
        '/team',
        '/pruefung',
        '/ride',
        '/app-ansichten',
      ],
    },
    sitemap: 'https://luxoreride.de/sitemap.xml',
  };
}
