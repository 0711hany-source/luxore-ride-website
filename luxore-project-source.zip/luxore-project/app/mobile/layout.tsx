import type { Viewport } from 'next';
import { databaseConfigured } from '@/db/sqlite';
import ServiceUnavailable from '@/components/service-unavailable';
export const dynamic = 'force-dynamic';
// The installed app has a fixed UI scale. Mapbox handles gestures inside its own canvas.
export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
  interactiveWidget: 'resizes-content',
};
export default function MobileLayout({children}:{children:React.ReactNode}) {
  return databaseConfigured() ? children : <ServiceUnavailable />;
}
