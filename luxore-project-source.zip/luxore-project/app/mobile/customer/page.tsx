import MobilityWorkspace from '@/app/mobility/workspace';
export const metadata = {
  title: 'LUXORÉ Ride',
  robots: { index: false, follow: false },
};
export default function Page() {
  return <MobilityWorkspace appMode="customer" />;
}
