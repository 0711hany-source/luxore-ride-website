import MobilityWorkspace from '@/app/mobility/workspace';
export const metadata = {
  title: 'LUXORÉ Driver',
  robots: { index: false, follow: false },
};
export default function Page() {
  return <MobilityWorkspace appMode="driver" />;
}
