import type { Metadata } from 'next';
import './globals.css';
import './mobility/app-design.css';
import './portal.css';
export const metadata: Metadata = {
  title: 'LUXORÉ RIDE | Chauffeurservice Frankfurt',
  description:
    'Chauffeurservice in Frankfurt und Rhein-Main: Business Class, First Class und Van. Entdecke unsere Leistungen, Kilometerpreise und die kommende LUXORÉ RIDE App.',
  icons: {
    icon: { url: '/favicon.svg', type: 'image/svg+xml' },
    apple: { url: '/brand/icon-ride.png', type: 'image/png', sizes: '1024x1024' },
  },
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}
