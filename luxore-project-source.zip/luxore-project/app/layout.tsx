import type { Metadata } from 'next';
import './design-tokens.css';
import './globals.css';
import './mobility/app-design.css';
import './portal.css';
import './platform.css';

const siteUrl = 'https://luxoreride.de';

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: 'LUXORÉ RIDE | Chauffeurservice & Flughafentransfer Frankfurt',
  description:
    'Chauffeurservice in Frankfurt und Rhein-Main: Flughafentransfer, Business-Fahrten und Events. Business Class, Electric Class, Van und First Class auf Anfrage mit transparenten Kilometerpreisen.',
  alternates: { canonical: '/' },
  openGraph: {
    type: 'website',
    locale: 'de_DE',
    url: siteUrl,
    siteName: 'LUXORÉ RIDE',
    title: 'LUXORÉ RIDE | Chauffeurservice & Flughafentransfer Frankfurt',
    description:
      'Persönlicher Chauffeur für Flughafentransfer, Business und Events in Frankfurt und Rhein-Main. Kilometerpreise ab 2,50 €.',
    images: [{ url: '/brand/frankfurt.png', width: 1024, height: 1024, alt: 'LUXORÉ RIDE Chauffeurservice Frankfurt' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'LUXORÉ RIDE | Chauffeurservice Frankfurt',
    description: 'Flughafentransfer, Business und Events mit persönlichem Chauffeur.',
    images: ['/brand/frankfurt.png'],
  },
  robots: { index: true, follow: true },
  icons: {
    icon: { url: '/favicon.svg', type: 'image/svg+xml' },
    apple: { url: '/brand/icon-ride.png', type: 'image/png', sizes: '1024x1024' },
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}
