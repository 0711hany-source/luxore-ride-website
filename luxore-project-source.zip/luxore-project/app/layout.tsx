import type { Metadata } from 'next';
import './globals.css';
import './mobility/app-design.css';
import './portal.css';
export const metadata: Metadata = {
  title: 'LUXORÉ RIDE | Chauffeurservice Frankfurt',
  description:
    'Chauffeurservice in Frankfurt und Rhein-Main: Business Class, First Class und Van. Entdecke unsere Leistungen, Kilometerpreise und die kommende LUXORÉ RIDE App.',
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}
