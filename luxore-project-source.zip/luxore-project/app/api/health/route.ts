import {
  accountsConfigured,
  databaseConfigured,
  runtimeDatabase,
} from '@/db/sqlite';
import { mailReady } from '@/lib/mobility/accounts';
export const dynamic = 'force-dynamic';
export async function GET() {
  let connected = false;
  let bookingSchemaReady = false;
  if (accountsConfigured()) {
    try {
      const db = runtimeDatabase('account');
      await Promise.all([
        db.prepare('SELECT id,email FROM mobility_accounts LIMIT 0').all(),
        db
          .prepare(
            'SELECT id,fleet_id,plate,services FROM mobility_vehicles LIMIT 0',
          )
          .all(),
      ]);
      connected = true;
      if (databaseConfigured()) {
        // Compile the booking queries without reading customer or trip data.
        // An incomplete booking migration must not hide working own accounts.
        await db
          .prepare(
            `SELECT p.id,p.owner_id,p.label,p.lat,p.lng,p.attribution,
                    q.payload,q.expires_at,b.price,b.status,o.expires_at
             FROM mobility_places p
             CROSS JOIN mobility_quotes q
             CROSS JOIN mobility_bookings b
             CROSS JOIN mobility_offers o LIMIT 0`,
          )
          .all();
        bookingSchemaReady = true;
      }
    } catch {
      /* Public readiness never includes credentials or database errors. */
    }
  }
  const ready = connected && bookingSchemaReady && databaseConfigured();
  return Response.json(
    {
      service: 'luxore-ride',
      bookingConfigured: ready,
      databaseConnected: connected,
      accountsReady: connected && mailReady(),
    },
    {
      status: ready ? 200 : 503,
      headers: { 'Cache-Control': 'no-store' },
    },
  );
}
