import { databaseConfigured } from '@/db/sqlite';
export const dynamic = 'force-dynamic';
export function GET() {
  const ready = databaseConfigured();
  return Response.json({ service: 'luxore-ride', bookingConfigured: ready }, {
    status: ready ? 200 : 503,
    headers: { 'Cache-Control': 'no-store' },
  });
}
