import {
  accountsConfigured,
  databaseConfigured,
  runtimeDatabase,
} from '@/db/sqlite';
import { mailReady } from '@/lib/mobility/accounts';
export const dynamic = 'force-dynamic';
export async function GET() {
  let connected = false;
  if (accountsConfigured()) {
    try {
      const db = runtimeDatabase('account');
      await Promise.all([
        db.prepare('SELECT id,email FROM mobility_accounts LIMIT 0').all(),
        db
          .prepare(
            'SELECT id,fleet_id,plate,services FROM mobility_vehicles LIMIT 0',
          )
          .all(),
      ]);
      connected = true;
    } catch {
      /* Public readiness never includes credentials or database errors. */
    }
  }
  const ready = connected && databaseConfigured();
  return Response.json(
    {
      service: 'luxore-ride',
      bookingConfigured: ready,
      databaseConnected: connected,
      accountsReady: connected && mailReady(),
    },
    {
      status: ready ? 200 : 503,
      headers: { 'Cache-Control': 'no-store' },
    },
  );
}
