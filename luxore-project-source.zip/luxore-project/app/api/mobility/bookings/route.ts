import { emptyOrder, parseCart } from '@/lib/mobility/refreshments';
import { parseRidePreferences } from '@/lib/mobility/ride-preferences';
import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import { coordinate, isService, type Quote } from '@/lib/mobility/domain';
import { hydrate } from '@/lib/mobility/bookings';
import { dispatch } from '@/lib/mobility/dispatch';
export async function GET() {
  return handled(async () => {
    const user = await identity();
    const rows = await db()
      .prepare(
        'SELECT * FROM mobility_bookings WHERE owner_id=? ORDER BY created_at DESC LIMIT 100',
      )
      .bind(user.userId)
      .all();
    return json({
      bookings: await Promise.all(rows.results.map(hydrate)),
      serverTime: Date.now(),
    });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    const b = await body(request);
    const now = Date.now();
    if (b.action === 'start-sharing') {
      const shareId = crypto.randomUUID();
      const changed = await db()
        .prepare(
          "UPDATE mobility_bookings SET rider_share_id=? WHERE id=? AND owner_id=? AND status IN ('accepted','arrived','riding')",
        )
        .bind(shareId, text(b.id), user.userId)
        .run();
      if (!changed.meta.changes)
        throw new ApiError(409, 'Keine aktive zugewiesene Fahrt.');
      return json({ shareId });
    }
    if (b.action === 'position') {
      if (!coordinate(b.lat, b.lng))
        throw new ApiError(400, 'Ungültiger Standort.');
      const r = await db()
        .prepare(
          "UPDATE mobility_bookings SET rider_lat=?,rider_lng=?,rider_location_at=? WHERE id=? AND owner_id=? AND rider_share_id=? AND status IN ('accepted','arrived','riding')",
        )
        .bind(b.lat, b.lng, now, text(b.id), user.userId, text(b.shareId))
        .run();
      if (!r.meta.changes)
        throw new ApiError(
          409,
          'Standortfreigabe ist nur bei einer aktiven zugewiesenen Fahrt möglich.',
        );
      return json({ ok: true });
    }
    if (b.action === 'stop-sharing') {
      await db()
        .prepare(
          'UPDATE mobility_bookings SET rider_lat=NULL,rider_lng=NULL,rider_location_at=NULL,rider_share_id=NULL WHERE id=? AND owner_id=?',
        )
        .bind(text(b.id), user.userId)
        .run();
      return json({ ok: true });
    }
    if (b.action === 'cancel') {
      const id = text(b.id);
      await db().writeTransaction(async (transaction) => {
        const changed = await transaction
          .prepare(
            "UPDATE mobility_bookings SET status='cancelled',updated_at=?,rider_lat=NULL,rider_lng=NULL,rider_location_at=NULL,rider_share_id=NULL WHERE id=? AND owner_id=? AND status IN ('reserved','requesting','accepted','arrived')",
          )
          .bind(now, id, user.userId)
          .run();
        if (!changed.meta.changes) {
          const saved = await transaction
            .prepare(
              "SELECT id FROM mobility_bookings WHERE id=? AND owner_id=? AND status='cancelled'",
            )
            .bind(id, user.userId)
            .first();
          // A lost answer must acknowledge the saved cancellation without
          // rewriting timestamps, withdrawing offers or adding another event.
          if (saved) return;
          throw new ApiError(
            409,
            'Diese Fahrt kann nicht mehr storniert werden.',
          );
        }
        await transaction
          .prepare(
            "UPDATE mobility_offers SET status='withdrawn' WHERE booking_id=? AND status='pending'",
          )
          .bind(id)
          .run();
        await transaction
          .prepare("INSERT INTO mobility_events VALUES(?,?,?,'cancelled',?)")
          .bind(crypto.randomUUID(), id, user.userId, now)
          .run();
      });
      return json({ ok: true });
    }
    await limit(user.userId, 'book', 10);
    const quoteId = text(b.quoteId);
    if (!isService(b.service))
      throw new ApiError(400, 'Ungültige Fahrzeugklasse.');
    const existing = await db()
      .prepare(
        'SELECT * FROM mobility_bookings WHERE quote_id=? AND owner_id=?',
      )
      .bind(quoteId, user.userId)
      .first();
    if (existing) {
      if (existing.service !== b.service)
        throw new ApiError(
          409,
          'Dieses Angebot wurde bereits für eine andere Klasse gebucht.',
        );
      return json(await hydrate(existing));
    }
    const stored = await db()
      .prepare(
        'SELECT payload FROM mobility_quotes WHERE id=? AND owner_id=? AND expires_at>?',
      )
      .bind(quoteId, user.userId, now)
      .first<{ payload: string }>();
    if (!stored)
      throw new ApiError(
        409,
        'Das Preisangebot ist abgelaufen. Bitte die Route neu berechnen.',
      );
    const q = JSON.parse(stored.payload) as Quote;
    if (
      q.mode === 'reservation' &&
      (!q.scheduledAt || q.scheduledAt < now + 25 * 60000)
    )
      throw new ApiError(409, 'Bitte die Abholzeit aktualisieren.');
    const riderName = text(b.riderName, 80);
    const riderPhone = text(b.riderPhone, 30);
    if (!/^\+?[\d\s()-]{6,30}$/.test(riderPhone))
      throw new ApiError(400, 'Bitte eine gültige Telefonnummer angeben.');
    let preferences;
    const refreshments = emptyOrder();
    try {
      preferences = parseRidePreferences(b.preferences);
      refreshments.requested = parseCart(b.refreshments);
    } catch (error) {
      throw new ApiError(400, (error as Error).message);
    }
    const id = crypto.randomUUID();
    try {
      await db().batch([
        db()
          .prepare(
            'INSERT INTO mobility_bookings(id,quote_id,owner_id,service,price,route,mode,scheduled_at,status,created_at,updated_at,dispatch_at,rider_name,rider_phone,rider_preferences,refreshments,fare_price) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
          )
          .bind(
            id,
            quoteId,
            user.userId,
            b.service,
            q.prices[b.service],
            JSON.stringify(q),
            q.mode,
            q.scheduledAt,
            q.mode === 'reservation' ? 'reserved' : 'requesting',
            now,
            now,
            q.mode === 'now' ? now : null,
            riderName,
            riderPhone,
            JSON.stringify(preferences),
            JSON.stringify(refreshments),
            q.prices[b.service],
          ),
        db()
          .prepare("INSERT INTO mobility_events VALUES(?,?,?,'created',?)")
          .bind(crypto.randomUUID(), id, user.userId, now),
      ]);
    } catch {
      const retry = await db()
        .prepare(
          'SELECT * FROM mobility_bookings WHERE quote_id=? AND owner_id=?',
        )
        .bind(quoteId, user.userId)
        .first();
      if (retry && retry.service === b.service)
        return json(await hydrate(retry));
      throw new ApiError(
        409,
        'Du hast bereits eine aktive Fahrt. Bitte diese zuerst abschließen oder stornieren.',
      );
    }
    await dispatch(db(), now);
    const result = await db()
      .prepare('SELECT * FROM mobility_bookings WHERE id=?')
      .bind(id)
      .first();
    return json(await hydrate(result!), 201);
  });
}
