import { freshLocation } from '@/lib/mobility/location';
import { stockReminder } from '@/lib/mobility/inventory-server';
import { berlinDayStart } from '@/lib/mobility/time';
import { vehicleEligible, driverIdle } from '@/lib/mobility/vehicles';
import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  text,
  tokenHash,
} from '@/lib/mobility/server';
import {
  coordinate,
  driverNext,
  parseServices,
  type Driver,
  type BookingStatus,
} from '@/lib/mobility/domain';
import { accept, dispatch } from '@/lib/mobility/dispatch';
import { hydrate } from '@/lib/mobility/bookings';
export async function GET() {
  return handled(async () => {
    const user = await identity();
    const driver = await db()
      .prepare('SELECT * FROM mobility_drivers WHERE id=?')
      .bind(user.userId)
      .first<Driver>();
    if (!driver) return json({ driver: null, offers: [], bookings: [] });
    const bookings = await db()
      .prepare(
        "SELECT * FROM mobility_bookings WHERE driver_id=? AND status IN ('accepted','arrived','riding')",
      )
      .bind(user.userId)
      .all();
    const payments = await db()
      .prepare(
        "SELECT * FROM mobility_bookings WHERE driver_id=? AND status='completed' AND completed_at IS NOT NULL AND payment_status='unpaid' ORDER BY completed_at",
      )
      .bind(user.userId)
      .all();
    const history = await db()
      .prepare(
        "SELECT * FROM mobility_bookings WHERE driver_id=? AND status='completed' AND completed_at IS NOT NULL ORDER BY completed_at DESC LIMIT 30",
      )
      .bind(user.userId)
      .all();
    const revenue = await db()
      .prepare(
        "SELECT COUNT(*) AS trips,COALESCE(SUM(price),0) AS gross,COALESCE(SUM(CASE WHEN payment_status='paid' THEN price ELSE 0 END),0) AS collected,COALESCE(SUM(CASE WHEN payment_status='unpaid' THEN price ELSE 0 END),0) AS outstanding FROM mobility_bookings WHERE driver_id=? AND status='completed' AND completed_at>=?",
      )
      .bind(user.userId, Date.now() - 7 * 86400000)
      .first();
    const today = await db()
      .prepare(
        "SELECT COUNT(*) AS trips,COALESCE(SUM(price),0) AS gross,COALESCE(SUM(CASE WHEN payment_status='paid' THEN price ELSE 0 END),0) AS collected,COALESCE(SUM(CASE WHEN payment_status='unpaid' THEN price ELSE 0 END),0) AS outstanding FROM mobility_bookings WHERE driver_id=? AND status='completed' AND completed_at>=?",
      )
      .bind(user.userId, berlinDayStart())
      .first();
    const vehicles = await db()
      .prepare(
        "SELECT v.*,d.id AS driver_id,d.name AS driver_name,d.online FROM mobility_vehicles v JOIN mobility_employees e ON e.fleet_id=v.fleet_id LEFT JOIN mobility_drivers d ON d.vehicle_id=v.id WHERE e.user_id=? AND v.status='active' ORDER BY v.model,v.plate",
      )
      .bind(user.userId)
      .all();
    const membership = await db()
      .prepare(
        'SELECT f.id,f.name FROM mobility_employees e JOIN mobility_fleets f ON f.id=e.fleet_id WHERE e.user_id=?',
      )
      .bind(user.userId)
      .first();
    const vehicleRequired = true;
    const offers = await db()
      .prepare(
        "SELECT o.id,o.expires_at,b.id AS booking_id FROM mobility_offers o JOIN mobility_bookings b ON b.id=o.booking_id WHERE o.driver_id=? AND o.status='pending' AND o.expires_at>? AND b.status='requesting'",
      )
      .bind(user.userId, Date.now())
      .all<{ id: string; expires_at: number; booking_id: string }>();
    return json({
      driver,
      inventory: await stockReminder(driver.vehicle_id || null),
      today,
      todaySince: berlinDayStart(),
      vehicles: vehicles.results,
      vehicleRequired,
      fleet: membership,
      payments: await Promise.all(payments.results.map(hydrate)),
      history: await Promise.all(history.results.map(hydrate)),
      revenue,
      bookings: await Promise.all(bookings.results.map(hydrate)),
      offers: await Promise.all(
        offers.results.map(async (o) => ({
          id: o.id,
          expires_at: o.expires_at,
          booking: await hydrate(
            (await db()
              .prepare('SELECT * FROM mobility_bookings WHERE id=?')
              .bind(o.booking_id)
              .first())!,
          ),
        })),
      ),
      serverTime: Date.now(),
    });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    const b = await body(request);
    const now = Date.now();
    if (b.action === 'register') {
      let services;
      try {
        services = parseServices(
          b.services ?? (b.service ? [b.service] : ['premium']),
        );
      } catch {
        throw new ApiError(
          400,
          'Bitte mindestens eine gültige Fahrzeugklasse wählen.',
        );
      }
      const busy = await db()
        .prepare(
          `SELECT id FROM mobility_drivers WHERE id=? AND NOT (${driverIdle('mobility_drivers')})`,
        )
        .bind(user.userId)
        .first();
      if (busy)
        throw new ApiError(
          409,
          'Profil erst offline, nach Fahrtabschluss und Kassieren ändern.',
        );
      const phone = text(b.phone, 30);
      if (!/^\+?[\d\s()-]{6,30}$/.test(phone))
        throw new ApiError(400, 'Bitte eine gültige Telefonnummer angeben.');
      const registered = await db().batch([
        db()
          .prepare(
            `INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,services,approved,online) VALUES(?,?,?,?,?,?,?,0,0) ON CONFLICT(id) DO UPDATE SET name=excluded.name,phone=excluded.phone,approved=0 WHERE ${driverIdle('mobility_drivers')}`,
          )
          .bind(
            user.userId,
            text(b.name, 80),
            phone,
            typeof b.vehicle === 'string' ? b.vehicle.trim().slice(0, 80) : '',
            typeof b.plate === 'string' ? b.plate.trim().slice(0, 20) : '',
            services[0],
            JSON.stringify(services),
          ),
        db()
          .prepare(
            "UPDATE mobility_offers SET status='withdrawn' WHERE driver_id=? AND status='pending' AND changes()>0",
          )
          .bind(user.userId),
      ]);
      if (!registered[0].meta.changes)
        throw new ApiError(
          409,
          'Deine Schicht wurde zwischenzeitlich gestartet. Bitte zuerst offline gehen.',
        );
      await db()
        .prepare('UPDATE mobility_employees SET name=?,phone=? WHERE user_id=?')
        .bind(text(b.name, 80), phone, user.userId)
        .run();
      return json({ ok: true });
    }
    const driver = await db()
      .prepare('SELECT * FROM mobility_drivers WHERE id=? AND approved=1')
      .bind(user.userId)
      .first<Driver>();
    if (!driver)
      throw new ApiError(
        403,
        'Dein Fahrerprofil muss zuerst von der Disposition freigegeben werden.',
      );
    if (b.action === 'online') {
      const sessionId = crypto.randomUUID();
      const nativeToken =
        b.native === true
          ? (crypto.randomUUID() + crypto.randomUUID()).replaceAll('-', '')
          : null;
      const expiresAt = now + 24 * 60 * 60 * 1000;
      // Finish asynchronous credential preparation before changing the shift.
      // Session rotation and its native credential must commit together: a
      // failed insert or another start cannot orphan the current GPS session.
      const hash = nativeToken ? await tokenHash(nativeToken) : null;
      const start = db()
        .prepare(
          `UPDATE mobility_drivers SET online=0,lat=NULL,lng=NULL,location_at=NULL,session_id=? WHERE id=? AND approved=1 AND ${vehicleEligible('mobility_drivers')}`,
        )
        .bind(sessionId, user.userId);
      const statements = [
        start,
        db()
          .prepare(
            'DELETE FROM mobility_location_sessions WHERE (driver_id=? OR expires_at<=?) AND EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND session_id=?)',
          )
          .bind(user.userId, now, user.userId, sessionId),
      ];
      if (hash)
        statements.push(
          db()
            .prepare(
              'INSERT INTO mobility_location_sessions(token_hash,driver_id,session_id,expires_at) SELECT ?,?,?,? WHERE EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND session_id=?)',
            )
            .bind(
              hash,
              user.userId,
              sessionId,
              expiresAt,
              user.userId,
              sessionId,
            ),
        );
      const started = await db().batch(statements);
      if (!started[0].meta.changes)
        throw new ApiError(
          409,
          'Bitte zuerst ein aktives Fahrzeug deiner Flotte wählen.',
        );
      if (nativeToken) {
        return json({ sessionId, nativeToken, expiresAt });
      }
      return json({ sessionId });
    }
    if (b.action === 'heartbeat') {
      if (b.timestamp !== undefined && !freshLocation(b, now))
        throw new ApiError(
          400,
          'Der GPS-Standort ist veraltet oder ungenau. Bitte Standort aktualisieren.',
        );
      if (
        !coordinate(b.lat, b.lng) ||
        typeof b.accuracy !== 'number' ||
        !Number.isFinite(b.accuracy) ||
        b.accuracy < 0 ||
        b.accuracy > 100
      )
        throw new ApiError(
          400,
          'Der Standort ist zu ungenau. Bitte GPS aktivieren und erneut versuchen.',
        );
      const saved = await db()
        .prepare(
          `UPDATE mobility_drivers SET lat=?,lng=?,accuracy=?,location_at=?,online=1 WHERE id=? AND approved=1 AND session_id=? AND ${vehicleEligible('mobility_drivers')}`,
        )
        .bind(b.lat, b.lng, b.accuracy, now, user.userId, text(b.sessionId))
        .run();
      if (!saved.meta.changes)
        throw new ApiError(
          409,
          'Diese Standortfreigabe ist beendet. Bitte erneut online gehen.',
        );
      await dispatch(db(), now);
      return json({ ok: true, at: now });
    }
    if (b.action === 'offline') {
      await db().batch([
        db()
          .prepare(
            'UPDATE mobility_drivers SET online=0,session_id=NULL WHERE id=? AND session_id=?',
          )
          .bind(user.userId, text(b.sessionId)),
        db()
          .prepare(
            "UPDATE mobility_offers SET status='rejected' WHERE driver_id=? AND status='pending' AND EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND online=0)",
          )
          .bind(user.userId, user.userId),
      ]);
      await dispatch(db(), now);
      return json({ ok: true });
    }
    if (b.action === 'accept') {
      if (!(await accept(db(), text(b.offerId), user.userId, now)))
        throw new ApiError(
          409,
          'Das Angebot ist abgelaufen oder bereits vergeben.',
        );
      return json({ ok: true });
    }
    if (b.action === 'reject') {
      const result = await db()
        .prepare(
          "UPDATE mobility_offers SET status='rejected' WHERE id=? AND driver_id=? AND status='pending' AND expires_at>?",
        )
        .bind(text(b.offerId), user.userId, now)
        .run();
      if (!result.meta.changes)
        throw new ApiError(409, 'Das Angebot ist nicht mehr verfügbar.');
      await dispatch(db(), now);
      return json({ ok: true });
    }
    if (b.action === 'status') {
      if (
        typeof b.from !== 'string' ||
        typeof b.status !== 'string' ||
        driverNext[b.from as BookingStatus] !== b.status
      )
        throw new ApiError(400, 'Dieser Statuswechsel ist nicht erlaubt.');
      const id = text(b.id);
      const r = await db().batch([
        db()
          .prepare(
            "UPDATE mobility_bookings SET status=?,updated_at=?,completed_at=CASE WHEN ?='completed' THEN ? ELSE completed_at END WHERE id=? AND driver_id=? AND status=?",
          )
          .bind(b.status, now, b.status, now, id, user.userId, b.from),
        db()
          .prepare(
            'INSERT INTO mobility_events(id,booking_id,actor_id,action,created_at) SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM mobility_bookings WHERE id=? AND driver_id=? AND status=? AND updated_at=?)',
          )
          .bind(
            crypto.randomUUID(),
            id,
            user.userId,
            b.status,
            now,
            id,
            user.userId,
            b.status,
            now,
          ),
      ]);
      if (!r[0].meta.changes)
        throw new ApiError(
          409,
          'Die Fahrt wurde bereits geändert. Bitte aktualisieren.',
        );
      return json({ ok: true });
    }
    throw new ApiError(400, 'Unbekannte Fahreraktion.');
  });
}
