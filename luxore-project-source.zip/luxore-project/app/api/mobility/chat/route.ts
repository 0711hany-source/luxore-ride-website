import {
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import {
  CHAT_RATE_PER_MINUTE,
  chatMessages,
  parseChatAfter,
  parseChatBody,
  sendChatMessage,
} from '@/lib/mobility/chat';

/**
 * GET ?bookingId=…&after=<created_at> → { serverTime, open, messages }.
 * Only the customer and the driver of the ride, only while it is accepted,
 * arrived or riding; otherwise the list is empty.
 */
export async function GET(request: Request) {
  return handled(async () => {
    const user = await identity();
    const params = new URL(request.url).searchParams;
    return json(
      await chatMessages(
        db(),
        user.userId,
        text(params.get('bookingId'), 60),
        parseChatAfter(params.get('after')),
      ),
    );
  });
}
/** { bookingId, body: 1–500 characters } — the side follows from the ride. */
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    const b = await body(request);
    const bookingId = text(b.bookingId, 60);
    const message = parseChatBody(b.body);
    await limit(user.userId, 'chat', CHAT_RATE_PER_MINUTE);
    return json(
      {
        ok: true,
        message: await sendChatMessage(db(), user.userId, bookingId, message),
      },
      201,
    );
  });
}
