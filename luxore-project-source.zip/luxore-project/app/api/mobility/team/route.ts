import {
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
  ApiError,
} from '@/lib/mobility/server';
export async function GET() {
  return handled(async () => {
    const u = await identity();
    return json({
      employee: await db()
        .prepare(
          'SELECT e.*,f.name AS fleet_name FROM mobility_employees e LEFT JOIN mobility_fleets f ON f.id=e.fleet_id WHERE e.user_id=?',
        )
        .bind(u.userId)
        .first(),
    });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const u = await identity(request);
    await limit(u.userId, 'team', 5);
    const b = await body(request);
    const phone = text(b.phone, 30);
    if (!/^\+?[\d\s()-]{6,30}$/.test(phone))
      throw new ApiError(400, 'Ungültige Telefonnummer.');
    await db()
      .prepare(
        "INSERT INTO mobility_employees(user_id,name,phone,role,created_at) VALUES(?,?,?,'staff',?) ON CONFLICT(user_id) DO UPDATE SET name=excluded.name,phone=excluded.phone",
      )
      .bind(u.userId, text(b.name, 80), phone, Date.now())
      .run();
    return json({ ok: true });
  });
}
