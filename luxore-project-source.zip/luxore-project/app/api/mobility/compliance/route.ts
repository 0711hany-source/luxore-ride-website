import {
  ApiError,
  body,
  db,
  handled,
  identity,
  isAdmin,
  json,
  limit,
} from '@/lib/mobility/server';
import { operatorScope } from '@/lib/mobility/fleets';
import { audit } from '@/lib/mobility/accounts';
import { berlinDate } from '@/lib/mobility/settlement';
import {
  driverCompliance,
  enforcedSince,
  setEnforcement,
  subjectPapers,
  vehicleInspection,
  type SuspensionRow,
} from '@/lib/mobility/compliance';

export async function GET(request: Request) {
  return handled(async () => {
    const user = await identity();
    const params = new URL(request.url).searchParams;
    const view = params.get('scope');
    const now = Date.now(),
      today = berlinDate(now);
    if (!view) {
      // The caller's own state as a driver; never anyone else's.
      const driver = await db()
        .prepare('SELECT id FROM mobility_drivers WHERE id=?')
        .bind(user.userId)
        .first();
      return json({
        enforcedSince: await enforcedSince(db()),
        driver: driver ? await driverCompliance(db(), user.userId, now) : null,
        papers: driver
          ? await subjectPapers(db(), 'driver', user.userId, today)
          : [],
      });
    }
    const scope = await operatorScope(user);
    if (view === 'operator') {
      if (!isAdmin(user))
        throw new ApiError(
          403,
          'Dieser Bereich ist ausschließlich für den Betreiber freigegeben.',
        );
      const counts = await db()
        .prepare(
          `SELECT
          (SELECT COUNT(*) FROM mobility_documents WHERE status='submitted') AS review,
          (SELECT COUNT(*) FROM mobility_fleet_applications WHERE status='submitted') AS applications,
          (SELECT COUNT(*) FROM mobility_suspensions WHERE lifted_at IS NULL) AS suspensions`,
        )
        .first<Record<string, number>>();
      // Vehicles whose most recent check reported a defect.
      const defects = await db()
        .prepare(
          `SELECT i.id,i.vehicle_id,i.items,i.inspector_name,i.created_at,v.model,v.plate,f.id AS fleet_id,f.name AS fleet_name,
           EXISTS(SELECT 1 FROM mobility_suspensions s WHERE s.subject_type='vehicle' AND s.subject_id=v.id AND s.lifted_at IS NULL) AS suspended
           FROM mobility_inspections i JOIN mobility_vehicles v ON v.id=i.vehicle_id AND v.status='active' LEFT JOIN mobility_fleets f ON f.id=v.fleet_id
           WHERE i.result='defect' AND i.created_at=(SELECT MAX(created_at) FROM mobility_inspections WHERE vehicle_id=i.vehicle_id)
           ORDER BY i.created_at DESC LIMIT 50`,
        )
        .all<{ items: string }>();
      const fleets = await db()
        .prepare('SELECT id,name FROM mobility_fleets ORDER BY name')
        .all();
      return json({
        enforcedSince: await enforcedSince(db()),
        counts: { ...counts, defects: defects.results.length },
        defects: defects.results.map((d) => ({
          ...d,
          items: JSON.parse(d.items),
        })),
        fleets: fleets.results,
      });
    }
    if (view !== 'fleet') throw new ApiError(400, 'Ungültige Anfrage.');
    if (!scope)
      throw new ApiError(403, 'Nur die Flottenleitung hat Zugriff.');
    const requested = params.get('fleetId');
    if (requested && scope !== 'all' && requested !== scope)
      throw new ApiError(403, 'Diese Flotte gehört nicht zu deinem Zugang.');
    const fleetId = requested || (scope === 'all' ? null : scope);
    const fleet = fleetId
      ? await db()
          .prepare('SELECT id,name FROM mobility_fleets WHERE id=?')
          .bind(fleetId)
          .first<{ id: string; name: string }>()
      : null;
    if (!fleet) throw new ApiError(404, 'Flotte nicht gefunden.');
    const [vehicles, drivers, holds] = await Promise.all([
      db()
        .prepare(
          "SELECT id,model,plate FROM mobility_vehicles WHERE fleet_id=? AND status='active' ORDER BY model,plate",
        )
        .bind(fleet.id)
        .all<{ id: string; model: string; plate: string }>(),
      db()
        .prepare(
          'SELECT d.id,d.name,d.approved,d.online FROM mobility_drivers d JOIN mobility_employees e ON e.user_id=d.id WHERE e.fleet_id=? ORDER BY d.name',
        )
        .bind(fleet.id)
        .all<{ id: string; name: string; approved: number; online: number }>(),
      db()
        .prepare(
          "SELECT * FROM mobility_suspensions WHERE lifted_at IS NULL AND (fleet_id=? OR (subject_type='fleet' AND subject_id=?)) ORDER BY created_at",
        )
        .bind(fleet.id, fleet.id)
        .all<SuspensionRow>(),
    ]);
    const held = (type: string, id: string) =>
      holds.results
        .filter((s) => s.subject_type === type && s.subject_id === id)
        .map((s) => ({
          id: s.id,
          level: s.level,
          reason: s.reason,
          by: s.created_by_name,
          at: s.created_at,
        }));
    return json({
      enforcedSince: await enforcedSince(db()),
      operator: scope === 'all',
      fleet: {
        ...fleet,
        papers: await subjectPapers(db(), 'fleet', fleet.id, today),
        suspensions: held('fleet', fleet.id),
      },
      vehicles: await Promise.all(
        vehicles.results.map(async (v) => ({
          ...v,
          papers: await subjectPapers(db(), 'vehicle', v.id, today),
          inspection: await vehicleInspection(db(), v.id, now),
          suspensions: held('vehicle', v.id),
        })),
      ),
      drivers: await Promise.all(
        drivers.results.map(async (d) => ({
          ...d,
          papers: await subjectPapers(db(), 'driver', d.id, today),
          suspensions: held('driver', d.id),
        })),
      ),
    });
  });
}
/** The operator alone switches enforcement on or off. */
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    if (!isAdmin(user))
      throw new ApiError(
        403,
        'Die Prüfpflicht schaltet ausschließlich der Betreiber.',
      );
    await limit(user.userId, 'compliance-write', 10);
    const b = await body(request);
    if (b.action !== 'enforcement' || typeof b.enabled !== 'boolean')
      throw new ApiError(400, 'Unbekannte Aktion.');
    const current = await enforcedSince(db());
    // Switching on twice keeps the original start date.
    if (b.enabled !== Boolean(current)) {
      await setEnforcement(db(), b.enabled, user.userId);
      await audit(
        user.userId,
        user.userId,
        b.enabled ? 'compliance.enforcement_on' : 'compliance.enforcement_off',
        db,
      );
    }
    return json({ ok: true, enforcedSince: await enforcedSince(db()) });
  });
}
