import {
  body,
  handled,
  identity,
  json,
  db,
  limit,
  ApiError,
  text,
} from '@/lib/mobility/server';
import { geocode } from '@/lib/mobility/provider';
import { permanentGeocode } from '@/lib/mobility/geocoding-cache';
import { selectedGeocode } from '@/lib/mobility/geocoding-policy';
import { coordinate } from '@/lib/mobility/domain';
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit('public', 'public-places', 300);
    await limit(user.userId, 'places');
    const b = await body(request);
    let query: string | { lat: number; lng: number };
    if (b.kind === 'location' || b.kind === 'pin') {
      if (!coordinate(b.lat, b.lng))
        throw new ApiError(400, 'Ungültiger Standort.');
      query = { lat: b.lat, lng: b.lng as number };
    } else {
      query = text(b.query, 256);
      if (query.length < 3)
        throw new ApiError(400, 'Bitte mindestens drei Zeichen eingeben.');
    }
    if (b.kind === 'selected' && !coordinate(b.lat, b.lng))
      throw new ApiError(400, 'Ungültige Adressauswahl.');
    const preview = b.kind === 'search';
    if (preview) {
      const allowed = await db()
        .prepare(
          'INSERT INTO mobility_limits(key,count) VALUES(?,1) ON CONFLICT(key) DO UPDATE SET count=count+1 WHERE count < 2000 RETURNING count',
        )
        .bind(`geocode-search:${Math.floor(Date.now() / 86400000)}`)
        .first();
      if (!allowed)
        throw new ApiError(
          429,
          'Das tägliche Suchkontingent ist ausgeschöpft. Bereits gespeicherte Ziele bleiben verfügbar.',
        );
    }
    let points = preview ? await geocode(query) : await permanentGeocode(query);
    if (b.kind === 'selected') {
      const selected = selectedGeocode(points, {
        lat: b.lat as number,
        lng: b.lng as number,
      });
      if (!selected)
        throw new ApiError(
          409,
          'Die Adresse hat sich geändert. Bitte erneut suchen und auswählen.',
        );
      points = [selected];
    }
    const results = points.map((p) => ({
      ...p,
      ...(b.kind === 'pin'
        ? {
            lat: b.lat as number,
            lng: b.lng as number,
            label: 'Gewählter Punkt · ' + p.label,
          }
        : {}),
      id: crypto.randomUUID(),
    }));
    // Temporary suggestions stay in the open UI only: never persist them.
    if (!preview && results.length)
      await db().batch(
        results.map((p) =>
          db()
            .prepare(
              'INSERT INTO mobility_places(id,owner_id,label,lat,lng,created_at) VALUES(?,?,?,?,?,?)',
            )
            .bind(p.id, user.userId, p.label, p.lat, p.lng, Date.now()),
        ),
      );
    return json({ results });
  });
}
