import {
  body,
  handled,
  identity,
  json,
  db,
  limit,
  ApiError,
  text,
  settings,
} from '@/lib/mobility/server';
import { bookingGeocode } from '@/lib/mobility/geocoding-provider';
import {
  selectedGeocode,
  permanentDailyLimit,
} from '@/lib/mobility/geocoding-policy';
import { coordinate, type Point } from '@/lib/mobility/domain';
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit('public', 'public-places', 300);
    await limit(user.userId, 'places');
    const b = await body(request);
    let query: string | { lat: number; lng: number };
    if (b.kind === 'location' || b.kind === 'pin') {
      if (!coordinate(b.lat, b.lng))
        throw new ApiError(400, 'Ungültiger Standort.');
      query = { lat: b.lat, lng: b.lng as number };
    } else {
      query = text(b.query, 256);
      if (query.length < 3)
        throw new ApiError(400, 'Bitte mindestens drei Zeichen eingeben.');
    }
    if (b.kind === 'selected' && !coordinate(b.lat, b.lng))
      throw new ApiError(400, 'Ungültige Adressauswahl.');
    const preview = b.kind === 'search';
    if (preview) {
      const allowed = await db()
        .prepare(
          'INSERT INTO mobility_limits(key,count) VALUES(?,1) ON CONFLICT(key) DO UPDATE SET count=count+1 WHERE count < 2000 RETURNING count',
        )
        .bind(`geocode-search:${Math.floor(Date.now() / 86400000)}`)
        .first();
      if (!allowed)
        throw new ApiError(
          429,
          'Das tägliche Suchkontingent ist ausgeschöpft. Bereits gespeicherte Ziele bleiben verfügbar.',
        );
    }
    // Device/map-pin coordinates are supplied directly by the user. Their own
    // generic label is not a temporary provider result and needs no geocoding.
    const ownCoordinate = b.kind === 'pin' || b.kind === 'location';
    const coordinateOnly =
      ownCoordinate &&
      !settings().GEOAPIFY_API_KEY &&
      !permanentDailyLimit(settings().MAPBOX_PERMANENT_DAILY_LIMIT);
    const coordinatePoint = (): Omit<Point, 'id'>[] => [
      {
        lat: b.lat as number,
        lng: b.lng as number,
        label: b.kind === 'pin' ? 'Punkt auf Karte' : 'Aktueller Standort',
      },
    ];
    let points: Omit<Point, 'id'>[];
    try {
      points = coordinateOnly
        ? coordinatePoint()
        : await bookingGeocode(query, preview);
    } catch (error) {
      // Reverse geocoding only supplies an optional address for an already
      // chosen coordinate. Provider outages/quota must not disable map/GPS
      // selection too. Authentication, endpoint limits, lease conflicts and
      // unexpected database failures are not recovered here.
      if (
        !ownCoordinate ||
        !(error instanceof ApiError) ||
        ![429, 502, 503, 504].includes(error.status)
      )
        throw error;
      points = coordinatePoint();
    }
    if (ownCoordinate && !points.length) points = coordinatePoint();
    if (b.kind === 'selected') {
      const selected = selectedGeocode(points, {
        lat: b.lat as number,
        lng: b.lng as number,
      });
      if (!selected)
        throw new ApiError(
          409,
          'Die Adresse hat sich geändert. Bitte erneut suchen und auswählen.',
        );
      points = [selected];
    }
    const results = points.map((p) => ({
      ...p,
      ...(b.kind === 'pin'
        ? {
            lat: b.lat as number,
            lng: b.lng as number,
            label: 'Gewählter Punkt · ' + p.label,
          }
        : {}),
      id: crypto.randomUUID(),
    }));
    // Temporary suggestions stay in the open UI only: never persist them.
    if (!preview && results.length)
      await db().batch(
        results.map((p) =>
          db()
            .prepare(
              'INSERT INTO mobility_places(id,owner_id,label,lat,lng,created_at,attribution) VALUES(?,?,?,?,?,?,?)',
            )
            .bind(
              p.id,
              user.userId,
              p.label,
              p.lat,
              p.lng,
              Date.now(),
              'attribution' in p ? p.attribution : null,
            ),
        ),
      );
    return json({ results });
  });
}
