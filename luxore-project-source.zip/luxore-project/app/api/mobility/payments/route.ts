import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import { collect } from '@/lib/mobility/payments';
export async function POST(request: Request) {
  return handled(async () => {
    const u = await identity(request);
    await limit(u.userId, 'payment', 15);
    const b = await body(request);
    if (b.method !== 'cash' && b.method !== 'terminal')
      throw new ApiError(
        400,
        'Bitte Barzahlung oder separates Kartenterminal wählen.',
      );
    if (!(await collect(db(), text(b.id), u.userId, b.method)))
      throw new ApiError(
        409,
        'Zahlung kann für diese Fahrt nicht bestätigt werden.',
      );
    return json({ ok: true });
  });
}
