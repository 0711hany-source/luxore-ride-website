import { driverIdle } from '@/lib/mobility/vehicles';
import { berlinDayStart } from '@/lib/mobility/time';
import {
  ApiError,
  body,
  db,
  handled,
  identity,
  isAdmin,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import {
  assignFleetMember,
  removeFleetMember,
} from '@/lib/mobility/fleet-membership';
import { operatorScope } from '@/lib/mobility/fleets';
import { createFleetInvite, joinFleet } from '@/lib/mobility/fleet-invites';
import {
  changeDeputy,
  transferFleetOwner,
} from '@/lib/mobility/fleet-leadership';
export async function GET(request: Request) {
  return handled(async () => {
    const user = await identity();
    const scope = await operatorScope(user);
    if (!scope) throw new ApiError(403, 'Nur die Disposition hat Zugriff.');
    const fleets = await db()
      .prepare(
        "SELECT * FROM mobility_fleets WHERE ?='all' OR id=? ORDER BY name",
      )
      .bind(scope, scope)
      .all();
    const employees = await db()
      .prepare(
        `SELECT e.*,d.id AS driver_id,d.approved,d.online,d.vehicle_id,d.plate,CASE WHEN d.id IS NULL OR (${driverIdle('d')}) THEN 1 ELSE 0 END AS can_remove FROM mobility_employees e LEFT JOIN mobility_drivers d ON d.id=e.user_id WHERE ?='all' OR e.fleet_id=? ORDER BY e.name`,
      )
      .bind(scope, scope)
      .all();
    // Existing driver profiles can be assigned without changing their driver approval.
    const unassigned =
      scope === 'all'
        ? await db()
            .prepare(
              "SELECT id AS user_id,name,phone,NULL AS fleet_id,'driver' AS role FROM mobility_drivers WHERE id NOT IN (SELECT user_id FROM mobility_employees)",
            )
            .all()
        : { results: [] };
    const period = new URL(request.url).searchParams.get('period') || 'all';
    if (!['today', '7', '30', 'all'].includes(period))
      throw new ApiError(400, 'Ungültiger Zeitraum.');
    const since =
      period === 'all'
        ? 0
        : period === 'today'
          ? berlinDayStart()
          : Date.now() - Number(period) * 86400000;
    const revenue = await db()
      .prepare(
        "SELECT b.fleet_id,b.driver_id,COALESCE(d.name,'Fahrer') AS driver_name,COUNT(*) AS trips,COALESCE(SUM(b.price),0) AS gross,COALESCE(SUM(CASE WHEN b.payment_status='paid' THEN b.price ELSE 0 END),0) AS collected,COALESCE(SUM(CASE WHEN b.payment_status='unpaid' THEN b.price ELSE 0 END),0) AS outstanding FROM mobility_bookings b LEFT JOIN mobility_drivers d ON d.id=b.driver_id WHERE b.status='completed' AND b.completed_at>=? AND (?='all' OR b.fleet_id=?) GROUP BY b.fleet_id,b.driver_id ORDER BY gross DESC",
      )
      .bind(since, scope, scope)
      .all();
    return json({
      revenue: revenue.results,
      fleets: fleets.results,
      employees: [...employees.results, ...unassigned.results],
      canManage: isAdmin(user),
      userId: user.userId,
    });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit(user.userId, 'fleet-write', 30);
    const b = await body(request);
    if (b.action === 'join')
      return json(await joinFleet(user.userId, text(b.code, 50).toUpperCase()));
    const scope = await operatorScope(user);
    if (!scope) throw new ApiError(403, 'Nur die Flottenleitung hat Zugriff.');
    if (b.action === 'rename') {
      const fleetId = text(b.fleetId),
        name = text(b.name, 100);
      const result = await db()
        .prepare(
          'UPDATE mobility_fleets SET name=? WHERE id=? AND (owner_id=? OR ?=1)',
        )
        .bind(name, fleetId, user.userId, Number(isAdmin(user)))
        .run();
      if (!result.meta.changes)
        throw new ApiError(
          403,
          'Nur der Besitzer darf den Flottennamen ändern.',
        );
      return json({ ok: true });
    }
    if (b.action === 'remove_member') {
      await removeFleetMember(user, text(b.fleetId), text(b.userId));
      return json({ ok: true });
    }
    if (b.action === 'invite_driver') {
      return json(await createFleetInvite(user.userId, text(b.fleetId, 60)));
    }
    if (b.action === 'deputy') {
      const fleetId = text(b.fleetId);
      const deputyId = b.deputyId === null ? null : text(b.deputyId);
      await changeDeputy(user, fleetId, deputyId);
      return json({ ok: true });
    }
    if (!isAdmin(user))
      throw new ApiError(
        403,
        'Flotten und Zuordnungen verwaltet der Plattformbetreiber.',
      );
    if (b.action === 'transfer_owner') {
      const fleetId = text(b.fleetId),
        previous = text(b.previousOwnerId),
        next = text(b.ownerId);
      if (previous === next || b.confirmed !== true)
        throw new ApiError(
          400,
          'Bitte einen neuen Besitzer wählen und die Übergabe bestätigen.',
        );
      await transferFleetOwner(user, fleetId, previous, next);
      return json({ ok: true });
    }
    if (b.action === 'create') {
      const name = text(b.name, 100);
      const id =
        b.requestId === undefined ? crypto.randomUUID() : text(b.requestId, 36);
      if (
        !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(
          id,
        )
      )
        throw new ApiError(
          400,
          'Ungültige Speicheranfrage. Bitte die Flottenansicht neu öffnen.',
        );
      const ownerId = b.ownerId ? text(b.ownerId) : user.userId;
      const readExisting = () =>
        db()
          .prepare('SELECT id,name,owner_id FROM mobility_fleets WHERE id=?')
          .bind(id)
          .first<{ id: string; name: string; owner_id: string }>();
      const matches = (record: Awaited<ReturnType<typeof readExisting>>) =>
        record?.owner_id === ownerId && record.name === name;
      const existing = await readExisting();
      if (existing) {
        if (matches(existing)) return json({ id, name, replayed: true });
        throw new ApiError(
          409,
          'Diese Speicheranfrage wurde bereits verarbeitet. Bitte die Flottenansicht aktualisieren.',
        );
      }
      const owner =
        ownerId === user.userId
          ? { name: user.displayName, phone: '' }
          : await db()
              .prepare(
                'SELECT name,phone FROM mobility_employees WHERE user_id=? UNION ALL SELECT name,phone FROM mobility_drivers WHERE id=? LIMIT 1',
              )
              .bind(ownerId, ownerId)
              .first<{ name: string; phone: string }>();
      if (!owner)
        throw new ApiError(
          404,
          'Besitzer muss zuerst ein Mitarbeiter- oder Fahrerprofil einreichen.',
        );
      const created = await db().batch([
        db()
          .prepare(
            `INSERT OR IGNORE INTO mobility_fleets(id,name,owner_id,created_at) SELECT ?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM mobility_employees WHERE user_id=? AND fleet_id IS NOT NULL) AND NOT EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND NOT (${driverIdle('mobility_drivers')}))`,
          )
          .bind(id, name, ownerId, Date.now(), ownerId, ownerId),
        db()
          .prepare(
            "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) SELECT ?,?,?,?,'staff',? WHERE changes()>0 AND EXISTS(SELECT 1 FROM mobility_fleets WHERE id=? AND owner_id=?) ON CONFLICT(user_id) DO UPDATE SET fleet_id=excluded.fleet_id",
          )
          .bind(ownerId, owner.name, owner.phone, id, Date.now(), id, ownerId),
      ]);
      if (!created[0].meta.changes) {
        // A competing retry may have committed between the first read and this transaction.
        if (matches(await readExisting()))
          return json({ id, name, replayed: true });
        throw new ApiError(
          409,
          'Besitzer bereits zugeordnet oder noch im Einsatz. Bitte zuerst offline gehen und offene Fahrten abrechnen.',
        );
      }
      return json({ id, name }, 201);
    }
    if (b.action === 'assign') {
      const id = text(b.userId);
      const fleetId = b.fleetId === null ? null : text(b.fleetId);
      if (b.role !== 'staff' && b.role !== 'driver')
        throw new ApiError(400, 'Ungültige Rolle.');
      await assignFleetMember(user, id, fleetId, b.role);
      return json({ ok: true });
    }
    throw new ApiError(400, 'Unbekannte Flottenaktion.');
  });
}
