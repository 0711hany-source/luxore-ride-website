import { driverIdle } from '@/lib/mobility/vehicles';
import { berlinDayStart } from '@/lib/mobility/time';
import {
  ApiError,
  body,
  db,
  handled,
  identity,
  isAdmin,
  json,
  limit,
  text,
  tokenHash,
} from '@/lib/mobility/server';
import { operatorScope } from '@/lib/mobility/fleets';
import { joinFleet } from '@/lib/mobility/fleet-invites';
import { audit } from '@/lib/mobility/accounts';
export async function GET(request: Request) {
  return handled(async () => {
    const user = await identity();
    const scope = await operatorScope(user);
    if (!scope) throw new ApiError(403, 'Nur die Disposition hat Zugriff.');
    const fleets = await db()
      .prepare(
        "SELECT * FROM mobility_fleets WHERE ?='all' OR id=? ORDER BY name",
      )
      .bind(scope, scope)
      .all();
    const employees = await db()
      .prepare(
        `SELECT e.*,d.id AS driver_id,d.approved,d.online,d.vehicle_id,d.plate,CASE WHEN d.id IS NULL OR (${driverIdle('d')}) THEN 1 ELSE 0 END AS can_remove FROM mobility_employees e LEFT JOIN mobility_drivers d ON d.id=e.user_id WHERE ?='all' OR e.fleet_id=? ORDER BY e.name`,
      )
      .bind(scope, scope)
      .all();
    // Existing driver profiles can be assigned without changing their driver approval.
    const unassigned =
      scope === 'all'
        ? await db()
            .prepare(
              "SELECT id AS user_id,name,phone,NULL AS fleet_id,'driver' AS role FROM mobility_drivers WHERE id NOT IN (SELECT user_id FROM mobility_employees)",
            )
            .all()
        : { results: [] };
    const period = new URL(request.url).searchParams.get('period') || 'all';
    if (!['today', '7', '30', 'all'].includes(period))
      throw new ApiError(400, 'Ungültiger Zeitraum.');
    const since =
      period === 'all'
        ? 0
        : period === 'today'
          ? berlinDayStart()
          : Date.now() - Number(period) * 86400000;
    const revenue = await db()
      .prepare(
        "SELECT b.fleet_id,b.driver_id,COALESCE(d.name,'Fahrer') AS driver_name,COUNT(*) AS trips,COALESCE(SUM(b.price),0) AS gross,COALESCE(SUM(CASE WHEN b.payment_status='paid' THEN b.price ELSE 0 END),0) AS collected,COALESCE(SUM(CASE WHEN b.payment_status='unpaid' THEN b.price ELSE 0 END),0) AS outstanding FROM mobility_bookings b LEFT JOIN mobility_drivers d ON d.id=b.driver_id WHERE b.status='completed' AND b.completed_at>=? AND (?='all' OR b.fleet_id=?) GROUP BY b.fleet_id,b.driver_id ORDER BY gross DESC",
      )
      .bind(since, scope, scope)
      .all();
    return json({
      revenue: revenue.results,
      fleets: fleets.results,
      employees: [...employees.results, ...unassigned.results],
      canManage: isAdmin(user),
      userId: user.userId,
    });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit(user.userId, 'fleet-write', 30);
    const b = await body(request);
    if (b.action === 'join')
      return json(await joinFleet(user.userId, text(b.code, 50).toUpperCase()));
    const scope = await operatorScope(user);
    if (!scope) throw new ApiError(403, 'Nur die Flottenleitung hat Zugriff.');
    if (b.action === 'rename') {
      const fleetId = text(b.fleetId),
        name = text(b.name, 100);
      const result = await db()
        .prepare(
          'UPDATE mobility_fleets SET name=? WHERE id=? AND (owner_id=? OR ?=1)',
        )
        .bind(name, fleetId, user.userId, Number(isAdmin(user)))
        .run();
      if (!result.meta.changes)
        throw new ApiError(
          403,
          'Nur der Besitzer darf den Flottennamen ändern.',
        );
      return json({ ok: true });
    }
    if (b.action === 'remove_member') {
      const fleetId = text(b.fleetId),
        id = text(b.userId);
      if (scope !== 'all' && scope !== fleetId)
        throw new ApiError(403, 'Diese Flotte gehört nicht zu deinem Zugang.');
      const results = await db().batch([
        db()
          .prepare(`UPDATE mobility_employees SET fleet_id=NULL WHERE user_id=? AND fleet_id=?
          AND NOT EXISTS(SELECT 1 FROM mobility_fleets f WHERE f.owner_id=mobility_employees.user_id OR f.deputy_id=mobility_employees.user_id)
          AND NOT EXISTS(SELECT 1 FROM mobility_drivers d WHERE d.id=mobility_employees.user_id AND NOT (${driverIdle('d')}))`)
          .bind(id, fleetId),
        db()
          .prepare(
            `UPDATE mobility_drivers SET approved=0,online=0,session_id=NULL,vehicle_id=NULL,vehicle='',plate='',services='[]' WHERE id=? AND changes()>0 AND ${driverIdle('mobility_drivers')}`,
          )
          .bind(id),
        db()
          .prepare(
            "UPDATE mobility_offers SET status='withdrawn' WHERE driver_id=? AND status='pending' AND changes()>0",
          )
          .bind(id),
      ]);
      if (!results[0].meta.changes)
        throw new ApiError(
          409,
          'Entfernen nicht möglich: Mitarbeiter nicht zugeordnet, noch im Einsatz oder Zahlung offen. Eine Stellvertretung muss zuerst aufgehoben werden; der Besitzer bleibt in seiner Flotte.',
        );
      return json({ ok: true });
    }
    if (b.action === 'invite_driver') {
      const fleetId = text(b.fleetId, 60);
      const fleet = await db()
        .prepare(
          'SELECT id,name,owner_id,deputy_id FROM mobility_fleets WHERE id=?',
        )
        .bind(fleetId)
        .first<{
          id: string;
          name: string;
          owner_id: string;
          deputy_id: string | null;
        }>();
      if (!fleet || ![fleet.owner_id, fleet.deputy_id].includes(user.userId))
        throw new ApiError(
          403,
          'Nur die Leitung dieser Flotte kann Einladungen ausstellen.',
        );
      const code =
        'LX-' + crypto.randomUUID().replaceAll('-', '').toUpperCase();
      const expiresAt = Date.now() + 86400000;
      await db().batch([
        db()
          .prepare('DELETE FROM mobility_fleet_invites WHERE expires_at<=?')
          .bind(Date.now()),
        db()
          .prepare(
            'INSERT INTO mobility_fleet_invites(token_hash,fleet_id,inviter_id,expires_at) VALUES(?,?,?,?)',
          )
          .bind(await tokenHash(code), fleetId, user.userId, expiresAt),
      ]);
      return json({
        ok: true,
        code,
        expiresAt,
        shareText: `Einladung zu ${fleet.name}\n\nCode: ${code}\n\n24 Stunden gültig. Öffne Luxóre Driver, lege dein Fahrerprofil an und wähle „Flotte beitreten“. Die Flottenleitung prüft und aktiviert anschließend dein Profil.`,
      });
    }
    if (b.action === 'deputy') {
      const fleetId = text(b.fleetId);
      const fleet = await db()
        .prepare('SELECT * FROM mobility_fleets WHERE id=?')
        .bind(fleetId)
        .first<{ owner_id: string }>();
      if (!fleet || (!isAdmin(user) && fleet.owner_id !== user.userId))
        throw new ApiError(
          403,
          'Nur der Flottenbesitzer darf die Stellvertretung bestimmen.',
        );
      const deputyId = b.deputyId === null ? null : text(b.deputyId);
      if (
        deputyId &&
        (deputyId === fleet.owner_id ||
          !(await db()
            .prepare(
              'SELECT user_id FROM mobility_employees WHERE user_id=? AND fleet_id=?',
            )
            .bind(deputyId, fleetId)
            .first()))
      )
        throw new ApiError(
          400,
          'Bitte einen anderen Mitarbeiter dieser Flotte auswählen.',
        );
      const changed = await db()
        .prepare(
          'UPDATE mobility_fleets SET deputy_id=? WHERE id=? AND (? IS NULL OR EXISTS(SELECT 1 FROM mobility_employees WHERE user_id=? AND fleet_id=mobility_fleets.id))',
        )
        .bind(deputyId, fleetId, deputyId, deputyId)
        .run();
      if (!changed.meta.changes)
        throw new ApiError(
          409,
          'Die Mitarbeiterzuordnung hat sich geändert. Bitte neu laden.',
        );
      return json({ ok: true });
    }
    if (!isAdmin(user))
      throw new ApiError(
        403,
        'Flotten und Zuordnungen verwaltet der Plattformbetreiber.',
      );
    if (b.action === 'transfer_owner') {
      const fleetId = text(b.fleetId),
        previous = text(b.previousOwnerId),
        next = text(b.ownerId);
      if (previous === next || b.confirmed !== true)
        throw new ApiError(
          400,
          'Bitte einen neuen Besitzer wählen und die Übergabe bestätigen.',
        );
      const changed = await db()
        .prepare(`UPDATE mobility_fleets SET owner_id=?,deputy_id=CASE WHEN deputy_id=? THEN NULL ELSE deputy_id END
        WHERE id=? AND owner_id=? AND EXISTS(SELECT 1 FROM mobility_employees e JOIN mobility_drivers d ON d.id=e.user_id WHERE e.user_id=? AND e.fleet_id=mobility_fleets.id AND d.approved=1 AND ${driverIdle('d')})
        AND NOT EXISTS(SELECT 1 FROM mobility_drivers d WHERE d.id=mobility_fleets.owner_id AND NOT (${driverIdle('d')}))
        AND NOT EXISTS(SELECT 1 FROM mobility_accounts a WHERE a.id=? AND a.status<>'active')
        AND NOT EXISTS(SELECT 1 FROM mobility_fleets other WHERE other.owner_id=? AND other.id<>mobility_fleets.id) RETURNING id`)
        .bind(next, next, fleetId, previous, next, next, next)
        .first();
      if (!changed)
        throw new ApiError(
          409,
          'Übergabe nicht möglich: Besitzer geändert, Ziel gehört nicht zur Flotte, ist nicht freigegeben oder noch im Einsatz. Beide Fahrer müssen offline und fertig abgerechnet sein.',
        );
      await audit(user.userId, fleetId, 'fleet.owner_transferred');
      return json({ ok: true });
    }
    if (b.action === 'create') {
      const name = text(b.name, 100);
      const id = crypto.randomUUID();
      const ownerId = b.ownerId ? text(b.ownerId) : user.userId;
      const owner =
        ownerId === user.userId
          ? { name: user.displayName, phone: '' }
          : await db()
              .prepare(
                'SELECT name,phone FROM mobility_employees WHERE user_id=? UNION ALL SELECT name,phone FROM mobility_drivers WHERE id=? LIMIT 1',
              )
              .bind(ownerId, ownerId)
              .first<{ name: string; phone: string }>();
      if (!owner)
        throw new ApiError(
          404,
          'Besitzer muss zuerst ein Mitarbeiter- oder Fahrerprofil einreichen.',
        );
      if (
        await db()
          .prepare(
            'SELECT user_id FROM mobility_employees WHERE user_id=? AND fleet_id IS NOT NULL',
          )
          .bind(ownerId)
          .first()
      )
        throw new ApiError(409, 'Der Besitzer gehört bereits einer Flotte an.');
      const created = await db().batch([
        db()
          .prepare(
            `INSERT OR IGNORE INTO mobility_fleets(id,name,owner_id,created_at) SELECT ?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM mobility_employees WHERE user_id=? AND fleet_id IS NOT NULL) AND NOT EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND NOT (${driverIdle('mobility_drivers')}))`,
          )
          .bind(id, name, ownerId, Date.now(), ownerId, ownerId),
        db()
          .prepare(
            "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) SELECT ?,?,?,?,'staff',? WHERE changes()>0 AND EXISTS(SELECT 1 FROM mobility_fleets WHERE id=? AND owner_id=?) ON CONFLICT(user_id) DO UPDATE SET fleet_id=excluded.fleet_id",
          )
          .bind(ownerId, owner.name, owner.phone, id, Date.now(), id, ownerId),
      ]);
      if (!created[0].meta.changes)
        throw new ApiError(
          409,
          'Besitzer bereits zugeordnet oder noch im Einsatz. Bitte zuerst offline gehen und offene Fahrten abrechnen.',
        );
      return json({ id, name }, 201);
    }
    if (b.action === 'assign') {
      const id = text(b.userId);
      const fleetId = b.fleetId === null ? null : text(b.fleetId);
      if (!['staff', 'driver'].includes(String(b.role)))
        throw new ApiError(400, 'Ungültige Rolle.');
      if (
        fleetId &&
        !(await db()
          .prepare('SELECT id FROM mobility_fleets WHERE id=?')
          .bind(fleetId)
          .first())
      )
        throw new ApiError(404, 'Flotte nicht gefunden.');
      if (
        await db()
          .prepare(
            'SELECT id FROM mobility_fleets WHERE owner_id=? OR deputy_id=?',
          )
          .bind(id, id)
          .first()
      )
        throw new ApiError(
          409,
          'Besitzer können nicht umgehängt werden. Bei Stellvertretern zuerst die Stellvertretung aufheben.',
        );
      const existing = await db()
        .prepare('SELECT fleet_id,role FROM mobility_employees WHERE user_id=?')
        .bind(id)
        .first<{ fleet_id: string | null; role: string }>();
      if (existing && existing.fleet_id === fleetId && existing.role === b.role)
        return json({ ok: true });
      if (
        await db()
          .prepare(
            `SELECT id FROM mobility_drivers WHERE id=? AND NOT (${driverIdle('mobility_drivers')})`,
          )
          .bind(id)
          .first()
      )
        throw new ApiError(
          409,
          'Flottenwechsel erst offline, nach Fahrtabschluss und Kassieren.',
        );
      const member = await db()
        .prepare(
          'SELECT name,phone FROM mobility_employees WHERE user_id=? UNION ALL SELECT name,phone FROM mobility_drivers WHERE id=? LIMIT 1',
        )
        .bind(id, id)
        .first<{ name: string; phone: string }>();
      if (!member) throw new ApiError(404, 'Mitarbeiterprofil nicht gefunden.');
      const assigned = await db().batch([
        db()
          .prepare(
            `INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) SELECT ?,?,?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND NOT (${driverIdle('mobility_drivers')})) AND NOT EXISTS(SELECT 1 FROM mobility_fleets WHERE owner_id=? OR deputy_id=?) ON CONFLICT(user_id) DO UPDATE SET fleet_id=excluded.fleet_id,role=excluded.role`,
          )
          .bind(
            id,
            member.name,
            member.phone,
            fleetId,
            b.role,
            Date.now(),
            id,
            id,
            id,
          ),
        db()
          .prepare(
            `UPDATE mobility_drivers SET online=0,session_id=NULL,vehicle_id=NULL,vehicle='',plate='',services='[]',approved=0 WHERE id=? AND changes()>0 AND ${driverIdle('mobility_drivers')}`,
          )
          .bind(id),
        db()
          .prepare(
            "UPDATE mobility_offers SET status='withdrawn' WHERE driver_id=? AND status='pending' AND changes()>0",
          )
          .bind(id),
      ]);
      if (!assigned[0].meta.changes)
        throw new ApiError(
          409,
          'Zuordnung wurde zwischenzeitlich geändert oder eine Fahrt angenommen. Bitte neu laden.',
        );
      return json({ ok: true });
    }
    throw new ApiError(400, 'Unbekannte Flottenaktion.');
  });
}
