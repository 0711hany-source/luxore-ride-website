import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import {
  inventoryView,
  stockFor,
  stockVehicles,
} from '@/lib/mobility/inventory-server';
import { moveStock, validateStock, type Stock } from '@/lib/mobility/inventory';

export async function GET(request: Request) {
  return handled(async () =>
    json(
      await inventoryView(
        await identity(),
        new URL(request.url).searchParams.get('vehicleId') || undefined,
        new URL(request.url).searchParams.get('fleetId') || undefined,
      ),
    ),
  );
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit(user.userId, 'inventory', 40);
    const b = await body(request),
      vehicleId = text(b.vehicleId),
      action = text(b.action);
    if (!['save', 'personal', 'restock'].includes(action))
      throw new ApiError(400, 'Unbekannte Bestandsaktion.');
    if (!(await stockVehicles(user)).some((v) => v.id === vehicleId))
      throw new ApiError(403, 'Dieses Fahrzeug gehört nicht zu deinem Zugang.');
    const row = await stockFor(vehicleId);
    if (!Number.isInteger(b.revision) || b.revision !== (row?.revision ?? 0))
      throw new ApiError(
        409,
        'Der Bestand wurde inzwischen geändert. Bitte aktualisieren.',
      );
    if (!row && action !== 'save')
      throw new ApiError(
        409,
        'Bitte zuerst den gezählten Anfangsbestand speichern.',
      );
    let next: Stock;
    try {
      next =
        action === 'save'
          ? validateStock(b.stock)
          : moveStock(
              JSON.parse(row!.data),
              b.quantities,
              action === 'restock' ? 1 : -1,
            );
    } catch (e) {
      throw new ApiError(400, (e as Error).message);
    }
    const note =
      action === 'save'
        ? text(b.note, 160)
        : typeof b.note === 'string'
          ? b.note.slice(0, 160).trim()
          : '';
    const id = crypto.randomUUID(),
      now = Date.now();
    const actor = await db()
      .prepare('SELECT name FROM mobility_drivers WHERE id=?')
      .bind(user.userId)
      .first<{ name: string }>();
    const actorName = actor?.name || user.displayName || 'Flottenleitung';
    const statement = row
      ? db()
          .prepare(
            'UPDATE mobility_stock SET data=?,revision=revision+1,operation_id=?,updated_at=? WHERE vehicle_id=? AND revision=?',
          )
          .bind(JSON.stringify(next), id, now, vehicleId, b.revision)
      : db()
          .prepare(
            'INSERT OR IGNORE INTO mobility_stock(vehicle_id,data,revision,operation_id,updated_at) VALUES(?,?,1,?,?)',
          )
          .bind(vehicleId, JSON.stringify(next), id, now);
    const result = await db().batch([
      statement,
      db()
        .prepare(`INSERT INTO mobility_stock_movements(id,vehicle_id,actor_id,actor_name,kind,note,details,created_at)
        SELECT ?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM mobility_stock WHERE vehicle_id=? AND operation_id=?)`)
        .bind(
          id,
          vehicleId,
          user.userId,
          actorName,
          action === 'save' ? (row ? 'correction' : 'initial') : action,
          note,
          JSON.stringify({
            before: row ? JSON.parse(row.data) : null,
            after: next,
            quantities: action === 'save' ? null : b.quantities,
          }),
          now,
          vehicleId,
          id,
        ),
    ]);
    if (!result[0].meta.changes)
      throw new ApiError(
        409,
        'Der Bestand wurde inzwischen geändert. Bitte aktualisieren.',
      );
    return json(await inventoryView(user, vehicleId));
  });
}
