import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
  settings,
} from '@/lib/mobility/server';
import { parseRoadTrace, readRoadMatch } from '@/lib/mobility/road-matching';
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    const driver = await db()
      .prepare('SELECT id FROM mobility_drivers WHERE id=? AND approved=1')
      .bind(user.userId)
      .first();
    if (!driver)
      throw new ApiError(403, 'Straßenabgleich nur für freigegebene Fahrer.');
    await limit(user.userId, 'navigation-match', 12);
    const b = await body(request);
    let trace;
    try {
      trace = parseRoadTrace(b.points, Date.now());
    } catch (e) {
      throw new ApiError(400, (e as Error).message);
    }
    const token =
      settings().MAPBOX_ACCESS_TOKEN || settings().MAPBOX_PUBLIC_TOKEN;
    if (!token) return json({ match: null });
    const url = new URL(
      `https://api.mapbox.com/matching/v5/mapbox/driving/${trace.map((p) => `${p.lng},${p.lat}`).join(';')}`,
    );
    url.search = new URLSearchParams({
      access_token: token,
      geometries: 'geojson',
      overview: 'full',
      steps: 'false',
      tidy: 'false',
      timestamps: trace.map((p) => Math.floor(p.timestamp / 1000)).join(';'),
      radiuses: trace
        .map((p) => Math.max(5, Math.min(30, p.accuracy)))
        .join(';'),
    }).toString();
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(3500) });
      if (!response.ok) return json({ match: null });
      return json({ match: readRoadMatch(await response.json(), trace) });
    } catch {
      return json({ match: null });
    }
  });
}
