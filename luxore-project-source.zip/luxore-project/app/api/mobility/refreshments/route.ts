import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import { hydrate } from '@/lib/mobility/bookings';
import {
  cartPrice,
  storedOrder,
  updateOrder,
} from '@/lib/mobility/refreshments';
import { stockFor } from '@/lib/mobility/inventory-server';
import { moveStock } from '@/lib/mobility/inventory';
import type { Service } from '@/lib/mobility/domain';
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit(user.userId, 'refreshments', 40);
    const b = await body(request);
    if (!['request', 'deliver', 'unavailable'].includes(String(b.action)))
      throw new ApiError(400, 'Unbekannte Bordkarten-Aktion.');
    const action = b.action as 'request' | 'deliver' | 'unavailable';
    const row = await db()
      .prepare(
        'SELECT * FROM mobility_bookings WHERE id=? AND (owner_id=? OR driver_id=?)',
      )
      .bind(text(b.id), user.userId, user.userId)
      .first();
    if (!row) throw new ApiError(404, 'Fahrt nicht gefunden.');
    const owner = action === 'request';
    if (user.userId !== (owner ? row.owner_id : row.driver_id))
      throw new ApiError(403, 'Diese Änderung ist nicht erlaubt.');
    const statuses = owner
      ? ['reserved', 'requesting', 'accepted', 'arrived', 'riding']
      : ['accepted', 'arrived', 'riding'];
    if (
      !statuses.includes(String(row.status)) ||
      row.payment_status !== 'unpaid'
    )
      throw new ApiError(409, 'Die Bordkarte ist für diese Fahrt geschlossen.');
    const current = storedOrder(row.refreshments);
    if (b.revision !== current.revision)
      throw new ApiError(
        409,
        'Die Bestellung wurde geändert. Bitte aktualisieren und erneut prüfen.',
      );
    let next;
    try {
      next = updateOrder(current, action, b);
    } catch (e) {
      throw new ApiError(400, (e as Error).message);
    }
    const fare = Number(row.fare_price ?? row.price);
    const total = fare + cartPrice(next.delivered, row.service as Service);
    // Stock and fare updates share one database transaction; the booking revision gates both.
    const operationId = crypto.randomUUID();
    const stock =
      action === 'deliver' && typeof row.vehicle_id === 'string'
        ? await stockFor(row.vehicle_id)
        : null;
    if (action === 'deliver' && !stock)
      throw new ApiError(
        409,
        'Bitte unter Bestand zuerst den Bordbestand dieses Fahrzeugs erfassen.',
      );
    let stockData;
    if (stock) {
      try {
        stockData = moveStock(
          JSON.parse(stock.data),
          { [String(b.itemId)]: b.quantity },
          -1,
        );
      } catch (e) {
        throw new ApiError(409, (e as Error).message);
      }
    }
    const update = db()
      .prepare(
        `UPDATE mobility_bookings SET refreshments=?,fare_price=?,price=?,updated_at=? WHERE id=? AND ${owner ? 'owner_id' : 'driver_id'}=? AND refreshments IS ? AND status IN (${statuses.map(() => '?').join(',')}) AND payment_status='unpaid'${stock ? ' AND EXISTS(SELECT 1 FROM mobility_stock WHERE vehicle_id=? AND operation_id=?)' : ''}`,
      )
      .bind(
        JSON.stringify(next),
        fare,
        total,
        Date.now(),
        row.id,
        user.userId,
        row.refreshments ?? null,
        ...statuses,
        ...(stock ? [row.vehicle_id, operationId] : []),
      );
    let changed;
    if (stock) {
      const actor = await db()
        .prepare('SELECT name FROM mobility_drivers WHERE id=?')
        .bind(user.userId)
        .first<{ name: string }>();
      const results = await db().batch([
        db()
          .prepare(`UPDATE mobility_stock SET data=?,revision=revision+1,operation_id=?,updated_at=?
          WHERE vehicle_id=? AND revision=? AND EXISTS(SELECT 1 FROM mobility_bookings
          WHERE id=? AND driver_id=? AND vehicle_id=? AND refreshments IS ? AND status IN ('accepted','arrived','riding') AND payment_status='unpaid')`)
          .bind(
            JSON.stringify(stockData),
            operationId,
            Date.now(),
            row.vehicle_id,
            stock.revision,
            row.id,
            user.userId,
            row.vehicle_id,
            row.refreshments ?? null,
          ),
        update,
        db()
          .prepare(`INSERT INTO mobility_stock_movements(id,vehicle_id,actor_id,actor_name,kind,note,details,booking_id,created_at)
          SELECT ?,?,?,?,'delivery','An Fahrgast übergeben',?,?,? WHERE EXISTS(SELECT 1 FROM mobility_stock WHERE vehicle_id=? AND operation_id=?)`)
          .bind(
            operationId,
            row.vehicle_id,
            user.userId,
            actor?.name || 'Fahrer',
            JSON.stringify({ quantities: { [String(b.itemId)]: b.quantity } }),
            row.id,
            Date.now(),
            row.vehicle_id,
            operationId,
          ),
      ]);
      changed = results[1];
    } else changed = await update.run();
    if (!changed.meta.changes)
      throw new ApiError(
        409,
        'Die Fahrt oder Bestellung wurde inzwischen geändert. Bitte aktualisieren.',
      );
    return json(
      await hydrate(
        (await db()
          .prepare('SELECT * FROM mobility_bookings WHERE id=?')
          .bind(row.id)
          .first())!,
      ),
    );
  });
}
