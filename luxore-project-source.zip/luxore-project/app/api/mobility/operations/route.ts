import { driverIdle } from '@/lib/mobility/vehicles';
import { operatorScope } from '@/lib/mobility/fleets';
import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  text,
} from '@/lib/mobility/server';
import { hydrate } from '@/lib/mobility/bookings';
import { audit } from '@/lib/mobility/accounts';
export async function GET() {
  return handled(async () => {
    const user = await identity();
    const scope = await operatorScope(user);
    if (!scope) throw new ApiError(403, 'Nur die Disposition hat Zugriff.');
    const drivers = await db()
      .prepare(
        "SELECT d.*,e.fleet_id,f.name AS fleet_name FROM mobility_drivers d LEFT JOIN mobility_employees e ON e.user_id=d.id LEFT JOIN mobility_fleets f ON f.id=e.fleet_id WHERE ?='all' OR EXISTS(SELECT 1 FROM mobility_employees e WHERE e.user_id=d.id AND e.fleet_id=?) ORDER BY approved,name LIMIT 200",
      )
      .bind(scope, scope)
      .all();
    const bookings = await db()
      .prepare(
        "SELECT * FROM mobility_bookings WHERE ?='all' OR fleet_id=? ORDER BY created_at DESC LIMIT 200",
      )
      .bind(scope, scope)
      .all();
    return json({
      drivers: drivers.results,
      bookings: await Promise.all(bookings.results.map(hydrate)),
    });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    const scope = await operatorScope(user);
    if (!scope)
      throw new ApiError(403, 'Nur die Disposition darf Fahrer freigeben.');
    const b = await body(request);
    if (typeof b.approved !== 'boolean')
      throw new ApiError(400, 'Ungültige Freigabe.');
    const id = text(b.driverId);
    if (
      b.approved &&
      (await db()
        .prepare(
          "SELECT id FROM mobility_accounts WHERE id=? AND status<>'active'",
        )
        .bind(id)
        .first())
    )
      throw new ApiError(409, 'Dieses Konto ist gesperrt oder wird gelöscht.');
    if (
      scope !== 'all' &&
      !(await db()
        .prepare(
          'SELECT user_id FROM mobility_employees WHERE user_id=? AND fleet_id=?',
        )
        .bind(id, scope)
        .first())
    )
      throw new ApiError(403, 'Dieser Fahrer gehört nicht zu deiner Flotte.');
    const current = await db()
      .prepare('SELECT approved FROM mobility_drivers WHERE id=?')
      .bind(id)
      .first<{ approved: number }>();
    if (!current) throw new ApiError(404, 'Fahrerprofil nicht gefunden.');
    // Repeated approval must never stop an already approved driver's GPS session.
    if (current.approved === Number(b.approved)) return json({ ok: true });
    const results = await db().batch([
      db()
        .prepare(
          `UPDATE mobility_drivers SET approved=?,online=0,session_id=NULL WHERE id=? AND approved<>? AND (?='all' OR EXISTS(SELECT 1 FROM mobility_employees e WHERE e.user_id=mobility_drivers.id AND e.fleet_id=?)) AND (?=1 OR ${driverIdle('mobility_drivers')})`,
        )
        .bind(
          Number(b.approved),
          id,
          Number(b.approved),
          scope,
          scope,
          Number(b.approved),
        ),
      db()
        .prepare(
          "UPDATE mobility_offers SET status='withdrawn' WHERE driver_id=? AND status='pending' AND EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND approved=0)",
        )
        .bind(id, id),
    ]);
    if (!results[0].meta.changes)
      throw new ApiError(
        409,
        'Freigabe erst zurücknehmen, wenn der Fahrer offline ist, die Fahrt beendet und kassiert hat.',
      );
    await audit(
      user.userId,
      id,
      b.approved ? 'driver.approved' : 'driver.unapproved',
    );
    return json({ ok: true });
  });
}
