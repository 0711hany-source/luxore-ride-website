import { driverIdle } from '@/lib/mobility/vehicles';
import { operatorScope } from '@/lib/mobility/fleets';
import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  text,
} from '@/lib/mobility/server';
import { hydrate } from '@/lib/mobility/bookings';
import { audit } from '@/lib/mobility/accounts';
export async function GET() {
  return handled(async () => {
    const user = await identity();
    const scope = await operatorScope(user);
    if (!scope) throw new ApiError(403, 'Nur die Disposition hat Zugriff.');
    const drivers = await db()
      .prepare(
        "SELECT d.*,e.fleet_id,f.name AS fleet_name FROM mobility_drivers d LEFT JOIN mobility_employees e ON e.user_id=d.id LEFT JOIN mobility_fleets f ON f.id=e.fleet_id WHERE ?='all' OR EXISTS(SELECT 1 FROM mobility_employees e WHERE e.user_id=d.id AND e.fleet_id=?) ORDER BY approved,name LIMIT 200",
      )
      .bind(scope, scope)
      .all();
    const bookings = await db()
      .prepare(
        "SELECT * FROM mobility_bookings WHERE ?='all' OR fleet_id=? ORDER BY created_at DESC LIMIT 200",
      )
      .bind(scope, scope)
      .all();
    return json({
      drivers: drivers.results,
      bookings: await Promise.all(bookings.results.map(hydrate)),
    });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    const b = await body(request);
    if (typeof b.approved !== 'boolean')
      throw new ApiError(400, 'Ungültige Freigabe.');
    const id = text(b.driverId);
    await db().writeTransaction(async (transaction) => {
      const scope = await operatorScope(user, () => transaction);
      if (!scope)
        throw new ApiError(403, 'Nur die Disposition darf Fahrer freigeben.');
      if (
        await transaction
          .prepare(
            "SELECT id FROM mobility_accounts WHERE id=? AND status<>'active'",
          )
          .bind(user.userId)
          .first()
      )
        throw new ApiError(
          403,
          'Dein Konto ist nicht aktiv. Bitte erneut anmelden.',
        );
      if (
        b.approved &&
        (await transaction
          .prepare(
            "SELECT id FROM mobility_accounts WHERE id=? AND status<>'active'",
          )
          .bind(id)
          .first())
      )
        throw new ApiError(
          409,
          'Dieses Konto ist gesperrt oder wird gelöscht.',
        );
      if (
        scope !== 'all' &&
        !(await transaction
          .prepare(
            'SELECT user_id FROM mobility_employees WHERE user_id=? AND fleet_id=?',
          )
          .bind(id, scope)
          .first())
      )
        throw new ApiError(403, 'Dieser Fahrer gehört nicht zu deiner Flotte.');
      const current = await transaction
        .prepare('SELECT approved FROM mobility_drivers WHERE id=?')
        .bind(id)
        .first<{ approved: number }>();
      if (!current) throw new ApiError(404, 'Fahrerprofil nicht gefunden.');
      // Repeated approval must never stop an already approved driver's GPS session.
      if (current.approved === Number(b.approved)) return;
      const results = await transaction.batch([
        transaction
          .prepare(
            `UPDATE mobility_drivers SET approved=?,online=0,session_id=NULL WHERE id=? AND approved<>? AND (?='all' OR EXISTS(SELECT 1 FROM mobility_employees e WHERE e.user_id=mobility_drivers.id AND e.fleet_id=?)) AND (?=0 OR NOT EXISTS(SELECT 1 FROM mobility_accounts a WHERE a.id=mobility_drivers.id AND a.status<>'active')) AND (?=1 OR ${driverIdle('mobility_drivers')})`,
          )
          .bind(
            Number(b.approved),
            id,
            Number(b.approved),
            scope,
            scope,
            Number(b.approved),
            Number(b.approved),
          ),
        transaction
          .prepare(
            "UPDATE mobility_offers SET status='withdrawn' WHERE driver_id=? AND status='pending' AND EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND approved=0)",
          )
          .bind(id, id),
      ]);
      if (!results[0].meta.changes)
        throw new ApiError(
          409,
          'Freigabe nicht möglich: Konto oder Zuordnung geändert. Zum Zurücknehmen muss der Fahrer offline sein, die Fahrt beendet und kassiert haben.',
        );
      await audit(
        user.userId,
        id,
        b.approved ? 'driver.approved' : 'driver.unapproved',
        () => transaction,
      );
    });
    return json({ ok: true });
  });
}
