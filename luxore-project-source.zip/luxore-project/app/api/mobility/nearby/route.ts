import { vehicleEligible } from '@/lib/mobility/vehicles';
import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import { isService, type Driver, type Quote } from '@/lib/mobility/domain';
import { nearestDrivers } from '@/lib/mobility/nearby';
import { FRESH_MS } from '@/lib/mobility/dispatch';
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit(user.userId, 'nearby', 25);
    const b = await body(request);
    if (!isService(b.service)) throw new ApiError(400, 'Ungültige Klasse.');
    let route: Quote;
    if (b.bookingId) {
      const row = await db()
        .prepare(
          "SELECT route,service FROM mobility_bookings WHERE id=? AND owner_id=? AND status='requesting'",
        )
        .bind(text(b.bookingId), user.userId)
        .first<{ route: string; service: string }>();
      if (!row || row.service !== b.service) return json({ drivers: [] });
      route = JSON.parse(row.route);
    } else {
      const row = await db()
        .prepare(
          'SELECT payload FROM mobility_quotes WHERE id=? AND owner_id=? AND expires_at>?',
        )
        .bind(text(b.quoteId), user.userId, Date.now())
        .first<{ payload: string }>();
      if (!row) return json({ drivers: [] });
      route = JSON.parse(row.payload);
    }
    const candidates = await db()
      .prepare(`SELECT d.* FROM mobility_drivers d WHERE ${vehicleEligible('d')} AND approved=1 AND online=1 AND id<>? AND lat IS NOT NULL AND lng IS NOT NULL AND accuracy<=100 AND location_at>?
      AND EXISTS(SELECT 1 FROM json_each(COALESCE(d.services,json_array(d.service))) WHERE value=?)
      AND NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.driver_id=d.id AND (b.status IN ('accepted','arrived','riding') OR (b.status='completed' AND b.completed_at IS NOT NULL AND b.payment_status='unpaid')))
      AND NOT EXISTS(SELECT 1 FROM mobility_offers o WHERE o.driver_id=d.id AND o.status='pending' AND o.expires_at>? AND o.booking_id<>?)
      LIMIT 200`)
      .bind(
        user.userId,
        Date.now() - FRESH_MS,
        b.service,
        Date.now(),
        typeof b.bookingId === 'string' ? b.bookingId : '',
      )
      .all<Driver>();
    return json({ drivers: nearestDrivers(candidates.results, route.pickup) });
  });
}
