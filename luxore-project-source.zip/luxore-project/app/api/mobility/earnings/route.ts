import { db, handled, identity, json } from '@/lib/mobility/server';
import { driverEarnings } from '@/lib/mobility/settlement';
/** A driver's own trips only: the driver id comes from the sign-in alone. */
export async function GET() {
  return handled(async () => {
    const user = await identity();
    return json(await driverEarnings(db(), user.userId));
  });
}
