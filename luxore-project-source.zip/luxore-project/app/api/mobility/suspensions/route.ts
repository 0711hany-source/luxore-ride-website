import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import { operatorScope } from '@/lib/mobility/fleets';
import { audit } from '@/lib/mobility/accounts';
import {
  actorName,
  isSubjectType,
  liftSuspension,
  subjectAccess,
  suspend,
} from '@/lib/mobility/compliance';

const SUBJECT_NAME = `CASE s.subject_type
  WHEN 'driver' THEN (SELECT name FROM mobility_drivers WHERE id=s.subject_id)
  WHEN 'vehicle' THEN (SELECT model||' · '||plate FROM mobility_vehicles WHERE id=s.subject_id)
  ELSE (SELECT name FROM mobility_fleets WHERE id=s.subject_id) END`;
export async function GET(request: Request) {
  return handled(async () => {
    const user = await identity();
    const scope = await operatorScope(user);
    if (!scope)
      throw new ApiError(
        403,
        'Sperren sieht nur die Flottenleitung und der Betreiber.',
      );
    const requested = new URL(request.url).searchParams.get('fleetId');
    if (requested && scope !== 'all' && requested !== scope)
      throw new ApiError(403, 'Diese Flotte gehört nicht zu deinem Zugang.');
    const fleetId = requested || (scope === 'all' ? 'all' : scope);
    const rows = await db()
      .prepare(
        `SELECT s.*,${SUBJECT_NAME} AS subject_name,f.name AS fleet_name FROM mobility_suspensions s LEFT JOIN mobility_fleets f ON f.id=s.fleet_id
         WHERE ?='all' OR s.fleet_id=? ORDER BY s.lifted_at IS NOT NULL,s.created_at DESC LIMIT 100`,
      )
      .bind(fleetId, fleetId)
      .all();
    return json({ suspensions: rows.results, operator: scope === 'all' });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit(user.userId, 'suspension-write', 20);
    const b = await body(request);
    const scope = await operatorScope(user);
    if (!scope)
      throw new ApiError(
        403,
        'Sperren darf nur die Flottenleitung oder der Betreiber.',
      );
    if (b.action === 'suspend') {
      const type = b.subjectType,
        id = text(b.subjectId, 100),
        reason = text(b.reason, 200);
      if (!isSubjectType(type)) throw new ApiError(400, 'Ungültige Anfrage.');
      if (type === 'fleet' && scope !== 'all')
        throw new ApiError(
          403,
          'Eine ganze Flotte kann nur der Betreiber sperren.',
        );
      const result = await db().writeTransaction(async (transaction) => {
        // Rights are read inside the transaction: membership may just have changed.
        const access = await subjectAccess(
          transaction,
          user.userId,
          scope,
          type,
          id,
        );
        const own = scope === 'all' || (!!access.fleetId && access.fleetId === scope);
        if (!access.exists || !own || (type === 'fleet' && !access.fleetId))
          throw new ApiError(404, 'Nicht gefunden.');
        const created = await suspend(
          transaction,
          { userId: user.userId, name: await actorName(transaction, user) },
          scope === 'all' ? 'operator' : 'fleet',
          type,
          id,
          access.fleetId,
          reason,
        );
        if (!('replayed' in created))
          await audit(user.userId, id, 'suspension.created:' + type, () => transaction);
        return created;
      });
      return json({ ok: true, id: result.id });
    }
    if (b.action === 'lift') {
      const id = text(b.id, 60);
      await db().writeTransaction(async (transaction) => {
        const row = await liftSuspension(
          transaction,
          { userId: user.userId, name: await actorName(transaction, user) },
          scope,
          id,
        );
        if (row.lifted_at === null)
          await audit(
            user.userId,
            row.subject_id,
            'suspension.lifted:' + row.subject_type,
            () => transaction,
          );
      });
      return json({ ok: true });
    }
    throw new ApiError(400, 'Unbekannte Sperraktion.');
  });
}
