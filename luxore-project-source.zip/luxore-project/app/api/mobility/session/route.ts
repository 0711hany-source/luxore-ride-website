import { headers } from 'next/headers';
import { accountUser } from '@/lib/mobility/accounts';
import {
  checkOrigin,
  db,
  deviceUser,
  handled,
  json,
  limit,
  sessionCookie,
  tokenHash,
} from '@/lib/mobility/server';
export async function POST(request: Request) {
  return handled(async () => {
    checkOrigin(request);
    const h = await headers();
    if (
      (await accountUser(h)) ||
      (await deviceUser(h))
    )
      return json({ ok: true });
    // Global cap also bounds issuance when the host does not forward a trusted IP.
    await limit('public', 'session', 60);
    const ip = process.env.VERCEL ? h.get('x-vercel-forwarded-for')?.split(',')[0]?.trim() : null;
    if (ip) await limit(await tokenHash(ip), 'session-ip', 10);
    const token = Array.from(crypto.getRandomValues(new Uint8Array(32)), (b) =>
      b.toString(16).padStart(2, '0'),
    ).join('');
    const maxAge = 180 * 24 * 3600;
    await db()
      .prepare(
        'INSERT INTO mobility_sessions(token_hash,user_id,expires_at) VALUES(?,?,?)',
      )
      .bind(
        await tokenHash(token),
        'device:' + crypto.randomUUID(),
        Date.now() + maxAge * 1000,
      )
      .run();
    await db()
      .prepare('DELETE FROM mobility_sessions WHERE expires_at<?')
      .bind(Date.now())
      .run();
    const response = json({ ok: true }, 201);
    response.headers.set(
      'Set-Cookie',
      `${sessionCookie}=${token}; Path=/; Max-Age=${maxAge}; HttpOnly; SameSite=Strict${new URL(request.url).protocol === 'https:' ? '; Secure' : ''}`,
    );
    return response;
  });
}
