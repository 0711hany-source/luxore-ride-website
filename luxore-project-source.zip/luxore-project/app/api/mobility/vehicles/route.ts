import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import { operatorScope } from '@/lib/mobility/fleets';
import { driverIdle } from '@/lib/mobility/vehicles';
import { validateVehicleInput } from '@/lib/mobility/vehicle-input';
const idle = driverIdle('mobility_drivers');
export async function GET(request: Request) {
  return handled(async () => {
    const user = await identity(),
      scope = await operatorScope(user);
    if (!scope)
      throw new ApiError(403, 'Nur die Flottenleitung verwaltet Fahrzeuge.');
    const fleetId = new URL(request.url).searchParams.get('fleetId');
    if (fleetId && scope !== 'all' && scope !== fleetId)
      throw new ApiError(403, 'Diese Flotte gehört nicht zu deinem Zugang.');
    const selectedScope = fleetId || scope;
    const rows = await db()
      .prepare(
        `SELECT v.*,d.id AS driver_id,d.name AS driver_name,d.online,
        CASE WHEN d.id IS NULL OR (${driverIdle('d')}) THEN NULL
        WHEN EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.driver_id=d.id AND b.status IN ('accepted','arrived','riding')) THEN 'Fahrt läuft'
        WHEN EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.driver_id=d.id AND b.status='completed' AND b.completed_at IS NOT NULL AND b.payment_status='unpaid') THEN 'Zahlung noch offen'
        ELSE 'Fahrer muss zuerst offline gehen' END AS blocking_reason
        FROM mobility_vehicles v LEFT JOIN mobility_drivers d ON d.vehicle_id=v.id WHERE ?='all' OR v.fleet_id=? ORDER BY v.status,v.model,v.plate`,
      )
      .bind(selectedScope, selectedScope)
      .all();
    return json({ vehicles: rows.results });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit(user.userId, 'vehicles', 30);
    const b = await body(request);
    if (b.action === 'select') {
      const vehicleId = b.vehicleId === null ? null : text(b.vehicleId);
      let query: string, values: unknown[];
      if (vehicleId) {
        query = `UPDATE mobility_drivers SET vehicle_id=?,vehicle=(SELECT model FROM mobility_vehicles WHERE id=?),plate=(SELECT plate FROM mobility_vehicles WHERE id=?),services=(SELECT services FROM mobility_vehicles WHERE id=?),service=(SELECT json_extract(services,'$[0]') FROM mobility_vehicles WHERE id=?),session_id=NULL WHERE id=? AND approved=1 AND ${idle} AND EXISTS(SELECT 1 FROM mobility_vehicles v JOIN mobility_employees e ON e.fleet_id=v.fleet_id WHERE e.user_id=mobility_drivers.id AND v.id=? AND v.status='active') AND NOT EXISTS(SELECT 1 FROM mobility_drivers other WHERE other.vehicle_id=? AND other.id<>mobility_drivers.id)`;
        values = [
          vehicleId,
          vehicleId,
          vehicleId,
          vehicleId,
          vehicleId,
          user.userId,
          vehicleId,
          vehicleId,
        ];
      } else {
        query = `UPDATE mobility_drivers SET vehicle_id=NULL,vehicle='',plate='',services='[]',session_id=NULL WHERE id=? AND ${idle}`;
        values = [user.userId];
      }
      const results = await db().batch([
        db()
          .prepare(query)
          .bind(...values),
        db()
          .prepare(
            "UPDATE mobility_offers SET status='withdrawn' WHERE driver_id=? AND status='pending' AND changes()>0 AND EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND online=0 AND session_id IS NULL)",
          )
          .bind(user.userId, user.userId),
      ]);
      if (!results[0].meta.changes)
        throw new ApiError(
          409,
          'Fahrzeugwechsel nur offline und nach Fahrtabschluss und Kassieren. Das Auto muss frei und deiner Flotte zugeordnet sein.',
        );
      return json({ ok: true });
    }
    const scope = await operatorScope(user);
    if (!scope)
      throw new ApiError(403, 'Nur die Flottenleitung verwaltet Fahrzeuge.');
    if (b.action === 'create') {
      const fleetId = text(b.fleetId);
      if (scope !== 'all' && scope !== fleetId)
        throw new ApiError(403, 'Diese Flotte gehört nicht zu deinem Zugang.');
      if (
        !(await db()
          .prepare('SELECT id FROM mobility_fleets WHERE id=?')
          .bind(fleetId)
          .first())
      )
        throw new ApiError(404, 'Flotte nicht gefunden.');
      const validated = validateVehicleInput(b);
      if (!validated.value)
        throw new ApiError(400, Object.values(validated.errors)[0]!);
      const { model, plate, services } = validated.value;
      const id =
        b.requestId === undefined ? crypto.randomUUID() : text(b.requestId, 36);
      if (
        !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(
          id,
        )
      )
        throw new ApiError(
          400,
          'Ungültige Speicheranfrage. Bitte das Formular neu öffnen.',
        );
      const readExisting = () =>
        db()
          .prepare(
            'SELECT id,fleet_id,model,plate,services,status FROM mobility_vehicles WHERE id=?',
          )
          .bind(id)
          .first<{
            id: string;
            fleet_id: string;
            model: string;
            plate: string;
            services: string;
            status: string;
          }>();
      const existing = await readExisting();
      const matches = (record: Awaited<ReturnType<typeof readExisting>>) =>
        !!record &&
        record.fleet_id === fleetId &&
        record.model === model &&
        record.plate === plate &&
        record.services === JSON.stringify(services) &&
        record.status === 'active';
      if (existing) {
        if (matches(existing)) return json({ id, replayed: true });
        throw new ApiError(
          409,
          'Diese Speicheranfrage wurde bereits verarbeitet. Bitte die Fahrzeugliste aktualisieren.',
        );
      }
      const r = await db()
        .prepare(
          "INSERT OR IGNORE INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) SELECT ?,?,?,?,?,'active',? WHERE NOT EXISTS(SELECT 1 FROM mobility_vehicles WHERE status='active' AND replace(replace(upper(plate),' ',''),'-','')=replace(replace(upper(?),' ',''),'-',''))",
        )
        .bind(
          id,
          fleetId,
          model,
          plate,
          JSON.stringify(services),
          Date.now(),
          plate,
        )
        .run();
      if (!r.meta.changes) {
        if (matches(await readExisting())) return json({ id, replayed: true });
        throw new ApiError(
          409,
          'Dieses Kennzeichen ist bereits aktiv angelegt.',
        );
      }
      return json({ id }, 201);
    }
    if (b.action === 'update' || b.action === 'restore') {
      const id = text(b.id);
      const readVehicle = () =>
        db()
          .prepare(
            "SELECT * FROM mobility_vehicles WHERE id=? AND (?='all' OR fleet_id=?)",
          )
          .bind(id, scope, scope)
          .first<{
            model: string;
            plate: string;
            services: string;
            status: string;
          }>();
      const vehicle = await readVehicle();
      if (!vehicle) throw new ApiError(404, 'Fahrzeug nicht gefunden.');
      const restoring = b.action === 'restore';
      const validated = validateVehicleInput(
        restoring ? { ...vehicle, services: JSON.parse(vehicle.services) } : b,
      );
      if (!validated.value)
        throw new ApiError(400, Object.values(validated.errors)[0]!);
      const { model, plate, services } = validated.value;
      const alreadySaved = (current: Awaited<ReturnType<typeof readVehicle>>) =>
        !restoring &&
        current?.status === 'active' &&
        current.model === model &&
        current.plate === plate &&
        current.services === JSON.stringify(services);
      if (alreadySaved(vehicle)) return json({ ok: true, replayed: true });
      if (!restoring) {
        const expected = b.expected;
        if (
          !expected ||
          typeof expected !== 'object' ||
          Array.isArray(expected)
        )
          throw new ApiError(
            409,
            'Bitte die Fahrzeugliste neu laden und das Fahrzeug erneut bearbeiten.',
          );
        const prior = expected as Record<string, unknown>;
        if (
          prior.model !== vehicle.model ||
          prior.plate !== vehicle.plate ||
          prior.services !== vehicle.services
        )
          throw new ApiError(
            409,
            'Das Fahrzeug wurde zwischenzeitlich geändert. Lade die aktuellen Daten, bevor du erneut speicherst.',
          );
      }
      const results = await db().batch([
        db()
          .prepare(`UPDATE mobility_vehicles SET model=?,plate=?,services=?,status='active',archived_reason=NULL,archived_at=NULL WHERE id=? AND status=? AND (?='all' OR fleet_id=?)
          AND model=? AND plate=? AND services=?
          AND NOT EXISTS(SELECT 1 FROM mobility_drivers WHERE vehicle_id=mobility_vehicles.id AND NOT (${idle}))
          AND NOT EXISTS(SELECT 1 FROM mobility_vehicles other WHERE other.id<>mobility_vehicles.id AND other.status='active' AND replace(replace(upper(other.plate),' ',''),'-','')=replace(replace(upper(?),' ',''),'-',''))`)
          .bind(
            model,
            plate,
            JSON.stringify(services),
            id,
            restoring ? 'archived' : 'active',
            scope,
            scope,
            vehicle.model,
            vehicle.plate,
            vehicle.services,
            plate,
          ),
        db()
          .prepare(
            `UPDATE mobility_drivers SET vehicle=?,plate=?,services=?,service=?,session_id=NULL WHERE vehicle_id=? AND changes()>0 AND ${idle}`,
          )
          .bind(model, plate, JSON.stringify(services), services[0], id),
        db()
          .prepare(
            "UPDATE mobility_offers SET status='withdrawn' WHERE status='pending' AND driver_id IN (SELECT id FROM mobility_drivers WHERE vehicle_id=?) AND changes()>0",
          )
          .bind(id),
      ]);
      if (!results[0].meta.changes) {
        const current = await readVehicle();
        if (alreadySaved(current)) return json({ ok: true, replayed: true });
        if (
          !restoring &&
          current &&
          (current.model !== vehicle.model ||
            current.plate !== vehicle.plate ||
            current.services !== vehicle.services)
        )
          throw new ApiError(
            409,
            'Das Fahrzeug wurde zwischenzeitlich geändert. Lade die aktuellen Daten, bevor du erneut speicherst.',
          );
        throw new ApiError(
          409,
          'Änderung nicht möglich: Das Fahrzeug ist im Einsatz, das Kennzeichen ist bereits aktiv oder der Fahrzeugstatus wurde geändert. Bitte die Liste aktualisieren.',
        );
      }
      return json({ ok: true });
    }
    if (b.action === 'release') {
      const id = text(b.id);
      if (typeof b.expectedDriverId !== 'string' || !b.expectedDriverId.trim())
        throw new ApiError(
          409,
          'Bitte die Fahrzeugliste neu laden und die Freigabe erneut öffnen.',
        );
      const expectedDriverId = text(b.expectedDriverId);
      const results = await db().batch([
        db()
          .prepare(
            `UPDATE mobility_drivers SET vehicle_id=NULL,vehicle='',plate='',services='[]',session_id=NULL WHERE id=? AND vehicle_id=? AND ${idle} AND EXISTS(SELECT 1 FROM mobility_vehicles v WHERE v.id=mobility_drivers.vehicle_id AND (?='all' OR v.fleet_id=?))`,
          )
          .bind(expectedDriverId, id, scope, scope),
        db()
          .prepare(
            "UPDATE mobility_offers SET status='withdrawn' WHERE driver_id=? AND status='pending' AND changes()>0",
          )
          .bind(expectedDriverId),
      ]);
      if (!results[0].meta.changes) {
        const current = await db()
          .prepare(
            "SELECT d.id AS driver_id FROM mobility_vehicles v LEFT JOIN mobility_drivers d ON d.vehicle_id=v.id WHERE v.id=? AND (?='all' OR v.fleet_id=?)",
          )
          .bind(id, scope, scope)
          .first<{ driver_id: string | null }>();
        // A lost response may be retried, but never release a later assignee.
        if (current && current.driver_id === null)
          return json({ ok: true, replayed: true });
        if (current && current.driver_id !== expectedDriverId)
          throw new ApiError(
            409,
            'Ein anderer Fahrer hat das Fahrzeug inzwischen übernommen. Bitte diese Freigabe schließen und die aktuelle Zuordnung prüfen.',
          );
        throw new ApiError(
          409,
          'Freigeben nur bei einem belegten Fahrzeug deiner Flotte: Fahrer offline, Fahrt beendet und Zahlung erfasst.',
        );
      }
      return json({ ok: true });
    }
    if (b.action === 'archive') {
      const id = text(b.id),
        reason = text(b.reason, 80);
      const results = await db().batch([
        db()
          .prepare(
            `UPDATE mobility_vehicles SET status='archived',archived_reason=?,archived_at=? WHERE id=? AND status='active' AND (?='all' OR fleet_id=?) AND NOT EXISTS(SELECT 1 FROM mobility_drivers WHERE vehicle_id=mobility_vehicles.id AND NOT (${idle}))`,
          )
          .bind(reason, Date.now(), id, scope, scope),
        db()
          .prepare(
            "UPDATE mobility_drivers SET vehicle_id=NULL,vehicle='',plate='',services='[]',session_id=NULL WHERE vehicle_id=? AND changes()>0 AND EXISTS(SELECT 1 FROM mobility_vehicles WHERE id=? AND status='archived' AND (?='all' OR fleet_id=?))",
          )
          .bind(id, id, scope, scope),
      ]);
      if (!results[0].meta.changes)
        throw new ApiError(
          409,
          'Archivieren nicht möglich: Das Auto ist noch im Einsatz, bereits archiviert oder gehört zu einer anderen Flotte.',
        );
      return json({ ok: true });
    }
    throw new ApiError(400, 'Unbekannte Fahrzeugaktion.');
  });
}
