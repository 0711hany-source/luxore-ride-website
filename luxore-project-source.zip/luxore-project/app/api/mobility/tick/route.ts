import {
  db,
  handled,
  identity,
  json,
  limit,
  settings,
} from '@/lib/mobility/server';
import { dispatch } from '@/lib/mobility/dispatch';
export async function POST(request: Request) {
  return handled(async () => {
    const secret = settings().DISPATCH_SECRET;
    const authorizedScheduler =
      secret && request.headers.get('authorization') === `Bearer ${secret}`;
    if (!authorizedScheduler) {
      const user = await identity(request);
      await limit(user.userId, 'tick', 25);
    }
    await dispatch(db());
    return json({ ok: true, at: Date.now() });
  });
}
