import {
  db,
  handled,
  identity,
  json,
  limit,
  settings,
  tokenHash,
} from '@/lib/mobility/server';
import { dispatch } from '@/lib/mobility/dispatch';
import { wakeDriversAfterResponse } from '@/lib/mobility/push-after';
export async function POST(request: Request) {
  return handled(async () => {
    const secret = settings().DISPATCH_SECRET;
    // Compare digests, so the answer time reveals nothing about the secret.
    const authorizedScheduler =
      Boolean(secret) &&
      (await tokenHash(request.headers.get('authorization') || '')) ===
        (await tokenHash(`Bearer ${secret}`));
    if (!authorizedScheduler) {
      const user = await identity(request);
      await limit(user.userId, 'tick', 25);
    }
    await dispatch(db());
    // Due reservations become requests here; inactive without Firebase.
    await wakeDriversAfterResponse();
    return json({ ok: true, at: Date.now() });
  });
}
