import {
  ApiError,
  body,
  db,
  handled,
  json,
  limit,
  tokenHash,
} from '@/lib/mobility/server';
import {
  freshLocation,
  nativeSessionSql,
  nativeOfferSql,
} from '@/lib/mobility/location';
import { dispatch } from '@/lib/mobility/dispatch';
import { stopNativeLocation } from '@/lib/mobility/native-stop';
import { saveNativeLocation } from '@/lib/mobility/native-upload';
export async function POST(request: Request) {
  return handled(async () => {
    const token = request.headers
      .get('authorization')
      ?.match(/^Bearer ([a-f0-9]{64})$/)?.[1];
    if (!token) throw new ApiError(401, 'Standortfreigabe fehlt.');
    const hash = await tokenHash(token),
      now = Date.now();
    const session = await db()
      .prepare(nativeSessionSql)
      .bind(hash, now)
      .first<{ driver_id: string; session_id: string }>();
    if (!session)
      throw new ApiError(
        401,
        'Standortfreigabe beendet. Bitte erneut online gehen.',
      );
    const b = await body(request);
    if (b.action === 'stop') {
      await stopNativeLocation(hash);
      // Core pause is committed. A later queue refresh cannot change its
      // acknowledgment into failure; the next ordinary dispatch may retry it.
      try {
        await dispatch(db(), Date.now());
      } catch (error) {
        console.error('Native pause dispatch refresh failed:', error);
      }
      return json({ ok: true });
    }
    if (!freshLocation(b, now))
      throw new ApiError(400, 'Standort veraltet oder zu ungenau.');
    await limit(session.driver_id, 'native-location', 90);
    const updated = await saveNativeLocation(hash, session, b);
    if (updated) {
      try {
        await dispatch(db(), now);
      } catch (error) {
        console.error('Native location dispatch refresh failed:', error);
      }
    }
    const serverTime = Date.now();
    let offer: { id: string; expiresAt: number } | null | undefined;
    try {
      offer = await db()
        .prepare(nativeOfferSql)
        .bind(
          session.driver_id,
          session.session_id,
          hash,
          serverTime,
          serverTime - 45000,
          serverTime,
        )
        .first<{ id: string; expiresAt: number }>();
    } catch (error) {
      // Omit unknown metadata, rather than inventing offer:null (withdrawal).
      // Existing native parseAlertReply ignores this GPS-only acknowledgment.
      console.error('Native location offer read failed:', error);
    }
    return json({ ok: true, updated, offer, serverTime });
  });
}
