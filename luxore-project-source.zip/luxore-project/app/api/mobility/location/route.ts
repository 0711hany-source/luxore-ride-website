import {
  ApiError,
  body,
  db,
  handled,
  json,
  limit,
  tokenHash,
} from '@/lib/mobility/server';
import { vehicleEligible } from '@/lib/mobility/vehicles';
import {
  freshLocation,
  saveNativeLocationSql,
  nativeOfferSql,
} from '@/lib/mobility/location';
import { dispatch } from '@/lib/mobility/dispatch';
export async function POST(request: Request) {
  return handled(async () => {
    const token = request.headers
      .get('authorization')
      ?.match(/^Bearer ([a-f0-9]{64})$/)?.[1];
    if (!token) throw new ApiError(401, 'Standortfreigabe fehlt.');
    const hash = await tokenHash(token),
      now = Date.now();
    const session = await db()
      .prepare(
        `SELECT s.driver_id,s.session_id FROM mobility_location_sessions s JOIN mobility_drivers d ON d.id=s.driver_id AND d.session_id=s.session_id WHERE s.token_hash=? AND s.expires_at>? AND d.approved=1 AND ${vehicleEligible('d')}`,
      )
      .bind(hash, now)
      .first<{ driver_id: string; session_id: string }>();
    if (!session)
      throw new ApiError(
        401,
        'Standortfreigabe beendet. Bitte erneut online gehen.',
      );
    const b = await body(request);
    if (b.action === 'stop') {
      await db().batch([
        db()
          .prepare(
            'UPDATE mobility_drivers SET online=0,session_id=NULL WHERE id=? AND session_id=?',
          )
          .bind(session.driver_id, session.session_id),
        db()
          .prepare('DELETE FROM mobility_location_sessions WHERE token_hash=?')
          .bind(hash),
        db()
          .prepare(
            "UPDATE mobility_offers SET status='rejected' WHERE driver_id=? AND status='pending' AND EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND online=0)",
          )
          .bind(session.driver_id, session.driver_id),
      ]);
      await dispatch(db(), now);
      return json({ ok: true });
    }
    if (!freshLocation(b, now))
      throw new ApiError(400, 'Standort veraltet oder zu ungenau.');
    await limit(session.driver_id, 'native-location', 90);
    const saved = await db()
      .prepare(saveNativeLocationSql)
      .bind(
        b.lat,
        b.lng,
        b.accuracy,
        b.timestamp,
        session.driver_id,
        session.session_id,
        b.timestamp,
        hash,
        now,
      )
      .run();
    if (saved.meta.changes) await dispatch(db(), now);
    const serverTime = Date.now();
    const offer = await db()
      .prepare(nativeOfferSql)
      .bind(
        session.driver_id,
        session.session_id,
        hash,
        serverTime,
        serverTime - 45000,
        serverTime,
      )
      .first<{ id: string; expiresAt: number }>();
    return json({ ok: true, updated: !!saved.meta.changes, offer, serverTime });
  });
}
