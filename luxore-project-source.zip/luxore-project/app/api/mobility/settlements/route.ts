import {
  ApiError,
  body,
  db,
  handled,
  identity,
  isAdmin,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import { operatorScope } from '@/lib/mobility/fleets';
import { audit } from '@/lib/mobility/accounts';
import {
  SERVICE_FEE_BPS,
  SETTLEMENT_NOTICE,
  berlinWeek,
  fleetIncome,
  markSettlementPaid,
  reopenSettlement,
  settlementFor,
  statementCsv,
  validWeek,
} from '@/lib/mobility/settlement';

function weekParam(value: string | null, now: number) {
  if (!value) return berlinWeek(now);
  if (!validWeek(value))
    throw new ApiError(400, 'Bitte eine Woche wählen (Montag als Datum).');
  if (value > berlinWeek(now))
    throw new ApiError(400, 'Diese Woche liegt in der Zukunft.');
  return value;
}
/**
 * Operator: every fleet. Owner/deputy: only the own fleet — a foreign fleetId
 * is refused, never silently replaced.
 */
export async function GET(request: Request) {
  return handled(async () => {
    const user = await identity();
    const scope = await operatorScope(user);
    if (!scope)
      throw new ApiError(
        403,
        'Abrechnungen sieht nur die Flottenleitung und der Betreiber.',
      );
    const params = new URL(request.url).searchParams;
    const now = Date.now();
    const requested = params.get('fleetId');
    if (requested && scope !== 'all' && requested !== scope)
      throw new ApiError(403, 'Diese Flotte gehört nicht zu deinem Zugang.');
    const fleetId = requested || (scope === 'all' ? null : scope);
    const base = {
      notice: SETTLEMENT_NOTICE,
      rateBps: SERVICE_FEE_BPS,
      currentWeek: berlinWeek(now),
      canSettle: isAdmin(user),
    };
    if (params.get('view') === 'income') {
      if (!fleetId) throw new ApiError(400, 'Bitte eine Flotte wählen.');
      return json({ ...base, ...(await fleetIncome(db(), fleetId, now)) });
    }
    const week = weekParam(params.get('week'), now);
    if (fleetId) {
      const fleet = await db()
        .prepare('SELECT id,name FROM mobility_fleets WHERE id=?')
        .bind(fleetId)
        .first<{ id: string; name: string }>();
      if (!fleet) throw new ApiError(404, 'Flotte nicht gefunden.');
      const settlement = await settlementFor(db(), fleet, week, now);
      if (params.get('format') === 'csv')
        return new Response(statementCsv(settlement), {
          headers: {
            'Content-Type': 'text/csv; charset=utf-8',
            'Content-Disposition': `attachment; filename="abrechnung-${week}.csv"`,
            'Cache-Control': 'private, no-store',
            'X-Content-Type-Options': 'nosniff',
          },
        });
      return json({ ...base, week, ...settlement });
    }
    // Operator overview: one line per fleet, without the single trips.
    const fleets = await db()
      .prepare('SELECT id,name FROM mobility_fleets ORDER BY name')
      .all<{ id: string; name: string }>();
    const rows = [];
    for (const fleet of fleets.results) {
      const s = await settlementFor(db(), fleet, week, now);
      rows.push({
        fleetId: fleet.id,
        fleetName: fleet.name,
        trips: s.statement.trips,
        revenue: s.statement.revenue,
        fee: s.statement.fee,
        net: s.statement.net,
        status: s.status,
        paidAt: s.paidAt,
        closed: s.closed,
      });
    }
    return json({ ...base, week, fleets: rows });
  });
}
/** Only the operator records or withdraws an incoming payment. */
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    if (!isAdmin(user))
      throw new ApiError(
        403,
        'Den Zahlungseingang vermerkt ausschließlich der Betreiber.',
      );
    await limit(user.userId, 'settlement-write', 20);
    const b = await body(request);
    const fleetId = text(b.fleetId, 100);
    if (!validWeek(b.week))
      throw new ApiError(400, 'Bitte eine Woche wählen (Montag als Datum).');
    const week = b.week;
    if (b.action !== 'mark_paid' && b.action !== 'reopen')
      throw new ApiError(400, 'Unbekannte Abrechnungsaktion.');
    await db().writeTransaction(async (transaction) => {
      if (b.action === 'mark_paid')
        await markSettlementPaid(transaction, fleetId, week, user.userId);
      else await reopenSettlement(transaction, fleetId, week);
      await audit(
        user.userId,
        fleetId,
        b.action === 'mark_paid'
          ? 'settlement.paid:' + week
          : 'settlement.reopened:' + week,
        () => transaction,
      );
    });
    return json({ ok: true });
  });
}
