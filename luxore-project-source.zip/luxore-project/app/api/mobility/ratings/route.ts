import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import { operatorScope } from '@/lib/mobility/fleets';
import {
  RATING_COMMENT_MAX,
  RATING_PUBLIC_MIN,
  RATING_WINDOW_MS,
  givenRatings,
  parseComment,
  parseStars,
  rate,
  ratingsOverview,
} from '@/lib/mobility/ratings';

const rules = {
  windowDays: RATING_WINDOW_MS / 86400000,
  publicFrom: RATING_PUBLIC_MIN,
  commentMax: RATING_COMMENT_MAX,
};
/**
 * GET              → the stars the caller has given, keyed by ride.
 * GET ?scope=staff → operator / fleet lead: averages and latest comments.
 */
export async function GET(request: Request) {
  return handled(async () => {
    const user = await identity();
    const params = new URL(request.url).searchParams;
    const view = params.get('scope');
    if (!view)
      return json({ given: await givenRatings(db(), user.userId), rules });
    if (view !== 'staff') throw new ApiError(400, 'Ungültige Anfrage.');
    const scope = await operatorScope(user);
    if (!scope)
      throw new ApiError(
        403,
        'Bewertungen sehen nur Flottenleitung und Betreiber.',
      );
    const requested = params.get('fleetId');
    if (requested && scope !== 'all' && requested !== scope)
      throw new ApiError(403, 'Diese Flotte gehört nicht zu deinem Zugang.');
    return json({
      operator: scope === 'all',
      ...(await ratingsOverview(db(), requested || scope)),
      rules,
    });
  });
}
/** { bookingId, stars: 1–5, comment? } — the side follows from the ride. */
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    const b = await body(request);
    await limit(user.userId, 'rating', 10);
    const saved = await rate(
      db(),
      user.userId,
      text(b.bookingId, 60),
      parseStars(b.stars),
      parseComment(b.comment),
    );
    return json({ ok: true, ...saved }, 201);
  });
}
