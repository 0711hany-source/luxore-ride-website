import {
  ApiError,
  body,
  db,
  handled,
  identity,
  isAdmin,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import { audit } from '@/lib/mobility/accounts';
import { createFleet } from '@/lib/mobility/fleet-creation';
import { SERVICE_FEE_BPS } from '@/lib/mobility/settlement';

const COLUMNS =
  'id,account_id,fleet_id,company,legal_form,address,contact,phone,tax_id,terms_accepted_at,status,reason,decided_at,created_at';
const optional = (value: unknown, max: number) => {
  if (value === undefined || value === null || value === '') return null;
  return text(value, max);
};
export async function GET() {
  return handled(async () => {
    const user = await identity();
    const mine = await db()
      .prepare(
        `SELECT ${COLUMNS} FROM mobility_fleet_applications WHERE account_id=? ORDER BY created_at DESC LIMIT 20`,
      )
      .bind(user.userId)
      .all();
    const membership = await db()
      .prepare(
        'SELECT f.id,f.name FROM mobility_employees e JOIN mobility_fleets f ON f.id=e.fleet_id WHERE e.user_id=?',
      )
      .bind(user.userId)
      .first();
    // Only the operator sees other people's applications.
    const all = isAdmin(user)
      ? (
          await db()
            .prepare(
              `SELECT a.id,a.account_id,a.fleet_id,a.company,a.legal_form,a.address,a.contact,a.phone,a.tax_id,a.terms_accepted_at,a.status,a.reason,a.decided_at,a.created_at,acc.email,
               (SELECT COUNT(*) FROM mobility_documents d WHERE d.subject_type='fleet' AND d.subject_id=a.fleet_id) AS papers,
               (SELECT COUNT(*) FROM mobility_documents d WHERE d.subject_type='fleet' AND d.subject_id=a.fleet_id AND d.status='approved') AS papers_approved
               FROM mobility_fleet_applications a LEFT JOIN mobility_accounts acc ON acc.id=a.account_id
               ORDER BY CASE a.status WHEN 'submitted' THEN 0 ELSE 1 END,a.created_at DESC LIMIT 100`,
            )
            .all()
        ).results
      : undefined;
    return json({
      applications: mine.results,
      all,
      fleet: membership,
      signedIn: Boolean(user.email),
      rateBps: SERVICE_FEE_BPS,
    });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit(user.userId, 'fleet-application', 6);
    const b = await body(request);
    const now = Date.now();
    if (b.action === 'apply') {
      // A device guest has no e-mail; an application needs a real account.
      if (!user.email)
        throw new ApiError(
          403,
          'Bitte zuerst mit einem LUXORÉ-Konto anmelden, um eine Flotte zu beantragen.',
        );
      const company = text(b.company, 100),
        legalForm = text(b.legalForm, 60),
        address = text(b.address, 200),
        contact = text(b.contact, 80),
        phone = text(b.phone, 30),
        taxId = optional(b.taxId, 40);
      if (!/^\+?[\d\s()-]{6,30}$/.test(phone))
        throw new ApiError(400, 'Bitte eine gültige Telefonnummer angeben.');
      if (b.accepted !== true)
        throw new ApiError(
          400,
          'Bitte die Servicepauschale von 15 % und die wöchentliche Abrechnung bestätigen.',
        );
      const id = crypto.randomUUID(),
        fleetId = crypto.randomUUID();
      await db().writeTransaction(async (transaction) => {
        if (
          (await transaction
            .prepare(
              'SELECT id FROM mobility_fleets WHERE owner_id=? OR deputy_id=?',
            )
            .bind(user.userId, user.userId)
            .first()) ||
          (await transaction
            .prepare(
              'SELECT user_id FROM mobility_employees WHERE user_id=? AND fleet_id IS NOT NULL',
            )
            .bind(user.userId)
            .first())
        )
          throw new ApiError(
            409,
            'Dein Konto gehört bereits zu einer Flotte. Ein neuer Antrag ist nicht möglich.',
          );
        if (
          await transaction
            .prepare(
              "SELECT id FROM mobility_fleet_applications WHERE account_id=? AND status='submitted'",
            )
            .bind(user.userId)
            .first()
        )
          throw new ApiError(
            409,
            'Dein Antrag liegt bereits vor und wird geprüft.',
          );
        await transaction.batch([
          transaction
            .prepare(
              "INSERT INTO mobility_fleet_applications(id,account_id,fleet_id,company,legal_form,address,contact,phone,tax_id,terms_accepted_at,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,'submitted',?)",
            )
            .bind(
              id,
              user.userId,
              fleetId,
              company,
              legalForm,
              address,
              contact,
              phone,
              taxId,
              now,
              now,
            ),
          // The existing fleet creation requires a staff or driver profile.
          transaction
            .prepare(
              "INSERT INTO mobility_employees(user_id,name,phone,role,created_at) VALUES(?,?,?,'staff',?) ON CONFLICT(user_id) DO NOTHING",
            )
            .bind(user.userId, contact, phone, now),
        ]);
      });
      return json({ id, fleetId }, 201);
    }
    const id = text(b.id, 60);
    const application = await db()
      .prepare(
        `SELECT ${COLUMNS} FROM mobility_fleet_applications WHERE id=?`,
      )
      .bind(id)
      .first<{
        id: string;
        account_id: string;
        fleet_id: string;
        company: string;
        status: string;
      }>();
    if (b.action === 'withdraw') {
      if (!application || application.account_id !== user.userId)
        throw new ApiError(404, 'Antrag nicht gefunden.');
      await db()
        .prepare(
          "UPDATE mobility_fleet_applications SET status='withdrawn',decided_at=? WHERE id=? AND account_id=? AND status='submitted'",
        )
        .bind(now, id, user.userId)
        .run();
      return json({ ok: true });
    }
    if (!isAdmin(user))
      throw new ApiError(
        403,
        'Flottenanträge prüft ausschließlich der Betreiber.',
      );
    if (!application) throw new ApiError(404, 'Antrag nicht gefunden.');
    if (b.action === 'approve') {
      if (application.status === 'approved') return json({ ok: true });
      if (application.status !== 'submitted')
        throw new ApiError(
          409,
          'Dieser Antrag wurde bereits abgelehnt oder zurückgezogen.',
        );
      // The existing atomic creation path; the pre-assigned fleet id makes a
      // repeated approval return the same fleet instead of a second one.
      await createFleet(
        user,
        application.fleet_id,
        application.company,
        application.account_id,
      );
      await db().batch([
        db()
          .prepare(
            "UPDATE mobility_fleet_applications SET status='approved',decided_by=?,decided_at=?,reason=NULL WHERE id=? AND status='submitted'",
          )
          .bind(user.userId, now, id),
        db()
          .prepare(
            "UPDATE mobility_documents SET fleet_id=? WHERE subject_type='fleet' AND subject_id=?",
          )
          .bind(application.fleet_id, application.fleet_id),
      ]);
      await audit(
        user.userId,
        application.fleet_id,
        'fleet.application_approved',
        db,
      );
      return json({ ok: true, fleetId: application.fleet_id });
    }
    if (b.action === 'reject') {
      const reason = text(b.reason, 300);
      const result = await db()
        .prepare(
          "UPDATE mobility_fleet_applications SET status='rejected',reason=?,decided_by=?,decided_at=? WHERE id=? AND status='submitted'",
        )
        .bind(reason, user.userId, now, id)
        .run();
      if (!result.meta.changes)
        throw new ApiError(409, 'Dieser Antrag wurde bereits bearbeitet.');
      await audit(
        user.userId,
        application.account_id,
        'fleet.application_rejected',
        db,
      );
      return json({ ok: true });
    }
    throw new ApiError(400, 'Unbekannte Antragsaktion.');
  });
}
