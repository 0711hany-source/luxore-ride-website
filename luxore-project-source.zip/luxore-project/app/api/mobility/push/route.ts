import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
} from '@/lib/mobility/server';
import {
  PushForbidden,
  PushInvalid,
  pushConfig,
  registerPushToken,
  removePushToken,
} from '@/lib/mobility/push';
/** The driver app asks whether registering a device is worthwhile at all. */
export async function GET() {
  return handled(async () => {
    await identity();
    return json({ enabled: Boolean(pushConfig()) });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    // The signed-in user is the only possible owner of the stored token.
    const user = await identity(request);
    await limit(user.userId, 'push', 10);
    const b = await body(request);
    if (b.action === 'unregister') {
      await removePushToken(db(), user.userId);
      return json({ ok: true });
    }
    if (b.action !== 'register') throw new ApiError(400, 'Ungültige Anfrage.');
    try {
      await registerPushToken(db(), user.userId, b.token, b.platform);
    } catch (error) {
      if (error instanceof PushForbidden)
        throw new ApiError(403, error.message);
      if (error instanceof PushInvalid) throw new ApiError(400, error.message);
      throw error;
    }
    return json({ ok: true, enabled: Boolean(pushConfig()) });
  });
}
