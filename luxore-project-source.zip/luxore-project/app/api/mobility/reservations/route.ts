import {
  ApiError,
  body,
  db,
  handled,
  identity,
  isAdmin,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import { operatorScope } from '@/lib/mobility/fleets';
import { audit } from '@/lib/mobility/accounts';
import {
  FOREIGN_FLEET_MIN_AGE_MS,
  FOREIGN_FLEET_PICKUP_WINDOW_MS,
  OVERLAP_BUFFER_MS,
  RELEASE_DEADLINE_MS,
  boardBlock,
  claimReservation,
  openReservations,
  ownFleetId,
  ownReservations,
  releaseReservation,
  setOwnFleet,
  staffReservations,
  unassignReservation,
} from '@/lib/mobility/reservations';

const rules = {
  releaseMinutes: RELEASE_DEADLINE_MS / 60000,
  bufferMinutes: OVERLAP_BUFFER_MS / 60000,
  foreignFleetAfterMinutes: FOREIGN_FLEET_MIN_AGE_MS / 60000,
  foreignFleetBeforePickupMinutes: FOREIGN_FLEET_PICKUP_WINDOW_MS / 60000,
};
/**
 * GET                → the driver's board: open reservations and own ones.
 * GET ?scope=staff   → disposition: who has taken what (operator: all).
 * GET ?scope=settings→ operator only: the own fleet.
 */
export async function GET(request: Request) {
  return handled(async () => {
    const user = await identity();
    const view = new URL(request.url).searchParams.get('scope');
    const now = Date.now();
    if (view === 'settings') {
      if (!isAdmin(user))
        throw new ApiError(
          403,
          'Dieser Bereich ist ausschließlich für den Betreiber freigegeben.',
        );
      const fleets = await db()
        .prepare('SELECT id,name FROM mobility_fleets ORDER BY name')
        .all();
      return json({
        ownFleetId: await ownFleetId(db()),
        fleets: fleets.results,
        rules,
      });
    }
    if (view === 'staff') {
      const scope = await operatorScope(user);
      if (!scope) throw new ApiError(403, 'Nur die Disposition hat Zugriff.');
      return json({
        operator: scope === 'all',
        reservations: await staffReservations(db(), scope),
        rules,
        serverTime: now,
      });
    }
    if (view) throw new ApiError(400, 'Ungültige Anfrage.');
    const block = await boardBlock(db(), user.userId);
    // Reservations taken over earlier stay visible in every state (marked,
    // and without the customer's contact while the driver is blocked), so
    // they are never held silently.
    const mine =
      !block || block.profile ? await ownReservations(db(), user.userId) : [];
    return json({
      ready: !block,
      reason: block?.reason ?? null,
      needsVehicle: block?.needsVehicle ?? false,
      open: block ? [] : await openReservations(db(), user.userId, now, mine),
      mine,
      rules,
      serverTime: now,
    });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    const b = await body(request);
    await limit(user.userId, 'reservations', 20);
    const now = Date.now();
    if (b.action === 'own-fleet') {
      if (!isAdmin(user))
        throw new ApiError(
          403,
          'Die eigene Flotte legt ausschließlich der Betreiber fest.',
        );
      const fleetId =
        b.fleetId === null || b.fleetId === '' ? null : text(b.fleetId, 60);
      await setOwnFleet(db(), fleetId, user.userId, now);
      await audit(
        user.userId,
        fleetId || user.userId,
        fleetId ? 'reservations.own_fleet' : 'reservations.own_fleet_cleared',
        db,
      );
      return json({ ok: true, ownFleetId: await ownFleetId(db()) });
    }
    const id = text(b.id, 60);
    if (b.action === 'claim')
      return json(await claimReservation(db(), user.userId, id, now));
    if (b.action === 'release') {
      await releaseReservation(db(), user.userId, id, now);
      return json({ ok: true });
    }
    if (b.action === 'unassign') {
      const scope = await operatorScope(user);
      if (!scope)
        throw new ApiError(
          403,
          'Nur Flottenleitung oder Betreiber heben eine Zuteilung auf.',
        );
      await unassignReservation(db(), scope, user.userId, id, now);
      return json({ ok: true });
    }
    throw new ApiError(400, 'Unbekannte Aktion.');
  });
}
