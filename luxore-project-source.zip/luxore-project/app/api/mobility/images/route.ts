import {
  ApiError,
  db,
  handled,
  identity,
  json,
  limit,
} from '@/lib/mobility/server';
import { operatorScope } from '@/lib/mobility/fleets';
import {
  INSPECTION_SLOTS,
  subjectAccess,
  type DocumentRow,
} from '@/lib/mobility/compliance';
import {
  MAX_DOCUMENT_IMAGES,
  MAX_IMAGE_BYTES,
  MAX_INSPECTION_IMAGES,
  checkImage,
} from '@/lib/mobility/images';
import type { AppUser } from '@/lib/identity';

type Owner = { allowed: boolean; open: boolean; max: number };
/**
 * Who may see or add photos of this owner record. Papers: operator, the fleet
 * lead of the subject, the driver for own papers. Checks: operator, the fleet
 * lead, and the person who carried the check out.
 */
async function ownerAccess(
  user: AppUser,
  ownerType: string,
  ownerId: string,
  now: number,
): Promise<Owner | null> {
  const scope = await operatorScope(user);
  if (ownerType === 'document') {
    const document = await db()
      .prepare('SELECT * FROM mobility_documents WHERE id=?')
      .bind(ownerId)
      .first<DocumentRow>();
    if (!document) return null;
    const access = await subjectAccess(
      db(),
      user.userId,
      scope,
      document.subject_type,
      document.subject_id,
    );
    return {
      allowed: access.allowed,
      open: document.status === 'submitted',
      max: MAX_DOCUMENT_IMAGES,
    };
  }
  if (ownerType === 'inspection') {
    const inspection = await db()
      .prepare(
        'SELECT fleet_id,inspector_id,created_at FROM mobility_inspections WHERE id=?',
      )
      .bind(ownerId)
      .first<{ fleet_id: string; inspector_id: string; created_at: number }>();
    if (!inspection) return null;
    return {
      allowed:
        scope === 'all' ||
        scope === inspection.fleet_id ||
        inspection.inspector_id === user.userId,
      // Photos belong to the moment of the check, not to a later day.
      open:
        inspection.inspector_id === user.userId &&
        now - inspection.created_at < 60 * 60000,
      max: MAX_INSPECTION_IMAGES,
    };
  }
  return null;
}
export async function GET(request: Request) {
  return handled(async () => {
    const user = await identity();
    const id = new URL(request.url).searchParams.get('id') || '';
    if (!id || id.length > 60) throw new ApiError(404, 'Foto nicht gefunden.');
    const image = await db()
      .prepare(
        'SELECT owner_type,owner_id,mime,data FROM mobility_images WHERE id=?',
      )
      .bind(id)
      .first<{
        owner_type: string;
        owner_id: string;
        mime: string;
        data: ArrayBuffer | Uint8Array;
      }>();
    const owner = image
      ? await ownerAccess(user, image.owner_type, image.owner_id, Date.now())
      : null;
    // Unknown and foreign photos answer alike.
    if (!image || !owner?.allowed)
      throw new ApiError(404, 'Foto nicht gefunden.');
    return new Response(new Uint8Array(image.data as ArrayBuffer), {
      headers: {
        'Content-Type': image.mime,
        'Cache-Control': 'private, no-store',
        'X-Content-Type-Options': 'nosniff',
        'Content-Disposition': 'inline',
        'Content-Security-Policy': "default-src 'none'",
      },
    });
  });
}
/** Raw image bytes in the body; owner and slot in the query string. */
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit(user.userId, 'image-upload', 20);
    const params = new URL(request.url).searchParams;
    const ownerType = params.get('ownerType') || '',
      ownerId = params.get('ownerId') || '';
    let slot = params.get('slot') || 'photo';
    if (!ownerId || ownerId.length > 60)
      throw new ApiError(400, 'Ungültige Anfrage.');
    if (Number(request.headers.get('content-length') || 0) > MAX_IMAGE_BYTES)
      throw new ApiError(
        413,
        'Das Foto ist zu groß (höchstens 400 KB). Bitte erneut aufnehmen.',
      );
    const now = Date.now();
    const owner = await ownerAccess(user, ownerType, ownerId, now);
    if (!owner?.allowed) throw new ApiError(404, 'Nicht gefunden.');
    if (!owner.open)
      throw new ApiError(
        409,
        ownerType === 'document'
          ? 'Dieses Papier wurde bereits geprüft. Bitte ein neues anlegen.'
          : 'Fotos können nur direkt nach der Kontrolle ergänzt werden.',
      );
    if (ownerType === 'inspection') {
      if (!Object.hasOwn(INSPECTION_SLOTS, slot))
        throw new ApiError(400, 'Unbekannte Fotoposition.');
    } else slot = 'photo';
    const bytes = new Uint8Array(await request.arrayBuffer());
    const checked = checkImage(bytes);
    if ('error' in checked) throw new ApiError(checked.status, checked.error);
    const id = crypto.randomUUID();
    // Count and slot are re-checked in the insert itself (concurrent uploads).
    const saved = await db()
      .prepare(
        `INSERT INTO mobility_images(id,owner_type,owner_id,slot,mime,bytes,data,uploaded_by,created_at)
         SELECT ?,?,?,?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM mobility_images WHERE owner_type=? AND owner_id=?)<?
         AND (?='photo' OR ?='extra' OR NOT EXISTS(SELECT 1 FROM mobility_images WHERE owner_type=? AND owner_id=? AND slot=?))`,
      )
      .bind(
        id,
        ownerType,
        ownerId,
        slot,
        checked.mime,
        bytes.length,
        bytes,
        user.userId,
        now,
        ownerType,
        ownerId,
        owner.max,
        slot,
        slot,
        ownerType,
        ownerId,
        slot,
      )
      .run();
    if (!saved.meta.changes)
      throw new ApiError(
        409,
        'Für diesen Eintrag sind bereits alle Fotos vorhanden.',
      );
    return json({ id, bytes: bytes.length }, 201);
  });
}
