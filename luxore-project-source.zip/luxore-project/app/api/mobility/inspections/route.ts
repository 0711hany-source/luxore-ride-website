import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import { operatorScope } from '@/lib/mobility/fleets';
import {
  INSPECTION_ITEMS,
  INSPECTION_SLOTS,
  actorName,
  vehicleInspection,
  type InspectionItem,
} from '@/lib/mobility/compliance';

/** Fleet lead, operator, or the driver currently assigned to the vehicle. */
async function vehicleAccess(userId: string, vehicleId: string) {
  const vehicle = await db()
    .prepare(
      `SELECT v.id,v.fleet_id,v.model,v.plate,v.status,
       EXISTS(SELECT 1 FROM mobility_drivers d JOIN mobility_employees e ON e.user_id=d.id AND e.fleet_id=v.fleet_id WHERE d.id=? AND d.vehicle_id=v.id AND d.approved=1) AS assigned
       FROM mobility_vehicles v WHERE v.id=?`,
    )
    .bind(userId, vehicleId)
    .first<{
      id: string;
      fleet_id: string;
      model: string;
      plate: string;
      status: string;
      assigned: number;
    }>();
  return vehicle;
}
export async function GET(request: Request) {
  return handled(async () => {
    const user = await identity();
    const scope = await operatorScope(user);
    const vehicleId = new URL(request.url).searchParams.get('vehicleId') || '';
    const vehicle = vehicleId.length <= 100 ? await vehicleAccess(user.userId, vehicleId) : null;
    const lead = !!vehicle && (scope === 'all' || scope === vehicle.fleet_id);
    if (!vehicle || (!lead && !vehicle.assigned))
      throw new ApiError(404, 'Fahrzeug nicht gefunden.');
    const rows = await db()
      .prepare(
        'SELECT id,inspector_id,inspector_name,result,items,odometer,created_at FROM mobility_inspections WHERE vehicle_id=? ORDER BY created_at DESC LIMIT 20',
      )
      .bind(vehicleId)
      .all<{
        id: string;
        inspector_id: string;
        inspector_name: string;
        result: string;
        items: string;
        odometer: number | null;
        created_at: number;
      }>();
    const images = rows.results.length
      ? (
          await db()
            .prepare(
              `SELECT id,owner_id,slot FROM mobility_images WHERE owner_type='inspection' AND owner_id IN (${rows.results.map(() => '?').join(',')}) ORDER BY created_at`,
            )
            .bind(...rows.results.map((r) => r.id))
            .all<{ id: string; owner_id: string; slot: string }>()
        ).results
      : [];
    return json({
      vehicle: { id: vehicle.id, model: vehicle.model, plate: vehicle.plate },
      state: await vehicleInspection(db(), vehicleId, Date.now()),
      items: INSPECTION_ITEMS,
      slots: INSPECTION_SLOTS,
      inspections: rows.results.map((r) => ({
        id: r.id,
        inspectorName: r.inspector_name,
        result: r.result,
        items: JSON.parse(r.items),
        odometer: r.odometer,
        createdAt: r.created_at,
        // A driver sees only photos of checks he carried out himself.
        images:
          lead || r.inspector_id === user.userId
            ? images
                .filter((i) => i.owner_id === r.id)
                .map((i) => ({ id: i.id, slot: i.slot }))
            : [],
      })),
    });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit(user.userId, 'inspection-write', 10);
    const b = await body(request);
    if (b.action !== 'create')
      throw new ApiError(400, 'Unbekannte Kontrollaktion.');
    const vehicleId = text(b.vehicleId, 100);
    const scope = await operatorScope(user);
    const vehicle = await vehicleAccess(user.userId, vehicleId);
    if (
      !vehicle ||
      !(scope === 'all' || scope === vehicle.fleet_id || vehicle.assigned)
    )
      throw new ApiError(404, 'Fahrzeug nicht gefunden.');
    if (vehicle.status !== 'active')
      throw new ApiError(409, 'Dieses Fahrzeug ist archiviert.');
    const input =
      b.items && typeof b.items === 'object' && !Array.isArray(b.items)
        ? (b.items as Record<string, unknown>)
        : null;
    if (!input) throw new ApiError(400, 'Bitte alle Punkte der Kontrolle ausfüllen.');
    const items: Record<string, { ok: boolean; note: string }> = {};
    for (const key of Object.keys(INSPECTION_ITEMS) as InspectionItem[]) {
      const value = input[key] as { ok?: unknown; note?: unknown } | undefined;
      if (!value || typeof value.ok !== 'boolean')
        throw new ApiError(
          400,
          `Bitte „${INSPECTION_ITEMS[key]}“ als in Ordnung oder Mangel markieren.`,
        );
      const note =
        typeof value.note === 'string' ? value.note.trim().slice(0, 200) : '';
      if (!value.ok && !note)
        throw new ApiError(
          400,
          `Bitte den Mangel bei „${INSPECTION_ITEMS[key]}“ kurz beschreiben.`,
        );
      items[key] = { ok: value.ok, note };
    }
    const odometer =
      b.odometer === undefined || b.odometer === null || b.odometer === ''
        ? null
        : Number(b.odometer);
    if (
      odometer !== null &&
      (!Number.isInteger(odometer) || odometer < 0 || odometer > 5_000_000)
    )
      throw new ApiError(400, 'Bitte einen gültigen Kilometerstand angeben.');
    const result = Object.values(items).every((i) => i.ok) ? 'ok' : 'defect';
    const id = crypto.randomUUID();
    await db()
      .prepare(
        'INSERT INTO mobility_inspections(id,vehicle_id,fleet_id,inspector_id,inspector_name,result,items,odometer,created_at) VALUES(?,?,?,?,?,?,?,?,?)',
      )
      .bind(
        id,
        vehicleId,
        vehicle.fleet_id,
        user.userId,
        await actorName(db(), user),
        result,
        JSON.stringify(items),
        odometer,
        Date.now(),
      )
      .run();
    return json({ id, result }, 201);
  });
}
