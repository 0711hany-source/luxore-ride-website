import { operatorScope } from '@/lib/mobility/fleets';
import { headers } from 'next/headers';
import { sessionAccount, publicAccount } from '@/lib/mobility/accounts';
import {
  handled,
  identity,
  isAdmin,
  json,
  settings,
} from '@/lib/mobility/server';
export async function GET() {
  return handled(async () => {
    const user = await identity();
    const s = settings();
    const account = await sessionAccount(await headers());
    return json({
      authenticated: true,
      userId: user.userId,
      account: account ? publicAccount(account) : null,
      name: user.displayName,
      isAdmin: isAdmin(user),
      canDispatch: Boolean(await operatorScope(user)),
      mapsReady: Boolean(
        s.MAPBOX_ACCESS_TOKEN && s.MAPBOX_PUBLIC_TOKEN?.startsWith('pk.'),
      ),
      publicMapToken: s.MAPBOX_PUBLIC_TOKEN?.startsWith('pk.')
        ? s.MAPBOX_PUBLIC_TOKEN
        : null,
      mode: 'company-test',
      refreshSeconds: 3,
    });
  });
}
