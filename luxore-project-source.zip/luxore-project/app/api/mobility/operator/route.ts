import {
  ApiError,
  body,
  handled,
  identity,
  isAdmin,
  json,
  limit,
  settings,
  text,
} from '@/lib/mobility/server';
import {
  accountDb as db,
  assertAccountIdle,
  audit,
  mailReady,
  type Account,
} from '@/lib/mobility/accounts';
import { berlinDayStart } from '@/lib/mobility/time';

async function operator(request?: Request) {
  const user = await identity(request, db);
  if (!isAdmin(user))
    throw new ApiError(
      403,
      'Dieser Bereich ist ausschließlich für den Betreiber freigegeben.',
    );
  return user;
}
export async function GET(request: Request) {
  return handled(async () => {
    await operator();
    const params = new URL(request.url).searchParams;
    const page = Math.max(
      0,
      Math.min(1000, Number.parseInt(params.get('page') || '0', 10) || 0),
    );
    const q = (params.get('q') || '').trim().slice(0, 80);
    const filter = params.get('filter') || 'all';
    if (!['all', 'pending', 'blocked', 'deletion'].includes(filter))
      throw new ApiError(400, 'Ungültiger Filter.');
    const where = `(?='' OR a.name LIKE ? ESCAPE '\\' OR a.email LIKE ? ESCAPE '\\') AND
      (?='all' OR (?='pending' AND d.id IS NOT NULL AND d.approved=0 AND a.status='active') OR (?='blocked' AND a.status='blocked') OR (?='deletion' AND a.status='deletion_pending'))`;
    const like = '%' + q.replace(/[\\%_]/g, '\\$&') + '%';
    const values = [q, like, like, filter, filter, filter, filter];
    const [summary, profiles, count, pending, auditLog] = await Promise.all([
      db()
        .prepare(`SELECT
        (SELECT COUNT(*) FROM mobility_accounts) AS accounts,
        (SELECT COUNT(*) FROM mobility_drivers) AS drivers,
        (SELECT COUNT(*) FROM mobility_drivers WHERE approved=0) AS pending,
        (SELECT COUNT(*) FROM mobility_drivers WHERE online=1 AND location_at>?) AS online,
        (SELECT COUNT(*) FROM mobility_fleets) AS fleets,
        (SELECT COUNT(*) FROM mobility_vehicles WHERE status='active') AS vehicles,
        (SELECT COUNT(*) FROM mobility_bookings WHERE status IN ('requesting','accepted','arrived','riding')) AS activeTrips,
        (SELECT COUNT(*) FROM mobility_bookings WHERE status='reserved') AS reservations,
        (SELECT COALESCE(SUM(price),0) FROM mobility_bookings WHERE status='completed' AND completed_at>=?) AS todayRevenue,
        (SELECT COALESCE(SUM(price),0) FROM mobility_bookings WHERE status='completed' AND payment_status='unpaid') AS outstanding,
        (SELECT COUNT(*) FROM mobility_accounts WHERE status='deletion_pending') AS deletions`)
        .bind(Date.now() - 20000, berlinDayStart())
        .first(),
      db()
        .prepare(`SELECT a.id,a.email,a.name,a.phone,a.kind,a.status,a.created_at,a.verified_at,a.deletion_requested_at,d.approved,d.online,d.plate,e.fleet_id,f.name AS fleet_name
        FROM mobility_accounts a LEFT JOIN mobility_drivers d ON d.id=a.id LEFT JOIN mobility_employees e ON e.user_id=a.id LEFT JOIN mobility_fleets f ON f.id=e.fleet_id
        WHERE ${where} ORDER BY a.created_at DESC,a.id LIMIT 20 OFFSET ?`)
        .bind(...values, page * 20)
        .all(),
      db()
        .prepare(
          `SELECT COUNT(*) AS total FROM mobility_accounts a LEFT JOIN mobility_drivers d ON d.id=a.id WHERE ${where}`,
        )
        .bind(...values)
        .first(),
      db()
        .prepare(`SELECT d.id,d.name,d.phone,d.plate,e.fleet_id,f.name AS fleet_name,a.status AS account_status FROM mobility_drivers d
        LEFT JOIN mobility_employees e ON e.user_id=d.id LEFT JOIN mobility_fleets f ON f.id=e.fleet_id LEFT JOIN mobility_accounts a ON a.id=d.id
        WHERE d.approved=0 AND (a.status IS NULL OR a.status='active') ORDER BY d.name,d.id LIMIT 100`)
        .all(),
      db()
        .prepare(
          `SELECT l.action,l.subject_id,l.created_at,COALESCE(a.name,d.name,f.name,'Profil') AS subject_name,COALESCE(actor.name,ad.name,'Betreiber') AS actor_name FROM mobility_operator_audit l LEFT JOIN mobility_accounts a ON a.id=l.subject_id LEFT JOIN mobility_drivers d ON d.id=l.subject_id LEFT JOIN mobility_fleets f ON f.id=l.subject_id LEFT JOIN mobility_accounts actor ON actor.id=l.actor_id LEFT JOIN mobility_drivers ad ON ad.id=l.actor_id ORDER BY l.created_at DESC LIMIT 30`,
        )
        .all(),
    ]);
    return json({
      summary,
      profiles: profiles.results,
      total: count,
      page,
      pending: pending.results,
      audit: auditLog.results,
      readiness: {
        accounts: mailReady(),
        maps: Boolean(
          settings().MAPBOX_ACCESS_TOKEN && settings().MAPBOX_PUBLIC_TOKEN,
        ),
        stores: false,
        cardPayments: false,
        backgroundDeviceTest: false,
      },
      refreshedAt: Date.now(),
    });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await operator(request);
    await limit(user.userId, 'operator-write', 20, db);
    const b = await body(request);
    const id = text(b.accountId, 100);
    const account = await db()
      .prepare('SELECT * FROM mobility_accounts WHERE id=?')
      .bind(id)
      .first<Account>();
    if (!account) throw new ApiError(404, 'Konto nicht gefunden.');
    if (
      isAdmin({
        userId: id,
        email: account.email,
        displayName: account.name,
        fullName: account.name,
      })
    )
      throw new ApiError(
        409,
        'Der Betreiberzugang kann hier nicht gesperrt oder gelöscht werden.',
      );
    if (b.action === 'restore') {
      if (account.status !== 'blocked')
        throw new ApiError(
          409,
          'Nur gesperrte Konten können entsperrt werden.',
        );
      await db()
        .prepare(
          "UPDATE mobility_accounts SET status='active' WHERE id=? AND status='blocked'",
        )
        .bind(id)
        .run();
      await audit(user.userId, id, 'account.restored');
      return json({ ok: true });
    }
    if (b.action !== 'block' && b.action !== 'erase')
      throw new ApiError(400, 'Unbekannte Betreiberaktion.');
    await assertAccountIdle(id);
    if (b.action === 'erase' && account.status !== 'deletion_pending')
      throw new ApiError(
        409,
        'Es liegt keine Löschanfrage für dieses Konto vor.',
      );
    if (b.action === 'erase' && b.confirmation !== 'LÖSCHEN')
      throw new ApiError(400, 'Bitte die Löschung ausdrücklich bestätigen.');
    if (
      b.action === 'erase' &&
      (await db()
        .prepare('SELECT id FROM mobility_fleets WHERE owner_id=?')
        .bind(id)
        .first())
    )
      throw new ApiError(
        409,
        'Der Flottenbesitzer muss zuerst auf einen anderen Mitarbeiter übertragen werden. Die Löschanfrage bleibt offen.',
      );
    const state = await db()
      .prepare(`UPDATE mobility_accounts SET status=? WHERE id=? AND status=?
      AND NOT EXISTS(SELECT 1 FROM mobility_bookings WHERE (owner_id=? AND status IN ('requesting','accepted','arrived','riding')) OR (driver_id=? AND (status IN ('accepted','arrived','riding') OR (status='completed' AND payment_status='unpaid'))))
      AND NOT EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND (online=1 OR session_id IS NOT NULL)) RETURNING id`)
      .bind(
        b.action === 'erase' ? 'deletion_pending' : 'blocked',
        id,
        account.status,
        id,
        id,
        id,
      )
      .first();
    if (!state)
      throw new ApiError(
        409,
        'Das Profil wurde inzwischen geändert oder ist im Einsatz. Bitte neu laden.',
      );
    await db().batch([
      db()
        .prepare('DELETE FROM mobility_account_sessions WHERE account_id=?')
        .bind(id),
      db().prepare('DELETE FROM mobility_sessions WHERE user_id=?').bind(id),
      db()
        .prepare('DELETE FROM mobility_location_sessions WHERE driver_id=?')
        .bind(id),
      db()
        .prepare(
          'UPDATE mobility_drivers SET approved=0,online=0,session_id=NULL WHERE id=?',
        )
        .bind(id),
      db()
        .prepare(
          "UPDATE mobility_offers SET status='withdrawn' WHERE driver_id=? AND status='pending'",
        )
        .bind(id),
    ]);
    if (b.action === 'erase') {
      const deletedId = 'deleted:' + crypto.randomUUID();
      await db().batch([
        db().prepare('DELETE FROM mobility_places WHERE owner_id=?').bind(id),
        db().prepare('DELETE FROM mobility_quotes WHERE owner_id=?').bind(id),
        db()
          .prepare('DELETE FROM mobility_account_challenges WHERE email=?')
          .bind(account.email),
        db()
          .prepare(
            "UPDATE mobility_stock_movements SET actor_name='Gelöschtes Profil' WHERE actor_id=?",
          )
          .bind(id),
        db()
          .prepare(
            'UPDATE mobility_bookings SET owner_id=?,rider_name=NULL,rider_phone=NULL,rider_preferences=NULL,rider_lat=NULL,rider_lng=NULL,rider_location_at=NULL,rider_share_id=NULL WHERE owner_id=?',
          )
          .bind(deletedId, id),
        db()
          .prepare(
            "UPDATE mobility_drivers SET name='Gelöschtes Profil',phone='',lat=NULL,lng=NULL,accuracy=NULL,location_at=NULL,vehicle_id=NULL,vehicle='',plate='' WHERE id=?",
          )
          .bind(id),
        db()
          .prepare(
            "UPDATE mobility_employees SET name='Gelöschtes Profil',phone='',fleet_id=NULL WHERE user_id=?",
          )
          .bind(id),
        db()
          .prepare(
            'UPDATE mobility_fleets SET deputy_id=NULL WHERE deputy_id=?',
          )
          .bind(id),
        db()
          .prepare(
            "DELETE FROM mobility_accounts WHERE id=? AND status='deletion_pending'",
          )
          .bind(id),
      ]);
    }
    await audit(
      user.userId,
      id,
      b.action === 'erase' ? 'account.erased' : 'account.blocked',
    );
    return json({ ok: true });
  });
}
