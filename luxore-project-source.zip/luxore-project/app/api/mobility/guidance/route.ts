import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import { route } from '@/lib/mobility/provider';
import { reliableCourse } from '@/lib/mobility/gps-telemetry';
import type { RouteData } from '@/lib/mobility/domain';
import { usableFix, type GpsFix } from '@/app/mobility/gps-quality';
import { storedApproach } from '@/lib/mobility/approach';
type Assigned = { route: string; status: 'accepted' | 'riding' };
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    const b = await body(request);
    const bookingId = text(b.bookingId, 100);
    const fix = b.position as GpsFix | null;
    if (!usableFix(fix, Date.now()) || fix.accuracy > 50)
      throw new ApiError(
        400,
        'Für die Navigation wird ein frischer, genauer Standort benötigt.',
      );
    const assigned = () =>
      db()
        .prepare(
          "SELECT b.route,b.status FROM mobility_bookings b JOIN mobility_drivers d ON d.id=b.driver_id AND d.approved=1 WHERE b.id=? AND b.driver_id=? AND b.status IN ('accepted','riding')",
        )
        .bind(bookingId, user.userId)
        .first<Assigned>();
    const booking = await assigned();
    if (!booking)
      throw new ApiError(
        403,
        'Navigation ist nur für deine laufende Fahrt verfügbar.',
      );
    await limit(user.userId, 'traffic-guidance', 4);
    const booked = JSON.parse(booking.route) as RouteData;
    const destination =
      booking.status === 'accepted' ? booked.pickup : booked.destination;
    const guidance = await route(
      {
        id: 'driver-position',
        label: 'Dein Standort',
        lat: fix.lat,
        lng: fix.lng,
      },
      destination,
      null,
      reliableCourse(fix),
      true,
    );
    const current = await assigned();
    if (
      !current ||
      current.status !== booking.status ||
      current.route !== booking.route
    )
      throw new ApiError(
        409,
        'Die Fahrt hat sich geändert. Route wird aktualisiert.',
      );
    // The customer sees the way the chauffeur really drives to the pickup
    // point: the route the driver app has just paid for is kept at the ride.
    // Best effort only – a database without the column (migration 0023) or a
    // failed write must never disturb the driver's navigation.
    try {
      if (booking.status === 'accepted')
        await db()
          .prepare(
            "UPDATE mobility_bookings SET approach_route=? WHERE id=? AND driver_id=? AND status='accepted'",
          )
          .bind(
            storedApproach(guidance.geometry, Date.now()),
            bookingId,
            user.userId,
          )
          .run();
      else
        await db()
          .prepare(
            'UPDATE mobility_bookings SET approach_route=NULL WHERE id=? AND driver_id=? AND approach_route IS NOT NULL',
          )
          .bind(bookingId, user.userId)
          .run();
    } catch {}
    // Guidance never updates the original quote, fare or booking route.
    return json({ bookingId, phase: booking.status, route: guidance });
  });
}
