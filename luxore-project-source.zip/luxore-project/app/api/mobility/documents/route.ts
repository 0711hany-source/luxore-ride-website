import {
  ApiError,
  body,
  db,
  handled,
  identity,
  isAdmin,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import { operatorScope } from '@/lib/mobility/fleets';
import { audit } from '@/lib/mobility/accounts';
import { berlinDate } from '@/lib/mobility/settlement';
import {
  DOCUMENT_KINDS,
  isSubjectType,
  paperStates,
  parseExpiry,
  purgeStatements,
  subjectAccess,
  type DocumentRow,
} from '@/lib/mobility/compliance';

const SUBJECT_NAME = `CASE d.subject_type
  WHEN 'driver' THEN (SELECT name FROM mobility_drivers WHERE id=d.subject_id)
  WHEN 'vehicle' THEN (SELECT model||' · '||plate FROM mobility_vehicles WHERE id=d.subject_id)
  ELSE COALESCE((SELECT name FROM mobility_fleets WHERE id=d.subject_id),(SELECT company||' (Antrag)' FROM mobility_fleet_applications WHERE fleet_id=d.subject_id)) END`;
async function withImages<T extends { id: string }>(documents: T[]) {
  if (!documents.length) return [];
  const images = await db()
    .prepare(
      `SELECT id,owner_id,slot,bytes FROM mobility_images WHERE owner_type='document' AND owner_id IN (${documents.map(() => '?').join(',')}) ORDER BY created_at`,
    )
    .bind(...documents.map((d) => d.id))
    .all<{ id: string; owner_id: string; slot: string; bytes: number }>();
  return documents.map((d) => ({
    ...d,
    images: images.results
      .filter((i) => i.owner_id === d.id)
      .map((i) => ({ id: i.id, bytes: i.bytes })),
  }));
}
export async function GET(request: Request) {
  return handled(async () => {
    const user = await identity();
    const scope = await operatorScope(user);
    const params = new URL(request.url).searchParams;
    if (params.get('scope') === 'review') {
      if (!isAdmin(user))
        throw new ApiError(403, 'Papiere prüft ausschließlich der Betreiber.');
      const rows = await db()
        .prepare(
          `SELECT d.*,${SUBJECT_NAME} AS subject_name,f.name AS fleet_name FROM mobility_documents d LEFT JOIN mobility_fleets f ON f.id=d.fleet_id
           WHERE d.status='submitted' ORDER BY d.created_at LIMIT 100`,
        )
        .all<DocumentRow>();
      return json({ documents: await withImages(rows.results), kinds: DOCUMENT_KINDS });
    }
    const type = params.get('subjectType'),
      id = params.get('subjectId') || '';
    if (!isSubjectType(type) || !id || id.length > 100)
      throw new ApiError(400, 'Ungültige Anfrage.');
    const access = await subjectAccess(db(), user.userId, scope, type, id);
    // Same answer for "not there" and "not yours": no hint about other fleets.
    if (!access.allowed) throw new ApiError(404, 'Nicht gefunden.');
    const rows = await db()
      .prepare(
        'SELECT * FROM mobility_documents WHERE subject_type=? AND subject_id=? ORDER BY created_at DESC LIMIT 60',
      )
      .bind(type, id)
      .all<DocumentRow>();
    return json({
      papers: paperStates(type, rows.results, berlinDate(Date.now())),
      documents: await withImages(rows.results),
      kinds: DOCUMENT_KINDS[type],
      canReview: isAdmin(user),
    });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit(user.userId, 'document-write', 20);
    const b = await body(request);
    const scope = await operatorScope(user);
    const now = Date.now();
    if (b.action === 'create') {
      const type = b.subjectType,
        id = text(b.subjectId, 100);
      if (!isSubjectType(type)) throw new ApiError(400, 'Ungültige Anfrage.');
      const rule =
        typeof b.kind === 'string' && Object.hasOwn(DOCUMENT_KINDS[type], b.kind)
          ? DOCUMENT_KINDS[type][b.kind]
          : null;
      if (!rule) throw new ApiError(400, 'Unbekannte Dokumentart.');
      const access = await subjectAccess(db(), user.userId, scope, type, id);
      if (!access.allowed) throw new ApiError(404, 'Nicht gefunden.');
      const number =
        b.number === undefined || b.number === null || b.number === ''
          ? null
          : text(b.number, 60);
      const expiresOn = parseExpiry(b.expiresOn, rule);
      const documentId = crypto.randomUUID();
      // At most three unreviewed entries per paper keep the review list usable.
      const created = await db()
        .prepare(
          `INSERT INTO mobility_documents(id,subject_type,subject_id,fleet_id,kind,number,expires_on,status,uploaded_by,created_at)
           SELECT ?,?,?,?,?,?,?,'submitted',?,? WHERE (SELECT COUNT(*) FROM mobility_documents WHERE subject_type=? AND subject_id=? AND kind=? AND status='submitted')<3`,
        )
        .bind(
          documentId,
          type,
          id,
          access.fleetId ?? (type === 'fleet' ? id : null),
          b.kind,
          number,
          expiresOn,
          user.userId,
          now,
          type,
          id,
          b.kind,
        )
        .run();
      if (!created.meta.changes)
        throw new ApiError(
          409,
          'Für dieses Papier warten schon mehrere Einträge auf die Prüfung. Bitte einen alten Eintrag löschen.',
        );
      return json({ id: documentId }, 201);
    }
    if (b.action === 'purge') {
      const type = b.subjectType,
        id = text(b.subjectId, 100);
      if (!isSubjectType(type) || type === 'fleet')
        throw new ApiError(400, 'Ungültige Anfrage.');
      const access = await subjectAccess(db(), user.userId, scope, type, id);
      if (!access.allowed || !scope || (type === 'driver' && scope !== 'all'))
        throw new ApiError(404, 'Nicht gefunden.');
      if (
        type === 'vehicle' &&
        !(await db()
          .prepare(
            "SELECT id FROM mobility_vehicles WHERE id=? AND status='archived'",
          )
          .bind(id)
          .first())
      )
        throw new ApiError(
          409,
          'Papiere und Kontrollen können erst gelöscht werden, wenn das Fahrzeug archiviert ist.',
        );
      await db().batch(purgeStatements(db(), type, id));
      await audit(user.userId, id, 'documents.purged:' + type, db);
      return json({ ok: true });
    }
    const documentId = text(b.id, 60);
    const document = await db()
      .prepare('SELECT * FROM mobility_documents WHERE id=?')
      .bind(documentId)
      .first<DocumentRow>();
    if (b.action === 'review') {
      if (!isAdmin(user))
        throw new ApiError(403, 'Papiere prüft ausschließlich der Betreiber.');
      if (!document) throw new ApiError(404, 'Dokument nicht gefunden.');
      if (b.decision !== 'approved' && b.decision !== 'rejected')
        throw new ApiError(400, 'Bitte freigeben oder ablehnen.');
      const rule = DOCUMENT_KINDS[document.subject_type]?.[document.kind];
      if (!rule) throw new ApiError(400, 'Unbekannte Dokumentart.');
      const reason = b.decision === 'rejected' ? text(b.reason, 300) : null;
      // The reviewer may correct the date read from the photo.
      const expiresOn =
        b.decision === 'approved'
          ? parseExpiry(b.expiresOn ?? document.expires_on, rule)
          : document.expires_on;
      if (
        b.decision === 'approved' &&
        !(await db()
          .prepare(
            "SELECT id FROM mobility_images WHERE owner_type='document' AND owner_id=? LIMIT 1",
          )
          .bind(documentId)
          .first())
      )
        throw new ApiError(
          409,
          'Ohne Foto kann dieses Papier nicht freigegeben werden.',
        );
      await db()
        .prepare(
          'UPDATE mobility_documents SET status=?,reason=?,expires_on=?,reviewed_by=?,reviewed_at=? WHERE id=?',
        )
        .bind(b.decision, reason, expiresOn, user.userId, now, documentId)
        .run();
      await audit(
        user.userId,
        document.subject_id,
        `document.${b.decision}:${document.kind}`,
        db,
      );
      return json({ ok: true });
    }
    if (b.action === 'delete') {
      const access = document
        ? await subjectAccess(
            db(),
            user.userId,
            scope,
            document.subject_type,
            document.subject_id,
          )
        : null;
      if (!document || !access?.allowed)
        throw new ApiError(404, 'Dokument nicht gefunden.');
      if (document.status === 'approved' && !isAdmin(user))
        throw new ApiError(
          409,
          'Ein geprüftes Papier kann nur der Betreiber entfernen. Lade stattdessen ein neues hoch.',
        );
      await db().batch([
        db()
          .prepare(
            "DELETE FROM mobility_images WHERE owner_type='document' AND owner_id=?",
          )
          .bind(documentId),
        db().prepare('DELETE FROM mobility_documents WHERE id=?').bind(documentId),
      ]);
      return json({ ok: true });
    }
    throw new ApiError(400, 'Unbekannte Dokumentaktion.');
  });
}
