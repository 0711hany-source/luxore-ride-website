import { headers } from 'next/headers';
import {
  accountDb,
  cookieToken,
  sessionAccount,
  setAccountCookie,
} from '@/lib/mobility/accounts';
import {
  ApiError,
  body,
  checkOrigin,
  handled,
  limit,
} from '@/lib/mobility/server';
import { appSessionTarget } from '@/lib/mobility/app-targets';


async function transfer(request: Request, target: unknown) {
  const h = await headers();
  // Only an explicit, verified native bearer may create the browser cookie.
  // A browser navigation carrying existing cookies alone is not sufficient.
  const account = h.get('authorization') ? await sessionAccount(h) : null;
  if (!account)
    throw new ApiError(401, 'Bitte erneut mit deinem LUXORÉ-Konto anmelden.');
  // Fixed screens, plus /pruefung with its validated parameters. The path is
  // rebuilt by the allow-list, never taken over from the request.
  const path = appSessionTarget(target);
  if (!path) throw new ApiError(400, 'Ungültiger App-Bildschirm.');
  const token = cookieToken(h)!;
  await limit(account.id, 'app-session', 20, accountDb);
  const response = new Response(null, {
    status: 303,
    headers: {
      Location: new URL(path, new URL(request.url).origin).toString(),
      'Cache-Control': 'private, no-store',
      'Referrer-Policy': 'no-referrer',
    },
  });
  setAccountCookie(response, request, token);
  return response;
}

/** Android WebView preserves custom headers only for GET source requests. */
export async function GET(request: Request) {
  return handled(async () => {
    const origin = request.headers.get('origin');
    if (
      (origin !== null && origin !== new URL(request.url).origin) ||
      request.headers.get('sec-fetch-site') === 'cross-site'
    )
      throw new ApiError(403, 'Anfrageursprung nicht erlaubt.');
    return transfer(request, new URL(request.url).searchParams.get('target'));
  });
}

/** Transfer an authenticated native session to embedded trip screens without URL/JS credentials. */
export async function POST(request: Request) {
  return handled(async () => {
    checkOrigin(request);
    const b = await body(request);
    return transfer(request, b.target);
  });
}
