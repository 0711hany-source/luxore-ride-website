import { headers } from 'next/headers';
import {
  accountDb,
  cookieToken,
  sessionAccount,
  setAccountCookie,
} from '@/lib/mobility/accounts';
import {
  ApiError,
  body,
  checkOrigin,
  handled,
  limit,
} from '@/lib/mobility/server';

/** Transfer an authenticated native session to embedded trip screens without URL/JS credentials. */
export async function POST(request: Request) {
  return handled(async () => {
    checkOrigin(request);
    const h = await headers();
    const account = h.get('authorization') ? await sessionAccount(h) : null;
    if (!account)
      throw new ApiError(401, 'Bitte erneut mit deinem Luxóre-Konto anmelden.');
    const b = await body(request);
    const targets = [
      '/mobile/customer',
      '/mobile/driver',
      '/disposition',
      '/betreiber',
    ];
    if (typeof b.target !== 'string' || !targets.includes(b.target))
      throw new ApiError(400, 'Ungültiger App-Bildschirm.');
    const token = cookieToken(h)!;
    await limit(account.id, 'app-session', 20, accountDb);
    const response = new Response(null, {
      status: 303,
      headers: {
        Location: new URL(b.target, request.url).toString(),
        'Cache-Control': 'private, no-store',
        'Referrer-Policy': 'no-referrer',
      },
    });
    setAccountCookie(response, request, token);
    return response;
  });
}
