import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import {
  departure,
  distance,
  fare,
  type Point,
  type Quote,
} from '@/lib/mobility/domain';
import { route } from '@/lib/mobility/provider';
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit('public', 'public-quotes', 60);
    await limit(user.userId, 'quote', 10);
    const b = await body(request);
    const p = await db()
      .prepare(
        'SELECT id,label,lat,lng FROM mobility_places WHERE id=? AND owner_id=?',
      )
      .bind(text(b.pickupId), user.userId)
      .first<Point>();
    const d = await db()
      .prepare(
        'SELECT id,label,lat,lng FROM mobility_places WHERE id=? AND owner_id=?',
      )
      .bind(text(b.destinationId), user.userId)
      .first<Point>();
    if (!p || !d)
      throw new ApiError(
        400,
        'Bitte Abholort und Ziel aus der Adresssuche auswählen.',
      );
    if (distance(p, d) < 30)
      throw new ApiError(400, 'Abholort und Ziel liegen zu nah beieinander.');
    let scheduledAt: number | null;
    try {
      scheduledAt = departure(b.mode, b.scheduledAt, Date.now());
    } catch (e) {
      throw new ApiError(400, (e as Error).message);
    }
    const r = await route(p, d, scheduledAt);
    const q: Quote = {
      ...r,
      id: crypto.randomUUID(),
      expiresAt: Date.now() + 5 * 60000,
      prices: {
        premium: fare(r.distanceMeters, 'premium'),
        first: fare(r.distanceMeters, 'first'),
        van: fare(r.distanceMeters, 'van'),
      },
      mode: b.mode as Quote['mode'],
      scheduledAt,
    };
    await db()
      .prepare(
        'INSERT INTO mobility_quotes(id,owner_id,payload,expires_at) VALUES(?,?,?,?)',
      )
      .bind(q.id, user.userId, JSON.stringify(q), q.expiresAt)
      .run();
    return json(q);
  });
}
