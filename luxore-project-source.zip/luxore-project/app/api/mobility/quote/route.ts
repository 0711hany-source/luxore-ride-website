import {
  ApiError,
  body,
  db,
  handled,
  identity,
  json,
  limit,
  text,
} from '@/lib/mobility/server';
import {
  departure,
  distance,
  fares,
  type Point,
  type Quote,
} from '@/lib/mobility/domain';
import { route } from '@/lib/mobility/provider';
import { classArrival, classAvailability } from '@/lib/mobility/availability';
import { knownPlace } from '@/lib/mobility/known-place';
export async function POST(request: Request) {
  return handled(async () => {
    const user = await identity(request);
    await limit('public', 'public-quotes', 60);
    await limit(user.userId, 'quote', 10);
    const b = await body(request);
    const p = await knownPlace(db(), text(b.pickupId), user.userId);
    const d = await knownPlace(db(), text(b.destinationId), user.userId);
    if (!p || !d)
      throw new ApiError(
        400,
        'Bitte Abholort und Ziel aus der Adresssuche auswählen.',
      );
    if (distance(p, d) < 30)
      throw new ApiError(400, 'Abholort und Ziel liegen zu nah beieinander.');
    let scheduledAt: number | null;
    try {
      scheduledAt = departure(b.mode, b.scheduledAt, Date.now());
    } catch (e) {
      throw new ApiError(400, (e as Error).message);
    }
    const r = await route(p, d, scheduledAt);
    const q: Quote = {
      ...r,
      id: crypto.randomUUID(),
      expiresAt: Date.now() + 5 * 60000,
      prices: fares(r.distanceMeters),
      mode: b.mode as Quote['mode'],
      scheduledAt,
    };
    await db()
      .prepare(
        'INSERT INTO mobility_quotes(id,owner_id,payload,expires_at) VALUES(?,?,?,?)',
      )
      .bind(q.id, user.userId, JSON.stringify(q), q.expiresAt)
      .run();
    // Immediate rides only: true/false per class, read from our own database.
    // Not stored with the quote; a failed read never blocks the price.
    const availability =
      q.mode === 'now'
        ? await classAvailability(db()).catch(() => undefined)
        : undefined;
    const arrival =
      q.mode === 'now'
        ? await classArrival(db(), p).catch(() => undefined)
        : undefined;
    return json({
      ...q,
      ...(availability ? { availability } : {}),
      ...(arrival ? { arrival } : {}),
    });
  });
}
