import { reserveMailBudget } from '@/lib/mobility/mail-budget';
import { headers } from 'next/headers';
import {
  ApiError,
  body,
  checkOrigin,
  deviceUser,
  handled,
  isAdmin,
  json,
  settings,
  limit,
  text,
  tokenHash,
} from '@/lib/mobility/server';
import {
  accountDb as db,
  assertAccountIdle,
  audit,
  clearDeviceCookie,
  cookieToken,
  mailReady,
  normalizeEmail,
  publicAccount,
  randomToken,
  sendCode,
  sessionAccount,
  setAccountCookie,
  type Account,
} from '@/lib/mobility/accounts';

export async function GET() {
  return handled(async () => {
    const account = await sessionAccount(await headers());
    return json({
      account: account ? publicAccount(account) : null,
      registrationReady: mailReady(),
      isAdmin: account
        ? isAdmin({
            userId: account.id,
            email: account.email,
            displayName: account.name,
            fullName: account.name,
          })
        : false,
    });
  });
}
export async function POST(request: Request) {
  return handled(async () => {
    checkOrigin(request);
    const h = await headers();
    const b = await body(request);
    const ip = process.env.VERCEL
      ? h.get('x-vercel-forwarded-for')?.split(',')[0]?.trim()
      : null;
    await limit('public', 'account-write', 100, db);
    if (ip) await limit(await tokenHash(ip), 'account-ip', 20, db);
    if (b.action === 'code') {
      if (!mailReady())
        throw new ApiError(
          503,
          'Der E-Mail-Zugang wird noch eingerichtet. Bitte versuche es nach der Freischaltung erneut.',
        );
      const email = normalizeEmail(b.email);
      await limit(await tokenHash(email), 'account-email', 2, db);
      if (b.mode !== 'login' && b.mode !== 'register')
        throw new ApiError(400, 'Bitte Anmeldung oder Registrierung wählen.');
      const payload =
        b.mode === 'register'
          ? {
              mode: 'register',
              name: text(b.name, 80),
              phone: text(b.phone, 30),
              kind: b.kind,
            }
          : { mode: 'login' };
      if (
        b.mode === 'register' &&
        (!['customer', 'driver', 'fleet'].includes(String(b.kind)) ||
          !/^\+?[\d\s()-]{6,30}$/.test(String(b.phone)) ||
          b.privacy !== true)
      )
        throw new ApiError(
          400,
          'Bitte Profilart, Telefonnummer und Datenschutzhinweis prüfen.',
        );
      const recent = await db()
        .prepare(
          'SELECT id FROM mobility_account_challenges WHERE email=? AND created_at>? LIMIT 1',
        )
        .bind(email, Date.now() - 60000)
        .first();
      if (recent)
        throw new ApiError(
          429,
          'Bitte eine Minute warten, bevor du einen neuen Code anforderst.',
        );
      if (!(await reserveMailBudget(db())))
        throw new ApiError(
          429,
          'Die Reserve für Anmeldecodes ist vorübergehend erreicht. Bitte später erneut versuchen. Bereits angemeldete Konten bleiben nutzbar.',
        );
      const id = randomToken();
      let sample: number;
      do {
        sample = crypto.getRandomValues(new Uint32Array(1))[0];
      } while (sample >= 4294000000);
      const code = (sample % 1000000).toString().padStart(6, '0');
      const device = await deviceUser(h, db);
      const now = Date.now();
      await db().batch([
        db()
          .prepare('DELETE FROM mobility_account_challenges WHERE expires_at<?')
          .bind(now),
        db()
          .prepare(
            'UPDATE mobility_account_challenges SET claimed=1 WHERE email=?',
          )
          .bind(email),
        db()
          .prepare(
            'INSERT INTO mobility_account_challenges(id,email,code_hash,payload,device_id,expires_at,created_at) VALUES(?,?,?,?,?,?,?)',
          )
          .bind(
            id,
            email,
            await tokenHash(id + ':' + code),
            JSON.stringify(payload),
            device?.userId || null,
            now + 600000,
            now,
          ),
      ]);
      try {
        await sendCode(email, code, id);
      } catch (error) {
        await db()
          .prepare('DELETE FROM mobility_account_challenges WHERE id=?')
          .bind(id)
          .run();
        throw error;
      }
      return json({
        challengeId: id,
        expiresAt: now + 600000,
        message:
          'Wenn die Adresse erreichbar ist, erhältst du deinen Code per E-Mail.',
      });
    }
    if (b.action === 'verify') {
      const id = text(b.challengeId, 64);
      if (
        !/^[a-f0-9]{64}$/.test(id) ||
        typeof b.code !== 'string' ||
        !/^\d{6}$/.test(b.code)
      )
        throw new ApiError(400, 'Bitte den sechsstelligen Code eingeben.');
      const attempt = await db()
        .prepare(
          'UPDATE mobility_account_challenges SET attempts=attempts+1 WHERE id=? AND claimed=0 AND expires_at>? AND attempts<5 RETURNING *',
        )
        .bind(id, Date.now())
        .first<{
          id: string;
          email: string;
          code_hash: string;
          payload: string;
          device_id: string | null;
        }>();
      if (
        !attempt ||
        attempt.code_hash !== (await tokenHash(id + ':' + b.code))
      )
        throw new ApiError(
          400,
          'Code ungültig oder abgelaufen. Bitte einen neuen Code anfordern.',
        );
      const account = await db()
        .prepare('SELECT * FROM mobility_accounts WHERE email=?')
        .bind(attempt.email)
        .first<Account>();
      const payload = JSON.parse(attempt.payload);
      const bootstrapOwner =
        !account &&
        payload.mode === 'login' &&
        Boolean(settings().LUXORE_ADMIN_EMAIL) &&
        attempt.email === settings().LUXORE_ADMIN_EMAIL!.trim().toLowerCase();
      if (bootstrapOwner)
        Object.assign(payload, { name: 'Betreiber', phone: '', kind: 'fleet' });
      if (!account && payload.mode !== 'register' && !bootstrapOwner)
        throw new ApiError(400, 'Bitte zuerst ein Konto registrieren.');
      if (account && account.status !== 'active')
        throw new ApiError(
          403,
          'Dein Konto ist gesperrt oder wird gelöscht. Bitte den Support kontaktieren.',
        );
      const device = await deviceUser(h, db);
      const adopt =
        !account && device?.userId === attempt.device_id
          ? device!.userId
          : null;
      const currentAccount = await sessionAccount(h);
      // Prepare credentials before taking the write lock. Claim, profile,
      // session and audit must commit together so a storage failure cannot
      // consume an otherwise valid code or leave a partial registration.
      const token = randomToken();
      const hash = await tokenHash(token);
      const now = Date.now();
      const expiresAt = now + 30 * 86400000;
      const signedIn = await db().writeTransaction(async (transaction) => {
        let account = await transaction
          .prepare('SELECT * FROM mobility_accounts WHERE email=?')
          .bind(attempt.email)
          .first<Account>();
        if (!account && payload.mode !== 'register' && !bootstrapOwner)
          throw new ApiError(400, 'Bitte zuerst ein Konto registrieren.');
        if (account && account.status !== 'active')
          throw new ApiError(403, 'Das Konto ist nicht aktiv.');
        // Recheck trip/shift state under the same write lock as code consumption.
        if (device) await assertAccountIdle(device.userId, () => transaction);
        if (currentAccount && currentAccount.id !== account?.id)
          await assertAccountIdle(currentAccount.id, () => transaction);
        const claim = await transaction
          .prepare(
            'UPDATE mobility_account_challenges SET claimed=1 WHERE id=? AND code_hash=? AND claimed=0 AND expires_at>? AND attempts<=5 RETURNING id',
          )
          .bind(id, attempt.code_hash, Date.now())
          .first();
        if (!claim)
          throw new ApiError(400, 'Dieser Code wurde bereits verwendet.');
        if (!account) {
          const accountId = adopt || 'account:' + crypto.randomUUID();
          await transaction
            .prepare(
              "INSERT INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES(?,?,?,?,?,'active',?,?) ON CONFLICT(email) DO NOTHING",
            )
            .bind(
              accountId,
              attempt.email,
              payload.name,
              payload.phone,
              payload.kind,
              now,
              now,
            )
            .run();
          account = await transaction
            .prepare('SELECT * FROM mobility_accounts WHERE email=?')
            .bind(attempt.email)
            .first<Account>();
          if (!account)
            throw new ApiError(
              409,
              'Das Konto konnte nicht angelegt werden. Bitte erneut anmelden.',
            );
          if (account.id === accountId && account.kind !== 'customer') {
            await transaction
              .prepare(
                `INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,services,approved,online) VALUES(?,?,?,'','','premium','["premium"]',0,0) ON CONFLICT(id) DO NOTHING`,
              )
              .bind(account.id, account.name, account.phone)
              .run();
          }
        }
        if (account.status !== 'active')
          throw new ApiError(403, 'Das Konto ist nicht aktiv.');
        await transaction.batch([
          transaction
            .prepare('DELETE FROM mobility_sessions WHERE user_id=?')
            .bind(account.id),
          transaction
            .prepare('DELETE FROM mobility_account_sessions WHERE expires_at<?')
            .bind(now),
          transaction
            .prepare(
              'INSERT INTO mobility_account_sessions(token_hash,account_id,expires_at,verified_at) VALUES(?,?,?,?)',
            )
            .bind(hash, account.id, expiresAt, now),
        ]);
        await audit(
          account.id,
          account.id,
          'account.signin',
          () => transaction,
        );
        return account;
      });
      const response = json({
        account: publicAccount(signedIn),
        ...(h.get('x-luxore-client') === 'native-v1'
          ? {
              sessionToken: token,
              sessionExpiresAt: expiresAt,
            }
          : {}),
        isAdmin: isAdmin({
          userId: signedIn.id,
          email: signedIn.email,
          displayName: signedIn.name,
          fullName: signedIn.name,
        }),
      });
      setAccountCookie(response, request, token);
      clearDeviceCookie(response, request);
      return response;
    }
    const account = await sessionAccount(h);
    if (!account)
      throw new ApiError(401, 'Bitte mit deinem Luxóre-Konto anmelden.');
    await limit(account.id, 'account-manage', 10, db);
    if (b.action === 'profile') {
      await assertAccountIdle(account.id);
      const name = text(b.name, 80),
        phone = text(b.phone, 30);
      if (!/^\+?[\d\s()-]{6,30}$/.test(phone))
        throw new ApiError(400, 'Bitte eine gültige Telefonnummer eingeben.');
      await db().batch([
        db()
          .prepare('UPDATE mobility_accounts SET name=?,phone=? WHERE id=?')
          .bind(name, phone, account.id),
        db()
          .prepare('UPDATE mobility_drivers SET name=?,phone=? WHERE id=?')
          .bind(name, phone, account.id),
        db()
          .prepare(
            'UPDATE mobility_employees SET name=?,phone=? WHERE user_id=?',
          )
          .bind(name, phone, account.id),
      ]);
      return json({ ok: true });
    }
    if (b.action !== 'logout' && b.action !== 'delete')
      throw new ApiError(400, 'Unbekannte Kontoaktion.');
    await assertAccountIdle(account.id);
    if (b.action === 'delete') {
      if (b.confirmation !== 'LÖSCHEN')
        throw new ApiError(400, 'Bitte LÖSCHEN zur Bestätigung eingeben.');
      if (
        isAdmin({
          userId: account.id,
          email: account.email,
          displayName: account.name,
          fullName: account.name,
        })
      )
        throw new ApiError(
          409,
          'Bitte vor dem Löschen den Betreiberzugang übertragen.',
        );
      await db()
        .prepare(
          "UPDATE mobility_accounts SET status='deletion_pending',deletion_requested_at=? WHERE id=?",
        )
        .bind(Date.now(), account.id)
        .run();
      await db()
        .prepare(
          "UPDATE mobility_bookings SET status='cancelled',updated_at=? WHERE owner_id=? AND status='reserved'",
        )
        .bind(Date.now(), account.id)
        .run();
      await audit(account.id, account.id, 'account.deletion_requested');
    }
    const token = cookieToken(h);
    await db().batch([
      b.action === 'delete'
        ? db()
            .prepare('DELETE FROM mobility_account_sessions WHERE account_id=?')
            .bind(account.id)
        : db()
            .prepare('DELETE FROM mobility_account_sessions WHERE token_hash=?')
            .bind(await tokenHash(token!)),
      db()
        .prepare('DELETE FROM mobility_sessions WHERE user_id=?')
        .bind(account.id),
      db()
        .prepare('DELETE FROM mobility_location_sessions WHERE driver_id=?')
        .bind(account.id),
    ]);
    const response = json({
      ok: true,
      deletionRequested: b.action === 'delete',
    });
    setAccountCookie(response, request, '', 0);
    clearDeviceCookie(response, request);
    return response;
  });
}
