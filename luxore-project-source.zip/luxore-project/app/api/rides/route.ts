import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '@/app/chatgpt-auth';

const json = (data: unknown, status = 200) =>
  Response.json(data, { status, headers: { 'Cache-Control': 'no-store' } });
export async function GET() {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'Bitte zuerst anmelden.' }, 401);
  const { results } = await env.DB.prepare(
    'SELECT id,pickup,destination,service,price,status,created_at,scheduled_at FROM rides WHERE owner_id = ? ORDER BY created_at DESC LIMIT 200',
  )
    .bind(user.userId)
    .all();
  return json(results);
}
export async function POST() {
  return json({ error: 'Bitte die neue Routenbuchung verwenden.' }, 410);
}
export async function PATCH() {
  return json({ error: 'Frühere Testfahrten sind archiviert.' }, 410);
}
