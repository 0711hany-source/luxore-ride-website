import { identity, db, handled } from '@/lib/mobility/server';

const json = (data: unknown, status = 200) =>
  Response.json(data, { status, headers: { 'Cache-Control': 'no-store' } });
export async function GET() { return handled(async () => {
  const user = await identity();
  if (!user) return json({ error: 'Bitte zuerst anmelden.' }, 401);
  const { results } = await db().prepare(
    'SELECT id,pickup,destination,service,price,status,created_at,scheduled_at FROM rides WHERE owner_id = ? ORDER BY created_at DESC LIMIT 200',
  )
    .bind(user.userId)
    .all();
  return json(results);
}); }
export async function POST() {
  return json({ error: 'Bitte die neue Routenbuchung verwenden.' }, 410);
}
export async function PATCH() {
  return json({ error: 'Frühere Testfahrten sind archiviert.' }, 410);
}
