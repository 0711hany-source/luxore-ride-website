import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
export const metadata = { title: 'Hilfe & Kontakt | LUXORÉ RIDE' };
export default function Page() {
  return (
    <main className="legal-page">
      <header className="portal-header">
        <Link className="lux-logo" href="/">
          LUXORÉ <span>RIDE</span>
        </Link>
        <Link className="portal-back" href="/mobile/customer">
          <ArrowLeft size={18} /> Zur Fahrt
        </Link>
      </header>
      <article className="legal-content">
        <span className="portal-eyebrow">PERSÖNLICH FÜR DICH DA</span>
        <h1>Hilfe & Kontakt</h1>
        <p>
          Bei Fragen zu einer Fahrt, deinem Konto oder einer Bestellung
          unterstützt dich unser Team.
        </p>
        <p>
          <strong>Telefon:</strong>{' '}
          <a href="tel:+491605083829">+49 160 5083829</a>
          <br />
          <strong>E-Mail:</strong>{' '}
          <a href="mailto:booking@luxoreride.de">booking@luxoreride.de</a>
        </p>
        <h2>Eine Fahrt buchen</h2>
        <p>
          Wähle Abholort und Ziel, lasse die Strecke berechnen und entscheide
          dich für eine Fahrzeugklasse. Eine Sofortanfrage wird an verfügbare,
          freigegebene Fahrer vermittelt. Du siehst in deiner Fahrtübersicht, ob
          ein Chauffeur die Fahrt angenommen hat. Eine Reservierung erhält einen
          eigenen Status.
        </p>
        <h2>App Store & Google Play</h2>
        <p>
          LUXORÉ Ride und LUXORÉ Driver sind noch nicht in den Stores verfügbar.
          Die Veröffentlichung wird vorbereitet. Interne Android-Testapps werden
          getrennt verteilt; sie sind keine offiziellen Store-Versionen.
        </p>
        <h2>Anmeldung und Registrierung</h2>
        <p>
          Dein persönliches Luxóre-Konto nutzt einen einmaligen E-Mail-Code. Der
          Versandzugang wird derzeit eingerichtet. Bis dahin kannst du die
          Web-App als Gast nutzen. Fahrer und Flotten benötigen eine gesonderte
          Freigabe.
        </p>
        <h2>Konto löschen</h2>
        <p>
          Öffne <Link href="/konto">Mein Konto</Link>, melde dich an und wähle
          „Konto löschen“. Dort kannst du die Löschung direkt anfordern.
          Zunächst wird dein Konto gesperrt und deine Anmeldungen beendet. Die
          Löschanfrage erscheint in unserer geschützten Betreiberverwaltung.
          Kontodaten werden entfernt; gesetzlich aufzubewahrende Fahrt- und
          Zahlungsbelege bleiben erhalten. Zukünftige Reservierungen werden bei
          der Löschanfrage storniert.
        </p>
        <p>
          Beende oder storniere vorher eine laufende Fahrt. Fahrer müssen ihre
          Schicht pausieren und offene Fahrten abrechnen. Als Flottenbesitzer
          muss deine Flotte vor Abschluss der Löschung auf eine andere
          verantwortliche Person übertragen werden.
        </p>
        <h2>Standort und Navigation</h2>
        <p>
          Erlaube den Standort für die Abholung beziehungsweise die
          Fahrerortung. Fahrer benötigen für eine laufende Schicht im
          Hintergrund zusätzliche Systemberechtigungen. Eine beendete Schicht
          übermittelt keine neuen Standorte. Wenn Android die App ausdrücklich
          beendet oder die Berechtigung entzieht, kann keine fortlaufende Ortung
          zugesagt werden.
        </p>
        <h2>Notfall</h2>
        <p>
          Bei unmittelbarer Gefahr rufe <a href="tel:112">112</a> an. Der
          Kundenservice ist kein Ersatz für den Rettungsdienst.
        </p>
        <p>
          <Link href="/datenschutz">Datenschutz</Link> ·{' '}
          <Link href="/impressum">Impressum</Link>
        </p>
      </article>
    </main>
  );
}
