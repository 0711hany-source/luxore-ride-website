import ServiceUnavailable from '@/components/service-unavailable';
export const metadata = { title: 'Online-Buchung | LUXORÉ RIDE', robots: { index: false } };
export default function Page() {
  return <ServiceUnavailable />;
}
