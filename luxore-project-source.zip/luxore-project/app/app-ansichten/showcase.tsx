'use client';
import NavigationPreview from './navigation-preview';
import { useState, useEffect } from 'react';
import { defaultPreferences } from '@/lib/mobility/ride-preferences';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import CustomerHome from '@/app/mobility/customer-home';
import ClassPicker from '@/app/mobility/class-picker';
import BookingCheckout from '@/app/mobility/checkout';
import DriverView, { type DriverState } from '@/app/mobility/driver';
import Payment from '@/app/mobility/payment';
import DriverOffer from '@/app/mobility/driver-offer';
import DriverStandby from '@/app/mobility/driver-standby';
import DriverSheet from '@/app/mobility/driver-sheet';
import AppHeader from '@/app/mobility/app-header';
import { BoardPicker } from '@/app/mobility/refreshments';
import { className } from '@/lib/ride-domain';
import type { Booking, Service } from '@/lib/mobility/domain';
const route = {
  pickup: {
    id: 'example-p',
    label: 'Opernplatz, Frankfurt am Main',
    lat: 50.115,
    lng: 8.67,
  },
  destination: {
    id: 'example-d',
    label: 'Flughafen Terminal 1, Frankfurt',
    lat: 50.05,
    lng: 8.57,
  },
  distanceMeters: 21000,
  durationSeconds: 1500,
  geometry: {
    type: 'LineString' as const,
    coordinates: [
      [8.67, 50.115],
      [8.57, 50.05],
    ],
  },
  calculatedAt: 1790244000000,
};
const trip = {
  id: 'example-only',
  quote_id: 'example-q',
  owner_id: 'example-c',
  service: 'premium',
  price: 5250,
  route,
  mode: 'now',
  scheduled_at: null,
  status: 'completed',
  driver_id: 'example-driver',
  created_at: 1790244000000,
  updated_at: 1790244000000,
  completed_at: 1790244000000,
  payment_status: 'unpaid',
  payment_method: null,
  paid_at: null,
  fleet_id: 'example-fleet',
  rider_lat: null,
  rider_lng: null,
  rider_location_at: null,
  driver: null,
} as Booking;
const driver: DriverState = {
  driver: {
    id: 'example-driver',
    name: 'Beispielfahrer',
    phone: '',
    vehicle: 'Mercedes E-Klasse',
    plate: 'F LR 101',
    service: 'premium',
    services: '["premium","first"]',
    approved: 1,
    online: 0,
    lat: null,
    lng: null,
    location_at: null,
    accuracy: null,
    vehicle_id: 'example-v',
  },
  bookings: [],
  offers: [],
  payments: [],
  history: [5250, 4250, 2850, 1500].map((price, i) => ({
    ...trip,
    id: 'example-trip-' + i,
    price,
    payment_status: 'paid' as const,
    route: {
      ...route,
      distanceMeters: price * 4,
      destination: {
        ...route.destination,
        label: [
          'Flughafen Terminal 1, Frankfurt',
          'Messe Frankfurt, Frankfurt',
          'Alte Oper, Frankfurt',
          'Hauptbahnhof, Frankfurt',
        ][i],
      },
    },
  })),
  today: { gross: 13850, collected: 13850, outstanding: 0, trips: 4 },
  todaySince: 0,
  revenue: { gross: 72400, collected: 72400, outstanding: 0, trips: 21 },
  vehicleRequired: true,
  vehicles: [
    {
      id: 'example-v',
      fleet_id: 'example-fleet',
      model: 'Mercedes E-Klasse',
      plate: 'F LR 101',
      services: '["premium","first"]',
      status: 'active',
      archived_reason: null,
      driver_id: 'example-driver',
      driver_name: 'Beispielfahrer',
      online: 0,
    },
    {
      id: 'example-v2',
      fleet_id: 'example-fleet',
      model: 'Mercedes V-Klasse',
      plate: 'F LR 202',
      services: '["van"]',
      status: 'active',
      archived_reason: null,
      driver_id: null,
      driver_name: null,
      online: 0,
    },
  ],
};
const screens = [
  'Start',
  'Fahrzeugwahl',
  'Tagesumsatz',
  'Auto wechseln',
  'Kassieren',
  'Fahrerstart',
  'Fahrtangebot',
  'Bordkarte',
  'Navigation',
];
const screenLinks = [
  'start',
  'fahrzeugwahl',
  'umsatz',
  'fahrzeuge',
  'kassieren',
  'fahrer',
  'angebot',
  'bordkarte',
  'navigation',
];
export default function Showcase() {
  const [previewSheetHeight, setPreviewSheetHeight] = useState(330);
  const [refreshments, setRefreshments] = useState<Record<string, number>>({});
  const [preferences, setPreferences] = useState(defaultPreferences);
  const [active, setActive] = useState(0),
    [service, setService] = useState<Service>('premium'),
    [message, setMessage] = useState(''),
    [contact, setContact] = useState(false),
    [name, setName] = useState(''),
    [phone, setPhone] = useState('');
  useEffect(() => {
    const select = () => {
      const index = screenLinks.indexOf(window.location.hash.slice(1));
      if (index >= 0) setActive(index);
    };
    select();
    window.addEventListener('hashchange', select);
    return () => window.removeEventListener('hashchange', select);
  }, []);
  return (
    <main className="app-showcase">
      <BookingCheckout
        refreshments={refreshments}
        setRefreshments={setRefreshments}
        preferences={preferences}
        setPreferences={setPreferences}
        checkout={contact}
        setCheckout={setContact}
        quote={{
          ...route,
          id: 'example-quote',
          prices: { premium: 5250, first: 7350, van: 6300 },
          mode: 'now',
          scheduledAt: null,
          expiresAt: 4102444800000,
        }}
        service={service}
        riderName={name}
        setRiderName={setName}
        riderPhone={phone}
        setRiderPhone={setPhone}
        error="Beispielansicht: Angaben werden nicht gesendet oder gespeichert."
        busy={false}
        book={() => {
          setContact(false);
          setMessage('Beispiel abgeschlossen. Es wurde keine Fahrt gebucht.');
        }}
      />

      <header className="showcase-header">
        <div className="app-wordmark">
          luxóre<span>APP-ANSICHTEN</span>
        </div>
        <Link href="/mobile/customer">App öffnen ↗</Link>
      </header>
      <div className="showcase-intro">
        <h1>So fühlt sich Luxóre an.</h1>
        <p>
          Die eingebauten App-Oberflächen zum Durchsehen. Hier ausschließlich
          Beispieldaten, ohne Buchungen oder Zahlungen.
        </p>
      </div>
      <nav className="showcase-tabs" aria-label="App-Ansicht">
        {screens.map((s, i) => (
          <Button
            key={s}
            variant={i === active ? 'default' : 'outline'}
            aria-pressed={i === active}
            onClick={() => {
              setActive(i);
              window.history.replaceState(null, '', '#' + screenLinks[i]);
              setMessage('');
            }}
          >
            {s}
          </Button>
        ))}
      </nav>
      <div className="showcase-stage">
        <div className="showcase-caption">
          <span>
            {active < 2 || active === 7 ? 'LUXORÉ RIDE' : 'LUXORÉ DRIVER'}
          </span>
          <h2>{screens[active]}</h2>
          <p>
            {
              [
                'Suchen, sofort fahren oder eine Abholzeit planen.',
                'Fahrzeug und Preis wählen. Kontaktdaten erst im nächsten Schritt.',
                'Der Tagesumsatz steht im Mittelpunkt.',
                'Das aktuelle Auto und verfügbare Fahrzeuge deiner Flotte.',
                'Ein klarer Abschluss mit dem Betrag, der noch zu kassieren ist.',
                'Status, ausgewähltes Fahrzeug und Online-Schalter auf einen Blick.',
                'Fahrpreis, Strecke und Wünsche vor der Annahme. Countdown hier als Beispiel.',
                'Getränke und Snacks vor und während der Fahrt auswählen. Freimengen und Aufpreise passen zur Fahrzeugklasse.',
                'Die nächste Abbiegung, Ankunftszeit und Reststrecke bleiben sichtbar. Wische das Fahrtmenü klein, um mehr Karte zu sehen.',
              ][active]
            }
          </p>
          <small>
            Dieselben Komponenten werden in den Apps verwendet. Die
            Karteneinbindung wird hier nicht simuliert.
          </small>
          <div>
            <Link href="/mobile/customer">Kunden-App ↗</Link>
            <Link href="/mobile/driver">Fahrer-App ↗</Link>
          </div>
          {message && <output className="showcase-message">{message}</output>}
        </div>
        <div className="showcase-device">
          <div className="showcase-device-label">BEISPIELANSICHT</div>
          <div className="showcase-frame">
            {active === 8 ? (
              <div className="app-native app-driver">
                <NavigationPreview />
              </div>
            ) : active === 0 ? (
              <div className="app-native app-customer">
                <CustomerHome
                  bookings={[trip]}
                  onStart={() => setActive(1)}
                  onRecent={() => setActive(1)}
                  onMenu={() =>
                    setMessage(
                      'Im oberen Menü findest du deine Fahrten, Hilfe und – mit Freigabe – die Disposition.',
                    )
                  }
                />
              </div>
            ) : active === 1 ? (
              <div className="app-native showcase-selection">
                <Button variant="ghost" onClick={() => setActive(0)}>
                  <ArrowLeft />
                  Zurück
                </Button>
                <div className="selection-route">
                  <span>Opernplatz</span>
                  <small>→ Frankfurt Flughafen, Terminal 1</small>
                  <b>21 km · ca. 25 Min.</b>
                </div>
                <ClassPicker
                  prices={{ premium: 5250, first: 7350, van: 6300 }}
                  service={service}
                  onChange={setService}
                  onContinue={() => setContact(true)}
                />
              </div>
            ) : active === 7 ? (
              <div className="app-native showcase-selection">
                <AppHeader
                  onMenu={() => setMessage('Beispielansicht der Bordkarte.')}
                />
                <div className="board-order-actions">
                  {(['premium', 'first', 'van'] as const).map((item) => (
                    <Button
                      key={item}
                      variant={service === item ? 'default' : 'outline'}
                      onClick={() => setService(item)}
                    >
                      {className(item)}
                    </Button>
                  ))}
                </div>
                <BoardPicker
                  service={service}
                  value={refreshments}
                  onChange={setRefreshments}
                />
              </div>
            ) : active >= 5 ? (
              <div className="app-native app-driver driver-component-preview">
                <AppHeader
                  onMenu={() =>
                    setMessage(
                      'Beispielansicht: Das Flottenmenü öffnest du in der Fahrer-App.',
                    )
                  }
                />
                <p className="driver-preview-label">
                  BEISPIEL · KEINE AKTIVE FAHRT
                </p>
                <div className="driver-canvas driver-sheet-preview">
                  <div
                    className="driver-preview-map-space"
                    style={{ bottom: previewSheetHeight }}
                  >
                    <span>MEHR RAUM</span>
                    <strong>
                      Deine Karte.
                      <br />
                      Dein Überblick.
                    </strong>
                    <p>Die Statuszeile nach unten oder oben wischen.</p>
                    <small>Gestenvorschau · keine Live-Karte</small>
                  </div>
                  <DriverSheet
                    key={active}
                    title={
                      active === 5
                        ? 'Bereit für deine Schicht?'
                        : 'Neue Fahrt · 52,50 €'
                    }
                    subtitle={
                      active === 5
                        ? 'Zum Verkleinern nach unten wischen'
                        : 'Opernplatz, Frankfurt am Main'
                    }
                    peekSubtitle={
                      active === 5
                        ? 'Offline · Schicht starten'
                        : 'Neue Fahrt · 52,50 €'
                    }
                    onHeightChange={setPreviewSheetHeight}
                  >
                    {active === 5 ? (
                      <DriverStandby
                        preview
                        driver={driver.driver!}
                        vehicleRequired
                        tracking={false}
                        locationFresh={false}
                        alerts={{ enabled: true, sound: true }}
                        onTestAlert={() =>
                          setMessage(
                            'Beispielansicht: Den echten Testalarm löst du in der neuen Fahrer-APK aus.',
                          )
                        }
                        onAlertSettings={() =>
                          setMessage(
                            'Beispielansicht: Die Android-Einstellungen erreichst du in der Fahrer-APK.',
                          )
                        }
                        busy={false}
                        onAvailability={() =>
                          setMessage(
                            'Beispielansicht: Du wurdest nicht online geschaltet.',
                          )
                        }
                        onVehicle={() => setActive(3)}
                      />
                    ) : (
                      <DriverOffer
                        offer={{
                          id: 'example-offer',
                          expires_at: 18000,
                          booking: {
                            ...trip,
                            status: 'requesting',
                            refreshments: {
                              version: 1,
                              revision: 0,
                              requested: { water: 2, pretzels: 1 },
                              delivered: {},
                              unavailable: {},
                            },
                            driver_id: null,
                            rider_preferences: {
                              temperature: 'cool',
                              conversation: 'quiet',
                              music: 'off',
                            },
                          },
                        }}
                        now={0}
                        busy={false}
                        onAccept={() =>
                          setMessage(
                            'Beispielansicht: Es wurde keine Fahrt angenommen.',
                          )
                        }
                        onReject={() =>
                          setMessage(
                            'Beispielansicht: Es wurde keine Fahrt abgelehnt.',
                          )
                        }
                      />
                    )}
                  </DriverSheet>
                </div>
              </div>
            ) : active === 4 ? (
              <div className="app-native app-driver">
                <Payment booking={trip} preview refresh={async () => {}} />
              </div>
            ) : (
              <div className="app-native app-driver">
                <DriverView
                  key={active}
                  state={driver}
                  token={null}
                  preview
                  initialSection={active === 2 ? 'revenue' : 'vehicles'}
                  refresh={async () => {}}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
