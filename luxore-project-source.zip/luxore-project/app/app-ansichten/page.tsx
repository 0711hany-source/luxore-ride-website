import Showcase from './showcase';
export const metadata = {
  title: 'Luxóre · App-Ansichten',
  robots: { index: false, follow: false },
};
export default function Page() {
  return <Showcase />;
}
