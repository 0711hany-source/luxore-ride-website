import Showcase from './showcase';
export const metadata = {
  title: 'LUXORÉ · App-Ansichten',
  robots: { index: false, follow: false },
};
export default function Page() {
  return <Showcase />;
}
