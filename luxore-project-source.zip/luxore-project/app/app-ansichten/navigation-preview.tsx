'use client';
import { useState, type CSSProperties } from 'react';
import NavigationPanel from '@/app/mobility/navigation-panel';
import DriverSheet from '@/app/mobility/driver-sheet';
import {
  compileNavigation,
  advanceNavigation,
} from '@/app/mobility/navigation-progress';
import type { RouteData } from '@/lib/mobility/domain';
const now = 1800000000000;
const route: RouteData = {
  pickup: { id: 'demo-start', label: 'Frankfurt', lng: 8.68, lat: 50.11 },
  destination: {
    id: 'demo-target',
    label: 'Opernplatz · Frankfurt am Main',
    lng: 8.6804,
    lat: 50.115,
  },
  distanceMeters: 580,
  durationSeconds: 240,
  calculatedAt: now,
  geometry: {
    type: 'LineString',
    coordinates: [
      [8.68, 50.11],
      [8.6804, 50.11],
      [8.6804, 50.115],
    ],
  },
  navigation: [
    {
      distanceMeters: 30,
      durationSeconds: 30,
      coordinates: [
        [8.68, 50.11],
        [8.6804, 50.11],
      ],
      type: 'depart',
      instruction: 'Richtung Osten fahren',
      street: '',
    },
    {
      distanceMeters: 550,
      durationSeconds: 210,
      coordinates: [
        [8.6804, 50.11],
        [8.6804, 50.115],
      ],
      type: 'turn',
      modifier: 'left',
      instruction: 'Links auf die nächste Straße abbiegen',
      street: '',
    },
    {
      distanceMeters: 0,
      durationSeconds: 0,
      coordinates: [
        [8.6804, 50.115],
        [8.6804, 50.115],
      ],
      type: 'arrive',
      instruction: 'Das Fahrtziel liegt vor dir',
      street: '',
    },
  ],
};
export default function NavigationPreview() {
  const [mode, setMode] = useState('Abbiegen'),
    [height, setHeight] = useState(240);
  const fix = {
    lat: 50.11,
    lng: 8.68,
    accuracy: 5,
    speed: 6,
    heading: 90,
    timestamp: now,
  };
  const activeRoute: RouteData =
    mode === 'Kreisverkehr'
      ? {
          ...route,
          navigation: route.navigation!.map((s, i) =>
            i === 1
              ? {
                  ...s,
                  type: 'roundabout',
                  exit: 2,
                  instruction: 'Im Kreisverkehr die zweite Ausfahrt nehmen',
                }
              : s,
          ),
        }
      : route;
  const track = compileNavigation(activeRoute)!;
  return (
    <div className="driver-view">
      <div
        className="driver-canvas has-navigation navigation-preview-canvas"
        style={{ '--navigation-panel-height': `${height}px` } as CSSProperties}
      >
        <NavigationPanel
          phase="riding"
          destination={route.destination.label}
          route={activeRoute}
          progress={advanceNavigation(track, fix, now, null)}
          fix={mode === 'GPS fehlt' ? null : fix}
          now={now}
          online={mode !== 'Offline'}
          failed={mode === 'Offline'}
          pending={false}
          onHeightChange={setHeight}
        />
        <p className="navigation-preview-note">
          Beispieldaten
          <br />
          <span>Die Karte erscheint bei deiner echten Fahrt.</span>
        </p>
        <DriverSheet
          title="Navigation ansehen"
          subtitle="Beispiel auswählen · nach unten wischen"
          peekSubtitle="Nach oben wischen für weitere Beispiele"
          initialStop="half"
          reservedTop={height + 24}
          onHeightChange={() => {}}
        >
          <div className="navigation-preview-options">
            {['Abbiegen', 'Kreisverkehr', 'GPS fehlt', 'Offline'].map(
              (value) => (
                <button
                  type="button"
                  key={value}
                  aria-pressed={value === mode}
                  onClick={() => setMode(value)}
                >
                  {value}
                </button>
              ),
            )}
          </div>
          <p className="small-note">
            Keine aktive Fahrt. Es werden keine Standortdaten gesendet.
          </p>
        </DriverSheet>
      </div>
    </div>
  );
}
