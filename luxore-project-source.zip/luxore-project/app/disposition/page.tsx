import MobilityWorkspace from '@/app/mobility/workspace';
export { viewport } from '@/app/mobile/layout';
export default function Page() {
  return <MobilityWorkspace initialView="operations" />;
}
