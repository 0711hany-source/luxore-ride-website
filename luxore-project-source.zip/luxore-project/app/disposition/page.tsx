import MobilityWorkspace from '@/app/mobility/workspace';
import { databaseConfigured } from '@/db/sqlite';
import ServiceUnavailable from '@/components/service-unavailable';
export const dynamic = 'force-dynamic';
export { viewport } from '@/app/mobile/layout';
export default function Page() {
  return databaseConfigured() ? <MobilityWorkspace initialView="operations" /> : <ServiceUnavailable />;
}
