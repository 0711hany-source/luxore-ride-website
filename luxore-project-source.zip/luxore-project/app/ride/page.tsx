import type { Metadata } from 'next';
import MobilityWorkspace from '../mobility/workspace';
export const metadata: Metadata = {
  title: 'Web-App Vorschau | LUXORÉ RIDE',
  robots: { index: false, follow: false },
};
export default function RidePage() {
  return <MobilityWorkspace />;
}
