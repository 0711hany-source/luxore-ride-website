import './src/location-service';
import { registerRootComponent } from 'expo';
import App from './src/App';
registerRootComponent(App);
