## Vorbereitung für offizielle Stores – 06.10.2026

`eas.json` enthält nun getrennte `customer-production`- und `driver-production`-Profile für Store-App-Bundles. `app.config.ts` trennt die produktiven IDs von den internen `.preview`-Paketen und enthält iOS-Kennungen sowie verständliche Standortbegründungen. Diese Einstellungen erstellen noch kein Expo-/Apple-/Google-Konto, keine produktive Signatur und keine Store-Veröffentlichung. iOS-Berechtigungen, Fahrtalarme und Hintergrunddienst sind auf einem echten iPhone gesondert zu prüfen.

Store-Texte und öffentliche Support-/Datenschutz-/Kontolöschungs-URLs: [STORE-LISTINGS-DE.md](store/STORE-LISTINGS-DE.md). Verbindliche offene Voraussetzungen: [OFFICIAL-LAUNCH.md](../docs/OFFICIAL-LAUNCH.md). GitHub-Prüfworkflow vorbereitet; noch kein GitHub-Remote eingerichtet.

Die Unternehmens-Test-APKs 0.4.3 sind weiterhin interne ARM64-Pakete. Neue Website-Oberflächen werden dort über die gemeinsame WebView geladen; die Änderungen an E-Mail-Konten benötigen keinen erfundenen nativen Store-Download. Neue native Funktionen benötigen weiterhin einen neuen APK-/Store-Build.

# LUXORÉ Android – erste native Grundlage

Stand: 23.09.2026. Expo SDK 57 / React Native. Zwei App-Varianten aus einer Codebasis: `de.luxoreride.customer` und `de.luxoreride.driver`. Interne ARM64-Test-APKs werden lokal erzeugt; keine Store-Veröffentlichung und keine Produktionsfreigabe.

## Enthalten
- Kunden-App mit Fahrzeugklassen, bestätigten Kilometerpreisen, Kontakt und nativer Fahrtanfrage.
- Gemeinsame Anfragevalidierung mit der Website (`../lib/inquiry.ts`): Datum in Europe/Berlin, verschiedene Orte, Sitzplatzgrenzen, kodierter E-Mail-Entwurf.
- Optional einmalige Standortabfrage nach Betriebssystemfreigabe; Koordinaten werden in den überprüfbaren Entwurf eingesetzt. Keine automatische Adressauflösung, keine Hintergrundortung.
- E-Mail öffnen und Android-Teilen-Dialog. Kein automatischer Versand, keine vorgetäuschte Buchung.
- Fahrer-App als offline gekennzeichnete Oberfläche für Aufträge, Reservierungen und Kontakt. Noch keine Kontoanmeldung und kein Empfang echter Fahrten.
- Eingaben nur im Arbeitsspeicher. Keine Speicherung von Standorten/Telefonnummern auf einem neuen Server; Android-Backup deaktiviert. Kein Mikrofon-/Dateizugriff angefordert.

## Entwicklung
Aus `mobile/`: `pnpm install`, `pnpm start`. Kundenvariante ist Standard. Für die Fahreransicht `APP_VARIANT=driver pnpm start --clear` verwenden. Metro muss beim Variantenwechsel neu starten. Jede Variante besitzt eigene Android-Appkennung und Deep-Link-Scheme.

`pnpm typecheck` prüft TypeScript. `pnpm export:android` erzeugt ein Android-JavaScript-/Hermes-Bundle unter `dist`, **keine APK**. Die Fahrer-Variante: `APP_VARIANT=driver pnpm exec expo export --platform android --output-dir dist/driver`.

`pnpm prebuild:android` erzeugt das native Android-Projekt. Die erzeugten `android/`-Dateien sind ignoriert; app.config.ts ist die Quelle. Beim Wechsel einer bereits generierten nativen App auf eine andere Variante müssen die nativen Verzeichnisse frisch aus der passenden Konfiguration erzeugt werden. Nicht einfach nur APP_VARIANT beim Start einer bereits gebauten App ändern.

## Installierbare interne Testversion
Java 17 und Android SDK liegen inzwischen unter `.toolchain/` im Projekt. Die native Buildumgebung wurde eingerichtet, die offiziellen Java-/SDK-Archive wurden vor dem Entpacken über SHA-256 geprüft. Buildcache und Downloads bleiben lokal und werden nicht in Git aufgenommen.

Mit Node und pnpm im PATH:
- `bash scripts/build-android-preview.sh customer`
- `bash scripts/verify-android-preview.sh customer`
- `bash scripts/build-android-preview.sh driver`
- `bash scripts/verify-android-preview.sh driver`

Die Skripte erzeugen das native Projekt aus der Konfiguration neu. Keine manuellen Änderungen in `android/` vornehmen. Die APKs liegen unter `artifacts/luxore-customer-preview-arm64.apk` bzw. `artifacts/luxore-driver-preview-arm64.apk`. Beide enthalten das JavaScript-Bundle, sind mit dem lokalen Android-Debugschlüssel signiert und ausschließlich für interne Tests gedacht. Die zusätzliche `.preview`-Appkennung und „Test“ im Namen trennen sie von späteren regulären Apps. Nicht als Store-Release verwenden. Jedes Paket richtet sich an ARM64-Geräte.

Interne Cloud-APK-Profile stehen zusätzlich in `eas.json`. Kein Expo/EAS-Konto wurde eingerichtet und kein kostenpflichtiger Cloud-Build gestartet.

Das Projekt liegt im gemeinsamen Repository und importiert die Website-Validierung. Bei Cloud-Builds muss der Repository-Stamm mit `lib/inquiry.ts` enthalten bleiben; nur den `mobile/`-Ordner hochzuladen reicht nicht.

## Noch erforderlich
- Öffentliche, serverseitig verifizierte Identität und API-Zugang für native Clients; private Sites-Identitätsheader sind kein Mobile-Login und werden nicht nachgebaut.
- Kartenkonto, echte Suche, Route, verbindliche Angebote, Buchung und Statusanbindung.
- Fahrerfreigabe, Push, Hintergrundortung, unabhängiger Hintergrunddispatcher.
- Geräteprüfungen: Start, Berechtigungsablehnung, GPS, E-Mail-Handler fehlt, Teilen abbrechen, Tastatur, große Schrift, Zurück-Taste, Prozessneustart, Offlinebetrieb.
- Die Fahrer-App darf erst dann online schalten, wenn Authentifizierung, Freigabe und aktiver Standortkanal tatsächlich bestätigt sind.

## Nachweise dieses Arbeitsschritts
TypeScript-Prüfung beider Projekte; Android-JavaScript-Export für Kunden- und Fahrer-Variante; Erzeugung des nativen Kundenprojekts und Prüfung des Manifestes. Zusätzlich vollständiger nativer APK-Build und statische APK-Prüfungen. Noch keine Geräte-, Emulator- oder Hintergrundtests.

## Offizielle Grundlagen
- https://docs.expo.dev/more/create-expo/
- https://docs.expo.dev/build-reference/apk/
- https://docs.expo.dev/versions/latest/sdk/location/

## Stand 0.2: Online-Buchung

`src/App.tsx` ist jetzt eine HTTPS-WebView der gemeinsamen Kunden-/Fahreroberfläche. Kein Expo-Konto, kein `expo-updates` und kein eingebetteter Sites-Zugangsschlüssel. Web-Änderungen werden beim erneuten Öffnen geladen. Android-Rahmen, Berechtigungen und App-Icon benötigen eine neue APK. Einmaliges Update von 0.1 auf 0.2 erforderlich. Browseroberfläche verwendet ein HttpOnly-Gerätecookie; alle API-Rechte werden serverseitig geprüft. Details: `../docs/ONLINE-BETRIEBSTEST.md`. Der bisher beschriebene E-Mail-Anfrageumfang gilt nur für 0.1.

Icons: `assets/icon-ride.png` und `assets/icon-driver.png`, mit dem eingebauten Bildgenerator erstellt. Prompt: luxuriöses goldenes L-Monogramm mit subtiler Straßenform auf Schwarz; Driver-Variante in Schwarz auf Gold mit DRIVER-Schriftzug.

## Stand 0.3: Reduzierter App-Rahmen

Version 0.3.0 (Android versionCode 3) entfernt die doppelte Marken-Kopfzeile. Der native Rahmen verwendet einen hellen Hintergrund und dunkle Statussymbole. Die Kundenoberfläche startet mit Zielsuche, Sofortfahrt und Planung; Fahrer erhalten Fahren/Umsatz/Auto als Navigation. Diese native Änderung braucht einmal die neue interne APK. Keine neue Berechtigung und kein zusätzlicher Login. Die produktive Webseite bleibt dieselbe. Ohne gültigen Mapbox-Token sind Adressen, Routen und Live-Karten weiterhin nicht funktionsfähig.

## Stand 0.3.1: Feste Skalierung und Buchungsdialog

Android versionCode 4 schaltet die WebView-Zoomsteuerung, seitliche Scrollindikatoren und den Overscroll-Effekt ab. Die mobilen Routen liefern zusätzlich einen festen Viewport; die öffentliche Website behält ihre normale Skalierung. Karteninteraktionen bleiben innerhalb von Mapbox implementiert. Der mobile Buchungsdialog setzt auch die unabhängige CSS-Eigenschaft `translate` zurück, damit er nicht halb außerhalb des Bildschirms erscheint. Eingaben bleiben vertikal scrollbar, auch mit geöffneter Tastatur.

Graue Kartenflächen im Startbildschirm, in der Fahrzeugauswahl und im Checkout sowie dekorative Trennlinien wurden durch weiße Flächen ersetzt. Die Buchungsfelder behalten klare Unterlinien, ausgewählte Fahrzeuge ihren sichtbaren Auswahlrahmen. Der neue Mapbox-Token ist produktiv aktiviert; Kartenstile, Adresssuche und Routenangebot wurden am 25. September 2026 erfolgreich per HTTP geprüft.

Die Dialogkorrektur lädt online nach erneutem Öffnen. Für die nativen Zoom-Einstellungen einmal die APK 0.3.1 über die bestehende Test-App installieren, ohne sie vorher zu löschen; dadurch bleibt die Gerätezuordnung erhalten. TypeScript und die gelieferten Viewport-Metadaten sind geprüft. Physische Geräteprüfung, Tastatur- und Gestentests stehen noch aus.

## Stand 0.4.0: Fahrerstandort im Hintergrund (Android-Code 5)

Die Fahrer-APK enthält jetzt einen nativen Expo-Standortdienst. Die lokale Karte fragt beim Start nach Standortzugriff. Erst „Online gehen“ fordert zusätzlich den Hintergrundzugriff an und startet die Übertragung an die Disposition. In Android „Genauen Standort“ und „Immer zulassen“ aktivieren. Ein Android-Standorthinweis kennzeichnet die laufende Schicht. „Pause machen“ stoppt den nativen Dienst und entzieht die Standortfreigabe; auf der Verbindungsfehlerseite gibt es ebenfalls einen nativen Stoppschalter.

Einmal **die neue Fahrer-APK über die vorhandene Test-App installieren**, nicht vorher deinstallieren, damit die Fahrer-Gerätezuordnung bleibt. Kunden-APK 0.3.1 kann weiterverwendet werden. Weboberflächen aktualisieren sich weiterhin online; native Funktionen und Berechtigungen benötigen dieses APK-Update. Kein Expo-Konto nötig.

Die verschlüsselt im Android-Keystore/SecureStore gespeicherte Standortberechtigung ist auf Fahrer, Schicht und 24 Stunden beschränkt. Serverseitig liegt nur ihr SHA-256-Hash. Sie kann weder Fahrten lesen noch annehmen oder Zahlungen ändern. Pause, neue Schicht, entzogene Fahrerfreigabe oder inaktives Flottenfahrzeug sperren weitere Updates. Veraltete/ungenaue Positionen werden verworfen; ohne frischen Standort erhält ein Fahrer keine Angebote. Netzwerkverlust wird beim nächsten frischen Fix erneut versucht, ohne alte Fahrstrecken nachzusenden. Bei App-Neustart wird eine noch laufende native Schicht wieder angezeigt.

Grenzen: Android kann Hintergrundarbeit bei erzwungenem Beenden oder herstellerspezifischen Energiespareinstellungen stoppen. Dann App erneut öffnen und online gehen. **Fahrtangebote benötigen weiterhin die geöffnete Fahrer-App; native Push-Benachrichtigungen sind noch nicht integriert.** iOS-Hintergrundbetrieb ist nicht Bestandteil dieser Android-Testversion.

Prüfung: TypeScript, Standort-/Autorisierungs- und SQL-Rennentests, lokale HTTP-Abläufe sowie ARM64-APK-Build, Berechtigungen und Signatur. Noch keine Prüfung auf einem physischen Android-Gerät. Vor Betrieb: online gehen, Bildschirm 5 Minuten sperren, danach 5 Minuten Google Maps nutzen; in der Disposition Aktualität/Position kontrollieren, Pause testen, Internet aus/an testen, Berechtigung entziehen und App neu öffnen. Keine Testfahrt abrechnen.

Offizielle Plattformgrenzen: https://docs.expo.dev/versions/v57.0.0/sdk/location/

## Stand 0.4.3: Rückkehr aus dem Hintergrund und Renderer-Wiederherstellung

Version 0.4.3 / Android-Code 8 hält den letzten frischen Hintergrundstandort schichtgebunden im SecureStore vor und gibt ihn beim Wiederöffnen an die Webansicht. Die Vordergrund-Watch startet neu; hängende/überholte Einzelabfragen sperren sie nicht. Status kann keine laufende Schicht durch eine ältere Prüfung beenden. Native Dienst-/Speicheränderungen sind serialisiert; Pause hat Vorrang vor wartenden Wiederaufnahmen. Ein beendeter WebView-Renderer wird einmal je Minute automatisch neu erzeugt, danach bewusstes Verbinden angeboten. Hintergrundtakt weiterhin fünf Sekunden, Vordergrund eine Sekunde. Keine neue Berechtigung.

Beide ARM64-Test-APKs unter `artifacts/Luxore-Driver-Test-0.4.3.apk` und `artifacts/Luxore-Ride-Test-0.4.3.apk`. Pakete bleiben `.preview`; Fahrer-Signatur identisch zu 0.4.2. Über vorhandene Version installieren, ohne Deinstallation. Native Änderungen brauchen dieses einmalige Update. Physischer Android-Test mit aktiver Schicht, Sperrbildschirm, Navigation in anderer App, Netzunterbrechung und Pause steht aus. Einzelheiten, Kostenschutz und Veröffentlichungsblockade: `../docs/COST-GPS-REVIEW.md`.

## Stand 0.4.1: Fahrtalarme während der Online-Schicht (Android-Code 6)

Neue Android-Fahrer-Testversion: Der laufende Standortdienst erhält jetzt ausschließlich die ID und Ablaufzeit eines aktuellen Fahrtangebots. Die Freigabe gewährt weiterhin keinen Zugriff auf Kundendaten, Adressen, Fahrpreise, Annahme oder Zahlung. Die Standortantwort prüft vor Ausgabe nochmals Fahrer, Schicht, gültige Freigabe, verfügbares Flottenfahrzeug, Fahrzeugklasse und Angebotsstatus.

Ein neues Angebot erzeugt eine lokale Android-Benachrichtigung mit Ton/Vibration im Kanal „Fahrtangebote“. Antippen führt ausschließlich zur Fahrer-App; dort werden die aktuellen Angebote neu geladen und serverseitig geprüft. Kein automatisches Annehmen. Doppelte Standortantworten lösen pro Angebot nur einen Alarm aus; der letzte gemeldete Angebotsbezeichner bleibt im SecureStore erhalten. Veraltete und überholte Antworten werden verworfen. Pause räumt den Alarm weg. Bei Ablauf/Zurücknahme räumt der nächste Standortkontakt den Hinweis weg; zusätzlich läuft ein lokaler Ablauf-Timer, soweit Android JavaScript weiter ausführt. Bei gestoppter App/fehlender Verbindung kann ein alter Hinweis verbleiben; Öffnen prüft stets die aktuelle Verfügbarkeit.

Beim Onlinegehen bittet Android zusätzlich um Benachrichtigungsfreigabe. Bei Ablehnung bleibt die App benutzbar und zeigt an, dass Fahrtalarme deaktiviert sind. „Alarm testen“ sendet nur eine klar beschriftete Testbenachrichtigung, ohne Buchung, Fahrerstatus- oder Zahlungsänderung. „Einstellungen“ öffnet die Android-App-Einstellungen. Benutzerdefinierte Stummschaltung, Lautstärke und Nicht-stören-Modus werden respektiert. Die Kunden-App fordert diese Rechte nicht an.

**Dies sind Alarme über den laufenden Hintergrunddienst, kein FCM-/APNs-Pushdienst.** Keine Expo-/Firebase-Anmeldung erforderlich. Nach erzwungenem Beenden, bei unterbrochener Internetverbindung oder ohne frischen GPS-Standort werden keine zeitnahen Alarme zugesichert. Ein unabhängiger Pushdienst und iOS bleiben weitere Arbeitsschritte. Das ersetzt die Aussage aus 0.4.0, dass Angebote ausschließlich bei geöffneter App gemeldet werden.

Einmal die Fahrer-APK 0.4.1 über die vorhandene Testversion installieren. Standort „Immer zulassen“, „Genau“ und Benachrichtigungen erlauben. Anschließend „Alarm testen“. Vor Fahrbetrieb mit einem zweiten Gerät eine echte interne Testanfrage stellen, während das Fahrergerät gesperrt ist bzw. Google Maps zeigt. Ton, Hinweis, Öffnen, Annahme, Ablauf, Pause und Offline/Online prüfen. Automatisierte Logik-/SQL-/HTTP-Prüfungen und APK-Prüfungen ersetzen diesen noch ausstehenden Handset-Test nicht.

Offizielle Benachrichtigungs-API: https://docs.expo.dev/versions/v57.0.0/sdk/notifications/

## Stand 0.4.2: GPS-Nachlauf und Fahrtrichtung (Android-Code 7)

Die Fahreransicht fordert bei geöffneter App Navigationstreue und einen 1-Sekunden-Takt an. Fahrtrichtung und Geschwindigkeit werden an die Webansicht übergeben; ungültige Messwerte werden verworfen. Der Hintergrunddienst bleibt bei fünf Sekunden, mit höherer angeforderter Genauigkeit. Keine neuen Berechtigungen. Die Webansicht nutzt diese Daten für stabilere Richtung und kürzeres Einholen neuer Positionen; Mapbox-Verkehrsrouten werden während einer zugeordneten aktiven Fahrt nachgeladen.

`artifacts/Luxore-Driver-Test-0.4.2.apk` über die vorhandene Version installieren, ohne Deinstallation. Signatur identisch mit 0.4.1, Paket `de.luxoreride.driver.preview`, Version 0.4.2 / Code 7. Native Typprüfung, vollständiger Release-APK-Build, Signaturvergleich und Manifest-/Bundle-Prüfung bestanden. Messintervall und Positionsqualität müssen noch auf dem tatsächlichen Fahrerhandy bei einer Probefahrt geprüft werden. Einzelheiten und Testfälle stehen in `../docs/NAVIGATION-MOTION.md`.
