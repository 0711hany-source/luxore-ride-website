# LUXORÉ Ride / Driver

Version 0.5.2 / Build 12 startet mit echten React-Native-Oberflächen: Start, Konto mit E-Mail-Code, Profil und Menü. Beide Varianten verwenden dieselben Komponenten, feste Kopf-/Fußnavigation und helle Premium-Farben. Die Karten-, Fahrt-, Flotten- und Betreiberansichten bleiben vorerst eingebettet; die vollständige native Umstellung ist noch offen.

Beim Start und bei der Rückkehr in den Vordergrund laufen Kontoabfrage und Wiederaufnahme der bestehenden Fahrerortung unabhängig voneinander. Eine langsame oder fehlgeschlagene Kontoabfrage verzögert die Standortwiederaufnahme nicht mehr. Wiederholte Vordergrundereignisse teilen laufende Anfragen; eine neue Kontositzung wird unabhängig von einer alten geprüft. Bestehende Standortberechtigungen und die eigene Schichtfreigabe bleiben erforderlich. Der Android-Geräte-/GPS-Nachweis steht weiterhin aus.

Alle API-, Fahrt-, Standort- und Signalverbindungen verwenden ausschließlich https://luxoreride.de. Kontositzungen liegen in Expo SecureStore und werden beim Start/Rückkehr serverseitig überprüft. Netzfehler löschen sie nicht. Die Übertragung in eingebettete Fahrtseiten erfolgt per eigener POST-Brücke mit HTTP-only-Cookie, ohne Zugangsdaten in URLs. Keine Fremdanmeldung. Kunden und Fahrer brauchen für die neuen internen Apps ein eigenes verifiziertes Konto; Fahrer bleiben bis zur Freigabe ungeprüft.

Einmalig die neue APK installieren. Danach laden eingebettete Seiten geprüfte Serveränderungen beim Öffnen. Änderungen an nativen Oberflächen, Berechtigungen und Bibliotheken benötigen weiterhin einen neuen Build; native Online-Updates sind noch nicht eingerichtet.

## Interne Android-Builds

`bash scripts/build-android-preview.sh customer`, danach `bash scripts/verify-android-preview.sh customer`; für Fahrer entsprechend `driver`. Varianten nacheinander bauen, da beide denselben generierten Android-Baum nutzen. Build-Skripte während einer laufenden Ausführung nicht verändern. Varianten und deaktivierter Design-Vorschaumodus werden explizit eingebettet. Interne Kennungen behalten `.preview` und bisherige interne Signatur; niemals als Store-Release verwenden. `app.config.ts` / `eas.json` bereiten getrennte Store-Kennungen und iOS vor.

Für die reine Designprüfung: `APP_PREVIEW=true EXPO_PUBLIC_APP_PREVIEW=true APP_VARIANT=customer EXPO_PUBLIC_APP_VARIANT=customer npx expo export --platform web --clear --output-dir ../work/native-preview-customer`. Für die zweite Variante Werte auf `driver` ändern. `--clear` verhindert Wiederverwendung statisch eingebetteter Werte der anderen Variante. Diese Browserprüfung verwendet keine reale Konto-/Fahrtsitzung und ersetzt keine Geräteprüfung.

## Freischaltung und Grenzen

Turso Production und die kostenlose, verifizierte Resend-Verbindung sind eingerichtet. Die letzte Freigabe für die Produktivschalter und Betreiberadresse steht aus; ohne diese bleibt der Server im Umstellungsmodus. Neustart mit neuen Profilen ist bestätigt; Altbestand bleibt erhalten. Siehe `docs/INDEPENDENT-DEPLOYMENT.md` und `docs/ACTIVATION.md`.

Fahrer benötigen Vordergrund-/Hintergrundstandort und ggf. Fahrtalarme. Gesperrten Bildschirm, externe Navigation, Wiederaufnahme und Neustart auf echten Android-Geräten prüfen. Kunden brauchen keine Fahrer-Hintergrundortung. iOS-, Store-, native Karten- und kommerzielle Betriebsfreigabe sind noch offen.
