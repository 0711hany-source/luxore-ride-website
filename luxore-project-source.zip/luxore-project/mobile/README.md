# LUXORÉ Ride / Driver

Version 0.6.1 / Build 15: Nach der eigenen Anmeldung startet die Fahrer-App direkt im nativen Cockpit, ohne einen zweiten eingebetteten Fahrerbereich zu öffnen. Karte (Mapbox SDK v11 via @rnmapbox/maps 10.3.7), GPS, Schicht, Fahrzeugwechsel, Angebote, Fahrtstatus, Zahlung, Tagesumsatz, Fahrzeuge/Team und Bordbestand sind native React-Native-Oberflächen. Flotten-Fahrzeugformulare öffnen als feste native Dialoge mit Tastaturausgleich. Kunden-Buchungen bleiben noch eingebettet. Erweiterte Disposition, Betreiber-Freigaben und Verwaltung bleiben im eigenen Webportal; keine vollständige native Umstellung beider Apps behaupten.

Beim Start und bei der Rückkehr in den Vordergrund laufen Kontoabfrage und Wiederaufnahme der bestehenden Fahrerortung unabhängig voneinander. Eine langsame oder fehlgeschlagene Kontoabfrage verzögert die Standortwiederaufnahme nicht mehr. Wiederholte Vordergrundereignisse teilen laufende Anfragen; eine neue Kontositzung wird unabhängig von einer alten geprüft. Bestehende Standortberechtigungen und die eigene Schichtfreigabe bleiben erforderlich. Der Android-Geräte-/GPS-Nachweis steht weiterhin aus.

Alle API-, Fahrt-, Standort- und Signalverbindungen verwenden ausschließlich https://luxoreride.de. Kontositzungen liegen in Expo SecureStore und werden beim Start/Rückkehr serverseitig überprüft. Netzfehler löschen sie nicht. Nur in der Kunden-App erfolgt die Übertragung in eingebettete Fahrtseiten per authentifiziertem GET mit Anmeldeheader und anschließendem HTTP-only-Cookie, ohne Zugangsdaten in URLs. Android-WebView verwirft bei POST-Quellen eigene Header; Version 0.5.3 korrigiert diesen Übergang. Keine Fremdanmeldung. Kunden und Fahrer brauchen für die neuen internen Apps ein eigenes verifiziertes Konto; Fahrer bleiben bis zur Freigabe ungeprüft.

Einmalig die neue APK installieren. Danach laden eingebettete Seiten geprüfte Serveränderungen beim Öffnen. Änderungen an nativen Oberflächen, Berechtigungen und Bibliotheken benötigen weiterhin einen neuen Build; native Online-Updates sind noch nicht eingerichtet.

## Interne Android-Builds

`bash scripts/build-android-preview.sh customer`, danach `bash scripts/verify-android-preview.sh customer`; für Fahrer entsprechend `driver`. Varianten nacheinander bauen, da beide denselben generierten Android-Baum nutzen. Build-Skripte während einer laufenden Ausführung nicht verändern. Varianten und deaktivierter Design-Vorschaumodus werden explizit eingebettet. Interne Kennungen behalten `.preview` und bisherige interne Signatur; niemals als Store-Release verwenden. `app.config.ts` / `eas.json` bereiten getrennte Store-Kennungen und iOS vor.

Für die reine Designprüfung: `APP_PREVIEW=true EXPO_PUBLIC_APP_PREVIEW=true APP_VARIANT=customer EXPO_PUBLIC_APP_VARIANT=customer npx expo export --platform web --clear --output-dir ../work/native-preview-customer`. Für die zweite Variante Werte auf `driver` ändern. `--clear` verhindert Wiederverwendung statisch eingebetteter Werte der anderen Variante. Diese Browserprüfung verwendet keine reale Konto-/Fahrtsitzung und ersetzt keine Geräteprüfung.

## Freischaltung und Grenzen

Turso Production und die kostenlose, verifizierte Resend-Verbindung sind eingerichtet. Produktivschalter und Betreiberadresse sind konkret bestätigt und aktiviert; die eigene Betreiberanmeldung ist im Live-Browser nachgewiesen. Neustart mit neuen Profilen ist bestätigt; Altbestand bleibt erhalten. Siehe `docs/INDEPENDENT-DEPLOYMENT.md` und `docs/ACTIVATION.md`.

Fahrer benötigen Vordergrund-/Hintergrundstandort und ggf. Fahrtalarme. Gesperrten Bildschirm, externe Navigation, Wiederaufnahme und Neustart auf echten Android-Geräten prüfen. Kunden brauchen keine Fahrer-Hintergrundortung. iOS-, Store-, vollständige native Kunden-Umstellung und kommerzielle Betriebsfreigabe sind noch offen. Der Fahrer-Kartenrenderer ist nun nativ; ein wirklicher Geräte-/GPS-Test steht aus.

## Native Fahrerarchitektur · 0.6.1

Der Fahrerzweig mountet `RideWorkspace` nicht. `use-driver-gps` besitzt einen kontinuierlichen Expo-Standort-Watcher (Navigationsgenauigkeit, angefragte 1-Sekunden-Kadenz) und holt beim Wiederöffnen einen frischen gespeicherten Standort. Der bestehende Hintergrunddienst mit Foreground-Service übermittelt unabhängig von Bildschirm und Karte; Vordergrund-Uploads werden auf maximal einen je drei Sekunden begrenzt und überlappen nicht. Android entscheidet über die tatsächliche Messkadenz. Keine künstlichen GPS-Punkte in Production.

`NavigationMotion(true)` zeichnet den einzelnen Pfeil mit begrenzter straßennaher Animation. Die echte Messung bleibt für Vermittlung und Navigation unverändert. Die native Kamera folgt nach einer Kartengeste nach drei Sekunden wieder. 3D-Gebäude und Route sind nativ; Mapbox-Logo/Herkunftsinfo bleiben sichtbar oberhalb des Sheets. Der Kartenrenderer wird bei App-Hintergrund und anderen Menüseiten freigegeben; GPS-Dienst bleibt unabhängig. Ein JS-Fehler in der Karte zeigt eine Wiederherstellung statt die Fahrtoberfläche auszublenden. Native System-/GPU-Abstürze lassen sich dadurch nicht generell ausschließen.

Profile werden sitzungsgebunden in SecureStore zwischengespeichert, damit eine fehlende Konto-Netzantwort beim Neustart nicht sämtliche Oberfläche zurücksetzt. Berechtigungen und Änderungen werden weiterhin am Server geprüft. Annahme, Fahrtstatus, Bordübergabe und Kassierbestätigungen haben ausschließlich Wischaktionen, keine parallelen Tippknöpfe. Die Bestandskorrektur schützt mit Revision vor konkurrierenden Änderungen und behält den Entwurf bei Fehlern. `docs/NATIVE-DRIVER-060.md` dokumentiert Prüfungen und offene Gerätefälle.

Startschutz 0.6.1: SDK-Import erst nach App-Registrierung; Tokeninitialisierung vor Mapbox-Telemetrie. SDK-Konstruktion und echte APK-Kaltstarts im isolierten Android-Emulator geprüft; kein physischer Schicht-/Hintergrund-GPS-Nachweis. Details und reproduzierbare SDK-Probe in `../docs/ANDROID-STARTUP-061.md`.
