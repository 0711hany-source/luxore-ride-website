# LUXORÉ Ride / Driver

Beide Varianten verwenden ausschließlich `https://luxoreride.de`, einschließlich Hintergrundortung und Fahrtsignalen. Eigene Luxóre-Konten oder bestehende freigegebene Gerätesitzungen; keine Fremdanmeldung.

Version 0.4.4 / Build 9 wechselt die eingebettete Serveradresse. Dafür ist einmalig eine neue APK nötig. Danach werden Änderungen an der Weboberfläche beim Öffnen geladen; neue native Berechtigungen und Funktionen benötigen weiterhin einen nativen Build.

Interne Android-Kennungen behalten `.preview` und die bisherige interne Signatur; Store-Kennungen sind `de.luxoreride.customer` und `de.luxoreride.driver`. Android-Kunden-App und Fahrer-App getrennt bauen. `app.config.ts` / `eas.json` enthalten auch iOS-Vorbereitung, noch keine native iOS-Freigabe.

Der Server wird unabhängig auf Vercel mit einer dauerhaften SQL-Datenbank vorbereitet. Bis zu deren Einrichtung und Datenübernahme bleibt die Online-Vermittlung im Umstellungsmodus. Ohne funktionierende Gegenstelle keine Fahrtbereitschaft behaupten. Bestehende Flotten-/Fahrerzuordnungen vor Freigabe übernehmen und mit den neuen Geräten prüfen.

Fahrer benötigen Vordergrund-/Hintergrundstandort und ggf. Fahrtalarme. Android-Herstellereinstellungen, gesperrter Bildschirm, externe Navigation und Neustart auf echten Geräten prüfen. Kunden benötigen keine Fahrer-Hintergrundortung.
