import React, { useEffect, useMemo, useState } from 'react';
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { routeMissingText } from './account-client';
import { CHAT_BODY_MAX, chatDraft, useRideChat, type ChatMessage } from './ride-chat';
import { colors, layout, maxFontScale, radii, space, typography } from './theme';

export type RideChatProps = {
  /** Sitzungs-Token des angemeldeten Kontos. */
  token: string | null;
  /** Die Fahrt, zu der geschrieben wird. */
  bookingId: string | null;
  /** true, solange die Fahrt angenommen, vor Ort oder unterwegs ist. Sonst wird nichts gezeigt und nichts abgerufen. */
  active: boolean;
  /** Überschrift des Fensters, z. B. „Nachricht an deinen Chauffeur“. */
  title: string;
  /** Text des Knopfs, z. B. „Nachricht an Chauffeur“ oder „Nachricht an Fahrgast“. */
  label: string;
  /** Neue fremde Nachricht, während das Fenster geschlossen ist. */
  onIncoming?: (text: string) => void;
  /** Äußerer Stil des Knopfs (Abstände im einbindenden Bildschirm). */
  style?: StyleProp<ViewStyle>;
};

const clock = (at: number) => {
  const d = new Date(at);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
};

/**
 * Knopf mit Zähler ungelesener Nachrichten; ein Tipp öffnet den Chat im
 * Vollbild. Das Eingabefeld steht oben unter der Kopfzeile, die neuesten
 * Nachrichten direkt darunter – so liegt beides nie unter der Tastatur.
 */
export default function RideChat({
  token,
  bookingId,
  active,
  title,
  label,
  onIncoming,
  style,
}: RideChatProps) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState('');
  const usable = active && !!token && !!bookingId;
  const chat = useRideChat({
    token,
    bookingId,
    active: usable,
    open: open && usable,
    onIncoming,
  });
  useEffect(() => {
    if (!usable) setOpen(false);
  }, [usable]);
  useEffect(() => setDraft(''), [bookingId]);
  // Neueste zuerst: Sie stehen direkt unter dem Eingabefeld.
  const newestFirst = useMemo(
    () => [...chat.messages].reverse(),
    [chat.messages],
  );
  if (!usable) return null;

  const writable = chat.available && chat.rideOpen;
  const ready = writable && !chat.sending && !!chatDraft(draft);
  const notice = !chat.available
    ? routeMissingText
    : !chat.rideOpen
      ? 'Der Chat ist nur während einer laufenden Fahrt verfügbar.'
      : chat.error ||
        (chat.offline
          ? 'Keine Verbindung zu LUXORÉ. Neue Nachrichten erscheinen, sobald du wieder online bist.'
          : '');
  const submit = async () => {
    if (!ready) return;
    if (await chat.send(draft)) setDraft('');
  };
  const badge = chat.unread > 99 ? '99+' : String(chat.unread);

  return (
    <>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={
          chat.unread
            ? `${label}. ${chat.unread} ungelesene ${chat.unread === 1 ? 'Nachricht' : 'Nachrichten'}.`
            : label
        }
        onPress={() => setOpen(true)}
        style={({ pressed }) => [s.button, pressed && s.pressed, style]}
      >
        <Text
          maxFontSizeMultiplier={maxFontScale}
          numberOfLines={1}
          style={s.buttonText}
        >
          {label}
        </Text>
        {chat.unread > 0 && (
          <View style={s.badge}>
            <Text maxFontSizeMultiplier={maxFontScale} style={s.badgeText}>
              {badge}
            </Text>
          </View>
        )}
      </Pressable>
      <Modal
        visible={open}
        animationType="slide"
        statusBarTranslucent
        onRequestClose={() => setOpen(false)}
      >
        <View style={s.sheet}>
          <View style={s.head}>
            <Text
              accessibilityRole="header"
              maxFontSizeMultiplier={maxFontScale}
              numberOfLines={2}
              style={s.title}
            >
              {title}
            </Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Chat schließen"
              hitSlop={8}
              onPress={() => setOpen(false)}
              style={({ pressed }) => [s.close, pressed && s.pressed]}
            >
              <Text maxFontSizeMultiplier={maxFontScale} style={s.closeText}>
                Schließen
              </Text>
            </Pressable>
          </View>
          <Text maxFontSizeMultiplier={maxFontScale} style={s.hint}>
            Die Nachricht läuft über LUXORÉ. Deine Telefonnummer bleibt privat.
          </Text>
          <View style={s.compose}>
            <TextInput
              accessibilityLabel="Deine Nachricht"
              autoFocus
              multiline
              editable={writable}
              value={draft}
              onChangeText={(t) => {
                setDraft(t);
                if (chat.error) chat.clearError();
              }}
              maxLength={CHAT_BODY_MAX}
              placeholder="Deine Nachricht"
              placeholderTextColor={colors.gray}
              maxFontSizeMultiplier={maxFontScale}
              style={[s.input, !writable && s.disabled]}
            />
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Nachricht senden"
              accessibilityState={{ disabled: !ready, busy: chat.sending }}
              disabled={!ready}
              onPress={submit}
              style={({ pressed }) => [
                s.send,
                !ready && s.disabled,
                pressed && s.pressed,
              ]}
            >
              <Text maxFontSizeMultiplier={maxFontScale} style={s.sendText}>
                {chat.sending ? 'Sendet …' : 'Senden'}
              </Text>
            </Pressable>
          </View>
          <Text maxFontSizeMultiplier={maxFontScale} style={s.hint}>
            {draft.length}/{CHAT_BODY_MAX}
          </Text>
          {!!notice && (
            <Text
              accessibilityRole="alert"
              accessibilityLiveRegion="polite"
              maxFontSizeMultiplier={maxFontScale}
              style={[s.notice, !!chat.error && writable && s.noticeError]}
            >
              {notice}
            </Text>
          )}
          {/* At most 200 short messages per ride: a plain list is enough. */}
          <ScrollView
            keyboardShouldPersistTaps="handled"
            style={s.list}
            contentContainerStyle={s.listContent}
          >
            {newestFirst.length > 1 && (
              <Text maxFontSizeMultiplier={maxFontScale} style={s.order}>
                Neueste zuerst
              </Text>
            )}
            {newestFirst.length === 0 && writable && (
              <Text maxFontSizeMultiplier={maxFontScale} style={s.empty}>
                Noch keine Nachrichten. Schreib kurz, was wichtig ist – zum
                Beispiel, wo genau du wartest.
              </Text>
            )}
            {newestFirst.map((message) => (
              <Bubble key={message.id} message={message} />
            ))}
          </ScrollView>
        </View>
      </Modal>
    </>
  );
}

function Bubble({ message }: { message: ChatMessage }) {
  const time = clock(message.created_at);
  return (
    <View
      accessible
      accessibilityLabel={`${message.mine ? 'Du' : 'Nachricht'}, ${time} Uhr: ${message.body}`}
      style={[s.bubble, message.mine ? s.mine : s.theirs]}
    >
      <Text
        maxFontSizeMultiplier={maxFontScale}
        selectable
        style={[s.bubbleText, message.mine && s.mineText]}
      >
        {message.body}
      </Text>
      <Text
        maxFontSizeMultiplier={maxFontScale}
        style={[s.time, message.mine && s.mineTime]}
      >
        {time}
      </Text>
    </View>
  );
}

const s = StyleSheet.create({
  button: {
    minHeight: layout.tap,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: space[2],
    borderWidth: 1,
    borderColor: colors.lineStrong,
    borderRadius: radii.m,
    backgroundColor: colors.white,
    paddingHorizontal: space[4],
  },
  buttonText: {
    ...typography.subhead,
    fontWeight: '600',
    color: colors.ink,
    flexShrink: 1,
  },
  badge: {
    minWidth: 24,
    height: 24,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radii.pill,
    backgroundColor: colors.danger,
    paddingHorizontal: space[2],
  },
  badgeText: { ...typography.footnote, fontWeight: '700', color: colors.white },
  pressed: { opacity: 0.7 },
  disabled: { opacity: 0.5 },
  sheet: {
    flex: 1,
    backgroundColor: colors.paper,
    paddingHorizontal: space[4],
    // Unter Statusleiste und Kameraaussparung, auf jedem Gerät.
    paddingTop: 56,
    gap: space[2],
  },
  head: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: space[3],
    minHeight: layout.tap,
  },
  title: { ...typography.headline, color: colors.ink, flex: 1 },
  close: {
    minHeight: layout.tap,
    minWidth: 88,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radii.m,
    borderWidth: 1,
    borderColor: colors.lineStrong,
    backgroundColor: colors.white,
    paddingHorizontal: space[4],
  },
  closeText: { ...typography.subhead, fontWeight: '600', color: colors.ink },
  hint: { ...typography.footnote, color: colors.textMuted },
  compose: { flexDirection: 'row', alignItems: 'stretch', gap: space[2] },
  input: {
    ...typography.body,
    flex: 1,
    color: colors.ink,
    height: 96,
    textAlignVertical: 'top',
    borderWidth: 1,
    borderColor: colors.lineStrong,
    borderRadius: radii.m,
    backgroundColor: colors.white,
    padding: space[3],
  },
  send: {
    minHeight: layout.tap,
    minWidth: 88,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radii.m,
    backgroundColor: colors.ink,
    paddingHorizontal: space[4],
  },
  sendText: { ...typography.subhead, fontWeight: '600', color: colors.white },
  notice: {
    ...typography.footnote,
    color: colors.textMuted,
    borderRadius: radii.s,
    backgroundColor: colors.sand,
    padding: space[3],
  },
  noticeError: { color: colors.danger, backgroundColor: colors.dangerWash },
  list: { flex: 1 },
  listContent: { gap: space[2], paddingTop: space[2], paddingBottom: space[6] },
  order: { ...typography.footnote, color: colors.gray, textAlign: 'center' },
  empty: {
    ...typography.subhead,
    color: colors.textMuted,
    textAlign: 'center',
    paddingVertical: space[5],
  },
  bubble: {
    maxWidth: '84%',
    borderRadius: radii.m,
    paddingHorizontal: space[3],
    paddingVertical: space[2],
    gap: space[1],
  },
  mine: { alignSelf: 'flex-end', backgroundColor: colors.ink },
  theirs: {
    alignSelf: 'flex-start',
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.line,
  },
  bubbleText: { ...typography.body, color: colors.ink },
  mineText: { color: colors.white },
  time: { ...typography.footnote, color: colors.textMuted },
  mineTime: { color: colors.textOnInkMuted, textAlign: 'right' },
});
