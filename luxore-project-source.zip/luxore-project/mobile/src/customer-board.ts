import type { Booking } from '../../lib/mobility/domain.ts';
import {
  cartShortage,
  combined,
  countCart,
  menu,
  parseCart,
  storedOrder,
  type BoardStock,
  type Cart,
} from '../../lib/mobility/refreshments.ts';
export type BoardRequest = {
  id: string;
  action: 'request';
  revision: number;
  cart: Cart;
  requestId: string;
};
export type BoardStore = {
  load(): Promise<BoardRequest | null>;
  save(body: BoardRequest): Promise<void>;
  clear(expectedId: string): Promise<void>;
};
/** Pieces in the assigned car; `null` until the chauffeur and car are known. */
export function boardStock(b: Booking): BoardStock | null {
  const raw: unknown = b.board_stock;
  // No car yet, or a server that does not send the stock: nothing to offer.
  if (
    !['accepted', 'arrived', 'riding'].includes(b.status) ||
    !raw ||
    typeof raw !== 'object' ||
    Array.isArray(raw)
  )
    return null;
  // Only known articles with whole pieces above zero count as stock.
  return Object.fromEntries(
    menu.flatMap((item) => {
      const count = (raw as Record<string, unknown>)[item.id];
      return typeof count === 'number' && Number.isInteger(count) && count > 0
        ? [[item.id, count]]
        : [];
    }),
  );
}
/** The board only opens once a car is assigned – only its stock is offered. */
export const boardOpen = (b: Booking) =>
  boardStock(b) !== null && b.payment_status === 'unpaid';
/**
 * Whether the ride screen offers the board. Only `open` shows an entry;
 * `empty` (car without stock) and `waiting` (no car yet, or the server sends
 * no stock) show nothing at all.
 */
export function boardEntry(b: Booking): 'open' | 'empty' | 'waiting' {
  const stock = boardStock(b);
  if (!stock || b.payment_status !== 'unpaid') return 'waiting';
  return Object.keys(stock).length ||
    countCart(storedOrder(b.refreshments).requested)
    ? 'open'
    : 'empty';
}
/** Articles shown on the board: in stock, or still in the open order. */
export const boardOffered = (stock: BoardStock | null, cart: Cart) =>
  (id: string) => (stock?.[id] || 0) > 0 || (cart[id] || 0) > 0;
export class CustomerBoardController {
  private state: {
    booking: Booking;
    cart: Cart;
    revision: number;
    restoring: boolean;
    pending: BoardRequest | null;
    submitting: boolean;
    error: string;
    confirmed: boolean;
  };
  private listeners = new Set<() => void>();
  private active = false;
  private connected = false;
  private initialized = false;
  constructor(
    private owner: string,
    booking: Booking,
    private store: BoardStore,
    private send: (body: BoardRequest) => Promise<Booking>,
    private uuid: () => string,
  ) {
    const order = storedOrder(booking.refreshments);
    this.state = {
      booking,
      cart: { ...order.requested },
      revision: order.revision,
      restoring: true,
      pending: null,
      submitting: false,
      error: '',
      confirmed: false,
    };
  }
  getSnapshot = () => this.state;
  setActive(active: boolean, connected: boolean) {
    this.active = active;
    this.connected = connected;
  }
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  private publish(patch: Partial<typeof this.state>) {
    this.state = { ...this.state, ...patch };
    for (const l of this.listeners) l();
  }
  receive(booking: Booking, active: boolean, connected: boolean) {
    this.active = active;
    this.connected = connected;
    if (
      booking.id === this.state.booking.id &&
      booking.owner_id === this.owner &&
      booking.updated_at >= this.state.booking.updated_at &&
      storedOrder(booking.refreshments).revision >=
        storedOrder(this.state.booking.refreshments).revision
    )
      this.publish({ booking });
  }
  async restore() {
    if (this.initialized) return;
    this.initialized = true;
    try {
      const pending = await this.store.load();
      if (pending) {
        if (
          pending.cart === undefined ||
          pending.id !== this.state.booking.id ||
          pending.action !== 'request' ||
          !Number.isInteger(pending.revision) ||
          pending.revision < 0 ||
          !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(
            pending.requestId,
          )
        )
          throw new Error('invalid');
        this.publish({
          pending: { ...pending, cart: parseCart(pending.cart) },
          cart: parseCart(pending.cart),
          revision: pending.revision,
        });
      }
      this.publish({ restoring: false });
    } catch {
      this.initialized = false;
      this.publish({
        error:
          'Gespeicherte Bestellung konnte nicht geprüft werden. Bitte erneut versuchen.',
      });
    }
  }
  edit(id: string, delta: number) {
    if (
      this.state.restoring ||
      this.state.pending ||
      this.state.submitting ||
      this.state.confirmed
    )
      return;
    try {
      const wanted = (this.state.cart[id] || 0) + delta;
      // Adding is limited to what the car carries; removing always works.
      if (delta > 0) {
        const short = cartShortage(
          { [id]: wanted },
          boardStock(this.state.booking) || {},
        );
        if (short) throw new Error(short.message);
      }
      const cart = parseCart({
        ...this.state.cart,
        [id]: wanted,
      });
      parseCart(
        combined(storedOrder(this.state.booking.refreshments).delivered, cart),
      );
      this.publish({ cart, error: '' });
    } catch (e) {
      this.publish({ error: (e as Error).message });
    }
  }
  review() {
    if (
      !this.active ||
      !this.connected ||
      this.state.pending ||
      this.state.submitting ||
      this.state.restoring
    )
      return;
    const order = storedOrder(this.state.booking.refreshments);
    this.publish({
      cart: { ...order.requested },
      revision: order.revision,
      error: '',
      confirmed: false,
    });
  }
  async submit() {
    if (
      !this.active ||
      !this.connected ||
      this.state.restoring ||
      this.state.submitting ||
      this.state.confirmed
    )
      return;
    const { booking, revision, cart } = this.state;
    if (booking.owner_id !== this.owner) return;
    let pending = this.state.pending;
    if (!pending) {
      if (
        !boardOpen(booking) ||
        storedOrder(booking.refreshments).revision !== revision
      ) {
        this.publish({
          error:
            'Die Fahrt oder Bordbestellung wurde geändert. Bitte den aktuellen Stand übernehmen und neu prüfen.',
        });
        return;
      }
      try {
        parseCart({ ...cart });
        const short = cartShortage(cart, boardStock(booking) || {});
        if (short) throw new Error(short.message);
        // Delivered articles continue to consume this ride's allowance and quantity limits.
        const delivered = storedOrder(booking.refreshments).delivered;
        parseCart(
          Object.fromEntries(
            [...new Set([...Object.keys(cart), ...Object.keys(delivered)])].map(
              (id) => [id, (cart[id] || 0) + (delivered[id] || 0)],
            ),
          ),
        );
      } catch (e) {
        this.publish({ error: (e as Error).message });
        return;
      }
      pending = {
        id: booking.id,
        action: 'request',
        revision,
        cart: { ...cart },
        requestId: this.uuid(),
      };
    }
    this.publish({ submitting: true, error: '' });
    try {
      await this.store.save(pending);
    } catch {
      this.publish({
        submitting: false,
        error:
          'Die Bestellung konnte nicht sicher gespeichert werden. Es wurde nichts gesendet.',
      });
      return;
    }
    this.publish({ pending });
    try {
      const result = await this.send(pending);
      if (
        result.id !== booking.id ||
        result.owner_id !== this.owner ||
        result.refreshments?.lastRequest?.id !== pending.requestId
      )
        throw new Error(
          'Die Bestätigung ist unvollständig. Bitte dieselbe Bestellung erneut bestätigen.',
        );
      // Keep the durable retry if clearing fails; another identical request only acknowledges it.
      await this.store.clear(pending.requestId);
      this.publish({ booking: result, pending: null, confirmed: true });
    } catch (e) {
      const status = (e as { status?: number }).status;
      if (status && [400, 401, 403, 404, 409, 422].includes(status)) {
        try {
          await this.store.clear(pending.requestId);
          this.publish({ pending: null });
        } catch {
          this.publish({
            error:
              'Die abgelehnte Bestellung konnte im Gerätespeicher nicht abgeschlossen werden. Bitte dieselbe Anfrage erneut prüfen.',
          });
          return;
        }
      }
      this.publish({ error: (e as Error).message });
    } finally {
      this.publish({ submitting: false });
    }
  }
}
