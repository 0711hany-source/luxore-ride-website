import React, { useEffect, useState, useSyncExternalStore } from 'react';
import {
  AppState,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Users, Mail, RefreshCw, ShieldCheck } from 'lucide-react-native';
import { nativeApi } from './account-client';
import SwipeAction from './SwipeAction';
import {
  FleetInvitationsController,
  type InvitationData,
  type InvitationAction,
  invitationCode,
} from './fleet-invitations';
export default function FleetInvitationsScreen(props: {
  token: string;
  userId: string;
  active: boolean;
  onDone: () => void;
}) {
  return <Workspace key={props.token} {...props} />;
}
function Workspace({
  token,
  userId,
  active,
  onDone,
}: {
  token: string;
  userId: string;
  active: boolean;
  onDone: () => void;
}) {
  const [controller] = useState(
    () =>
      new FleetInvitationsController(
        userId,
        (signal) =>
          nativeApi<InvitationData>(
            'fleets',
            token,
            undefined,
            undefined,
            signal,
          ),
        (body) => nativeApi('fleets', token, body),
      ),
  );
  const state = useSyncExternalStore(
    controller.subscribe,
    controller.getSnapshot,
    controller.getSnapshot,
  );
  const [foreground, setForeground] = useState(
    AppState.currentState === 'active',
  );
  const [mode, setMode] = useState<'join' | 'create'>('join');
  const [code, setCode] = useState('');
  const [selected, setSelected] = useState('');
  const [now, setNow] = useState(Date.now);
  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) =>
      setForeground(s === 'active'),
    );
    return () => sub.remove();
  }, []);
  useEffect(() => {
    controller.setActive(active && foreground);
    if (!active || !foreground) return;
    const clock = setInterval(() => setNow(Date.now()), 1000);
    return () => {
      clearInterval(clock);
      controller.setActive(false);
    };
  }, [active, foreground, controller]);
  useEffect(() => () => controller.dispose(), [controller]);
  const fleetId = state.fleets.some((f) => f.id === selected)
    ? selected
    : state.fleets[0]?.id || '';
  const body: InvitationAction =
    state.uncertain ||
    (mode === 'join'
      ? { action: 'join', code: invitationCode(code) }
      : { action: 'invite_driver', fleetId });
  const created = state.invitation,
    valid = !!created && created.expiresAt > now;
  return (
    <SafeAreaView style={s.root} edges={['bottom']}>
      <KeyboardAvoidingView
        style={s.root}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={s.content}
        >
          <View style={s.row}>
            <Users color={gold} size={35} />
            <Pressable
              accessibilityLabel="Einladungszugang aktualisieren"
              disabled={state.loading || !!state.busy}
              onPress={() => void controller.refresh()}
              style={s.refresh}
            >
              <RefreshCw color={gold} size={23} />
            </Pressable>
          </View>
          <Text style={s.eyebrow}>DEIN TEAM. EINE FLOTTE.</Text>
          <Text style={s.title}>Einladungen.</Text>
          <Text style={s.muted}>
            Mit einem persönlichen Code zur richtigen Flotte. Die Leitung prüft
            anschließend dein Fahrerprofil.
          </Text>
          <View style={s.tabs}>
            <Pressable
              accessibilityRole="tab"
              accessibilityState={{ selected: mode === 'join' }}
              disabled={!!state.busy || !!state.uncertain}
              onPress={() => setMode('join')}
              style={[s.tab, mode === 'join' && s.chosen]}
            >
              <Text style={[s.tabText, mode === 'join' && s.white]}>
                Code einlösen
              </Text>
            </Pressable>
            <Pressable
              accessibilityRole="tab"
              accessibilityState={{ selected: mode === 'create' }}
              disabled={!!state.busy || !!state.uncertain}
              onPress={() => setMode('create')}
              style={[s.tab, mode === 'create' && s.chosen]}
            >
              <Text style={[s.tabText, mode === 'create' && s.white]}>
                Team einladen
              </Text>
            </Pressable>
          </View>
          {mode === 'join' ? (
            <>
              <Text style={s.section}>Einladungscode</Text>
              <TextInput
                accessibilityLabel="Flotteneinladungscode"
                placeholder="LX-…"
                value={code}
                editable={!state.busy && !state.uncertain && !state.joined}
                onChangeText={setCode}
                autoCapitalize="characters"
                autoCorrect={false}
                maxLength={50}
                style={s.input}
              />
              <Text style={s.muted}>
                Du brauchst ein Fahrerprofil. Ein neuer Beitritt ist erst nach
                beendeter Schicht und abgerechneten Fahrten möglich. Deine
                Freigabe erfolgt durch die Leitung.
              </Text>
            </>
          ) : (
            <>
              <Text style={s.section}>Deine Flotte</Text>
              {state.fleets.map((f) => (
                <Pressable
                  key={f.id}
                  disabled={!!state.busy || !!state.uncertain}
                  accessibilityRole="radio"
                  accessibilityState={{ checked: f.id === fleetId }}
                  onPress={() => setSelected(f.id)}
                  style={[s.fleet, f.id === fleetId && s.fleetChosen]}
                >
                  <Text style={s.name}>{f.name}</Text>
                  <Text style={s.muted}>
                    {f.owner_id === userId
                      ? 'Flottenbesitzer'
                      : 'Stellvertretung'}
                  </Text>
                </Pressable>
              ))}
              {!state.fleets.length && (
                <Text style={s.muted}>
                  {state.loading
                    ? 'Leitungszugang wird geprüft …'
                    : 'Nur Besitzer und Stellvertretung können ihr Team einladen.'}
                </Text>
              )}
              <Text style={s.muted}>
                Der Code gilt 24 Stunden. Erstelle ihn nur für Personen, die
                deiner Flotte beitreten sollen.
              </Text>
            </>
          )}
          {!!created && (
            <View style={s.card}>
              <Mail color="#d7bd89" size={28} />
              <Text style={s.white}>Dein Einladungscode</Text>
              <Text selectable style={s.code}>
                {created.code}
              </Text>
              <Text style={s.detail}>
                {valid
                  ? 'Gültig bis ' +
                    new Date(created.expiresAt).toLocaleString('de-DE', {
                      timeZone: 'Europe/Berlin',
                    })
                  : 'Code abgelaufen · neue Einladung erstellen'}
              </Text>
              <Pressable
                accessibilityLabel="Einladung teilen"
                disabled={!valid || !active || !foreground}
                onPress={() =>
                  void Share.share({ message: created.shareText }).catch(
                    () => {},
                  )
                }
                style={s.share}
              >
                <Text style={s.name}>Einladung teilen</Text>
              </Pressable>
            </View>
          )}
          {!!state.uncertain && (
            <Text style={s.error}>
              Die Antwort fehlt.{' '}
              {state.uncertain.action === 'join'
                ? 'Bestätige nur denselben Code erneut.'
                : 'Eine erneute Erstellung kann einen weiteren Code erzeugen. Bestätige sie nur für dieselbe Flotte.'}{' '}
              Es wird nichts automatisch wiederholt.
            </Text>
          )}
          {!!state.error && (
            <Text accessibilityRole="alert" style={s.error}>
              {state.error}
            </Text>
          )}
          {!!state.notice && (
            <Text accessibilityRole="alert" style={s.notice}>
              {state.notice}
            </Text>
          )}
          {state.joined && (
            <>
              <ShieldCheck color={gold} size={32} />
              <Pressable
                onPress={onDone}
                style={s.share}
                accessibilityLabel="Zum Fahrerbereich"
              >
                <Text style={s.name}>Zum Fahrerbereich</Text>
              </Pressable>
            </>
          )}
        </ScrollView>
        {!state.joined && (
          <View style={s.footer}>
            <SwipeAction
              key={JSON.stringify(body) + !!state.busy}
              label={
                state.uncertain
                  ? 'Gleichen Vorgang erneut bestätigen'
                  : mode === 'join'
                    ? 'Flotte beitreten'
                    : created
                      ? 'Neue Einladung erstellen'
                      : 'Einladung erstellen'
              }
              disabled={!controller.canSubmit(body, now)}
              busy={!!state.busy}
              onComplete={() => void controller.submit(body)}
            />
          </View>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
const ink = '#161a20',
  gold = '#aa8345';
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  content: { padding: 22, gap: 17, paddingBottom: 30 },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  refresh: { padding: 12 },
  eyebrow: { fontSize: 10, letterSpacing: 1.5, color: gold, fontWeight: '700' },
  title: { fontSize: 32, fontWeight: '700', color: ink },
  muted: { fontSize: 13, lineHeight: 21, color: '#777e87' },
  tabs: { flexDirection: 'row', gap: 8 },
  tab: {
    flex: 1,
    borderRadius: 22,
    paddingVertical: 14,
    alignItems: 'center',
    backgroundColor: '#fbf8f2',
  },
  chosen: { backgroundColor: ink },
  tabText: { fontSize: 13, fontWeight: '600', color: ink },
  white: { color: '#fff' },
  section: { fontSize: 19, fontWeight: '600', color: ink },
  input: {
    borderBottomWidth: 1,
    borderColor: '#aa8345',
    fontSize: 17,
    paddingVertical: 17,
    color: ink,
  },
  fleet: { padding: 18, borderRadius: 20, gap: 5, backgroundColor: '#fbf8f2' },
  fleetChosen: { borderWidth: 1, borderColor: gold },
  name: { fontSize: 15, fontWeight: '600', color: ink },
  card: { backgroundColor: ink, padding: 23, borderRadius: 25, gap: 16 },
  code: { color: '#d7bd89', fontSize: 17, fontWeight: '600', lineHeight: 27 },
  detail: { color: '#d8dadd', fontSize: 12 },
  share: {
    padding: 17,
    borderRadius: 19,
    backgroundColor: '#f4e6cc',
    alignItems: 'center',
  },
  error: { color: '#a04c40', fontSize: 13, lineHeight: 21 },
  notice: { color: '#347961', fontSize: 13, lineHeight: 21 },
  footer: { padding: 22, backgroundColor: '#fff' },
});
