import React, { useEffect, useState, useSyncExternalStore } from 'react';
import {
  AppState,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Users, Mail, RefreshCw, ShieldCheck } from 'lucide-react-native';
import { nativeApi } from './account-client';
import SwipeAction from './SwipeAction';
import {
  FleetInvitationsController,
  type InvitationData,
  type InvitationAction,
  invitationCode,
} from './fleet-invitations';
import { colors, layout, radii, space, typography } from './theme';
export default function FleetInvitationsScreen(props: {
  token: string;
  userId: string;
  active: boolean;
  onDone: () => void;
}) {
  return <Workspace key={props.token} {...props} />;
}
function Workspace({
  token,
  userId,
  active,
  onDone,
}: {
  token: string;
  userId: string;
  active: boolean;
  onDone: () => void;
}) {
  const [controller] = useState(
    () =>
      new FleetInvitationsController(
        userId,
        (signal) =>
          nativeApi<InvitationData>(
            'fleets',
            token,
            undefined,
            undefined,
            signal,
          ),
        (body) => nativeApi('fleets', token, body),
      ),
  );
  const state = useSyncExternalStore(
    controller.subscribe,
    controller.getSnapshot,
    controller.getSnapshot,
  );
  const [foreground, setForeground] = useState(
    AppState.currentState === 'active',
  );
  const [mode, setMode] = useState<'join' | 'create'>('join');
  const [code, setCode] = useState('');
  const [selected, setSelected] = useState('');
  const [now, setNow] = useState(Date.now);
  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) =>
      setForeground(s === 'active'),
    );
    return () => sub.remove();
  }, []);
  useEffect(() => {
    controller.setActive(active && foreground);
    if (!active || !foreground) return;
    const clock = setInterval(() => setNow(Date.now()), 1000);
    return () => {
      clearInterval(clock);
      controller.setActive(false);
    };
  }, [active, foreground, controller]);
  useEffect(() => () => controller.dispose(), [controller]);
  const fleetId = state.fleets.some((f) => f.id === selected)
    ? selected
    : state.fleets[0]?.id || '';
  const body: InvitationAction =
    state.uncertain ||
    (mode === 'join'
      ? { action: 'join', code: invitationCode(code) }
      : { action: 'invite_driver', fleetId });
  const created = state.invitation,
    valid = !!created && created.expiresAt > now;
  return (
    <SafeAreaView style={s.root} edges={['bottom']}>
      <KeyboardAvoidingView
        style={s.root}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={s.content}
        >
          <View style={s.row}>
            <Users color={gold} size={35} />
            <Pressable
              accessibilityLabel="Einladungszugang aktualisieren"
              disabled={state.loading || !!state.busy}
              onPress={() => void controller.refresh()}
              style={s.refresh}
            >
              <RefreshCw color={gold} size={23} />
            </Pressable>
          </View>
          <Text style={s.eyebrow}>DEIN TEAM. EINE FLOTTE.</Text>
          <Text style={s.title}>Einladungen.</Text>
          <Text style={s.muted}>
            Mit einem persönlichen Code zur richtigen Flotte. Die Leitung prüft
            anschließend dein Fahrerprofil.
          </Text>
          <View style={s.tabs}>
            <Pressable
              accessibilityRole="tab"
              accessibilityState={{ selected: mode === 'join' }}
              disabled={!!state.busy || !!state.uncertain}
              onPress={() => setMode('join')}
              style={[s.tab, mode === 'join' && s.chosen]}
            >
              <Text style={[s.tabText, mode === 'join' && s.white]}>
                Code einlösen
              </Text>
            </Pressable>
            <Pressable
              accessibilityRole="tab"
              accessibilityState={{ selected: mode === 'create' }}
              disabled={!!state.busy || !!state.uncertain}
              onPress={() => setMode('create')}
              style={[s.tab, mode === 'create' && s.chosen]}
            >
              <Text style={[s.tabText, mode === 'create' && s.white]}>
                Team einladen
              </Text>
            </Pressable>
          </View>
          {mode === 'join' ? (
            <>
              <Text style={s.section}>Einladungscode</Text>
              <TextInput
                accessibilityLabel="Flotteneinladungscode"
                placeholder="LX-…"
                value={code}
                editable={!state.busy && !state.uncertain && !state.joined}
                onChangeText={setCode}
                autoCapitalize="characters"
                autoCorrect={false}
                maxLength={50}
                style={s.input}
              />
              <Text style={s.muted}>
                Du brauchst ein Fahrerprofil. Ein neuer Beitritt ist erst nach
                beendeter Schicht und abgerechneten Fahrten möglich. Deine
                Freigabe erfolgt durch die Leitung.
              </Text>
            </>
          ) : (
            <>
              <Text style={s.section}>Deine Flotte</Text>
              {state.fleets.map((f) => (
                <Pressable
                  key={f.id}
                  disabled={!!state.busy || !!state.uncertain}
                  accessibilityRole="radio"
                  accessibilityState={{ checked: f.id === fleetId }}
                  onPress={() => setSelected(f.id)}
                  style={[s.fleet, f.id === fleetId && s.fleetChosen]}
                >
                  <Text style={s.name}>{f.name}</Text>
                  <Text style={s.muted}>
                    {f.owner_id === userId
                      ? 'Flottenbesitzer'
                      : 'Stellvertretung'}
                  </Text>
                </Pressable>
              ))}
              {!state.fleets.length && (
                <Text style={s.muted}>
                  {state.loading
                    ? 'Leitungszugang wird geprüft …'
                    : 'Nur Besitzer und Stellvertretung können ihr Team einladen.'}
                </Text>
              )}
              <Text style={s.muted}>
                Der Code gilt 24 Stunden. Erstelle ihn nur für Personen, die
                deiner Flotte beitreten sollen.
              </Text>
            </>
          )}
          {!!created && (
            <View style={s.card}>
              <Mail color={colors.goldLight} size={28} />
              <Text style={s.white}>Dein Einladungscode</Text>
              <Text selectable style={s.code}>
                {created.code}
              </Text>
              <Text style={s.detail}>
                {valid
                  ? 'Gültig bis ' +
                    new Date(created.expiresAt).toLocaleString('de-DE', {
                      timeZone: 'Europe/Berlin',
                    })
                  : 'Code abgelaufen · neue Einladung erstellen'}
              </Text>
              <Pressable
                accessibilityLabel="Einladung teilen"
                disabled={!valid || !active || !foreground}
                onPress={() =>
                  void Share.share({ message: created.shareText }).catch(
                    () => {},
                  )
                }
                style={s.share}
              >
                <Text style={s.name}>Einladung teilen</Text>
              </Pressable>
            </View>
          )}
          {!!state.uncertain && (
            <Text style={s.error}>
              Die Antwort fehlt.{' '}
              {state.uncertain.action === 'join'
                ? 'Bestätige nur denselben Code erneut.'
                : 'Eine erneute Erstellung kann einen weiteren Code erzeugen. Bestätige sie nur für dieselbe Flotte.'}{' '}
              Es wird nichts automatisch wiederholt.
            </Text>
          )}
          {!!state.error && (
            <Text accessibilityRole="alert" style={s.error}>
              {state.error}
            </Text>
          )}
          {!!state.notice && (
            <Text accessibilityRole="alert" style={s.notice}>
              {state.notice}
            </Text>
          )}
          {state.joined && (
            <>
              <ShieldCheck color={gold} size={32} />
              <Pressable
                onPress={onDone}
                style={s.share}
                accessibilityLabel="Zum Fahrerbereich"
              >
                <Text style={s.name}>Zum Fahrerbereich</Text>
              </Pressable>
            </>
          )}
        </ScrollView>
        {!state.joined && (
          <View style={s.footer}>
            <SwipeAction
              key={JSON.stringify(body) + !!state.busy}
              label={
                state.uncertain
                  ? 'Gleichen Vorgang erneut bestätigen'
                  : mode === 'join'
                    ? 'Flotte beitreten'
                    : created
                      ? 'Neue Einladung erstellen'
                      : 'Einladung erstellen'
              }
              disabled={!controller.canSubmit(body, now)}
              busy={!!state.busy}
              onComplete={() => void controller.submit(body)}
            />
          </View>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
const ink = colors.ink,
  gold = colors.gold;
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
  content: { padding: layout.screenMargin, gap: space[4], paddingBottom: space[6] },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  refresh: { padding: space[3] },
  eyebrow: { ...typography.label, color: colors.goldText },
  title: { ...typography.largeTitle, color: ink },
  muted: { ...typography.footnote, color: colors.gray },
  tabs: { flexDirection: 'row', gap: space[2] },
  tab: {
    flex: 1,
    borderRadius: radii.pill,
    paddingVertical: space[4],
    alignItems: 'center',
    backgroundColor: colors.paper,
  },
  chosen: { backgroundColor: ink },
  tabText: { ...typography.footnote, fontWeight: '600', color: ink },
  white: { color: colors.white },
  section: { ...typography.headline, color: ink },
  input: {
    borderBottomWidth: 1,
    borderColor: colors.gold,
    fontSize: typography.body.fontSize,
    paddingVertical: space[4],
    color: ink,
  },
  fleet: { padding: space[4], borderRadius: radii.l, gap: space[1], backgroundColor: colors.paper },
  fleetChosen: { borderWidth: 1, borderColor: gold },
  name: { ...typography.subhead, fontWeight: '600', color: ink },
  card: { backgroundColor: ink, padding: space[5], borderRadius: radii.xl, gap: space[4] },
  code: { color: colors.goldLight, ...typography.headline },
  detail: { color: colors.line, ...typography.footnote },
  share: {
    padding: space[4],
    borderRadius: radii.l,
    backgroundColor: colors.goldWash,
    alignItems: 'center',
  },
  error: { color: colors.danger, ...typography.footnote },
  notice: { color: colors.success, ...typography.footnote },
  footer: { padding: layout.screenMargin, backgroundColor: colors.white },
});
