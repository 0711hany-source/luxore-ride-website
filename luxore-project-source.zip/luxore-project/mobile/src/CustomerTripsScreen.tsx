import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import {
  ActivityIndicator,
  AppState,
  Linking,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  ArrowRight,
  CalendarDays,
  CarFront,
  Check,
  ChevronRight,
  Clock3,
  MapPin,
  Phone,
  RefreshCw,
  X,
} from 'lucide-react-native';
import { statusNames, type Booking } from '../../lib/mobility/domain';
import { className } from '../../lib/ride-domain';
import { nativeApi } from './account-client';
import { euros } from './driver-model';
import SwipeAction from './SwipeAction';
import {
  CustomerTripsController,
  canCancelTrip,
  tripGroups,
} from './customer-trips';
function date(booking: Booking) {
  return new Date(booking.scheduled_at || booking.created_at).toLocaleString(
    'de-DE',
    { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' },
  );
}
export default function CustomerTripsScreen({
  token,
  active,
  onBook,
}: {
  token: string;
  active: boolean;
  onBook: () => void;
}) {
  const controller = useMemo(
    () =>
      new CustomerTripsController((body) => nativeApi('bookings', token, body)),
    [token],
  );
  const state = useSyncExternalStore(
    controller.subscribe,
    controller.getSnapshot,
    controller.getSnapshot,
  );
  const visible = useRef(active);
  const [selected, setSelected] = useState<string | null>(null);
  const booking = state.bookings.find((b) => b.id === selected);
  useEffect(() => {
    visible.current = active;
    controller.setActive(active && AppState.currentState === 'active');
  }, [active, controller]);
  useEffect(() => {
    const listener = AppState.addEventListener('change', (next) =>
      controller.setActive(visible.current && next === 'active'),
    );
    const timer = setInterval(() => void controller.refresh(), 10000);
    return () => {
      clearInterval(timer);
      listener.remove();
      // Effect cleanup may run again under React StrictMode. Stop reads and
      // invalidate old responses; useSyncExternalStore removes its subscription.
      controller.setActive(false);
    };
  }, [controller]);
  return (
    <View style={s.root}>
      <ScrollView
        contentContainerStyle={s.content}
        showsVerticalScrollIndicator={false}
      >
        <Text style={s.eyebrow}>DEIN LUXÓRE</Text>
        <View style={s.headingRow}>
          <Text style={s.title}>Deine Fahrten.</Text>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Fahrten aktualisieren"
            onPress={() => void controller.refresh()}
            disabled={state.refreshing || !!state.changing}
            style={s.round}
          >
            {state.refreshing ? (
              <ActivityIndicator color={gold} />
            ) : (
              <RefreshCw size={21} color={ink} />
            )}
          </Pressable>
        </View>
        <Text style={s.detail}>
          Deine nächste Ankunft. Und die Wege dahinter.
        </Text>
        {!!state.loadError && (
          <View style={s.message}>
            <Text accessibilityRole="alert" style={s.error}>
              {state.loadError}
            </Text>
            {state.bookings.length > 0 && (
              <Text style={s.detail}>
                Letzter Stand bleibt sichtbar. Status und Änderungen nach
                erfolgreicher Verbindung prüfen.
              </Text>
            )}
          </View>
        )}
        {!!state.actionError && (
          <Text accessibilityRole="alert" style={s.error}>
            {state.actionError}
          </Text>
        )}
        {!!state.notice && (
          <Text accessibilityRole="text" style={s.success}>
            {state.notice}
          </Text>
        )}
        {!state.loaded && !state.loadError && (
          <ActivityIndicator color={gold} />
        )}
        {state.loaded && !state.bookings.length && !state.loadError && (
          <View style={s.empty}>
            <CalendarDays size={36} color={gold} />
            <Text style={s.section}>Deine erste Fahrt wartet.</Text>
            <Text style={s.detail}>
              Sobald du eine Fahrt anfragst, findest du Status und Details hier.
            </Text>
            <Pressable
              accessibilityRole="button"
              onPress={onBook}
              style={s.primary}
            >
              <Text style={s.primaryText}>Fahrt anfragen</Text>
              <ArrowRight size={19} color="#fff" />
            </Pressable>
          </View>
        )}
        {tripGroups(state.bookings)
          .filter((group) => group.items.length)
          .map((group) => (
            <View key={group.title} style={s.group}>
              <Text style={s.section}>{group.title}</Text>
              {group.items.map((trip) => (
                <Pressable
                  key={trip.id}
                  accessibilityRole="button"
                  accessibilityLabel={`${statusNames[trip.status]} · ${trip.route.destination.label}`}
                  onPress={() => setSelected(trip.id)}
                  style={s.card}
                >
                  <View style={s.row}>
                    <View style={s.badge}>
                      <CarFront size={22} color={gold} />
                    </View>
                    <View style={s.flex}>
                      <Text style={s.status}>{statusNames[trip.status]}</Text>
                      <Text style={s.detail}>
                        {date(trip)} · {className(trip.service)}
                      </Text>
                    </View>
                    <ChevronRight size={18} color={ink} />
                  </View>
                  <Text numberOfLines={2} style={s.destination}>
                    {trip.route.destination.label}
                  </Text>
                  <Text numberOfLines={1} style={s.detail}>
                    Ab {trip.route.pickup.label}
                  </Text>
                  <View style={s.row}>
                    <Text style={s.price}>{euros(trip.price)}</Text>
                    <Text style={s.detail}>
                      {trip.status === 'completed'
                        ? trip.payment_status === 'paid'
                          ? 'Bezahlt'
                          : 'Zahlung noch offen'
                        : trip.status === 'reserved'
                          ? 'Fahrerzusage ausstehend'
                          : ''}
                    </Text>
                  </View>
                </Pressable>
              ))}
            </View>
          ))}
        {state.updatedAt && (
          <Text style={s.footer}>
            Stand{' '}
            {new Date(state.updatedAt).toLocaleTimeString('de-DE', {
              hour: '2-digit',
              minute: '2-digit',
            })}
            {state.loadError ? ' · Verbindung unterbrochen' : ''}
          </Text>
        )}
      </ScrollView>
      <Modal
        visible={active && !!booking}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => {
          if (!state.changing) setSelected(null);
        }}
      >
        <SafeAreaView style={s.root} edges={['top', 'bottom']}>
          <View style={s.sheetHeader}>
            <Text style={s.section}>Fahrtdetails</Text>
            <Pressable
              accessibilityLabel="Fahrtdetails schließen"
              disabled={!!state.changing}
              onPress={() => setSelected(null)}
              style={s.round}
            >
              <X color={ink} size={23} />
            </Pressable>
          </View>
          {booking && (
            <ScrollView contentContainerStyle={s.content}>
              <Text style={s.eyebrow}>
                {className(booking.service).toUpperCase()}
              </Text>
              <Text style={s.sheetTitle}>{statusNames[booking.status]}</Text>
              <View style={s.row}>
                <Clock3 size={19} color={gold} />
                <Text style={s.detail}>{date(booking)}</Text>
              </View>
              <View style={s.route}>
                <View style={s.row}>
                  <MapPin size={20} color={gold} />
                  <View style={s.flex}>
                    <Text style={s.eyebrow}>ABHOLUNG</Text>
                    <Text style={s.place}>{booking.route.pickup.label}</Text>
                  </View>
                </View>
                <View style={s.row}>
                  <Check size={20} color={gold} />
                  <View style={s.flex}>
                    <Text style={s.eyebrow}>ZIEL</Text>
                    <Text style={s.place}>
                      {booking.route.destination.label}
                    </Text>
                  </View>
                </View>
              </View>
              <View style={s.row}>
                <Text style={[s.section, s.flex]}>
                  {['cancelled', 'unavailable'].includes(booking.status)
                    ? 'Angefragter Preis'
                    : 'Gesamtpreis'}
                </Text>
                <Text style={s.price}>{euros(booking.price)}</Text>
              </View>
              {booking.status === 'reserved' && (
                <Text style={s.detail}>
                  Deine Reservierung ist vorgemerkt. Sie ist erst mit
                  Fahrerzusage bestätigt.
                </Text>
              )}
              {booking.status === 'completed' && (
                <Text style={s.detail}>
                  {booking.payment_status === 'paid'
                    ? 'Zahlung erfasst.'
                    : 'Die Zahlung ist noch offen.'}
                </Text>
              )}
              {booking.driver && (
                <View style={s.route}>
                  <Text style={s.eyebrow}>DEIN CHAUFFEUR</Text>
                  <Text style={s.section}>{booking.driver.name}</Text>
                  <Text style={s.detail}>
                    {booking.driver.vehicle} · {booking.driver.plate}
                  </Text>
                  {['accepted', 'arrived', 'riding'].includes(booking.status) &&
                    booking.driver.phone && (
                      <Pressable
                        accessibilityRole="button"
                        style={s.contact}
                        onPress={() =>
                          void Linking.openURL(
                            'tel:' +
                              booking.driver!.phone.replace(/[^+\d]/g, ''),
                          )
                        }
                      >
                        <Phone color={gold} size={19} />
                        <Text style={s.place}>Fahrer kontaktieren</Text>
                      </Pressable>
                    )}
                </View>
              )}
              {!!state.loadError && (
                <Text accessibilityRole="alert" style={s.error}>
                  {state.loadError}
                </Text>
              )}
              {!!state.actionError && (
                <Text accessibilityRole="alert" style={s.error}>
                  {state.actionError}
                </Text>
              )}
              {canCancelTrip(booking) && (
                <View style={s.group}>
                  <Text style={s.detail}>
                    Du möchtest diese Fahrt nicht mehr? Bestätige die
                    Stornierung durch vollständiges Wischen.
                  </Text>
                  <SwipeAction
                    key={booking.id}
                    label="Fahrt stornieren"
                    disabled={!!state.loadError || !!state.changing}
                    busy={state.changing === booking.id}
                    onComplete={() => void controller.cancel(booking.id)}
                  />
                </View>
              )}
              <Pressable
                accessibilityRole="button"
                style={s.contact}
                onPress={() => {
                  setSelected(null);
                  onBook();
                }}
              >
                <ArrowRight color={gold} size={19} />
                <Text style={s.place}>Zur Buchung & Live-Karte</Text>
              </Pressable>
            </ScrollView>
          )}
        </SafeAreaView>
      </Modal>
    </View>
  );
}
const ink = '#161a20',
  gold = '#aa8345';
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  content: { padding: 24, paddingBottom: 38, gap: 18 },
  headingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  title: {
    fontSize: 32,
    lineHeight: 38,
    color: ink,
    fontWeight: '600',
    letterSpacing: -1,
  },
  sheetTitle: {
    fontSize: 28,
    lineHeight: 34,
    color: ink,
    fontWeight: '600',
    letterSpacing: -0.7,
  },
  eyebrow: { color: gold, fontSize: 10, fontWeight: '700', letterSpacing: 1.6 },
  detail: { fontSize: 13, lineHeight: 20, color: '#727782' },
  round: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  group: { gap: 12 },
  section: { fontSize: 17, color: ink, fontWeight: '600' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  flex: { flex: 1, gap: 6 },
  badge: {
    height: 44,
    width: 44,
    borderRadius: 22,
    backgroundColor: '#fcf5e8',
    alignItems: 'center',
    justifyContent: 'center',
  },
  card: {
    padding: 20,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: '#eee5d6',
    gap: 15,
    backgroundColor: '#fff',
  },
  status: { fontSize: 14, fontWeight: '600', color: gold },
  destination: { fontSize: 20, lineHeight: 25, fontWeight: '600', color: ink },
  price: { fontSize: 22, fontWeight: '600', color: ink },
  empty: { paddingVertical: 24, gap: 16 },
  primary: {
    minHeight: 54,
    borderRadius: 27,
    backgroundColor: ink,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  primaryText: { fontSize: 15, color: '#fff', fontWeight: '600' },
  message: { gap: 10 },
  error: { fontSize: 13, lineHeight: 20, color: '#a33c32' },
  success: { fontSize: 14, color: '#356a51' },
  footer: { fontSize: 11, color: '#7d7e80', textAlign: 'center' },
  sheetHeader: {
    paddingHorizontal: 24,
    paddingTop: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  route: { padding: 20, borderRadius: 22, backgroundColor: '#fcf9f2', gap: 22 },
  place: { fontSize: 15, lineHeight: 23, color: ink, fontWeight: '500' },
  contact: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    minHeight: 48,
  },
});
