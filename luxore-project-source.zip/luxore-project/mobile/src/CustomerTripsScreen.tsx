import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import {
  ActivityIndicator,
  AppState,
  Linking,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  ArrowRight,
  CalendarDays,
  CarFront,
  Check,
  ChevronRight,
  Clock3,
  MapPin,
  Phone,
  RefreshCw,
  X,
} from 'lucide-react-native';
import { statusNames, type Booking } from '../../lib/mobility/domain';
import { className } from '../../lib/ride-domain';
import { nativeApi } from './account-client';
import { euros } from './driver-model';
import SwipeAction from './SwipeAction';
import {
  CustomerTripsController,
  canCancelTrip,
  tripGroups,
} from './customer-trips';
import { colors, layout, radii, space, typography } from './theme';
function date(booking: Booking) {
  return new Date(booking.scheduled_at || booking.created_at).toLocaleString(
    'de-DE',
    { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' },
  );
}
export default function CustomerTripsScreen({
  token,
  active,
  onBook,
  onLive,
}: {
  token: string;
  active: boolean;
  onBook: () => void;
  onLive?: (id: string) => void;
}) {
  const controller = useMemo(
    () =>
      new CustomerTripsController((body, signal) =>
        nativeApi('bookings', token, body, undefined, signal),
      ),
    [token],
  );
  const state = useSyncExternalStore(
    controller.subscribe,
    controller.getSnapshot,
    controller.getSnapshot,
  );
  const visible = useRef(active);
  const [selected, setSelected] = useState<string | null>(null);
  const [linkError, setLinkError] = useState('');
  const booking = state.bookings.find((b) => b.id === selected);
  useEffect(() => {
    visible.current = active;
    controller.setActive(active && AppState.currentState === 'active');
  }, [active, controller]);
  useEffect(() => {
    const listener = AppState.addEventListener('change', (next) =>
      controller.setActive(visible.current && next === 'active'),
    );
    const timer = setInterval(() => void controller.refresh(), 10000);
    return () => {
      clearInterval(timer);
      listener.remove();
      // Effect cleanup may run again under React StrictMode. Stop reads and
      // invalidate old responses; useSyncExternalStore removes its subscription.
      controller.setActive(false);
    };
  }, [controller]);
  return (
    <View style={s.root}>
      <ScrollView
        contentContainerStyle={s.content}
        showsVerticalScrollIndicator={false}
      >
        <Text style={s.eyebrow}>DEIN LUXORÉ</Text>
        <View style={s.headingRow}>
          <Text style={s.title}>Deine Fahrten.</Text>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Fahrten aktualisieren"
            onPress={() => void controller.refresh()}
            disabled={state.refreshing || !!state.changing}
            style={s.round}
          >
            {state.refreshing ? (
              <ActivityIndicator color={gold} />
            ) : (
              <RefreshCw size={21} color={ink} />
            )}
          </Pressable>
        </View>
        <Text style={s.detail}>
          Deine nächste Ankunft. Und die Wege dahinter.
        </Text>
        {!!state.loadError && (
          <View style={s.message}>
            <Text accessibilityRole="alert" style={s.error}>
              {state.loadError}
            </Text>
            {state.bookings.length > 0 && (
              <Text style={s.detail}>
                Letzter Stand bleibt sichtbar. Status und Änderungen nach
                erfolgreicher Verbindung prüfen.
              </Text>
            )}
          </View>
        )}
        {!!state.actionError && (
          <Text accessibilityRole="alert" style={s.error}>
            {state.actionError}
          </Text>
        )}
        {!!state.notice && (
          <Text accessibilityRole="text" style={s.success}>
            {state.notice}
          </Text>
        )}
        {!state.loaded && !state.loadError && (
          <ActivityIndicator color={gold} />
        )}
        {state.loaded && !state.bookings.length && !state.loadError && (
          <View style={s.empty}>
            <CalendarDays size={36} color={gold} />
            <Text style={s.section}>Deine erste Fahrt wartet.</Text>
            <Text style={s.detail}>
              Sobald du eine Fahrt anfragst, findest du Status und Details hier.
            </Text>
            <Pressable
              accessibilityRole="button"
              onPress={onBook}
              style={s.primary}
            >
              <Text style={s.primaryText}>Fahrt anfragen</Text>
              <ArrowRight size={19} color={colors.white} />
            </Pressable>
          </View>
        )}
        {tripGroups(state.bookings)
          .filter((group) => group.items.length)
          .map((group) => (
            <View key={group.title} style={s.group}>
              <Text style={s.section}>{group.title}</Text>
              {group.items.map((trip) => (
                <Pressable
                  key={trip.id}
                  accessibilityRole="button"
                  accessibilityLabel={`${statusNames[trip.status]} · ${trip.route.destination.label}`}
                  onPress={() => setSelected(trip.id)}
                  style={s.card}
                >
                  <View style={s.row}>
                    <View style={s.badge}>
                      <CarFront size={22} color={gold} />
                    </View>
                    <View style={s.flex}>
                      <Text style={s.status}>{statusNames[trip.status]}</Text>
                      <Text style={s.detail}>
                        {date(trip)} · {className(trip.service)}
                      </Text>
                    </View>
                    <ChevronRight size={18} color={ink} />
                  </View>
                  <Text numberOfLines={2} style={s.destination}>
                    {trip.route.destination.label}
                  </Text>
                  <Text numberOfLines={1} style={s.detail}>
                    Ab {trip.route.pickup.label}
                  </Text>
                  <View style={s.row}>
                    <Text style={s.price}>{euros(trip.price)}</Text>
                    <Text style={s.detail}>
                      {trip.status === 'completed'
                        ? trip.payment_status === 'paid'
                          ? 'Bezahlt'
                          : 'Zahlung noch offen'
                        : trip.status === 'reserved'
                          ? 'Fahrerzusage ausstehend'
                          : ''}
                    </Text>
                  </View>
                </Pressable>
              ))}
            </View>
          ))}
        {state.updatedAt && (
          <Text style={s.footer}>
            Stand{' '}
            {new Date(state.updatedAt).toLocaleTimeString('de-DE', {
              hour: '2-digit',
              minute: '2-digit',
            })}
            {state.loadError ? ' · Verbindung unterbrochen' : ''}
          </Text>
        )}
      </ScrollView>
      <Modal
        visible={active && !!booking}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => {
          if (!state.changing) setSelected(null);
        }}
      >
        <SafeAreaView style={s.root} edges={['top', 'bottom']}>
          <View style={s.sheetHeader}>
            <Text style={s.section}>Fahrtdetails</Text>
            <Pressable
              accessibilityLabel="Fahrtdetails schließen"
              disabled={!!state.changing}
              onPress={() => setSelected(null)}
              style={s.round}
            >
              <X color={ink} size={23} />
            </Pressable>
          </View>
          {booking && (
            <ScrollView contentContainerStyle={s.content}>
              <Text style={s.eyebrow}>
                {className(booking.service).toUpperCase()}
              </Text>
              <Text style={s.sheetTitle}>{statusNames[booking.status]}</Text>
              <View style={s.row}>
                <Clock3 size={19} color={gold} />
                <Text style={s.detail}>{date(booking)}</Text>
              </View>
              <View style={s.route}>
                <View style={s.row}>
                  <MapPin size={20} color={gold} />
                  <View style={s.flex}>
                    <Text style={s.eyebrow}>ABHOLUNG</Text>
                    <Text style={s.place}>{booking.route.pickup.label}</Text>
                  </View>
                </View>
                <View style={s.row}>
                  <Check size={20} color={gold} />
                  <View style={s.flex}>
                    <Text style={s.eyebrow}>ZIEL</Text>
                    <Text style={s.place}>
                      {booking.route.destination.label}
                    </Text>
                  </View>
                </View>
              </View>
              <View style={s.row}>
                <Text style={[s.section, s.flex]}>
                  {['cancelled', 'unavailable'].includes(booking.status)
                    ? 'Angefragter Preis'
                    : 'Gesamtpreis'}
                </Text>
                <Text style={s.price}>{euros(booking.price)}</Text>
              </View>
              {booking.status === 'reserved' && (
                <Text style={s.detail}>
                  Deine Reservierung ist vorgemerkt. Sie ist erst mit
                  Fahrerzusage bestätigt.
                </Text>
              )}
              {booking.status === 'completed' && (
                <Text style={s.detail}>
                  {booking.payment_status === 'paid'
                    ? 'Zahlung erfasst.'
                    : 'Die Zahlung ist noch offen.'}
                </Text>
              )}
              {booking.driver && (
                <View style={s.route}>
                  <Text style={s.eyebrow}>DEIN CHAUFFEUR</Text>
                  <Text style={s.section}>{booking.driver.name}</Text>
                  <Text style={s.detail}>
                    {booking.driver.vehicle} · {booking.driver.plate}
                  </Text>
                  {['accepted', 'arrived', 'riding'].includes(booking.status) &&
                    booking.driver.phone && (
                      <Pressable
                        accessibilityRole="button"
                        style={s.contact}
                        onPress={() =>
                          void Linking.openURL(
                            'tel:' +
                              booking.driver!.phone.replace(/[^+\d]/g, ''),
                          ).then(
                            () => setLinkError(''),
                            () =>
                              setLinkError(
                                'Die Telefon-App konnte nicht geöffnet werden. Bitte die Nummer über dein Telefon wählen.',
                              ),
                          )
                        }
                      >
                        <Phone color={gold} size={19} />
                        <Text style={s.place}>Fahrer kontaktieren</Text>
                      </Pressable>
                    )}
                </View>
              )}
              {!!linkError && (
                <Text accessibilityRole="alert" style={s.error}>
                  {linkError}
                </Text>
              )}
              {!!state.loadError && (
                <Text accessibilityRole="alert" style={s.error}>
                  {state.loadError}
                </Text>
              )}
              {!!state.actionError && (
                <Text accessibilityRole="alert" style={s.error}>
                  {state.actionError}
                </Text>
              )}
              {canCancelTrip(booking) && (
                <View style={s.group}>
                  <Text style={s.detail}>
                    Du möchtest diese Fahrt nicht mehr? Bestätige die
                    Stornierung durch vollständiges Wischen.
                  </Text>
                  <SwipeAction
                    key={booking.id}
                    label="Fahrt stornieren"
                    disabled={!!state.loadError || !!state.changing}
                    busy={state.changing === booking.id}
                    onComplete={() => void controller.cancel(booking.id)}
                  />
                </View>
              )}
              <Pressable
                accessibilityRole="button"
                style={s.contact}
                onPress={() => {
                  setSelected(null);
                  if (onLive) onLive(booking.id);
                  else onBook();
                }}
              >
                <ArrowRight color={gold} size={19} />
                <Text style={s.place}>Live-Karte öffnen</Text>
              </Pressable>
            </ScrollView>
          )}
        </SafeAreaView>
      </Modal>
    </View>
  );
}
const ink = colors.ink,
  gold = colors.gold;
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
  content: { padding: layout.screenMargin, paddingBottom: 40, gap: space[4] },
  headingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: space[3],
  },
  title: {
    ...typography.largeTitle,
    color: ink,
  },
  sheetTitle: {
    ...typography.title1,
    color: ink,
  },
  eyebrow: { color: colors.goldText, ...typography.label },
  detail: { ...typography.footnote, color: colors.gray },
  round: {
    width: layout.tap,
    height: layout.tap,
    borderRadius: radii.pill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  group: { gap: space[3] },
  section: { ...typography.headline, color: ink },
  row: { flexDirection: 'row', alignItems: 'center', gap: space[3] },
  flex: { flex: 1, gap: space[2] },
  badge: {
    height: 44,
    width: 44,
    borderRadius: radii.pill,
    backgroundColor: colors.paper,
    alignItems: 'center',
    justifyContent: 'center',
  },
  card: {
    padding: 20,
    borderRadius: radii.l,
    borderWidth: 1,
    borderColor: colors.sand,
    gap: space[4],
    backgroundColor: colors.white,
  },
  status: { ...typography.footnote, fontWeight: '600', color: colors.goldText },
  destination: { ...typography.title2, color: ink },
  price: { ...typography.title2, fontVariant: ['tabular-nums'], color: ink },
  empty: { paddingVertical: space[5], gap: space[4] },
  primary: {
    minHeight: 54,
    borderRadius: radii.pill,
    backgroundColor: ink,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  primaryText: { ...typography.subhead, fontWeight: '600', color: colors.white },
  message: { gap: space[3] },
  error: { ...typography.footnote, color: colors.danger },
  success: { ...typography.footnote, color: colors.success },
  footer: { ...typography.footnote, color: colors.gray, textAlign: 'center' },
  sheetHeader: {
    paddingHorizontal: layout.screenMargin,
    paddingTop: space[2],
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  route: { padding: 20, borderRadius: radii.l, backgroundColor: colors.paper, gap: space[5] },
  place: { ...typography.subhead, fontWeight: '600', color: ink },
  contact: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space[3],
    minHeight: 48,
  },
});
