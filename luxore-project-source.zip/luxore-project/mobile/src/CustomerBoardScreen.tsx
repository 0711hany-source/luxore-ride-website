import React, {
  useEffect,
  useMemo,
  useState,
  useSyncExternalStore,
} from 'react';
import {
  ActivityIndicator,
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Minus, Plus, X } from 'lucide-react-native';
import { randomUUID } from 'expo-crypto';
import type { Booking } from '../../lib/mobility/domain';
import {
  allowance,
  BOARD_EMPTY,
  cartPrice,
  combined,
  menu,
  storedOrder,
} from '../../lib/mobility/refreshments';
import { className } from '../../lib/ride-domain';
import { nativeApi } from './account-client';
import {
  CustomerBoardController,
  boardOffered,
  boardOpen,
  boardStock,
} from './customer-board';
import { boardStore } from './board-store';
import SwipeAction from './SwipeAction';
import { euros } from './driver-model';
import { colors, layout, radii, space, typography } from './theme';
export default function CustomerBoardScreen({
  token,
  ownerId,
  booking,
  active,
  connected,
  onClose,
  onSaved,
}: {
  token: string;
  ownerId: string;
  booking: Booking;
  active: boolean;
  connected: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  'use no memo';
  const [initialBooking] = useState(booking);
  const controller = useMemo(
    () =>
      new CustomerBoardController(
        ownerId,
        initialBooking,
        boardStore(ownerId, initialBooking.id),
        (body) => nativeApi('refreshments', token, body),
        randomUUID,
      ),
    [ownerId, token, initialBooking],
  );
  const state = useSyncExternalStore(
    controller.subscribe,
    controller.getSnapshot,
    controller.getSnapshot,
  );
  useEffect(() => {
    controller.receive(booking, active, connected);
  }, [controller, booking, active, connected]);
  useEffect(() => {
    void controller.restore();
    return () => controller.setActive(false, false);
  }, [controller]);
  useEffect(() => {
    if (state.confirmed) onSaved();
  }, [state.confirmed, onSaved]);
  const order = storedOrder(state.booking.refreshments),
    tier = allowance[state.booking.service];
  const changed = order.revision !== state.revision;
  const stock = boardStock(state.booking);
  const offered = menu.filter((item) =>
    boardOffered(stock, state.cart)(item.id),
  );
  const locked =
    state.restoring ||
    state.submitting ||
    !!state.pending ||
    state.confirmed ||
    !boardOpen(state.booking) ||
    changed ||
    !active ||
    !connected;
  const projected = cartPrice(
    combined(order.delivered, state.cart),
    state.booking.service,
  );
  const fare =
    state.booking.fare_price ??
    state.booking.price - cartPrice(order.delivered, state.booking.service);
  return (
    <Modal
      visible
      animationType="slide"
      presentationStyle="fullScreen"
      onRequestClose={onClose}
    >
      <SafeAreaView style={s.page}>
        <View style={s.header}>
          <View>
            <Text style={s.brand}>LUXORÉ</Text>
            <Text style={s.title}>Deine Bordkarte</Text>
          </View>
          <Pressable
            accessibilityLabel="Bordkarte schließen"
            accessibilityRole="button"
            onPress={onClose}
            style={s.close}
          >
            <X color={ink} />
          </Pressable>
        </View>
        <ScrollView style={s.scroll} contentContainerStyle={s.content}>
          <Text style={s.class}>
            {className(state.booking.service)} · Für deinen Komfort
          </Text>
          <Text style={s.detail}>
            {tier.drink} Getränke und {tier.snack} Snacks pro Fahrt inklusive.
            Bereits ausgegebene Artikel zählen mit. Weitere Getränke 2,50 €,
            Snacks 1,50 €.
          </Text>
          <Text style={s.detail}>
            Angeboten wird, was im Fahrzeug vorrätig ist. Dein Fahrer sieht die
            bestätigte Auswahl; bezahlt werden nur tatsächlich übergebene
            Artikel.
          </Text>
          {!connected && (
            <Text style={s.error}>
              Der aktuelle Fahrtstand fehlt. Die Auswahl bleibt erhalten; bitte
              die Verbindung abwarten.
            </Text>
          )}
          {state.restoring && (
            <>
              <ActivityIndicator color={gold} />
              <Pressable
                hitSlop={4}
                accessibilityRole="button"
                onPress={() => void controller.restore()}
              >
                <Text style={s.link}>
                  Gespeicherte Bestellung erneut prüfen
                </Text>
              </Pressable>
            </>
          )}
          {!!state.pending && (
            <Text style={s.detail}>
              Die Bestätigung ist noch offen. Erneutes Wischen wiederholt exakt
              dieselbe Bestellung und Wiederholungs-ID.
            </Text>
          )}
          {!boardOpen(state.booking) && !state.pending && (
            <Text style={s.detail}>
              Die Bordkarte ist für diese Fahrt geschlossen.
            </Text>
          )}
          {changed && !state.pending && !state.confirmed && (
            <Pressable
              hitSlop={4}
              accessibilityRole="button"
              disabled={!connected || !active || state.submitting}
              onPress={() => controller.review()}
            >
              <Text style={s.link}>
                Aktuelle Bestellung übernehmen und prüfen
              </Text>
            </Pressable>
          )}
          {!!state.error && (
            <Text accessibilityRole="alert" style={s.error}>
              {state.error}
            </Text>
          )}
          {state.confirmed && (
            <Text accessibilityRole="alert" style={s.success}>
              Bestellung bestätigt. Dein Fahrer kann die Auswahl jetzt sehen.
            </Text>
          )}
          {!offered.length && !state.restoring && (
            <Text style={s.empty}>{BOARD_EMPTY}</Text>
          )}
          <View style={s.grid}>
            {offered.map((item) => (
              <View style={s.product} key={item.id}>
                <Image
                  source={{
                    uri:
                      'https://luxoreride.de/board-products/' +
                      item.id +
                      '.png',
                  }}
                  resizeMode="contain"
                  style={s.image}
                />
                <Text style={s.name}>{item.name}</Text>
                <Text style={s.small}>{item.detail}</Text>
                <Text style={s.small}>
                  {(stock?.[item.id] || 0) > 0
                    ? `Noch ${stock![item.id]} an Bord`
                    : 'Nicht mehr an Bord'}
                </Text>
                {!!order.delivered[item.id] && (
                  <Text style={s.small}>
                    {order.delivered[item.id]} bereits ausgegeben
                  </Text>
                )}
                {!!order.unavailable[item.id] && (
                  <Text style={s.small}>
                    {order.unavailable[item.id]} nicht verfügbar gemeldet
                  </Text>
                )}
                <View style={s.quantity}>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={item.name + ' entfernen'}
                    disabled={locked || !state.cart[item.id]}
                    onPress={() => controller.edit(item.id, -1)}
                    style={s.control}
                  >
                    <Minus color={ink} size={20} />
                  </Pressable>
                  <Text style={s.amount}>{state.cart[item.id] || 0}</Text>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={item.name + ' hinzufügen'}
                    disabled={
                      locked ||
                      (state.cart[item.id] || 0) >= 12 ||
                      (state.cart[item.id] || 0) >= (stock?.[item.id] || 0)
                    }
                    onPress={() => controller.edit(item.id, 1)}
                    style={s.control}
                  >
                    <Plus color={ink} size={20} />
                  </Pressable>
                </View>
              </View>
            ))}
          </View>
        </ScrollView>
        <View style={s.footer}>
          <View style={s.row}>
            <View style={s.flex}>
              <Text style={s.small}>Gesamt bei vollständiger Ausgabe</Text>
              <Text style={s.detail}>
                Bordartikel darin: {euros(projected)}
              </Text>
            </View>
            <Text style={s.price}>{euros(fare + projected)}</Text>
          </View>
          {!state.confirmed && (
            <SwipeAction
              label={
                state.pending
                  ? 'Bestellung erneut bestätigen'
                  : 'Bordbestellung bestätigen'
              }
              disabled={
                !active ||
                !connected ||
                state.restoring ||
                (!state.pending && locked)
              }
              busy={state.submitting}
              onComplete={() => void controller.submit()}
            />
          )}
        </View>
      </SafeAreaView>
    </Modal>
  );
}
const ink = colors.ink,
  gold = colors.gold;
const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: colors.white },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: layout.screenMargin,
    paddingVertical: space[4],
  },
  brand: { color: colors.goldText, fontSize: 12, letterSpacing: 3, fontWeight: '700' },
  title: { color: ink, ...typography.title1, marginTop: space[1] },
  close: { padding: space[4], borderRadius: radii.pill, backgroundColor: colors.paper },
  scroll: { flex: 1 },
  content: { padding: layout.screenMargin, gap: space[4] },
  class: { ...typography.headline, color: ink },
  detail: { ...typography.footnote, color: colors.gray },
  small: { ...typography.footnote, color: colors.gray },
  link: { color: colors.goldText, ...typography.subhead, fontWeight: '600', paddingVertical: space[3] },
  error: { color: colors.danger, ...typography.footnote },
  success: { color: colors.success, ...typography.subhead },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: space[3],
  },
  product: {
    width: '48%',
    borderRadius: radii.l,
    padding: space[4],
    backgroundColor: colors.paper,
    gap: space[2],
  },
  image: { width: '100%', height: 100 },
  name: { ...typography.subhead, fontWeight: '600', color: ink },
  quantity: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 'auto',
    paddingTop: space[3],
  },
  control: {
    minWidth: layout.tap,
    minHeight: layout.tap,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radii.pill,
    backgroundColor: colors.white,
  },
  empty: { ...typography.body, color: ink, paddingVertical: space[4] },
  amount: { color: ink, ...typography.headline, fontVariant: ['tabular-nums'] },
  footer: { paddingHorizontal: layout.screenMargin, paddingTop: space[4], paddingBottom: space[4], gap: space[3] },
  row: { flexDirection: 'row', alignItems: 'center', gap: space[3] },
  flex: { flex: 1 },
  price: { ...typography.title2, fontVariant: ['tabular-nums'], color: ink },
});
