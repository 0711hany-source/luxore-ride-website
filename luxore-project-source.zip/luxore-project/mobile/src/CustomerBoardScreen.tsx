import React, {
  useEffect,
  useMemo,
  useState,
  useSyncExternalStore,
} from 'react';
import {
  ActivityIndicator,
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Minus, Plus, X } from 'lucide-react-native';
import { randomUUID } from 'expo-crypto';
import type { Booking } from '../../lib/mobility/domain';
import {
  allowance,
  cartPrice,
  combined,
  menu,
  storedOrder,
} from '../../lib/mobility/refreshments';
import { className } from '../../lib/ride-domain';
import { nativeApi } from './account-client';
import { CustomerBoardController, boardOpen } from './customer-board';
import { boardStore } from './board-store';
import SwipeAction from './SwipeAction';
import { euros } from './driver-model';
export default function CustomerBoardScreen({
  token,
  ownerId,
  booking,
  active,
  connected,
  onClose,
  onSaved,
}: {
  token: string;
  ownerId: string;
  booking: Booking;
  active: boolean;
  connected: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  'use no memo';
  const [initialBooking] = useState(booking);
  const controller = useMemo(
    () =>
      new CustomerBoardController(
        ownerId,
        initialBooking,
        boardStore(ownerId, initialBooking.id),
        (body) => nativeApi('refreshments', token, body),
        randomUUID,
      ),
    [ownerId, token, initialBooking],
  );
  const state = useSyncExternalStore(
    controller.subscribe,
    controller.getSnapshot,
    controller.getSnapshot,
  );
  useEffect(() => {
    controller.receive(booking, active, connected);
  }, [controller, booking, active, connected]);
  useEffect(() => {
    void controller.restore();
    return () => controller.setActive(false, false);
  }, [controller]);
  useEffect(() => {
    if (state.confirmed) onSaved();
  }, [state.confirmed, onSaved]);
  const order = storedOrder(state.booking.refreshments),
    tier = allowance[state.booking.service];
  const changed = order.revision !== state.revision;
  const locked =
    state.restoring ||
    state.submitting ||
    !!state.pending ||
    state.confirmed ||
    !boardOpen(state.booking) ||
    changed ||
    !active ||
    !connected;
  const projected = cartPrice(
    combined(order.delivered, state.cart),
    state.booking.service,
  );
  const fare =
    state.booking.fare_price ??
    state.booking.price - cartPrice(order.delivered, state.booking.service);
  return (
    <Modal
      visible
      animationType="slide"
      presentationStyle="fullScreen"
      onRequestClose={onClose}
    >
      <SafeAreaView style={s.page}>
        <View style={s.header}>
          <View>
            <Text style={s.brand}>LUXORÉ</Text>
            <Text style={s.title}>Deine Bordkarte</Text>
          </View>
          <Pressable
            accessibilityLabel="Bordkarte schließen"
            accessibilityRole="button"
            onPress={onClose}
            style={s.close}
          >
            <X color={ink} />
          </Pressable>
        </View>
        <ScrollView style={s.scroll} contentContainerStyle={s.content}>
          <Text style={s.class}>
            {className(state.booking.service)} · Für deinen Komfort
          </Text>
          <Text style={s.detail}>
            {tier.drink} Getränke und {tier.snack} Snacks pro Fahrt inklusive.
            Bereits ausgegebene Artikel zählen mit. Weitere Getränke 2,50 €,
            Snacks 1,50 €.
          </Text>
          <Text style={s.detail}>
            Du bearbeitest die noch offene Bestellung. Der Fahrer sieht die
            bestätigte Auswahl. Nach Verfügbarkeit; bezahlt werden nur
            tatsächlich übergebene Artikel.
          </Text>
          {!connected && (
            <Text style={s.error}>
              Der aktuelle Fahrtstand fehlt. Die Auswahl bleibt erhalten; bitte
              die Verbindung abwarten.
            </Text>
          )}
          {state.restoring && (
            <>
              <ActivityIndicator color={gold} />
              <Pressable
                accessibilityRole="button"
                onPress={() => void controller.restore()}
              >
                <Text style={s.link}>
                  Gespeicherte Bestellung erneut prüfen
                </Text>
              </Pressable>
            </>
          )}
          {!!state.pending && (
            <Text style={s.detail}>
              Die Bestätigung ist noch offen. Erneutes Wischen wiederholt exakt
              dieselbe Bestellung und Wiederholungs-ID.
            </Text>
          )}
          {!boardOpen(state.booking) && !state.pending && (
            <Text style={s.detail}>
              Die Bordkarte ist für diese Fahrt geschlossen.
            </Text>
          )}
          {changed && !state.pending && !state.confirmed && (
            <Pressable
              accessibilityRole="button"
              disabled={!connected || !active || state.submitting}
              onPress={() => controller.review()}
            >
              <Text style={s.link}>
                Aktuelle Bestellung übernehmen und prüfen
              </Text>
            </Pressable>
          )}
          {!!state.error && (
            <Text accessibilityRole="alert" style={s.error}>
              {state.error}
            </Text>
          )}
          {state.confirmed && (
            <Text accessibilityRole="alert" style={s.success}>
              Bestellung bestätigt. Dein Fahrer kann die Auswahl jetzt sehen.
            </Text>
          )}
          <View style={s.grid}>
            {menu.map((item) => (
              <View style={s.product} key={item.id}>
                <Image
                  source={{
                    uri:
                      'https://luxoreride.de/board-products/' +
                      item.id +
                      '.png',
                  }}
                  resizeMode="contain"
                  style={s.image}
                />
                <Text style={s.name}>{item.name}</Text>
                <Text style={s.small}>{item.detail}</Text>
                {!!order.delivered[item.id] && (
                  <Text style={s.small}>
                    {order.delivered[item.id]} bereits ausgegeben
                  </Text>
                )}
                {!!order.unavailable[item.id] && (
                  <Text style={s.small}>
                    {order.unavailable[item.id]} nicht verfügbar gemeldet
                  </Text>
                )}
                <View style={s.quantity}>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={item.name + ' entfernen'}
                    disabled={locked || !state.cart[item.id]}
                    onPress={() => controller.edit(item.id, -1)}
                    style={s.control}
                  >
                    <Minus color={ink} size={20} />
                  </Pressable>
                  <Text style={s.amount}>{state.cart[item.id] || 0}</Text>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={item.name + ' hinzufügen'}
                    disabled={locked || (state.cart[item.id] || 0) >= 12}
                    onPress={() => controller.edit(item.id, 1)}
                    style={s.control}
                  >
                    <Plus color={ink} size={20} />
                  </Pressable>
                </View>
              </View>
            ))}
          </View>
        </ScrollView>
        <View style={s.footer}>
          <View style={s.row}>
            <View style={s.flex}>
              <Text style={s.small}>Gesamt bei vollständiger Ausgabe</Text>
              <Text style={s.detail}>
                Bordartikel darin: {euros(projected)}
              </Text>
            </View>
            <Text style={s.price}>{euros(fare + projected)}</Text>
          </View>
          {!state.confirmed && (
            <SwipeAction
              label={
                state.pending
                  ? 'Bestellung erneut bestätigen'
                  : 'Bordbestellung bestätigen'
              }
              disabled={
                !active ||
                !connected ||
                state.restoring ||
                (!state.pending && locked)
              }
              busy={state.submitting}
              onComplete={() => void controller.submit()}
            />
          )}
        </View>
      </SafeAreaView>
    </Modal>
  );
}
const ink = '#161a20',
  gold = '#aa8345';
const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#fff' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 22,
    paddingVertical: 14,
  },
  brand: { color: gold, fontSize: 12, letterSpacing: 3, fontWeight: '700' },
  title: { color: ink, fontSize: 26, fontWeight: '700', marginTop: 4 },
  close: { padding: 14, borderRadius: 28, backgroundColor: '#faf8f3' },
  scroll: { flex: 1 },
  content: { padding: 22, gap: 14 },
  class: { fontSize: 18, fontWeight: '600', color: ink },
  detail: { fontSize: 14, lineHeight: 21, color: '#737882' },
  small: { fontSize: 12, lineHeight: 18, color: '#737882' },
  link: { color: gold, fontWeight: '700', fontSize: 15, paddingVertical: 10 },
  error: { color: '#9a3939', fontSize: 14, lineHeight: 21 },
  success: { color: '#2e7053', fontSize: 15, lineHeight: 22 },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
  },
  product: {
    width: '48%',
    borderRadius: 22,
    padding: 14,
    backgroundColor: '#faf8f3',
    gap: 6,
  },
  image: { width: '100%', height: 100 },
  name: { fontSize: 15, fontWeight: '600', color: ink },
  quantity: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 'auto',
    paddingTop: 10,
  },
  control: { padding: 10, borderRadius: 23, backgroundColor: '#fff' },
  amount: { color: ink, fontSize: 18, fontWeight: '600' },
  footer: { paddingHorizontal: 22, paddingTop: 14, paddingBottom: 14, gap: 12 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  flex: { flex: 1 },
  price: { fontSize: 24, fontWeight: '700', color: ink },
});
