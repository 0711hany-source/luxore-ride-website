/** Avoid overlapping foreground uploads; background fixes still use the native task. */
export class ForegroundUpload {
  private busy = false;
  private timestamp = 0;
  private attempted = -Infinity;
  async send(timestamp: number, now: number, work: () => Promise<void>) {
    if (this.busy || timestamp <= this.timestamp || now - this.attempted < 3000)
      return;
    this.busy = true;
    this.attempted = now;
    try {
      await work();
      this.timestamp = Math.max(this.timestamp, timestamp);
    } finally {
      this.busy = false;
    }
  }
}
