import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import {
  ActivityIndicator,
  AppState,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, Info, MapPin, Search } from 'lucide-react-native';
import type { Point } from '../../lib/mobility/domain';
import { nativeApi } from './account-client';
import { AddressSearchController } from './address-search';
import { colors, layout, space, typography } from './theme';

type Props = {
  visible: boolean;
  token: string;
  title: 'Abholort' | 'Ziel';
  initialQuery?: string;
  onClose: () => void;
  onSelected: (point: Point) => void;
};
export default function NativeAddressPicker(props: Props) {
  if (!props.visible) return null;
  return (
    <Modal
      visible
      animationType="slide"
      presentationStyle="fullScreen"
      onRequestClose={props.onClose}
    >
      <AddressSession key={props.token} {...props} />
    </Modal>
  );
}
/**
 * Data sources of the results: shown once for the whole list, in full for
 * five seconds, then folded into a small info line that opens on tap.
 */
function SourceCredit({ credits }: { credits: string[] }) {
  const key = credits.join('|');
  const [open, setOpen] = useState(true);
  useEffect(() => {
    if (!key) return;
    setOpen(true);
    const timer = setTimeout(() => setOpen(false), 5000);
    return () => clearTimeout(timer);
  }, [key]);
  if (!key) return null;
  return open ? (
    <Text style={s.credit}>{credits.join(' · ')}</Text>
  ) : (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel="Datenquellen der Adressen anzeigen"
      hitSlop={12}
      onPress={() => setOpen(true)}
      style={s.creditToggle}
    >
      <Info color={colors.gray} size={14} />
    </Pressable>
  );
}
function AddressSession({
  token,
  title,
  initialQuery = '',
  onClose,
  onSelected,
}: Props) {
  const controller = useMemo(
    () =>
      new AddressSearchController((body, signal) =>
        nativeApi('places', token, body, undefined, signal),
      ),
    [token],
  );
  const state = useSyncExternalStore(
    controller.subscribe,
    controller.getSnapshot,
  );
  const callback = useRef(onSelected);
  useEffect(() => {
    callback.current = onSelected;
  }, [onSelected]);
  const [openedQuery] = useState(initialQuery);
  const [foreground, setForeground] = useState(
    AppState.currentState === 'active',
  );
  useEffect(() => {
    controller.setQuery(openedQuery);
    controller.setActive(AppState.currentState === 'active');
    const subscription = AppState.addEventListener('change', (value) => {
      const active = value === 'active';
      setForeground(active);
      controller.setActive(active);
    });
    return () => {
      subscription.remove();
      // StrictMode replays setup with the same external store. Stop reads;
      // React removes its listener. Closed/account-replaced sessions cannot
      // deliver an old confirmation because their component is unmounted.
      controller.setActive(false);
    };
  }, [controller, openedQuery]);
  const delivered = useRef<Point | null>(null);
  useEffect(() => {
    if (
      foreground &&
      state.confirmed &&
      delivered.current !== state.confirmed
    ) {
      delivered.current = state.confirmed;
      callback.current(state.confirmed);
    }
  }, [foreground, state.confirmed]);
  return (
    <SafeAreaView style={s.safe} edges={['top', 'bottom']}>
      <KeyboardAvoidingView
        style={s.root}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={s.header}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Adresssuche schließen"
            onPress={onClose}
            style={s.back}
          >
            <ArrowLeft size={23} color={colors.inkSoft} />
          </Pressable>
          <Text style={s.brand}>
            LUXORÉ <Text style={s.ride}>RIDE</Text>
          </Text>
          <View style={s.spacer} />
        </View>
        <Text style={s.eyebrow}>DEINE FAHRT</Text>
        <Text style={s.title}>
          {title === 'Ziel' ? 'Wohin darf es gehen?' : 'Wo holen wir dich ab?'}
        </Text>
        <View style={s.inputRow}>
          <Search color={colors.goldText} size={22} />
          <TextInput
            style={s.input}
            accessibilityLabel={title}
            placeholder="Straße, Hausnummer, Ort"
            placeholderTextColor={colors.gray}
            value={state.query}
            onChangeText={(value) => controller.setQuery(value)}
            maxLength={256}
            autoCorrect={false}
            autoCapitalize="words"
            returnKeyType="search"
            onSubmitEditing={() => void controller.search()}
          />
          {(state.searching || state.confirming) && (
            <ActivityIndicator
              accessibilityLabel={
                state.confirming
                  ? 'Adresse wird bestätigt'
                  : 'Adressen werden gesucht'
              }
              color={colors.goldText}
            />
          )}
        </View>
        <ScrollView
          style={s.results}
          contentContainerStyle={s.resultContent}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
        >
          {!!state.error && (
            <View accessibilityRole="alert" style={s.error}>
              <Text style={s.errorText}>{state.error}</Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Adresssuche erneut versuchen"
                onPress={() => void controller.search()}
                disabled={!!state.confirming}
                style={s.retry}
              >
                <Text style={s.retryText}>Erneut suchen</Text>
              </Pressable>
            </View>
          )}
          {!state.error &&
            !state.searching &&
            !state.results.length &&
            !state.confirming &&
            !state.confirmed && (
              <Text style={s.hint}>
                Gib mindestens drei Zeichen ein. Wähle anschließend die passende
                Adresse.
              </Text>
            )}
          {state.results.map((p) => (
            <Pressable
              key={p.id}
              accessibilityRole="button"
              accessibilityLabel={p.label}
              accessibilityState={{ disabled: !!state.confirming }}
              disabled={!!state.confirming}
              onPress={() => void controller.select(p)}
              style={s.result}
            >
              <View style={s.pin}>
                <MapPin color={colors.goldText} size={23} />
              </View>
              <View style={s.address}>
                <Text style={s.addressLabel}>{p.label}</Text>
              </View>
            </Pressable>
          ))}
          <SourceCredit
            credits={[
              ...new Set(
                state.results
                  .map((p) => p.attribution)
                  .filter((c): c is string => !!c),
              ),
            ]}
          />
          {state.confirmed && <Text style={s.hint}>Adresse bestätigt.</Text>}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.white },
  root: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: space[4],
    paddingVertical: space[3],
  },
  back: {
    width: layout.tap,
    height: layout.tap,
    alignItems: 'center',
    justifyContent: 'center',
  },
  spacer: { width: layout.tap },
  brand: {
    fontSize: 19,
    letterSpacing: 2.4,
    fontWeight: '700',
    color: colors.inkSoft,
  },
  ride: { fontSize: 11, color: colors.goldText },
  eyebrow: {
    marginHorizontal: layout.screenMargin,
    marginTop: space[5],
    ...typography.label,
    color: colors.goldText,
  },
  title: {
    marginHorizontal: layout.screenMargin,
    marginTop: space[3],
    marginBottom: space[5],
    ...typography.title1,
    color: colors.inkSoft,
  },
  inputRow: {
    marginHorizontal: layout.screenMargin,
    flexDirection: 'row',
    alignItems: 'center',
    gap: space[3],
    borderBottomWidth: 1.5,
    borderBottomColor: colors.goldLight,
    minHeight: 60,
  },
  input: {
    flex: 1,
    minWidth: 0,
    color: colors.inkSoft,
    fontSize: typography.body.fontSize,
    paddingVertical: space[4],
  },
  results: { flex: 1 },
  resultContent: { paddingHorizontal: layout.screenMargin, paddingBottom: space[5], paddingTop: space[3] },
  result: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space[4],
    paddingVertical: space[4],
    minHeight: 76,
  },
  pin: { width: 30, alignItems: 'center' },
  address: { flex: 1, minWidth: 0 },
  addressLabel: {
    ...typography.headline,
    color: colors.inkSoft,
  },
  credit: { ...typography.footnote, color: colors.gray, marginTop: space[3] },
  creditToggle: { alignSelf: 'flex-start', marginTop: space[3], opacity: 0.7 },
  hint: { ...typography.subhead, color: colors.gray, paddingVertical: 20 },
  error: { paddingVertical: space[4] },
  errorText: { ...typography.subhead, color: colors.danger },
  retry: { alignSelf: 'flex-start', minHeight: 48, justifyContent: 'center' },
  retryText: { ...typography.subhead, fontWeight: '600', color: colors.inkSoft },
});
