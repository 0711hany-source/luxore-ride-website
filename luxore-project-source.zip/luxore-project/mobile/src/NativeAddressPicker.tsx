import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import {
  ActivityIndicator,
  AppState,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, MapPin, Search } from 'lucide-react-native';
import type { Point } from '../../lib/mobility/domain';
import { nativeApi } from './account-client';
import { AddressSearchController } from './address-search';

type Props = {
  visible: boolean;
  token: string;
  title: 'Abholort' | 'Ziel';
  initialQuery?: string;
  onClose: () => void;
  onSelected: (point: Point) => void;
};
export default function NativeAddressPicker(props: Props) {
  if (!props.visible) return null;
  return (
    <Modal
      visible
      animationType="slide"
      presentationStyle="fullScreen"
      onRequestClose={props.onClose}
    >
      <AddressSession key={props.token} {...props} />
    </Modal>
  );
}
function AddressSession({
  token,
  title,
  initialQuery = '',
  onClose,
  onSelected,
}: Props) {
  const controller = useMemo(
    () =>
      new AddressSearchController((body, signal) =>
        nativeApi('places', token, body, undefined, signal),
      ),
    [token],
  );
  const state = useSyncExternalStore(
    controller.subscribe,
    controller.getSnapshot,
  );
  const callback = useRef(onSelected);
  useEffect(() => {
    callback.current = onSelected;
  }, [onSelected]);
  const [openedQuery] = useState(initialQuery);
  const [foreground, setForeground] = useState(
    AppState.currentState === 'active',
  );
  useEffect(() => {
    controller.setQuery(openedQuery);
    controller.setActive(AppState.currentState === 'active');
    const subscription = AppState.addEventListener('change', (value) => {
      const active = value === 'active';
      setForeground(active);
      controller.setActive(active);
    });
    return () => {
      subscription.remove();
      // StrictMode replays setup with the same external store. Stop reads;
      // React removes its listener. Closed/account-replaced sessions cannot
      // deliver an old confirmation because their component is unmounted.
      controller.setActive(false);
    };
  }, [controller, openedQuery]);
  const delivered = useRef<Point | null>(null);
  useEffect(() => {
    if (
      foreground &&
      state.confirmed &&
      delivered.current !== state.confirmed
    ) {
      delivered.current = state.confirmed;
      callback.current(state.confirmed);
    }
  }, [foreground, state.confirmed]);
  return (
    <SafeAreaView style={s.safe} edges={['top', 'bottom']}>
      <KeyboardAvoidingView
        style={s.root}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={s.header}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Adresssuche schließen"
            onPress={onClose}
            style={s.back}
          >
            <ArrowLeft size={23} color="#191d23" />
          </Pressable>
          <Text style={s.brand}>
            LUXORÉ <Text style={s.ride}>RIDE</Text>
          </Text>
          <View style={s.spacer} />
        </View>
        <Text style={s.eyebrow}>DEINE FAHRT</Text>
        <Text style={s.title}>
          {title === 'Ziel' ? 'Wohin darf es gehen?' : 'Wo holen wir dich ab?'}
        </Text>
        <View style={s.inputRow}>
          <Search color="#9d7c43" size={22} />
          <TextInput
            style={s.input}
            accessibilityLabel={title}
            placeholder="Straße, Hausnummer, Ort"
            placeholderTextColor="#858a91"
            value={state.query}
            onChangeText={(value) => controller.setQuery(value)}
            maxLength={256}
            autoCorrect={false}
            autoCapitalize="words"
            returnKeyType="search"
            onSubmitEditing={() => void controller.search()}
          />
          {(state.searching || state.confirming) && (
            <ActivityIndicator
              accessibilityLabel={
                state.confirming
                  ? 'Adresse wird bestätigt'
                  : 'Adressen werden gesucht'
              }
              color="#9d7c43"
            />
          )}
        </View>
        <ScrollView
          style={s.results}
          contentContainerStyle={s.resultContent}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
        >
          {!!state.error && (
            <View accessibilityRole="alert" style={s.error}>
              <Text style={s.errorText}>{state.error}</Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Adresssuche erneut versuchen"
                onPress={() => void controller.search()}
                disabled={!!state.confirming}
                style={s.retry}
              >
                <Text style={s.retryText}>Erneut suchen</Text>
              </Pressable>
            </View>
          )}
          {!state.error &&
            !state.searching &&
            !state.results.length &&
            !state.confirming &&
            !state.confirmed && (
              <Text style={s.hint}>
                Gib mindestens drei Zeichen ein. Wähle anschließend die passende
                Adresse.
              </Text>
            )}
          {state.results.map((p) => (
            <Pressable
              key={p.id}
              accessibilityRole="button"
              accessibilityLabel={p.label}
              accessibilityState={{ disabled: !!state.confirming }}
              disabled={!!state.confirming}
              onPress={() => void controller.select(p)}
              style={s.result}
            >
              <View style={s.pin}>
                <MapPin color="#9d7c43" size={23} />
              </View>
              <View style={s.address}>
                <Text style={s.addressLabel}>{p.label}</Text>
                {!!p.attribution && (
                  <Text style={s.credit}>{p.attribution}</Text>
                )}
              </View>
            </Pressable>
          ))}
          {state.confirmed && <Text style={s.hint}>Adresse bestätigt.</Text>}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#fff' },
  root: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
    paddingVertical: 12,
  },
  back: {
    width: 46,
    height: 46,
    alignItems: 'center',
    justifyContent: 'center',
  },
  spacer: { width: 46 },
  brand: {
    fontSize: 19,
    letterSpacing: 2.4,
    fontWeight: '700',
    color: '#191d23',
  },
  ride: { fontSize: 11, color: '#9d7c43' },
  eyebrow: {
    marginHorizontal: 24,
    marginTop: 24,
    fontSize: 10,
    fontWeight: '700',
    color: '#9d7c43',
    letterSpacing: 2,
  },
  title: {
    marginHorizontal: 24,
    marginTop: 12,
    marginBottom: 22,
    fontSize: 29,
    lineHeight: 35,
    fontWeight: '700',
    color: '#191d23',
  },
  inputRow: {
    marginHorizontal: 24,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderBottomWidth: 1.5,
    borderBottomColor: '#c9af7f',
    minHeight: 60,
  },
  input: {
    flex: 1,
    minWidth: 0,
    color: '#191d23',
    fontSize: 18,
    paddingVertical: 16,
  },
  results: { flex: 1 },
  resultContent: { paddingHorizontal: 24, paddingBottom: 24, paddingTop: 12 },
  result: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingVertical: 18,
    minHeight: 76,
  },
  pin: { width: 30, alignItems: 'center' },
  address: { flex: 1, minWidth: 0 },
  addressLabel: {
    fontSize: 16,
    lineHeight: 23,
    color: '#191d23',
    fontWeight: '500',
  },
  credit: { fontSize: 11, lineHeight: 17, color: '#797f87', marginTop: 4 },
  hint: { fontSize: 15, lineHeight: 23, color: '#797f87', paddingVertical: 20 },
  error: { paddingVertical: 16 },
  errorText: { fontSize: 15, lineHeight: 23, color: '#9a3434' },
  retry: { alignSelf: 'flex-start', minHeight: 48, justifyContent: 'center' },
  retryText: { fontWeight: '600', fontSize: 15, color: '#191d23' },
});
