/** Owns the latest location attempt; superseded native responses must be ignored. */
export class LocationRequest {
  private active: AbortController | null = null;
  begin() {
    this.cancel();
    this.active = new AbortController();
    return this.active;
  }
  isCurrent(request: AbortController) {
    return this.active === request && !request.signal.aborted;
  }
  cancel() {
    this.active?.abort();
    this.active = null;
  }
  finish(request: AbortController) {
    if (this.active === request) this.cancel();
  }
}

/** Stops waiting; the platform may still finish its one-shot GPS request. */
export function locationDeadline<T>(
  work: Promise<T>,
  signal: AbortSignal,
  ms = 30_000,
): Promise<T> {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (fn: () => void) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      signal.removeEventListener('abort', abort);
      fn();
    };
    const abort = () =>
      finish(() => reject(new Error('Standortabfrage abgebrochen.')));
    const timer = setTimeout(
      () =>
        finish(() =>
          reject(
            new Error(
              'Die Standortabfrage dauert zu lange. Bitte versuche es erneut oder gib die Adresse von Hand ein.',
            ),
          ),
        ),
      ms,
    );
    // Always observe work, including rejection after cancellation or timeout.
    work.then(
      (value) => finish(() => resolve(value)),
      (error) => finish(() => reject(error)),
    );
    if (signal.aborted) {
      abort();
      return;
    }
    signal.addEventListener('abort', abort, { once: true });

  });
}
