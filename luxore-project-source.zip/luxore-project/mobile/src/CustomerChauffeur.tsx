import React, { useState } from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import {
  initials,
  ratingLabel,
  ratingText,
  type ChauffeurView,
  type ShownRating,
} from './customer-chauffeur';
import { photoSource } from './customer-photo';
import { colors, maxFontScale, radii, space, typography } from './theme';

/**
 * Round picture of the chauffeur. The guarded picture is fetched with the
 * app session; without a picture, or when loading fails, the initials show.
 */
export function CustomerAvatar({
  name,
  photoId,
  token,
  size = 48,
}: {
  name: string;
  photoId: string | null;
  token: string;
  size?: number;
}) {
  // Remember the failed picture itself, so a new picture is tried again.
  const [failed, setFailed] = useState<string | null>(null);
  const source = photoId && failed !== photoId ? photoSource(photoId, token) : null;
  const box = { width: size, height: size };
  return source ? (
    <Image
      source={source}
      accessibilityLabel={'Profilbild von ' + name}
      resizeMode="cover"
      onError={() => setFailed(photoId)}
      style={[s.avatar, box]}
    />
  ) : (
    <View
      accessible
      accessibilityLabel={'Kein Profilbild von ' + name}
      style={[s.avatar, s.placeholder, box]}
    >
      <Text maxFontSizeMultiplier={maxFontScale} style={s.initials}>
        {initials(name)}
      </Text>
    </View>
  );
}

/** "★ 4,7 (12)" or "Neu"; nothing when the server sent no rating field. */
export function CustomerRatingBadge({
  rating,
}: {
  rating: ShownRating | null | undefined;
}) {
  const text = ratingText(rating);
  if (text === undefined) return null;
  return rating ? (
    <Text
      accessibilityLabel={ratingLabel(rating)}
      maxFontSizeMultiplier={maxFontScale}
      style={s.rating}
    >
      <Text style={s.star}>★ </Text>
      {text}
    </Text>
  ) : (
    <View style={s.chip}>
      <Text
        accessibilityLabel={ratingLabel(rating)}
        maxFontSizeMultiplier={maxFontScale}
        style={s.chipText}
      >
        {text}
      </Text>
    </View>
  );
}

/** Picture, name, rating and vehicle of the chauffeur – only server values. */
export default function CustomerChauffeur({
  chauffeur,
  token,
  children,
}: {
  chauffeur: ChauffeurView;
  token: string;
  /** Extra lines under the vehicle (e.g. position hint). */
  children?: React.ReactNode;
}) {
  return (
    <View style={s.person}>
      <CustomerAvatar
        name={chauffeur.name}
        photoId={chauffeur.photoId}
        token={token}
      />
      <View style={s.flex}>
        <Text maxFontSizeMultiplier={maxFontScale} style={s.name}>
          {chauffeur.name}
        </Text>
        <CustomerRatingBadge rating={chauffeur.rating} />
        {!!chauffeur.vehicle && (
          <Text maxFontSizeMultiplier={maxFontScale} style={s.detail}>
            {chauffeur.vehicle}
          </Text>
        )}
        {children}
      </View>
    </View>
  );
}
const s = StyleSheet.create({
  person: { flexDirection: 'row', alignItems: 'center', gap: space[4] },
  flex: { flex: 1, gap: space[1] },
  avatar: { borderRadius: radii.pill, backgroundColor: colors.sand },
  placeholder: { alignItems: 'center', justifyContent: 'center' },
  initials: { ...typography.headline, color: colors.goldText },
  name: { ...typography.headline, color: colors.ink },
  detail: { ...typography.footnote, color: colors.textMuted },
  rating: {
    ...typography.footnote,
    fontWeight: '600',
    fontVariant: ['tabular-nums'],
    color: colors.ink,
  },
  star: { color: colors.gold },
  chip: {
    alignSelf: 'flex-start',
    borderRadius: radii.s,
    backgroundColor: colors.goldWash,
    paddingHorizontal: space[2],
    paddingVertical: 2,
  },
  chipText: { ...typography.footnote, fontWeight: '600', color: colors.goldText },
});
