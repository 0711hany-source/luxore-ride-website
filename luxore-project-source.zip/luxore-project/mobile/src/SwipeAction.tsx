import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  PanResponder,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { ArrowRight } from 'lucide-react-native';
import { colors, typography, maxFontScale } from './theme';
export default function SwipeAction({
  label,
  disabled,
  busy,
  onComplete,
}: {
  label: string;
  disabled?: boolean;
  busy?: boolean;
  onComplete: () => void;
}) {
  'use no memo'; // Native gesture/camera commands use mutable imperative handles.
  const [x] = useState(() => new Animated.Value(0));
  const width = useRef(0),
    completed = useRef(false),
    props = useRef({ disabled, busy, onComplete });
  useEffect(() => {
    props.current = { disabled, busy, onComplete };
  }, [disabled, busy, onComplete]);
  const [measured, setMeasured] = useState(false);
  // An action that refuses without ever becoming busy (validation message,
  // expired offer) must not leave the thumb locked at the end of the track.
  const release = useRef<ReturnType<typeof setTimeout> | null>(null);
  const armRelease = () => {
    if (release.current) clearTimeout(release.current);
    release.current = setTimeout(() => {
      release.current = null;
      if (props.current.busy || !completed.current) return;
      completed.current = false;
      reset();
    }, 1500);
  };
  useEffect(
    () => () => {
      if (release.current) clearTimeout(release.current);
    },
    [],
  );
  const reset = () =>
    Animated.spring(x, {
      toValue: 0,
      useNativeDriver: true,
      speed: 25,
      bounciness: 0,
    }).start();
  useEffect(() => {
    completed.current = false;
    x.setValue(0);
  }, [label, busy, x]);
  // PanResponder stores callbacks; it does not execute the gesture refs during render.
  // oxlint-disable-next-line react/react-compiler
  const [pan] = useState(() =>
    PanResponder.create({
      onStartShouldSetPanResponder: () =>
        !props.current.disabled && !props.current.busy && width.current > 0,
      onPanResponderMove: (_, gesture) =>
        x.setValue(Math.max(0, Math.min(width.current, gesture.dx))),
      onPanResponderRelease: (_, gesture) => {
        if (
          !props.current.disabled &&
          !props.current.busy &&
          !completed.current &&
          width.current > 0 &&
          gesture.dx >= width.current * 0.88
        ) {
          completed.current = true;
          x.setValue(width.current);
          armRelease();
          props.current.onComplete();
        } else reset();
      },
      onPanResponderTerminate: reset,
      onPanResponderTerminationRequest: () => false,
    }),
  );
  return (
    <View
      style={[s.track, (disabled || busy) && s.disabled]}
      onLayout={(event) => {
        width.current = Math.max(0, event.nativeEvent.layout.width - 66);
        setMeasured(true);
      }}
    >
      <Text style={s.label} maxFontSizeMultiplier={maxFontScale}>{busy ? 'Wird bestätigt …' : label}</Text>
      <Animated.View
        {...(measured ? pan.panHandlers : {})}
        accessible
        accessibilityLabel={`${label} · vollständig nach rechts wischen`}
        accessibilityState={{ disabled: !!disabled || !!busy, busy: !!busy }}
        // Screen-reader alternative to the swipe; offered in the actions menu,
        // never triggered by a plain tap.
        accessibilityActions={[{ name: 'confirm', label: 'Bestätigen' }]}
        onAccessibilityAction={(event) => {
          if (
            event.nativeEvent.actionName !== 'confirm' ||
            disabled ||
            busy ||
            completed.current
          )
            return;
          completed.current = true;
          x.setValue(width.current);
          armRelease();
          onComplete();
        }}
        style={[s.thumb, { transform: [{ translateX: x }] }]}
      >
        {busy ? (
          <ActivityIndicator color={colors.white} />
        ) : (
          <ArrowRight size={23} color={colors.white} />
        )}
      </Animated.View>
    </View>
  );
}
const s = StyleSheet.create({
  track: {
    height: 64,
    backgroundColor: colors.goldWash,
    borderRadius: 32,
    justifyContent: 'center',
    overflow: 'hidden',
  },
  label: {
    ...typography.footnote,
    fontWeight: '600',
    color: colors.goldText,
    textAlign: 'center',
    paddingLeft: 44,
    paddingRight: 12,
  },
  thumb: {
    position: 'absolute',
    left: 5,
    top: 5,
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: colors.inkSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  disabled: { opacity: 0.5 },
});
