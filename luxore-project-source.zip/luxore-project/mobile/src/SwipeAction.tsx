import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  PanResponder,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { ArrowRight } from 'lucide-react-native';
export default function SwipeAction({
  label,
  disabled,
  busy,
  onComplete,
}: {
  label: string;
  disabled?: boolean;
  busy?: boolean;
  onComplete: () => void;
}) {
  'use no memo'; // Native gesture/camera commands use mutable imperative handles.
  const [x] = useState(() => new Animated.Value(0));
  const width = useRef(0),
    completed = useRef(false),
    props = useRef({ disabled, busy, onComplete });
  useEffect(() => {
    props.current = { disabled, busy, onComplete };
  }, [disabled, busy, onComplete]);
  const [measured, setMeasured] = useState(false);
  const reset = () =>
    Animated.spring(x, {
      toValue: 0,
      useNativeDriver: true,
      speed: 25,
      bounciness: 0,
    }).start();
  useEffect(() => {
    completed.current = false;
    x.setValue(0);
  }, [label, busy, x]);
  // PanResponder stores callbacks; it does not execute the gesture refs during render.
  // oxlint-disable-next-line react/react-compiler
  const [pan] = useState(() =>
    PanResponder.create({
      onStartShouldSetPanResponder: () =>
        !props.current.disabled && !props.current.busy && width.current > 0,
      onPanResponderMove: (_, gesture) =>
        x.setValue(Math.max(0, Math.min(width.current, gesture.dx))),
      onPanResponderRelease: (_, gesture) => {
        if (
          !props.current.disabled &&
          !props.current.busy &&
          !completed.current &&
          width.current > 0 &&
          gesture.dx >= width.current * 0.88
        ) {
          completed.current = true;
          x.setValue(width.current);
          props.current.onComplete();
        } else reset();
      },
      onPanResponderTerminate: reset,
      onPanResponderTerminationRequest: () => false,
    }),
  );
  return (
    <View
      style={[s.track, (disabled || busy) && s.disabled]}
      onLayout={(event) => {
        width.current = Math.max(0, event.nativeEvent.layout.width - 66);
        setMeasured(true);
      }}
    >
      <Text style={s.label}>{busy ? 'Wird bestätigt …' : label}</Text>
      <Animated.View
        {...(measured ? pan.panHandlers : {})}
        accessibilityLabel={`${label} · vollständig nach rechts wischen`}
        style={[s.thumb, { transform: [{ translateX: x }] }]}
      >
        {busy ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <ArrowRight size={23} color="#fff" />
        )}
      </Animated.View>
    </View>
  );
}
const s = StyleSheet.create({
  track: {
    height: 64,
    backgroundColor: '#f1e5cd',
    borderRadius: 32,
    justifyContent: 'center',
    overflow: 'hidden',
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6d5837',
    textAlign: 'center',
    paddingLeft: 44,
    paddingRight: 12,
  },
  thumb: {
    position: 'absolute',
    left: 5,
    top: 5,
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: '#191e25',
    alignItems: 'center',
    justifyContent: 'center',
  },
  disabled: { opacity: 0.5 },
});
