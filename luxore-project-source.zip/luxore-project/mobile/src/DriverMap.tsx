import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import type { Position } from './location-service';
import type { RouteData } from '../../lib/mobility/domain';
export type DriverMapProps = {
  token: string;
  position: Position | null;
  route: RouteData | null;
  active: boolean;
};
// Metro selects DriverMap.native.tsx in installed apps. Browser design previews
// must never pretend to provide native navigation or background tracking.
export default function DriverMap(_props: DriverMapProps) {
  return (
    <View style={s.map}>
      <Text style={s.text}>
        Die native 3D-Karte ist in der Android-App verfügbar.
      </Text>
    </View>
  );
}
const s = StyleSheet.create({
  map: {
    flex: 1,
    backgroundColor: '#f5f2eb',
    justifyContent: 'center',
    padding: 40,
  },
  text: { color: '#857355', textAlign: 'center' },
});
