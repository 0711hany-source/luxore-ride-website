import { useCallback, useEffect, useRef, useState } from 'react';
import { AppState, Platform } from 'react-native';
import * as Location from 'expo-location';
import { acceptFix, usableFix } from '../../app/mobility/gps-quality';
import { ForegroundUpload } from './foreground-upload';
import { LocationRequest, locationDeadline } from './location-request';
import {
  deliverForeground,
  foregroundPermission,
  point,
  resumeLocation,
  type Position,
} from './location-service';

export function useDriverGps() {
  const [position, setPosition] = useState<Position | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [foreground, setForeground] = useState(
    AppState.currentState === 'active',
  );
  const request = useRef(new LocationRequest());
  const watcher = useRef<Location.LocationSubscription | null>(null);
  const latest = useRef<Position | null>(null);
  const upload = useRef(new ForegroundUpload());
  const alive = useRef(true);
  const accept = useCallback((fix: Position) => {
    if (
      !usableFix(fix, Date.now()) ||
      !acceptFix(latest.current, fix, Date.now())
    )
      return;
    latest.current = fix;
    setPosition(fix);
    setError('');
  }, []);
  const sync = useCallback(async () => {
    const status = await resumeLocation();
    if (!alive.current) return status;
    setSessionId(
      status.active && 'sessionId' in status ? status.sessionId! : null,
    );
    if ('position' in status && status.position) accept(status.position);
    return status;
  }, [accept]);
  const restart = useCallback(async () => {
    if (Platform.OS === 'web') return;
    const attempt = request.current.begin();
    watcher.current?.remove();
    watcher.current = null;
    try {
      await foregroundPermission();
      if (!request.current.isCurrent(attempt)) return;
      // Restoring the native shift is independent of an account/API refresh.
      void sync().catch(() => {});
      const subscription = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.BestForNavigation,
          timeInterval: 1000,
          distanceInterval: 0,
        },
        (location) => {
          if (!request.current.isCurrent(attempt)) return;
          accept(point(location));
          void upload.current
            .send(location.timestamp, Date.now(), () =>
              deliverForeground(location),
            )
            .catch(() => {});
        },
      );
      if (!request.current.isCurrent(attempt)) {
        subscription.remove();
        return;
      }
      watcher.current = subscription;
      void Location.getLastKnownPositionAsync({
        maxAge: 10000,
        requiredAccuracy: 35,
      })
        .then((cached) => {
          if (cached && request.current.isCurrent(attempt))
            accept(point(cached));
        })
        .catch(() => {});
      const first = await locationDeadline(
        Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.BestForNavigation,
        }),
        attempt.signal,
        15000,
      );
      if (request.current.isCurrent(attempt)) accept(point(first));
    } catch (e) {
      if (
        request.current.isCurrent(attempt) &&
        (!latest.current || Date.now() - latest.current.timestamp > 15000)
      )
        setError((e as Error).message);
      // Keep the continuous watcher when the initial one-shot times out.
    }
  }, [accept, sync]);
  useEffect(() => {
    alive.current = true;
    const requests = request.current;
    void restart();
    const listener = AppState.addEventListener('change', (next) => {
      setForeground(next === 'active');
      if (next === 'active') void restart();
      else {
        request.current.cancel();
        watcher.current?.remove();
        watcher.current = null;
      }
    });
    const timer = setInterval(() => {
      if (AppState.currentState === 'active') void sync().catch(() => {});
    }, 5000);
    return () => {
      alive.current = false;
      clearInterval(timer);
      listener.remove();
      requests.cancel();
      watcher.current?.remove();
    };
  }, [restart, sync]);
  return { position, sessionId, error, foreground, restart, sync };
}
