import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { CalendarDays, ChevronRight } from 'lucide-react-native';
import { nativeApi } from './account-client';
import { loadFeature } from './operator-platform';
import {
  boardSummary,
  isReservationBoard,
  type ReservationBoard,
} from './driver-reservations';
import { colors, layout, maxFontScale, space, typography } from './theme';

/**
 * Einstieg „Reservierungen“ im Fahrerbereich mit der Zahl offener und
 * übernommener Reservierungen. Liest nur; kennt der Server die Route noch
 * nicht oder schlägt das Lesen fehl, bleibt die Zeile unsichtbar – die
 * Schicht hängt nie davon ab. Der Bereich ist dann weiter über „Konto“
 * erreichbar.
 */
export default function ReservationsEntry({
  token,
  active,
  refreshKey,
  onOpen,
}: {
  token: string;
  /** Wird wieder `true`, wenn der Fahrer in den Fahrerbereich zurückkehrt. */
  active: boolean;
  /** Ändert sich nach einem Fahrzeugwechsel: neu lesen. */
  refreshKey: string;
  onOpen: () => void;
}) {
  const [board, setBoard] = useState<ReservationBoard | null>(null);
  useEffect(() => {
    if (!active) return;
    let alive = true;
    const controller = new AbortController();
    void loadFeature(
      () =>
        nativeApi('reservations', token, undefined, undefined, controller.signal),
      isReservationBoard,
    )
      .then((next) => {
        if (alive) setBoard(next.kind === 'ready' ? next.data : null);
      })
      .catch(() => {});
    return () => {
      alive = false;
      controller.abort();
    };
  }, [token, active, refreshKey]);
  if (!board) return null;
  const detail = boardSummary(board);
  return (
    <Pressable
      style={s.row}
      accessibilityRole="button"
      accessibilityLabel={`Reservierungen, ${detail}`}
      onPress={onOpen}
    >
      <CalendarDays
        color={colors.gold}
        size={22}
        strokeWidth={layout.iconStroke}
      />
      <View style={s.flex}>
        <Text style={s.title} maxFontSizeMultiplier={maxFontScale}>
          Reservierungen
        </Text>
        <Text style={s.detail} maxFontSizeMultiplier={maxFontScale}>
          {detail}
        </Text>
      </View>
      <ChevronRight color={colors.gray} size={20} strokeWidth={layout.iconStroke} />
    </Pressable>
  );
}
const s = StyleSheet.create({
  row: {
    minHeight: layout.tap,
    flexDirection: 'row',
    alignItems: 'center',
    gap: space[4],
    paddingVertical: space[4],
    paddingHorizontal: space[1],
  },
  flex: { flex: 1 },
  title: { ...typography.subhead, fontWeight: '600', color: colors.ink },
  detail: { ...typography.footnote, color: colors.gray },
});
