// Texte, die das Betriebssystem beim Namen nennen. Android behält wortgleich
// die bisherigen Formulierungen; iOS bekommt die dort üblichen Begriffe
// („Einstellungen“, Standort → „Immer“).
//
// `process.env.EXPO_OS` setzt babel-preset-expo beim Bündeln fest ein
// ('android' | 'ios' | 'web'). Bewusst kein Import von `react-native`: diese
// Datei wird auch von Diensten ohne Oberfläche (Standort, Fahrtalarm) geladen.
export const isIos = process.env.EXPO_OS === 'ios';

export const platformText = isIos
  ? {
      /** Subjekt für „… antwortet nicht. Bitte erneut versuchen.“ */
      locationService: 'Der Standortdienst des iPhones',
      onlineStepHint:
        'Das iPhone fragt nach deinem Standort. Bitte „Beim Verwenden der App“ und danach „Immer erlauben“ wählen.',
      backgroundAlert:
        'LUXORÉ Driver überträgt deinen Standort auch bei gesperrtem Bildschirm und während der Navigation, damit Fahrgast und Disposition dich sehen. Wähle im nächsten Hinweis „Immer erlauben“. Mit „Pause machen“ endet die Übertragung.',
      backgroundMissing:
        'Bitte unter Einstellungen → LUXORÉ Driver → Standort „Immer“ wählen und erneut online gehen.',
      backgroundHowTo:
        'So geht es: „Einstellungen öffnen“ → Standort → „Immer“ wählen und „Genauer Standort“ einschalten. Danach hierher zurückkehren und „Erneut versuchen“ tippen.',
      navigationNote:
        'Der native Standortdienst läuft während deiner gestarteten Schicht auch beim Wechsel zu Apple Karten, Waze oder Google Maps. In den Einstellungen muss Standort auf „Immer“ stehen. Ein erzwungenes Beenden oder entzogene Berechtigungen unterbrechen den Dienst.',
      openPermissions: 'Einstellungen öffnen',
      disableLocationInSettings:
        'Bitte Standort in den Einstellungen deaktivieren.',
      alertsDisabled:
        'Mitteilungen sind deaktiviert. Bitte unter Einstellungen → LUXORÉ Driver → Mitteilungen erlauben.',
      serviceManifestMissing:
        'Dieser App-Version fehlt das Recht für den Standortdienst. Bitte die aktuelle LUXORÉ Driver installieren.',
      serviceNeedsForeground:
        'Der Standortdienst startet nur, wenn LUXORÉ Driver sichtbar geöffnet ist. Bitte die App geöffnet lassen und erneut versuchen.',
    }
  : {
      locationService: 'Der Android-Standortdienst',
      onlineStepHint:
        'Android fragt nach deinem Standort. Für die Schicht bitte „Immer zulassen“ wählen.',
      backgroundAlert:
        'LUXORÉ Driver überträgt deinen Standort auch bei gesperrtem Bildschirm und während der Navigation, damit Fahrgast und Disposition dich sehen. Wähle in den Einstellungen „Immer zulassen“. Mit „Pause machen“ endet die Übertragung.',
      backgroundMissing:
        'Bitte unter App-Berechtigungen → Standort „Immer zulassen“ wählen und erneut online gehen.',
      backgroundHowTo:
        'So geht es: „Einstellungen öffnen“ → Berechtigungen → Standort → „Immer zulassen“ und „Genauen Standort verwenden“ einschalten. Danach hierher zurückkehren und „Erneut versuchen“ tippen.',
      navigationNote:
        'Der native Standortdienst läuft während deiner gestarteten Schicht auch beim Wechsel zu Waze oder Google Maps. Android muss Standort „Immer zulassen“ erlauben. Ein erzwungenes Beenden oder entzogene Berechtigungen unterbrechen den Dienst.',
      openPermissions: 'Android-Berechtigungen öffnen',
      disableLocationInSettings:
        'Bitte Standort in den Android-Einstellungen deaktivieren.',
      alertsDisabled:
        'Benachrichtigungen sind deaktiviert. Bitte in den Android-App-Einstellungen erlauben.',
      serviceManifestMissing:
        'Dieser App-Version fehlt das Android-Recht für den Standortdienst. Bitte die aktuelle LUXORÉ Driver installieren.',
      serviceNeedsForeground:
        'Android startet den Standortdienst nur, wenn LUXORÉ Driver sichtbar geöffnet ist. Bitte die App geöffnet lassen und erneut versuchen.',
    };
