import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import {
  ActivityIndicator,
  AppState,
  Linking,
  Modal,
  PanResponder,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  CarFront,
  ChevronDown,
  MapPin,
  Phone,
  ShieldCheck,
  X,
} from 'lucide-react-native';
import { statusNames, type Booking } from '../../lib/mobility/domain';
import { className } from '../../lib/ride-domain';
import { menu } from '../../lib/mobility/refreshments';
import { companyOrigin, nativeApi } from './account-client';
import { euros } from './driver-model';
import { CustomerLiveController, customerMapSnapshot } from './customer-live';
import CustomerMap from './CustomerMap';
import CustomerBoardScreen from './CustomerBoardScreen';
import { colors, layout, radii, space, typography } from './theme';
export default function CustomerLiveScreen({
  token,
  ownerId,
  active,
  bookingId,
  onTrips,
  onHome,
}: {
  token: string;
  ownerId: string;
  active: boolean;
  bookingId: string | null;
  onTrips: () => void;
  onHome?: () => void;
}) {
  'use no memo';
  const controller = useMemo(
    () =>
      new CustomerLiveController(
        ownerId,
        (signal) =>
          nativeApi<{ bookings: Booking[]; serverTime: number }>(
            'bookings',
            token,
            undefined,
            undefined,
            signal,
          ),
        (body, signal) => nativeApi('nearby', token, body, undefined, signal),
      ),
    [ownerId, token],
  );
  const { height } = useWindowDimensions();
  const [now, setNow] = useState(() => Date.now());
  const subscribe = useCallback(
    (listener: () => void) =>
      controller.subscribe(() => {
        setNow(Date.now());
        listener();
      }),
    [controller],
  );
  const state = useSyncExternalStore(
    subscribe,
    controller.getSnapshot,
    controller.getSnapshot,
  );
  const [foreground, setForeground] = useState(
    AppState.currentState === 'active',
  );
  const [mapToken, setMapToken] = useState(''),
    [mapError, setMapError] = useState(''),
    [configAttempt, setConfigAttempt] = useState(0);
  const [expanded, setExpanded] = useState(true),
    [board, setBoard] = useState(false),
    [safety, setSafety] = useState(false),
    [linkError, setLinkError] = useState('');
  const lastManual = useRef(0);
  const visible = active && foreground;
  const boardSaved = useCallback(() => {
    void controller.refresh();
  }, [controller]);
  useEffect(() => {
    const listener = AppState.addEventListener('change', (next) =>
      setForeground(next === 'active'),
    );
    return () => listener.remove();
  }, []);
  useEffect(() => {
    controller.select(bookingId);
  }, [controller, bookingId]);
  useEffect(() => {
    controller.setActive(visible);
    return () => controller.setActive(false);
  }, [controller, visible]);
  useEffect(() => {
    if (!visible) return;
    const clock = setInterval(() => setNow(Date.now()), 1000),
      poll = setInterval(() => void controller.refresh(), 5000);
    return () => {
      clearInterval(clock);
      clearInterval(poll);
    };
  }, [controller, visible]);
  useEffect(() => {
    if (!visible) return;
    let current = true;
    const abort = new AbortController();
    void nativeApi<{ publicMapToken: string }>(
      'config',
      token,
      undefined,
      undefined,
      abort.signal,
    )
      .then((r) => {
        if (!current) return;
        if (!r.publicMapToken?.startsWith('pk.'))
          throw new Error('Der Kartenzugang ist momentan nicht verfügbar.');
        setMapError('');
        setMapToken(r.publicMapToken);
      })
      .catch((e) => {
        if (current) setMapError((e as Error).message);
      });
    return () => {
      current = false;
      abort.abort();
    };
  }, [token, visible, configAttempt]);
  const view = customerMapSnapshot(state, now),
    b = view.booking;
  // The ride is over: show a clear closing view instead of live details.
  const ended =
    !!b && ['completed', 'unavailable', 'cancelled'].includes(b.status);
  useEffect(() => {
    if (ended) setExpanded(true);
  }, [ended]);
  const gesture = PanResponder.create({
    onMoveShouldSetPanResponder: (_, g) =>
      Math.abs(g.dy) > 15 && Math.abs(g.dy) > Math.abs(g.dx) * 1.5,
    onPanResponderRelease: (_, g) => {
      if (g.dy > 35) setExpanded(false);
      else if (g.dy < -35) setExpanded(true);
    },
  });
  async function link(url: string) {
    try {
      await Linking.openURL(url);
      setLinkError('');
    } catch {
      setLinkError(
        'Diese Funktion konnte nicht geöffnet werden. Bitte über dein Telefon starten.',
      );
    }
  }
  return (
    <View style={s.root}>
      <View style={s.map}>
        {b && mapToken ? (
          <CustomerMap
            token={mapToken}
            active={visible}
            bookingId={b.id}
            route={b.route}
            driver={view.driverPosition}
            nearby={view.nearby}
          />
        ) : (
          <View style={s.wait}>
            {!state.loaded || (!mapToken && !mapError && b) ? (
              <ActivityIndicator color={gold} />
            ) : (
              <MapPin color={gold} size={32} />
            )}
            <Text style={s.detail}>
              {mapError ||
                (state.loaded
                  ? 'Deine Fahrtdetails stehen unten.'
                  : 'Deine Fahrt wird geladen …')}
            </Text>
          </View>
        )}
        {!!mapError && (
          <Pressable
            style={s.mapRetry}
            accessibilityRole="button"
            onPress={() => setConfigAttempt((v) => v + 1)}
          >
            <Text style={s.detail}>Kartenzugang erneut prüfen</Text>
          </Pressable>
        )}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Sicherheit öffnen"
          style={s.safety}
          onPress={() => setSafety(true)}
        >
          <ShieldCheck color={gold} size={23} />
        </Pressable>
      </View>
      <View
        style={[
          s.sheet,
          expanded ? { height: Math.min(420, height * 0.5) } : s.collapsed,
        ]}
      >
        <View {...gesture.panHandlers}>
          <View style={s.handle} />
          <View style={s.heading}>
            <View style={s.flex}>
              <Text style={s.eyebrow}>
                {view.connected ? 'DEINE FAHRT' : 'VERBINDUNG WIRD GEPRÜFT'}
              </Text>
              <Text style={s.title}>
                {b
                  ? statusNames[b.status]
                  : state.loaded
                    ? 'Fahrt nicht verfügbar'
                    : 'Einen Moment …'}
              </Text>
            </View>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={
                expanded ? 'Fahrtdetails einklappen' : 'Fahrtdetails ausklappen'
              }
              onPress={() => setExpanded((v) => !v)}
              style={s.toggle}
            >
              <ChevronDown
                color={ink}
                size={24}
                style={{
                  transform: [{ rotate: expanded ? '0deg' : '180deg' }],
                }}
              />
            </Pressable>
          </View>
        </View>
        {expanded && (
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={s.content}
          >
            {!!state.error && (
              <Text style={s.error} accessibilityRole="alert">
                {state.error} Bekannte Details sind möglicherweise nicht
                aktuell.
              </Text>
            )}
            {!view.connected && (
              <Pressable
                hitSlop={6}
                accessibilityRole="button"
                onPress={() => {
                  if (Date.now() - lastManual.current < 5000) return;
                  lastManual.current = Date.now();
                  void controller.refresh();
                }}
              >
                <Text style={s.link}>Fahrtstand erneut prüfen</Text>
              </Pressable>
            )}
            {b ? (
              <>
                {b.status === 'requesting' && (
                  <Text style={s.detail}>
                    {state.nearbyError
                      ? 'Fahrzeugsuche läuft. Die Umgebungspunkte sind momentan nicht verfügbar.'
                      : 'Wir suchen einen passenden Chauffeur. Fahrzeuge auf der Karte zeigen ungefähre Positionen.'}
                  </Text>
                )}
                {b.status === 'reserved' && (
                  <Text style={s.detail}>
                    Reservierung vorgemerkt ·{' '}
                    {new Date(b.scheduled_at!).toLocaleString('de-DE')}. Erst
                    mit Fahrerzusage bestätigt.
                  </Text>
                )}
                {ended && (
                  <View style={s.closing}>
                    {b.status === 'completed' ? (
                      <>
                        <Text style={s.eyebrow}>BETRAG</Text>
                        <Text style={s.amount}>{euros(b.price)}</Text>
                        <Text style={s.name}>
                          {b.payment_status === 'paid'
                            ? 'Zahlung bestätigt'
                            : 'Beim Chauffeur zu zahlen'}
                        </Text>
                      </>
                    ) : (
                      <Text style={s.detail}>
                        {b.status === 'unavailable'
                          ? 'Aktuell ist kein passender Chauffeur verfügbar. Es wurde keine Fahrt zugesagt und es ist nichts zu zahlen.'
                          : 'Diese Fahrt wurde storniert. Es wurde keine Fahrt durchgeführt.'}
                      </Text>
                    )}
                    {!!onHome && (
                      <Pressable
                        accessibilityRole="button"
                        style={s.primary}
                        onPress={onHome}
                      >
                        <Text style={s.primaryText}>Zur Startseite</Text>
                      </Pressable>
                    )}
                  </View>
                )}
                {b.driver && (
                  <View style={s.chauffeur}>
                    <CarFront color={gold} size={27} />
                    <View style={s.flex}>
                      <Text style={s.name}>{b.driver.name}</Text>
                      <Text style={s.detail}>
                        {b.driver.vehicle} · {b.driver.plate}
                      </Text>
                      {['accepted', 'arrived', 'riding'].includes(b.status) && (
                        <Text style={s.detail}>
                          {view.driverPosition
                            ? 'Aktuelle Fahrerposition verfügbar'
                            : 'Aktuelle Fahrerposition wird gesucht'}
                        </Text>
                      )}
                    </View>
                    {view.canContactDriver && b.driver.phone && (
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel="Chauffeur anrufen"
                        style={s.toggle}
                        onPress={() =>
                          void link(
                            'tel:' + b.driver!.phone.replace(/[^+\d]/g, ''),
                          )
                        }
                      >
                        <Phone color={gold} size={22} />
                      </Pressable>
                    )}
                  </View>
                )}
                <View style={s.row}>
                  <Text style={s.class}>{className(b.service)}</Text>
                  <Text style={s.price}>{euros(b.price)}</Text>
                </View>
                <Text style={s.eyebrow}>ABHOLUNG</Text>
                <Text style={s.address}>{b.route.pickup.label}</Text>
                <Text style={s.eyebrow}>ZIEL</Text>
                <Text style={s.address}>{b.route.destination.label}</Text>
                {b.refreshments && (
                  <View style={s.board}>
                    <Text style={s.eyebrow}>DEINE BORDKARTE</Text>
                    {menu
                      .filter(
                        (p) =>
                          (b.refreshments?.requested[p.id] || 0) +
                            (b.refreshments?.delivered[p.id] || 0) +
                            (b.refreshments?.unavailable[p.id] || 0) >
                          0,
                      )
                      .map((p) => (
                        <Text key={p.id} style={s.detail}>
                          {p.name}: {b.refreshments!.requested[p.id] || 0} offen
                          {(b.refreshments!.unavailable[p.id] || 0) > 0
                            ? ` · ${b.refreshments!.unavailable[p.id]} nicht verfügbar`
                            : ''}
                          {(b.refreshments!.delivered[p.id] || 0) > 0
                            ? ` · ${b.refreshments!.delivered[p.id]} ausgegeben`
                            : ''}
                        </Text>
                      ))}
                  </View>
                )}
                {!ended && (
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel="Bordkarte öffnen"
                    onPress={() => setBoard(true)}
                    style={s.details}
                  >
                    <Text style={s.link}>
                      Getränke & Snacks · Bordkarte öffnen
                    </Text>
                  </Pressable>
                )}
              </>
            ) : (
              state.loaded && (
                <Text style={s.detail}>
                  Diese Fahrt ist in deiner aktuellen eigenen Fahrtenliste nicht
                  verfügbar. Öffne deine Fahrten, um die Auswahl zu prüfen.
                </Text>
              )
            )}
            {!!linkError && (
              <Text accessibilityRole="alert" style={s.error}>
                {linkError}
              </Text>
            )}
            <Pressable
              accessibilityRole="button"
              style={s.details}
              onPress={onTrips}
            >
              <Text style={s.link}>
                {ended ? 'Meine Fahrten' : 'Meine Fahrten & Stornierung'}
              </Text>
            </Pressable>
          </ScrollView>
        )}
      </View>
      {board && b && (
        <CustomerBoardScreen
          key={`${ownerId}:${b.id}`}
          token={token}
          ownerId={ownerId}
          booking={b}
          active={visible}
          connected={view.connected}
          onClose={() => setBoard(false)}
          onSaved={boardSaved}
        />
      )}
      <Modal
        visible={active && safety}
        animationType="slide"
        presentationStyle="fullScreen"
        onRequestClose={() => setSafety(false)}
      >
        <SafeAreaView style={s.safetyPage}>
          <View style={s.row}>
            <Text style={s.title}>Deine Sicherheit.</Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Sicherheit schließen"
              onPress={() => setSafety(false)}
              style={s.toggle}
            >
              <X color={ink} size={24} />
            </Pressable>
          </View>
          <Text style={s.detail}>
            Bei akuter Gefahr oder einem medizinischen Notfall wähle 112.
          </Text>
          <Pressable
            style={s.emergency}
            accessibilityRole="button"
            onPress={() => void link('tel:112')}
          >
            <Phone color={colors.white} size={22} />
            <Text style={s.emergencyText}>112 · Notruf wählen</Text>
          </Pressable>
          <Pressable
            accessibilityRole="button"
            style={s.details}
            onPress={() => void link(companyOrigin + '/hilfe')}
          >
            <Text style={s.link}>LUXORÉ Support öffnen</Text>
          </Pressable>
          {!!linkError && <Text style={s.error}>{linkError}</Text>}
        </SafeAreaView>
      </Modal>
    </View>
  );
}
const ink = colors.ink,
  gold = colors.gold;
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
  map: { flex: 1, minHeight: 120 },
  wait: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: space[3],
    padding: space[6],
    backgroundColor: colors.paper,
  },
  mapRetry: {
    position: 'absolute',
    bottom: 10,
    left: 16,
    backgroundColor: colors.white,
    borderRadius: radii.l,
    padding: space[3],
    minHeight: layout.tap,
    justifyContent: 'center',
  },
  safety: {
    position: 'absolute',
    top: 14,
    right: 16,
    padding: space[4],
    borderRadius: radii.pill,
    backgroundColor: colors.white,
  },
  sheet: {
    backgroundColor: colors.white,
    borderTopLeftRadius: radii.xl,
    borderTopRightRadius: radii.xl,
    paddingHorizontal: layout.screenMargin,
  },
  collapsed: { paddingBottom: space[4] },
  handle: {
    width: 40,
    height: 4,
    borderRadius: radii.pill,
    backgroundColor: colors.goldLight,
    alignSelf: 'center',
    marginVertical: space[3],
  },
  heading: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space[3],
    paddingBottom: space[3],
  },
  flex: { flex: 1 },
  eyebrow: {
    ...typography.label,
    color: colors.goldText,
    marginTop: space[2],
  },
  title: { ...typography.title2, color: ink, marginTop: space[1] },
  toggle: { padding: space[3], borderRadius: radii.pill, backgroundColor: colors.paper },
  content: { paddingBottom: 20, gap: space[2] },
  detail: { ...typography.footnote, color: colors.gray },
  error: { color: colors.danger, ...typography.footnote },
  link: { ...typography.subhead, fontWeight: '600', color: colors.goldText, paddingVertical: space[2] },
  chauffeur: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space[4],
    paddingVertical: space[3],
  },
  name: { ...typography.headline, color: ink },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: space[3],
  },
  class: { ...typography.headline, color: ink },
  price: { ...typography.title2, fontVariant: ['tabular-nums'], color: ink },
  address: { ...typography.body, color: ink },
  board: { backgroundColor: colors.paper, borderRadius: radii.l, padding: space[4], gap: space[1] },
  closing: {
    backgroundColor: colors.paper,
    borderRadius: radii.l,
    padding: space[4],
    gap: space[2],
    marginBottom: space[2],
  },
  amount: { ...typography.title1, fontVariant: ['tabular-nums'], color: ink },
  primary: {
    marginTop: space[2],
    minHeight: 54,
    borderRadius: radii.m,
    backgroundColor: ink,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: space[4],
  },
  primaryText: { color: colors.white, ...typography.subhead, fontWeight: '600' },
  details: { paddingVertical: space[3] },
  safetyPage: { flex: 1, padding: layout.screenMargin, gap: space[5], backgroundColor: colors.white },
  emergency: {
    flexDirection: 'row',
    gap: space[4],
    alignItems: 'center',
    backgroundColor: ink,
    padding: space[5],
    borderRadius: radii.l,
  },
  emergencyText: { color: colors.white, ...typography.headline },
});
