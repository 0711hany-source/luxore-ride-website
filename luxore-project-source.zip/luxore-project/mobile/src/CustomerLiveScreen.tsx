import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import {
  ActivityIndicator,
  AppState,
  Linking,
  Modal,
  PanResponder,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  CarFront,
  ChevronDown,
  MapPin,
  Phone,
  ShieldCheck,
  X,
} from 'lucide-react-native';
import { statusNames, type Booking } from '../../lib/mobility/domain';
import { className } from '../../lib/ride-domain';
import { menu } from '../../lib/mobility/refreshments';
import { companyOrigin, nativeApi } from './account-client';
import { euros } from './driver-model';
import { CustomerLiveController, customerMapSnapshot } from './customer-live';
import CustomerMap from './CustomerMap';
export default function CustomerLiveScreen({
  token,
  ownerId,
  active,
  bookingId,
  onTrips,
}: {
  token: string;
  ownerId: string;
  active: boolean;
  bookingId: string | null;
  onTrips: () => void;
}) {
  'use no memo';
  const controller = useMemo(
    () =>
      new CustomerLiveController(
        ownerId,
        (signal) =>
          nativeApi<{ bookings: Booking[]; serverTime: number }>(
            'bookings',
            token,
            undefined,
            undefined,
            signal,
          ),
        (body, signal) => nativeApi('nearby', token, body, undefined, signal),
      ),
    [ownerId, token],
  );
  const { height } = useWindowDimensions();
  const [now, setNow] = useState(() => Date.now());
  const subscribe = useCallback(
    (listener: () => void) =>
      controller.subscribe(() => {
        setNow(Date.now());
        listener();
      }),
    [controller],
  );
  const state = useSyncExternalStore(
    subscribe,
    controller.getSnapshot,
    controller.getSnapshot,
  );
  const [foreground, setForeground] = useState(
    AppState.currentState === 'active',
  );
  const [mapToken, setMapToken] = useState(''),
    [mapError, setMapError] = useState(''),
    [configAttempt, setConfigAttempt] = useState(0);
  const [expanded, setExpanded] = useState(true),
    [safety, setSafety] = useState(false),
    [linkError, setLinkError] = useState('');
  const lastManual = useRef(0);
  const visible = active && foreground;
  useEffect(() => {
    const listener = AppState.addEventListener('change', (next) =>
      setForeground(next === 'active'),
    );
    return () => listener.remove();
  }, []);
  useEffect(() => {
    controller.select(bookingId);
  }, [controller, bookingId]);
  useEffect(() => {
    controller.setActive(visible);
    return () => controller.setActive(false);
  }, [controller, visible]);
  useEffect(() => {
    if (!visible) return;
    const clock = setInterval(() => setNow(Date.now()), 1000),
      poll = setInterval(() => void controller.refresh(), 5000);
    return () => {
      clearInterval(clock);
      clearInterval(poll);
    };
  }, [controller, visible]);
  useEffect(() => {
    if (!visible) return;
    let current = true;
    const abort = new AbortController();
    void nativeApi<{ publicMapToken: string }>(
      'config',
      token,
      undefined,
      undefined,
      abort.signal,
    )
      .then((r) => {
        if (!current) return;
        if (!r.publicMapToken?.startsWith('pk.'))
          throw new Error('Der Kartenzugang ist momentan nicht verfügbar.');
        setMapError('');
        setMapToken(r.publicMapToken);
      })
      .catch((e) => {
        if (current) setMapError((e as Error).message);
      });
    return () => {
      current = false;
      abort.abort();
    };
  }, [token, visible, configAttempt]);
  const view = customerMapSnapshot(state, now),
    b = view.booking;
  const gesture = PanResponder.create({
    onMoveShouldSetPanResponder: (_, g) =>
      Math.abs(g.dy) > 15 && Math.abs(g.dy) > Math.abs(g.dx) * 1.5,
    onPanResponderRelease: (_, g) => {
      if (g.dy > 35) setExpanded(false);
      else if (g.dy < -35) setExpanded(true);
    },
  });
  async function link(url: string) {
    try {
      await Linking.openURL(url);
      setLinkError('');
    } catch {
      setLinkError(
        'Diese Funktion konnte nicht geöffnet werden. Bitte über dein Telefon starten.',
      );
    }
  }
  return (
    <View style={s.root}>
      <View style={s.map}>
        {b && mapToken ? (
          <CustomerMap
            token={mapToken}
            active={visible}
            bookingId={b.id}
            route={b.route}
            driver={view.driverPosition}
            nearby={view.nearby}
          />
        ) : (
          <View style={s.wait}>
            {!state.loaded || (!mapToken && !mapError && b) ? (
              <ActivityIndicator color={gold} />
            ) : (
              <MapPin color={gold} size={32} />
            )}
            <Text style={s.detail}>
              {mapError ||
                (state.loaded
                  ? 'Deine Fahrtdetails stehen unten.'
                  : 'Deine Fahrt wird geladen …')}
            </Text>
          </View>
        )}
        {!!mapError && (
          <Pressable
            style={s.mapRetry}
            accessibilityRole="button"
            onPress={() => setConfigAttempt((v) => v + 1)}
          >
            <Text style={s.detail}>Kartenzugang erneut prüfen</Text>
          </Pressable>
        )}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Sicherheit öffnen"
          style={s.safety}
          onPress={() => setSafety(true)}
        >
          <ShieldCheck color={gold} size={23} />
        </Pressable>
      </View>
      <View
        style={[
          s.sheet,
          expanded ? { height: Math.min(420, height * 0.5) } : s.collapsed,
        ]}
      >
        <View {...gesture.panHandlers}>
          <View style={s.handle} />
          <View style={s.heading}>
            <View style={s.flex}>
              <Text style={s.eyebrow}>
                {view.connected ? 'DEINE FAHRT' : 'VERBINDUNG WIRD GEPRÜFT'}
              </Text>
              <Text style={s.title}>
                {b
                  ? statusNames[b.status]
                  : state.loaded
                    ? 'Fahrt nicht verfügbar'
                    : 'Einen Moment …'}
              </Text>
            </View>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={
                expanded ? 'Fahrtdetails einklappen' : 'Fahrtdetails ausklappen'
              }
              onPress={() => setExpanded((v) => !v)}
              style={s.toggle}
            >
              <ChevronDown
                color={ink}
                size={24}
                style={{
                  transform: [{ rotate: expanded ? '0deg' : '180deg' }],
                }}
              />
            </Pressable>
          </View>
        </View>
        {expanded && (
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={s.content}
          >
            {!!state.error && (
              <Text style={s.error} accessibilityRole="alert">
                {state.error} Bekannte Details sind möglicherweise nicht
                aktuell.
              </Text>
            )}
            {!view.connected && (
              <Pressable
                accessibilityRole="button"
                onPress={() => {
                  if (Date.now() - lastManual.current < 5000) return;
                  lastManual.current = Date.now();
                  void controller.refresh();
                }}
              >
                <Text style={s.link}>Fahrtstand erneut prüfen</Text>
              </Pressable>
            )}
            {b ? (
              <>
                {b.status === 'requesting' && (
                  <Text style={s.detail}>
                    {state.nearbyError
                      ? 'Fahrzeugsuche läuft. Die Umgebungspunkte sind momentan nicht verfügbar.'
                      : 'Wir suchen einen passenden Chauffeur. Fahrzeuge auf der Karte zeigen ungefähre Positionen.'}
                  </Text>
                )}
                {b.status === 'reserved' && (
                  <Text style={s.detail}>
                    Reservierung vorgemerkt ·{' '}
                    {new Date(b.scheduled_at!).toLocaleString('de-DE')}. Erst
                    mit Fahrerzusage bestätigt.
                  </Text>
                )}
                {b.status === 'unavailable' && (
                  <Text style={s.detail}>
                    Aktuell ist kein passender Chauffeur verfügbar. Es wurde
                    keine Fahrt zugesagt.
                  </Text>
                )}
                {b.driver && (
                  <View style={s.chauffeur}>
                    <CarFront color={gold} size={27} />
                    <View style={s.flex}>
                      <Text style={s.name}>{b.driver.name}</Text>
                      <Text style={s.detail}>
                        {b.driver.vehicle} · {b.driver.plate}
                      </Text>
                      {['accepted', 'arrived', 'riding'].includes(b.status) && (
                        <Text style={s.detail}>
                          {view.driverPosition
                            ? 'Aktuelle Fahrerposition verfügbar'
                            : 'Aktuelle Fahrerposition wird gesucht'}
                        </Text>
                      )}
                    </View>
                    {view.canContactDriver && b.driver.phone && (
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel="Chauffeur anrufen"
                        style={s.toggle}
                        onPress={() =>
                          void link(
                            'tel:' + b.driver!.phone.replace(/[^+\d]/g, ''),
                          )
                        }
                      >
                        <Phone color={gold} size={22} />
                      </Pressable>
                    )}
                  </View>
                )}
                <View style={s.row}>
                  <Text style={s.class}>{className(b.service)}</Text>
                  <Text style={s.price}>{euros(b.price)}</Text>
                </View>
                <Text style={s.eyebrow}>ABHOLUNG</Text>
                <Text style={s.address}>{b.route.pickup.label}</Text>
                <Text style={s.eyebrow}>ZIEL</Text>
                <Text style={s.address}>{b.route.destination.label}</Text>
                {b.status === 'completed' && (
                  <Text style={s.detail}>
                    {b.payment_status === 'paid'
                      ? 'Zahlung erfasst.'
                      : 'Zahlung noch offen.'}
                  </Text>
                )}
                {b.refreshments &&
                  Object.entries(b.refreshments.requested).some(
                    ([, n]) => n > 0,
                  ) && (
                    <View style={s.board}>
                      <Text style={s.eyebrow}>DEINE BORDKARTE</Text>
                      {menu
                        .filter(
                          (p) => (b.refreshments?.requested[p.id] || 0) > 0,
                        )
                        .map((p) => (
                          <Text key={p.id} style={s.detail}>
                            {b.refreshments!.requested[p.id]} × {p.name}
                            {(b.refreshments!.unavailable[p.id] || 0) > 0
                              ? ' · nicht verfügbar'
                              : ''}
                            {(b.refreshments!.delivered[p.id] || 0) > 0
                              ? ' · Ausgabe erfasst'
                              : ''}
                          </Text>
                        ))}
                    </View>
                  )}
              </>
            ) : (
              state.loaded && (
                <Text style={s.detail}>
                  Diese Fahrt ist in deiner aktuellen eigenen Fahrtenliste nicht
                  verfügbar. Öffne deine Fahrten, um die Auswahl zu prüfen.
                </Text>
              )
            )}
            {!!linkError && (
              <Text accessibilityRole="alert" style={s.error}>
                {linkError}
              </Text>
            )}
            <Pressable
              accessibilityRole="button"
              style={s.details}
              onPress={onTrips}
            >
              <Text style={s.link}>Meine Fahrten & Stornierung</Text>
            </Pressable>
          </ScrollView>
        )}
      </View>
      <Modal
        visible={active && safety}
        animationType="slide"
        presentationStyle="fullScreen"
        onRequestClose={() => setSafety(false)}
      >
        <SafeAreaView style={s.safetyPage}>
          <View style={s.row}>
            <Text style={s.title}>Deine Sicherheit.</Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Sicherheit schließen"
              onPress={() => setSafety(false)}
              style={s.toggle}
            >
              <X color={ink} size={24} />
            </Pressable>
          </View>
          <Text style={s.detail}>
            Bei akuter Gefahr oder einem medizinischen Notfall wähle 112.
          </Text>
          <Pressable
            style={s.emergency}
            accessibilityRole="button"
            onPress={() => void link('tel:112')}
          >
            <Phone color="#fff" size={22} />
            <Text style={s.emergencyText}>112 · Notruf wählen</Text>
          </Pressable>
          <Pressable
            accessibilityRole="button"
            style={s.details}
            onPress={() => void link(companyOrigin + '/hilfe')}
          >
            <Text style={s.link}>Luxóre Support öffnen</Text>
          </Pressable>
          {!!linkError && <Text style={s.error}>{linkError}</Text>}
        </SafeAreaView>
      </Modal>
    </View>
  );
}
const ink = '#161a20',
  gold = '#aa8345';
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  map: { flex: 1, minHeight: 120 },
  wait: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    padding: 32,
    backgroundColor: '#f7f4ee',
  },
  mapRetry: {
    position: 'absolute',
    bottom: 10,
    left: 16,
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 12,
  },
  safety: {
    position: 'absolute',
    top: 14,
    right: 16,
    padding: 14,
    borderRadius: 26,
    backgroundColor: '#fff',
  },
  sheet: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: 22,
  },
  collapsed: { paddingBottom: 18 },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 3,
    backgroundColor: '#c7ad7c',
    alignSelf: 'center',
    marginVertical: 12,
  },
  heading: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingBottom: 12,
  },
  flex: { flex: 1 },
  eyebrow: {
    fontSize: 10,
    letterSpacing: 1.6,
    color: gold,
    fontWeight: '700',
    marginTop: 8,
  },
  title: { fontSize: 24, fontWeight: '700', color: ink, marginTop: 4 },
  toggle: { padding: 12, borderRadius: 26, backgroundColor: '#faf8f3' },
  content: { paddingBottom: 20, gap: 8 },
  detail: { fontSize: 14, color: '#737882', lineHeight: 21 },
  error: { color: '#9a3939', fontSize: 14, lineHeight: 21 },
  link: { fontSize: 15, color: gold, fontWeight: '700', paddingVertical: 8 },
  chauffeur: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingVertical: 12,
  },
  name: { fontSize: 18, fontWeight: '700', color: ink },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  class: { fontSize: 17, color: ink, fontWeight: '600' },
  price: { fontSize: 23, color: ink, fontWeight: '700' },
  address: { fontSize: 16, color: ink, lineHeight: 23 },
  board: { backgroundColor: '#faf8f3', borderRadius: 18, padding: 16, gap: 5 },
  details: { paddingVertical: 10 },
  safetyPage: { flex: 1, padding: 24, gap: 22, backgroundColor: '#fff' },
  emergency: {
    flexDirection: 'row',
    gap: 14,
    alignItems: 'center',
    backgroundColor: ink,
    padding: 22,
    borderRadius: 22,
  },
  emergencyText: { color: '#fff', fontSize: 17, fontWeight: '700' },
});
