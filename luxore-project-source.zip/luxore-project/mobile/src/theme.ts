// Gemeinsame Grundwerte, identisch mit app/design-tokens.css (Web-Designsystem).
export const colors = {
  ink: '#151719',
  inkSoft: '#222427',
  lineOnInk: '#45464a',
  textMuted: '#5d5d58',
  gray: '#8b8a84',
  textOnInkMuted: '#bdbcb4',
  lineStrong: '#cbc6ba',
  line: '#e0dcd2',
  sand: '#efece5',
  paper: '#f9f8f5',
  white: '#ffffff',
  goldText: '#7a5f30',
  gold: '#b99a60',
  goldLight: '#c9b285',
  goldWash: '#f6f0e1',
  danger: '#a63333',
  dangerWash: '#f8e9e6',
  success: '#2f7d55',
  successWash: '#e6f1ea',
  info: '#2f6291',
  infoWash: '#e6eef5',
} as const;

export const radius = { s: 6, m: 12, l: 18, pill: 999 } as const;

export const space = { 1: 4, 2: 8, 3: 12, 4: 16, 5: 24, 6: 32, 7: 48, 8: 64, 9: 96 } as const;

export const font = {
  sans: undefined,
  serif: 'Georgia',
  tap: 48,
} as const;

// ---------------------------------------------------------------------------
// Neudesign (docs/REDESIGN-KONZEPT.md, Abschnitt 4.1). Die Exporte oben bleiben
// unverändert, weil die bestehenden Screens sie nutzen; neue Bausteine unter
// `src/ui/` verwenden ausschließlich die folgenden Werte.
// ---------------------------------------------------------------------------

/** Radien: Chips/kleine Felder · Knöpfe/Felder · Karten · Sheets oben · Pille. */
export const radii = { s: 8, m: 14, l: 20, xl: 28, pill: 999 } as const;

/** Feste Schrift-Skala (Größe/Zeilenhöhe/Gewicht), Systemschrift. */
export const typography = {
  largeTitle: { fontSize: 34, lineHeight: 41, fontWeight: '700' },
  title1: { fontSize: 28, lineHeight: 34, fontWeight: '700' },
  title2: { fontSize: 22, lineHeight: 28, fontWeight: '600' },
  headline: { fontSize: 17, lineHeight: 22, fontWeight: '600' },
  body: { fontSize: 17, lineHeight: 24, fontWeight: '400' },
  subhead: { fontSize: 15, lineHeight: 20, fontWeight: '400' },
  footnote: { fontSize: 13, lineHeight: 18, fontWeight: '400' },
  label: {
    fontSize: 11,
    lineHeight: 13,
    fontWeight: '600',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
} as const;

/** Systemweite Schriftvergrößerung zulassen, aber begrenzen (bis 1,3-fach). */
export const maxFontScale = 1.3;

/** Weicher Schatten für schwebende Flächen (y 8, Radius 24, 8 % Tinte). */
export const shadow = {
  floating: {
    shadowColor: colors.ink,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.08,
    shadowRadius: 24,
    elevation: 8,
  },
} as const;

/** Material für schwebende Flächen: iOS Unschärfe, Android Papier 92 %. */
export const material = {
  paperFloating: 'rgba(249, 248, 245, 0.92)',
  blurIntensity: 60,
  scrim: 'rgba(21, 23, 25, 0.32)',
} as const;

/** Federn für `withSpring` (react-native-reanimated). */
export const springs = {
  standard: { damping: 20, stiffness: 220, mass: 1, overshootClamping: true },
  sheet: { damping: 28, stiffness: 300, mass: 1 },
  emphasis: { damping: 14, stiffness: 180, mass: 1 },
} as const;

/** Feste Dauern in Millisekunden. */
export const durations = { fade: 180, screen: 320 } as const;

export const layout = {
  screenMargin: 20,
  cardGap: 12,
  sectionGap: 32,
  tap: 48,
  icon: 24,
  iconStroke: 1.75,
} as const;

/** Wischknopf: einheitliche Schwelle zum Bestätigen (Anteil des Wegs). */
export const swipeConfirmThreshold = 0.9;

/** Namen der Haptiken, siehe `ui/haptics.ts`. */
export const hapticNames = [
  'light',
  'medium',
  'success',
  'warning',
  'error',
] as const;
export type HapticName = (typeof hapticNames)[number];
