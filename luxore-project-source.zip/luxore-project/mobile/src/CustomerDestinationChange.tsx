import React, { useState } from 'react';
import {
  ActivityIndicator,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MapPin, X } from 'lucide-react-native';
import type { Booking, Point } from '../../lib/mobility/domain';
import { nativeApi } from './account-client';
import { euros } from './driver-model';
import NativeAddressPicker from './NativeAddressPicker';
import { colors, layout, maxFontScale, radii, space, typography } from './theme';

type Offer = {
  destination: { id: string; label: string };
  distanceMeters: number;
  fare: number;
  price: number;
  currentPrice: number;
};
/**
 * New destination during the ride. The customer first sees the new price;
 * only the confirmation of exactly that amount changes ride and price
 * (server: destination-offer / destination-confirm).
 */
export default function CustomerDestinationChange({
  token,
  booking,
  onChanged,
}: {
  token: string;
  booking: Booking;
  onChanged: () => void;
}) {
  const [picker, setPicker] = useState(false),
    [sheet, setSheet] = useState(false),
    [offer, setOffer] = useState<Offer | null>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  if (!['accepted', 'arrived', 'riding'].includes(booking.status)) return null;
  async function ask(point: Point) {
    setPicker(false);
    setOffer(null);
    setError('');
    setSheet(true);
    setBusy(true);
    try {
      setOffer(
        await nativeApi<Offer>('bookings', token, {
          action: 'destination-offer',
          id: booking.id,
          destinationId: point.id,
        }),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function confirm() {
    if (!offer || busy) return;
    setBusy(true);
    setError('');
    try {
      await nativeApi('bookings', token, {
        action: 'destination-confirm',
        id: booking.id,
        fare: offer.fare,
      });
      setSheet(false);
      setOffer(null);
      onChanged();
    } catch (e) {
      setError((e as Error).message);
      setOffer(null);
    } finally {
      setBusy(false);
    }
  }
  const difference = offer ? offer.price - offer.currentPrice : 0;
  return (
    <>
      <Pressable
        accessibilityRole="button"
        onPress={() => setPicker(true)}
        style={({ pressed }) => [s.button, pressed && s.pressed]}
      >
        <MapPin color={colors.ink} size={19} />
        <Text maxFontSizeMultiplier={maxFontScale} style={s.buttonText}>
          Ziel ändern
        </Text>
      </Pressable>
      <NativeAddressPicker
        visible={picker}
        token={token}
        title="Ziel"
        onClose={() => setPicker(false)}
        onSelected={(point) => void ask(point)}
      />
      <Modal
        visible={sheet}
        animationType="slide"
        presentationStyle="fullScreen"
        onRequestClose={() => {
          if (!busy) setSheet(false);
        }}
      >
        <SafeAreaView style={s.page}>
          <View style={s.head}>
            <Text style={s.title}>Ziel ändern</Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Schließen"
              disabled={busy}
              onPress={() => setSheet(false)}
              style={s.close}
            >
              <X color={colors.ink} size={24} />
            </Pressable>
          </View>
          <Text style={s.detail}>
            Bisheriges Ziel: {booking.route.destination.label}
          </Text>
          {busy && !offer && (
            <View style={s.wait}>
              <ActivityIndicator color={colors.gold} />
              <Text style={s.detail}>Preis wird berechnet …</Text>
            </View>
          )}
          {!!error && (
            <Text accessibilityRole="alert" style={s.error}>
              {error}
            </Text>
          )}
          {offer && (
            <View style={s.offer}>
              <Text style={s.detail}>Neues Ziel</Text>
              <Text style={s.place}>{offer.destination.label}</Text>
              <View style={s.priceRow}>
                <Text style={s.detail}>Neuer Gesamtpreis</Text>
                <Text style={s.price}>{euros(offer.price)}</Text>
              </View>
              <Text style={s.detail}>
                Bisher {euros(offer.currentPrice)}
                {difference === 0
                  ? ' – der Preis bleibt gleich.'
                  : difference > 0
                    ? ` – ${euros(difference)} mehr.`
                    : ` – ${euros(-difference)} weniger.`}
              </Text>
              <Pressable
                accessibilityRole="button"
                disabled={busy}
                onPress={() => void confirm()}
                style={({ pressed }) => [
                  s.primary,
                  (pressed || busy) && s.pressed,
                ]}
              >
                <Text style={s.primaryText}>
                  {busy
                    ? 'Wird geändert …'
                    : `Neues Ziel für ${euros(offer.price)} bestätigen`}
                </Text>
              </Pressable>
            </View>
          )}
          <Pressable
            accessibilityRole="button"
            disabled={busy}
            onPress={() => setSheet(false)}
            style={({ pressed }) => [s.button, pressed && s.pressed]}
          >
            <Text style={s.buttonText}>Beim bisherigen Ziel bleiben</Text>
          </Pressable>
        </SafeAreaView>
      </Modal>
    </>
  );
}
const s = StyleSheet.create({
  button: {
    minHeight: layout.tap,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: space[2],
    borderWidth: 1,
    borderColor: colors.lineStrong,
    borderRadius: radii.m,
    backgroundColor: colors.white,
    paddingHorizontal: space[4],
    marginTop: space[3],
  },
  buttonText: { ...typography.subhead, fontWeight: '600', color: colors.ink },
  pressed: { opacity: 0.6 },
  page: { flex: 1, backgroundColor: colors.paper, padding: space[5], gap: space[3] },
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  title: { ...typography.title2, color: colors.ink },
  close: { minWidth: layout.tap, minHeight: layout.tap, alignItems: 'center', justifyContent: 'center' },
  detail: { ...typography.footnote, color: colors.textMuted },
  wait: { flexDirection: 'row', alignItems: 'center', gap: space[3], paddingVertical: space[4] },
  error: { ...typography.footnote, color: colors.danger },
  offer: {
    gap: space[2],
    padding: space[4],
    borderWidth: 1,
    borderColor: colors.lineStrong,
    borderRadius: radii.m,
    backgroundColor: colors.white,
  },
  place: { ...typography.subhead, fontWeight: '600', color: colors.ink },
  priceRow: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', marginTop: space[2] },
  price: { ...typography.title2, fontVariant: ['tabular-nums'], color: colors.ink },
  primary: {
    minHeight: layout.tap,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radii.m,
    backgroundColor: colors.ink,
    paddingHorizontal: space[4],
    paddingVertical: space[3],
    marginTop: space[3],
  },
  primaryText: { ...typography.subhead, fontWeight: '600', color: colors.white, textAlign: 'center' },
});
