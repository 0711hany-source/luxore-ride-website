import {
  coordinate,
  departure,
  distance,
  isService,
  type Booking,
  type Point,
  type Quote,
  type Service,
} from '../../lib/mobility/domain.ts';
import {
  parseRidePreferences,
  defaultPreferences,
  type RidePreferences,
} from '../../lib/mobility/ride-preferences.ts';
import { parseCart, type Cart } from '../../lib/mobility/refreshments.ts';
export type BookingBody = {
  quoteId: string;
  service: Service;
  riderName: string;
  riderPhone: string;
  preferences: RidePreferences;
  refreshments: Cart;
};
export type PendingBooking = { body: BookingBody; destination: string };
export type BookingStore = {
  load(): Promise<PendingBooking | null>;
  save(value: PendingBooking): Promise<void>;
  clear(): Promise<void>;
};
type Requests = {
  quote(
    body: {
      pickupId: string;
      destinationId: string;
      mode: 'now' | 'reservation';
      scheduledAt: number | null;
    },
    signal: AbortSignal,
  ): Promise<Quote>;
  book(body: BookingBody): Promise<Booking>;
};
export type CustomerBookingState = {
  pickup: Point | null;
  destination: Point | null;
  mode: 'now' | 'reservation';
  scheduledAt: number | null;
  quote: Quote | null;
  service: Service;
  preferences: RidePreferences;
  refreshments: Cart;
  riderName: string;
  riderPhone: string;
  loading: boolean;
  submitting: boolean;
  restoring: boolean;
  pending: PendingBooking | null;
  booking: Booking | null;
  error: string;
};
export class CustomerBookingController {
  private state: CustomerBookingState;
  private listeners = new Set<() => void>();
  private read: AbortController | null = null;
  private revision = 0;
  private active = false;
  private initialized = false;
  constructor(
    private api: Requests,
    private store: BookingStore,
    profile: { name: string; phone: string },
    private now = () => Date.now(),
  ) {
    this.state = {
      pickup: null,
      destination: null,
      mode: 'now',
      scheduledAt: null,
      quote: null,
      service: 'premium',
      preferences: { ...defaultPreferences },
      refreshments: {},
      riderName: profile.name,
      riderPhone: profile.phone,
      loading: false,
      submitting: false,
      restoring: true,
      pending: null,
      booking: null,
      error: '',
    };
  }
  getSnapshot = () => this.state;
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  private publish(patch: Partial<CustomerBookingState>) {
    this.state = { ...this.state, ...patch };
    for (const listener of this.listeners) listener();
  }
  private stopRead() {
    this.read?.abort();
    this.read = null;
    this.revision++;
    this.publish({ loading: false });
  }
  setActive(value: boolean) {
    this.active = value;
    if (!value) this.stopRead();
  }
  async restore() {
    if (this.initialized) return;
    this.initialized = true;
    try {
      const pending = await this.store.load();
      if (pending) {
        if (
          !isService(pending.body.service) ||
          typeof pending.body.quoteId !== 'string' ||
          !pending.body.quoteId
        )
          throw new Error(
            'Gespeicherte Anfrage ist ungültig. Bitte Support kontaktieren.',
          );
        this.publish({ pending, service: pending.body.service });
      }
      this.publish({ restoring: false });
    } catch {
      this.initialized = false;
      this.publish({
        error:
          'Gespeicherte Anfrage konnte nicht geprüft werden. Bitte erneut versuchen.',
      });
    }
  }
  private editable() {
    return (
      !this.state.restoring &&
      !this.state.submitting &&
      !this.state.pending &&
      !this.state.booking
    );
  }
  selectPlace(key: 'pickup' | 'destination', point: Point) {
    if (
      !this.editable() ||
      !point.id ||
      !point.label ||
      !coordinate(point.lat, point.lng)
    )
      return;
    this.stopRead();
    this.publish({ [key]: point, quote: null, error: '' });
  }
  setDeparture(mode: 'now' | 'reservation', scheduledAt: number | null) {
    if (!this.editable()) return;
    this.stopRead();
    this.publish({
      mode,
      scheduledAt: mode === 'now' ? null : scheduledAt,
      quote: null,
      error: '',
    });
  }
  setDetails(
    patch: Partial<
      Pick<
        CustomerBookingState,
        'service' | 'riderName' | 'riderPhone' | 'preferences' | 'refreshments'
      >
    >,
  ) {
    if (!this.editable()) return;
    if (patch.service && !isService(patch.service)) return;
    try {
      if (patch.preferences) parseRidePreferences(patch.preferences);
      if (patch.refreshments) parseCart(patch.refreshments);
    } catch (error) {
      this.publish({ error: (error as Error).message });
      return;
    }
    this.publish({ ...patch, error: '' });
  }
  newDraft() {
    if (this.state.submitting || this.state.pending || this.state.restoring)
      return;
    this.stopRead();
    this.publish({ booking: null, quote: null, error: '' });
  }
  async calculate() {
    if (!this.active || !this.editable() || this.state.loading) return;
    this.stopRead();
    const { pickup, destination, mode, scheduledAt } = this.state;
    try {
      if (!pickup || !destination)
        throw new Error('Bitte Abholort und Ziel auswählen.');
      if (distance(pickup, destination) < 30)
        throw new Error('Abholort und Ziel liegen zu nah beieinander.');
      departure(mode, scheduledAt, this.now());
    } catch (error) {
      this.publish({ quote: null, error: (error as Error).message });
      return;
    }
    const revision = this.revision,
      controller = new AbortController();
    this.read = controller;
    this.publish({ loading: true, quote: null, error: '' });
    try {
      const quote = await this.api.quote(
        {
          pickupId: pickup!.id,
          destinationId: destination!.id,
          mode,
          scheduledAt,
        },
        controller.signal,
      );
      if (
        controller.signal.aborted ||
        this.read !== controller ||
        revision !== this.revision
      )
        return;
      if (
        !quote.id ||
        quote.pickup.id !== pickup!.id ||
        quote.destination.id !== destination!.id ||
        quote.mode !== mode ||
        quote.scheduledAt !== scheduledAt ||
        !Number.isFinite(quote.expiresAt) ||
        quote.expiresAt <= this.now() ||
        !Number.isFinite(quote.distanceMeters) ||
        quote.distanceMeters < 1 ||
        !Number.isFinite(quote.durationSeconds) ||
        quote.durationSeconds < 0 ||
        !Object.values(quote.prices).every(
          (p) => Number.isInteger(p) && p >= 1500,
        ) ||
        !['premium', 'first', 'van'].every((k) =>
          Object.hasOwn(quote.prices, k),
        )
      )
        throw new Error(
          'Ungültiges Preisangebot. Bitte Route erneut berechnen.',
        );
      this.publish({ quote });
    } catch (error) {
      if (
        !controller.signal.aborted &&
        this.read === controller &&
        revision === this.revision
      )
        this.publish({ error: (error as Error).message });
    } finally {
      if (this.read === controller) {
        this.read = null;
        this.publish({ loading: false });
      }
    }
  }
  async submit() {
    if (
      !this.active ||
      this.state.restoring ||
      this.state.submitting ||
      this.state.booking
    )
      return;
    let pending = this.state.pending;
    if (!pending) {
      const {
        quote,
        service,
        riderName,
        riderPhone,
        preferences,
        refreshments,
      } = this.state;
      try {
        if (!quote || quote.expiresAt <= this.now())
          throw new Error(
            'Das Preisangebot ist abgelaufen. Bitte die Route neu berechnen.',
          );
        if (
          quote.mode === 'reservation' &&
          (!quote.scheduledAt || quote.scheduledAt < this.now() + 25 * 60000)
        )
          throw new Error('Bitte die Abholzeit aktualisieren.');
        if (!riderName.trim() || riderName.trim().length > 80)
          throw new Error('Bitte deinen Namen angeben.');
        if (!/^\+?[\d\s()-]{6,30}$/.test(riderPhone.trim()))
          throw new Error('Bitte eine gültige Telefonnummer angeben.');
        pending = {
          body: {
            quoteId: quote.id,
            service,
            riderName: riderName.trim(),
            riderPhone: riderPhone.trim(),
            preferences: parseRidePreferences(preferences),
            refreshments: parseCart(refreshments),
          },
          destination: quote.destination.label,
        };
      } catch (error) {
        this.publish({ error: (error as Error).message });
        return;
      }
    }
    this.publish({ submitting: true, error: '' });
    // Persist before transport. Lost answers and restarts retry the same quote
    // and class; the existing server returns the already created booking.
    try {
      await this.store.save(pending);
    } catch {
      this.publish({
        submitting: false,
        error:
          'Die Anfrage konnte nicht sicher gespeichert werden. Es wurde keine neue Buchung gesendet.',
      });
      return;
    }
    this.publish({ pending });
    try {
      const booking = await this.api.book(pending.body);
      if (
        !booking.id ||
        booking.quote_id !== pending.body.quoteId ||
        booking.service !== pending.body.service
      )
        throw new Error(
          'Die Buchungsbestätigung ist unvollständig. Bitte dieselbe Anfrage erneut bestätigen.',
        );
      this.publish({ booking, pending: null });
      await this.store.clear().catch(() => {});
    } catch (error) {
      // Only definite client rejection unlocks a new draft. Transport/server
      // failures may follow a committed booking and must retain its retry ID.
      const status = (error as { status?: number }).status;
      if (status && [400, 401, 403, 409, 422].includes(status)) {
        try {
          await this.store.clear();
          this.publish({ pending: null });
        } catch {
          this.publish({
            error:
              'Die abgelehnte Anfrage konnte nicht im Gerätespeicher abgeschlossen werden. Bitte erneut bestätigen.',
          });
          return;
        }
      }
      this.publish({ error: (error as Error).message });
    } finally {
      this.publish({ submitting: false });
    }
  }
}
