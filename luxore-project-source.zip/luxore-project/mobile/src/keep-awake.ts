type KeepAwake = {
  activateKeepAwakeAsync(tag: string): Promise<void>;
  deactivateKeepAwake(tag: string): Promise<void>;
};
/**
 * Keeps the screen on until the returned function is called. Best effort:
 * a missing native module must never stop the shift. (Plain Node test runs
 * have no bundler `require`; there it does nothing.)
 */
export function keepScreenOn(tag: string): () => void {
  let api: KeepAwake | null = null;
  try {
    api = typeof require === 'function' ? require('expo-keep-awake') : null;
  } catch {
    api = null;
  }
  if (
    typeof api?.activateKeepAwakeAsync !== 'function' ||
    typeof api.deactivateKeepAwake !== 'function'
  )
    return () => {};
  void api.activateKeepAwakeAsync(tag).catch(() => {});
  return () => {
    void api.deactivateKeepAwake(tag).catch(() => {});
  };
}
