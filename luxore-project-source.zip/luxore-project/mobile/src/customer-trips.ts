import type { Booking } from '../../lib/mobility/domain';
import { givenRatings, mergeRatings, validStars } from './customer-chauffeur.ts';
export type TripsState = {
  bookings: Booking[];
  /** Stars this customer gave, by ride; null: the server sends none yet. */
  ratings?: Record<string, number> | null;
  loaded: boolean;
  refreshing: boolean;
  changing: string | null;
  loadError: string;
  actionError: string;
  notice: string;
  updatedAt: number | null;
};
export const canCancelTrip = (booking: Booking) =>
  ['reserved', 'requesting', 'accepted', 'arrived'].includes(booking.status);
export function tripGroups(bookings: Booking[]) {
  return [
    {
      title: 'Aktuell',
      items: bookings
        .filter((b) =>
          ['requesting', 'accepted', 'arrived', 'riding'].includes(b.status),
        )
        .sort((a, b) => b.created_at - a.created_at),
    },
    {
      title: 'Reservierungen',
      items: bookings
        .filter((b) => b.status === 'reserved')
        .sort(
          (a, b) =>
            (a.scheduled_at || a.created_at) - (b.scheduled_at || b.created_at),
        ),
    },
    {
      title: 'Rückblick',
      items: bookings
        .filter((b) =>
          ['completed', 'cancelled', 'unavailable'].includes(b.status),
        )
        .sort((a, b) => b.created_at - a.created_at),
    },
  ];
}
/** A screen/account-bound store; background reads cannot replace newer trip actions. */
export class CustomerTripsController {
  private state: TripsState = {
    bookings: [],
    ratings: null,
    loaded: false,
    refreshing: false,
    changing: null,
    loadError: '',
    actionError: '',
    notice: '',
    updatedAt: null,
  };
  private listeners = new Set<() => void>();
  private active = false;
  private disposed = false;
  private revision = 0;
  private read: Promise<void> | null = null;
  private readController: AbortController | null = null;
  private queued = false;
  private ownRatings: Record<string, number> = {};
  constructor(
    private request: (
      body?: {
        action: 'cancel';
        id: string;
      },
      signal?: AbortSignal,
    ) => Promise<{ bookings?: Booking[]; ratings?: unknown }>,
  ) {}
  getSnapshot = () => this.state;
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  private publish(patch: Partial<TripsState>) {
    if (this.disposed) return;
    this.state = { ...this.state, ...patch };
    for (const listener of this.listeners) listener();
  }
  private abandonRead() {
    this.readController?.abort();
    this.readController = null;
    this.read = null;
    this.queued = false;
  }
  setActive(value: boolean) {
    if (this.disposed || value === this.active) return;
    this.active = value;
    this.revision++;
    if (value) void this.refresh();
    else {
      this.abandonRead();
      this.publish({ refreshing: false });
    }
  }
  refresh(): Promise<void> {
    if (this.disposed || !this.active) return Promise.resolve();
    if (this.read || this.state.changing) {
      this.queued = true;
      return this.read || Promise.resolve();
    }
    const revision = this.revision;
    this.queued = false;
    const controller = new AbortController();
    this.readController = controller;
    this.publish({ refreshing: true });
    const task = Promise.resolve().then(async () => {
      try {
        if (controller.signal.aborted) return;
        const result = await this.request(undefined, controller.signal);
        if (revision !== this.revision || !this.active || this.disposed) return;
        if (!Array.isArray(result.bookings))
          throw new Error(
            'Die Fahrten konnten nicht geladen werden. Bitte erneut versuchen.',
          );
        this.publish({
          bookings: result.bookings,
          ratings: mergeRatings(givenRatings(result.ratings), this.ownRatings),
          loaded: true,
          loadError: '',
          updatedAt: Date.now(),
        });
      } catch (error) {
        if (revision === this.revision && this.active)
          this.publish({
            loaded: true,
            loadError:
              error instanceof Error
                ? error.message
                : 'Die Fahrten konnten nicht geladen werden.',
          });
      } finally {
        // A cancelled transport may still settle later. Never release a newer
        // request's slot or schedule an overlapping read from this old task.
        if (this.read === task) {
          this.read = null;
          this.readController = null;
          if (revision === this.revision) this.publish({ refreshing: false });
          if (this.active && this.queued && !this.disposed) {
            this.queued = false;
            void this.refresh();
          }
        }
      }
    });
    this.read = task;
    return task;
  }
  async cancel(id: string) {
    const booking = this.state.bookings.find((b) => b.id === id);
    if (
      this.disposed ||
      !this.active ||
      this.state.changing ||
      this.state.loadError ||
      !booking ||
      !canCancelTrip(booking)
    )
      return;
    this.revision++;
    this.abandonRead();
    this.publish({
      changing: id,
      actionError: '',
      notice: '',
      refreshing: false,
    });
    try {
      await this.request({ action: 'cancel', id });
      // Change the displayed status only after the server has confirmed it.
      this.publish({
        bookings: this.state.bookings.map((b) =>
          b.id === id ? { ...b, status: 'cancelled' } : b,
        ),
        notice: 'Deine Fahrt wurde storniert.',
      });
    } catch (error) {
      this.publish({
        actionError:
          error instanceof Error
            ? error.message
            : 'Die Fahrt konnte nicht storniert werden.',
      });
    } finally {
      this.publish({ changing: null });
      if (this.active && !this.disposed) await this.refresh();
    }
  }
  /** The server confirmed a rating; a slower, older read must not hide it. */
  rated(id: string, stars: number) {
    if (this.disposed || !validStars(stars)) return;
    this.ownRatings = { ...this.ownRatings, [id]: stars };
    this.publish({ ratings: { ...this.state.ratings, [id]: stars } });
  }
  dispose() {
    this.disposed = true;
    this.active = false;
    this.revision++;
    this.abandonRead();
    this.listeners.clear();
  }
}
