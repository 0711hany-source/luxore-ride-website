export type NativeMapRuntime = {
  setAccessToken: (token: string) => Promise<unknown>;
  setTelemetryEnabled: (enabled: boolean) => void;
};
/** Mapbox's Android telemetry helper creates a native MapView. It must never
 * execute until setAccessToken has completed on the native UI thread. */
export class MapStartup {
  private token = '';
  private queue: Promise<void> = Promise.resolve();
  private readonly runtime: NativeMapRuntime;
  constructor(runtime: NativeMapRuntime) {
    this.runtime = runtime;
  }
  prepare(token: string, current: () => boolean): Promise<boolean> {
    const attempt = this.queue.then(async () => {
      if (!current()) return false;
      if (!token.startsWith('pk.') || token.length < 20)
        throw new Error('Der öffentliche Kartenzugang ist nicht verfügbar.');
      if (this.token === token) return true;
      // A canceled token change can still have changed the SDK token. Never
      // reuse a previous ready flag after beginning a different initialization.
      this.token = '';
      await this.runtime.setAccessToken(token);
      if (!current()) return false;
      this.runtime.setTelemetryEnabled(false);
      this.token = token;
      return true;
    });
    // An interrupted or failed initialization cannot poison subsequent retries.
    this.queue = attempt.then(
      () => {},
      () => {},
    );
    return attempt;
  }
}
