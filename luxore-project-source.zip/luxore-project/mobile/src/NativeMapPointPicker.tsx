import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import {
  ActivityIndicator,
  AppState,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, MapPin } from 'lucide-react-native';
import { nativeApi } from './account-client';
import type { Point } from '../../lib/mobility/domain';
import { MapPointController } from './map-point';
import PointMap from './PointMap';
import { colors, layout, radii, space, typography, maxFontScale } from './theme';
type Props = {
  visible: boolean;
  token: string;
  title: 'Abholort' | 'Ziel';
  initial?: Point | null;
  onClose: () => void;
  onSelected: (point: Point) => void;
};
export default function NativeMapPointPicker(props: Props) {
  if (!props.visible) return null;
  return (
    <Modal
      visible
      animationType="slide"
      presentationStyle="fullScreen"
      onRequestClose={props.onClose}
    >
      <Session key={props.token} {...props} />
    </Modal>
  );
}
function Session(props: Props) {
  'use no memo';
  const [initial] = useState(props.initial);
  const controller = useMemo(
    () =>
      new MapPointController(
        {
          config: (signal) =>
            nativeApi('config', props.token, undefined, undefined, signal),
          confirm: (center) =>
            nativeApi('places', props.token, {
              kind: 'pin',
              lat: center.lat,
              lng: center.lng,
            }),
        },
        initial,
      ),
    [props.token, initial],
  );
  const state = useSyncExternalStore(
    controller.subscribe,
    controller.getSnapshot,
    controller.getSnapshot,
  );
  const [foreground, setForeground] = useState(
    AppState.currentState === 'active',
  );
  const latest = useRef(props),
    delivered = useRef(false);
  useEffect(() => {
    latest.current = props;
  }, [props]);
  useEffect(() => {
    controller.setActive(AppState.currentState === 'active');
    const listener = AppState.addEventListener('change', (status) => {
      setForeground(status === 'active');
      controller.setActive(status === 'active');
    });
    return () => {
      listener.remove();
      controller.setActive(false);
    };
  }, [controller]);
  useEffect(() => {
    if (foreground && state.confirmed && !delivered.current) {
      delivered.current = true;
      latest.current.onSelected(state.confirmed);
    }
  }, [foreground, state.confirmed]);
  return (
    <SafeAreaView style={s.root} edges={['top', 'bottom']}>
      <View style={s.header}>
        <Pressable
          style={s.back}
          accessibilityLabel="Kartenwahl schließen"
          accessibilityRole="button"
          onPress={props.onClose}
        >
          <ArrowLeft size={24} color={colors.ink} />
        </Pressable>
        <Text style={s.brand} maxFontSizeMultiplier={maxFontScale}>
          LUXORÉ <Text style={s.ride}>RIDE</Text>
        </Text>
        <View style={s.back} />
      </View>
      <View style={s.map}>
        <PointMap
          token={state.token}
          active={foreground && !!state.token}
          center={state.center}
          locked={state.saving}
          onReady={() => controller.ready()}
          onMoving={() => controller.moving()}
          onIdle={(center) => controller.idle(center)}
          onError={() => controller.failed()}
        />
        {state.loading && (
          <View style={s.loading}>
            <ActivityIndicator color={colors.gold} />
            <Text style={s.detail}>Karte wird vorbereitet …</Text>
          </View>
        )}
      </View>
      <View style={s.panel}>
        <View style={s.row}>
          <MapPin size={23} color={colors.gold} />
          <Text style={s.title}>{props.title} auf Karte wählen</Text>
        </View>
        <Text style={s.detail}>
          {state.saving
            ? 'Der gewählte Punkt wird bestätigt …'
            : state.center.zoom < 14
              ? 'Vergrößere die Karte bis zur Straße und verschiebe sie unter die Markierung.'
              : 'Verschiebe die Karte. Die Spitze der Markierung zeigt deinen genauen Punkt.'}
        </Text>
        {state.error ? (
          <View style={s.error}>
            <Text accessibilityRole="alert" style={s.detail}>
              {state.error}
            </Text>
            {!state.token && !state.loading && (
              <Pressable
                hitSlop={15}
                accessibilityRole="button"
                onPress={() => void controller.load()}
              >
                <Text style={s.link}>Karte erneut laden</Text>
              </Pressable>
            )}
          </View>
        ) : null}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`${props.title} auf Karte bestätigen`}
          disabled={!controller.canConfirm()}
          onPress={() => void controller.confirm()}
          style={[s.primary, !controller.canConfirm() && s.disabled]}
        >
          {state.saving && <ActivityIndicator color={colors.white} />}
          <Text style={s.primaryText}>
            {state.saving
              ? 'Punkt wird bestätigt …'
              : `${props.title} bestätigen`}
          </Text>
        </Pressable>
        <Pressable
          accessibilityRole="button"
          onPress={props.onClose}
          style={s.address}
        >
          <Text style={s.link}>Zurück zur Adresseingabe</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 66,
    paddingHorizontal: space[4],
  },
  back: {
    width: layout.tap,
    height: layout.tap,
    alignItems: 'center',
    justifyContent: 'center',
  },
  brand: {
    fontSize: 22,
    fontWeight: '600',
    letterSpacing: 3,
    color: colors.ink,
  },
  ride: { fontSize: 10, color: colors.gold, letterSpacing: 2 },
  map: { flex: 1, backgroundColor: colors.paper, minHeight: 160 },
  loading: {
    position: 'absolute',
    inset: 0,
    alignItems: 'center',
    justifyContent: 'center',
    gap: space[3],
  },
  panel: { paddingHorizontal: layout.screenMargin, paddingTop: space[5], paddingBottom: space[3], gap: space[4] },
  row: { flexDirection: 'row', alignItems: 'center', gap: space[3] },
  title: { flex: 1, ...typography.title2, color: colors.ink },
  detail: { ...typography.footnote, color: colors.gray },
  error: { gap: space[2] },
  link: { ...typography.footnote, fontWeight: '600', color: colors.gold },
  primary: {
    minHeight: 56,
    borderRadius: radii.pill,
    paddingHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: space[3],
    backgroundColor: colors.ink,
  },
  disabled: { opacity: 0.42 },
  primaryText: { ...typography.subhead, fontWeight: '600', color: colors.white },
  address: {
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: layout.tap,
    padding: space[3],
  },
});
