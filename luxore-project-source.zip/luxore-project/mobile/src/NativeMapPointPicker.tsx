import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import {
  ActivityIndicator,
  AppState,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, MapPin } from 'lucide-react-native';
import { nativeApi } from './account-client';
import type { Point } from '../../lib/mobility/domain';
import { MapPointController } from './map-point';
import PointMap from './PointMap';
type Props = {
  visible: boolean;
  token: string;
  title: 'Abholort' | 'Ziel';
  initial?: Point | null;
  onClose: () => void;
  onSelected: (point: Point) => void;
};
export default function NativeMapPointPicker(props: Props) {
  if (!props.visible) return null;
  return (
    <Modal
      visible
      animationType="slide"
      presentationStyle="fullScreen"
      onRequestClose={props.onClose}
    >
      <Session key={props.token} {...props} />
    </Modal>
  );
}
function Session(props: Props) {
  'use no memo';
  const [initial] = useState(props.initial);
  const controller = useMemo(
    () =>
      new MapPointController(
        {
          config: (signal) =>
            nativeApi('config', props.token, undefined, undefined, signal),
          confirm: (center) =>
            nativeApi('places', props.token, {
              kind: 'pin',
              lat: center.lat,
              lng: center.lng,
            }),
        },
        initial,
      ),
    [props.token, initial],
  );
  const state = useSyncExternalStore(
    controller.subscribe,
    controller.getSnapshot,
    controller.getSnapshot,
  );
  const [foreground, setForeground] = useState(
    AppState.currentState === 'active',
  );
  const latest = useRef(props),
    delivered = useRef(false);
  useEffect(() => {
    latest.current = props;
  }, [props]);
  useEffect(() => {
    controller.setActive(AppState.currentState === 'active');
    const listener = AppState.addEventListener('change', (status) => {
      setForeground(status === 'active');
      controller.setActive(status === 'active');
    });
    return () => {
      listener.remove();
      controller.setActive(false);
    };
  }, [controller]);
  useEffect(() => {
    if (foreground && state.confirmed && !delivered.current) {
      delivered.current = true;
      latest.current.onSelected(state.confirmed);
    }
  }, [foreground, state.confirmed]);
  return (
    <SafeAreaView style={s.root} edges={['top', 'bottom']}>
      <View style={s.header}>
        <Pressable
          style={s.back}
          accessibilityLabel="Kartenwahl schließen"
          accessibilityRole="button"
          onPress={props.onClose}
        >
          <ArrowLeft size={24} color="#161a20" />
        </Pressable>
        <Text style={s.brand}>
          LUXORÉ <Text style={s.ride}>RIDE</Text>
        </Text>
        <View style={s.back} />
      </View>
      <View style={s.map}>
        <PointMap
          token={state.token}
          active={foreground && !!state.token}
          center={state.center}
          locked={state.saving}
          onReady={() => controller.ready()}
          onMoving={() => controller.moving()}
          onIdle={(center) => controller.idle(center)}
          onError={() => controller.failed()}
        />
        {state.loading && (
          <View style={s.loading}>
            <ActivityIndicator color="#aa8345" />
            <Text style={s.detail}>Karte wird vorbereitet …</Text>
          </View>
        )}
      </View>
      <View style={s.panel}>
        <View style={s.row}>
          <MapPin size={23} color="#aa8345" />
          <Text style={s.title}>{props.title} auf Karte wählen</Text>
        </View>
        <Text style={s.detail}>
          {state.saving
            ? 'Der gewählte Punkt wird bestätigt …'
            : state.center.zoom < 14
              ? 'Vergrößere die Karte bis zur Straße und verschiebe sie unter die Markierung.'
              : 'Verschiebe die Karte. Die Spitze der Markierung zeigt deinen genauen Punkt.'}
        </Text>
        {state.error ? (
          <View style={s.error}>
            <Text accessibilityRole="alert" style={s.detail}>
              {state.error}
            </Text>
            {!state.token && !state.loading && (
              <Pressable
                accessibilityRole="button"
                onPress={() => void controller.load()}
              >
                <Text style={s.link}>Karte erneut laden</Text>
              </Pressable>
            )}
          </View>
        ) : null}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`${props.title} auf Karte bestätigen`}
          disabled={!controller.canConfirm()}
          onPress={() => void controller.confirm()}
          style={[s.primary, !controller.canConfirm() && s.disabled]}
        >
          {state.saving && <ActivityIndicator color="#fff" />}
          <Text style={s.primaryText}>
            {state.saving
              ? 'Punkt wird bestätigt …'
              : `${props.title} bestätigen`}
          </Text>
        </Pressable>
        <Pressable
          accessibilityRole="button"
          onPress={props.onClose}
          style={s.address}
        >
          <Text style={s.link}>Zurück zur Adresseingabe</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 66,
    paddingHorizontal: 16,
  },
  back: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  brand: {
    fontSize: 22,
    fontWeight: '600',
    letterSpacing: 3,
    color: '#161a20',
  },
  ride: { fontSize: 10, color: '#aa8345', letterSpacing: 2 },
  map: { flex: 1, backgroundColor: '#faf7f0', minHeight: 160 },
  loading: {
    position: 'absolute',
    inset: 0,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  panel: { paddingHorizontal: 24, paddingTop: 24, paddingBottom: 12, gap: 14 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  title: { flex: 1, fontSize: 21, fontWeight: '600', color: '#161a20' },
  detail: { fontSize: 13, lineHeight: 20, color: '#737984' },
  error: { gap: 8 },
  link: { fontSize: 13, lineHeight: 20, fontWeight: '600', color: '#aa8345' },
  primary: {
    minHeight: 56,
    borderRadius: 28,
    paddingHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 10,
    backgroundColor: '#161a20',
  },
  disabled: { opacity: 0.42 },
  primaryText: { fontSize: 15, fontWeight: '600', color: '#fff' },
  address: { alignItems: 'center', padding: 10 },
});
