// Gemeinsame Teile der Betreiberplattform-Screens: Laden mit ruhigem
// „wird freigeschaltet“, Herunterziehen, Skeleton, Segment, Karte, Aufklapper.
// Ohne Reanimated – die Screens werden zwar erst beim Öffnen geladen, sollen
// aber keine weiteren Pakete in ihren Start ziehen.
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Animated,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { ChevronDown, ChevronRight, Clock3 } from 'lucide-react-native';
import { colors, layout, maxFontScale, radii, space, typography } from '../theme';
import Banner from '../ui/Banner';
import EmptyState from '../ui/EmptyState';
import { useReduceMotion } from '../ui/accessibility';
import { featurePendingText, loadFeature } from '../operator-platform';

export type Feature<T> = {
  data: T | null;
  phase: 'loading' | 'ready' | 'pending' | 'error';
  /** Fehler; bei vorhandenen Daten bleibt die letzte Ansicht stehen. */
  error: string;
  refreshing: boolean;
  /** Herunterziehen. */
  refresh: () => void;
  /** „Erneut versuchen“ bzw. Nachladen nach einem Schreibvorgang. */
  reload: () => Promise<void>;
};

/**
 * Liest eine Route und hält den Zustand der Ansicht. Jede neue Anfrage macht
 * die vorige ungültig; nach dem Verlassen des Screens wird nichts mehr gesetzt.
 */
export function useFeature<T>(
  read: (signal: AbortSignal) => Promise<unknown>,
  valid: (value: unknown) => value is T,
): Feature<T> {
  const [view, setView] = useState<{
    data: T | null;
    phase: Feature<T>['phase'];
    error: string;
    refreshing: boolean;
  }>({ data: null, phase: 'loading', error: '', refreshing: false });
  const run = useRef(0);
  const abort = useRef<AbortController | null>(null);
  const load = useCallback(
    async (pull: boolean) => {
      const id = ++run.current;
      abort.current?.abort();
      const controller = new AbortController();
      abort.current = controller;
      setView((v) => ({
        ...v,
        refreshing: pull,
        phase: v.data || pull ? v.phase : 'loading',
      }));
      try {
        const next = await loadFeature(() => read(controller.signal), valid);
        if (id !== run.current) return;
        setView((v) =>
          next.kind === 'ready'
            ? { data: next.data, phase: 'ready', error: '', refreshing: false }
            : next.kind === 'pending'
              ? { data: null, phase: 'pending', error: '', refreshing: false }
              : next.kind === 'error'
                ? {
                    data: v.data,
                    phase: v.data ? 'ready' : 'error',
                    error: next.message,
                    refreshing: false,
                  }
                : v,
        );
      } catch {
        // Abgebrochen: eine neuere Anfrage oder das Verlassen des Screens.
      }
    },
    [read, valid],
  );
  useEffect(() => {
    void load(false);
    return () => {
      run.current++;
      abort.current?.abort();
    };
  }, [load]);
  return {
    ...view,
    refresh: () => void load(true),
    reload: () => load(false),
  };
}

/** Rahmen jedes Screens: Scrollfläche mit Herunterziehen und allen Zuständen. */
export function FeatureScreen<T>({
  feature,
  loadingLabel,
  children,
  footer,
}: {
  feature: Feature<T>;
  loadingLabel: string;
  children: (data: T) => React.ReactNode;
  footer?: React.ReactNode;
}) {
  return (
    <ScrollView
      style={s.root}
      contentContainerStyle={s.content}
      keyboardShouldPersistTaps="handled"
      refreshControl={
        <RefreshControl
          refreshing={feature.refreshing}
          onRefresh={feature.refresh}
          colors={[colors.gold]}
          tintColor={colors.gold}
        />
      }
    >
      {feature.phase === 'loading' && <Skeleton label={loadingLabel} />}
      {feature.phase === 'pending' && (
        <EmptyState
          icon={Clock3}
          title="Bald verfügbar"
          text={featurePendingText}
        />
      )}
      {feature.phase === 'error' && (
        <Banner
          tone="error"
          title="Das hat nicht geklappt"
          text={feature.error}
          actionLabel="Erneut versuchen"
          onAction={() => void feature.reload()}
        />
      )}
      {feature.phase === 'ready' && !!feature.error && (
        <Banner
          tone="error"
          title="Nicht aktualisiert"
          text={feature.error}
          actionLabel="Erneut versuchen"
          onAction={() => void feature.reload()}
        />
      )}
      {feature.phase === 'ready' && feature.data !== null
        ? children(feature.data)
        : null}
      {footer}
    </ScrollView>
  );
}

/** Platzhalter beim ersten Laden; pulsiert nur ohne „Bewegung reduzieren“. */
export function Skeleton({ label }: { label: string }) {
  const reduceMotion = useReduceMotion();
  const opacity = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    if (reduceMotion) return;
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, {
          toValue: 0.45,
          duration: 700,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 1,
          duration: 700,
          useNativeDriver: true,
        }),
      ]),
    );
    pulse.start();
    return () => pulse.stop();
  }, [opacity, reduceMotion]);
  return (
    <Animated.View
      style={[s.skeleton, { opacity }]}
      accessible
      accessibilityRole="progressbar"
      accessibilityLabel={label}
    >
      <View style={[s.bone, { height: 96 }]} />
      <View style={s.boneRow}>
        <View style={[s.bone, s.flex, { height: 72 }]} />
        <View style={[s.bone, s.flex, { height: 72 }]} />
      </View>
      {[0, 1, 2, 3].map((row) => (
        <View key={row} style={[s.bone, { height: 56 }]} />
      ))}
    </Animated.View>
  );
}

export function Segment<Key extends string>({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: readonly { key: Key; label: string }[];
  value: Key;
  onChange: (key: Key) => void;
}) {
  return (
    <View style={s.segment} accessibilityRole="tablist" accessibilityLabel={label}>
      {options.map((option) => {
        const active = option.key === value;
        return (
          <Pressable
            key={option.key}
            style={[s.segmentItem, active && s.segmentActive]}
            accessibilityRole="tab"
            accessibilityLabel={option.label}
            accessibilityState={{ selected: active }}
            onPress={() => onChange(option.key)}
          >
            <Text
              style={[s.segmentText, active && s.segmentTextActive]}
              numberOfLines={1}
              maxFontSizeMultiplier={maxFontScale}
            >
              {option.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

/** Kennzahl: kleine Beschriftung, Betrag in Tabellenziffern. */
export function Stat({
  label,
  value,
  dark,
  large,
}: {
  label: string;
  value: string;
  dark?: boolean;
  large?: boolean;
}) {
  return (
    <View
      style={[s.stat, dark && s.statDark]}
      accessible
      accessibilityLabel={`${label}: ${value}`}
    >
      <Text
        style={[s.statLabel, dark && { color: colors.textOnInkMuted }]}
        maxFontSizeMultiplier={maxFontScale}
      >
        {label}
      </Text>
      <Text
        style={[
          large ? s.statValueLarge : s.statValue,
          dark && { color: colors.white },
        ]}
        maxFontSizeMultiplier={maxFontScale}
        adjustsFontSizeToFit
        numberOfLines={1}
      >
        {value}
      </Text>
    </View>
  );
}

/** Zeile einer Fahrt: Strecke, Betrag rechts, Detail darunter. */
export function TripRow({
  title,
  detail,
  value,
}: {
  title: string;
  detail: string;
  value: string;
}) {
  return (
    <View
      style={s.trip}
      accessible
      accessibilityLabel={`${title}, ${value}, ${detail}`}
    >
      <View style={s.tripTop}>
        <Text style={s.tripTitle} maxFontSizeMultiplier={maxFontScale}>
          {title}
        </Text>
        <Text style={s.tripValue} maxFontSizeMultiplier={maxFontScale}>
          {value}
        </Text>
      </View>
      <Text style={s.muted} maxFontSizeMultiplier={maxFontScale}>
        {detail}
      </Text>
    </View>
  );
}

/** Aufklappbarer Abschnitt mit Titel, Detailzeile und beliebigem Kopf-Zusatz. */
export function Disclosure({
  title,
  detail,
  header,
  initiallyOpen,
  children,
}: {
  title: string;
  detail?: string;
  header?: React.ReactNode;
  initiallyOpen?: boolean;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(!!initiallyOpen);
  const Icon = open ? ChevronDown : ChevronRight;
  return (
    <View style={s.card}>
      <Pressable
        style={s.disclosure}
        accessibilityRole="button"
        accessibilityLabel={[title, detail].filter(Boolean).join(', ')}
        accessibilityState={{ expanded: open }}
        onPress={() => setOpen((value) => !value)}
      >
        <View style={s.flex}>
          <Text style={s.cardTitle} maxFontSizeMultiplier={maxFontScale}>
            {title}
          </Text>
          {detail ? (
            <Text style={s.muted} maxFontSizeMultiplier={maxFontScale}>
              {detail}
            </Text>
          ) : null}
          {header}
        </View>
        <Icon color={colors.gray} size={20} strokeWidth={layout.iconStroke} />
      </Pressable>
      {open ? <View style={s.disclosureBody}>{children}</View> : null}
    </View>
  );
}

export function Note({ children }: { children: React.ReactNode }) {
  return (
    <Text style={s.muted} maxFontSizeMultiplier={maxFontScale}>
      {children}
    </Text>
  );
}
export function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <Text
      style={s.section}
      accessibilityRole="header"
      maxFontSizeMultiplier={maxFontScale}
    >
      {children}
    </Text>
  );
}
/** Punktliste für Gründe und Hinweise: jeder Punkt eine eigene Zeile. */
export function Bullets({ items, color }: { items: string[]; color?: string }) {
  return (
    <View style={s.bullets}>
      {items.map((item) => (
        <View key={item} style={s.bullet}>
          <Text style={[s.bulletDot, color ? { color } : null]}>•</Text>
          <Text
            style={[s.bulletText, color ? { color } : null]}
            maxFontSizeMultiplier={maxFontScale}
          >
            {item}
          </Text>
        </View>
      ))}
    </View>
  );
}

export const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
  content: {
    padding: layout.screenMargin,
    paddingBottom: space[7],
    gap: space[4],
  },
  flex: { flex: 1 },
  skeleton: { gap: layout.cardGap },
  bone: { borderRadius: radii.m, backgroundColor: colors.sand },
  boneRow: { flexDirection: 'row', gap: layout.cardGap },
  segment: {
    flexDirection: 'row',
    backgroundColor: colors.sand,
    borderRadius: radii.m,
    padding: space[1],
    gap: space[1],
  },
  segmentItem: {
    flex: 1,
    minHeight: layout.tap,
    borderRadius: radii.s,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: space[2],
  },
  segmentActive: { backgroundColor: colors.white },
  segmentText: { ...typography.subhead, color: colors.textMuted },
  segmentTextActive: { color: colors.ink, fontWeight: '600' },
  stats: { flexDirection: 'row', gap: layout.cardGap },
  stat: {
    flex: 1,
    borderRadius: radii.l,
    borderWidth: 1,
    borderColor: colors.line,
    backgroundColor: colors.white,
    padding: space[4],
    gap: space[1],
  },
  statDark: { backgroundColor: colors.ink, borderColor: colors.ink },
  statLabel: { ...typography.footnote, color: colors.textMuted },
  statValue: {
    ...typography.title2,
    color: colors.ink,
    fontVariant: ['tabular-nums'],
  },
  statValueLarge: {
    ...typography.largeTitle,
    color: colors.ink,
    fontVariant: ['tabular-nums'],
  },
  card: {
    borderRadius: radii.l,
    borderWidth: 1,
    borderColor: colors.line,
    backgroundColor: colors.white,
    overflow: 'hidden',
  },
  cardBody: { padding: space[4], gap: space[3] },
  cardTitle: { ...typography.headline, color: colors.ink },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: space[3],
  },
  disclosure: {
    minHeight: 56,
    flexDirection: 'row',
    alignItems: 'center',
    gap: space[3],
    padding: space[4],
  },
  disclosureBody: {
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.line,
    padding: space[4],
    gap: space[3],
  },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: space[2], marginTop: space[2] },
  trip: {
    paddingVertical: space[3],
    gap: 2,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.line,
  },
  tripTop: { flexDirection: 'row', gap: space[3], alignItems: 'flex-start' },
  tripTitle: { ...typography.body, color: colors.ink, flex: 1 },
  tripValue: {
    ...typography.headline,
    color: colors.ink,
    fontVariant: ['tabular-nums'],
  },
  muted: { ...typography.footnote, color: colors.textMuted },
  section: { ...typography.headline, color: colors.ink, marginTop: space[2] },
  bullets: { gap: space[1] },
  bullet: { flexDirection: 'row', gap: space[2] },
  bulletDot: { ...typography.subhead, color: colors.ink },
  bulletText: { ...typography.subhead, color: colors.ink, flex: 1 },
  notice: {
    borderRadius: radii.m,
    padding: space[4],
    gap: space[2],
  },
  noticeTitle: { ...typography.headline },
});
