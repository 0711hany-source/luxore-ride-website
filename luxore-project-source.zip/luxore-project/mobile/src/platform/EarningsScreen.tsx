import React, { useCallback, useState } from 'react';
import { View } from 'react-native';
import { CalendarDays } from 'lucide-react-native';
import { nativeApi } from '../account-client';
import EmptyState from '../ui/EmptyState';
import {
  euros,
  isEarnings,
  periodLabels,
  periods,
  rideDetail,
  ridesIn,
  routeLine,
  tripCount,
  type Period,
} from '../operator-platform';
import {
  FeatureScreen,
  Note,
  SectionTitle,
  Segment,
  Stat,
  TripRow,
  s,
  useFeature,
} from './parts';

const options = periods.map((key) => ({ key, label: periodLabels[key] }));

/** „Meine Einnahmen“: eigene Fahrten des Fahrers, bar und Terminal getrennt. */
export default function EarningsScreen({ token }: { token: string }) {
  const [period, setPeriod] = useState<Period>('today');
  const read = useCallback(
    (signal: AbortSignal) =>
      nativeApi('earnings', token, undefined, undefined, signal),
    [token],
  );
  const feature = useFeature(read, isEarnings);
  return (
    <FeatureScreen feature={feature} loadingLabel="Einnahmen werden geladen">
      {(data) => {
        const t = data.periods[period];
        const rides = ridesIn(data, period);
        return (
          <>
            <Segment
              label="Zeitraum"
              options={options}
              value={period}
              onChange={setPeriod}
            />
            <Stat
              dark
              large
              label={`${periodLabels[period]} · ${tripCount(t.trips)}`}
              value={euros(t.total)}
            />
            <View style={s.stats}>
              <Stat label="Bar kassiert" value={euros(t.cash)} />
              <Stat label="Über Terminal" value={euros(t.terminal)} />
            </View>
            {t.open > 0 && (
              <Stat label="Noch nicht kassiert" value={euros(t.open)} />
            )}
            <Note>
              Von dir kassierte Beträge deiner eigenen Fahrten (Woche ab Montag,
              deutscher Zeit). Dein Lohn oder Anteil wird hier nicht berechnet
              – das regelt deine Flotte.
            </Note>
            <SectionTitle>Fahrten</SectionTitle>
            {rides.length ? (
              <View>
                {rides.map((ride) => (
                  <TripRow
                    key={ride.id}
                    title={routeLine(ride.from, ride.to)}
                    value={euros(ride.price)}
                    detail={rideDetail(ride)}
                  />
                ))}
              </View>
            ) : (
              <EmptyState
                icon={CalendarDays}
                title="Noch keine Fahrten"
                text="Keine abgeschlossenen Fahrten in diesem Zeitraum."
              />
            )}
          </>
        );
      }}
    </FeatureScreen>
  );
}
