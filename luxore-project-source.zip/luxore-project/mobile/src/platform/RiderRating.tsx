import React, { useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { nativeApi } from '../account-client';
import { colors, layout, maxFontScale, space, typography } from '../theme';
import Button from '../ui/Button';
import TextField from '../ui/TextField';
import {
  canRate,
  isRatingSaved,
  ratingBody,
  ratingCommentMax,
  ratingErrorText,
  ratingProblem,
  sendLabel,
} from '../driver-reservations';
import StarInput, { StarsShown } from './StarInput';

/**
 * Der Fahrer bewertet den Fahrgast nach abgeschlossener Fahrt: 1 bis 5
 * Sterne, freiwilliger Kommentar, einmalig. Zeigt die vergebenen Sterne, die
 * Eingabe innerhalb der Frist oder nichts. Berührt weder Kassieren noch
 * Fahrtstatus; ein Fehler bleibt eine ruhige Zeile in diesem Block.
 */
export default function RiderRating({
  token,
  bookingId,
  given,
  completedAt,
  collapsed,
}: {
  token: string;
  bookingId: string;
  /** Sterne, die der Server für diese Fahrt schon kennt (0 = keine). */
  given: number;
  completedAt: number | null | undefined;
  /** In Listen: erst „Fahrgast bewerten“, dann die Eingabe. */
  collapsed?: boolean;
}) {
  const [open, setOpen] = useState(!collapsed),
    [stars, setStars] = useState(0),
    [comment, setComment] = useState(''),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [saved, setSaved] = useState(0);
  const alive = useRef(true),
    sending = useRef(false);
  useEffect(
    () => () => {
      alive.current = false;
    },
    [],
  );
  const done = saved || given;
  if (done)
    return (
      <View style={s.done}>
        <Text style={s.muted} maxFontSizeMultiplier={maxFontScale}>
          Deine Bewertung
        </Text>
        <StarsShown stars={done} />
      </View>
    );
  if (!canRate(completedAt, Date.now())) return null;
  if (!open)
    return (
      <Pressable
        style={s.link}
        accessibilityRole="button"
        accessibilityLabel="Fahrgast bewerten"
        onPress={() => setOpen(true)}
      >
        <Text style={s.linkText} maxFontSizeMultiplier={maxFontScale}>
          Fahrgast bewerten
        </Text>
      </Pressable>
    );
  async function send() {
    // Einmalig: ein zweiter Tipp während des Sendens löst nichts aus.
    if (sending.current) return;
    const problem = ratingProblem(stars, comment);
    if (problem) {
      setError(problem);
      return;
    }
    sending.current = true;
    setBusy(true);
    setError('');
    try {
      const answer = await nativeApi(
        'ratings',
        token,
        ratingBody(bookingId, stars, comment),
      );
      if (alive.current) setSaved(isRatingSaved(answer) ? answer.stars : stars);
    } catch (e) {
      if (alive.current) setError(ratingErrorText(e));
    } finally {
      sending.current = false;
      if (alive.current) setBusy(false);
    }
  }
  return (
    <View style={s.box}>
      <Text style={s.title} maxFontSizeMultiplier={maxFontScale}>
        Wie war der Fahrgast?
      </Text>
      <StarInput
        label="Fahrgast bewerten"
        value={stars}
        disabled={busy}
        onChange={(n) => {
          setStars(n);
          setError('');
        }}
      />
      {stars > 0 && (
        <>
          <TextField
            label="Kommentar (freiwillig)"
            value={comment}
            onChangeText={setComment}
            maxLength={ratingCommentMax}
            multiline
            editable={!busy}
            hint={`Wird nie veröffentlicht. Nur Betreiber und Flottenleitung lesen ihn. ${comment.length}/${ratingCommentMax}`}
          />
          <Button
            label={sendLabel(stars)}
            variant="secondary"
            loading={busy}
            onPress={() => void send()}
          />
          <Text style={s.muted} maxFontSizeMultiplier={maxFontScale}>
            Die Bewertung kann danach nicht mehr geändert werden.
          </Text>
        </>
      )}
      {!!error && (
        <Text
          style={s.error}
          accessibilityLiveRegion="polite"
          maxFontSizeMultiplier={maxFontScale}
        >
          {error}
        </Text>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  box: { gap: space[3], paddingVertical: space[2] },
  done: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: space[3],
    minHeight: layout.tap,
  },
  title: { ...typography.headline, color: colors.ink },
  muted: { ...typography.footnote, color: colors.textMuted },
  error: { ...typography.footnote, color: colors.danger },
  link: { minHeight: layout.tap, justifyContent: 'center' },
  linkText: {
    ...typography.subhead,
    fontWeight: '600',
    color: colors.ink,
    textDecorationLine: 'underline',
  },
});
