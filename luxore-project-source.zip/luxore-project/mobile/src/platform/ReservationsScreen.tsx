import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AppState, Linking, Text, View } from 'react-native';
import { CalendarDays, Phone } from 'lucide-react-native';
import { nativeApi } from '../account-client';
import { colors, maxFontScale } from '../theme';
import SwipeAction from '../SwipeAction';
import Banner from '../ui/Banner';
import Button from '../ui/Button';
import EmptyState from '../ui/EmptyState';
import {
  actionNotice,
  boardOptions,
  claimBody,
  claimHint,
  claimedText,
  classFacts,
  conflictText,
  contactHiddenText,
  isReservationBoard,
  mayRelease,
  offerFirstText,
  phoneLink,
  ratingLabel,
  ratingText,
  releaseBody,
  releaseClosedText,
  releasedText,
  reservationLabel,
  reservationPrice,
  reservationWhen,
  routeFacts,
  type ActionNotice,
  type BoardView,
  type ReservationCard,
} from '../driver-reservations';
import { FeatureScreen, Note, Segment, s, useFeature } from './parts';

/** Kopf einer Karte: Termin und Preis, Strecke, Klasse. */
function Facts({ r, full }: { r: ReservationCard; full?: boolean }) {
  return (
    <View style={{ gap: 4 }} accessible accessibilityLabel={reservationLabel(r)}>
      <View style={s.tripTop}>
        <Text style={s.tripTitle} maxFontSizeMultiplier={maxFontScale}>
          {reservationWhen(r.scheduledAt)}
        </Text>
        <Text style={s.tripValue} maxFontSizeMultiplier={maxFontScale}>
          {reservationPrice(r)}
        </Text>
      </View>
      <Text style={s.cardTitle} maxFontSizeMultiplier={maxFontScale}>
        {r.pickup}
      </Text>
      <Text style={s.bulletText} maxFontSizeMultiplier={maxFontScale}>
        nach {r.destination}
      </Text>
      <Text style={s.muted} maxFontSizeMultiplier={maxFontScale}>
        {routeFacts(r)}
      </Text>
      <Text style={s.muted} maxFontSizeMultiplier={maxFontScale}>
        {classFacts(r)}
      </Text>
      {full && !!r.wishes.length && (
        <Text style={s.muted} maxFontSizeMultiplier={maxFontScale}>
          Fahrtwünsche: {r.wishes.join(' · ')}
        </Text>
      )}
      {full && !!r.boardOrder && (
        <Text style={s.muted} maxFontSizeMultiplier={maxFontScale}>
          Bordwünsche: {r.boardOrder}
        </Text>
      )}
    </View>
  );
}

/**
 * „Reservierungen“: offene Reservierungen, die zum gewählten Fahrzeug passen,
 * und die eigenen. Übernehmen nur per vollständigem Wischen, Abgeben mit
 * Rückfrage. Sichtbarkeit, Fristen und Meldungen entscheidet der Server.
 */
export default function ReservationsScreen({ token }: { token: string }) {
  const [view, setView] = useState<BoardView>('open'),
    [detail, setDetail] = useState<string | null>(null),
    [returning, setReturning] = useState<string | null>(null),
    [busy, setBusy] = useState(false),
    [notice, setNotice] = useState<ActionNotice | null>(null),
    [saved, setSaved] = useState('');
  const read = useCallback(
    (signal: AbortSignal) =>
      nativeApi('reservations', token, undefined, undefined, signal),
    [token],
  );
  const feature = useFeature(read, isReservationBoard);
  const reload = useRef(feature.reload);
  reload.current = feature.reload;
  // Zeitpunkt der letzten Antwort: die Abgabefrist läuft mit der Serverzeit.
  const readAt = useRef(Date.now());
  const serverTime = feature.data?.serverTime;
  useEffect(() => {
    readAt.current = Date.now();
  }, [serverTime]);
  const locked = useRef(false),
    alive = useRef(true);
  useEffect(() => {
    // Rückkehr in die App: die Tafel kann sich inzwischen geändert haben.
    const listener = AppState.addEventListener('change', (state) => {
      if (state === 'active' && !locked.current) void reload.current();
    });
    return () => {
      alive.current = false;
      listener?.remove();
    };
  }, []);
  async function act(action: 'claim' | 'release', id: string) {
    if (locked.current) return;
    locked.current = true;
    setBusy(true);
    setNotice(null);
    setSaved('');
    try {
      await nativeApi(
        'reservations',
        token,
        action === 'claim' ? claimBody(id) : releaseBody(id),
      );
      if (!alive.current) return;
      setSaved(action === 'claim' ? claimedText : releasedText);
      if (action === 'claim') setView('mine');
    } catch (error) {
      if (alive.current) setNotice(actionNotice(action, error));
    } finally {
      locked.current = false;
      if (alive.current) {
        setDetail(null);
        setReturning(null);
        // Auch nach einer Ablehnung neu lesen: die Tafel hat sich geändert.
        await reload.current();
        if (alive.current) setBusy(false);
      }
    }
  }
  return (
    <FeatureScreen
      feature={feature}
      loadingLabel="Reservierungen werden geladen"
    >
      {(board) => (
        <>
          <Segment
            label="Ansicht"
            options={boardOptions(board)}
            value={view}
            onChange={(next) => {
              setView(next);
              setDetail(null);
              setReturning(null);
            }}
          />
          {!!notice && (
            <Banner tone={notice.tone} title={notice.title} text={notice.text} />
          )}
          {!!saved && <Banner tone="success" title={saved} />}
          {view === 'open' && (
            <>
              {!board.ready && (
                <Banner
                  title="Noch nicht möglich"
                  text={
                    board.reason ||
                    'Offene Reservierungen siehst du mit freigegebenem Profil und gewähltem Fahrzeug.'
                  }
                />
              )}
              {board.ready && !board.open.length && (
                <EmptyState
                  icon={CalendarDays}
                  title="Keine offene Reservierung"
                  text="Gerade passt keine offene Reservierung zu deinem Fahrzeug. Zum Aktualisieren nach unten ziehen."
                />
              )}
              {board.open.map((r) => (
                <View key={r.id} style={[s.card, s.cardBody]}>
                  <Facts r={r} full={detail === r.id} />
                  {r.conflict ? (
                    <View
                      style={[s.notice, { backgroundColor: colors.goldWash }]}
                    >
                      <Text
                        style={s.bulletText}
                        maxFontSizeMultiplier={maxFontScale}
                      >
                        {conflictText(board)}
                      </Text>
                    </View>
                  ) : detail === r.id ? (
                    <>
                      <Note>{claimHint(board)}</Note>
                      <SwipeAction
                        label="Reservierung übernehmen"
                        busy={busy}
                        onComplete={() => void act('claim', r.id)}
                      />
                      <Button
                        label="Doch nicht"
                        variant="text"
                        disabled={busy}
                        onPress={() => setDetail(null)}
                      />
                    </>
                  ) : (
                    <Button
                      label="Ansehen und übernehmen"
                      variant="secondary"
                      disabled={busy}
                      onPress={() => {
                        setDetail(r.id);
                        setNotice(null);
                        setSaved('');
                      }}
                    />
                  )}
                </View>
              ))}
              {!!board.open.length && (
                <Note>
                  Name und Telefonnummer des Fahrgasts siehst du erst nach dem
                  Übernehmen.
                </Note>
              )}
            </>
          )}
          {view === 'mine' && (
            <>
              {!board.mine.length && (
                <EmptyState
                  icon={CalendarDays}
                  title="Noch nichts übernommen"
                  text="Du hast noch keine Reservierung übernommen."
                />
              )}
              {board.mine.map((r) => {
                const call = phoneLink(r.riderPhone);
                const open = mayRelease(
                  r,
                  board.serverTime,
                  Date.now() - readAt.current,
                );
                return (
                  <View key={r.id} style={[s.card, s.cardBody]}>
                    <Facts r={r} full />
                    {!!r.check && (
                      <View
                        style={[s.notice, { backgroundColor: colors.goldWash }]}
                        accessibilityRole="alert"
                      >
                        <Text
                          style={[s.noticeTitle, { color: colors.goldText }]}
                          maxFontSizeMultiplier={maxFontScale}
                        >
                          Zuteilung prüfen
                        </Text>
                        <Text
                          style={s.bulletText}
                          maxFontSizeMultiplier={maxFontScale}
                        >
                          {r.check}
                        </Text>
                      </View>
                    )}
                    {r.contactHidden ? (
                      <Note>{contactHiddenText}</Note>
                    ) : (
                      <>
                        <View style={s.cardRow}>
                          <View style={s.flex}>
                            <Text
                              style={s.muted}
                              maxFontSizeMultiplier={maxFontScale}
                            >
                              Fahrgast
                            </Text>
                            <Text
                              style={s.cardTitle}
                              maxFontSizeMultiplier={maxFontScale}
                            >
                              {r.riderName || 'Fahrgast'}
                            </Text>
                          </View>
                          <Text
                            style={s.bulletDot}
                            accessible
                            accessibilityLabel={ratingLabel(r.riderRating)}
                            maxFontSizeMultiplier={maxFontScale}
                          >
                            {ratingText(r.riderRating)}
                          </Text>
                        </View>
                        {!!call && (
                          <Button
                            label={`Fahrgast anrufen · ${r.riderPhone}`}
                            variant="secondary"
                            icon={Phone}
                            onPress={() => void Linking.openURL(call).catch(() => {})}
                          />
                        )}
                      </>
                    )}
                    <Note>{offerFirstText}</Note>
                    {!open ? (
                      <Note>{releaseClosedText(board)}</Note>
                    ) : returning === r.id ? (
                      <View style={{ gap: 8 }}>
                        <Text
                          style={s.bulletText}
                          maxFontSizeMultiplier={maxFontScale}
                        >
                          Reservierung wirklich abgeben? Sie ist dann sofort
                          wieder für andere Fahrer offen.
                        </Text>
                        <Button
                          label="Ja, abgeben"
                          variant="destructive"
                          loading={busy}
                          onPress={() => void act('release', r.id)}
                        />
                        <Button
                          label="Behalten"
                          variant="secondary"
                          disabled={busy}
                          onPress={() => setReturning(null)}
                        />
                      </View>
                    ) : (
                      <Button
                        label="Reservierung abgeben"
                        variant="text"
                        disabled={busy}
                        onPress={() => {
                          setReturning(r.id);
                          setNotice(null);
                          setSaved('');
                        }}
                      />
                    )}
                  </View>
                );
              })}
            </>
          )}
        </>
      )}
    </FeatureScreen>
  );
}
