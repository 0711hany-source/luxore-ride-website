import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { nativeApi } from '../account-client';
import { colors, layout, maxFontScale, radii, space, typography } from '../theme';
import Banner from '../ui/Banner';
import Button from '../ui/Button';
import StatusChip from '../ui/StatusChip';
import TextField from '../ui/TextField';
import {
  checkBody,
  checkProblem,
  checkResultText,
  featurePendingText,
  inspectionChip,
  inspectionItems,
  isVehicleCheck,
  loadFeature,
  when,
  writeErrorText,
  type CheckDraft,
  type Loaded,
  type VehicleCheck,
} from '../operator-platform';
import { Note, s as shared } from './parts';

/**
 * Wochenkontrolle eines Fahrzeugs: Prüfliste ohne Fotos absenden, Verlauf
 * ansehen. Fotos sind freiwillig und laufen über die Web-Ansicht.
 */
export default function VehicleCheckForm({
  token,
  vehicleId,
  onChanged,
  onPhotos,
}: {
  token: string;
  vehicleId: string;
  onChanged?: () => void;
  onPhotos?: () => void;
}) {
  const [state, setState] = useState<Loaded<VehicleCheck>>({ kind: 'loading' });
  const [open, setOpen] = useState(false),
    [draft, setDraft] = useState<CheckDraft>({}),
    [odometer, setOdometer] = useState(''),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [saved, setSaved] = useState('');
  const alive = useRef(true),
    lock = useRef(false);
  const load = useCallback(async () => {
    const next = await loadFeature(
      () => nativeApi('inspections', token, undefined, { vehicleId }),
      isVehicleCheck,
    ).catch(() => null);
    if (alive.current && next) setState(next);
  }, [token, vehicleId]);
  useEffect(() => {
    alive.current = true;
    void load();
    return () => {
      alive.current = false;
    };
  }, [load]);
  if (state.kind === 'loading') return <Note>Kontrolle wird geladen …</Note>;
  if (state.kind === 'pending') return <Note>{featurePendingText}</Note>;
  if (state.kind === 'error')
    return (
      <Banner
        tone="error"
        title="Kontrolle nicht geladen"
        text={state.message}
        actionLabel="Erneut versuchen"
        onAction={() => {
          setState({ kind: 'loading' });
          void load();
        }}
      />
    );
  const data = state.data;
  const labels = Object.keys(data.items).length ? data.items : inspectionItems;
  const chip = inspectionChip(data.state);
  async function submit() {
    if (lock.current) return;
    const problem = checkProblem(labels, draft, odometer);
    if (problem) return setError(problem);
    lock.current = true;
    setBusy(true);
    setError('');
    try {
      const result = await nativeApi<{ result?: string }>(
        'inspections',
        token,
        checkBody(vehicleId, labels, draft, odometer),
      );
      if (!alive.current) return;
      setSaved(checkResultText(result.result));
      setOpen(false);
      setDraft({});
      setOdometer('');
      await load();
      onChanged?.();
    } catch (e) {
      if (alive.current) setError(writeErrorText(e));
    } finally {
      lock.current = false;
      if (alive.current) setBusy(false);
    }
  }
  return (
    <View style={f.wrap}>
      <View style={shared.cardRow}>
        <Text style={shared.cardTitle} maxFontSizeMultiplier={maxFontScale}>
          {data.vehicle.model} · {data.vehicle.plate}
        </Text>
        <StatusChip label={chip.text} tone={chip.tone} />
      </View>
      {data.state.latestResult === 'defect' && (
        <StatusChip label="Mangel gemeldet" tone="danger" />
      )}
      {!!saved && <Banner tone="success" title={saved} />}
      {!open ? (
        <Button
          label="Kontrolle jetzt durchführen"
          variant="secondary"
          onPress={() => {
            setOpen(true);
            setSaved('');
            setError('');
          }}
        />
      ) : (
        <View style={f.wrap}>
          {Object.entries(labels).map(([key, label]) => {
            const value = draft[key];
            return (
              <View key={key} style={f.item}>
                <Text style={f.label} maxFontSizeMultiplier={maxFontScale}>
                  {label}
                </Text>
                <View style={f.choices} accessibilityLabel={label}>
                  <Choice
                    label="In Ordnung"
                    selected={value?.ok === true}
                    onPress={() =>
                      setDraft((v) => ({ ...v, [key]: { ok: true, note: '' } }))
                    }
                  />
                  <Choice
                    label="Mangel"
                    danger
                    selected={value?.ok === false}
                    onPress={() =>
                      setDraft((v) => ({
                        ...v,
                        [key]: { ok: false, note: v[key]?.note || '' },
                      }))
                    }
                  />
                </View>
                {value?.ok === false && (
                  <TextField
                    label="Was ist der Mangel?"
                    value={value.note}
                    maxLength={200}
                    placeholder="z. B. Kratzer an der Tür hinten links"
                    onChangeText={(note) =>
                      setDraft((v) => ({ ...v, [key]: { ok: false, note } }))
                    }
                  />
                )}
              </View>
            );
          })}
          <TextField
            label="Kilometerstand (freiwillig)"
            value={odometer}
            keyboardType="number-pad"
            maxLength={7}
            onChangeText={setOdometer}
          />
          <Note>
            Fotos der vier Seiten und des Innenraums sind freiwillig. Die
            Prüfliste kannst du hier ohne Fotos absenden.
          </Note>
          {!!error && <Banner tone="error" title={error} />}
          <Button
            label="Kontrolle speichern"
            loading={busy}
            onPress={() => void submit()}
          />
          <Button
            label="Abbrechen"
            variant="text"
            disabled={busy}
            onPress={() => {
              setOpen(false);
              setError('');
            }}
          />
        </View>
      )}
      {!!onPhotos && !open && (
        <Button label="Kontrolle mit Fotos (Web-Ansicht)" variant="text" onPress={onPhotos} />
      )}
      {data.inspections.slice(0, 5).map((row) => {
        const defects = Object.entries(row.items || {}).filter(
          ([, item]) => item && item.ok === false,
        );
        return (
          <View key={row.id} style={f.history}>
            <View style={shared.cardRow}>
              <Text style={shared.muted} maxFontSizeMultiplier={maxFontScale}>
                {when(row.createdAt)} · {row.inspectorName}
                {row.odometer != null ? ` · ${row.odometer} km` : ''}
              </Text>
              <StatusChip
                label={row.result === 'ok' ? 'ohne Mangel' : 'mit Mangel'}
                tone={row.result === 'ok' ? 'success' : 'danger'}
              />
            </View>
            {defects.map(([key, item]) => (
              <Text key={key} style={f.defect} maxFontSizeMultiplier={maxFontScale}>
                {labels[key] || key}: {item.note}
              </Text>
            ))}
          </View>
        );
      })}
    </View>
  );
}
function Choice({
  label,
  selected,
  danger,
  onPress,
}: {
  label: string;
  selected: boolean;
  danger?: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      style={[
        f.choice,
        selected &&
          (danger
            ? { backgroundColor: colors.dangerWash, borderColor: colors.danger }
            : { backgroundColor: colors.successWash, borderColor: colors.success }),
      ]}
      accessibilityRole="radio"
      accessibilityLabel={label}
      accessibilityState={{ selected }}
      onPress={onPress}
    >
      <Text
        style={[
          f.choiceText,
          selected && { color: danger ? colors.danger : colors.success },
        ]}
        maxFontSizeMultiplier={maxFontScale}
      >
        {label}
      </Text>
    </Pressable>
  );
}
const f = StyleSheet.create({
  wrap: { gap: space[3] },
  item: { gap: space[2] },
  label: { ...typography.subhead, color: colors.ink, fontWeight: '600' },
  choices: { flexDirection: 'row', gap: space[2] },
  choice: {
    flex: 1,
    minHeight: layout.tap,
    borderRadius: radii.m,
    borderWidth: 1,
    borderColor: colors.lineStrong,
    alignItems: 'center',
    justifyContent: 'center',
  },
  choiceText: { ...typography.subhead, color: colors.ink, fontWeight: '600' },
  history: {
    paddingTop: space[3],
    gap: space[1],
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.line,
  },
  defect: { ...typography.footnote, color: colors.danger },
});
