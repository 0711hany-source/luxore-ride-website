import React, { useCallback, useEffect, useState } from 'react';
import { BackHandler, Pressable, StyleSheet, Text, View } from 'react-native';
import { ChevronRight } from 'lucide-react-native';
import { nativeApi } from '../account-client';
import { colors, layout, maxFontScale, space } from '../theme';
import Button from '../ui/Button';
import StatusChip from '../ui/StatusChip';
import {
  euros,
  isFleetIncome,
  isWeekStatement,
  monthLabel,
  routeLine,
  settledTripDetail,
  settlementNotice,
  shiftWeek,
  totalsLine,
  tripCount,
  weekChip,
  weekLabel,
  when,
} from '../operator-platform';
import {
  Disclosure,
  FeatureScreen,
  Note,
  SectionTitle,
  Segment,
  Stat,
  TripRow,
  s,
  useFeature,
} from './parts';

const modes = [
  { key: 'weeks', label: 'Wochen' },
  { key: 'months', label: 'Monate' },
] as const;
const fleetQuery = (fleetId: string, extra: Record<string, string>) => ({
  ...extra,
  ...(fleetId ? { fleetId } : {}),
});

/**
 * Flottenleitung: Einnahmen der eigenen Flotte, offene Servicepauschale,
 * Wochen bis zur einzelnen Fahrt. Nur Anzeige – abgerechnet wird beim Betreiber.
 */
export default function FleetIncomeScreen({
  token,
  fleetId,
}: {
  token: string;
  fleetId: string;
}) {
  const [week, setWeek] = useState<string | null>(null);
  useEffect(() => {
    if (!week) return;
    // Zurück führt aus der Woche erst zur Übersicht, dann eine Ebene weiter.
    const listener = BackHandler.addEventListener('hardwareBackPress', () => {
      setWeek(null);
      return true;
    });
    return () => listener.remove();
  }, [week]);
  return week ? (
    <WeekDetail
      key={week}
      token={token}
      fleetId={fleetId}
      week={week}
      onWeek={setWeek}
    />
  ) : (
    <Overview token={token} fleetId={fleetId} onWeek={setWeek} />
  );
}
function Overview({
  token,
  fleetId,
  onWeek,
}: {
  token: string;
  fleetId: string;
  onWeek: (week: string) => void;
}) {
  const [mode, setMode] = useState<'weeks' | 'months'>('weeks');
  const read = useCallback(
    (signal: AbortSignal) =>
      nativeApi(
        'settlements',
        token,
        undefined,
        fleetQuery(fleetId, { view: 'income' }),
        signal,
      ),
    [token, fleetId],
  );
  const feature = useFeature(read, isFleetIncome);
  return (
    <FeatureScreen feature={feature} loadingLabel="Einnahmen werden geladen">
      {(data) => (
        <>
          <SectionTitle>{data.fleet.name}</SectionTitle>
          <Note>{data.notice || settlementNotice}</Note>
          <Stat
            dark
            large
            label="Offene Servicepauschale · abgeschlossene Wochen"
            value={euros(data.openFee)}
          />
          <Stat
            label="Laufende Woche · Pauschale bisher"
            value={euros(data.currentFee)}
          />
          <Note>
            Für jede kassierte Fahrt fallen 15 % des Fahrpreises als
            Servicepauschale an. Abgerechnet wird wöchentlich, Montag bis
            Sonntag.
          </Note>
          <Segment label="Zeitraum" options={modes} value={mode} onChange={setMode} />
          {mode === 'weeks'
            ? data.weeks.map((w) => {
                const chip = weekChip(w);
                const label = weekLabel(w.start, w.end);
                return (
                  <Pressable
                    key={w.week}
                    style={[s.card, f.week]}
                    accessibilityRole="button"
                    accessibilityLabel={`Woche ${label}, ${chip.text}, ${totalsLine(w)}`}
                    onPress={() => onWeek(w.week)}
                  >
                    <View style={s.flex}>
                      <View style={s.cardRow}>
                        <Text style={s.cardTitle} maxFontSizeMultiplier={maxFontScale}>
                          {label}
                        </Text>
                        <StatusChip label={chip.text} tone={chip.tone} />
                      </View>
                      <Text style={[s.muted, f.figures]} maxFontSizeMultiplier={maxFontScale}>
                        {totalsLine(w)}
                      </Text>
                    </View>
                    <ChevronRight
                      color={colors.gray}
                      size={20}
                      strokeWidth={layout.iconStroke}
                    />
                  </Pressable>
                );
              })
            : data.months.map((m) => (
                <View key={m.month} style={[s.card, s.cardBody]}>
                  <Text style={s.cardTitle} maxFontSizeMultiplier={maxFontScale}>
                    {monthLabel(m.month)}
                  </Text>
                  <Text style={[s.muted, f.figures]} maxFontSizeMultiplier={maxFontScale}>
                    {totalsLine(m)}
                    {'\n'}bar {euros(m.cash)} · Terminal {euros(m.terminal)}
                  </Text>
                </View>
              ))}
        </>
      )}
    </FeatureScreen>
  );
}
function WeekDetail({
  token,
  fleetId,
  week,
  onWeek,
}: {
  token: string;
  fleetId: string;
  week: string;
  onWeek: (week: string | null) => void;
}) {
  const read = useCallback(
    (signal: AbortSignal) =>
      nativeApi(
        'settlements',
        token,
        undefined,
        fleetQuery(fleetId, { week }),
        signal,
      ),
    [token, fleetId, week],
  );
  const feature = useFeature(read, isWeekStatement);
  return (
    <FeatureScreen
      feature={feature}
      loadingLabel="Abrechnung wird geladen"
      footer={
        <Button
          label="Zur Übersicht"
          variant="secondary"
          onPress={() => onWeek(null)}
        />
      }
    >
      {(data) => {
        const st = data.statement;
        const chip = weekChip({ status: data.status, closed: data.closed, fee: st.fee });
        return (
          <>
            <View style={s.cardRow}>
              <Text style={s.section} accessibilityRole="header" maxFontSizeMultiplier={maxFontScale}>
                {weekLabel(st.start, st.end)}
              </Text>
              <StatusChip
                label={
                  data.status === 'paid' && data.paidAt
                    ? 'bezahlt am ' + when(data.paidAt)
                    : chip.text
                }
                tone={chip.tone}
              />
            </View>
            <Note>
              {data.notice || settlementNotice}. Zuordnung nach Kassierzeitpunkt.
            </Note>
            <View style={s.stats}>
              <Button
                label="Vorherige Woche"
                variant="secondary"
                style={s.flex}
                onPress={() => onWeek(shiftWeek(week, -7))}
              />
              <Button
                label="Nächste Woche"
                variant="secondary"
                style={s.flex}
                disabled={!data.closed}
                onPress={() => onWeek(shiftWeek(week, 7))}
              />
            </View>
            <View style={s.stats}>
              <Stat label="Fahrten" value={String(st.trips)} />
              <Stat label="Umsatz (Fahrpreise)" value={euros(st.revenue)} />
            </View>
            <View style={s.stats}>
              <Stat dark label="Servicepauschale 15 %" value={euros(st.fee)} />
              <Stat label="Rest für die Flotte" value={euros(st.net)} />
            </View>
            <Note>
              Kassiert bar {euros(st.cash)} · über Terminal {euros(st.terminal)}.
              Bordprodukte sind nicht Teil der Pauschale.
            </Note>
            <SectionTitle>Fahrer</SectionTitle>
            {st.drivers.length ? (
              st.drivers.map((d) => (
                <Disclosure
                  key={d.driverId}
                  title={d.name}
                  detail={`${tripCount(d.trips)} · ${euros(d.revenue)} · Pauschale ${euros(d.fee)}`}
                >
                  {d.rides.map((r) => (
                    <TripRow
                      key={r.id}
                      title={routeLine(r.from, r.to)}
                      value={euros(r.fare)}
                      detail={settledTripDetail(r)}
                    />
                  ))}
                </Disclosure>
              ))
            ) : (
              <Note>Keine kassierten Fahrten in dieser Woche.</Note>
            )}
          </>
        );
      }}
    </FeatureScreen>
  );
}
const f = StyleSheet.create({
  week: {
    minHeight: 64,
    flexDirection: 'row',
    alignItems: 'center',
    gap: space[3],
    padding: space[4],
  },
  figures: { fontVariant: ['tabular-nums'], marginTop: space[1] },
});
