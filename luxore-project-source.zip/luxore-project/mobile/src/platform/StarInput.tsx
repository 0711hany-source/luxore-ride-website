import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, layout, maxFontScale, space } from '../theme';
import { starValues, starsLabel, starsShown } from '../driver-reservations';

/**
 * Sterne-Eingabe 1 bis 5. Jede Tippfläche ist mindestens 48 × 48 groß und
 * wird als „3 von 5 Sternen“ vorgelesen; der Wert steht zusätzlich als Text
 * daneben, die Farbe trägt nie allein die Bedeutung.
 */
export default function StarInput({
  label,
  value,
  disabled,
  onChange,
}: {
  label: string;
  /** 0 = noch nichts gewählt. */
  value: number;
  disabled?: boolean;
  onChange: (stars: number) => void;
}) {
  return (
    <View
      style={s.row}
      accessibilityRole="radiogroup"
      accessibilityLabel={label}
    >
      {starValues.map((n) => {
        const on = value >= n;
        return (
          <Pressable
            key={n}
            style={s.star}
            disabled={disabled}
            accessibilityRole="radio"
            accessibilityLabel={starsLabel(n)}
            accessibilityState={{ checked: value === n, disabled: !!disabled }}
            onPress={() => onChange(n)}
          >
            <Text
              style={[s.glyph, { color: on ? colors.goldText : colors.lineStrong }]}
              maxFontSizeMultiplier={maxFontScale}
            >
              {on ? '★' : '☆'}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

/** Vergebene Sterne, nur Anzeige. */
export function StarsShown({ stars }: { stars: number }) {
  return (
    <Text
      style={s.shown}
      accessible
      accessibilityLabel={starsLabel(stars)}
      maxFontSizeMultiplier={maxFontScale}
    >
      {starsShown(stars)}
    </Text>
  );
}

const s = StyleSheet.create({
  row: { flexDirection: 'row', gap: space[1] },
  star: {
    minWidth: layout.tap,
    minHeight: layout.tap,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  glyph: { fontSize: 32, lineHeight: 38 },
  shown: { fontSize: 20, lineHeight: 24, color: colors.goldText, letterSpacing: 2 },
});
