import React, { useCallback } from 'react';
import { Text, View } from 'react-native';
import { nativeApi } from '../account-client';
import { colors, maxFontScale } from '../theme';
import Banner from '../ui/Banner';
import Button from '../ui/Button';
import StatusChip from '../ui/StatusChip';
import {
  isOwnCompliance,
  paperChip,
  readiness,
  refusalTitle,
  when,
} from '../operator-platform';
import {
  Bullets,
  FeatureScreen,
  Note,
  SectionTitle,
  s,
  useFeature,
} from './parts';
import VehicleCheckForm from './VehicleCheckForm';
import ProfilePhoto from './ProfilePhoto';
import { knowsProfilePhoto, profilePhotoId } from '../driver-reservations';

/**
 * „Vor der Schicht“: eigener Prüfstand des Fahrers (Sperren, Papiere,
 * Wochenkontrolle), Prüfliste absenden, Fotos über die Web-Ansicht.
 */
export default function ComplianceScreen({
  token,
  onPhotos,
}: {
  token: string;
  onPhotos: () => void;
}) {
  const read = useCallback(
    (signal: AbortSignal) =>
      nativeApi('compliance', token, undefined, undefined, signal),
    [token],
  );
  const feature = useFeature(read, isOwnCompliance);
  return (
    <FeatureScreen feature={feature} loadingLabel="Prüfstatus wird geladen">
      {(data) => {
        const r = readiness(data);
        if (!r.registered)
          return (
            <Banner
              title="Noch kein Fahrerprofil"
              text="Papiere und Wochenkontrolle gibt es, sobald dieses Konto als Chauffeur einer Flotte angelegt ist."
            />
          );
        return (
          <>
            {!!r.stops.length && (
              <View
                style={[s.notice, { backgroundColor: colors.dangerWash }]}
                accessibilityRole="alert"
              >
                <Text
                  style={[s.noticeTitle, { color: colors.danger }]}
                  maxFontSizeMultiplier={maxFontScale}
                >
                  {refusalTitle}:
                </Text>
                <Bullets items={r.stops} />
              </View>
            )}
            {!!r.hints.length && (
              <View style={[s.notice, { backgroundColor: colors.goldWash }]}>
                <Text
                  style={[s.noticeTitle, { color: colors.goldText }]}
                  maxFontSizeMultiplier={maxFontScale}
                >
                  {r.hintTitle}:
                </Text>
                <Bullets items={r.hints} />
              </View>
            )}
            {r.ok && (
              <Banner
                tone="success"
                title="Alles in Ordnung"
                text="Papiere und Wochenkontrolle sind in Ordnung."
              />
            )}
            <Note>
              {r.enforced
                ? `Prüfpflicht aktiv seit ${when(data.enforcedSince!)}: Ohne geprüfte Pflichtpapiere und gültige Wochenkontrolle kannst du nicht online gehen.`
                : 'Die Prüfpflicht ist noch nicht aktiv. Fehlende Papiere und Kontrollen sind derzeit nur Hinweise.'}
            </Note>
            {knowsProfilePhoto(data) && (
              <>
                <SectionTitle>Profilbild</SectionTitle>
                <ProfilePhoto
                  token={token}
                  photoId={profilePhotoId(data)}
                  onUpload={onPhotos}
                />
              </>
            )}
            <SectionTitle>Wochenkontrolle des Fahrzeugs</SectionTitle>
            {r.vehicle ? (
              <View style={[s.card, s.cardBody]}>
                <VehicleCheckForm
                  key={r.vehicle.id}
                  token={token}
                  vehicleId={r.vehicle.id}
                  onChanged={() => void feature.reload()}
                  onPhotos={onPhotos}
                />
              </View>
            ) : (
              <Note>
                Wähle zuerst im Bereich „Fahren“ ein Fahrzeug, um die
                Wochenkontrolle durchzuführen.
              </Note>
            )}
            <SectionTitle>Meine Papiere</SectionTitle>
            <View style={[s.card, s.cardBody]}>
              {(data.papers || []).map((paper) => {
                const chip = paperChip(paper);
                return (
                  <View key={paper.kind} style={{ gap: 4 }}>
                    <View style={s.cardRow}>
                      <Text
                        style={[s.bulletText, { fontWeight: '600' }]}
                        maxFontSizeMultiplier={maxFontScale}
                      >
                        {paper.label}
                      </Text>
                      <StatusChip label={chip.text} tone={chip.tone} />
                    </View>
                    {paper.state === 'rejected' && !!paper.reason && (
                      <Note>Grund: {paper.reason}</Note>
                    )}
                  </View>
                );
              })}
              {!data.papers?.length && <Note>Keine Papiere hinterlegt.</Note>}
              <Button label="Fotos hochladen" onPress={onPhotos} />
              <Note>
                Papiere brauchen ein Foto. Das Hochladen öffnet die
                LUXORÉ-Seite in der App; geprüft werden Papiere vom Betreiber.
              </Note>
            </View>
          </>
        );
      }}
    </FeatureScreen>
  );
}
