import React, { useState } from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import { UserRound } from 'lucide-react-native';
import { companyOrigin } from '../account-client';
import { colors, layout, maxFontScale, radii, space, typography } from '../theme';
import Button from '../ui/Button';
import StatusChip from '../ui/StatusChip';
import { profileMissingText, profilePhotoSource } from '../driver-reservations';

const size = 72;

/**
 * Eigenes Profilbild des Fahrers: Anzeige oder „Profilbild fehlt“. Hochladen
 * läuft über die LUXORÉ-Seite in der App (derselbe Weg wie bei Papieren) –
 * die App enthält kein Foto-Paket und braucht keine neue Berechtigung.
 */
export default function ProfilePhoto({
  token,
  photoId,
  onUpload,
}: {
  token: string;
  photoId: string | null;
  onUpload: () => void;
}) {
  // Lässt sich das Bild nicht laden, bleibt der Platzhalter stehen.
  const [failed, setFailed] = useState<string | null>(null);
  const shown = !!photoId && failed !== photoId;
  return (
    <View style={s.card}>
      <View style={s.top}>
        {shown ? (
          <Image
            source={profilePhotoSource(companyOrigin, photoId, token)}
            style={s.photo}
            accessible
            accessibilityRole="image"
            accessibilityLabel="Dein Profilbild"
            onError={() => setFailed(photoId)}
          />
        ) : (
          <View style={[s.photo, s.empty]} accessibilityElementsHidden>
            <UserRound
              color={colors.gray}
              size={32}
              strokeWidth={layout.iconStroke}
            />
          </View>
        )}
        <View style={s.texts}>
          {photoId ? (
            <StatusChip label="Profilbild vorhanden" tone="success" />
          ) : (
            <StatusChip label={profileMissingText} tone="danger" />
          )}
          <Text style={s.muted} maxFontSizeMultiplier={maxFontScale}>
            {photoId
              ? 'Fahrgäste sehen dein Bild, sobald eine Fahrt oder Reservierung dir zugeteilt ist.'
              : 'Fahrgäste sehen dein Bild, sobald eine Fahrt dir zugeteilt ist. Bitte lade ein Foto hoch.'}
          </Text>
        </View>
      </View>
      <Button
        label={photoId ? 'Profilbild ändern' : 'Profilbild hochladen'}
        variant="secondary"
        onPress={onUpload}
      />
    </View>
  );
}

const s = StyleSheet.create({
  card: {
    borderRadius: radii.l,
    borderWidth: 1,
    borderColor: colors.line,
    backgroundColor: colors.white,
    padding: space[4],
    gap: space[3],
  },
  top: { flexDirection: 'row', alignItems: 'center', gap: space[4] },
  photo: {
    width: size,
    height: size,
    borderRadius: size / 2,
    backgroundColor: colors.sand,
  },
  empty: { alignItems: 'center', justifyContent: 'center' },
  texts: { flex: 1, gap: space[2] },
  muted: { ...typography.footnote, color: colors.textMuted },
});
