import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Text, View } from 'react-native';
import { nativeApi } from '../account-client';
import SwipeAction from '../SwipeAction';
import { colors, maxFontScale } from '../theme';
import Banner from '../ui/Banner';
import Button from '../ui/Button';
import StatusChip from '../ui/StatusChip';
import TextField from '../ui/TextField';
import {
  historyDetail,
  holdActions,
  holdBy,
  inspectionChip,
  isFleetCompliance,
  isSuspensionList,
  liftBody,
  loadFeature,
  openPapers,
  openPapersText,
  paperChip,
  subjectName,
  suspendBody,
  suspendProblem,
  when,
  writeErrorText,
  type Hold,
  type PaperState,
  type SubjectType,
  type SuspensionHistory,
} from '../operator-platform';
import {
  Disclosure,
  FeatureScreen,
  Note,
  SectionTitle,
  s,
  useFeature,
} from './parts';
import VehicleCheckForm from './VehicleCheckForm';

/**
 * Flottenleitung: fällige Kontrollen und Papiere der Flotte, Fahrer und
 * Fahrzeuge aussetzen und wieder freigeben. Wer nicht zur Leitung gehört,
 * bekommt vom Server keine Daten – und sieht damit keine dieser Aktionen.
 */
export default function FleetComplianceScreen({
  token,
  fleetId,
  onPhotos,
}: {
  token: string;
  fleetId: string;
  onPhotos: () => void;
}) {
  const read = useCallback(
    (signal: AbortSignal) =>
      nativeApi(
        'compliance',
        token,
        undefined,
        fleetId ? { scope: 'fleet', fleetId } : { scope: 'fleet' },
        signal,
      ),
    [token, fleetId],
  );
  const feature = useFeature(read, isFleetCompliance);
  const [history, setHistory] = useState<SuspensionHistory[]>([]);
  const alive = useRef(true);
  const loadHistory = useCallback(async () => {
    const next = await loadFeature(
      () =>
        nativeApi(
          'suspensions',
          token,
          undefined,
          fleetId ? { fleetId } : undefined,
        ),
      isSuspensionList,
    ).catch(() => null);
    if (alive.current && next?.kind === 'ready')
      setHistory(next.data.suspensions);
  }, [token, fleetId]);
  useEffect(() => {
    alive.current = true;
    void loadHistory();
    return () => {
      alive.current = false;
    };
  }, [loadHistory]);
  const changed = () => {
    void feature.reload();
    void loadHistory();
  };
  return (
    <FeatureScreen feature={feature} loadingLabel="Prüfung wird geladen">
      {(data) => {
        const fleetOpen = openPapers(data.fleet.papers);
        const hold = (type: SubjectType, id: string, list: Hold[]) => (
          <HoldControl
            token={token}
            subjectType={type}
            subjectId={id}
            holds={list}
            operator={data.operator}
            onChanged={changed}
          />
        );
        return (
          <>
            <Banner
              tone={data.enforcedSince ? 'error' : 'info'}
              title={data.enforcedSince ? 'Prüfpflicht aktiv' : 'Prüfpflicht noch nicht aktiv'}
              text={
                data.enforcedSince
                  ? `Seit ${when(data.enforcedSince)}: Ohne geprüfte Pflichtpapiere und gültige Wochenkontrolle kann nicht online gegangen werden.`
                  : 'Fehlende Papiere und Kontrollen sind derzeit nur Hinweise. Bitte jetzt vorbereiten.'
              }
            />
            <Disclosure
              title={`Flotte · ${data.fleet.name}`}
              initiallyOpen={!!fleetOpen || !!data.fleet.suspensions.length}
              header={
                <View style={s.chips}>
                  {!!data.fleet.suspensions.length && (
                    <StatusChip label="ausgesetzt" tone="danger" />
                  )}
                  <StatusChip
                    label={openPapersText(fleetOpen)}
                    tone={fleetOpen ? 'danger' : 'success'}
                  />
                </View>
              }
            >
              {hold('fleet', data.fleet.id, data.fleet.suspensions)}
              <Papers papers={data.fleet.papers} />
            </Disclosure>
            <Button label="Fotos hochladen" variant="secondary" onPress={onPhotos} />
            <Note>
              Papiere und Kontrollfotos lädst du über die LUXORÉ-Seite in der
              App hoch. Geprüft werden Papiere vom Betreiber.
            </Note>
            <SectionTitle>Fahrzeuge</SectionTitle>
            {!data.vehicles.length && <Note>Keine aktiven Fahrzeuge.</Note>}
            {data.vehicles.map((v) => {
              const chip = inspectionChip(v.inspection),
                missing = openPapers(v.papers);
              return (
                <Disclosure
                  key={v.id}
                  title={`${v.model} · ${v.plate}`}
                  header={
                    <View style={s.chips}>
                      {!!v.suspensions.length && (
                        <StatusChip label="ausgesetzt" tone="danger" />
                      )}
                      <StatusChip label={chip.text} tone={chip.tone} />
                      {v.inspection.latestResult === 'defect' && (
                        <StatusChip label="Mangel gemeldet" tone="danger" />
                      )}
                      <StatusChip
                        label={openPapersText(missing)}
                        tone={missing ? 'danger' : 'success'}
                      />
                    </View>
                  }
                >
                  {hold('vehicle', v.id, v.suspensions)}
                  <VehicleCheckForm
                    token={token}
                    vehicleId={v.id}
                    onChanged={changed}
                  />
                  <Papers papers={v.papers} />
                </Disclosure>
              );
            })}
            <SectionTitle>Fahrer</SectionTitle>
            {!data.drivers.length && (
              <Note>Noch keine Fahrer in dieser Flotte.</Note>
            )}
            {data.drivers.map((d) => {
              const missing = openPapers(d.papers);
              const soon = d.papers
                .map(paperChip)
                .find((c) => c.tone === 'gold' && c.text.startsWith('läuft'));
              return (
                <Disclosure
                  key={d.id}
                  title={d.name}
                  header={
                    <View style={s.chips}>
                      {!!d.suspensions.length && (
                        <StatusChip label="ausgesetzt" tone="danger" />
                      )}
                      {!d.approved && (
                        <StatusChip label="nicht freigegeben" tone="gold" />
                      )}
                      <StatusChip
                        label={openPapersText(missing)}
                        tone={missing ? 'danger' : 'success'}
                      />
                      {soon && <StatusChip label={soon.text} tone="gold" />}
                    </View>
                  }
                >
                  {hold('driver', d.id, d.suspensions)}
                  <Papers papers={d.papers} />
                </Disclosure>
              );
            })}
            {!!history.length && (
              <Disclosure title={`Verlauf der Sperren (${history.length})`}>
                {history.map((h) => (
                  <View key={h.id} style={{ gap: 2 }}>
                    <View style={s.cardRow}>
                      <Text
                        style={[s.bulletText, { fontWeight: '600' }]}
                        maxFontSizeMultiplier={maxFontScale}
                      >
                        {subjectName(h.subject_type)} · {h.subject_name || '–'}
                      </Text>
                      <StatusChip
                        label={h.lifted_at ? 'aufgehoben' : 'aktiv'}
                        tone={h.lifted_at ? 'neutral' : 'danger'}
                      />
                    </View>
                    <Note>{historyDetail(h)}</Note>
                  </View>
                ))}
              </Disclosure>
            )}
          </>
        );
      }}
    </FeatureScreen>
  );
}
function Papers({ papers }: { papers: PaperState[] }) {
  return (
    <View style={{ gap: 8 }}>
      {papers.map((paper) => {
        const chip = paperChip(paper);
        return (
          <View key={paper.kind} style={s.cardRow}>
            <Text style={s.bulletText} maxFontSizeMultiplier={maxFontScale}>
              {paper.label}
            </Text>
            <StatusChip label={chip.text} tone={chip.tone} />
          </View>
        );
      })}
    </View>
  );
}
/** Aussetzen mit Grund und Freigeben – beides nur per vollständigem Wischen. */
function HoldControl({
  token,
  subjectType,
  subjectId,
  holds,
  operator,
  onChanged,
}: {
  token: string;
  subjectType: SubjectType;
  subjectId: string;
  holds: Hold[];
  operator: boolean;
  onChanged: () => void;
}) {
  const [asking, setAsking] = useState(false),
    [reason, setReason] = useState(''),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const lock = useRef(false),
    alive = useRef(true);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);
  const actions = holdActions(subjectType, holds, operator);
  async function send(body: object) {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError('');
    try {
      await nativeApi('suspensions', token, body);
      if (!alive.current) return;
      setAsking(false);
      setReason('');
      onChanged();
    } catch (e) {
      if (alive.current) setError(writeErrorText(e));
    } finally {
      lock.current = false;
      if (alive.current) setBusy(false);
    }
  }
  if (!holds.length && !actions.canSuspend) return null;
  return (
    <View style={{ gap: 12 }}>
      {holds.map((h) => (
        <View
          key={h.id}
          style={[s.notice, { backgroundColor: colors.dangerWash }]}
        >
          <Text
            style={[s.noticeTitle, { color: colors.danger }]}
            maxFontSizeMultiplier={maxFontScale}
          >
            Ausgesetzt durch {holdBy(h.level)}
          </Text>
          <Text style={s.bulletText} maxFontSizeMultiplier={maxFontScale}>
            {h.reason}
          </Text>
          <Note>
            {h.by} · {when(h.at)}
          </Note>
          {actions.liftable.includes(h.id) ? (
            <SwipeAction
              label="Wieder freigeben"
              busy={busy}
              onComplete={() => void send(liftBody(h.id))}
            />
          ) : (
            <Note>Diese Sperre kann nur der Betreiber aufheben.</Note>
          )}
        </View>
      ))}
      {!!error && <Banner tone="error" title={error} />}
      {actions.canSuspend &&
        (asking ? (
          <View style={{ gap: 12 }}>
            <TextField
              label="Grund"
              value={reason}
              maxLength={200}
              placeholder="z. B. Schaden vorne rechts"
              hint="Eine laufende Fahrt wird nicht abgebrochen. Ohne laufende Fahrt endet die Schicht sofort."
              onChangeText={setReason}
            />
            <SwipeAction
              label="Jetzt aussetzen"
              busy={busy}
              // Ohne Grund lässt sich nicht wischen.
              disabled={!!suspendProblem(reason)}
              onComplete={() => {
                const problem = suspendProblem(reason);
                if (problem) setError(problem);
                else void send(suspendBody(subjectType, subjectId, reason));
              }}
            />
            <Button
              label="Abbrechen"
              variant="text"
              disabled={busy}
              onPress={() => {
                setAsking(false);
                setError('');
              }}
            />
          </View>
        ) : (
          <Button
            label={subjectType === 'fleet' ? 'Ganze Flotte aussetzen' : 'Aussetzen'}
            variant="destructive"
            onPress={() => setAsking(true)}
          />
        ))}
    </View>
  );
}
