import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  BackHandler,
  Linking,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { WebView } from 'react-native-webview';
import { colors, maxFontScale, space, typography } from '../theme';
import Button from '../ui/Button';
import { photoTargets, type PhotoTarget } from '../operator-platform';
import { webviewSessionSource } from '../webview-session';

const origin = 'https://luxoreride.de';
function external(url: string) {
  if (/^(https:\/\/|tel:\+?[0-9]|mailto:)/i.test(url))
    void Linking.openURL(url).catch(() => {});
}

/**
 * Foto-Upload für Papiere und Kontrollen: die LUXORÉ-Webseite mit
 * Sitzungsübergabe, weil die Apps kein Foto-Paket enthalten. Die Seite nutzt
 * ihre eigene Dateiauswahl (`<input type="file">`). Bewusst ohne
 * Standortbrücke: Schicht, GPS und Fahrtalarm bleiben allein im nativen
 * Fahrerbereich.
 */
export default function PhotoWebScreen({
  token,
  target,
}: {
  token: string;
  target: PhotoTarget;
}) {
  const { path, hint } = photoTargets[target];
  const source = useMemo(() => webviewSessionSource(path, token), [path, token]);
  const web = useRef<WebView>(null);
  const canBack = useRef(false);
  const [loading, setLoading] = useState(true),
    [failed, setFailed] = useState(false),
    [renderer, setRenderer] = useState(0);
  useEffect(() => {
    if (!loading || failed) return;
    const timeout = setTimeout(() => {
      setLoading(false);
      setFailed(true);
    }, 20000);
    return () => clearTimeout(timeout);
  }, [loading, failed, renderer]);
  useEffect(() => {
    // Zurück geht erst innerhalb der Webseite, dann eine Ebene in der App.
    const listener = BackHandler.addEventListener('hardwareBackPress', () => {
      if (!canBack.current) return false;
      web.current?.goBack();
      return true;
    });
    return () => listener.remove();
  }, []);
  return (
    <View style={s.root}>
      <Text style={s.hint} maxFontSizeMultiplier={maxFontScale}>
        {hint}
      </Text>
      <View style={s.root}>
        <WebView
          key={renderer}
          ref={web}
          source={source}
          style={s.root}
          originWhitelist={['https://*', 'tel:*', 'mailto:*']}
          onShouldStartLoadWithRequest={(request) => {
            try {
              if (new URL(request.url).origin === origin) return true;
            } catch {
              return false;
            }
            external(request.url);
            return false;
          }}
          onOpenWindow={(event) => external(event.nativeEvent.targetUrl)}
          onNavigationStateChange={(state) => {
            canBack.current = state.canGoBack;
          }}
          domStorageEnabled
          javaScriptEnabled
          thirdPartyCookiesEnabled={false}
          mixedContentMode="never"
          allowFileAccess={false}
          allowFileAccessFromFileURLs={false}
          allowUniversalAccessFromFileURLs={false}
          cacheEnabled={false}
          cacheMode="LOAD_NO_CACHE"
          webviewDebuggingEnabled={false}
          setBuiltInZoomControls={false}
          setDisplayZoomControls={false}
          overScrollMode="never"
          bounces={false}
          onLoadStart={() => {
            setLoading(true);
            setFailed(false);
          }}
          onLoadEnd={() => setLoading(false)}
          onError={() => {
            setFailed(true);
            setLoading(false);
          }}
          onHttpError={(event) => {
            if (
              event.nativeEvent.url === source.uri &&
              event.nativeEvent.statusCode >= 400
            )
              setFailed(true);
          }}
          onRenderProcessGone={() => {
            canBack.current = false;
            setFailed(true);
            setLoading(false);
          }}
        />
        {loading && !failed && (
          <View style={s.overlay}>
            <ActivityIndicator color={colors.gold} />
            <Text style={s.message} maxFontSizeMultiplier={maxFontScale}>
              Verbindung zu LUXORÉ …
            </Text>
          </View>
        )}
        {failed && (
          <View style={s.overlay}>
            <Text style={s.title} maxFontSizeMultiplier={maxFontScale}>
              Seite nicht geladen
            </Text>
            <Text style={s.message} maxFontSizeMultiplier={maxFontScale}>
              Prüfe deine Internetverbindung und versuche es erneut.
            </Text>
            <Button
              label="Erneut versuchen"
              onPress={() => {
                setFailed(false);
                setLoading(true);
                setRenderer((value) => value + 1);
              }}
            />
          </View>
        )}
      </View>
    </View>
  );
}
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
  hint: {
    ...typography.footnote,
    color: colors.ink,
    backgroundColor: colors.goldWash,
    paddingHorizontal: space[4],
    paddingVertical: space[3],
  },
  overlay: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    padding: space[6],
    gap: space[4],
  },
  title: { ...typography.title2, color: colors.ink },
  message: { ...typography.body, color: colors.textMuted, textAlign: 'center' },
});
