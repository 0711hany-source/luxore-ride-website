import type { Point } from '../../lib/mobility/domain';
export type MapCenter = { lat: number; lng: number; zoom: number };
export type MapPointState = {
  center: MapCenter;
  token: string;
  loading: boolean;
  ready: boolean;
  idle: boolean;
  saving: boolean;
  confirmed: Point | null;
  error: string;
};
export const europeCenter: MapCenter = { lat: 50.5, lng: 10.5, zoom: 4 };
export function validMapCenter(value: MapCenter) {
  return (
    Number.isFinite(value.lat) &&
    Math.abs(value.lat) <= 85 &&
    Number.isFinite(value.lng) &&
    Math.abs(value.lng) <= 180 &&
    Number.isFinite(value.zoom) &&
    value.zoom >= 0 &&
    value.zoom <= 22
  );
}
type MapPointApi = {
  config(signal: AbortSignal): Promise<{ publicMapToken?: string }>;
  confirm(center: MapCenter): Promise<{ results: Point[] }>;
};
export class MapPointController {
  private readonly api: MapPointApi;
  private state: MapPointState;
  private active = false;
  private revision = 0;
  private read: AbortController | null = null;
  private listeners = new Set<() => void>();
  constructor(api: MapPointApi, initial?: Point | null) {
    this.api = api;
    this.state = {
      center: initial
        ? { lat: initial.lat, lng: initial.lng, zoom: 16 }
        : europeCenter,
      token: '',
      loading: false,
      ready: false,
      idle: false,
      saving: false,
      confirmed: null,
      error: '',
    };
  }
  getSnapshot = () => this.state;
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  private patch(value: Partial<MapPointState>) {
    this.state = { ...this.state, ...value };
    this.listeners.forEach((fn) => fn());
  }
  setActive(active: boolean) {
    if (active === this.active) return;
    this.active = active;
    if (!active) {
      this.revision++;
      this.read?.abort();
      this.read = null;
      this.patch({ loading: false, ready: false, idle: false });
    } else if (!this.state.confirmed) void this.load();
  }
  async load() {
    if (!this.active || this.state.loading) return;
    const revision = ++this.revision,
      read = new AbortController();
    this.read = read;
    this.patch({
      loading: true,
      token: '',
      ready: false,
      idle: false,
      error: '',
    });
    try {
      const config = await this.api.config(read.signal);
      if (revision !== this.revision || !this.active) return;
      if (
        !config.publicMapToken?.startsWith('pk.') ||
        config.publicMapToken.length < 20
      )
        throw Error(
          'Kartenzugang derzeit nicht verfügbar. Bitte erneut versuchen oder eine Adresse wählen.',
        );
      this.patch({ token: config.publicMapToken });
    } catch (error) {
      if (revision === this.revision && this.active)
        this.patch({
          error:
            error instanceof Error
              ? error.message
              : 'Karte konnte nicht geladen werden.',
        });
    } finally {
      if (revision === this.revision) {
        this.read = null;
        this.patch({ loading: false });
      }
    }
  }
  ready() {
    if (this.active) this.patch({ ready: true, error: '' });
  }
  moving() {
    if (this.active && !this.state.saving) this.patch({ idle: false });
  }
  idle(center: MapCenter) {
    if (this.active && !this.state.saving && validMapCenter(center))
      this.patch({ center, idle: true });
  }
  failed() {
    if (this.active)
      this.patch({
        ready: false,
        idle: false,
        error: 'Karte konnte nicht geladen werden. Bitte erneut laden.',
      });
  }
  canConfirm() {
    return (
      this.active &&
      this.state.ready &&
      this.state.idle &&
      this.state.center.zoom >= 14 &&
      !this.state.saving &&
      !this.state.confirmed
    );
  }
  async confirm() {
    if (!this.canConfirm()) return;
    const center = { ...this.state.center };
    this.patch({ saving: true, error: '' });
    try {
      // This persists a user-chosen point. Lifecycle changes must not abort it.
      const response = await this.api.confirm(center),
        point = response.results[0];
      if (
        !point?.id ||
        !point.label ||
        !validMapCenter({ ...point, zoom: 16 }) ||
        Math.abs(point.lat - center.lat) > 0.000001 ||
        Math.abs(point.lng - center.lng) > 0.000001
      )
        throw Error(
          'Der gewählte Kartenpunkt wurde nicht bestätigt. Bitte erneut versuchen.',
        );
      this.patch({ confirmed: point });
    } catch (error) {
      this.patch({
        error:
          error instanceof Error
            ? error.message
            : 'Kartenpunkt konnte nicht bestätigt werden.',
      });
    } finally {
      this.patch({ saving: false });
    }
  }
}
