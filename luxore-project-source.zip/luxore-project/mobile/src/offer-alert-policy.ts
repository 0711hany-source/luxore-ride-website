export type OfferAlert = { id: string; expiresAt: number };
export type AlertState = {
  sessionId: string;
  checkedAt: number;
  seenId: string | null;
};
export type AlertReply = { serverTime: number; offer: OfferAlert | null };
export function parseAlertReply(value: unknown): AlertReply | null {
  if (!value || typeof value !== 'object') return null;
  const b = value as Record<string, unknown>;
  if (typeof b.serverTime !== 'number' || !Number.isFinite(b.serverTime))
    return null;
  if (b.offer === null) return { serverTime: b.serverTime, offer: null };
  if (!b.offer || typeof b.offer !== 'object') return null;
  const o = b.offer as Record<string, unknown>;
  if (
    typeof o.id !== 'string' ||
    o.id.length < 1 ||
    o.id.length > 100 ||
    typeof o.expiresAt !== 'number' ||
    !Number.isFinite(o.expiresAt)
  )
    return null;
  return {
    serverTime: b.serverTime,
    offer: { id: o.id, expiresAt: o.expiresAt },
  };
}
export function alertLifetime(reply: AlertReply, elapsed: number) {
  // Use the server clock; subtract the whole round trip so slow responses never revive expired offers.
  return reply.offer
    ? Math.max(
        0,
        Math.min(
          25000,
          reply.offer.expiresAt - reply.serverTime - Math.max(0, elapsed),
        ),
      )
    : 0;
}
export function createAlertController(io: {
  load: () => Promise<AlertState | null>;
  save: (state: AlertState) => Promise<void>;
  present: (offer: OfferAlert, lifetime: number) => Promise<boolean>;
  dismiss: () => Promise<void>;
}) {
  let queue: Promise<unknown> = Promise.resolve();
  function serial<T>(job: () => Promise<T>): Promise<T> {
    const result = queue.then(job);
    queue = result.catch(() => {});
    return result;
  }
  return {
    clear: () => serial(() => io.dismiss()),
    sync: (
      sessionId: string,
      reply: AlertReply,
      elapsed: number,
      isCurrent: () => Promise<boolean>,
    ) => {
      const queuedAt = Date.now();
      return serial(async () => {
        if (!(await isCurrent())) return;
        const saved = await io.load();
        const state =
          saved?.sessionId === sessionId
            ? saved
            : { sessionId, checkedAt: 0, seenId: null };
        if (reply.serverTime <= state.checkedAt) return;
        const lifetime = alertLifetime(reply, elapsed + Date.now() - queuedAt);
        if (!reply.offer || lifetime <= 2000) {
          await io.dismiss();
          await io.save({ ...state, checkedAt: reply.serverTime });
          return;
        }
        if (reply.offer.id === state.seenId) {
          await io.save({ ...state, checkedAt: reply.serverTime });
          return;
        }
        if (!(await isCurrent())) return;
        const shown = await io.present(reply.offer, lifetime);
        if (!(await isCurrent())) {
          await io.dismiss();
          return;
        }
        await io.save({
          sessionId,
          checkedAt: reply.serverTime,
          seenId: shown ? reply.offer.id : state.seenId,
        });
      });
    },
  };
}
