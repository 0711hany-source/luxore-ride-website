export type OfferAlert = { id: string; expiresAt: number };
export type AlertState = {
  sessionId: string;
  checkedAt: number;
  seenId: string | null;
};
export type AlertReply = { serverTime: number; offer: OfferAlert | null };
export type AlertUpdate = AlertReply | { serverTime: number; offer: undefined };
export function parseAlertReply(value: unknown): AlertReply | null {
  if (!value || typeof value !== 'object') return null;
  const b = value as Record<string, unknown>;
  if (typeof b.serverTime !== 'number' || !Number.isFinite(b.serverTime))
    return null;
  if (b.offer === null) return { serverTime: b.serverTime, offer: null };
  if (!b.offer || typeof b.offer !== 'object') return null;
  const o = b.offer as Record<string, unknown>;
  if (
    typeof o.id !== 'string' ||
    o.id.length < 1 ||
    o.id.length > 100 ||
    typeof o.expiresAt !== 'number' ||
    !Number.isFinite(o.expiresAt)
  )
    return null;
  return {
    serverTime: b.serverTime,
    offer: { id: o.id, expiresAt: o.expiresAt },
  };
}
export function parseLocationAlertUpdate(value: unknown): AlertUpdate | null {
  const reply = parseAlertReply(value);
  if (reply) return reply;
  if (!value || typeof value !== 'object') return null;
  const b = value as Record<string, unknown>;
  // A confirmed GPS-only response is an ordering checkpoint, never a claim
  // that the current offer was withdrawn. Malformed offer data is not one.
  if (
    b.ok !== true ||
    typeof b.updated !== 'boolean' ||
    typeof b.serverTime !== 'number' ||
    !Number.isFinite(b.serverTime) ||
    Object.prototype.hasOwnProperty.call(b, 'offer')
  )
    return null;
  return { serverTime: b.serverTime, offer: undefined };
}
export function alertLifetime(reply: AlertReply, elapsed: number) {
  // Use the server clock; subtract the whole round trip so slow responses never revive expired offers.
  return reply.offer
    ? Math.max(
        0,
        Math.min(
          25000,
          reply.offer.expiresAt - reply.serverTime - Math.max(0, elapsed),
        ),
      )
    : 0;
}
export function createAlertController(io: {
  load: () => Promise<AlertState | null>;
  save: (state: AlertState) => Promise<void>;
  present: (
    offer: OfferAlert,
    lifetime: number,
    isCurrent: () => Promise<boolean>,
  ) => Promise<boolean>;
  dismiss: () => Promise<void>;
}) {
  let queue: Promise<unknown> = Promise.resolve();
  function serial<T>(job: () => Promise<T>): Promise<T> {
    const result = queue.then(job);
    queue = result.catch(() => {});
    return result;
  }
  return {
    clear: () => serial(() => io.dismiss()),
    sync: (
      sessionId: string,
      reply: AlertUpdate,
      elapsed: number,
      isCurrent: () => Promise<boolean>,
    ) => {
      const queuedAt = Date.now();
      return serial(async () => {
        if (!(await isCurrent())) return;
        const saved = await io.load();
        const state =
          saved?.sessionId === sessionId
            ? saved
            : { sessionId, checkedAt: 0, seenId: null };
        if (reply.serverTime <= state.checkedAt) return;
        // Credential/storage work also consumes the remaining offer lifetime.
        if (!(await isCurrent())) return;
        if (reply.offer === undefined) {
          // Preserve the existing alarm/seen ID/deadline, while preventing a
          // delayed older response from initiating a new stale notification.
          await io.save({ ...state, checkedAt: reply.serverTime });
          return;
        }
        const lifetime = alertLifetime(reply, elapsed + Date.now() - queuedAt);
        if (!reply.offer || lifetime <= 2000) {
          await io.dismiss();
          await io.save({ ...state, checkedAt: reply.serverTime });
          return;
        }
        if (reply.offer.id === state.seenId) {
          await io.save({ ...state, checkedAt: reply.serverTime });
          return;
        }
        const shown = await io.present(reply.offer, lifetime, isCurrent);
        if (!(await isCurrent())) {
          await io.dismiss();
          return;
        }
        await io.save({
          sessionId,
          checkedAt: reply.serverTime,
          seenId: shown ? reply.offer.id : state.seenId,
        });
      });
    },
  };
}
