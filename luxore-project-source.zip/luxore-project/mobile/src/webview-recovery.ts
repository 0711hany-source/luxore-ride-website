/** Restore a killed renderer once; repeated crashes need a deliberate retry. */
export class WebViewRecovery {
  private lastAttempt: number | null = null;
  private gone = false;
  crashed(now = Date.now()) {
    this.gone = true;
    if (this.lastAttempt !== null && now - this.lastAttempt < 60000)
      return false;
    this.lastAttempt = now;
    this.gone = false;
    return true;
  }
  retry() {
    const replace = this.gone;
    this.gone = false;
    return replace;
  }
}
