import * as Notifications from 'expo-notifications';
import * as SecureStore from 'expo-secure-store';
import { createAlertController, type AlertState } from './offer-alert-policy';
const channelId = 'luxore-ride-offers-v1';
const notificationId = 'luxore-current-offer';
const stateKey = 'luxore-offer-alert-state';
let expiry: ReturnType<typeof setTimeout> | undefined;
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
    priority: Notifications.AndroidNotificationPriority.HIGH,
  }),
});
async function channel() {
  await Notifications.setNotificationChannelAsync(channelId, {
    name: 'Fahrtangebote',
    description: 'Neue Fahrtangebote während deiner Online-Schicht',
    importance: Notifications.AndroidImportance.HIGH,
    sound: 'default',
    enableVibrate: true,
    vibrationPattern: [0, 250, 150, 250],
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PRIVATE,
    bypassDnd: false,
  });
}
export async function alertStatus() {
  await channel();
  const p = await Notifications.getPermissionsAsync();
  const c = await Notifications.getNotificationChannelAsync(channelId);
  const enabled =
    p.granted && !!c && c.importance !== Notifications.AndroidImportance.NONE;
  return {
    enabled,
    sound:
      enabled &&
      c!.sound !== null &&
      c!.importance >= Notifications.AndroidImportance.DEFAULT,
  };
}
export async function requestAlerts() {
  await channel();
  const p = await Notifications.getPermissionsAsync();
  if (!p.granted && p.canAskAgain)
    await Notifications.requestPermissionsAsync();
  return alertStatus();
}
async function dismiss() {
  clearTimeout(expiry);
  expiry = undefined;
  await Notifications.dismissNotificationAsync(notificationId);
}
export const offerAlerts = createAlertController({
  load: async () => {
    const raw = await SecureStore.getItemAsync(stateKey);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as AlertState;
    } catch {
      return null;
    }
  },
  save: (state) => SecureStore.setItemAsync(stateKey, JSON.stringify(state)),
  dismiss,
  present: async (offer, lifetime) => {
    const deadline = Date.now() + lifetime;
    if (!(await alertStatus()).enabled) return false;
    if (deadline - Date.now() <= 2000) return false;
    await dismiss();
    await Notifications.scheduleNotificationAsync({
      identifier: notificationId,
      content: {
        title: 'Neue Fahrt · Luxóre Driver',
        body: 'Fahrtangebot eingegangen. Jetzt öffnen und Verfügbarkeit prüfen.',
        sound: 'default',
        priority: Notifications.AndroidNotificationPriority.HIGH,
        autoDismiss: true,
        data: { kind: 'luxore-offer', offerId: offer.id },
      },
      trigger: { channelId },
    });
    // Best effort in JS; every following heartbeat also removes expired/withdrawn offers.
    expiry = setTimeout(
      () => {
        void dismiss().catch(() => {});
      },
      Math.max(0, deadline - Date.now()),
    );
    return true;
  },
});
export async function testAlert() {
  const status = await requestAlerts();
  if (!status.enabled)
    throw new Error(
      'Benachrichtigungen sind deaktiviert. Bitte in den Android-App-Einstellungen erlauben.',
    );
  await Notifications.scheduleNotificationAsync({
    identifier: 'luxore-test-alarm',
    content: {
      title: 'Luxóre · Testalarm',
      body: 'So meldet sich ein neues Fahrtangebot. Dies ist keine echte Fahrt.',
      sound: 'default',
      autoDismiss: true,
      data: { kind: 'luxore-test' },
    },
    trigger: { channelId },
  });
  return status;
}
