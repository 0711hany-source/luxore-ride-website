import * as Notifications from 'expo-notifications';
import * as SecureStore from 'expo-secure-store';
import * as ReactNative from 'react-native';
// (Plain Node test runs replace react-native with a small stand-in.)
const Vibration = ReactNative.Vibration as
  | typeof ReactNative.Vibration
  | undefined;
import {
  createAlertController,
  stateKey,
  type AlertState,
} from './offer-alert-policy';
import { isIos, platformText } from './platform-text';
const channelId = 'luxore-ride-offers-v1';
// The offer rings again every few seconds until it is answered or expires.
const ringEveryMs = 5000;
let ring: ReturnType<typeof setInterval> | undefined;
const notificationId = 'luxore-current-offer';
let expiry: ReturnType<typeof setTimeout> | undefined;
// (Optional call: plain Node test runs use a small stand-in.)
Notifications.setNotificationHandler?.({
  handleNotification: async () => ({
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
    priority: Notifications.AndroidNotificationPriority.HIGH,
  }),
});
async function channel() {
  // Notification channels exist on Android only.
  if (isIos) return;
  await Notifications.setNotificationChannelAsync(channelId, {
    name: 'Fahrtangebote',
    description: 'Neue Fahrtangebote während deiner Online-Schicht',
    importance: Notifications.AndroidImportance.HIGH,
    sound: 'default',
    enableVibrate: true,
    vibrationPattern: [0, 250, 150, 250],
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PRIVATE,
    bypassDnd: false,
  });
}
export async function alertStatus() {
  await channel();
  const p = await Notifications.getPermissionsAsync();
  // iOS has no channels: the notification permission alone decides.
  if (isIos)
    return {
      enabled: p.granted,
      sound: p.granted && p.ios?.allowsSound !== false,
    };
  const c = await Notifications.getNotificationChannelAsync(channelId);
  const enabled =
    p.granted && !!c && c.importance !== Notifications.AndroidImportance.NONE;
  return {
    enabled,
    sound:
      enabled &&
      c!.sound !== null &&
      c!.importance >= Notifications.AndroidImportance.DEFAULT,
  };
}
export async function requestAlerts() {
  await channel();
  const p = await Notifications.getPermissionsAsync();
  if (!p.granted && p.canAskAgain)
    await Notifications.requestPermissionsAsync();
  return alertStatus();
}
async function dismiss() {
  clearTimeout(expiry);
  expiry = undefined;
  clearInterval(ring);
  ring = undefined;
  Vibration?.cancel();
  await Notifications.dismissNotificationAsync(notificationId);
}
export const offerAlerts = createAlertController({
  load: async () => {
    const raw = await SecureStore.getItemAsync(stateKey);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as AlertState;
    } catch {
      return null;
    }
  },
  save: (state) => SecureStore.setItemAsync(stateKey, JSON.stringify(state)),
  dismiss,
  present: async (offer, lifetime, isCurrent) => {
    const deadline = Date.now() + lifetime;
    if (!(await alertStatus()).enabled) return false;
    if (!(await isCurrent()) || deadline - Date.now() <= 2000) return false;
    await dismiss();
    // Native dismissal may settle late; never schedule beyond the original deadline.
    if (!(await isCurrent()) || deadline - Date.now() <= 2000) return false;
    const show = () =>
      Notifications.scheduleNotificationAsync({
        // Same identifier: the entry is replaced and the phone rings again.
        identifier: notificationId,
        content: {
          title: 'Neue Fahrt · LUXORÉ Driver',
          body: 'Fahrtangebot wartet auf deine Antwort. Jetzt öffnen.',
          sound: 'default',
          priority: Notifications.AndroidNotificationPriority.HIGH,
          autoDismiss: true,
          data: { kind: 'luxore-offer', offerId: offer.id },
        },
        // `channelId` alone means „show now“; iOS ignores the channel.
        trigger: { channelId },
      });
    await show();
    Vibration?.vibrate([0, 400, 200, 400]);
    ring = setInterval(() => {
      if (deadline - Date.now() <= 2000) {
        clearInterval(ring);
        ring = undefined;
        return;
      }
      Vibration?.vibrate([0, 400, 200, 400]);
      void show().catch(() => {});
    }, ringEveryMs);
    // Best effort in JS; every following heartbeat also removes expired/withdrawn offers.
    expiry = setTimeout(
      () => {
        void dismiss().catch(() => {});
      },
      Math.max(0, deadline - Date.now()),
    );
    return true;
  },
});
export async function testAlert() {
  const status = await requestAlerts();
  if (!status.enabled)
    throw new Error(
      platformText.alertsDisabled,
    );
  await Notifications.scheduleNotificationAsync({
    identifier: 'luxore-test-alarm',
    content: {
      title: 'LUXORÉ · Testalarm',
      body: 'So meldet sich ein neues Fahrtangebot. Dies ist keine echte Fahrt.',
      sound: 'default',
      autoDismiss: true,
      data: { kind: 'luxore-test' },
    },
    // `channelId` alone means „show now“; iOS ignores the channel.
    trigger: { channelId },
  });
  return status;
}
