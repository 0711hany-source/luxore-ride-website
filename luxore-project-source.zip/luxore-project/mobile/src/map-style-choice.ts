import { useSyncExternalStore } from 'react';
import { mapStyleFor } from '../../lib/mobility/map-style';

/**
 * Street map or satellite: one choice for every map of the app, remembered on
 * the device. Android, iPhone and the web use the same two styles.
 */
const KEY = 'luxore-map-satellite';
let satellite = false;
const listeners = new Set<() => void>();
// Loaded on demand: the choice is a convenience, a map must never wait for
// or fail with the device store.
const store = () => import('expo-secure-store');
void store()
  .then((s) => s.getItemAsync(KEY))
  .then((value) => {
    if (value === '1' && !satellite) {
      satellite = true;
      listeners.forEach((l) => l());
    }
  })
  .catch(() => {});
export function toggleSatellite() {
  satellite = !satellite;
  listeners.forEach((l) => l());
  void store()
    .then((s) => s.setItemAsync(KEY, satellite ? '1' : '0'))
    .catch(() => {});
}
const subscribe = (listener: () => void) => {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
};
export function useSatellite() {
  return useSyncExternalStore(subscribe, () => satellite);
}
/** Style for maps that show places and routes (not the driving view). */
export function useMapStyle() {
  return mapStyleFor(useSatellite());
}
