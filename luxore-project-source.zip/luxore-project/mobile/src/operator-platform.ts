// Betreiberplattform in der Fahrer-App: Einnahmen, Prüfstatus, Wochenkontrolle,
// Flotten-Abrechnung und Sperren. Reine Logik ohne React Native, damit Tests
// sie direkt laden können. Gerechnet wird ausschließlich auf dem Server; hier
// wird nur gelesen, geprüft und für die Anzeige aufbereitet.

export const featurePendingText =
  'Diese Funktion wird mit dem nächsten Server-Update freigeschaltet.';
export const settlementNotice =
  'Abrechnungsübersicht – keine Rechnung im steuerlichen Sinn';

/** Zustand einer Ansicht, die Daten einer neuen Server-Route zeigt. */
export type Loaded<T> =
  | { kind: 'loading' }
  | { kind: 'ready'; data: T }
  /** Der (ältere) Server kennt die Route noch nicht. */
  | { kind: 'pending' }
  | { kind: 'error'; message: string };

export const isRouteMissing = (error: unknown) =>
  !!error && (error as { routeMissing?: unknown }).routeMissing === true;
const isAbort = (error: unknown) =>
  !!error && (error as { name?: unknown }).name === 'AbortError';

/**
 * Liest eine Route der Betreiberplattform. Fehlt sie auf dem Server, ist das
 * kein Fehler, sondern der ruhige Zustand „wird freigeschaltet“. Eine Antwort
 * in unerwarteter Form wird nie angezeigt.
 */
export async function loadFeature<T>(
  read: () => Promise<unknown>,
  valid: (value: unknown) => value is T,
): Promise<Loaded<T>> {
  try {
    const value = await read();
    return valid(value)
      ? { kind: 'ready', data: value }
      : {
          kind: 'error',
          message:
            'Die Antwort des Servers konnte nicht gelesen werden. Bitte erneut versuchen.',
        };
  } catch (error) {
    if (isAbort(error)) throw error;
    if (isRouteMissing(error)) return { kind: 'pending' };
    return {
      kind: 'error',
      message:
        (error as Error)?.message || 'Anfrage fehlgeschlagen. Bitte erneut versuchen.',
    };
  }
}
/** Meldung nach einem Schreibversuch; fehlende Route bleibt ruhig. */
export const writeErrorText = (error: unknown) =>
  isRouteMissing(error)
    ? featurePendingText
    : (error as Error)?.message || 'Speichern fehlgeschlagen. Bitte erneut versuchen.';

const record = (value: unknown): value is Record<string, unknown> =>
  !!value && typeof value === 'object' && !Array.isArray(value);
const list = (value: unknown): value is unknown[] => Array.isArray(value);
const amount = (value: unknown): value is number =>
  typeof value === 'number' && Number.isFinite(value);
const strings = (value: unknown): value is string[] =>
  list(value) && value.every((item) => typeof item === 'string');

// ---------------------------------------------------------------- Anzeige --

export const euros = (cents: number) =>
  (cents / 100).toLocaleString('de-DE', { style: 'currency', currency: 'EUR' });
export const tripCount = (trips: number) =>
  `${trips} ${trips === 1 ? 'Fahrt' : 'Fahrten'}`;
const serviceNames: Record<string, string> = {
  premium: 'Business Class',
  electric: 'Electric Class',
  van: 'First Class Van',
  first: 'First Class',
};
export const serviceName = (id: string) => serviceNames[id] || id;
export const methodName = (method: 'cash' | 'terminal' | null) =>
  method === 'cash' ? 'Bar' : method === 'terminal' ? 'Terminal' : 'noch offen';
export const germanDate = (date: string | null) =>
  date ? date.split('-').reverse().join('.') : '';

const berlin = (options: Intl.DateTimeFormatOptions) => {
  try {
    return new Intl.DateTimeFormat('de-DE', {
      timeZone: 'Europe/Berlin',
      ...options,
    });
  } catch {
    return null;
  }
};
const stampFormat = berlin({
  weekday: 'short',
  day: '2-digit',
  month: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
});
const dayFormat = berlin({ day: '2-digit', month: '2-digit' });
const dayYearFormat = berlin({ day: '2-digit', month: '2-digit', year: 'numeric' });
const whenFormat = berlin({ dateStyle: 'short', timeStyle: 'short' });
const format = (formatter: Intl.DateTimeFormat | null, at: number) => {
  try {
    if (formatter) return formatter.format(at);
  } catch {}
  return new Date(at).toISOString().slice(0, 16).replace('T', ' ');
};
/** „Mo., 16.11., 14:05“ in Frankfurter Zeit. */
export const tripStamp = (at: number) => format(stampFormat, at);
export const when = (at: number) => format(whenFormat, at);
/** Montag bis Sonntag; `end` ist der Beginn der Folgewoche. */
export const weekLabel = (start: number, end: number) =>
  `${format(dayFormat, start)} – ${format(dayYearFormat, end - 1)}`;
const months = [
  'Januar',
  'Februar',
  'März',
  'April',
  'Mai',
  'Juni',
  'Juli',
  'August',
  'September',
  'Oktober',
  'November',
  'Dezember',
];
export const monthLabel = (month: string) =>
  `${months[Number(month.slice(5, 7)) - 1] || month} ${month.slice(0, 4)}`;

// -------------------------------------------------------- Meine Einnahmen --

export type Period = 'today' | 'week' | 'month';
export const periodLabels: Record<Period, string> = {
  today: 'Heute',
  week: 'Diese Woche',
  month: 'Dieser Monat',
};
export const periods = Object.keys(periodLabels) as Period[];
export type EarningsTotals = {
  trips: number;
  total: number;
  cash: number;
  terminal: number;
  open: number;
};
export type EarningsRide = {
  id: string;
  completedAt: number;
  service: string;
  from: string;
  to: string;
  price: number;
  extras: number;
  method: 'cash' | 'terminal' | null;
};
export type Earnings = {
  periods: Record<Period, EarningsTotals>;
  since: Record<Period, number>;
  rides: EarningsRide[];
};
const totals = (value: unknown): value is EarningsTotals =>
  record(value) &&
  amount(value.trips) &&
  amount(value.total) &&
  amount(value.cash) &&
  amount(value.terminal) &&
  amount(value.open);
export function isEarnings(value: unknown): value is Earnings {
  if (!record(value) || !record(value.periods) || !record(value.since))
    return false;
  const p = value.periods,
    s = value.since;
  return (
    periods.every((key) => totals(p[key]) && amount(s[key])) &&
    list(value.rides) &&
    value.rides.every(
      (ride) =>
        record(ride) &&
        typeof ride.id === 'string' &&
        amount(ride.completedAt) &&
        amount(ride.price),
    )
  );
}
export const ridesIn = (data: Earnings, period: Period) =>
  data.rides.filter((ride) => ride.completedAt >= data.since[period]);
/** „Hauptbahnhof → Flughafen“; fehlt ein Ort, steht nur der andere da. */
export const routeLine = (from: string, to: string) =>
  [from, to].filter(Boolean).join(' → ') || 'Fahrt';
export const rideDetail = (ride: EarningsRide) =>
  [
    tripStamp(ride.completedAt),
    serviceName(ride.service),
    methodName(ride.method),
    ...(ride.extras ? [`davon Bordprodukte ${euros(ride.extras)}`] : []),
  ].join(' · ');

// ------------------------------------------------------------ Prüfstatus --

export type PaperState = {
  kind: string;
  label: string;
  required: boolean;
  state: 'missing' | 'submitted' | 'rejected' | 'approved' | 'expired';
  expiresOn: string | null;
  daysLeft: number | null;
  reason: string | null;
};
export type InspectionState = {
  lastPassedAt: number | null;
  dueAt: number | null;
  state: 'ok' | 'due' | 'never';
  daysLeft: number | null;
  latestResult: 'ok' | 'defect' | null;
  latestAt: number | null;
};
export type DriverCompliance = {
  enforcedSince: number | null;
  holds: string[];
  requirements: string[];
  warnings: string[];
  vehicle: { id: string; plate: string } | null;
  inspection: InspectionState | null;
};
export type OwnCompliance = {
  enforcedSince: number | null;
  driver: DriverCompliance | null;
  papers: PaperState[];
};
const paper = (value: unknown): value is PaperState =>
  record(value) &&
  typeof value.kind === 'string' &&
  typeof value.label === 'string' &&
  typeof value.state === 'string';
const papers = (value: unknown): value is PaperState[] =>
  list(value) && value.every(paper);
const inspection = (value: unknown): value is InspectionState =>
  record(value) && typeof value.state === 'string';
export function isOwnCompliance(value: unknown): value is OwnCompliance {
  if (!record(value) || !('driver' in value)) return false;
  const driver = value.driver;
  return (
    (driver === null ||
      (record(driver) &&
        strings(driver.holds) &&
        strings(driver.requirements) &&
        strings(driver.warnings) &&
        (driver.inspection == null || inspection(driver.inspection)))) &&
    (value.papers === undefined || papers(value.papers))
  );
}
export type Chip = { tone: 'success' | 'gold' | 'danger' | 'neutral'; text: string };
const days = (count: number) => `${count} ${count === 1 ? 'Tag' : 'Tagen'}`;
export function paperChip(p: PaperState): Chip {
  if (p.state === 'approved') {
    const soon = p.daysLeft !== null && p.daysLeft <= 14;
    return {
      tone: soon ? 'gold' : 'success',
      text: soon
        ? p.daysLeft === 0
          ? 'läuft heute ab'
          : `läuft in ${days(p.daysLeft!)} ab`
        : p.expiresOn
          ? 'geprüft · bis ' + germanDate(p.expiresOn)
          : 'geprüft',
    };
  }
  if (p.state === 'submitted') return { tone: 'gold', text: 'wird geprüft' };
  if (p.state === 'rejected') return { tone: 'danger', text: 'abgelehnt' };
  if (p.state === 'expired')
    return { tone: 'danger', text: 'abgelaufen am ' + germanDate(p.expiresOn) };
  return p.required
    ? { tone: 'danger', text: 'fehlt' }
    : { tone: 'neutral', text: 'freiwillig' };
}
export function inspectionChip(s: InspectionState): Chip {
  if (s.state === 'never') return { tone: 'danger', text: 'Kontrolle fehlt' };
  if (s.state === 'due') return { tone: 'danger', text: 'Kontrolle fällig' };
  return s.daysLeft !== null && s.daysLeft < 3
    ? {
        tone: 'gold',
        text:
          s.daysLeft === 0
            ? 'Kontrolle heute fällig'
            : `Kontrolle in ${days(s.daysLeft)} fällig`,
      }
    : { tone: 'success', text: 'Kontrolle gültig' };
}
export const openPapers = (items: PaperState[]) =>
  items.filter((p) => p.required && p.state !== 'approved').length;
export const openPapersText = (count: number) =>
  count ? `${count} Papier${count === 1 ? '' : 'e'} offen` : 'Papiere geprüft';

/**
 * Was der Fahrer vor der Schicht wissen muss. `stops` verhindern das
 * Online-Gehen (Sperren immer; fehlende Papiere/Kontrolle nur bei aktiver
 * Prüfpflicht), `hints` sind Hinweise.
 */
export function readiness(data: OwnCompliance) {
  const d = data.driver;
  const enforced = !!data.enforcedSince;
  const stops = d ? [...d.holds, ...(enforced ? d.requirements : [])] : [];
  const hints = d ? [...(enforced ? [] : d.requirements), ...d.warnings] : [];
  return {
    registered: !!d,
    enforced,
    stops,
    hints,
    hintTitle: enforced ? 'Bitte bald erledigen' : 'Bitte erledigen',
    ok: !!d && !stops.length && !hints.length,
    vehicle: d?.vehicle || null,
    inspection: d?.inspection || null,
  };
}

const refusalMarker = 'Online gehen ist gerade nicht möglich:';
/**
 * Zerlegt die Ablehnung des Servers beim Online-Gehen in ihre Gründe
 * („… nicht möglich: A · B.“). `null`, wenn es eine andere Meldung ist.
 */
export function shiftRefusal(message: string): string[] | null {
  const at = message.indexOf(refusalMarker);
  if (at < 0) return null;
  const reasons = message
    .slice(at + refusalMarker.length)
    .trim()
    .replace(/\.$/, '')
    .split(' · ')
    .map((reason) => reason.trim())
    .filter(Boolean);
  return reasons.length ? reasons : null;
}
export const refusalTitle = 'Online gehen ist gerade nicht möglich';

// ---------------------------------------------------------- Wochenkontrolle --

/** Wortgleich mit dem Server; dessen Liste hat Vorrang, wenn er sie liefert. */
export const inspectionItems: Record<string, string> = {
  front: 'Außen vorne',
  rear: 'Außen hinten',
  left: 'Außen links',
  right: 'Außen rechts',
  clean: 'Innenraum sauber',
  equipment: 'Ausstattung vollständig',
  tires: 'Reifen',
  lights: 'Licht',
};
export type CheckItem = { ok: boolean; note: string };
export type CheckDraft = Record<string, CheckItem | undefined>;
export type InspectionHistory = {
  id: string;
  inspectorName: string;
  result: 'ok' | 'defect';
  items: Record<string, CheckItem>;
  odometer: number | null;
  createdAt: number;
};
export type VehicleCheck = {
  vehicle: { id: string; model: string; plate: string };
  state: InspectionState;
  items: Record<string, string>;
  inspections: InspectionHistory[];
};
export function isVehicleCheck(value: unknown): value is VehicleCheck {
  return (
    record(value) &&
    record(value.vehicle) &&
    typeof value.vehicle.id === 'string' &&
    inspection(value.state) &&
    record(value.items) &&
    list(value.inspections)
  );
}
/** Dieselben Regeln wie der Server, damit der Fahrer sofort Bescheid weiß. */
export function checkProblem(
  labels: Record<string, string>,
  draft: CheckDraft,
  odometer: string,
): string | null {
  for (const [key, label] of Object.entries(labels)) {
    const item = draft[key];
    if (!item) return `Bitte „${label}“ als in Ordnung oder Mangel markieren.`;
    if (!item.ok && !item.note.trim())
      return `Bitte den Mangel bei „${label}“ kurz beschreiben.`;
  }
  const km = odometer.trim();
  if (km && (!/^\d{1,7}$/.test(km) || Number(km) > 5_000_000))
    return 'Bitte einen gültigen Kilometerstand angeben.';
  return null;
}
export function checkBody(
  vehicleId: string,
  labels: Record<string, string>,
  draft: CheckDraft,
  odometer: string,
) {
  const items: Record<string, CheckItem> = {};
  for (const key of Object.keys(labels)) {
    const item = draft[key]!;
    items[key] = { ok: item.ok, note: item.ok ? '' : item.note.trim().slice(0, 200) };
  }
  const km = odometer.trim();
  return {
    action: 'create',
    vehicleId,
    items,
    ...(km ? { odometer: Number(km) } : {}),
  };
}
export const checkResultText = (result: unknown) =>
  result === 'defect'
    ? 'Kontrolle gespeichert – mit Mangel. Die Flottenleitung sieht den Mangel. Nur eine Kontrolle ohne Mangel zählt als bestanden.'
    : 'Kontrolle ohne Mangel gespeichert. Sie gilt 7 Tage.';

// ------------------------------------------------- Flotte: Einnahmen/Woche --

export type Totals = {
  trips: number;
  revenue: number;
  fee: number;
  net: number;
  cash: number;
  terminal: number;
};
export type WeekSummary = Totals & {
  week: string;
  start: number;
  end: number;
  status: 'open' | 'paid';
  paidAt: number | null;
  closed: boolean;
};
export type FleetIncome = {
  notice?: string;
  fleet: { id: string; name: string };
  weeks: WeekSummary[];
  months: (Totals & { month: string })[];
  openFee: number;
  currentFee: number;
  /** Satz der Flotte in Basispunkten; ältere Server senden ihn nicht. */
  rateBps?: number;
};
/** „15“, „12,5“, „0“ – ohne Angabe der Standardsatz. */
export const feePercent = (bps: unknown) =>
  String(
    (typeof bps === 'number' && Number.isFinite(bps) && bps >= 0 ? bps : 1500) /
      100,
  ).replace('.', ',');
export type SettledTrip = {
  id: string;
  completedAt: number;
  service: string;
  from: string;
  to: string;
  fare: number;
  method: 'cash' | 'terminal';
  fee: number;
};
export type WeekStatement = {
  notice?: string;
  week: string;
  status: 'open' | 'paid';
  paidAt: number | null;
  closed: boolean;
  statement: Totals & {
    rateBps?: number;
    fleetName: string;
    start: number;
    end: number;
    drivers: (Totals & { driverId: string; name: string; rides: SettledTrip[] })[];
  };
};
const sums = (value: unknown): value is Record<string, unknown> =>
  record(value) &&
  amount(value.trips) &&
  amount(value.revenue) &&
  amount(value.fee) &&
  amount(value.net);
export function isFleetIncome(value: unknown): value is FleetIncome {
  return (
    record(value) &&
    record(value.fleet) &&
    typeof value.fleet.id === 'string' &&
    amount(value.openFee) &&
    amount(value.currentFee) &&
    list(value.weeks) &&
    value.weeks.every(
      (w) => sums(w) && typeof w.week === 'string' && amount(w.start) && amount(w.end),
    ) &&
    list(value.months) &&
    value.months.every((m) => sums(m) && typeof m.month === 'string')
  );
}
export function isWeekStatement(value: unknown): value is WeekStatement {
  if (!record(value) || typeof value.week !== 'string') return false;
  const s = value.statement;
  return (
    sums(s) &&
    list(s.drivers) &&
    s.drivers.every((d) => sums(d) && record(d) && list(d.rides))
  );
}
export function weekChip(w: {
  status: string;
  closed: boolean;
  fee: number;
}): Chip {
  if (w.status === 'paid') return { tone: 'success', text: 'bezahlt' };
  if (!w.closed) return { tone: 'neutral', text: 'läuft' };
  return w.fee
    ? { tone: 'gold', text: 'offen' }
    : { tone: 'neutral', text: 'keine Fahrten' };
}
/** Montag einer anderen Woche (`YYYY-MM-DD`), ohne Zeitzonenfehler. */
export function shiftWeek(week: string, days: number) {
  const at = new Date(week + 'T12:00:00Z');
  at.setUTCDate(at.getUTCDate() + days);
  return at.toISOString().slice(0, 10);
}
export const totalsLine = (t: Totals) =>
  `${tripCount(t.trips)} · Umsatz ${euros(t.revenue)} · Pauschale ${euros(t.fee)} · Rest ${euros(t.net)}`;
export const settledTripDetail = (r: SettledTrip) =>
  `${tripStamp(r.completedAt)} · ${serviceName(r.service)} · ${r.method === 'terminal' ? 'Terminal' : 'Bar'} · Pauschale ${euros(r.fee)}`;

// ----------------------------------------------------- Flotte: Prüfung/Sperre --

export type SubjectType = 'driver' | 'vehicle' | 'fleet';
export type Hold = {
  id: string;
  level: 'operator' | 'fleet';
  reason: string;
  by: string;
  at: number;
};
export type FleetCompliance = {
  enforcedSince: number | null;
  /** true = Betreiber; sonst Besitzer oder Stellvertreter der Flotte. */
  operator: boolean;
  fleet: { id: string; name: string; papers: PaperState[]; suspensions: Hold[] };
  vehicles: {
    id: string;
    model: string;
    plate: string;
    papers: PaperState[];
    inspection: InspectionState;
    suspensions: Hold[];
  }[];
  drivers: {
    id: string;
    name: string;
    approved: number;
    papers: PaperState[];
    suspensions: Hold[];
  }[];
};
const holds = (value: unknown): value is Hold[] =>
  list(value) &&
  value.every(
    (h) => record(h) && typeof h.id === 'string' && typeof h.reason === 'string',
  );
const subject = (value: unknown) =>
  record(value) &&
  typeof value.id === 'string' &&
  papers(value.papers) &&
  holds(value.suspensions);
export function isFleetCompliance(value: unknown): value is FleetCompliance {
  return (
    record(value) &&
    subject(value.fleet) &&
    list(value.vehicles) &&
    value.vehicles.every(
      (v) => subject(v) && inspection((v as Record<string, unknown>).inspection),
    ) &&
    list(value.drivers) &&
    value.drivers.every(subject)
  );
}
export const holdBy = (level: string) =>
  level === 'operator' ? 'den Betreiber' : 'die Flottenleitung';
/**
 * Was die Leitung an einem Fahrer oder Fahrzeug tun darf. Der Server prüft
 * dasselbe noch einmal: Die Leitung hebt keine Sperre des Betreibers auf, und
 * eine ganze Flotte setzt nur der Betreiber aus.
 */
export function holdActions(
  subjectType: SubjectType,
  list: Hold[],
  operator: boolean,
) {
  const own = operator ? 'operator' : 'fleet';
  return {
    canSuspend:
      (operator || subjectType !== 'fleet') &&
      !list.some((h) => h.level === own),
    liftable: list.filter((h) => operator || h.level === 'fleet').map((h) => h.id),
  };
}
export function suspendProblem(reason: string): string | null {
  const text = reason.trim();
  if (!text) return 'Bitte einen Grund angeben.';
  if (text.length > 200) return 'Der Grund darf höchstens 200 Zeichen haben.';
  return null;
}
export const suspendBody = (
  subjectType: SubjectType,
  subjectId: string,
  reason: string,
) => ({ action: 'suspend', subjectType, subjectId, reason: reason.trim() });
export const liftBody = (id: string) => ({ action: 'lift', id });
export type SuspensionHistory = {
  id: string;
  subject_type: SubjectType;
  subject_name: string | null;
  level: string;
  reason: string;
  created_by_name: string;
  created_at: number;
  lifted_by_name: string | null;
  lifted_at: number | null;
};
export const isSuspensionList = (
  value: unknown,
): value is { suspensions: SuspensionHistory[] } =>
  record(value) && list(value.suspensions);
export const subjectName = (type: SubjectType) =>
  type === 'driver' ? 'Fahrer' : type === 'vehicle' ? 'Fahrzeug' : 'Flotte';
export const historyDetail = (h: SuspensionHistory) =>
  `${h.reason} · ausgesetzt von ${h.created_by_name} (${h.level === 'operator' ? 'Betreiber' : 'Flottenleitung'}) am ${when(h.created_at)}` +
  (h.lifted_at ? ` · freigegeben von ${h.lifted_by_name} am ${when(h.lifted_at)}` : '');
/**
 * Einträge „Einnahmen“ und „Prüfung“ nur für Betreiber, Besitzer und
 * Stellvertreter der gewählten Flotte. Der Server lehnt alle anderen ab.
 */
export function leadsFleet(
  fleet: { owner_id?: string | null; deputy_id?: string | null } | undefined,
  userId: string | undefined,
  canManage: boolean,
) {
  return (
    !!fleet &&
    (canManage || (!!userId && (fleet.owner_id === userId || fleet.deputy_id === userId)))
  );
}

// ------------------------------------------------------- Fotos (Web-Ansicht) --

/**
 * Fotos lädt die eingebettete Web-Ansicht hoch (Dateiauswahl der Webseite).
 * Ziele sind genau die, die die Sitzungsübergabe des Servers kennt.
 */
export type PhotoTarget = 'driver' | 'fleet';
export const photoTargets: Record<
  PhotoTarget,
  { path: '/pruefung'; title: string; hint: string }
> = {
  driver: {
    path: '/pruefung',
    title: 'Fotos hochladen',
    hint: 'Hier lädst du Fotos für deine Papiere und die Wochenkontrolle hoch. Kamera oder Galerie wählst du beim Antippen eines Fotofelds.',
  },
  fleet: {
    path: '/pruefung',
    title: 'Fotos hochladen',
    hint: 'Hier lädst du Papiere und Kontrollfotos für Fahrzeuge, Fahrer und Flotte hoch. Kamera oder Galerie wählst du beim Antippen eines Fotofelds.',
  },
};
