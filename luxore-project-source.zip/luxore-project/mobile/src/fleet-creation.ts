import type { Fleet } from '../../lib/mobility/domain';
import type { TeamMember } from './operations';
export type FleetCreateRequest = {
  action: 'create';
  requestId: string;
  name: string;
  ownerId: string;
};
export type FleetCreateStore = {
  load(): Promise<FleetCreateRequest | null>;
  save(value: FleetCreateRequest): Promise<void>;
  clear(requestId: string): Promise<void>;
};
export type FleetCreateData = {
  userId: string;
  canManage: boolean;
  fleets: Fleet[];
  employees: TeamMember[];
};
export type FleetCreateState = {
  data: FleetCreateData | null;
  name: string;
  ownerId: string;
  restored: boolean;
  pending: FleetCreateRequest | null;
  busy: boolean;
  loading: boolean;
  updatedAt: number | null;
  error: string;
  loadError: string;
  notice: string;
  confirmed: { id: string; name: string } | null;
  discardable: boolean;
};
export function validFleetRequest(value: unknown): value is FleetCreateRequest {
  const v = value as FleetCreateRequest;
  return (
    !!v &&
    v.action === 'create' &&
    /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(
      v.requestId,
    ) &&
    typeof v.name === 'string' &&
    v.name === v.name.trim() &&
    v.name.length > 0 &&
    v.name.length <= 100 &&
    typeof v.ownerId === 'string' &&
    v.ownerId === v.ownerId.trim() &&
    v.ownerId.length > 0 &&
    v.ownerId.length <= 100
  );
}
export function availableFleetOwners(data: FleetCreateData) {
  const candidates = [...data.employees];
  if (!candidates.some((e) => e.user_id === data.userId))
    candidates.unshift({
      user_id: data.userId,
      name: 'Eigenes Betreiberprofil',
      fleet_id: null,
    });
  return candidates.filter(
    (e) =>
      e.fleet_id === null &&
      e.can_remove !== 0 &&
      !data.fleets.some(
        (f) => f.owner_id === e.user_id || f.deputy_id === e.user_id,
      ),
  );
}
const message = (e: unknown) =>
  e instanceof Error ? e.message : 'Keine Verbindung zur Flotte.';
export class FleetCreationController {
  private state: FleetCreateState = {
    data: null,
    name: '',
    ownerId: '',
    restored: false,
    pending: null,
    busy: false,
    loading: false,
    updatedAt: null,
    error: '',
    loadError: '',
    notice: '',
    confirmed: null,
    discardable: false,
  };
  private listeners = new Set<() => void>();
  private active = false;
  private disposed = false;
  private revision = 0;
  private read: Promise<void> | null = null;
  private abort: AbortController | null = null;
  private restoreTask: Promise<void> | null = null;
  constructor(
    private accountId: string,
    private store: FleetCreateStore,
    private load: (signal: AbortSignal) => Promise<FleetCreateData>,
    private write: (
      body: FleetCreateRequest,
    ) => Promise<{ id: string; name: string }>,
    private uuid: () => string,
  ) {}
  getSnapshot = () => this.state;
  subscribe = (f: () => void) => {
    this.listeners.add(f);
    return () => {
      this.listeners.delete(f);
    };
  };
  private publish(patch: Partial<FleetCreateState>) {
    if (this.disposed) return;
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((f) => f());
  }
  private stopRead() {
    this.abort?.abort();
    this.abort = null;
    this.read = null;
  }
  restore(): Promise<void> {
    if (this.disposed || this.state.restored) return Promise.resolve();
    if (this.restoreTask) return this.restoreTask;
    const task = Promise.resolve().then(async () => {
      try {
        const pending = await this.store.load();
        if (pending && !validFleetRequest(pending))
          throw new Error('Gespeicherte Gründungsanfrage ist unvollständig.');
        this.publish({
          restored: true,
          pending: pending ? { ...pending } : null,
          name: pending?.name || '',
          ownerId: pending?.ownerId || '',
          error: '',
          discardable: false,
        });
      } catch (e) {
        this.publish({ error: message(e) });
      } finally {
        if (this.restoreTask === task) this.restoreTask = null;
      }
    });
    this.restoreTask = task;
    return task;
  }
  setActive(active: boolean) {
    if (this.disposed || this.active === active) return;
    this.active = active;
    this.revision++;
    this.stopRead();
    this.publish({ loading: false });
    if (active) void this.refresh();
  }
  refresh(): Promise<void> {
    if (!this.active || this.disposed || this.state.busy)
      return Promise.resolve();
    if (this.read) return this.read;
    const rev = ++this.revision,
      abort = new AbortController();
    this.abort = abort;
    this.publish({ loading: true });
    const task = Promise.resolve().then(async () => {
      try {
        if (abort.signal.aborted) return;
        const data = await this.load(abort.signal);
        if (rev !== this.revision || !this.active || this.disposed) return;
        if (
          data.userId !== this.accountId ||
          !Array.isArray(data.fleets) ||
          !Array.isArray(data.employees) ||
          data.canManage !== true
        )
          throw Object.assign(
            new Error('Nur der Plattformbetreiber darf Flotten gründen.'),
            { status: 403 },
          );
        this.publish({ data, updatedAt: Date.now(), loadError: '' });
        const pending = this.state.pending,
          fleet =
            pending && data.fleets.find((f) => f.id === pending.requestId);
        if (
          pending &&
          fleet?.name === pending.name &&
          fleet.owner_id === pending.ownerId
        )
          await this.confirm(pending, { id: fleet.id, name: fleet.name }, true);
      } catch (e) {
        if (rev !== this.revision || !this.active || this.disposed) return;
        const status = (e as { status?: number }).status;
        this.publish({
          loadError: message(e),
          updatedAt: null,
          ...(status === 401 || status === 403 ? { data: null } : {}),
        });
      } finally {
        if (this.read === task) {
          this.read = null;
          this.abort = null;
          this.publish({ loading: false });
        }
      }
    });
    this.read = task;
    return task;
  }
  edit(name: string, ownerId: string) {
    if (
      this.disposed ||
      !this.state.restored ||
      this.state.pending ||
      this.state.busy ||
      this.state.confirmed
    )
      return;
    this.publish({ name, ownerId, error: '', notice: '' });
  }
  private fresh(now: number) {
    return (
      this.active &&
      !this.disposed &&
      this.state.restored &&
      !this.state.loading &&
      !this.state.loadError &&
      this.state.data?.canManage === true &&
      this.state.data.userId === this.accountId &&
      this.state.updatedAt !== null &&
      now - this.state.updatedAt < 30000
    );
  }
  canSubmit(now = Date.now()) {
    const s = this.state;
    if (!this.fresh(now) || s.busy || s.confirmed) return false;
    if (s.pending) return true; // Replay only the persisted original body; current guards remain on the server.
    return (
      s.name.trim().length > 0 &&
      s.name.trim().length <= 100 &&
      availableFleetOwners(s.data!).some((e) => e.user_id === s.ownerId)
    );
  }
  async submit() {
    if (!this.canSubmit()) return;
    const pending = this.state.pending || {
      action: 'create' as const,
      requestId: this.uuid(),
      name: this.state.name.trim(),
      ownerId: this.state.ownerId,
    };
    if (!validFleetRequest(pending)) {
      this.publish({ error: 'Ungültige Gründungsanfrage.' });
      return;
    }
    this.revision++;
    this.stopRead();
    this.publish({
      pending: { ...pending },
      name: pending.name,
      busy: true,
      loading: false,
      error: '',
      notice: '',
      discardable: false,
    });
    let sent = false;
    try {
      await this.store.save({ ...pending });
      if (this.disposed) return;
      sent = true;
      const result = await this.write({ ...pending });
      if (result.id !== pending.requestId || result.name !== pending.name)
        throw new Error(
          'Die Gründungsbestätigung ist unvollständig. Bitte den Serverstand prüfen.',
        );
      await this.confirm(pending, result);
    } catch (e) {
      const status = (e as { status?: number }).status;
      this.publish({
        error: message(e),
        discardable: !sent || (!!status && status >= 400 && status < 500),
        ...(status === 401 || status === 403
          ? { data: null, updatedAt: null }
          : {}),
      });
    } finally {
      this.publish({ busy: false });
      if (this.active && !this.disposed) await this.refresh();
    }
  }
  private async confirm(
    pending: FleetCreateRequest,
    result: { id: string; name: string },
    fromRead = false,
  ) {
    this.publish({
      confirmed: { id: result.id, name: result.name },
      updatedAt: fromRead ? this.state.updatedAt : null,
      error: '',
      notice: 'Flotte gegründet.',
      discardable: false,
    });
    try {
      await this.store.clear(pending.requestId);
      this.publish({ pending: null });
    } catch {
      this.publish({
        error:
          'Flotte ist bestätigt. Die offene Geräteanfrage konnte noch nicht abgeschlossen werden. Bitte den Gerätespeicher erneut prüfen.',
      });
    }
  }
  canDiscard(now = Date.now()) {
    return (
      !!this.state.pending &&
      this.state.discardable &&
      !this.state.busy &&
      !!this.fresh(now)
    );
  }
  async discard() {
    if (!this.canDiscard()) return;
    const id = this.state.pending!.requestId;
    this.publish({ busy: true });
    try {
      await this.store.clear(id);
      this.publish({
        pending: null,
        discardable: false,
        error: '',
        notice: 'Geräteanfrage beendet. Bestehende Flotten bleiben erhalten.',
      });
    } catch (e) {
      this.publish({ error: message(e) });
    } finally {
      this.publish({ busy: false });
    }
  }
  async finishConfirmed() {
    if (
      !this.active ||
      this.disposed ||
      this.state.busy ||
      !this.state.confirmed ||
      !this.state.pending
    )
      return;
    const id = this.state.pending.requestId;
    this.publish({ busy: true });
    try {
      await this.store.clear(id);
      this.publish({ pending: null, error: '' });
    } catch (e) {
      this.publish({ error: message(e) });
    } finally {
      this.publish({ busy: false });
    }
  }
  reset() {
    if (!this.active || this.disposed || this.state.busy || this.state.pending)
      return;
    this.publish({
      name: '',
      ownerId: '',
      confirmed: null,
      error: '',
      notice: '',
      discardable: false,
    });
  }
  dispose() {
    this.disposed = true;
    this.active = false;
    this.revision++;
    this.stopRead();
    this.listeners.clear();
  }
}
