import React from 'react';
import { Text, View } from 'react-native';
import type { MapCenter } from './map-point';
export type PointMapProps = {
  token: string;
  active: boolean;
  center: MapCenter;
  locked: boolean;
  onReady: () => void;
  onMoving: () => void;
  onIdle: (center: MapCenter) => void;
  onError: () => void;
};
export default function PointMap(_props: PointMapProps) {
  return (
    <View style={{ flex: 1, justifyContent: 'center', padding: 24 }}>
      <Text>Die native Kartenpunktwahl ist in der Android-App verfügbar.</Text>
    </View>
  );
}
