import React, { useEffect, useState, useSyncExternalStore } from 'react';
import {
  ActivityIndicator,
  AppState,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  CarFront,
  ChevronRight,
  RefreshCw,
  ShieldCheck,
  Users,
  X,
} from 'lucide-react-native';
import { nativeApi } from './account-client';
import { euros } from './driver-model';
import SwipeAction from './SwipeAction';
import {
  approvalBlocked,
  OperationsController,
  type OperationsData,
} from './operations';
import { statusNames, type Booking } from '../../lib/mobility/domain';
export default function OperationsScreen({
  token,
  active,
  onFleet,
}: {
  token: string;
  active: boolean;
  onFleet: () => void;
}) {
  return (
    <Workspace key={token} token={token} active={active} onFleet={onFleet} />
  );
}
function Workspace({
  token,
  active,
  onFleet,
}: {
  token: string;
  active: boolean;
  onFleet: () => void;
}) {
  const [controller] = useState(
    () =>
      new OperationsController(
        async (signal) => {
          const [operations, fleets] = await Promise.all([
            nativeApi<Pick<OperationsData, 'drivers' | 'bookings'>>(
              'operations',
              token,
              undefined,
              undefined,
              signal,
            ),
            nativeApi<Pick<OperationsData, 'fleets' | 'revenue'>>(
              'fleets',
              token,
              undefined,
              { period: 'today' },
              signal,
            ),
          ]);
          return { ...operations, ...fleets };
        },
        (body) => nativeApi('operations', token, body),
      ),
  );
  const state = useSyncExternalStore(
    controller.subscribe,
    controller.getSnapshot,
    controller.getSnapshot,
  );
  const [foreground, setForeground] = useState(
    AppState.currentState === 'active',
  );
  const [selectedFleet, setSelectedFleet] = useState('');
  const [selectedDriver, setSelectedDriver] = useState<string | null>(null);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const sub = AppState.addEventListener('change', (value) =>
      setForeground(value === 'active'),
    );
    return () => sub.remove();
  }, []);
  useEffect(() => {
    controller.setActive(active && foreground);
    if (!active || !foreground) return;
    const poll = setInterval(() => void controller.refresh(), 15000);
    const tick = setInterval(() => setNow(Date.now()), 1000);
    return () => {
      clearInterval(poll);
      clearInterval(tick);
      controller.setActive(false);
    };
  }, [controller, active, foreground]);
  useEffect(() => () => controller.dispose(), [controller]);
  const data = state.data;
  const fleetId = data?.fleets.some((f) => f.id === selectedFleet)
    ? selectedFleet
    : data?.fleets[0]?.id || '';
  const fleet = data?.fleets.find((f) => f.id === fleetId);
  const drivers = data?.drivers.filter((d) => d.fleet_id === fleetId) || [];
  const bookings = data?.bookings.filter((b) => b.fleet_id === fleetId) || [];
  const revenue = data?.revenue.filter((r) => r.fleet_id === fleetId) || [];
  const driver = drivers.find((d) => d.id === selectedDriver);
  const pending =
    state.uncertain?.driverId === driver?.id ? state.uncertain : null;
  const approved = pending ? pending.approved : !driver?.approved;
  const body = { driverId: driver?.id || '', approved };
  const blocked =
    !!driver && !approved && approvalBlocked(driver, data?.bookings || []);
  const connected =
    active &&
    foreground &&
    !state.loadError &&
    state.updatedAt !== null &&
    now - state.updatedAt < 30000;
  return (
    <View style={s.root}>
      <ScrollView
        contentContainerStyle={s.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={s.row}>
          <View style={s.grow}>
            <Text style={s.eyebrow}>DEIN TEAM. DEIN ÜBERBLICK.</Text>
            <Text style={s.title}>Disposition.</Text>
          </View>
          <Pressable
            accessibilityLabel="Disposition aktualisieren"
            disabled={state.refreshing || !!state.changing}
            onPress={() => void controller.refresh()}
            style={s.icon}
          >
            {state.refreshing ? (
              <ActivityIndicator color={gold} />
            ) : (
              <RefreshCw color={gold} size={22} />
            )}
          </Pressable>
        </View>
        <Text style={s.muted}>
          {connected
            ? 'Aktueller Serverstand'
            : data
              ? 'Bekannter Stand · Änderungen pausiert'
              : 'Team und Fahrten deiner Flotte'}
        </Text>
        {!!state.loadError && (
          <Text accessibilityRole="alert" style={s.error}>
            {state.loadError}
          </Text>
        )}
        {!!state.actionError && (
          <Text accessibilityRole="alert" style={s.error}>
            {state.actionError}
          </Text>
        )}
        {!!state.notice && (
          <Text accessibilityRole="alert" style={s.notice}>
            {state.notice}
          </Text>
        )}
        {data && (
          <>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={s.fleetTabs}
            >
              {data.fleets.map((f) => (
                <Pressable
                  key={f.id}
                  accessibilityRole="tab"
                  accessibilityState={{ selected: f.id === fleetId }}
                  onPress={() => {
                    setSelectedFleet(f.id);
                    setSelectedDriver(null);
                  }}
                  style={[s.fleetTab, f.id === fleetId && s.fleetActive]}
                >
                  <Text
                    style={[s.fleetName, f.id === fleetId && { color: '#fff' }]}
                  >
                    {f.name}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
            <View style={s.revenue}>
              <Text style={s.heroLabel}>
                TAGESUMSATZ · {fleet?.name || 'KEINE FLOTTE'}
              </Text>
              <Text style={s.amount}>
                {euros(revenue.reduce((sum, r) => sum + r.gross, 0))}
              </Text>
              <View style={s.row}>
                <Text style={s.heroDetail}>
                  {revenue.reduce((sum, r) => sum + r.trips, 0)} abgeschlossene
                  Fahrten
                </Text>
                <Text style={s.heroDetail}>
                  Offen{' '}
                  {euros(revenue.reduce((sum, r) => sum + r.outstanding, 0))}
                </Text>
              </View>
            </View>
            <View style={s.row}>
              <Text style={s.section}>Fahrer & Freigaben</Text>
              <Text style={s.muted}>{drivers.length} Profile</Text>
            </View>
            {drivers.map((d) => (
              <Pressable
                key={d.id}
                accessibilityRole="button"
                accessibilityLabel={`Fahrer ${d.name || 'Ohne Namen'} öffnen`}
                style={s.person}
                onPress={() => setSelectedDriver(d.id)}
              >
                <View style={s.avatar}>
                  <Users size={22} color={gold} />
                </View>
                <View style={s.grow}>
                  <Text style={s.name}>
                    {d.name || 'Profil vervollständigen'}
                  </Text>
                  <Text style={s.muted}>
                    {d.id === fleet?.owner_id
                      ? 'Flottenbesitzer'
                      : d.id === fleet?.deputy_id
                        ? 'Stellvertretung'
                        : 'Fahrer'}{' '}
                    · {d.plate || 'Kein Fahrzeug'}
                  </Text>
                  <Text style={[s.status, !d.approved && { color: gold }]}>
                    {d.approved
                      ? d.online
                        ? 'Online'
                        : 'Freigegeben · offline'
                      : 'Freigabe ausstehend'}
                  </Text>
                </View>
                <ChevronRight size={20} color="#8d9298" />
              </Pressable>
            ))}
            {!drivers.length && (
              <Text style={s.empty}>
                Noch keine Fahrerprofile in dieser Flotte.
              </Text>
            )}
            <Pressable
              style={s.link}
              accessibilityRole="button"
              onPress={onFleet}
            >
              <CarFront color={gold} size={23} />
              <View style={s.grow}>
                <Text style={s.name}>Fahrzeuge & Flotte</Text>
                <Text style={s.muted}>
                  Fahrzeuge hinzufügen, bearbeiten und wechseln
                </Text>
              </View>
              <ChevronRight color={gold} size={20} />
            </Pressable>
            <Text style={s.section}>Aktuelle Fahrten</Text>
            {bookings
              .filter((b) =>
                [
                  'requesting',
                  'accepted',
                  'arrived',
                  'riding',
                  'reserved',
                ].includes(b.status),
              )
              .map((b) => (
                <Trip key={b.id} booking={b} />
              ))}
            {!bookings.some((b) =>
              [
                'requesting',
                'accepted',
                'arrived',
                'riding',
                'reserved',
              ].includes(b.status),
            ) && (
              <Text style={s.empty}>
                Aktuell keine Anfragen oder Reservierungen.
              </Text>
            )}
            {(data.drivers.length >= 200 || data.bookings.length >= 200) && (
              <Text style={s.muted}>
                Die Übersicht enthält die vom Server gelieferten bis zu 200
                Profile und jüngsten 200 Fahrten. Ältere Einträge sind hier
                nicht vollständig enthalten.
              </Text>
            )}
          </>
        )}
        {!data && !state.loadError && (
          <ActivityIndicator color={gold} style={{ margin: 30 }} />
        )}
        {!data && !!state.loadError && (
          <Pressable
            onPress={() => void controller.refresh()}
            style={s.link}
            accessibilityRole="button"
          >
            <Text style={s.name}>Erneut laden</Text>
          </Pressable>
        )}
      </ScrollView>
      <Modal
        visible={!!driver && active}
        animationType="slide"
        presentationStyle="fullScreen"
        onRequestClose={() => setSelectedDriver(null)}
      >
        <SafeAreaView style={s.root} edges={['top', 'bottom']}>
          <View style={s.modalHeader}>
            <Text style={s.section}>Fahrerprofil</Text>
            <Pressable
              accessibilityLabel="Fahrerprofil schließen"
              onPress={() => setSelectedDriver(null)}
              hitSlop={12}
            >
              <X size={24} color={ink} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={s.content}>
            <ShieldCheck size={40} color={gold} />
            <Text style={s.title}>{driver?.name || 'Fahrer'}</Text>
            <Text style={s.muted}>{fleet?.name}</Text>
            <Text style={s.section}>Fahrzeug</Text>
            <Text style={s.name}>
              {driver?.vehicle || 'Noch nicht gewählt'}
            </Text>
            <Text style={s.muted}>{driver?.plate || 'Kein Kennzeichen'}</Text>
            <Text style={s.section}>Telefon</Text>
            <Text style={s.name}>{driver?.phone || 'Noch nicht ergänzt'}</Text>
            <Text style={s.section}>Freigabe</Text>
            <Text style={s.muted}>
              {driver?.approved
                ? 'Dieser Fahrer ist freigegeben.'
                : 'Prüfe das Fahrerprofil vor der Freigabe.'}
            </Text>
            {blocked && (
              <Text style={s.error}>
                Rücknahme erst nach beendeter Schicht, abgeschlossener Fahrt und
                bestätigter Zahlung möglich.
              </Text>
            )}
            {!!pending && (
              <Text style={s.error}>
                Die Speicherantwort fehlt. Aktuellen Stand neu laden oder
                dieselbe Änderung erneut bestätigen. Andere Änderungen bleiben
                bis zur Klärung gesperrt.
              </Text>
            )}
            {!!state.actionError && (
              <Text accessibilityRole="alert" style={s.error}>
                {state.actionError}
              </Text>
            )}
            {!!state.notice && (
              <Text accessibilityRole="alert" style={s.notice}>
                {state.notice}
              </Text>
            )}
          </ScrollView>
          <View style={s.footer}>
            <Text style={s.muted}>
              {connected
                ? 'Der Server prüft Flottenrechte und Einsatzstatus erneut.'
                : 'Zum Ändern zuerst die Verbindung wiederherstellen.'}
            </Text>
            <SwipeAction
              key={`${driver?.id}:${approved}:${!!pending}`}
              label={
                pending
                  ? 'Gleiche Änderung erneut bestätigen'
                  : approved
                    ? 'Fahrer freigeben'
                    : 'Freigabe zurücknehmen'
              }
              disabled={!connected || !controller.canChange(body, now)}
              busy={!!state.changing}
              onComplete={() => void controller.approve(body)}
            />
          </View>
        </SafeAreaView>
      </Modal>
    </View>
  );
}
function Trip({ booking: b }: { booking: Booking }) {
  return (
    <View style={s.trip}>
      <Text style={s.status}>{statusNames[b.status]}</Text>
      <Text style={s.name} numberOfLines={2}>
        {b.route.pickup.label}
      </Text>
      <Text style={s.muted} numberOfLines={2}>
        → {b.route.destination.label}
      </Text>
      <View style={s.row}>
        <Text style={s.muted}>
          {b.driver?.name || 'Noch kein Fahrer'}
          {b.scheduled_at
            ? ' · ' +
              new Date(b.scheduled_at).toLocaleString('de-DE', {
                timeZone: 'Europe/Berlin',
                day: '2-digit',
                month: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
              })
            : ''}
        </Text>
        <Text style={s.name}>{euros(b.price)}</Text>
      </View>
    </View>
  );
}
const ink = '#161a20',
  gold = '#aa8345';
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  content: { padding: 22, gap: 16, paddingBottom: 30 },
  grow: { flex: 1, minWidth: 0 },
  row: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
  },
  eyebrow: { color: gold, fontSize: 10, fontWeight: '700', letterSpacing: 1.5 },
  title: { color: ink, fontSize: 32, fontWeight: '700', marginTop: 8 },
  muted: { color: '#777e87', fontSize: 13, lineHeight: 20 },
  icon: { padding: 12 },
  fleetTabs: { gap: 8, paddingVertical: 5 },
  fleetTab: {
    borderRadius: 23,
    paddingHorizontal: 17,
    paddingVertical: 12,
    backgroundColor: '#f8f5ef',
  },
  fleetActive: { backgroundColor: ink },
  fleetName: { color: ink, fontWeight: '600', fontSize: 13 },
  revenue: { padding: 23, gap: 16, borderRadius: 26, backgroundColor: ink },
  heroLabel: {
    color: '#d7bd89',
    fontWeight: '600',
    letterSpacing: 1,
    fontSize: 10,
  },
  amount: { color: '#fff', fontSize: 37, fontWeight: '600' },
  heroDetail: { color: '#d8dadd', fontSize: 12 },
  section: { color: ink, fontSize: 19, fontWeight: '600', marginTop: 12 },
  person: {
    flexDirection: 'row',
    gap: 14,
    alignItems: 'center',
    paddingVertical: 14,
  },
  avatar: {
    width: 46,
    height: 46,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 23,
    backgroundColor: '#fbf7ef',
  },
  name: { color: ink, fontSize: 15, fontWeight: '600', lineHeight: 22 },
  status: { color: '#347961', fontSize: 12, fontWeight: '600', marginTop: 5 },
  link: {
    flexDirection: 'row',
    gap: 14,
    alignItems: 'center',
    padding: 19,
    borderRadius: 21,
    backgroundColor: '#fbf8f2',
  },
  trip: { paddingVertical: 14, gap: 9 },
  empty: { color: '#777e87', paddingVertical: 15, lineHeight: 22 },
  error: { color: '#a04c40', fontSize: 13, lineHeight: 21 },
  notice: { color: '#347961', fontSize: 13, lineHeight: 21 },
  modalHeader: {
    paddingHorizontal: 22,
    paddingVertical: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  footer: { padding: 22, gap: 14, backgroundColor: '#fff' },
});
