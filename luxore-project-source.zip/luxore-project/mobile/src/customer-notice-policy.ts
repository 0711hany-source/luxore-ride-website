// Which ride notice the customer gets at which change of the ride.
// Pure logic without React Native imports (tested in
// tests/customer-notices.test.mjs); the device side is customer-notices.ts.
export type NoticeEvent =
  | 'accepted'
  | 'near'
  | 'arrived'
  | 'riding'
  | 'completed'
  | 'unavailable'
  | 'cancelled';
export type NoticeSnapshot = { id: string; status: string; near: boolean };
export type NoticeSeen = Record<string, NoticeEvent[]>;
type LatLng = { lat: number; lng: number };
/** Beeline chauffeur → pickup point below which "gleich da" is announced. */
export const NEAR_METERS = 900;
const KEPT_RIDES = 12;
const finite = (p: LatLng | null | undefined): p is LatLng =>
  !!p &&
  Number.isFinite(p.lat) &&
  Number.isFinite(p.lng) &&
  Math.abs(p.lat) <= 90 &&
  Math.abs(p.lng) <= 180;
export function beelineMeters(a: LatLng, b: LatLng) {
  const rad = Math.PI / 180,
    dLat = (b.lat - a.lat) * rad,
    dLng = (b.lng - a.lng) * rad,
    h =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLng / 2) ** 2;
  return 2 * 6371000 * Math.asin(Math.min(1, Math.sqrt(h)));
}
/** Only with a real, fresh position of the assigned chauffeur. */
export function chauffeurNear(
  status: string,
  driver: LatLng | null | undefined,
  pickup: LatLng | null | undefined,
) {
  return (
    status === 'accepted' &&
    finite(driver) &&
    finite(pickup) &&
    beelineMeters(driver, pickup) < NEAR_METERS
  );
}
/** Everything that has already happened once a ride shows this state. */
export function impliedEvents(snapshot: NoticeSnapshot): NoticeEvent[] {
  switch (snapshot.status) {
    case 'accepted':
      return snapshot.near ? ['accepted', 'near'] : ['accepted'];
    case 'arrived':
      return ['accepted', 'near', 'arrived'];
    case 'riding':
      return ['accepted', 'near', 'arrived', 'riding'];
    case 'completed':
      return ['accepted', 'near', 'arrived', 'riding', 'completed'];
    case 'unavailable':
      return ['unavailable'];
    case 'cancelled':
      return ['cancelled'];
    default:
      return [];
  }
}
/**
 * One step of the ride as the app sees it.
 * - First sight of a ride (app or live view just opened): nothing is announced;
 *   what has already happened counts as known.
 * - Afterwards: the newest event that has not been announced yet, exactly once.
 *   Skipped steps (e.g. requesting → arrived) are not announced afterwards.
 */
export function noticeStep(
  previous: NoticeSnapshot | null,
  next: NoticeSnapshot,
  seen: readonly NoticeEvent[],
): { event: NoticeEvent | null; seen: NoticeEvent[] } {
  const implied = impliedEvents(next);
  const fresh = implied.filter((e) => !seen.includes(e));
  return {
    event:
      previous && previous.id === next.id && fresh.length
        ? fresh[fresh.length - 1]
        : null,
    seen: fresh.length ? [...seen, ...fresh] : [...seen],
  };
}
export type NoticeRide = {
  driver?: {
    name?: string | null;
    vehicle?: string | null;
    plate?: string | null;
  } | null;
};
const clean = (v: unknown) => (typeof v === 'string' ? v.trim() : '');
/** Texts state only what the ride data says – no invented arrival minutes. */
export function noticeText(event: NoticeEvent, ride: NoticeRide) {
  const name = clean(ride.driver?.name),
    car = [clean(ride.driver?.vehicle), clean(ride.driver?.plate)]
      .filter(Boolean)
      .join(' · ');
  switch (event) {
    case 'accepted':
      return {
        title: 'Dein Chauffeur ist unterwegs',
        body:
          [name, car].filter(Boolean).join(' · ') ||
          'Deine Fahrt wurde angenommen.',
      };
    case 'near':
      return {
        title: 'Dein Chauffeur ist gleich da',
        body: car || 'Bitte halte dich am Abholort bereit.',
      };
    case 'arrived':
      return {
        title: 'Dein Chauffeur wartet am Abholort',
        body: car || 'Dein Fahrzeug steht bereit.',
      };
    case 'riding':
      return { title: 'Gute Fahrt', body: 'Deine Fahrt hat begonnen.' };
    case 'completed':
      return { title: 'Fahrt beendet', body: 'Bitte bewerte deine Fahrt.' };
    case 'unavailable':
      return {
        title: 'Kein Chauffeur verfügbar',
        body: 'Es wurde keine Fahrt zugesagt. Bitte versuche es später erneut.',
      };
    case 'cancelled':
      return {
        title: 'Fahrt storniert',
        body: 'Diese Fahrt findet nicht statt.',
      };
  }
}
const events: NoticeEvent[] = [
  'accepted',
  'near',
  'arrived',
  'riding',
  'completed',
  'unavailable',
  'cancelled',
];
/** Stored memory, read defensively; anything unreadable counts as empty. */
export function parseSeen(raw: string | null | undefined): NoticeSeen {
  if (!raw) return {};
  try {
    const value: unknown = JSON.parse(raw);
    if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
    const result: NoticeSeen = {};
    for (const [id, list] of Object.entries(value))
      if (Array.isArray(list))
        result[id] = events.filter((e) => list.includes(e));
    return result;
  } catch {
    return {};
  }
}
export type NoticeDevice = {
  load(): Promise<string | null>;
  save(raw: string): Promise<void>;
  present(
    bookingId: string,
    event: NoticeEvent,
    text: { title: string; body: string },
  ): Promise<void>;
};
/**
 * Follows the rides the live view reports. Every event is marked as announced
 * (memory and device storage) BEFORE it is shown, so a failure can only lose a
 * notice, never repeat one.
 */
export function createNoticeTracker(device: NoticeDevice) {
  let seen: NoticeSeen | null = null,
    previous: NoticeSnapshot | null = null,
    chain: Promise<unknown> = Promise.resolve();
  async function step(snapshot: NoticeSnapshot, ride: NoticeRide) {
    if (!seen) {
      try {
        seen = parseSeen(await device.load());
      } catch {
        seen = {};
      }
    }
    const result = noticeStep(previous, snapshot, seen[snapshot.id] || []);
    previous = snapshot;
    if (result.seen.length !== (seen[snapshot.id] || []).length) {
      const rest = Object.entries(seen).filter(([id]) => id !== snapshot.id);
      seen = Object.fromEntries([
        ...rest.slice(-(KEPT_RIDES - 1)),
        [snapshot.id, result.seen],
      ]);
      try {
        await device.save(JSON.stringify(seen));
      } catch {
        // The memory of this app run still prevents a repetition.
      }
    }
    if (result.event) {
      try {
        await device.present(
          snapshot.id,
          result.event,
          noticeText(result.event, ride),
        );
      } catch {
        // A notice is a convenience; the ride view itself stays correct.
      }
    }
    return result.event;
  }
  return {
    /** Reports the current server state of a ride; returns what was announced. */
    observe(snapshot: NoticeSnapshot, ride: NoticeRide) {
      const task = chain.then(() => step(snapshot, ride));
      chain = task.catch(() => {});
      return task;
    },
  };
}
