import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  AppState,
  BackHandler,
  Image,
  Keyboard,
  KeyboardAvoidingView,
  Linking,
  PanResponder,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { driverVariant, designPreview } from './build-config';
import * as Notifications from 'expo-notifications';
import {
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  CarFront,
  Check,
  ChevronRight,
  CircleHelp,
  Home,
  LogOut,
  Mail,
  MapPinned,
  Settings,
  ShieldCheck,
  UserRound,
  Users,
} from 'lucide-react-native';
import {
  companyOrigin,
  cacheProfile,
  cachedProfile,
  forgetSession,
  nativeApi,
  saveSession,
  storedSession,
  type AccountState,
  type NativeAccount,
} from './account-client';
import RideWorkspace from './RideWorkspace';
import DriverScreen from './DriverScreen';
import FleetScreen from './FleetScreen';
import StockScreen from './StockScreen';
import { ForegroundRefresh } from './foreground-refresh';
import {
  resumeLocation,
  stopLocation,
  type Position,
} from './location-service';

type Screen =
  | 'home'
  | 'account'
  | 'settings'
  | 'workspace'
  | 'fleet'
  | 'inventory'
  | 'navigation';
const isDriver = driverVariant;
const defaultPath = '/mobile/' + (isDriver ? 'driver' : 'customer');
const ink = '#161a20',
  gold = '#aa8345';
export default function App() {
  const [screen, setScreen] = useState<Screen>('home');
  const [path, setPath] = useState(defaultPath);
  const pathRef = useRef(defaultPath);
  const [hasOpened, setHasOpened] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const tokenRef = useRef<string | null>(null);
  const [profile, setProfile] = useState<NativeAccount | null>(null);
  const [admin, setAdmin] = useState(false),
    [ready, setReady] = useState(false);
  const [loaded, setLoaded] = useState(false),
    [error, setError] = useState('');
  const [busy, setBusy] = useState(false),
    [tracking, setTracking] = useState(false);
  const [position, setPosition] = useState<Position | null>(null);
  const [reload, setReload] = useState(0);
  const [inventoryVehicle, setInventoryVehicle] = useState('');
  const nativeDriver = isDriver && !!token && !!profile;
  const pendingOffer = useRef(false);
  const foregroundRefresh = useRef(new ForegroundRefresh());
  const refresh = useCallback(async () => {
    const session = tokenRef.current;
    await foregroundRefresh.current.refresh(
      session,
      async () => {
        try {
          const r = await nativeApi<AccountState>('account', session);
          // An older response must not replace a newly verified session.
          if (session !== tokenRef.current) return;
          setProfile(r.account);
          setAdmin(r.isAdmin);
          setReady(r.registrationReady);
          setError('');
          if (session && r.account)
            void cacheProfile(session, r.account).catch(() => {});
          if (session && !r.account) {
            setHasOpened(false);
            await forgetSession();
            tokenRef.current = null;
            setToken(null);
          }
        } catch (e) {
          if (session === tokenRef.current) setError((e as Error).message);
        } finally {
          setLoaded(true);
        }
      },
      isDriver
        ? async () => {
            const status = await resumeLocation().catch(() => null);
            if (status) {
              setTracking(status.active);
              if ('position' in status) setPosition(status.position || null);
            }
          }
        : undefined,
    );
  }, []);
  useEffect(() => {
    if (designPreview) {
      setLoaded(true);
      return;
    }
    let alive = true;
    void storedSession()
      .then(async (value) => {
        if (!alive) return;
        tokenRef.current = value;
        setToken(value);
        const cached = await cachedProfile(value);
        if (alive && tokenRef.current === value && cached) setProfile(cached);
        await refresh();
      })
      .catch(() => {
        if (alive) {
          setLoaded(true);
          setError(
            'Der geschützte Gerätespeicher ist nicht verfügbar. Bitte erneut starten.',
          );
        }
      });
    const state = AppState.addEventListener('change', (next) => {
      if (alive && next === 'active') void refresh();
    });
    return () => {
      alive = false;
      state.remove();
    };
  }, [refresh]);
  useEffect(() => {
    const listener = BackHandler.addEventListener('hardwareBackPress', () => {
      if (screen === 'home') return false;
      setScreen('home');
      return true;
    });
    return () => listener.remove();
  }, [screen]);
  const open = useCallback((target: string) => {
    if (!tokenRef.current) {
      setScreen('account');
      return;
    }
    if (isDriver) {
      if (target === '/disposition') setScreen('fleet');
      else if (target === '/betreiber')
        void Linking.openURL(companyOrigin + '/betreiber');
      else setScreen('home');
      return;
    }
    if (pathRef.current !== target) {
      pathRef.current = target;
      setPath(target);
      setReload((v) => v + 1);
    }
    setHasOpened(true);
    setScreen('workspace');
  }, []);
  useEffect(() => {
    if (!isDriver || Platform.OS === 'web') return;
    const openOffer = (response: Notifications.NotificationResponse) => {
      if (response.notification.request.content.data?.kind !== 'luxore-offer')
        return;
      pendingOffer.current = true;
      if (tokenRef.current) {
        pendingOffer.current = false;
        open('/mobile/driver');
      }
      Notifications.clearLastNotificationResponse();
    };
    const old = Notifications.getLastNotificationResponse();
    if (old) openOffer(old);
    const listener =
      Notifications.addNotificationResponseReceivedListener(openOffer);
    return () => listener.remove();
  }, [open]);
  useEffect(() => {
    if (loaded && pendingOffer.current) {
      pendingOffer.current = false;
      open('/mobile/driver');
    }
  }, [loaded, open]);
  async function signedIn(value: {
    account: NativeAccount;
    sessionToken: string;
    isAdmin: boolean;
  }) {
    await saveSession(value.sessionToken);
    setHasOpened(false);
    tokenRef.current = value.sessionToken;
    setToken(value.sessionToken);
    await cacheProfile(value.sessionToken, value.account);
    setProfile(value.account);
    setAdmin(value.isAdmin);
    setError('');
    setScreen('home');
  }
  async function logout() {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      // Server refuses logout while a ride or unsettled driver payment is active.
      await nativeApi('account', tokenRef.current, { action: 'logout' });
      if (isDriver) await stopLocation();
      setHasOpened(false);
      await forgetSession();
      tokenRef.current = null;
      setToken(null);
      setProfile(null);
      setAdmin(false);
      setTracking(false);
      setScreen('home');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const backGesture = PanResponder.create({
    onMoveShouldSetPanResponder: (_, g) =>
      screen !== 'home' &&
      screen !== 'workspace' &&
      g.x0 < 24 &&
      g.dx > 24 &&
      Math.abs(g.dy) < 18,
    onPanResponderRelease: (_, g) => {
      if (g.dx > 90 && Math.abs(g.dy) < 45) {
        Keyboard.dismiss();
        setScreen('home');
      }
    },
  });
  async function pauseTracking() {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      await stopLocation();
      setHasOpened(false);
      setTracking(false);
      setPosition(null);
    } catch {
      setError(
        'Die Ortung konnte nicht beendet werden. Bitte Standortfreigabe in den Systemeinstellungen prüfen.',
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <SafeAreaProvider>
      <SafeAreaView
        {...backGesture.panHandlers}
        style={s.root}
        edges={['top', 'bottom']}
      >
        <StatusBar style="dark" />
        <View style={s.header}>
          {screen !== 'home' ? (
            <Pressable
              onPress={() => setScreen('home')}
              accessibilityLabel="Zur Startseite"
              hitSlop={12}
            >
              <ArrowLeft color={ink} size={23} />
            </Pressable>
          ) : (
            <View style={{ width: 23 }} />
          )}
          <View>
            <Text style={s.brand}>
              LUXORÉ{' '}
              <Text style={s.brandFine}>{isDriver ? 'DRIVER' : 'RIDE'}</Text>
            </Text>
          </View>
          <Pressable
            onPress={() => setScreen('settings')}
            accessibilityLabel="App-Menü öffnen"
            hitSlop={12}
          >
            <Settings color={ink} size={23} />
          </Pressable>
        </View>
        {screen === 'workspace' ||
        screen === 'account' ||
        screen === 'fleet' ||
        screen === 'inventory' ||
        screen === 'navigation' ||
        (screen === 'home' && nativeDriver) ? null : (
          <ScrollView
            style={s.body}
            contentContainerStyle={s.content}
            showsVerticalScrollIndicator={false}
          >
            {screen === 'home' ? (
              <>
                <Text style={s.eyebrow}>
                  {isDriver
                    ? 'DEIN TAG. DEINE FAHRTEN.'
                    : 'FRANKFURT & RHEIN-MAIN'}
                </Text>
                <Text style={s.title}>
                  {profile
                    ? `Hallo, ${profile.name.split(' ')[0]}.`
                    : isDriver
                      ? 'Bereit für\ndeinen Tag.'
                      : 'Entspannt\nankommen.'}
                </Text>
                <Text style={s.subtitle}>
                  {isDriver
                    ? 'Deine Schicht, dein Fahrzeug und deine Fahrten an einem Ort.'
                    : 'Dein Chauffeur. Dein Moment. Persönlich, komfortabel und verlässlich.'}
                </Text>
                <View style={s.hero}>
                  <View style={s.heroTop}>
                    <Text style={s.heroLabel}>
                      {isDriver ? 'DEIN FAHRERBEREICH' : 'DEINE NÄCHSTE FAHRT'}
                    </Text>
                    <ShieldCheck size={21} color="#d9bd82" />
                  </View>
                  <Image
                    source={
                      isDriver
                        ? require('../assets/business.png')
                        : require('../assets/first-class.png')
                    }
                    style={s.car}
                    resizeMode="contain"
                  />
                  <Pressable
                    style={s.heroAction}
                    onPress={() => open(defaultPath)}
                    accessibilityRole="button"
                  >
                    <Text style={s.heroActionText}>
                      {isDriver
                        ? profile
                          ? 'Schicht & Fahrten öffnen'
                          : 'Als Fahrer anmelden'
                        : 'Wohin möchtest du?'}
                    </Text>
                    <ArrowRight color={ink} size={21} />
                  </Pressable>
                </View>
                {isDriver && tracking && (
                  <View style={s.note}>
                    <MapPinned color={gold} size={21} />
                    <Text style={s.noteText}>
                      {position
                        ? 'Standortdienst aktiv. Dein letzter Standort ist gespeichert.'
                        : 'Standortdienst aktiv. Der GPS-Status wird im Fahrerbereich geprüft.'}
                    </Text>
                  </View>
                )}
                <View style={s.twoColumns}>
                  <Shortcut
                    icon={isDriver ? CarFront : CalendarDays}
                    title={isDriver ? 'Fahrzeug' : 'Fahrt planen'}
                    detail={
                      isDriver ? 'Flotte & Wechsel' : 'Im Voraus anfragen'
                    }
                    onPress={() => open(defaultPath)}
                  />
                  <Shortcut
                    icon={isDriver ? Users : UserRound}
                    title={isDriver ? 'Disposition' : 'Mein Konto'}
                    detail={isDriver ? 'Fahrten & Team' : 'Profil & Zugang'}
                    onPress={() =>
                      isDriver ? open('/disposition') : setScreen('account')
                    }
                  />
                </View>
                {!profile && (
                  <Pressable style={s.row} onPress={() => setScreen('account')}>
                    <Mail color={gold} size={23} />
                    <View style={s.rowCopy}>
                      <Text style={s.rowTitle}>Dein persönlicher Zugang</Text>
                      <Text style={s.rowDetail}>
                        Mit E-Mail anmelden oder registrieren
                      </Text>
                    </View>
                    <ChevronRight color={ink} size={20} />
                  </Pressable>
                )}
                {admin && (
                  <Pressable style={s.row} onPress={() => open('/betreiber')}>
                    <ShieldCheck color={gold} size={23} />
                    <View style={s.rowCopy}>
                      <Text style={s.rowTitle}>Betreiberübersicht</Text>
                      <Text style={s.rowDetail}>
                        Profile, Freigaben und Gesamtbetrieb
                      </Text>
                    </View>
                    <ChevronRight color={ink} size={20} />
                  </Pressable>
                )}
              </>
            ) : (
              <>
                <Text style={s.eyebrow}>DEIN LUXÓRE</Text>
                <Text style={s.title}>Einstellungen.</Text>
                <Shortcut
                  icon={UserRound}
                  title={profile?.name || 'Anmelden & registrieren'}
                  detail={profile?.email || 'Dein persönliches Konto'}
                  onPress={() => setScreen('account')}
                />
                {isDriver && (
                  <>
                    <Shortcut
                      icon={MapPinned}
                      title="Navigation & Standort"
                      detail="Navigation, GPS und Schichtstatus"
                      onPress={() =>
                        setScreen(profile ? 'navigation' : 'account')
                      }
                    />
                    <Shortcut
                      icon={Users}
                      title="Flotte & Disposition"
                      detail="Fahrzeuge, Mitarbeiter und Fahrten"
                      onPress={() => open('/disposition')}
                    />
                    <Shortcut
                      icon={CarFront}
                      title="Bordbestand & Einkauf"
                      detail="Snacks, Getränke und Eigenverbrauch"
                      onPress={() =>
                        setScreen(profile ? 'inventory' : 'account')
                      }
                    />
                  </>
                )}
                {isDriver && tracking && !nativeDriver && (
                  <Shortcut
                    icon={MapPinned}
                    title={
                      busy ? 'Wird pausiert …' : 'Hintergrundortung pausieren'
                    }
                    detail="Standortdienst auf diesem Gerät beenden"
                    onPress={() => void pauseTracking()}
                  />
                )}
                {admin && (
                  <Shortcut
                    icon={ShieldCheck}
                    title="Betreiberportal"
                    detail="Geschütztes Portal im Browser öffnen"
                    onPress={() => open('/betreiber')}
                  />
                )}
                <Shortcut
                  icon={CircleHelp}
                  title="Hilfe & Kontakt"
                  detail="Unser Team ist für dich da"
                  onPress={() => void Linking.openURL(companyOrigin + '/hilfe')}
                />
                <Shortcut
                  icon={ShieldCheck}
                  title="Datenschutz"
                  detail="Informationen zu deinen Daten"
                  onPress={() =>
                    void Linking.openURL(companyOrigin + '/datenschutz')
                  }
                />
                {profile && (
                  <Shortcut
                    icon={LogOut}
                    title={busy ? 'Wird abgemeldet …' : 'Abmelden'}
                    detail="Nur nach abgeschlossener Fahrt möglich"
                    onPress={() => void logout()}
                  />
                )}
                <Text style={s.version}>
                  {isDriver ? 'LUXORÉ Driver' : 'LUXORÉ Ride'} · Version 0.6.0
                </Text>
              </>
            )}
            {!loaded && <ActivityIndicator color={gold} />}
            {!!error && (
              <View style={s.errorBox}>
                <Text style={s.error}>{error}</Text>
                <Pressable
                  onPress={() => void refresh()}
                  accessibilityRole="button"
                >
                  <Text style={s.link}>Verbindung erneut prüfen</Text>
                </Pressable>
              </View>
            )}
          </ScrollView>
        )}
        <View style={[s.body, screen !== 'workspace' && { display: 'none' }]}>
          {!isDriver && hasOpened && (
            <RideWorkspace
              key={reload}
              path={path}
              sessionToken={token}
              active={screen === 'workspace'}
              onAccount={() => {
                setScreen('account');
                void refresh();
              }}
            />
          )}
        </View>
        {nativeDriver && (
          <View
            style={[
              s.body,
              screen !== 'home' &&
                screen !== 'navigation' && { display: 'none' },
            ]}
          >
            <DriverScreen
              token={token!}
              profile={profile!}
              active={screen === 'home'}
              settings={screen === 'navigation'}
              onFleet={() => setScreen('fleet')}
              onInventory={(vehicleId) => {
                setInventoryVehicle(vehicleId || '');
                setScreen('inventory');
              }}
            />
          </View>
        )}
        {isDriver && token && screen === 'fleet' && (
          <FleetScreen token={token} />
        )}
        {isDriver && token && screen === 'inventory' && (
          <StockScreen token={token} vehicleId={inventoryVehicle} />
        )}
        <View style={[s.body, screen !== 'account' && { display: 'none' }]}>
          <AccountPanel
            profile={profile}
            ready={ready}
            token={token}
            onSignedIn={signedIn}
            onUpdated={refresh}
            onLogout={logout}
            logoutBusy={busy}
            externalError={error}
          />
        </View>
        {screen !== 'workspace' && (
          <View style={s.tabs}>
            {(
              [
                { key: 'home', label: 'Start', icon: Home },
                { key: 'account', label: 'Konto', icon: UserRound },
                { key: 'settings', label: 'Menü', icon: Settings },
              ] as const
            ).map(({ key, label, icon: Icon }) => (
              <Pressable
                key={key}
                style={[s.tab, screen === key && s.tabActive]}
                onPress={() => setScreen(key)}
                accessibilityRole="tab"
                accessibilityState={{ selected: screen === key }}
              >
                <Icon color={screen === key ? gold : '#777d85'} size={23} />
                <Text style={[s.tabText, screen === key && { color: ink }]}>
                  {label}
                </Text>
              </Pressable>
            ))}
          </View>
        )}
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
function Shortcut({
  icon: Icon,
  title,
  detail,
  onPress,
}: {
  icon: typeof Home;
  title: string;
  detail: string;
  onPress: () => void;
}) {
  return (
    <Pressable style={s.shortcut} onPress={onPress} accessibilityRole="button">
      <Icon color={gold} size={25} />
      <Text style={s.shortcutTitle}>{title}</Text>
      <Text style={s.shortcutDetail}>{detail}</Text>
    </Pressable>
  );
}
function AccountPanel({
  profile,
  ready,
  token,
  onSignedIn,
  onUpdated,
  onLogout,
  logoutBusy,
  externalError,
}: {
  profile: NativeAccount | null;
  ready: boolean;
  token: string | null;
  onSignedIn: (v: {
    account: NativeAccount;
    sessionToken: string;
    isAdmin: boolean;
  }) => Promise<void>;
  onUpdated: () => Promise<void>;
  onLogout: () => Promise<void>;
  logoutBusy: boolean;
  externalError: string;
}) {
  const [mode, setMode] = useState<'login' | 'register'>('register');
  const [email, setEmail] = useState(''),
    [name, setName] = useState(profile?.name || ''),
    [phone, setPhone] = useState(profile?.phone || '');
  const [kind, setKind] = useState(isDriver ? 'driver' : 'customer'),
    [privacy, setPrivacy] = useState(false);
  const [challenge, setChallenge] = useState(''),
    [code, setCode] = useState(''),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [message, setMessage] = useState('');
  useEffect(() => {
    if (profile) {
      setName(profile.name);
      setPhone(profile.phone);
      setChallenge('');
      setCode('');
    }
  }, [profile?.id]);
  async function submit() {
    if (busy) return;
    setBusy(true);
    setError('');
    setMessage('');
    try {
      if (profile) {
        await nativeApi('account', token, { action: 'profile', name, phone });
        await onUpdated();
        setMessage('Dein Profil wurde gespeichert.');
      } else if (challenge) {
        if (!/^\d{6}$/.test(code))
          throw new Error('Bitte den sechsstelligen Code eingeben.');
        await onSignedIn(
          await nativeApi('account', null, {
            action: 'verify',
            challengeId: challenge,
            code,
          }),
        );
      } else {
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()))
          throw new Error('Bitte eine gültige E-Mail-Adresse eingeben.');
        if (
          mode === 'register' &&
          (!name.trim() || !/^\+?[\d\s()-]{6,30}$/.test(phone) || !privacy)
        )
          throw new Error(
            'Bitte Name, Telefonnummer und Datenschutz bestätigen.',
          );
        const r = await nativeApi<{ challengeId: string }>('account', null, {
          action: 'code',
          mode,
          email,
          name,
          phone,
          kind,
          privacy,
        });
        setChallenge(r.challengeId);
        setMessage('Dein Code ist unterwegs und 10 Minuten gültig.');
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <KeyboardAvoidingView
      style={s.body}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        contentContainerStyle={s.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={s.accountSymbol}>
          <UserRound color={gold} size={30} />
        </View>
        <Text style={s.eyebrow}>DEIN PERSÖNLICHER ZUGANG</Text>
        <Text style={s.title}>
          {profile
            ? 'Dein Profil.'
            : challenge
              ? 'Dein Code.'
              : mode === 'register'
                ? 'Willkommen.'
                : 'Schön, dich\nwiederzusehen.'}
        </Text>
        <Text style={s.subtitle}>
          {profile
            ? profile.email
            : challenge
              ? `Gib den Code für ${email.trim()} ein.`
              : 'Dein Luxóre-Konto funktioniert in beiden Apps und auf der Website.'}
        </Text>
        {!profile && !challenge && (
          <View style={s.segment}>
            {(['register', 'login'] as const).map((v) => (
              <Pressable
                key={v}
                disabled={busy}
                style={[s.segmentItem, mode === v && s.segmentActive]}
                onPress={() => {
                  setMode(v);
                  setError('');
                }}
              >
                <Text style={s.segmentText}>
                  {v === 'register' ? 'Registrieren' : 'Anmelden'}
                </Text>
              </Pressable>
            ))}
          </View>
        )}
        {!profile && !ready && (
          <View style={s.note}>
            <Mail color={gold} size={22} />
            <Text style={s.noteText}>
              Der E-Mail-Zugang wird noch eingerichtet. Bitte nach der
              Freischaltung erneut versuchen.
            </Text>
          </View>
        )}
        {challenge ? (
          <>
            <Text style={s.fieldLabel}>ANMELDECODE</Text>
            <TextInput
              style={[s.input, s.codeInput]}
              value={code}
              onChangeText={(v) => setCode(v.replace(/\D/g, ''))}
              maxLength={6}
              keyboardType="number-pad"
              textContentType="oneTimeCode"
              autoComplete="sms-otp"
              autoFocus
              accessibilityLabel="Sechsstelliger Anmeldecode"
            />
            <Pressable
              disabled={busy}
              onPress={() => {
                setChallenge('');
                setCode('');
                setError('');
              }}
            >
              <Text style={s.link}>Neuen Code anfordern</Text>
            </Pressable>
          </>
        ) : (
          <>
            {!profile && (
              <Field
                label="E-MAIL"
                value={email}
                onChange={setEmail}
                keyboard="email-address"
                autoComplete="email"
              />
            )}
            {(profile || mode === 'register') && (
              <>
                <Field
                  label="DEIN NAME"
                  value={name}
                  onChange={setName}
                  autoComplete="name"
                />
                <Field
                  label="TELEFON"
                  value={phone}
                  onChange={setPhone}
                  keyboard="phone-pad"
                  autoComplete="tel"
                />
                {!profile && isDriver && (
                  <View style={s.segment}>
                    {[
                      ['driver', 'Fahrer'],
                      ['fleet', 'Flottenleiter'],
                    ].map(([v, label]) => (
                      <Pressable
                        key={v}
                        disabled={busy}
                        style={[s.segmentItem, kind === v && s.segmentActive]}
                        onPress={() => setKind(v)}
                      >
                        <Text style={s.segmentText}>{label}</Text>
                      </Pressable>
                    ))}
                  </View>
                )}
                {!profile && (
                  <Pressable
                    style={s.consent}
                    onPress={() => setPrivacy(!privacy)}
                    accessibilityRole="checkbox"
                    accessibilityState={{ checked: privacy }}
                  >
                    <View
                      style={[
                        s.check,
                        privacy && { backgroundColor: gold, borderColor: gold },
                      ]}
                    >
                      {privacy && <Check color="#fff" size={17} />}
                    </View>
                    <Text style={s.consentText}>
                      Ich habe die Datenschutzinformationen gelesen.
                    </Text>
                  </Pressable>
                )}
                {!profile && (
                  <Pressable
                    onPress={() =>
                      void Linking.openURL(companyOrigin + '/datenschutz')
                    }
                  >
                    <Text style={s.link}>Datenschutz öffnen</Text>
                  </Pressable>
                )}
              </>
            )}
          </>
        )}
        {!!(error || externalError) && (
          <Text accessibilityRole="alert" style={s.error}>
            {error || externalError}
          </Text>
        )}
        {!!message && <Text style={s.noteText}>{message}</Text>}
        <Pressable
          style={[
            s.primary,
            (busy || (!profile && !ready)) && { opacity: 0.45 },
          ]}
          disabled={busy || (!profile && !ready)}
          onPress={() => void submit()}
          accessibilityRole="button"
        >
          {busy ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <Text style={s.primaryText}>
                {profile
                  ? 'Profil speichern'
                  : challenge
                    ? 'Code bestätigen'
                    : 'Code per E-Mail erhalten'}
              </Text>
              <ArrowRight color="#fff" size={20} />
            </>
          )}
        </Pressable>
        {profile && (
          <Pressable disabled={logoutBusy} onPress={() => void onLogout()}>
            <Text style={s.link}>
              {logoutBusy ? 'Wird abgemeldet …' : 'Abmelden'}
            </Text>
          </Pressable>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
function Field({
  label,
  value,
  onChange,
  keyboard,
  autoComplete,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  keyboard?: 'email-address' | 'phone-pad';
  autoComplete?: 'name' | 'email' | 'tel';
}) {
  return (
    <View>
      <Text style={s.fieldLabel}>{label}</Text>
      <TextInput
        style={s.input}
        value={value}
        onChangeText={onChange}
        keyboardType={keyboard}
        autoComplete={autoComplete}
        autoCapitalize={keyboard ? 'none' : 'words'}
        autoCorrect={!keyboard}
        maxLength={
          keyboard === 'email-address'
            ? 254
            : keyboard === 'phone-pad'
              ? 30
              : 80
        }
        accessibilityLabel={label}
      />
    </View>
  );
}
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  header: {
    height: 58,
    paddingHorizontal: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  brand: { color: ink, fontSize: 20, fontWeight: '600', letterSpacing: 2.3 },
  brandFine: { fontSize: 11, letterSpacing: 2.8, color: gold },
  body: { flex: 1 },
  content: { padding: 24, paddingTop: 22, gap: 20, paddingBottom: 32 },
  eyebrow: { color: gold, fontSize: 10, fontWeight: '700', letterSpacing: 2.2 },
  title: {
    fontSize: 38,
    fontWeight: '600',
    letterSpacing: -1.6,
    lineHeight: 43,
    color: ink,
  },
  subtitle: { fontSize: 15, lineHeight: 23, color: '#72777d', marginTop: -7 },
  hero: {
    borderRadius: 26,
    backgroundColor: ink,
    padding: 22,
    overflow: 'hidden',
  },
  heroTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  heroLabel: {
    color: '#d9bd82',
    fontSize: 10,
    letterSpacing: 1.8,
    fontWeight: '600',
  },
  car: {
    height: 136,
    width: '100%',
    marginVertical: 7,
    transform: [{ scale: 1.4 }],
  },
  heroAction: {
    backgroundColor: '#f1e4ca',
    padding: 17,
    borderRadius: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  heroActionText: { color: ink, fontSize: 16, fontWeight: '600' },
  twoColumns: { flexDirection: 'row', gap: 12 },
  shortcut: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#eee8dc',
    borderRadius: 20,
    padding: 18,
    gap: 9,
    backgroundColor: '#fff',
  },
  shortcutTitle: { fontSize: 16, fontWeight: '600', color: ink },
  shortcutDetail: { fontSize: 12, lineHeight: 18, color: '#797e84' },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
    paddingVertical: 16,
  },
  rowCopy: { flex: 1, gap: 5 },
  rowTitle: { fontSize: 15, fontWeight: '600', color: ink },
  rowDetail: { fontSize: 12, color: '#797e84', lineHeight: 18 },
  note: {
    flexDirection: 'row',
    padding: 17,
    borderRadius: 17,
    backgroundColor: '#fbf7ee',
    gap: 12,
    alignItems: 'center',
  },
  noteText: { color: '#766b56', fontSize: 13, lineHeight: 21, flexShrink: 1 },
  tabs: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginBottom: 8,
    padding: 5,
    gap: 6,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#f2eee6',
    backgroundColor: '#fff',
  },
  tab: { flex: 1, padding: 12, alignItems: 'center', gap: 5, borderRadius: 20 },
  tabActive: { backgroundColor: '#faf5eb' },
  tabText: { fontSize: 10, color: '#777d85' },
  errorBox: {
    gap: 10,
    padding: 16,
    borderRadius: 16,
    backgroundColor: '#fff4ee',
  },
  error: { fontSize: 14, color: '#ad493c', lineHeight: 21 },
  link: { color: gold, fontSize: 14, fontWeight: '600', paddingVertical: 10 },
  version: {
    fontSize: 12,
    color: '#989ca2',
    textAlign: 'center',
    marginTop: 16,
  },
  accountSymbol: {
    width: 62,
    height: 62,
    borderRadius: 22,
    backgroundColor: '#faf5eb',
    alignItems: 'center',
    justifyContent: 'center',
  },
  segment: {
    flexDirection: 'row',
    backgroundColor: '#faf7f2',
    borderRadius: 16,
    padding: 4,
  },
  segmentItem: { flex: 1, borderRadius: 12, padding: 13, alignItems: 'center' },
  segmentActive: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#eee4d2',
  },
  segmentText: { fontSize: 14, color: ink, fontWeight: '500' },
  fieldLabel: {
    fontSize: 10,
    letterSpacing: 1.5,
    color: '#8b8171',
    fontWeight: '600',
    marginBottom: 9,
  },
  input: {
    borderWidth: 1,
    borderColor: '#e9e5de',
    borderRadius: 15,
    padding: 17,
    fontSize: 16,
    color: ink,
    minHeight: 56,
    backgroundColor: '#fff',
  },
  codeInput: { fontSize: 30, letterSpacing: 9, textAlign: 'center' },
  primary: {
    borderRadius: 17,
    backgroundColor: ink,
    padding: 19,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 60,
  },
  primaryText: { color: '#fff', fontSize: 15, fontWeight: '600' },
  consent: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  consentText: { flex: 1, fontSize: 13, lineHeight: 21, color: '#7a7e84' },
  check: {
    width: 23,
    height: 23,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: '#ddd5c7',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
