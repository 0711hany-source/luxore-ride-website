import React, {
  Suspense,
  useCallback,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  ActivityIndicator,
  Keyboard,
  Linking,
  StyleSheet,
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import Constants from 'expo-constants';
import {
  CalendarDays,
  CarFront,
  UserRound,
  Users,
  Wallet,
  type LucideIcon,
} from 'lucide-react-native';
import { driverVariant } from './build-config';
import { companyOrigin } from './account-client';
import RideWorkspace from './RideWorkspace';
import DriverScreen from './DriverScreen';
import FleetScreen from './FleetScreen';
import OperationsScreen from './OperationsScreen';
import FleetInvitationsScreen from './FleetInvitationsScreen';
import StockScreen from './StockScreen';
import CustomerTripsScreen from './CustomerTripsScreen';
import CustomerBookingScreen from './CustomerBookingScreen';
import CustomerLiveScreen from './CustomerLiveScreen';
import { colors } from './theme';
import { useSession, type SessionTargets } from './use-session';
import Header from './navigation/Header';
import ScreenSlot from './navigation/ScreenSlot';
import {
  allowsEdgeBack,
  navConfig,
  screenTitle,
  showsTabs,
  type Route,
  type TabKey,
} from './navigation/routes';
import { useEdgeBack } from './navigation/use-edge-back';
import { useNavigation } from './navigation/use-navigation';
import { useOfferNotification } from './navigation/use-offer-notification';
import AccountMenu, { type AccountMenuAction } from './screens/AccountMenu';
import AccountPanel from './screens/AccountPanel';
import HomeScreen from './screens/HomeScreen';
import TabBar from './ui/TabBar';
import { useReduceMotion } from './ui/accessibility';
import type { PhotoTarget } from './operator-platform';

// Musterseite des Neudesigns (Etappe 0): erst beim Öffnen geladen, damit die
// neuen Gesten-/Animationspakete den normalen App-Start nicht berühren.
// Sichtbar nur in Testbauten (App-Name endet auf „Test“) und in der Entwicklung.
const UiShowcaseScreen = React.lazy(() => import('./ui/UiShowcaseScreen'));
const showDesignSamples =
  (typeof __DEV__ !== 'undefined' && __DEV__) ||
  (Constants.expoConfig?.name ?? '').endsWith(' Test');

// Betreiberplattform: ebenfalls erst beim Öffnen geladen – der Start der App
// und der Fahrerbereich bleiben davon unberührt.
const EarningsScreen = React.lazy(() => import('./platform/EarningsScreen'));
const ComplianceScreen = React.lazy(
  () => import('./platform/ComplianceScreen'),
);
const FleetIncomeScreen = React.lazy(
  () => import('./platform/FleetIncomeScreen'),
);
const FleetComplianceScreen = React.lazy(
  () => import('./platform/FleetComplianceScreen'),
);
const PhotoWebScreen = React.lazy(() => import('./platform/PhotoWebScreen'));
const ReservationsScreen = React.lazy(
  () => import('./platform/ReservationsScreen'),
);
const lazyFallback = <ActivityIndicator color={colors.gold} />;

const isDriver = driverVariant;
const defaultPath = '/mobile/' + (isDriver ? 'driver' : 'customer');
const tabIcons: Record<TabKey, LucideIcon> = {
  start: CarFront,
  trips: CalendarDays,
  earnings: Wallet,
  fleet: Users,
  account: UserRound,
};

/**
 * Wurzel der App: verbindet Anmeldung (`use-session`), Verlauf
 * (`navigation/*`) und die Screens. Versteckte Screens bleiben eingehängt
 * (`ScreenSlot`), damit Abfragen, Schicht, GPS und Fahrtalarm weiterlaufen.
 */
export default function App() {
  const targets = useRef<SessionTargets>({ home() {}, account() {} });
  const session = useSession(targets);
  const { token, tokenRef, profile, admin, hasOpened, setHasOpened, refresh } =
    session;
  const signedIn = !!token && !!profile;
  const nativeDriver = isDriver && signedIn;
  const fleetRole = profile?.kind === 'fleet' || admin;
  const config = useMemo(
    () => navConfig({ driver: isDriver, signedIn, fleetRole }),
    [signedIn, fleetRole],
  );
  const nav = useNavigation(config);
  const { route, push, replace, back, canGoBack, selectTab, reset } = nav;
  targets.current = {
    home: reset,
    account: () => {
      reset();
      push('account');
    },
  };

  const [path, setPath] = useState(defaultPath);
  const pathRef = useRef(defaultPath);
  const [reload, setReload] = useState(0);
  const [inventoryVehicle, setInventoryVehicle] = useState('');
  const [plannedBooking, setPlannedBooking] = useState(false);
  const [liveBookingId, setLiveBookingId] = useState<string | null>(null);
  // Flotte der Leitungs-Ansichten und Ziel der Foto-Web-Ansicht.
  const [platformFleet, setPlatformFleet] = useState('');
  const [photoTarget, setPhotoTarget] = useState<PhotoTarget>('driver');
  const openPhotos = (target: PhotoTarget) => {
    setPhotoTarget(target);
    push('photos');
  };
  const openLive = (id: string) => {
    setLiveBookingId(id);
    push('live');
  };
  const open = useCallback(
    (target: string) => {
      if (!tokenRef.current) {
        push('account');
        return;
      }
      if (isDriver) {
        if (target === '/disposition') push('operations');
        else if (target === '/betreiber')
          void Linking.openURL(companyOrigin + '/betreiber').catch(() => {});
        else push('home');
        return;
      }
      if (target === '/mobile/customer?live=1') {
        setLiveBookingId(null);
        push('live');
        return;
      }
      if (target === defaultPath) {
        setPlannedBooking(false);
        push('booking');
        return;
      }
      if (pathRef.current !== target) {
        pathRef.current = target;
        setPath(target);
        setReload((v) => v + 1);
      }
      setHasOpened(true);
      push('workspace');
    },
    [push, tokenRef, setHasOpened],
  );
  const hasSession = useCallback(() => !!tokenRef.current, [tokenRef]);
  const openDriver = useCallback(() => open('/mobile/driver'), [open]);
  useOfferNotification({
    enabled: isDriver,
    loaded: session.loaded,
    signedIn: hasSession,
    openDriver,
  });

  const routeRef = useRef<Route>(route);
  routeRef.current = route;
  const edgeBack = useEdgeBack(
    () => allowsEdgeBack(routeRef.current) && canGoBack(),
    back,
  );
  const reduceMotion = useReduceMotion();
  const slot = (visible: boolean, animated = true) => ({
    visible,
    animated,
    motion: nav.motion,
    reduceMotion,
  });
  // Ohne Anmeldung führt jeder geschützte Eintrag zur Anmeldung im Konto-Tab.
  const guarded = (target: Route) => push(profile ? target : 'account');
  const menu = (action: AccountMenuAction) => {
    if (action === 'earnings') guarded('earnings');
    else if (action === 'reservations') guarded('reservations');
    else if (action === 'compliance') guarded('compliance');
    else if (action === 'navigation') guarded('navigation');
    else if (action === 'disposition') open('/disposition');
    else if (action === 'invitations') guarded('invitations');
    else if (action === 'inventory') guarded('inventory');
    else if (action === 'pauseTracking') void session.pauseTracking();
    else if (action === 'operator') open('/betreiber');
    else if (action === 'help')
      void Linking.openURL(companyOrigin + '/hilfe').catch(() => {});
    else if (action === 'privacy')
      void Linking.openURL(companyOrigin + '/datenschutz').catch(() => {});
    else push('design');
  };

  return (
    <SafeAreaProvider>
      <SafeAreaView {...edgeBack} style={s.root} edges={['top', 'bottom']}>
        <StatusBar style="dark" />
        <Header
          title={screenTitle(route)}
          product={isDriver ? 'DRIVER' : 'RIDE'}
          onBack={
            nav.canPop
              ? () => {
                  Keyboard.dismiss();
                  back();
                }
              : undefined
          }
        />
        {route === 'home' && !nativeDriver && (
          <ScreenSlot {...slot(true)}>
            <HomeScreen
              profile={profile}
              admin={admin}
              loaded={session.loaded}
              error={session.error}
              tracking={session.tracking}
              hasPosition={!!session.position}
              onStart={() => open(defaultPath)}
              onPlan={() => {
                if (!token) push('account');
                else {
                  setPlannedBooking(true);
                  push('booking');
                }
              }}
              onAccount={() => push('account')}
              onDisposition={() => open('/disposition')}
              onOperator={() => open('/betreiber')}
              onRetry={() => void refresh()}
            />
          </ScreenSlot>
        )}
        <ScreenSlot {...slot(route === 'workspace', false)}>
          {!isDriver && hasOpened && (
            <RideWorkspace
              key={reload}
              path={path}
              sessionToken={token}
              active={route === 'workspace'}
              onAccount={() => {
                push('account');
                void refresh();
              }}
            />
          )}
        </ScreenSlot>
        {nativeDriver && (
          // Bleibt bei jedem Tab-Wechsel eingehängt: Schicht, GPS und
          // Fahrtalarm laufen im versteckten Fahrerbereich weiter.
          <ScreenSlot
            {...slot(route === 'home' || route === 'navigation', false)}
          >
            <DriverScreen
              token={token!}
              profile={profile!}
              active={route === 'home'}
              settings={route === 'navigation'}
              onFleet={() => push('fleet')}
              onEarnings={() => push('earnings')}
              onCompliance={() => push('compliance')}
              onReservations={() => push('reservations')}
              onInventory={(vehicleId) => {
                setInventoryVehicle(vehicleId || '');
                push('inventory');
              }}
            />
          </ScreenSlot>
        )}
        {isDriver && token && (
          <ScreenSlot {...slot(route === 'operations')}>
            <OperationsScreen
              key={token}
              token={token}
              accountId={profile?.id}
              active={route === 'operations'}
              onInvitations={() => push('invitations')}
              onFleet={() => push('fleet')}
              onIncome={(fleetId) => {
                setPlatformFleet(fleetId);
                push('fleetIncome');
              }}
              onCompliance={(fleetId) => {
                setPlatformFleet(fleetId);
                push('fleetCompliance');
              }}
            />
          </ScreenSlot>
        )}
        {isDriver && token && route === 'earnings' && (
          <ScreenSlot {...slot(true)}>
            <Suspense fallback={lazyFallback}>
              <EarningsScreen key={token} token={token} />
            </Suspense>
          </ScreenSlot>
        )}
        {isDriver && token && route === 'compliance' && (
          <ScreenSlot {...slot(true)}>
            <Suspense fallback={lazyFallback}>
              <ComplianceScreen
                key={token}
                token={token}
                onPhotos={() => openPhotos('driver')}
              />
            </Suspense>
          </ScreenSlot>
        )}
        {isDriver && token && route === 'reservations' && (
          <ScreenSlot {...slot(true)}>
            <Suspense fallback={lazyFallback}>
              <ReservationsScreen key={token} token={token} />
            </Suspense>
          </ScreenSlot>
        )}
        {isDriver && token && route === 'fleetIncome' && (
          <ScreenSlot {...slot(true)}>
            <Suspense fallback={lazyFallback}>
              <FleetIncomeScreen
                key={token + ':' + platformFleet}
                token={token}
                fleetId={platformFleet}
              />
            </Suspense>
          </ScreenSlot>
        )}
        {isDriver && token && route === 'fleetCompliance' && (
          <ScreenSlot {...slot(true)}>
            <Suspense fallback={lazyFallback}>
              <FleetComplianceScreen
                key={token + ':' + platformFleet}
                token={token}
                fleetId={platformFleet}
                onPhotos={() => openPhotos('fleet')}
              />
            </Suspense>
          </ScreenSlot>
        )}
        {isDriver && token && route === 'photos' && (
          <ScreenSlot {...slot(true, false)}>
            <Suspense fallback={lazyFallback}>
              <PhotoWebScreen
                key={token + ':' + photoTarget}
                token={token}
                target={photoTarget}
              />
            </Suspense>
          </ScreenSlot>
        )}
        {isDriver && token && profile && route === 'invitations' && (
          <ScreenSlot {...slot(true)}>
            <FleetInvitationsScreen
              token={token}
              userId={profile.id}
              active={true}
              onDone={() => push('home')}
            />
          </ScreenSlot>
        )}
        {isDriver && token && route === 'fleet' && (
          <ScreenSlot {...slot(true)}>
            <FleetScreen
              token={token}
              onInvitations={() => push('invitations')}
            />
          </ScreenSlot>
        )}
        {isDriver && token && route === 'inventory' && (
          <ScreenSlot {...slot(true)}>
            <StockScreen token={token} vehicleId={inventoryVehicle} />
          </ScreenSlot>
        )}
        {!isDriver && token && (
          <ScreenSlot {...slot(route === 'booking')}>
            {profile && (
              <CustomerBookingScreen
                key={token}
                token={token}
                profile={profile}
                active={route === 'booking'}
                planned={plannedBooking}
                onTrips={() => push('trips')}
                onLive={openLive}
              />
            )}
          </ScreenSlot>
        )}
        {!isDriver && token && (
          <ScreenSlot {...slot(route === 'trips')}>
            <CustomerTripsScreen
              key={token}
              token={token}
              active={route === 'trips'}
              onBook={() => open(defaultPath)}
              onLive={openLive}
            />
          </ScreenSlot>
        )}
        {!isDriver && token && profile && route === 'live' && (
          <ScreenSlot {...slot(true, false)}>
            <CustomerLiveScreen
              key={token + ':' + liveBookingId}
              token={token}
              ownerId={profile.id}
              active={true}
              bookingId={liveBookingId}
              onTrips={() => replace('trips')}
              onHome={() => replace('home')}
            />
          </ScreenSlot>
        )}
        {route === 'design' && (
          <ScreenSlot {...slot(true)}>
            <Suspense fallback={<ActivityIndicator color={colors.gold} />}>
              <UiShowcaseScreen />
            </Suspense>
          </ScreenSlot>
        )}
        <ScreenSlot {...slot(route === 'account')}>
          <AccountPanel
            profile={profile}
            ready={session.ready}
            token={token}
            onSignedIn={session.signedIn}
            onUpdated={refresh}
            onLogout={session.logout}
            onDelete={session.deleteAccount}
            logoutBusy={session.busy}
            externalError={session.error}
            externalNotice={session.notice}
          >
            <AccountMenu
              signedIn={signedIn}
              admin={admin}
              canPauseTracking={isDriver && session.tracking && !nativeDriver}
              busy={session.busy}
              designSamples={showDesignSamples}
              version={Constants.expoConfig?.version}
              onAction={menu}
            />
          </AccountPanel>
        </ScreenSlot>
        {showsTabs(route) && (
          <TabBar
            items={config.tabs.map(({ key, label }) => ({
              key,
              label,
              icon: tabIcons[key],
            }))}
            selected={nav.tab}
            onSelect={(key) =>
              selectTab(key === 'trips' && !token ? 'account' : key)
            }
          />
        )}
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
});
