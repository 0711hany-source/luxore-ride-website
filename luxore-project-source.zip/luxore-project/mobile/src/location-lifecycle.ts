/** Serialize native service/storage mutations; newer transitions cancel pending starts. */
export class LocationLifecycle {
  version = 0;
  private queue: Promise<unknown> = Promise.resolve();
  begin() {
    return ++this.version;
  }
  current(version: number) {
    return version === this.version;
  }
  run<T>(work: () => Promise<T>): Promise<T> {
    const result = this.queue.then(work, work);
    this.queue = result.catch(() => {});
    return result;
  }
}
