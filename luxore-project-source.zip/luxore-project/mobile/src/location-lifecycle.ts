/** Serialize native service/storage mutations; newer transitions cancel pending starts. */
export class LocationLifecycle {
  version = 0;
  // A fresh native runtime may restore a persisted capability. Any explicit
  // transition revokes delivery until its matching start has actually finished.
  private deliveryVersion = 0;
  private queue: Promise<unknown> = Promise.resolve();
  begin() {
    this.deliveryVersion = -1;
    return ++this.version;
  }
  current(version: number) {
    return version === this.version;
  }
  activate(version: number) {
    if (this.current(version)) this.deliveryVersion = version;
  }
  canDeliver(version: number) {
    return this.current(version) && this.deliveryVersion === version;
  }
  run<T>(work: () => Promise<T>): Promise<T> {
    const result = this.queue.then(work, work);
    this.queue = result.catch(() => {});
    return result;
  }
}
