import * as SecureStore from 'expo-secure-store';
import type { BoardStore, BoardRequest } from './customer-board';
const queues = new Map<string, Promise<unknown>>();
function serial<T>(key: string, work: () => Promise<T>): Promise<T> {
  const previous = queues.get(key) ?? Promise.resolve();
  const task = previous.catch(() => {}).then(work);
  queues.set(key, task);
  void task.then(
    () => {
      if (queues.get(key) === task) queues.delete(key);
    },
    () => {
      if (queues.get(key) === task) queues.delete(key);
    },
  );
  return task;
}
export function boardStore(owner: string, booking: string): BoardStore {
  const key =
    'luxore-board-pending-v1-' +
    encodeURIComponent(owner) +
    '-' +
    encodeURIComponent(booking);
  return {
    load: () =>
      serial(key, async () => {
        const v = await SecureStore.getItemAsync(key);
        return v ? (JSON.parse(v) as BoardRequest) : null;
      }),
    save: (v) =>
      serial(key, async () => {
        const existing = await SecureStore.getItemAsync(key);
        if (existing && existing !== JSON.stringify(v))
          throw new Error('Eine andere Bordbestellung ist noch offen.');
        await SecureStore.setItemAsync(key, JSON.stringify(v));
      }),
    clear: (expectedId) =>
      serial(key, async () => {
        const existing = await SecureStore.getItemAsync(key);
        if (
          existing &&
          (JSON.parse(existing) as BoardRequest).requestId === expectedId
        )
          await SecureStore.deleteItemAsync(key);
      }),
  };
}
