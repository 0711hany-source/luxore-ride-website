import * as SecureStore from 'expo-secure-store';
import type { BoardStore, BoardRequest } from './customer-board';
import { secureKeyPart, storageDeadline } from './booking-store';
const queues = new Map<string, Promise<unknown>>();
function serial<T>(key: string, work: () => Promise<T>): Promise<T> {
  const previous = queues.get(key) ?? Promise.resolve();
  const task = previous.catch(() => {}).then(work);
  queues.set(key, task);
  void task.then(
    () => {
      if (queues.get(key) === task) queues.delete(key);
    },
    () => {
      if (queues.get(key) === task) queues.delete(key);
    },
  );
  return task;
}
export const boardKey = (owner: string, booking: string) =>
  'luxore-board-pending-v1-' +
  secureKeyPart(owner) +
  '-' +
  secureKeyPart(booking);
export function boardStore(owner: string, booking: string): BoardStore {
  const key = boardKey(owner, booking);
  return {
    load: () =>
      serial(key, async () => {
        const v = await storageDeadline(SecureStore.getItemAsync(key));
        return v ? (JSON.parse(v) as BoardRequest) : null;
      }),
    save: (v) =>
      serial(key, async () => {
        // Bounded like load(): a silent keystore must not leave the swipe busy forever.
        const existing = await storageDeadline(SecureStore.getItemAsync(key));
        if (existing && existing !== JSON.stringify(v))
          throw new Error('Eine andere Bordbestellung ist noch offen.');
        await storageDeadline(SecureStore.setItemAsync(key, JSON.stringify(v)));
      }),
    clear: (expectedId) =>
      serial(key, async () => {
        const existing = await storageDeadline(SecureStore.getItemAsync(key));
        if (
          existing &&
          (JSON.parse(existing) as BoardRequest).requestId === expectedId
        )
          await storageDeadline(SecureStore.deleteItemAsync(key));
      }),
  };
}
