import React from 'react';
import { Pressable, Text } from 'react-native';
import type { LucideIcon } from 'lucide-react-native';
import { gold, s } from './styles';

/** Kachel mit Symbol, Titel und Detail (Startansicht). */
export default function Shortcut({
  icon: Icon,
  title,
  detail,
  onPress,
}: {
  icon: LucideIcon;
  title: string;
  detail: string;
  onPress: () => void;
}) {
  return (
    <Pressable style={s.shortcut} onPress={onPress} accessibilityRole="button">
      <Icon color={gold} size={25} />
      <Text style={s.shortcutTitle}>{title}</Text>
      <Text style={s.shortcutDetail}>{detail}</Text>
    </Pressable>
  );
}
