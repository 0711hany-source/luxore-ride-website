import React from 'react';
import { Text, View } from 'react-native';
import {
  CarFront,
  CircleHelp,
  Mail,
  MapPinned,
  Settings,
  ShieldCheck,
  Users,
  Wallet,
  type LucideIcon,
} from 'lucide-react-native';
import { driverVariant as isDriver } from '../build-config';
import ListRow from '../ui/ListRow';
import { s } from './styles';

export type AccountMenuAction =
  | 'earnings'
  | 'compliance'
  | 'navigation'
  | 'disposition'
  | 'invitations'
  | 'inventory'
  | 'pauseTracking'
  | 'operator'
  | 'help'
  | 'privacy'
  | 'design';

/**
 * Einträge des früheren „Menü“-Tabs, jetzt im Konto-Tab unter Anmeldung bzw.
 * Profil. Einträge, die ohne Anmeldung nur zur Anmeldung führten, erscheinen
 * erst mit Anmeldung – das Formular steht direkt darüber.
 */
export default function AccountMenu({
  signedIn,
  admin,
  canPauseTracking,
  busy,
  designSamples,
  version,
  onAction,
}: {
  signedIn: boolean;
  admin: boolean;
  /** Fahrer ohne Anmeldung, dessen Standortdienst noch läuft. */
  canPauseTracking: boolean;
  busy: boolean;
  designSamples: boolean;
  version?: string;
  onAction: (action: AccountMenuAction) => void;
}) {
  const rows: {
    action: AccountMenuAction;
    icon: LucideIcon;
    title: string;
    detail: string;
  }[] = [
    ...(isDriver && signedIn
      ? ([
          {
            action: 'earnings',
            icon: Wallet,
            title: 'Meine Einnahmen',
            detail: 'Heute, Woche, Monat – bar und Terminal',
          },
          {
            action: 'compliance',
            icon: ShieldCheck,
            title: 'Vor der Schicht',
            detail: 'Papiere, Wochenkontrolle und Sperren',
          },
          {
            action: 'navigation',
            icon: MapPinned,
            title: 'Navigation & Standort',
            detail: 'Navigation, GPS und Schichtstatus',
          },
          {
            action: 'disposition',
            icon: Users,
            title: 'Flotte & Disposition',
            detail: 'Fahrzeuge, Mitarbeiter und Fahrten',
          },
          {
            action: 'invitations',
            icon: Mail,
            title: 'Flotteneinladungen',
            detail: 'Code einlösen oder Team einladen',
          },
          {
            action: 'inventory',
            icon: CarFront,
            title: 'Bordbestand & Einkauf',
            detail: 'Snacks, Getränke und Eigenverbrauch',
          },
        ] as const)
      : []),
    ...(canPauseTracking
      ? ([
          {
            action: 'pauseTracking',
            icon: MapPinned,
            title: busy ? 'Wird pausiert …' : 'Hintergrundortung pausieren',
            detail: 'Standortdienst auf diesem Gerät beenden',
          },
        ] as const)
      : []),
    ...(admin
      ? ([
          {
            action: 'operator',
            icon: ShieldCheck,
            title: 'Betreiberportal',
            detail: 'Geschütztes Portal im Browser öffnen',
          },
        ] as const)
      : []),
    {
      action: 'help',
      icon: CircleHelp,
      title: 'Hilfe & Kontakt',
      detail: 'Unser Team ist für dich da',
    },
    {
      action: 'privacy',
      icon: ShieldCheck,
      title: 'Datenschutz',
      detail: 'Informationen zu deinen Daten',
    },
    ...(designSamples
      ? ([
          {
            action: 'design',
            icon: Settings,
            title: 'Design-Muster (Test)',
            detail: 'Bausteine des neuen Designs ansehen',
          },
        ] as const)
      : []),
  ];
  return (
    <View>
      <Text style={s.eyebrow}>MEHR</Text>
      {rows.map(({ action, icon, title, detail }, index) => (
        <ListRow
          key={action}
          icon={icon}
          title={title}
          detail={detail}
          divider={index < rows.length - 1}
          onPress={() => onAction(action)}
        />
      ))}
      <Text style={s.version}>
        {isDriver ? 'LUXORÉ Driver' : 'LUXORÉ Ride'}
        {version ? ` · Version ${version}` : ''}
      </Text>
    </View>
  );
}
