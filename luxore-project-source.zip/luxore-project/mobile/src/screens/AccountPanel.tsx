import React, { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import {
  KeyboardAvoidingView,
  Linking,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { ArrowLeft, Check, UserRound } from 'lucide-react-native';
import {
  companyOrigin,
  NativeTimeoutError,
  nativeApi,
  type NativeAccount,
} from '../account-client';
import { driverVariant as isDriver } from '../build-config';
import {
  SignInFlow,
  requestLabel,
  stepPosition,
  waitSeconds,
} from '../sign-in-flow';
import SwipeAction from '../SwipeAction';
import { colors, layout, maxFontScale, space } from '../theme';
// Einzeln eingebunden: `ui/index.ts` zöge Reanimated/Gesture-Handler an die
// App-Wurzel. Aus demselben Grund bleibt der Umschalter hier ein einfacher
// Baustein statt `ui/SegmentedControl` (nutzt Reanimated).
import Banner from '../ui/Banner';
import Button from '../ui/Button';
import CodeField from '../ui/CodeField';
import TextField from '../ui/TextField';
import { Label, Subhead, Title } from '../ui/Typography';
import { gold, s } from './styles';

type Session = { account: NativeAccount; sessionToken: string; isAdmin: boolean };

/**
 * Anmeldung, Registrierung, Profil, Abmelden und Kontolöschung. `children`
 * (die Einträge des Konto-Tabs) stehen am Ende derselben Scrollfläche.
 */
export default function AccountPanel({
  profile,
  ready,
  token,
  onSignedIn,
  onUpdated,
  onLogout,
  onDelete,
  logoutBusy,
  externalError,
  externalNotice,
  children,
}: {
  profile: NativeAccount | null;
  ready: boolean;
  token: string | null;
  onSignedIn: (v: Session) => Promise<void>;
  onUpdated: () => Promise<void>;
  onLogout: () => Promise<void>;
  onDelete: () => Promise<void>;
  logoutBusy: boolean;
  externalError: string;
  externalNotice: string;
  children?: React.ReactNode;
}) {
  const signedIn = useRef(onSignedIn);
  signedIn.current = onSignedIn;
  // Server-Aufrufe und Zeitgrenzen wie bisher: Code anfordern 35 s (der Server
  // antwortet nach wenigen Sekunden und verschickt langsame Post danach),
  // Code prüfen 30 s.
  const [flow] = useState(
    () =>
      new SignInFlow<Session>({
        requestCode: (body) =>
          nativeApi<{ challengeId: string }>(
            'account',
            null,
            body,
            undefined,
            undefined,
            35000,
          ),
        verify: (challengeId, code) =>
          nativeApi<Session>(
            'account',
            null,
            { action: 'verify', challengeId, code },
            undefined,
            undefined,
            30000,
          ),
        onSignedIn: (session) => signedIn.current(session),
        isTimeout: (e) => e instanceof NativeTimeoutError,
        defaultKind: isDriver ? 'driver' : 'customer',
      }),
  );
  const f = useSyncExternalStore(flow.subscribe, flow.getState, flow.getState);
  const [name, setName] = useState(profile?.name || ''),
    [phone, setPhone] = useState(profile?.phone || '');
  const [saving, setSaving] = useState(false),
    [profileError, setProfileError] = useState(''),
    [profileMessage, setProfileMessage] = useState('');
  // The server accepts one code request per e-mail and minute. Show that wait
  // instead of letting the next attempt fail.
  const [now, setNow] = useState(() => Date.now());
  const [hiddenExternal, setHiddenExternal] = useState('');
  const [deleting, setDeleting] = useState(false);
  const retryAt = f.retryAt;
  const wait = waitSeconds(retryAt, now);
  useEffect(() => {
    if (retryAt <= Date.now()) return;
    setNow(Date.now());
    const timer = setInterval(() => setNow(Date.now()), 1000);
    const end = setTimeout(
      () => clearInterval(timer),
      retryAt - Date.now() + 1000,
    );
    return () => {
      clearInterval(timer);
      clearTimeout(end);
    };
  }, [retryAt]);
  // Typing answers a message; an old notice must not stay on screen.
  const edited = () => {
    setProfileError('');
    setHiddenExternal(externalError);
  };
  useEffect(() => {
    // Signed in, signed out or deleted: the sign-in steps start again and the
    // previous account's details leave the form.
    flow.reset();
    setName(profile?.name || '');
    setPhone(profile?.phone || '');
    setProfileError('');
    setProfileMessage('');
    setDeleting(false);
  }, [profile?.id]);
  async function saveProfile() {
    if (saving) return;
    setSaving(true);
    setProfileError('');
    setHiddenExternal(externalError);
    setProfileMessage('');
    try {
      await nativeApi('account', token, { action: 'profile', name, phone });
      await onUpdated();
      setProfileMessage('Dein Profil wurde gespeichert.');
    } catch (e) {
      setProfileError((e as Error).message);
    } finally {
      setSaving(false);
    }
  }
  const act = (run: () => unknown) => () => {
    setHiddenExternal(externalError);
    void run();
  };
  const step = profile ? null : f.step;
  const position = stepPosition(f.step, f.mode);
  const resume = flow.hasCurrentChallenge();
  const requestBlocked = !resume && wait > 0;
  const shownError =
    (profile ? profileError : f.error) ||
    (externalError !== hiddenExternal && externalError) ||
    '';
  const message = profile ? profileMessage : f.message;
  return (
    <KeyboardAvoidingView
      style={s.body}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        contentContainerStyle={s.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={s.accountSymbol}>
          <UserRound color={gold} size={30} />
        </View>
        <View style={a.heading}>
          <Label tone="gold">
            {profile
              ? 'DEIN PERSÖNLICHER ZUGANG'
              : `SCHRITT ${position.index} VON ${position.count}`}
          </Label>
          <Title>
            {profile
              ? 'Dein Profil.'
              : step === 'code'
                ? 'Dein Code.'
                : step === 'details'
                  ? 'Deine Angaben.'
                  : f.mode === 'register'
                    ? 'Willkommen.'
                    : 'Schön, dich\nwiederzusehen.'}
          </Title>
          <Subhead>
            {profile
              ? profile.email
              : step === 'code'
                ? `Gib den Code für ${f.email.trim()} ein.`
                : step === 'details'
                  ? `Neues Konto für ${f.email.trim()}.`
                  : 'Dein LUXORÉ-Konto funktioniert in beiden Apps und auf der Website.'}
          </Subhead>
        </View>
        {!profile && !ready && (
          <Banner
            title="Der E-Mail-Zugang wird noch eingerichtet."
            text="Bitte nach der Freischaltung erneut versuchen."
          />
        )}
        {step === 'email' && (
          <>
            <Choice
              label="Anmelden oder neu registrieren"
              options={[
                ['register', 'Registrieren'],
                ['login', 'Anmelden'],
              ]}
              value={f.mode}
              disabled={f.busy}
              onChange={(v) => flow.setMode(v as 'login' | 'register')}
            />
            <TextField
              label="E-Mail"
              value={f.email}
              onChangeText={(v) => {
                flow.setEmail(v);
                edited();
              }}
              keyboardType="email-address"
              autoComplete="email"
              textContentType="emailAddress"
              autoCapitalize="none"
              autoCorrect={false}
              maxLength={254}
              returnKeyType="next"
              onSubmitEditing={act(() => flow.next())}
            />
          </>
        )}
        {step === 'details' && (
          <>
            <TextField
              label="Dein Name"
              value={f.name}
              onChangeText={(v) => {
                flow.setName(v);
                edited();
              }}
              autoComplete="name"
              textContentType="name"
              autoCapitalize="words"
              maxLength={80}
            />
            <TextField
              label="Telefon"
              value={f.phone}
              onChangeText={(v) => {
                flow.setPhone(v);
                edited();
              }}
              keyboardType="phone-pad"
              autoComplete="tel"
              textContentType="telephoneNumber"
              autoCapitalize="none"
              autoCorrect={false}
              maxLength={30}
            />
            {isDriver && (
              <Choice
                label="Profilart"
                options={[
                  ['driver', 'Fahrer'],
                  ['fleet', 'Flottenleiter'],
                ]}
                value={f.kind}
                disabled={f.busy}
                onChange={(v) => flow.setKind(v)}
              />
            )}
            <Pressable
              style={[s.consent, a.tapRow]}
              onPress={() => flow.togglePrivacy()}
              accessibilityRole="checkbox"
              accessibilityState={{ checked: f.privacy }}
            >
              <View
                style={[
                  s.check,
                  f.privacy && { backgroundColor: gold, borderColor: gold },
                ]}
              >
                {f.privacy && <Check color={colors.white} size={17} />}
              </View>
              <Text style={s.consentText} maxFontSizeMultiplier={maxFontScale}>
                Ich habe die Datenschutzinformationen gelesen.
              </Text>
            </Pressable>
            <Button
              variant="text"
              label="Datenschutz öffnen"
              style={a.start}
              onPress={() =>
                void Linking.openURL(companyOrigin + '/datenschutz').catch(
                  () => {},
                )
              }
            />
          </>
        )}
        {step === 'code' && (
          <CodeField
            label="Anmeldecode"
            value={f.code}
            onChange={(v) => {
              setHiddenExternal(externalError);
              flow.setCode(v);
            }}
            autoFocus
          />
        )}
        {profile && (
          <>
            <TextField
              label="Dein Name"
              value={name}
              onChangeText={(v) => {
                setName(v);
                edited();
              }}
              autoComplete="name"
              autoCapitalize="words"
              maxLength={80}
            />
            <TextField
              label="Telefon"
              value={phone}
              onChangeText={(v) => {
                setPhone(v);
                edited();
              }}
              keyboardType="phone-pad"
              autoComplete="tel"
              autoCapitalize="none"
              autoCorrect={false}
              maxLength={30}
            />
          </>
        )}
        {!!shownError && (
          <Banner tone="error" title="Hinweis" text={shownError} />
        )}
        {!!message && <Banner tone="success" title={message} />}
        {!profile && !!externalNotice && (
          <Banner tone="success" title={externalNotice} />
        )}
        {profile ? (
          <Button
            label="Profil speichern"
            loading={saving}
            onPress={() => void saveProfile()}
          />
        ) : step === 'code' ? (
          <>
            <Button
              label="Code bestätigen"
              loading={f.busy}
              disabled={!ready}
              onPress={act(() => flow.verify())}
            />
            <Button
              variant="secondary"
              label={requestLabel(wait, 'Neuen Code anfordern')}
              disabled={f.busy || wait > 0 || !ready}
              onPress={act(() => flow.resend())}
            />
          </>
        ) : (
          <Button
            label={
              step === 'email' && f.mode === 'register'
                ? 'Weiter'
                : resume
                  ? 'Weiter zur Code-Eingabe'
                  : requestLabel(wait, 'Code per E-Mail erhalten')
            }
            loading={f.busy}
            disabled={
              !ready ||
              (!(step === 'email' && f.mode === 'register') && requestBlocked)
            }
            onPress={act(() => flow.next())}
          />
        )}
        {(step === 'details' || step === 'code') && (
          <Button
            variant="text"
            label="Zurück"
            icon={ArrowLeft}
            disabled={f.busy}
            style={a.start}
            onPress={() => flow.back()}
          />
        )}
        {profile && (
          <Button
            variant="text"
            label={logoutBusy && !deleting ? 'Wird abgemeldet …' : 'Abmelden'}
            disabled={logoutBusy}
            style={a.start}
            onPress={() => void onLogout()}
          />
        )}
        {profile && (
          <Pressable
            disabled={logoutBusy}
            onPress={() => setDeleting((v) => !v)}
            accessibilityRole="button"
            accessibilityState={{ expanded: deleting }}
            style={a.tap}
          >
            <Text
              style={[s.link, { color: colors.danger }]}
              maxFontSizeMultiplier={maxFontScale}
            >
              Konto löschen
            </Text>
          </Pressable>
        )}
        {profile && deleting && (
          <View style={s.deletion}>
            <Text style={s.rowTitle}>Konto löschen</Text>
            <Text style={s.deletionText}>
              Mit deiner Bestätigung wird dein LUXORÉ-Konto sofort gesperrt und
              zur Löschung vorgemerkt. Du wirst überall abgemeldet – in beiden
              Apps und auf der Website. Vorgemerkte Reservierungen werden
              storniert.
            </Text>
            <Text style={s.deletionText}>
              Die endgültige Löschung deiner Daten nehmen wir anschließend vor.
              Fahrt- und Zahlungsbelege mit gesetzlicher Aufbewahrungspflicht
              bleiben erhalten. Auf diesem Gerät werden deine Anmeldung und die
              gespeicherten App-Daten entfernt.
            </Text>
            <Text style={s.deletionText}>
              {isDriver
                ? 'Vorher bitte laufende Fahrten beenden, offene Fahrten kassieren und die Schicht pausieren.'
                : 'Vorher bitte eine laufende Fahrt beenden oder stornieren.'}{' '}
              Die Sperrung lässt sich in der App nicht rückgängig machen.
            </Text>
            {!!externalError && (
              <Text
                accessibilityRole="alert"
                style={s.error}
                maxFontSizeMultiplier={maxFontScale}
              >
                {externalError}
              </Text>
            )}
            <SwipeAction
              label="Löschung anfordern"
              busy={logoutBusy}
              onComplete={() => void onDelete()}
            />
            <Button
              variant="text"
              label="Abbrechen"
              disabled={logoutBusy}
              style={a.start}
              onPress={() => setDeleting(false)}
            />
          </View>
        )}
        {children}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

/** Zwei gleichrangige Möglichkeiten nebeneinander (ohne Animation). */
function Choice({
  label,
  options,
  value,
  disabled,
  onChange,
}: {
  label: string;
  options: [string, string][];
  value: string;
  disabled: boolean;
  onChange: (value: string) => void;
}) {
  return (
    <View style={s.segment} accessibilityRole="tablist" accessibilityLabel={label}>
      {options.map(([key, text]) => (
        <Pressable
          key={key}
          disabled={disabled}
          style={[s.segmentItem, value === key && s.segmentActive]}
          onPress={() => onChange(key)}
          accessibilityRole="tab"
          accessibilityState={{ selected: value === key, disabled }}
        >
          <Text style={s.segmentText} maxFontSizeMultiplier={maxFontScale}>
            {text}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}

const a = StyleSheet.create({
  heading: { gap: space[2] },
  tap: { minHeight: layout.tap, justifyContent: 'center' },
  tapRow: { minHeight: layout.tap },
  start: { alignSelf: 'flex-start', paddingHorizontal: 0 },
});
