import React from 'react';
import {
  ActivityIndicator,
  Image,
  Pressable,
  ScrollView,
  Text,
  View,
} from 'react-native';
import {
  ArrowRight,
  CalendarDays,
  CarFront,
  ChevronRight,
  Mail,
  MapPinned,
  ShieldCheck,
  UserRound,
  Users,
} from 'lucide-react-native';
import type { NativeAccount } from '../account-client';
import { driverVariant as isDriver } from '../build-config';
import { colors } from '../theme';
import Shortcut from './Shortcut';
import { gold, ink, s } from './styles';

/**
 * Startansicht: Begrüßung, Hauptknopf und Schnellzugriffe. Angemeldete Fahrer
 * sehen stattdessen den Fahrerbereich (`DriverScreen`).
 */
export default function HomeScreen({
  profile,
  admin,
  loaded,
  error,
  tracking,
  hasPosition,
  onStart,
  onPlan,
  onAccount,
  onDisposition,
  onOperator,
  onRetry,
}: {
  profile: NativeAccount | null;
  admin: boolean;
  loaded: boolean;
  error: string;
  tracking: boolean;
  hasPosition: boolean;
  /** Hauptknopf: Buchung (Kunde) bzw. Fahrerbereich/Anmeldung (Fahrer). */
  onStart: () => void;
  /** Kunde: Fahrt im Voraus planen. */
  onPlan: () => void;
  onAccount: () => void;
  onDisposition: () => void;
  onOperator: () => void;
  onRetry: () => void;
}) {
  return (
    <ScrollView
      style={s.body}
      contentContainerStyle={s.content}
      showsVerticalScrollIndicator={false}
    >
      <Text style={s.eyebrow}>
        {isDriver ? 'DEIN TAG. DEINE FAHRTEN.' : 'FRANKFURT & RHEIN-MAIN'}
      </Text>
      <Text style={s.title}>
        {profile
          ? `Hallo, ${profile.name.split(' ')[0]}.`
          : isDriver
            ? 'Bereit für\ndeinen Tag.'
            : 'Entspannt\nankommen.'}
      </Text>
      <Text style={s.subtitle}>
        {isDriver
          ? 'Deine Schicht, dein Fahrzeug und deine Fahrten an einem Ort.'
          : 'Dein Chauffeur. Dein Moment. Persönlich, komfortabel und verlässlich.'}
      </Text>
      <View style={s.hero}>
        <View style={s.heroTop}>
          <Text style={s.heroLabel}>
            {isDriver ? 'DEIN FAHRERBEREICH' : 'DEINE NÄCHSTE FAHRT'}
          </Text>
          <ShieldCheck size={21} color={colors.goldLight} />
        </View>
        <Image
          source={
            isDriver
              ? require('../../assets/business.png')
              : require('../../assets/first-class.png')
          }
          style={s.car}
          resizeMode="contain"
        />
        <Pressable
          style={s.heroAction}
          onPress={onStart}
          accessibilityRole="button"
        >
          <Text style={s.heroActionText}>
            {isDriver
              ? profile
                ? 'Schicht & Fahrten öffnen'
                : 'Als Fahrer anmelden'
              : 'Wohin möchtest du?'}
          </Text>
          <ArrowRight color={ink} size={21} />
        </Pressable>
      </View>
      {isDriver && tracking && (
        <View style={s.note}>
          <MapPinned color={gold} size={21} />
          <Text style={s.noteText}>
            {hasPosition
              ? 'Standortdienst aktiv. Dein letzter Standort ist gespeichert.'
              : 'Standortdienst aktiv. Der GPS-Status wird im Fahrerbereich geprüft.'}
          </Text>
        </View>
      )}
      <View style={s.twoColumns}>
        <Shortcut
          icon={isDriver ? CarFront : CalendarDays}
          title={isDriver ? 'Fahrzeug' : 'Fahrt planen'}
          detail={isDriver ? 'Flotte & Wechsel' : 'Im Voraus anfragen'}
          onPress={isDriver ? onStart : onPlan}
        />
        <Shortcut
          icon={isDriver ? Users : UserRound}
          title={isDriver ? 'Disposition' : 'Mein Konto'}
          detail={isDriver ? 'Fahrten & Team' : 'Profil & Zugang'}
          onPress={isDriver ? onDisposition : onAccount}
        />
      </View>
      {!profile && (
        <Pressable style={s.row} onPress={onAccount}>
          <Mail color={gold} size={23} />
          <View style={s.rowCopy}>
            <Text style={s.rowTitle}>Dein persönlicher Zugang</Text>
            <Text style={s.rowDetail}>
              Mit E-Mail anmelden oder registrieren
            </Text>
          </View>
          <ChevronRight color={ink} size={20} />
        </Pressable>
      )}
      {admin && (
        <Pressable style={s.row} onPress={onOperator}>
          <ShieldCheck color={gold} size={23} />
          <View style={s.rowCopy}>
            <Text style={s.rowTitle}>Betreiberübersicht</Text>
            <Text style={s.rowDetail}>Profile, Freigaben und Gesamtbetrieb</Text>
          </View>
          <ChevronRight color={ink} size={20} />
        </Pressable>
      )}
      {!loaded && <ActivityIndicator color={gold} />}
      {!!error && (
        <View style={s.errorBox}>
          <Text style={s.error}>{error}</Text>
          <Pressable hitSlop={4} onPress={onRetry} accessibilityRole="button">
            <Text style={s.link}>Verbindung erneut prüfen</Text>
          </Pressable>
        </View>
      )}
    </ScrollView>
  );
}
