import * as SecureStore from 'expo-secure-store';

export const companyOrigin = 'https://luxoreride.de';
const sessionKey = 'luxore-account-v1';
export type NativeAccount = {
  id: string;
  email: string;
  name: string;
  phone: string;
  kind: string;
};
export type AccountState = {
  account: NativeAccount | null;
  registrationReady: boolean;
  isAdmin: boolean;
};
export class NativeApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}
export async function storedSession() {
  const value = await SecureStore.getItemAsync(sessionKey);
  return value && /^[a-f0-9]{64}$/.test(value) ? value : null;
}
export async function saveSession(token: string) {
  if (!/^[a-f0-9]{64}$/.test(token))
    throw new Error('Ungültige Anmeldeantwort.');
  await SecureStore.setItemAsync(sessionKey, token);
}
export async function forgetSession() {
  await SecureStore.deleteItemAsync(sessionKey);
}
export async function nativeApi<T>(
  path: string,
  token: string | null,
  body?: unknown,
): Promise<T> {
  if (!/^[a-z-]+$/.test(path)) throw new Error('Ungültige Anfrage.');
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(companyOrigin + '/api/mobility/' + path, {
      method: body === undefined ? 'GET' : 'POST',
      credentials: 'omit',
      redirect: 'error',
      signal: controller.signal,
      headers: {
        Origin: companyOrigin,
        'X-Luxore-Client': 'native-v1',
        ...(token ? { Authorization: 'Bearer ' + token } : {}),
        ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    const value = await response.json();
    if (!response.ok)
      throw new NativeApiError(
        value.error || 'Anfrage fehlgeschlagen.',
        response.status,
      );
    return value as T;
  } catch (error) {
    if (controller.signal.aborted)
      throw new Error(
        'Die Verbindung dauert zu lange. Bitte erneut versuchen.',
      );
    if (error instanceof NativeApiError) throw error;
    throw new Error(
      'Keine Verbindung zu Luxóre. Bitte Internetverbindung prüfen.',
    );
  } finally {
    clearTimeout(timeout);
  }
}
