import * as SecureStore from 'expo-secure-store';

export const companyOrigin = 'https://luxoreride.de';
const sessionKey = 'luxore-account-v1';
const profileKey = 'luxore-account-profile-v1';
export type NativeAccount = {
  id: string;
  email: string;
  name: string;
  phone: string;
  kind: string;
};
export type AccountState = {
  account: NativeAccount | null;
  registrationReady: boolean;
  isAdmin: boolean;
};
export class NativeApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}
export class NativeRequestAborted extends Error {
  constructor() {
    super('Anfrage wurde abgebrochen.');
    this.name = 'AbortError';
  }
}
/**
 * The server does not know this route yet (HTML 404 of an older deployment,
 * never a JSON answer of an existing route). Deliberately not a
 * `NativeApiError`: callers that judge a status keep their behaviour.
 */
export const routeMissingText =
  'Diese Funktion wird mit dem nächsten Server-Update freigeschaltet.';
export class NativeRouteMissingError extends Error {
  readonly routeMissing = true;
  constructor() {
    super(routeMissingText);
    this.name = 'NativeRouteMissingError';
  }
}
/** The request left the device; the server may still complete it. */
export class NativeTimeoutError extends Error {
  constructor() {
    super('Die Verbindung dauert zu lange. Bitte erneut versuchen.');
  }
}
export async function storedSession() {
  const value = await SecureStore.getItemAsync(sessionKey);
  return value && /^[a-f0-9]{64}$/.test(value) ? value : null;
}
export async function saveSession(token: string) {
  if (!/^[a-f0-9]{64}$/.test(token))
    throw new Error('Ungültige Anmeldeantwort.');
  await SecureStore.setItemAsync(sessionKey, token);
}
export async function forgetSession() {
  await SecureStore.deleteItemAsync(sessionKey);
  await SecureStore.deleteItemAsync(profileKey);
}
/**
 * After a confirmed account deletion: remove this app's remaining protected
 * entries. Best effort and bounded – it must never keep the user signed in.
 */
export async function forgetDeviceData(keys: string[]) {
  let timer: ReturnType<typeof setTimeout> | undefined;
  await Promise.race([
    Promise.all(
      keys.map((key) => SecureStore.deleteItemAsync(key).catch(() => {})),
    ),
    new Promise<void>((resolve) => {
      timer = setTimeout(resolve, 8000);
    }),
  ]);
  clearTimeout(timer);
}
export async function cacheProfile(token: string, account: NativeAccount) {
  // A response from an older sign-in must never restore its profile after logout.
  if ((await storedSession()) !== token) return;
  await SecureStore.setItemAsync(
    profileKey,
    JSON.stringify({ token, account }),
  );
}
export async function cachedProfile(
  token: string | null,
): Promise<NativeAccount | null> {
  if (!token) return null;
  try {
    const cached = JSON.parse(
      (await SecureStore.getItemAsync(profileKey)) || 'null',
    );
    const account = cached?.account;
    return cached?.token === token &&
      typeof account?.id === 'string' &&
      typeof account?.name === 'string' &&
      typeof account?.email === 'string' &&
      typeof account?.phone === 'string' &&
      typeof account?.kind === 'string'
      ? account
      : null;
  } catch {
    return null;
  }
}
export async function nativeApi<T>(
  path: string,
  token: string | null,
  body?: unknown,
  query?: Record<string, string>,
  signal?: AbortSignal,
  timeoutMs = 15000,
): Promise<T> {
  if (!/^[a-z-]+$/.test(path)) throw new Error('Ungültige Anfrage.');
  if (signal?.aborted) throw new NativeRequestAborted();
  const controller = new AbortController();
  const cancelled = () => controller.abort();
  signal?.addEventListener('abort', cancelled, { once: true });
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const search = query ? '?' + new URLSearchParams(query) : '';
    const response = await fetch(
      companyOrigin + '/api/mobility/' + path + search,
      {
        method: body === undefined ? 'GET' : 'POST',
        credentials: 'omit',
        redirect: 'error',
        signal: controller.signal,
        headers: {
          Origin: companyOrigin,
          'X-Luxore-Client': 'native-v1',
          ...(token ? { Authorization: 'Bearer ' + token } : {}),
          ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
        },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      },
    );
    if (signal?.aborted) throw new NativeRequestAborted();
    let value;
    try {
      value = await response.json();
    } catch (error) {
      if (response.status === 404 && !controller.signal.aborted)
        throw new NativeRouteMissingError();
      throw error;
    }
    if (signal?.aborted) throw new NativeRequestAborted();
    if (!response.ok)
      throw new NativeApiError(
        value.error || 'Anfrage fehlgeschlagen.',
        response.status,
      );
    return value as T;
  } catch (error) {
    if (signal?.aborted) throw new NativeRequestAborted();
    if (controller.signal.aborted) throw new NativeTimeoutError();
    if (
      error instanceof NativeApiError ||
      error instanceof NativeRouteMissingError
    )
      throw error;
    throw new Error(
      'Keine Verbindung zu LUXORÉ. Bitte Internetverbindung prüfen.',
    );
  } finally {
    clearTimeout(timeout);
    signal?.removeEventListener('abort', cancelled);
  }
}
