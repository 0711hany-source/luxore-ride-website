import * as SecureStore from 'expo-secure-store';

export const companyOrigin = 'https://luxoreride.de';
const sessionKey = 'luxore-account-v1';
const profileKey = 'luxore-account-profile-v1';
export type NativeAccount = {
  id: string;
  email: string;
  name: string;
  phone: string;
  kind: string;
};
export type AccountState = {
  account: NativeAccount | null;
  registrationReady: boolean;
  isAdmin: boolean;
};
export class NativeApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}
export class NativeRequestAborted extends Error {
  constructor() {
    super('Anfrage wurde abgebrochen.');
    this.name = 'AbortError';
  }
}
export async function storedSession() {
  const value = await SecureStore.getItemAsync(sessionKey);
  return value && /^[a-f0-9]{64}$/.test(value) ? value : null;
}
export async function saveSession(token: string) {
  if (!/^[a-f0-9]{64}$/.test(token))
    throw new Error('Ungültige Anmeldeantwort.');
  await SecureStore.setItemAsync(sessionKey, token);
}
export async function forgetSession() {
  await SecureStore.deleteItemAsync(sessionKey);
  await SecureStore.deleteItemAsync(profileKey);
}
export async function cacheProfile(token: string, account: NativeAccount) {
  // A response from an older sign-in must never restore its profile after logout.
  if ((await storedSession()) !== token) return;
  await SecureStore.setItemAsync(
    profileKey,
    JSON.stringify({ token, account }),
  );
}
export async function cachedProfile(
  token: string | null,
): Promise<NativeAccount | null> {
  if (!token) return null;
  try {
    const cached = JSON.parse(
      (await SecureStore.getItemAsync(profileKey)) || 'null',
    );
    const account = cached?.account;
    return cached?.token === token &&
      typeof account?.id === 'string' &&
      typeof account?.name === 'string' &&
      typeof account?.email === 'string' &&
      typeof account?.phone === 'string' &&
      typeof account?.kind === 'string'
      ? account
      : null;
  } catch {
    return null;
  }
}
export async function nativeApi<T>(
  path: string,
  token: string | null,
  body?: unknown,
  query?: Record<string, string>,
  signal?: AbortSignal,
): Promise<T> {
  if (!/^[a-z-]+$/.test(path)) throw new Error('Ungültige Anfrage.');
  if (signal?.aborted) throw new NativeRequestAborted();
  const controller = new AbortController();
  const cancelled = () => controller.abort();
  signal?.addEventListener('abort', cancelled, { once: true });
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const search = query ? '?' + new URLSearchParams(query) : '';
    const response = await fetch(
      companyOrigin + '/api/mobility/' + path + search,
      {
        method: body === undefined ? 'GET' : 'POST',
        credentials: 'omit',
        redirect: 'error',
        signal: controller.signal,
        headers: {
          Origin: companyOrigin,
          'X-Luxore-Client': 'native-v1',
          ...(token ? { Authorization: 'Bearer ' + token } : {}),
          ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
        },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      },
    );
    if (signal?.aborted) throw new NativeRequestAborted();
    const value = await response.json();
    if (signal?.aborted) throw new NativeRequestAborted();
    if (!response.ok)
      throw new NativeApiError(
        value.error || 'Anfrage fehlgeschlagen.',
        response.status,
      );
    return value as T;
  } catch (error) {
    if (signal?.aborted) throw new NativeRequestAborted();
    if (controller.signal.aborted)
      throw new Error(
        'Die Verbindung dauert zu lange. Bitte erneut versuchen.',
      );
    if (error instanceof NativeApiError) throw error;
    throw new Error(
      'Keine Verbindung zu Luxóre. Bitte Internetverbindung prüfen.',
    );
  } finally {
    clearTimeout(timeout);
    signal?.removeEventListener('abort', cancelled);
  }
}
