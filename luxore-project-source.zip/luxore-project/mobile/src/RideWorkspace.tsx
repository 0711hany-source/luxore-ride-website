import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  AppState,
  BackHandler,
  Linking,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { driverVariant } from './build-config';
import * as Location from 'expo-location';
import { testAlert } from './offer-alerts';
import {
  foregroundPermission,
  locationStatus,
  point,
  startLocation,
  stopLocation,
  resumeLocation,
  type Position,
  type Credential,
} from './location-service';
import { WebView } from 'react-native-webview';
import { LocationRequest, locationDeadline } from './location-request';
import { newestNativePosition } from './position-cache';
import { WebViewRecovery } from './webview-recovery';
import { webviewSessionSource } from './webview-session';

const origin = 'https://luxoreride.de';

function external(url: string) {
  if (/^(https:\/\/|tel:\+?[0-9]|mailto:)/i.test(url))
    void Linking.openURL(url).catch(() => {});
}
export default function RideWorkspace({
  path,
  sessionToken,
  onAccount,
  active,
}: {
  path: string;
  sessionToken: string | null;
  onAccount: () => void;
  active: boolean;
}) {
  const startUrl = origin + path;
  const driver = driverVariant && path === '/mobile/driver';
  const source = useMemo(
    () => webviewSessionSource(path, sessionToken),
    [path, sessionToken],
  );
  const web = useRef<WebView>(null);
  const canBack = useRef(false);
  const latest = useRef<Position | null>(null);
  const locationBusy = useRef(false);
  function emit(data: object) {
    const encoded = JSON.stringify(data).replace(/</g, '\\u003c');
    web.current?.injectJavaScript(
      `window.dispatchEvent(new CustomEvent('luxore-location',{detail:${encoded}}));true;`,
    );
  }
  function receivePosition(value: unknown) {
    latest.current = newestNativePosition(latest.current, value);
    return latest.current;
  }
  async function syncStatus(requestId?: string, resume = false) {
    const status = await (resume ? resumeLocation() : locationStatus());
    if ('position' in status) receivePosition(status.position);
    emit({ requestId, status, position: latest.current });
  }
  useEffect(() => {
    if (!driver) return;
    let closed = false;
    let subscription: Location.LocationSubscription | undefined;
    const requests = new LocationRequest();
    const locate = async () => {
      if (closed || AppState.currentState !== 'active') return;
      const request = requests.begin();
      subscription?.remove();
      subscription = undefined;
      try {
        await foregroundPermission();
        if (closed || !requests.isCurrent(request)) return;
        const cached = await Location.getLastKnownPositionAsync({
          maxAge: 10000,
        });
        if (closed || !requests.isCurrent(request)) return;
        if (cached) {
          receivePosition(point(cached));
          emit({ position: latest.current });
        }
        if (!subscription) {
          const watch = await Location.watchPositionAsync(
            {
              accuracy: Location.Accuracy.BestForNavigation,
              timeInterval: 1000,
              distanceInterval: 0,
            },
            (value) => {
              if (closed || !requests.isCurrent(request)) return;
              receivePosition(point(value));
              emit({ position: latest.current });
            },
          );
          if (closed || !requests.isCurrent(request)) watch.remove();
          else subscription = watch;
        }
        if (closed || !requests.isCurrent(request)) return;
        const fresh = await locationDeadline(
          Location.getCurrentPositionAsync({
            accuracy: Location.Accuracy.BestForNavigation,
          }),
          request.signal,
          15000,
        );
        if (!closed && requests.isCurrent(request)) {
          receivePosition(point(fresh));
          emit({ position: latest.current });
        }
      } catch (error) {
        if (!closed && requests.isCurrent(request) && !latest.current)
          emit({ error: (error as Error).message });
      }
    };
    void locate();
    const state = AppState.addEventListener('change', (value) => {
      if (value === 'active') {
        void syncStatus(undefined, true).catch(() => {});
        void locate();
      } else {
        requests.cancel();
        subscription?.remove();
        subscription = undefined;
      }
    });
    return () => {
      closed = true;
      requests.cancel();
      subscription?.remove();
      state.remove();
    };
  }, [driver]);
  const [stopMessage, setStopMessage] = useState('');
  const [stopping, setStopping] = useState(false);
  const [failed, setFailed] = useState(false);
  const [loading, setLoading] = useState(true);
  const [renderer, setRenderer] = useState(0);
  const recovery = useRef(new WebViewRecovery());
  useEffect(() => {
    if (!loading || failed) return;
    const timeout = setTimeout(() => {
      setLoading(false);
      setFailed(true);
    }, 20000);
    return () => clearTimeout(timeout);
  }, [loading, failed, renderer]);
  useEffect(() => {
    const listener = BackHandler.addEventListener('hardwareBackPress', () => {
      if (!active || !canBack.current) return false;
      web.current?.goBack();
      return true;
    });
    return () => listener.remove();
  }, [active]);
  return (
    <View style={styles.root}>
      <StatusBar style="dark" />
      <WebView
        key={renderer}
        ref={web}
        source={source}
        style={styles.web}
        originWhitelist={['https://*', 'tel:*', 'mailto:*']}
        onShouldStartLoadWithRequest={(request) => {
          try {
            const url = new URL(request.url);
            if (url.origin === origin && url.pathname === '/konto') {
              onAccount();
              return false;
            }
            if (url.origin === origin) return true;
          } catch {
            return false;
          }
          external(request.url);
          return false;
        }}
        onOpenWindow={(event) => external(event.nativeEvent.targetUrl)}
        onNavigationStateChange={(state) => {
          canBack.current = state.canGoBack;
        }}
        injectedJavaScriptBeforeContentLoaded={
          driver ? 'window.LuxoreNativeLocation=true;true;' : undefined
        }
        onMessage={async (event) => {
          if (!driver) return;
          let message: {
            type?: string;
            action?: string;
            requestId?: string;
            credential?: Credential;
          };
          try {
            const url = new URL(event.nativeEvent.url);
            if (url.origin !== origin || url.pathname !== '/mobile/driver')
              return;
            message = JSON.parse(event.nativeEvent.data);
            if (
              message.type !== 'luxore-location' ||
              typeof message.requestId !== 'string'
            )
              return;
          } catch {
            return;
          }
          try {
            if (message.action === 'status') {
              await syncStatus(message.requestId);
            } else if (message.action === 'test-alert') {
              await testAlert();
              emit({
                requestId: message.requestId,
                status: await locationStatus(),
              });
            } else if (message.action === 'alert-settings') {
              await Linking.openSettings();
              emit({ requestId: message.requestId });
            } else if (message.action === 'locate') {
              await foregroundPermission();
              receivePosition(
                point(
                  await Location.getCurrentPositionAsync({
                    accuracy: Location.Accuracy.BestForNavigation,
                  }),
                ),
              );
              emit({
                requestId: message.requestId,
                position: latest.current,
              });
            } else if (
              message.action === 'start' ||
              message.action === 'stop'
            ) {
              if (locationBusy.current)
                throw new Error('Standortfreigabe wird gerade geändert.');
              locationBusy.current = true;
              try {
                if (message.action === 'start' && message.credential)
                  emit({
                    requestId: message.requestId,
                    status: await startLocation(message.credential),
                  });
                else if (message.action === 'stop') {
                  await stopLocation();
                  emit({
                    requestId: message.requestId,
                    status: { active: false },
                  });
                } else throw new Error('Standortfreigabe fehlt.');
              } finally {
                locationBusy.current = false;
              }
            }
          } catch (error) {
            emit({
              requestId: message.requestId,
              error: (error as Error).message,
            });
          }
        }}
        scalesPageToFit={false}
        setBuiltInZoomControls={false}
        setDisplayZoomControls={false}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        overScrollMode="never"
        bounces={false}
        geolocationEnabled
        domStorageEnabled
        javaScriptEnabled
        thirdPartyCookiesEnabled={false}
        mixedContentMode="never"
        allowFileAccess={false}
        allowFileAccessFromFileURLs={false}
        allowUniversalAccessFromFileURLs={false}
        cacheEnabled={false}
        cacheMode="LOAD_NO_CACHE"
        webviewDebuggingEnabled={false}
        onLoadStart={() => {
          setLoading(true);
          setFailed(false);
        }}
        onLoadEnd={() => {
          setLoading(false);
          if (driver) {
            web.current?.injectJavaScript(
              'window.LuxoreNativeLocation=true;true;',
            );
            emit({ position: latest.current });
            void syncStatus().catch(() => {});
          }
        }}
        onError={() => {
          setFailed(true);
          setLoading(false);
        }}
        onHttpError={(event) => {
          if (
            (event.nativeEvent.url === startUrl ||
              event.nativeEvent.url === source.uri) &&
            event.nativeEvent.statusCode >= 400
          )
            setFailed(true);
        }}
        onRenderProcessGone={() => {
          // Android requires a new WebView after its renderer was killed.
          // Native tracking and the device cookie/session survive this replacement.
          canBack.current = false;
          const restore = recovery.current.crashed();
          setFailed(!restore);
          setLoading(restore);
          if (restore) setRenderer((value) => value + 1);
        }}
      />
      {loading && !failed && (
        <View style={styles.overlay}>
          <ActivityIndicator color="#be9857" />
          <Text style={styles.message}>Verbindung zu LUXORÉ …</Text>
        </View>
      )}
      {failed && (
        <View style={styles.overlay}>
          <Text style={styles.title}>Verbindung unterbrochen</Text>
          <Text style={styles.message}>
            Prüfe deine Internetverbindung. Deine gespeicherten Fahrten bleiben
            erhalten.
          </Text>
          <Pressable
            style={styles.button}
            onPress={() => {
              setFailed(false);
              if (recovery.current.retry()) setRenderer((value) => value + 1);
              else web.current?.reload();
            }}
          >
            <Text style={styles.buttonText}>Erneut verbinden</Text>
          </Pressable>
          {driver && (
            <Pressable
              disabled={stopping}
              onPress={() => {
                setStopping(true);
                void stopLocation()
                  .then(() => setStopMessage('Standortübertragung beendet.'))
                  .catch(() =>
                    setStopMessage(
                      'Bitte Standort in den Android-Einstellungen deaktivieren.',
                    ),
                  )
                  .finally(() => setStopping(false));
              }}
            >
              <Text style={styles.message}>
                {stopping ? 'Wird beendet …' : 'Standortübertragung beenden'}
              </Text>
            </Pressable>
          )}
          {!!stopMessage && <Text style={styles.message}>{stopMessage}</Text>}
        </View>
      )}
    </View>
  );
}
const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  web: { flex: 1, backgroundColor: '#fff' },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  brand: {
    color: '#d5b77b',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 2,
  },
  caption: { color: '#ddd', fontSize: 12 },
  overlay: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
    gap: 18,
  },
  title: { color: '#191a1c', fontSize: 23, fontWeight: '600' },
  message: { color: '#666', fontSize: 16, lineHeight: 24, textAlign: 'center' },
  button: {
    paddingHorizontal: 24,
    paddingVertical: 16,
    backgroundColor: '#d5b77b',
    borderRadius: 8,
  },
  buttonText: { color: '#101216', fontWeight: '700', fontSize: 16 },
});
