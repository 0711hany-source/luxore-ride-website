import React, { useState } from 'react';
import {
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { colors, layout, maxFontScale, radii, space, typography } from '../theme';

/**
 * Mehrzeiliger Kommentar. In der Liste steht nur eine Vorschau; geschrieben
 * wird in einem eigenen Fenster mit dem Textfeld ganz oben. So liegt das Feld
 * nie unter der Tastatur – unabhängig davon, wo die Vorschau auf dem
 * Bildschirm steht und ob das Gerät den Inhalt bei offener Tastatur verschiebt.
 */
export default function CommentField({
  label,
  value,
  onChangeText,
  maxLength,
  editable = true,
  hint,
}: {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  maxLength: number;
  editable?: boolean;
  hint?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <View style={s.box}>
      <Text maxFontSizeMultiplier={maxFontScale} style={s.label}>
        {label}
      </Text>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={`${label}. ${value ? value : 'Noch leer'}. Zum Schreiben tippen.`}
        accessibilityState={{ disabled: !editable }}
        disabled={!editable}
        onPress={() => setOpen(true)}
        style={[s.preview, !editable && s.disabled]}
      >
        <Text
          maxFontSizeMultiplier={maxFontScale}
          numberOfLines={3}
          style={[s.text, !value && s.placeholder]}
        >
          {value || 'Tippen, um einen Kommentar zu schreiben'}
        </Text>
      </Pressable>
      {!!hint && (
        <Text maxFontSizeMultiplier={maxFontScale} style={s.hint}>
          {hint}
        </Text>
      )}
      <Modal
        visible={open}
        animationType="slide"
        statusBarTranslucent
        onRequestClose={() => setOpen(false)}
      >
        <View style={s.sheet}>
          <View style={s.head}>
            <Text
              accessibilityRole="header"
              maxFontSizeMultiplier={maxFontScale}
              style={s.title}
            >
              {label}
            </Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Kommentar übernehmen und schließen"
              hitSlop={8}
              onPress={() => setOpen(false)}
              style={s.done}
            >
              <Text maxFontSizeMultiplier={maxFontScale} style={s.doneText}>
                Fertig
              </Text>
            </Pressable>
          </View>
          <TextInput
            accessibilityLabel={label}
            autoFocus
            multiline
            value={value}
            onChangeText={onChangeText}
            maxLength={maxLength}
            placeholder="Dein Kommentar"
            placeholderTextColor={colors.gray}
            maxFontSizeMultiplier={maxFontScale}
            style={s.input}
          />
          <Text maxFontSizeMultiplier={maxFontScale} style={s.hint}>
            {value.length}/{maxLength}
            {hint ? ` · ${hint}` : ''}
          </Text>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  box: { gap: space[2] },
  label: { ...typography.footnote, fontWeight: '600', color: colors.ink },
  preview: {
    minHeight: layout.tap + space[4],
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.lineStrong,
    borderRadius: radii.m,
    backgroundColor: colors.white,
    padding: space[3],
  },
  disabled: { opacity: 0.5 },
  text: { ...typography.body, color: colors.ink },
  placeholder: { color: colors.gray },
  hint: { ...typography.footnote, color: colors.textMuted },
  sheet: {
    flex: 1,
    backgroundColor: colors.paper,
    paddingHorizontal: space[4],
    // Unter Statusleiste und Kameraaussparung, auf jedem Gerät.
    paddingTop: 56,
    gap: space[3],
  },
  head: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: layout.tap,
  },
  title: { ...typography.headline, color: colors.ink, flex: 1 },
  done: {
    minHeight: layout.tap,
    minWidth: 88,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radii.m,
    backgroundColor: colors.ink,
    paddingHorizontal: space[4],
  },
  doneText: { ...typography.subhead, fontWeight: '600', color: colors.white },
  input: {
    ...typography.body,
    color: colors.ink,
    height: 150,
    textAlignVertical: 'top',
    borderWidth: 1,
    borderColor: colors.lineStrong,
    borderRadius: radii.m,
    backgroundColor: colors.white,
    padding: space[3],
  },
});
