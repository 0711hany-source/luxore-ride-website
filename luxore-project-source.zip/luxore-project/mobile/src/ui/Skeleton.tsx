import React, { useEffect } from 'react';
import type { DimensionValue, StyleProp, ViewStyle } from 'react-native';
import Animated, {
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';
import { colors, radii } from '../theme';
import { useReduceMotion } from './accessibility';

/** Platzhalter während des Ladens. Pulsiert ruhig; ohne Bewegung statisch. */
export default function Skeleton({
  width = '100%',
  height = 16,
  radius = radii.s,
  style,
}: {
  width?: DimensionValue;
  height?: number;
  radius?: number;
  style?: StyleProp<ViewStyle>;
}) {
  const reduced = useReduceMotion();
  const opacity = useSharedValue(1);
  useEffect(() => {
    if (reduced) {
      cancelAnimation(opacity);
      opacity.value = 1;
      return;
    }
    opacity.value = withRepeat(withTiming(0.45, { duration: 900 }), -1, true);
    return () => cancelAnimation(opacity);
  }, [reduced, opacity]);
  const animated = useAnimatedStyle(() => ({ opacity: opacity.value }));
  return (
    <Animated.View
      accessible
      accessibilityLabel="Wird geladen"
      accessibilityState={{ busy: true }}
      style={[
        { width, height, borderRadius: radius, backgroundColor: colors.line },
        animated,
        style,
      ]}
    />
  );
}
