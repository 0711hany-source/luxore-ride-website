import React from 'react';
import { StyleSheet, View } from 'react-native';
import type { LucideIcon } from 'lucide-react-native';
import { colors, layout } from '../theme';
import Button from './Button';
import { Subhead, Title2 } from './Typography';

/** Leerer Zustand: Symbol, klare Aussage, höchstens eine Aktion. */
export default function EmptyState({
  icon: Icon,
  title,
  text,
  actionLabel,
  onAction,
}: {
  icon?: LucideIcon;
  title: string;
  text?: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  return (
    <View style={s.wrap}>
      {Icon ? (
        <View style={s.symbol}>
          <Icon color={colors.goldText} size={28} strokeWidth={layout.iconStroke} />
        </View>
      ) : null}
      <Title2 center>{title}</Title2>
      {text ? <Subhead center>{text}</Subhead> : null}
      {actionLabel && onAction ? (
        <Button
          label={actionLabel}
          onPress={onAction}
          variant="secondary"
          style={s.action}
        />
      ) : null}
    </View>
  );
}
const s = StyleSheet.create({
  wrap: { alignItems: 'center', gap: 8, paddingVertical: 32, paddingHorizontal: 24 },
  symbol: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.goldWash,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  action: { marginTop: 12, alignSelf: 'stretch' },
});
