import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import {
  CircleAlert,
  CircleCheck,
  Info,
  WifiOff,
  type LucideIcon,
} from 'lucide-react-native';
import { colors, layout, maxFontScale, radii, typography } from '../theme';

export type BannerTone = 'info' | 'success' | 'error' | 'offline';
const tones: Record<
  BannerTone,
  { background: string; text: string; icon: LucideIcon }
> = {
  info: { background: colors.infoWash, text: colors.info, icon: Info },
  success: {
    background: colors.successWash,
    text: colors.success,
    icon: CircleCheck,
  },
  error: {
    background: colors.dangerWash,
    text: colors.danger,
    icon: CircleAlert,
  },
  offline: { background: colors.sand, text: colors.ink, icon: WifiOff },
};

/** Ruhiger Hinweis im Seitenfluss (offline, Fehler, Erfolg). */
export default function Banner({
  title,
  text,
  tone = 'info',
  actionLabel,
  onAction,
}: {
  title: string;
  text?: string;
  tone?: BannerTone;
  actionLabel?: string;
  onAction?: () => void;
}) {
  const t = tones[tone];
  const Icon = t.icon;
  return (
    <View
      style={[s.banner, { backgroundColor: t.background }]}
      accessibilityRole={tone === 'error' ? 'alert' : undefined}
      accessibilityLiveRegion={tone === 'error' ? 'assertive' : 'polite'}
    >
      <Icon color={t.text} size={layout.icon} strokeWidth={layout.iconStroke} />
      <View style={s.texts}>
        <Text
          style={[s.title, { color: t.text }]}
          maxFontSizeMultiplier={maxFontScale}
        >
          {title}
        </Text>
        {text ? (
          <Text style={s.text} maxFontSizeMultiplier={maxFontScale}>
            {text}
          </Text>
        ) : null}
        {actionLabel && onAction ? (
          <Pressable
            onPress={onAction}
            accessibilityRole="button"
            accessibilityLabel={actionLabel}
            style={s.action}
            hitSlop={4}
          >
            <Text
              style={[s.actionText, { color: t.text }]}
              maxFontSizeMultiplier={maxFontScale}
            >
              {actionLabel}
            </Text>
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}
const s = StyleSheet.create({
  banner: {
    flexDirection: 'row',
    gap: 12,
    padding: 16,
    borderRadius: radii.m,
  },
  texts: { flex: 1, gap: 2 },
  title: { ...typography.headline },
  text: { ...typography.subhead, color: colors.ink },
  action: { minHeight: layout.tap, justifyContent: 'center' },
  actionText: {
    ...typography.subhead,
    fontWeight: '600',
    textDecorationLine: 'underline',
  },
});
