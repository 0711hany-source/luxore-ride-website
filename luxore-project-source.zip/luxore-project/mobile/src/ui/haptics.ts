import { Platform } from 'react-native';
import * as Haptics from 'expo-haptics';
import type { HapticName } from '../theme';

// Benannte Haptiken (Konzept 4.1): leicht = Auswahl/Rastpunkt, mittel =
// Wischknopf rastet ein, Erfolg/Warnung/Fehler = Rückmeldung zu einer Aktion.
//
// Android nutzt bewusst `performAndroidHapticsAsync` (View-Haptik des Systems):
// sie braucht KEINE Vibrationsberechtigung. Die Kunden-App sperrt
// `android.permission.VIBRATE` in app.config.ts; der Vibrator-Weg würde dort
// scheitern. Jede Haptik ist rein schmückend und darf nie einen Fehler werfen.
const android: Record<HapticName, Haptics.AndroidHaptics> = {
  light: Haptics.AndroidHaptics.Segment_Tick,
  medium: Haptics.AndroidHaptics.Context_Click,
  success: Haptics.AndroidHaptics.Confirm,
  warning: Haptics.AndroidHaptics.Gesture_End,
  error: Haptics.AndroidHaptics.Reject,
};

async function run(name: HapticName) {
  if (Platform.OS === 'android')
    return Haptics.performAndroidHapticsAsync(android[name]);
  if (Platform.OS !== 'ios') return;
  if (name === 'light')
    return Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  if (name === 'medium')
    return Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  return Haptics.notificationAsync(
    name === 'success'
      ? Haptics.NotificationFeedbackType.Success
      : name === 'warning'
        ? Haptics.NotificationFeedbackType.Warning
        : Haptics.NotificationFeedbackType.Error,
  );
}

/** Löst eine benannte Haptik aus. Schlägt nie fehl und wartet auf nichts. */
export function haptic(name: HapticName): void {
  try {
    run(name).catch(() => {});
  } catch {
    // Gerät ohne Haptik oder Modul nicht vorhanden: still ignorieren.
  }
}
