import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import type { LucideIcon } from 'lucide-react-native';
import { colors, maxFontScale, radii, typography } from '../theme';

export type ChipTone =
  | 'neutral'
  | 'gold'
  | 'success'
  | 'danger'
  | 'info';
const tones: Record<ChipTone, { background: string; text: string }> = {
  neutral: { background: colors.sand, text: colors.textMuted },
  gold: { background: colors.goldWash, text: colors.goldText },
  success: { background: colors.successWash, text: colors.success },
  danger: { background: colors.dangerWash, text: colors.danger },
  info: { background: colors.infoWash, text: colors.info },
};

/** Statusfarben erscheinen nur in Chips; der Text trägt immer die Bedeutung. */
export default function StatusChip({
  label,
  tone = 'neutral',
  icon: Icon,
}: {
  label: string;
  tone?: ChipTone;
  icon?: LucideIcon;
}) {
  const t = tones[tone];
  return (
    <View
      style={[s.chip, { backgroundColor: t.background }]}
      accessible
      accessibilityRole="text"
      accessibilityLabel={`Status: ${label}`}
    >
      {Icon ? <Icon color={t.text} size={14} strokeWidth={2} /> : null}
      <Text
        style={[s.text, { color: t.text }]}
        maxFontSizeMultiplier={maxFontScale}
      >
        {label}
      </Text>
    </View>
  );
}
const s = StyleSheet.create({
  chip: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    minHeight: 28,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: radii.s,
  },
  text: { ...typography.footnote, fontWeight: '600' },
});
