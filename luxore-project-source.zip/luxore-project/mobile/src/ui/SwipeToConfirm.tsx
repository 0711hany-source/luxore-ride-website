import React, { useCallback, useEffect, useMemo, useRef } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { scheduleOnRN } from 'react-native-worklets';
import { ArrowRight } from 'lucide-react-native';
import {
  colors,
  maxFontScale,
  radii,
  springs,
  swipeConfirmThreshold,
  typography,
} from '../theme';
import { useScreenReader } from './accessibility';
import { haptic } from './haptics';

const height = 64,
  inset = 5,
  thumb = height - inset * 2;

/**
 * Wischen zum Bestätigen – Nachfolger von `SwipeAction` für das Neudesign.
 * Der Daumen muss mindestens 90 % des Wegs gezogen und dort losgelassen
 * werden; beim Erreichen der Schwelle gibt es eine mittlere Haptik.
 * Barrierefreiheit: Screenreader-Aktion „Bestätigen“ sowie (nur bei aktivem
 * Screenreader) doppelt tippen und 1 Sekunde halten. Braucht eine
 * `GestureHandlerRootView` als Vorfahren.
 */
export default function SwipeToConfirm({
  label,
  onConfirm,
  disabled,
  busy,
  busyLabel = 'Wird bestätigt …',
  tone = 'gold',
  resetKey,
}: {
  label: string;
  onConfirm: () => void;
  disabled?: boolean;
  /** Während der Server antwortet: Kreisel, keine Geste. Danach Rückstellung. */
  busy?: boolean;
  busyLabel?: string;
  tone?: 'gold' | 'danger';
  /** Ändert sich der Wert, springt der Daumen zurück (z. B. nach Fehler). */
  resetKey?: string | number;
}) {
  const screenReader = useScreenReader();
  const blocked = !!disabled || !!busy;
  const x = useSharedValue(0),
    max = useSharedValue(0),
    armed = useSharedValue(false),
    done = useSharedValue(false);
  const latest = useRef({ onConfirm, blocked });
  useEffect(() => {
    latest.current = { onConfirm, blocked };
  }, [onConfirm, blocked]);
  const confirm = useCallback(() => {
    if (!latest.current.blocked) latest.current.onConfirm();
  }, []);
  useEffect(() => {
    done.value = false;
    armed.value = false;
    x.value = withSpring(0, springs.standard);
  }, [label, busy, resetKey, done, armed, x]);

  const pan = useMemo(
    () =>
      Gesture.Pan()
        .enabled(!blocked)
        .onUpdate((event) => {
          if (done.value) return;
          const next = Math.min(max.value, Math.max(0, event.translationX));
          x.value = next;
          const reached =
            max.value > 0 && next >= max.value * swipeConfirmThreshold;
          if (reached !== armed.value) {
            armed.value = reached;
            if (reached) scheduleOnRN(haptic, 'medium');
          }
        })
        .onEnd((_event, success) => {
          if (done.value) return;
          if (success && armed.value && max.value > 0) {
            done.value = true;
            x.value = withSpring(max.value, springs.standard);
            scheduleOnRN(confirm);
          } else x.value = withSpring(0, springs.standard);
          armed.value = false;
        }),
    [blocked, confirm, x, max, armed, done],
  );

  const thumbStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: x.value }],
  }));
  const fillStyle = useAnimatedStyle(() => ({
    width: x.value + thumb + inset * 2,
  }));
  const labelStyle = useAnimatedStyle(() => ({
    opacity: max.value > 0 ? Math.max(0, 1 - (x.value / max.value) * 1.6) : 1,
  }));
  const danger = tone === 'danger';
  const confirmAccessible = () => {
    if (blocked) return;
    haptic('medium');
    onConfirm();
  };
  return (
    <Pressable
      style={[s.track, danger && s.trackDanger, blocked && s.blocked]}
      onLayout={(event) => {
        max.value = Math.max(
          0,
          event.nativeEvent.layout.width - thumb - inset * 2,
        );
      }}
      accessible
      accessibilityRole="button"
      accessibilityLabel={busy ? busyLabel : label}
      accessibilityHint="Zum Bestätigen vollständig nach rechts wischen. Mit Screenreader: Aktion „Bestätigen“ wählen oder doppelt tippen und eine Sekunde halten."
      accessibilityState={{ disabled: blocked, busy: !!busy }}
      accessibilityActions={[{ name: 'activate', label: 'Bestätigen' }]}
      onAccessibilityAction={(event) => {
        if (event.nativeEvent.actionName === 'activate') confirmAccessible();
      }}
      // Langes Halten bestätigt nur mit Screenreader; sonst gilt allein Wischen.
      onLongPress={screenReader ? confirmAccessible : undefined}
      delayLongPress={1000}
    >
      <Animated.View
        style={[s.fill, danger && s.fillDanger, fillStyle]}
        pointerEvents="none"
      />
      <Animated.View style={[s.labelWrap, labelStyle]} pointerEvents="none">
        <Text
          style={[s.label, danger && s.labelDanger]}
          numberOfLines={2}
          maxFontSizeMultiplier={maxFontScale}
        >
          {busy ? busyLabel : label}
        </Text>
      </Animated.View>
      <GestureDetector gesture={pan}>
        <Animated.View
          style={[s.thumb, danger && s.thumbDanger, thumbStyle]}
          importantForAccessibility="no-hide-descendants"
          accessibilityElementsHidden
        >
          {busy ? (
            <ActivityIndicator color={colors.white} />
          ) : (
            <ArrowRight color={colors.white} size={24} strokeWidth={1.75} />
          )}
        </Animated.View>
      </GestureDetector>
    </Pressable>
  );
}
const s = StyleSheet.create({
  track: {
    height,
    borderRadius: radii.pill,
    backgroundColor: colors.goldWash,
    justifyContent: 'center',
    overflow: 'hidden',
  },
  trackDanger: { backgroundColor: colors.dangerWash },
  blocked: { opacity: 0.5 },
  fill: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    borderRadius: radii.pill,
    backgroundColor: colors.goldLight,
    opacity: 0.45,
  },
  fillDanger: { backgroundColor: colors.danger, opacity: 0.18 },
  labelWrap: {
    paddingLeft: thumb + inset * 2 + 4,
    paddingRight: 16,
    alignItems: 'center',
  },
  label: {
    ...typography.subhead,
    fontWeight: '600',
    color: colors.goldText,
    textAlign: 'center',
  },
  labelDanger: { color: colors.danger },
  thumb: {
    position: 'absolute',
    left: inset,
    top: inset,
    width: thumb,
    height: thumb,
    borderRadius: thumb / 2,
    backgroundColor: colors.inkSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  thumbDanger: { backgroundColor: colors.danger },
});
