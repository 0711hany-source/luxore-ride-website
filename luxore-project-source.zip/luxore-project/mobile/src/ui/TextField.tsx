import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  TextInput,
  View,
  type TextInputProps,
} from 'react-native';
import { colors, maxFontScale, radii, typography } from '../theme';

/** Beschriftetes Eingabefeld mit Hinweis- und Fehlerzeile. */
export default function TextField({
  label,
  hint,
  error,
  style,
  onFocus,
  onBlur,
  ...input
}: Omit<TextInputProps, 'placeholderTextColor'> & {
  label: string;
  hint?: string;
  error?: string;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={s.wrap}>
      <Text style={s.label} maxFontSizeMultiplier={maxFontScale}>
        {label}
      </Text>
      <TextInput
        accessibilityLabel={label}
        accessibilityHint={error || hint}
        maxFontSizeMultiplier={maxFontScale}
        {...input}
        placeholderTextColor={colors.gray}
        onFocus={(event) => {
          setFocused(true);
          onFocus?.(event);
        }}
        onBlur={(event) => {
          setFocused(false);
          onBlur?.(event);
        }}
        style={[
          s.input,
          focused && s.focused,
          !!error && s.invalid,
          input.editable === false && s.readOnly,
          style,
        ]}
      />
      {error ? (
        <Text
          style={s.error}
          accessibilityLiveRegion="polite"
          maxFontSizeMultiplier={maxFontScale}
        >
          {error}
        </Text>
      ) : hint ? (
        <Text style={s.hint} maxFontSizeMultiplier={maxFontScale}>
          {hint}
        </Text>
      ) : null}
    </View>
  );
}
const s = StyleSheet.create({
  wrap: { gap: 6 },
  label: { ...typography.footnote, fontWeight: '600', color: colors.ink },
  input: {
    minHeight: 52,
    borderRadius: radii.m,
    borderWidth: 1,
    borderColor: colors.lineStrong,
    backgroundColor: colors.white,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: typography.body.fontSize,
    color: colors.ink,
  },
  focused: { borderColor: colors.goldText, borderWidth: 2 },
  invalid: { borderColor: colors.danger },
  readOnly: { backgroundColor: colors.sand, color: colors.textMuted },
  hint: { ...typography.footnote, color: colors.textMuted },
  error: { ...typography.footnote, color: colors.danger },
});
