import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Platform, Pressable, StyleSheet, View } from 'react-native';
import { BlurView } from 'expo-blur';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { scheduleOnRN } from 'react-native-worklets';
import {
  settleSheet,
  sheetHeights,
  type SheetStop,
} from '../../../app/mobility/sheet-motion';
import { colors, layout, material, radii, shadow, springs } from '../theme';
import { haptic } from './haptics';

export type { SheetStop };
const order: readonly SheetStop[] = ['peek', 'half', 'full'];
const names: Record<SheetStop, string> = {
  peek: 'klein',
  half: 'mittel',
  full: 'groß',
};

/**
 * Unteres Fenster mit drei Rastpunkten (klein / mittel / groß). Füllt seinen
 * Eltern-Container unten aus und misst dessen Höhe selbst; der Container
 * braucht eine feste Höhe bzw. `flex: 1`, und es muss eine
 * `GestureHandlerRootView` als Vorfahre vorhanden sein.
 *
 * Gezogen wird am Griff und an der Kopfzeile (`header`), damit Scrollen im
 * Inhalt nie mit dem Ziehen kollidiert. Die Rastregeln sind dieselben wie in
 * der Web-App (`app/mobility/sheet-motion.ts`).
 * Barrierefreiheit: Griff antippen wechselt den Rastpunkt; Screenreader-
 * Aktionen „Vergrößern“ / „Verkleinern“.
 */
export default function Sheet({
  children,
  header,
  stop: controlled,
  initialStop = 'half',
  onStopChange,
  heights: custom,
  accessibilityLabel = 'Fenster',
}: {
  children?: React.ReactNode;
  /** Bleibt an jedem Rastpunkt sichtbar und ist ebenfalls Ziehfläche. */
  header?: React.ReactNode;
  /** Gesteuerter Rastpunkt; ohne Angabe verwaltet das Sheet ihn selbst. */
  stop?: SheetStop;
  initialStop?: SheetStop;
  onStopChange?: (stop: SheetStop) => void;
  /** Eigene Höhen je Rastpunkt in Punkten (sonst Regeln der Web-App). */
  heights?: Partial<Record<SheetStop, number>>;
  accessibilityLabel?: string;
}) {
  const [available, setAvailable] = useState(0);
  const [own, setOwn] = useState<SheetStop>(controlled ?? initialStop);
  const stop = controlled ?? own;
  const heights = useMemo(() => {
    const base = sheetHeights(available);
    const full = Math.min(custom?.full ?? base.full, base.full);
    return {
      peek: Math.min(custom?.peek ?? base.peek, full),
      half: Math.min(custom?.half ?? base.half, full),
      full,
    };
  }, [available, custom?.peek, custom?.half, custom?.full]);

  const height = useSharedValue(0),
    start = useSharedValue(0);
  const placed = useRef(false);
  const latest = useRef({ stop, onStopChange, heights });
  useEffect(() => {
    latest.current = { stop, onStopChange, heights };
  }, [stop, onStopChange, heights]);

  // Rastpunkt oder verfügbare Höhe geändert: dorthin federn (erstes Mal ohne
  // Bewegung). „Bewegung reduzieren“ beachtet withSpring selbst.
  useEffect(() => {
    if (available <= 0) return;
    if (!placed.current) {
      placed.current = true;
      height.value = heights[stop];
    } else height.value = withSpring(heights[stop], springs.sheet);
  }, [available, heights, stop, height]);

  const goTo = useCallback(
    (next: SheetStop) => {
      const current = latest.current;
      if (next !== current.stop) {
        haptic('light');
        setOwn(next);
        current.onStopChange?.(next);
      }
      // Auch bei gleichem Rastpunkt zurückfedern (losgelassen zwischen zweien).
      height.value = withSpring(current.heights[next], springs.sheet);
    },
    [height],
  );
  const settle = useCallback(
    (released: number, velocityUp: number) =>
      goTo(settleSheet(released, velocityUp, latest.current.heights)),
    [goTo],
  );
  const step = useCallback(
    (direction: 1 | -1 | 'cycle') => {
      const index = order.indexOf(latest.current.stop);
      const next =
        direction === 'cycle'
          ? order[(index + 1) % order.length]
          : order[Math.max(0, Math.min(order.length - 1, index + direction))];
      goTo(next);
    },
    [goTo],
  );

  const low = heights.peek,
    high = heights.full;
  const pan = useMemo(
    () =>
      Gesture.Pan()
        .enabled(high > 0)
        .activeOffsetY([-6, 6])
        .onStart(() => {
          start.value = height.value;
        })
        .onUpdate((event) => {
          const raw = start.value - event.translationY;
          // Über die Enden hinaus nur mit Widerstand (ein Viertel des Wegs).
          height.value =
            raw > high
              ? high + (raw - high) * 0.25
              : raw < low
                ? low - (low - raw) * 0.25
                : raw;
        })
        .onEnd((event) => {
          // settleSheet erwartet Punkte pro Millisekunde, aufwärts positiv.
          scheduleOnRN(settle, height.value, -event.velocityY / 1000);
        }),
    [high, low, settle, height, start],
  );

  const animated = useAnimatedStyle(() => ({ height: height.value }));
  return (
    <View
      style={StyleSheet.absoluteFill}
      pointerEvents="box-none"
      onLayout={(event) => setAvailable(event.nativeEvent.layout.height)}
    >
      {available > 0 ? (
        <Animated.View style={[s.sheet, animated]}>
          {Platform.OS === 'ios' ? (
            <BlurView
              tint="light"
              intensity={material.blurIntensity}
              style={StyleSheet.absoluteFill}
            />
          ) : null}
          <GestureDetector gesture={pan}>
            <View>
              <Pressable
                style={s.gripArea}
                onPress={() => step('cycle')}
                accessibilityRole="adjustable"
                accessibilityLabel={`${accessibilityLabel}: Größe`}
                accessibilityHint="Antippen wechselt die Größe. Ziehen vergrößert oder verkleinert."
                accessibilityValue={{ text: names[stop] }}
                accessibilityActions={[
                  { name: 'increment', label: 'Vergrößern' },
                  { name: 'decrement', label: 'Verkleinern' },
                  { name: 'activate', label: 'Größe wechseln' },
                ]}
                onAccessibilityAction={(event) => {
                  const action = event.nativeEvent.actionName;
                  step(
                    action === 'increment'
                      ? 1
                      : action === 'decrement'
                        ? -1
                        : 'cycle',
                  );
                }}
              >
                <View style={s.grip} />
              </Pressable>
              {header ? <View style={s.header}>{header}</View> : null}
            </View>
          </GestureDetector>
          <View style={s.content}>{children}</View>
        </Animated.View>
      ) : null}
    </View>
  );
}
const s = StyleSheet.create({
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: radii.xl,
    borderTopRightRadius: radii.xl,
    // iOS: Unschärfe darunter; Android: halbtransparentes Papier als Ersatz.
    backgroundColor:
      Platform.OS === 'ios' ? 'transparent' : material.paperFloating,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderColor: colors.line,
    overflow: Platform.OS === 'ios' ? 'hidden' : 'visible',
    ...shadow.floating,
    // Android: Höhen-Schatten scheint durch halbtransparente Flächen durch.
    elevation: 0,
  },
  gripArea: {
    minHeight: layout.tap,
    alignItems: 'center',
    justifyContent: 'center',
  },
  grip: {
    width: 40,
    height: 5,
    borderRadius: radii.pill,
    backgroundColor: colors.lineStrong,
  },
  header: { paddingHorizontal: layout.screenMargin, paddingBottom: 12 },
  content: { flex: 1, overflow: 'hidden' },
});
