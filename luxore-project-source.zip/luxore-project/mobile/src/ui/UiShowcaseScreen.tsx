import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { CalendarDays, CarFront, Inbox, MapPinned } from 'lucide-react-native';
import { colors, layout, radii, type HapticName } from '../theme';
import Banner from './Banner';
import Button from './Button';
import CodeField from './CodeField';
import Countdown from './Countdown';
import EmptyState from './EmptyState';
import ListRow from './ListRow';
import ProgressSteps from './ProgressSteps';
import SegmentedControl from './SegmentedControl';
import Sheet, { type SheetStop } from './Sheet';
import Skeleton from './Skeleton';
import StatusChip from './StatusChip';
import Stepper from './Stepper';
import SwipeToConfirm from './SwipeToConfirm';
import TextField from './TextField';
import {
  Amount,
  Body,
  Caption,
  Headline,
  Label,
  LargeTitle,
  Subhead,
  Title,
  Title2,
} from './Typography';
import { haptic } from './haptics';

// Musterseite des Neudesigns (Etappe 0). Alle Inhalte sind Beispiele ohne
// Bezug zu echten Fahrten, Preisen oder Personen; nichts wird gesendet.
const pages = [
  { key: 'parts', label: 'Bausteine' },
  { key: 'gestures', label: 'Gesten' },
  { key: 'sheet', label: 'Fenster' },
] as const;
type Page = (typeof pages)[number]['key'];
const haptics: readonly { name: HapticName; label: string }[] = [
  { name: 'light', label: 'Leicht' },
  { name: 'medium', label: 'Mittel' },
  { name: 'success', label: 'Erfolg' },
  { name: 'warning', label: 'Warnung' },
  { name: 'error', label: 'Fehler' },
];
const countdownTotal = 20;
const stopNames: Record<SheetStop, string> = {
  peek: 'klein',
  half: 'mittel',
  full: 'groß',
};

export default function UiShowcaseScreen() {
  const [page, setPage] = useState<Page>('parts');
  return (
    <GestureHandlerRootView style={s.root}>
      <View style={s.top}>
        <Label>Design-Muster · nur Test</Label>
        <SegmentedControl
          options={pages}
          value={page}
          onChange={setPage}
          accessibilityLabel="Bereich der Musterseite"
        />
      </View>
      {page === 'parts' ? <Parts /> : null}
      {page === 'gestures' ? <Gestures /> : null}
      {page === 'sheet' ? <SheetDemo /> : null}
    </GestureHandlerRootView>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <View style={s.section}>
      <Label>{title}</Label>
      {children}
    </View>
  );
}

function Parts() {
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [count, setCount] = useState(1);
  const [step, setStep] = useState(1);
  useEffect(() => {
    if (!loading) return;
    const timer = setTimeout(() => setLoading(false), 1500);
    return () => clearTimeout(timer);
  }, [loading]);
  return (
    <ScrollView
      contentContainerStyle={s.scroll}
      keyboardShouldPersistTaps="handled"
    >
      <Banner
        title="Alles auf dieser Seite ist ein Beispiel"
        text="Keine echten Daten, keine Buchung, nichts wird gesendet."
      />
      <Section title="Schrift">
        <LargeTitle>Großer Titel</LargeTitle>
        <Title>Titel 1</Title>
        <Title2>Titel 2</Title2>
        <Headline>Überschrift</Headline>
        <Body>Text – so sieht normaler Fließtext aus.</Body>
        <Subhead>Nebentext für ergänzende Angaben.</Subhead>
        <Caption>Fußnote für Kleingedrucktes.</Caption>
        <Label>Etikett</Label>
        <Amount>Beispielbetrag 00,00 €</Amount>
      </Section>
      <Section title="Knöpfe">
        <Button
          label="Primäre Aktion"
          loading={loading}
          onPress={() => setLoading(true)}
          accessibilityHint="Zeigt für kurze Zeit den Ladezustand"
        />
        <Button label="Sekundäre Aktion" variant="secondary" onPress={() => {}} />
        <Button label="Textaktion" variant="text" onPress={() => {}} />
        <Button
          label="Zerstörende Aktion"
          variant="destructive"
          onPress={() => haptic('warning')}
        />
        <Button label="Nicht verfügbar" disabled onPress={() => {}} />
      </Section>
      <Section title="Status">
        <View style={s.wrapRow}>
          <StatusChip label="Neutral" />
          <StatusChip label="Hinweis" tone="gold" />
          <StatusChip label="Erledigt" tone="success" />
          <StatusChip label="Abgelehnt" tone="danger" />
          <StatusChip label="Information" tone="info" />
        </View>
      </Section>
      <Section title="Hinweise">
        <Banner tone="success" title="Beispiel: Erfolg" text="So sieht eine Bestätigung aus." />
        <Banner
          tone="error"
          title="Beispiel: Fehler"
          text="So sieht eine Fehlermeldung aus."
          actionLabel="Erneut versuchen"
          onAction={() => haptic('error')}
        />
        <Banner tone="offline" title="Beispiel: Keine Verbindung" />
      </Section>
      <Section title="Liste">
        <View style={s.card}>
          <ListRow
            icon={MapPinned}
            title="Beispielzeile mit Pfeil"
            detail="Detailzeile"
            onPress={() => haptic('light')}
          />
          <ListRow
            icon={CalendarDays}
            title="Beispielzeile mit Wert"
            value="Wert"
            onPress={() => haptic('light')}
          />
          <ListRow icon={CarFront} title="Zeile ohne Aktion" divider={false} />
        </View>
      </Section>
      <Section title="Eingabe">
        <TextField
          label="Beispielfeld"
          value={name}
          onChangeText={setName}
          placeholder="Text eingeben"
          hint="Hinweis unter dem Feld."
        />
        <TextField
          label="Feld mit Fehler"
          value=""
          editable={false}
          error="So sieht eine Fehlermeldung am Feld aus."
        />
        <Subhead>Code-Eingabe (Beispiel, wird nicht geprüft)</Subhead>
        <CodeField
          value={code}
          onChange={setCode}
          onComplete={() => haptic('success')}
        />
        <View style={s.between}>
          <Body>Beispielmenge</Body>
          <Stepper value={count} onChange={setCount} max={9} label="Beispiel" />
        </View>
      </Section>
      <Section title="Fortschritt">
        <ProgressSteps
          steps={['Schritt 1', 'Schritt 2', 'Schritt 3', 'Schritt 4']}
          current={step}
        />
        <Button
          label="Nächster Schritt"
          variant="secondary"
          onPress={() => setStep((value) => (value + 1) % 4)}
        />
      </Section>
      <Section title="Laden">
        <Skeleton width="60%" height={22} />
        <Skeleton />
        <Skeleton width="80%" />
      </Section>
      <Section title="Leerer Zustand">
        <View style={s.card}>
          <EmptyState
            icon={Inbox}
            title="Noch nichts vorhanden"
            text="Beispieltext für einen leeren Zustand."
            actionLabel="Beispielaktion"
            onAction={() => haptic('light')}
          />
        </View>
      </Section>
    </ScrollView>
  );
}

function Gestures() {
  const [busy, setBusy] = useState(false);
  const [confirmed, setConfirmed] = useState(0);
  const [remaining, setRemaining] = useState(countdownTotal);
  const [running, setRunning] = useState(false);
  useEffect(() => {
    if (!busy) return;
    const timer = setTimeout(() => {
      setBusy(false);
      setConfirmed((value) => value + 1);
      haptic('success');
    }, 1200);
    return () => clearTimeout(timer);
  }, [busy]);
  useEffect(() => {
    if (!running) return;
    const end = Date.now() + remaining * 1000;
    let warned = remaining <= 5;
    const timer = setInterval(() => {
      const left = Math.max(0, (end - Date.now()) / 1000);
      setRemaining(left);
      if (!warned && left <= 5) {
        warned = true;
        haptic('warning'); // einmal in den letzten 5 Sekunden
      }
      if (left <= 0) setRunning(false);
    }, 100);
    return () => clearInterval(timer);
    // Nur beim Starten/Stoppen neu aufsetzen, nicht bei jedem Tick.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running]);
  return (
    <ScrollView contentContainerStyle={s.scroll}>
      <Section title="Wischen zum Bestätigen">
        <SwipeToConfirm
          label="Beispiel: wischen zum Bestätigen"
          busy={busy}
          onConfirm={() => setBusy(true)}
        />
        <SwipeToConfirm
          label="Beispiel: wischen zum Stornieren"
          tone="danger"
          resetKey={confirmed}
          onConfirm={() => setConfirmed((value) => value + 1)}
        />
        <SwipeToConfirm label="Gesperrt" disabled onConfirm={() => {}} />
        <Caption>
          Bestätigt wird erst ab 90 % des Wegs. Auf dieser Seite ausgelöst:{' '}
          {confirmed}× (nur gezählt, nichts gesendet).
        </Caption>
      </Section>
      <Section title="Haptik">
        <View style={s.wrapRow}>
          {haptics.map((item) => (
            <Button
              key={item.name}
              label={item.label}
              variant="secondary"
              onPress={() => haptic(item.name)}
              accessibilityHint="Löst die Haptik zum Fühlen aus"
              style={s.hapticButton}
            />
          ))}
        </View>
        <Caption>
          Haptik hängt vom Gerät und von den Systemeinstellungen ab.
        </Caption>
      </Section>
      <Section title="Countdown">
        <View style={s.between}>
          <Countdown
            remainingSeconds={remaining}
            totalSeconds={countdownTotal}
            caption="Beispiel-Countdown"
          />
          <View style={s.countdownButtons}>
            <Button
              label={running ? 'Anhalten' : 'Starten'}
              variant="secondary"
              onPress={() => {
                if (!running && remaining <= 0) setRemaining(countdownTotal);
                setRunning(!running);
              }}
            />
            <Button
              label="Zurücksetzen"
              variant="text"
              onPress={() => {
                setRunning(false);
                setRemaining(countdownTotal);
              }}
            />
          </View>
        </View>
      </Section>
    </ScrollView>
  );
}

function SheetDemo() {
  const [stop, setStop] = useState<SheetStop>('half');
  return (
    <View style={s.stage}>
      <View style={s.mapPlaceholder}>
        <MapPinned color={colors.gray} size={32} strokeWidth={layout.iconStroke} />
        <Subhead center>Platzhalter für die Karte (Beispiel)</Subhead>
        <StatusChip label={`Rastpunkt: ${stopNames[stop]}`} tone="gold" />
      </View>
      <Sheet
        stop={stop}
        onStopChange={setStop}
        accessibilityLabel="Beispielfenster"
        header={<Title2>Beispielfenster</Title2>}
      >
        <ScrollView contentContainerStyle={s.sheetBody}>
          <Subhead>
            Am Griff oder an der Überschrift ziehen; Griff antippen wechselt
            klein → mittel → groß.
          </Subhead>
          <View style={s.wrapRow}>
            {(['peek', 'half', 'full'] as const).map((key) => (
              <Button
                key={key}
                label={stopNames[key]}
                variant={key === stop ? 'primary' : 'secondary'}
                onPress={() => setStop(key)}
                style={s.hapticButton}
              />
            ))}
          </View>
          <View style={s.card}>
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <ListRow
                key={n}
                title={`Beispielzeile ${n}`}
                detail="Inhalt zum Scrollen"
                divider={n < 6}
              />
            ))}
          </View>
        </ScrollView>
      </Sheet>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.paper },
  top: {
    paddingHorizontal: layout.screenMargin,
    paddingTop: 12,
    paddingBottom: 12,
    gap: 8,
  },
  scroll: {
    // 25 statt 20: Der Wischknopf beginnt außerhalb der Zurück-Randzone (24)
    // des bestehenden App-Rahmens.
    paddingHorizontal: layout.screenMargin + 5,
    paddingBottom: 48,
    gap: layout.sectionGap,
  },
  section: { gap: layout.cardGap },
  card: {
    backgroundColor: colors.white,
    borderRadius: radii.l,
    borderWidth: 1,
    borderColor: colors.line,
    overflow: 'hidden',
  },
  wrapRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  between: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 16,
  },
  hapticButton: { flexGrow: 1, minWidth: 96 },
  countdownButtons: { flex: 1, gap: 4 },
  stage: { flex: 1 },
  mapPlaceholder: {
    flex: 1,
    backgroundColor: colors.sand,
    alignItems: 'center',
    paddingTop: 32,
    gap: 12,
  },
  sheetBody: {
    paddingHorizontal: layout.screenMargin,
    paddingBottom: 32,
    gap: layout.cardGap,
  },
});
