import { useEffect, useState } from 'react';
import { AccessibilityInfo } from 'react-native';

/** Systemeinstellung „Bewegung reduzieren“: dann nur überblenden/springen. */
export function useReduceMotion(): boolean {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    let alive = true;
    AccessibilityInfo.isReduceMotionEnabled()
      .then((value) => alive && setReduced(value))
      .catch(() => {});
    const listener = AccessibilityInfo.addEventListener(
      'reduceMotionChanged',
      setReduced,
    );
    return () => {
      alive = false;
      listener.remove();
    };
  }, []);
  return reduced;
}

/** Ist ein Screenreader (TalkBack/VoiceOver) aktiv? */
export function useScreenReader(): boolean {
  const [enabled, setEnabled] = useState(false);
  useEffect(() => {
    let alive = true;
    AccessibilityInfo.isScreenReaderEnabled()
      .then((value) => alive && setEnabled(value))
      .catch(() => {});
    const listener = AccessibilityInfo.addEventListener(
      'screenReaderChanged',
      setEnabled,
    );
    return () => {
      alive = false;
      listener.remove();
    };
  }, []);
  return enabled;
}
