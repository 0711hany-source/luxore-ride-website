import React from 'react';
import { Text, type TextProps, type TextStyle } from 'react-native';
import { colors, maxFontScale, typography } from '../theme';

type Tone = 'ink' | 'muted' | 'gold' | 'danger' | 'success' | 'onInk';
const tones: Record<Tone, string> = {
  ink: colors.ink,
  muted: colors.textMuted,
  gold: colors.goldText,
  danger: colors.danger,
  success: colors.success,
  onInk: colors.white,
};
export type TypographyProps = TextProps & { tone?: Tone; center?: boolean };

function make(
  variant: keyof typeof typography,
  defaultTone: Tone,
  heading = false,
) {
  const base = typography[variant] as TextStyle;
  return function Typo({ tone, center, style, ...rest }: TypographyProps) {
    return (
      <Text
        accessibilityRole={heading ? 'header' : undefined}
        maxFontSizeMultiplier={maxFontScale}
        {...rest}
        style={[
          base,
          { color: tones[tone ?? defaultTone] },
          center && { textAlign: 'center' },
          style,
        ]}
      />
    );
  };
}

/** Großer Titel 34/41/700 */
export const LargeTitle = make('largeTitle', 'ink', true);
/** Titel 1 28/34/700 */
export const Title = make('title1', 'ink', true);
/** Titel 2 22/28/600 */
export const Title2 = make('title2', 'ink', true);
/** Überschrift 17/22/600 */
export const Headline = make('headline', 'ink');
/** Text 17/24/400 */
export const Body = make('body', 'ink');
/** Nebentext 15/20/400 */
export const Subhead = make('subhead', 'muted');
/** Fußnote 13/18/400 */
export const Caption = make('footnote', 'muted');
/** Etikett 11/13/600, Großbuchstaben mit Sperrung */
export const Label = make('label', 'muted');

/** Beträge mit Tabellenziffern, damit Spalten nicht springen. */
export function Amount({ tone, center, style, ...rest }: TypographyProps) {
  return (
    <Text
      maxFontSizeMultiplier={maxFontScale}
      {...rest}
      style={[
        typography.headline as TextStyle,
        { color: tones[tone ?? 'ink'], fontVariant: ['tabular-nums'] },
        center && { textAlign: 'center' },
        style,
      ]}
    />
  );
}
