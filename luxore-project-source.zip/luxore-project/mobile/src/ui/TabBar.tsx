import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { LucideIcon } from 'lucide-react-native';
import { colors, layout, maxFontScale, radii, space } from '../theme';

export type TabBarItem<Key extends string> = {
  key: Key;
  label: string;
  icon: LucideIcon;
};

/** Untere Tab-Leiste: Symbol + Wort, aktiver Tab hinterlegt und in Tinte. */
export default function TabBar<Key extends string>({
  items,
  selected,
  onSelect,
}: {
  items: readonly TabBarItem<Key>[];
  selected: Key;
  onSelect: (key: Key) => void;
}) {
  return (
    <View style={s.bar} accessibilityRole="tablist">
      {items.map(({ key, label, icon: Icon }) => {
        const active = key === selected;
        return (
          <Pressable
            key={key}
            style={[s.tab, active && s.tabActive]}
            onPress={() => onSelect(key)}
            accessibilityRole="tab"
            accessibilityLabel={label}
            accessibilityState={{ selected: active }}
          >
            <Icon
              color={active ? colors.goldText : colors.gray}
              size={layout.icon}
              strokeWidth={layout.iconStroke}
            />
            <Text
              style={[s.label, active && s.labelActive]}
              maxFontSizeMultiplier={maxFontScale}
              numberOfLines={1}
            >
              {label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const s = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    marginHorizontal: layout.screenMargin,
    marginBottom: space[2],
    padding: space[1],
    gap: space[1],
    borderRadius: radii.xl,
    borderWidth: 1,
    borderColor: colors.sand,
    backgroundColor: colors.white,
  },
  tab: {
    flex: 1,
    minHeight: layout.tap + space[2],
    paddingVertical: space[2],
    alignItems: 'center',
    justifyContent: 'center',
    gap: space[1],
    borderRadius: radii.l + space[1],
  },
  tabActive: { backgroundColor: colors.paper },
  label: { fontSize: 11, lineHeight: 13, fontWeight: '600', color: colors.textMuted },
  labelActive: { color: colors.ink },
});
