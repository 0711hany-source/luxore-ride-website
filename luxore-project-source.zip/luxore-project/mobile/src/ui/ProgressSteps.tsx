import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Check } from 'lucide-react-native';
import { colors, maxFontScale, typography } from '../theme';

/** Fortschritt in benannten Schritten (z. B. Anfahrt → Vor Ort → Fahrt). */
export default function ProgressSteps({
  steps,
  current,
}: {
  steps: readonly string[];
  /** Index des aktuellen Schritts (0-basiert). */
  current: number;
}) {
  const index = Math.max(0, Math.min(steps.length - 1, current));
  return (
    <View
      style={s.row}
      accessible
      accessibilityRole="progressbar"
      accessibilityLabel="Fortschritt"
      accessibilityValue={{
        min: 1,
        max: steps.length,
        now: index + 1,
        text: `Schritt ${index + 1} von ${steps.length}: ${steps[index] ?? ''}`,
      }}
    >
      {steps.map((step, i) => {
        const done = i < index,
          active = i === index;
        return (
          <View key={step} style={s.step}>
            <View style={s.track}>
              <View
                style={[
                  s.line,
                  i === 0 && s.hidden,
                  (done || active) && s.lineDone,
                ]}
              />
              <View
                style={[s.dot, done && s.dotDone, active && s.dotActive]}
              >
                {done ? (
                  <Check color={colors.white} size={12} strokeWidth={3} />
                ) : null}
              </View>
              <View
                style={[
                  s.line,
                  i === steps.length - 1 && s.hidden,
                  done && s.lineDone,
                ]}
              />
            </View>
            <Text
              style={[s.label, (done || active) && s.labelActive]}
              numberOfLines={2}
              maxFontSizeMultiplier={maxFontScale}
            >
              {step}
            </Text>
          </View>
        );
      })}
    </View>
  );
}
const s = StyleSheet.create({
  row: { flexDirection: 'row' },
  step: { flex: 1, alignItems: 'center', gap: 6 },
  track: { flexDirection: 'row', alignItems: 'center', alignSelf: 'stretch' },
  line: { flex: 1, height: 2, backgroundColor: colors.line },
  lineDone: { backgroundColor: colors.gold },
  hidden: { opacity: 0 },
  dot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: colors.lineStrong,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dotDone: { backgroundColor: colors.gold, borderColor: colors.gold },
  dotActive: { borderColor: colors.gold, backgroundColor: colors.goldWash },
  label: {
    ...typography.footnote,
    color: colors.textMuted,
    textAlign: 'center',
    paddingHorizontal: 2,
  },
  labelActive: { color: colors.ink, fontWeight: '600' },
});
