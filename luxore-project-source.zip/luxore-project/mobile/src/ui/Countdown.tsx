import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { colors, maxFontScale, typography } from '../theme';

/**
 * Countdown als Ring. Reine Anzeige: die verbleibende Zeit kommt von außen
 * (z. B. aus der Angebotsfrist des Servers), die Komponente zählt nicht selbst.
 */
export default function Countdown({
  remainingSeconds,
  totalSeconds,
  size = 72,
  strokeWidth = 5,
  warnBelowSeconds = 5,
  caption,
}: {
  remainingSeconds: number;
  totalSeconds: number;
  size?: number;
  strokeWidth?: number;
  /** Ab dieser Restzeit wechselt der Ring auf die Warnfarbe. */
  warnBelowSeconds?: number;
  caption?: string;
}) {
  const remaining = Math.max(0, Math.min(totalSeconds, remainingSeconds));
  const whole = Math.ceil(remaining);
  const fraction = totalSeconds > 0 ? remaining / totalSeconds : 0;
  const r = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * r;
  const urgent = remaining <= warnBelowSeconds;
  const color = urgent ? colors.danger : colors.gold;
  return (
    <View
      style={{ width: size, height: size }}
      accessible
      accessibilityRole="timer"
      accessibilityLabel={`${caption ? caption + ': ' : ''}noch ${whole} ${whole === 1 ? 'Sekunde' : 'Sekunden'}`}
    >
      <Svg width={size} height={size}>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={colors.line}
          strokeWidth={strokeWidth}
          fill="none"
        />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={`${circumference} ${circumference}`}
          strokeDashoffset={circumference * (1 - fraction)}
          // Start oben (12 Uhr), läuft im Uhrzeigersinn ab.
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </Svg>
      <View style={s.center} pointerEvents="none">
        <Text
          style={[s.number, urgent && { color: colors.danger }]}
          maxFontSizeMultiplier={maxFontScale}
        >
          {whole}
        </Text>
      </View>
    </View>
  );
}
const s = StyleSheet.create({
  center: {
    position: 'absolute', left: 0, right: 0, top: 0, bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  number: {
    ...typography.title2,
    color: colors.ink,
    fontVariant: ['tabular-nums'],
  },
});
