import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Minus, Plus } from 'lucide-react-native';
import { colors, layout, maxFontScale, radii, typography } from '../theme';
import { haptic } from './haptics';

/** Mengenwähler (Minus · Zahl · Plus) mit Grenzen. */
export default function Stepper({
  value,
  onChange,
  min = 0,
  max = 99,
  label,
  disabled,
}: {
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  /** Wofür die Menge gilt, z. B. „Wasser still“. */
  label: string;
  disabled?: boolean;
}) {
  const set = (next: number) => {
    const clamped = Math.max(min, Math.min(max, next));
    if (clamped === value) return;
    haptic('light');
    onChange(clamped);
  };
  const canLess = !disabled && value > min,
    canMore = !disabled && value < max;
  return (
    <View
      style={s.wrap}
      accessible
      accessibilityRole="adjustable"
      accessibilityLabel={`Menge ${label}`}
      accessibilityValue={{ min, max, now: value, text: String(value) }}
      accessibilityActions={[
        { name: 'increment', label: 'Erhöhen' },
        { name: 'decrement', label: 'Verringern' },
      ]}
      onAccessibilityAction={(event) =>
        set(value + (event.nativeEvent.actionName === 'increment' ? 1 : -1))
      }
    >
      <Pressable
        style={[s.button, !canLess && s.off]}
        disabled={!canLess}
        onPress={() => set(value - 1)}
        accessibilityLabel={`${label} verringern`}
        accessibilityRole="button"
      >
        <Minus color={colors.ink} size={20} strokeWidth={layout.iconStroke} />
      </Pressable>
      <Text style={s.value} maxFontSizeMultiplier={maxFontScale}>
        {value}
      </Text>
      <Pressable
        style={[s.button, !canMore && s.off]}
        disabled={!canMore}
        onPress={() => set(value + 1)}
        accessibilityLabel={`${label} erhöhen`}
        accessibilityRole="button"
      >
        <Plus color={colors.ink} size={20} strokeWidth={layout.iconStroke} />
      </Pressable>
    </View>
  );
}
const s = StyleSheet.create({
  wrap: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radii.m,
    borderWidth: 1,
    borderColor: colors.lineStrong,
    backgroundColor: colors.white,
  },
  button: {
    width: layout.tap,
    height: layout.tap,
    alignItems: 'center',
    justifyContent: 'center',
  },
  off: { opacity: 0.3 },
  value: {
    ...typography.headline,
    color: colors.ink,
    minWidth: 32,
    textAlign: 'center',
    fontVariant: ['tabular-nums'],
  },
});
