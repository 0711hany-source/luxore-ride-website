import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import type { LucideIcon } from 'lucide-react-native';
import { colors, layout, maxFontScale, radii, typography } from '../theme';

export type ButtonVariant = 'primary' | 'secondary' | 'text' | 'destructive';
const look: Record<
  ButtonVariant,
  { background: string; border: string; text: string }
> = {
  // Gold bleibt Akzent: genau eine primäre Aktion pro Screen.
  primary: { background: colors.gold, border: colors.gold, text: colors.ink },
  secondary: {
    background: colors.white,
    border: colors.lineStrong,
    text: colors.ink,
  },
  text: {
    background: 'transparent',
    border: 'transparent',
    text: colors.goldText,
  },
  destructive: {
    background: colors.dangerWash,
    border: colors.dangerWash,
    text: colors.danger,
  },
};

export default function Button({
  label,
  onPress,
  variant = 'primary',
  loading,
  disabled,
  icon: Icon,
  accessibilityHint,
  style,
}: {
  label: string;
  onPress: () => void;
  variant?: ButtonVariant;
  /** Ladezustand: zeigt einen Kreisel und sperrt weitere Tipps. */
  loading?: boolean;
  disabled?: boolean;
  icon?: LucideIcon;
  accessibilityHint?: string;
  style?: StyleProp<ViewStyle>;
}) {
  const v = look[variant];
  const blocked = !!disabled || !!loading;
  return (
    <Pressable
      onPress={onPress}
      disabled={blocked}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityHint={accessibilityHint}
      accessibilityState={{ disabled: blocked, busy: !!loading }}
      style={({ pressed }) => [
        s.base,
        { backgroundColor: v.background, borderColor: v.border },
        pressed && s.pressed,
        disabled && s.disabled,
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={v.text} />
      ) : (
        <View style={s.content}>
          {Icon ? (
            <Icon
              color={v.text}
              size={layout.icon - 4}
              strokeWidth={layout.iconStroke}
            />
          ) : null}
          <Text
            style={[s.label, { color: v.text }]}
            numberOfLines={1}
            maxFontSizeMultiplier={maxFontScale}
          >
            {label}
          </Text>
        </View>
      )}
    </Pressable>
  );
}
const s = StyleSheet.create({
  base: {
    minHeight: 52,
    borderRadius: radii.m,
    borderWidth: 1,
    paddingHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  label: { ...typography.headline },
  pressed: { opacity: 0.72 },
  disabled: { opacity: 0.45 },
});
