import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { colors, layout, maxFontScale, radii, springs, typography } from '../theme';
import { haptic } from './haptics';

const inset = 3;

/** Umschalter für 2–4 gleichrangige Ansichten (z. B. Jetzt / Später). */
export default function SegmentedControl<Key extends string>({
  options,
  value,
  onChange,
  accessibilityLabel,
}: {
  options: readonly { key: Key; label: string }[];
  value: Key;
  onChange: (key: Key) => void;
  accessibilityLabel: string;
}) {
  const [width, setWidth] = useState(0);
  const segment = options.length ? (width - inset * 2) / options.length : 0;
  const index = Math.max(
    0,
    options.findIndex((option) => option.key === value),
  );
  const x = useSharedValue(0);
  useEffect(() => {
    // „Bewegung reduzieren“ beachtet withSpring selbst (springt ans Ziel).
    x.value = withSpring(index * segment, springs.standard);
  }, [index, segment, x]);
  const thumb = useAnimatedStyle(() => ({
    transform: [{ translateX: x.value }],
  }));
  return (
    <View
      style={s.track}
      onLayout={(event) => setWidth(event.nativeEvent.layout.width)}
      accessibilityRole="tablist"
      accessibilityLabel={accessibilityLabel}
    >
      {segment > 0 ? (
        <Animated.View style={[s.thumb, { width: segment }, thumb]} />
      ) : null}
      {options.map((option) => {
        const selected = option.key === value;
        return (
          <Pressable
            key={option.key}
            style={s.option}
            onPress={() => {
              if (selected) return;
              haptic('light');
              onChange(option.key);
            }}
            accessibilityRole="tab"
            accessibilityLabel={option.label}
            accessibilityState={{ selected }}
          >
            <Text
              style={[s.label, selected && s.selected]}
              numberOfLines={1}
              maxFontSizeMultiplier={maxFontScale}
            >
              {option.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
const s = StyleSheet.create({
  track: {
    flexDirection: 'row',
    minHeight: layout.tap,
    padding: inset,
    borderRadius: radii.m,
    backgroundColor: colors.sand,
  },
  thumb: {
    position: 'absolute',
    left: inset,
    top: inset,
    bottom: inset,
    borderRadius: radii.m - inset,
    backgroundColor: colors.white,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.line,
  },
  option: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  label: { ...typography.subhead, fontWeight: '600', color: colors.textMuted },
  selected: { color: colors.ink },
});
