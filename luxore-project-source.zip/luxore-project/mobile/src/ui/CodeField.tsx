import React, { useRef, useState } from 'react';
import {
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { colors, maxFontScale, radii, typography } from '../theme';

/**
 * Code-Eingabe mit einzelnen Kästchen (Standard 6 Ziffern). Ein einziges,
 * unsichtbares Eingabefeld liegt über den Kästchen: Einfügen und
 * Code-Vorschläge der Tastatur funktionieren so ohne Sonderlogik.
 */
export default function CodeField({
  value,
  onChange,
  onComplete,
  length = 6,
  label = 'Bestätigungscode',
  error,
  disabled,
  autoFocus,
}: {
  value: string;
  onChange: (code: string) => void;
  /** Wird genau dann gerufen, wenn alle Stellen gefüllt sind. */
  onComplete?: (code: string) => void;
  length?: number;
  label?: string;
  error?: string;
  disabled?: boolean;
  autoFocus?: boolean;
}) {
  const input = useRef<TextInput>(null);
  const [focused, setFocused] = useState(false);
  const digits = value.replace(/\D/g, '').slice(0, length);
  return (
    <View style={s.wrap}>
      <Pressable
        style={s.row}
        onPress={() => input.current?.focus()}
        disabled={disabled}
        accessible={false}
      >
        {Array.from({ length }, (_, index) => {
          const active =
            focused &&
            (index === digits.length ||
              (digits.length === length && index === length - 1));
          return (
            <View
              key={index}
              style={[
                s.box,
                active && s.active,
                !!error && s.invalid,
                disabled && s.disabled,
              ]}
            >
              <Text style={s.digit} maxFontSizeMultiplier={maxFontScale}>
                {digits[index] ?? ''}
              </Text>
            </View>
          );
        })}
        <TextInput
          ref={input}
          value={digits}
          onChangeText={(text) => {
            const next = text.replace(/\D/g, '').slice(0, length);
            onChange(next);
            if (next.length === length && next !== digits) onComplete?.(next);
          }}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          editable={!disabled}
          autoFocus={autoFocus}
          keyboardType="number-pad"
          inputMode="numeric"
          // Android kennt nur „sms-otp“, iOS „one-time-code“; beide bieten
          // auch einen kopierten E-Mail-Code über der Tastatur an.
          autoComplete={Platform.OS === 'android' ? 'sms-otp' : 'one-time-code'}
          textContentType="oneTimeCode"
          maxLength={length}
          caretHidden
          accessibilityLabel={`${label}, ${length} Ziffern`}
          accessibilityHint={error}
          style={s.input}
        />
      </Pressable>
      {error ? (
        <Text
          style={s.error}
          accessibilityLiveRegion="polite"
          maxFontSizeMultiplier={maxFontScale}
        >
          {error}
        </Text>
      ) : null}
    </View>
  );
}
const s = StyleSheet.create({
  wrap: { gap: 8 },
  row: { flexDirection: 'row', gap: 8 },
  box: {
    flex: 1,
    height: 56,
    borderRadius: radii.m,
    borderWidth: 1,
    borderColor: colors.lineStrong,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
  },
  active: { borderColor: colors.goldText, borderWidth: 2 },
  invalid: { borderColor: colors.danger },
  disabled: { backgroundColor: colors.sand },
  digit: {
    ...typography.title2,
    color: colors.ink,
    fontVariant: ['tabular-nums'],
  },
  // Unsichtbar, aber über der ganzen Zeile: Antippen setzt den Fokus nativ.
  input: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, opacity: 0.01, color: 'transparent' },
  error: { ...typography.footnote, color: colors.danger },
});
