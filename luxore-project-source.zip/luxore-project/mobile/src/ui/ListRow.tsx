import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { ChevronRight, type LucideIcon } from 'lucide-react-native';
import { colors, layout, maxFontScale, typography } from '../theme';

/** Listenzeile: Symbol, Titel, Detail, Wert, Pfeil. */
export default function ListRow({
  title,
  detail,
  value,
  icon: Icon,
  onPress,
  chevron = !!onPress,
  divider = true,
  accessibilityHint,
}: {
  title: string;
  detail?: string;
  value?: string;
  icon?: LucideIcon;
  onPress?: () => void;
  chevron?: boolean;
  /** Trennlinie unter der Zeile (letzte Zeile einer Gruppe: false). */
  divider?: boolean;
  accessibilityHint?: string;
}) {
  const content = (
    <>
      {Icon ? (
        <Icon
          color={colors.goldText}
          size={layout.icon}
          strokeWidth={layout.iconStroke}
        />
      ) : null}
      <View style={s.texts}>
        <Text style={s.title} maxFontSizeMultiplier={maxFontScale}>
          {title}
        </Text>
        {detail ? (
          <Text style={s.detail} maxFontSizeMultiplier={maxFontScale}>
            {detail}
          </Text>
        ) : null}
      </View>
      {value ? (
        <Text style={s.value} maxFontSizeMultiplier={maxFontScale}>
          {value}
        </Text>
      ) : null}
      {chevron ? (
        <ChevronRight
          color={colors.gray}
          size={20}
          strokeWidth={layout.iconStroke}
        />
      ) : null}
    </>
  );
  const label = [title, detail, value].filter(Boolean).join(', ');
  if (!onPress)
    return (
      <View
        style={[s.row, divider && s.divider]}
        accessible
        accessibilityLabel={label}
      >
        {content}
      </View>
    );
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityHint={accessibilityHint}
      style={({ pressed }) => [
        s.row,
        divider && s.divider,
        pressed && s.pressed,
      ]}
    >
      {content}
    </Pressable>
  );
}
const s = StyleSheet.create({
  row: {
    minHeight: 56,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  divider: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.line,
  },
  pressed: { backgroundColor: colors.sand },
  texts: { flex: 1, gap: 2 },
  title: { ...typography.body, color: colors.ink },
  detail: { ...typography.footnote, color: colors.textMuted },
  value: {
    ...typography.subhead,
    color: colors.textMuted,
    fontVariant: ['tabular-nums'],
  },
});
