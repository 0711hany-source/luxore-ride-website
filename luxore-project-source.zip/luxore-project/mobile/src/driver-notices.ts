import * as Notifications from 'expo-notifications';
import * as ReactNative from 'react-native';
// (Plain Node test runs replace react-native with a small stand-in.)
const Vibration = ReactNative.Vibration as
  | typeof ReactNative.Vibration
  | undefined;
import { isIos } from './platform-text';

// Short hints for the driver during a ride (board order, message, rating).
// Shown as a notification with sound so nothing is missed while driving.
const channelId = 'luxore-driver-notices-v1';
let prepared = false;
async function channel() {
  if (isIos || prepared) return;
  await Notifications.setNotificationChannelAsync(channelId, {
    name: 'Hinweise während der Fahrt',
    description: 'Bordbestellungen, Nachrichten des Fahrgasts und Bewertungen',
    importance: Notifications.AndroidImportance.HIGH,
    sound: 'default',
    enableVibrate: true,
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PRIVATE,
    bypassDnd: false,
  });
  prepared = true;
}
/** Best effort: the banner in the app is the reliable part. Never throws. */
export async function driverNotice(id: string, title: string, body: string) {
  Vibration?.vibrate([0, 300, 150, 300]);
  try {
    await channel();
    if (!(await Notifications.getPermissionsAsync()).granted) return;
    await Notifications.scheduleNotificationAsync({
      identifier: id,
      content: {
        title,
        body,
        sound: 'default',
        priority: Notifications.AndroidNotificationPriority.HIGH,
        autoDismiss: true,
        data: { kind: 'luxore-notice' },
      },
      trigger: { channelId },
    });
  } catch {
    /* The in-app banner still shows the hint. */
  }
}
