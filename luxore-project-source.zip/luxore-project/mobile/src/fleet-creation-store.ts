import type { FleetCreateRequest, FleetCreateStore } from './fleet-creation.ts';
import { validFleetRequest } from './fleet-creation.ts';
export type SecureFleetStorage = {
  getItemAsync(key: string): Promise<string | null>;
  setItemAsync(key: string, value: string): Promise<void>;
  deleteItemAsync(key: string): Promise<void>;
};
const queues = new Map<string, Promise<unknown>>();
function serial<T>(key: string, work: () => Promise<T>) {
  const task = (queues.get(key) || Promise.resolve())
    .catch(() => {})
    .then(work);
  queues.set(key, task);
  void task
    .finally(() => {
      if (queues.get(key) === task) queues.delete(key);
    })
    .catch(() => {});
  return task;
}
export function fleetCreateStore(
  storage: SecureFleetStorage,
  accountId: string,
): FleetCreateStore {
  if (!accountId || accountId.length > 100)
    throw new Error('Kontozuordnung fehlt.');
  const key =
    'luxore-fleet-create-v1-' +
    Array.from(accountId)
      .map((c) => c.codePointAt(0)!.toString(16).padStart(6, '0'))
      .join('');
  async function read() {
    const raw = await storage.getItemAsync(key);
    if (!raw) return null;
    const value = JSON.parse(raw);
    if (
      value.accountId !== accountId ||
      value.version !== 1 ||
      !validFleetRequest(value.request)
    )
      throw new Error(
        'Gespeicherte Gründungsanfrage konnte nicht geprüft werden.',
      );
    return value.request as FleetCreateRequest;
  }
  return {
    load: () => serial(key, read),
    save: (value) =>
      serial(key, async () => {
        if (!validFleetRequest(value)) throw new Error('Ungültiger Entwurf.');
        const old = await read();
        if (
          old &&
          (old.requestId !== value.requestId ||
            old.name !== value.name ||
            old.ownerId !== value.ownerId)
        )
          throw new Error(
            'Eine andere Gründungsanfrage ist noch offen. Bitte diese zuerst prüfen.',
          );
        await storage.setItemAsync(
          key,
          JSON.stringify({ version: 1, accountId, request: { ...value } }),
        );
      }),
    clear: (requestId) =>
      serial(key, async () => {
        const value = await read();
        if (value?.requestId === requestId) await storage.deleteItemAsync(key);
      }),
  };
}
