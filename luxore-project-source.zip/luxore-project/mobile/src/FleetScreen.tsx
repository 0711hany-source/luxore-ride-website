import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { randomUUID } from 'expo-crypto';
import { SafeAreaView } from 'react-native-safe-area-context';
import { CarFront, Check, Plus, Users, X } from 'lucide-react-native';
import { nativeApi } from './account-client';
import { euros } from './driver-model';
import type { Fleet, FleetVehicle, Service } from '../../lib/mobility/domain';
import { validateVehicleInput } from '../../lib/mobility/vehicle-input';
type FleetData = {
  fleets: Fleet[];
  employees: {
    user_id: string;
    name: string;
    fleet_id: string | null;
    approved?: number;
    online?: number;
    plate?: string;
  }[];
  revenue: {
    fleet_id: string;
    driver_id: string;
    driver_name: string;
    gross: number;
    trips: number;
  }[];
};
function vehicleClasses(value: string): Service[] {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed)
      ? parsed.filter((item): item is Service =>
          ['premium', 'first', 'van'].includes(item),
        )
      : [];
  } catch {
    return [];
  }
}
const classes = [
  ['premium', 'Business'],
  ['first', 'First Class'],
  ['van', 'Van'],
] as const;
export default function FleetScreen({ token }: { token: string }) {
  // An account change must discard drafts and invalidate the previous reads.
  return <FleetWorkspace key={token} token={token} />;
}
function FleetWorkspace({ token }: { token: string }) {
  'use no memo'; // Native gesture/camera commands use mutable imperative handles.
  const [data, setData] = useState<FleetData | null>(null),
    [vehicles, setVehicles] = useState<FleetVehicle[]>([]);
  const [selected, setSelected] = useState(''),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  const [editor, setEditor] = useState<{
    vehicle?: FleetVehicle;
    requestId: string;
    fleetId: string;
  } | null>(null);
  const [model, setModel] = useState(''),
    [plate, setPlate] = useState(''),
    [services, setServices] = useState<Service[]>(['premium']);
  const [join, setJoin] = useState('');
  const [loading, setLoading] = useState(false),
    [listError, setListError] = useState(''),
    [notice, setNotice] = useState('');
  const lock = useRef(false),
    alive = useRef(true),
    readRevision = useRef(0);
  const invalidateReads = useCallback(() => {
    readRevision.current++;
  }, []);
  const refresh = useCallback(async () => {
    if (!alive.current) return;
    const revision = ++readRevision.current;
    setLoading(true);
    try {
      const [fleetData, cars] = await Promise.all([
        nativeApi<FleetData>('fleets', token, undefined, { period: 'today' }),
        nativeApi<{ vehicles: FleetVehicle[] }>('vehicles', token),
      ]);
      if (!alive.current || revision !== readRevision.current) return;
      setData(fleetData);
      setVehicles(cars.vehicles);
      setSelected((value) =>
        fleetData.fleets.some((fleet) => fleet.id === value)
          ? value
          : fleetData.fleets[0]?.id || '',
      );
      setListError('');
    } catch (e) {
      if (alive.current && revision === readRevision.current)
        setListError((e as Error).message);
    } finally {
      if (alive.current && revision === readRevision.current) setLoading(false);
    }
  }, [token]);
  useEffect(() => {
    alive.current = true;
    void Promise.resolve().then(refresh);
    return () => {
      alive.current = false;
      invalidateReads();
    };
  }, [refresh, invalidateReads]);
  async function action(body: object, confirmation: string) {
    if (lock.current) return;
    lock.current = true;
    // A list requested before this write cannot overwrite its confirmed result.
    invalidateReads();
    setLoading(false);
    setBusy(true);
    setError('');
    setNotice('');
    try {
      await nativeApi('vehicles', token, body);
      if (!alive.current) return;
      setEditor(null);
      setNotice(confirmation);
      await refresh();
    } catch (e) {
      if (alive.current) setError((e as Error).message);
    } finally {
      lock.current = false;
      if (alive.current) setBusy(false);
    }
  }
  function edit(vehicle?: FleetVehicle) {
    if (!selected) {
      setError('Bitte zuerst eine Flotte wählen.');
      return;
    }
    setModel(vehicle?.model || '');
    setPlate(vehicle?.plate || '');
    setServices(vehicle ? vehicleClasses(vehicle.services) : ['premium']);
    setError('');
    setNotice('');
    setEditor({ vehicle, requestId: randomUUID(), fleetId: selected });
  }
  function save() {
    if (!editor || lock.current) return;
    const validated = validateVehicleInput({ model, plate, services });
    if (!validated.value) {
      setError(Object.values(validated.errors)[0]!);
      return;
    }
    const vehicle = editor.vehicle;
    void action(
      vehicle
        ? {
            action: vehicle.status === 'archived' ? 'restore' : 'update',
            id: vehicle.id,
            ...validated.value,
            expected: {
              model: vehicle.model,
              plate: vehicle.plate,
              services: vehicle.services,
            },
          }
        : {
            action: 'create',
            fleetId: editor.fleetId,
            requestId: editor.requestId,
            ...validated.value,
          },
      vehicle?.status === 'archived'
        ? 'Fahrzeug wieder aktiviert.'
        : 'Fahrzeug gespeichert.',
    );
  }
  return (
    <View style={s.root}>
      <ScrollView
        contentContainerStyle={s.content}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={s.eyebrow}>DEINE FLOTTE</Text>
        <Text style={s.title}>Alles an einem Ort.</Text>
        {!data && loading && <ActivityIndicator color={gold} />}
        {!data && listError && (
          <>
            <Text style={s.error}>{listError}</Text>
            {!!error && <Text style={s.error}>{error}</Text>}
            <Text style={s.detail}>
              Ohne Dispositionsrecht kannst du mit dem Einladungscode deiner
              Flottenleitung beitreten.
            </Text>
            <TextInput
              value={join}
              onChangeText={setJoin}
              autoCapitalize="characters"
              style={s.input}
              placeholder="Einladungscode"
            />
            <Pressable
              disabled={busy}
              style={s.primary}
              onPress={() => {
                if (lock.current) return;
                lock.current = true;
                setBusy(true);
                void nativeApi('fleets', token, { action: 'join', code: join })
                  .then(refresh)
                  .catch((e) => {
                    if (alive.current) setError((e as Error).message);
                  })
                  .finally(() => {
                    lock.current = false;
                    if (alive.current) setBusy(false);
                  });
              }}
            >
              <Text style={s.primaryText}>Flotte beitreten</Text>
            </Pressable>
          </>
        )}
        {data && (
          <>
            {!!notice && (
              <Text accessibilityRole="alert" style={s.confirmation}>
                {notice}
              </Text>
            )}
            {!!listError && (
              <Text accessibilityRole="alert" style={s.error}>
                Die Liste konnte nicht aktualisiert werden: {listError}
                {'\n'}Bitte die Liste erneut laden.
              </Text>
            )}
            <View style={s.chips}>
              {data.fleets.map((fleet) => (
                <Pressable
                  key={fleet.id}
                  style={[s.chip, selected === fleet.id && s.chipActive]}
                  onPress={() => setSelected(fleet.id)}
                >
                  <Text style={s.heading}>{fleet.name}</Text>
                </Pressable>
              ))}
            </View>
            <View style={s.summary}>
              <Text style={s.eyebrow}>FLOTTENUMSATZ HEUTE</Text>
              <Text style={s.amount}>
                {euros(
                  data.revenue
                    .filter((r) => r.fleet_id === selected)
                    .reduce((sum, r) => sum + r.gross, 0),
                )}
              </Text>
              <Text style={s.detail}>Umsatz aller Fahrer dieser Flotte</Text>
            </View>
            <View style={s.row}>
              <CarFront color={gold} size={24} />
              <Text style={[s.heading, s.flex]}>Fahrzeuge</Text>
              <Pressable
                disabled={busy || !selected}
                onPress={() => edit()}
                style={s.add}
              >
                <Plus color="#fff" size={20} />
                <Text style={s.primaryText}>Hinzufügen</Text>
              </Pressable>
            </View>
            {vehicles
              .filter((v) => v.fleet_id === selected)
              .map((vehicle) => (
                <View key={vehicle.id} style={s.card}>
                  <View style={s.row}>
                    <CarFront color={gold} size={30} />
                    <View style={s.flex}>
                      <Text style={s.heading}>{vehicle.model}</Text>
                      <Text style={s.detail}>
                        {vehicle.plate} ·{' '}
                        {vehicle.status === 'archived'
                          ? 'Archiviert'
                          : vehicle.driver_name
                            ? vehicle.driver_name
                            : 'Frei'}
                      </Text>
                      <Text style={s.detail}>
                        {classes
                          .filter(([id]) =>
                            vehicleClasses(vehicle.services).includes(id),
                          )
                          .map(([, name]) => name)
                          .join(' · ')}
                      </Text>
                    </View>
                  </View>
                  {vehicle.blocking_reason && (
                    <Text style={s.error}>{vehicle.blocking_reason}</Text>
                  )}
                  <View style={s.chips}>
                    <Pressable
                      disabled={busy || !!vehicle.blocking_reason}
                      onPress={() => edit(vehicle)}
                    >
                      <Text style={s.link}>
                        {vehicle.status === 'archived'
                          ? 'Wieder aktivieren'
                          : 'Bearbeiten'}
                      </Text>
                    </Pressable>
                    {vehicle.status === 'active' && (
                      <Pressable
                        disabled={busy || !!vehicle.blocking_reason}
                        onPress={() =>
                          Alert.alert(
                            'Fahrzeug archivieren?',
                            `${vehicle.model} · ${vehicle.plate} wird aus der aktiven Auswahl entfernt. Frühere Fahrten bleiben erhalten.`,
                            [
                              { text: 'Abbrechen', style: 'cancel' },
                              {
                                text: 'Archivieren',
                                onPress: () =>
                                  void action(
                                    {
                                      action: 'archive',
                                      id: vehicle.id,
                                      reason: 'Aus der aktiven Flotte genommen',
                                    },
                                    'Fahrzeug archiviert. Frühere Fahrten bleiben erhalten.',
                                  ),
                              },
                            ],
                          )
                        }
                      >
                        <Text style={s.link}>Archivieren</Text>
                      </Pressable>
                    )}
                  </View>
                </View>
              ))}
            <View style={s.row}>
              <Users color={gold} size={23} />
              <Text style={s.heading}>Team</Text>
            </View>
            {data.employees
              .filter((employee) => employee.fleet_id === selected)
              .map((employee) => (
                <View key={employee.user_id} style={s.row}>
                  <View style={s.flex}>
                    <Text style={s.heading}>{employee.name}</Text>
                    <Text style={s.detail}>
                      {employee.online ? 'Online' : 'Offline'} ·{' '}
                      {employee.plate || 'Kein Fahrzeug'}
                      {employee.approved === 0 ? ' · Freigabe ausstehend' : ''}
                    </Text>
                  </View>
                  <Text style={s.heading}>
                    {euros(
                      data.revenue
                        .filter(
                          (r) =>
                            r.fleet_id === selected &&
                            r.driver_id === employee.user_id,
                        )
                        .reduce((sum, r) => sum + r.gross, 0),
                    )}
                  </Text>
                </View>
              ))}
            {!!error && !editor && <Text style={s.error}>{error}</Text>}
          </>
        )}
        <Pressable disabled={busy || loading} onPress={() => void refresh()}>
          <Text style={s.link}>
            {loading ? 'Liste wird aktualisiert …' : 'Liste aktualisieren'}
          </Text>
        </Pressable>
      </ScrollView>
      <Modal
        visible={!!editor}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => {
          if (!busy) setEditor(null);
        }}
      >
        <SafeAreaView style={s.root}>
          <KeyboardAvoidingView
            style={s.root}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          >
            <View style={s.editorHeader}>
              <Text style={s.heading}>
                {editor?.vehicle
                  ? 'Fahrzeug bearbeiten'
                  : 'Fahrzeug hinzufügen'}
              </Text>
              <Pressable
                disabled={busy}
                accessibilityLabel="Formular schließen"
                onPress={() => setEditor(null)}
              >
                <X size={24} color={ink} />
              </Pressable>
            </View>
            <ScrollView
              contentContainerStyle={s.content}
              keyboardShouldPersistTaps="handled"
            >
              <Text style={s.detail}>
                Flotte:{' '}
                {data?.fleets.find((f) => f.id === editor?.fleetId)?.name}
              </Text>
              <Text style={s.eyebrow}>MODELL</Text>
              <TextInput
                value={model}
                onChangeText={setModel}
                maxLength={80}
                style={s.input}
                placeholder="Zum Beispiel Audi A6"
                accessibilityLabel="Fahrzeugmodell"
                editable={!busy}
              />
              <Text style={s.eyebrow}>KENNZEICHEN</Text>
              <TextInput
                value={plate}
                onChangeText={setPlate}
                maxLength={20}
                autoCapitalize="characters"
                style={s.input}
                placeholder="HG IV 777"
                accessibilityLabel="Kennzeichen"
                editable={!busy}
              />
              <Text style={s.eyebrow}>FREIGEGEBENE KLASSEN</Text>
              <Text style={s.detail}>
                Ein Fahrzeug kann für mehrere Klassen freigegeben sein.
              </Text>
              {classes.map(([id, title]) => (
                <Pressable
                  key={id}
                  disabled={busy}
                  style={s.row}
                  accessibilityRole="checkbox"
                  accessibilityState={{ checked: services.includes(id) }}
                  onPress={() =>
                    setServices((current) =>
                      current.includes(id)
                        ? current.filter((v) => v !== id)
                        : [...current, id],
                    )
                  }
                >
                  <View style={s.check}>
                    {services.includes(id) && <Check size={19} color={gold} />}
                  </View>
                  <Text style={s.heading}>{title}</Text>
                </Pressable>
              ))}
              {!!error && (
                <Text accessibilityRole="alert" style={s.error}>
                  {error}
                </Text>
              )}
              <Pressable disabled={busy} style={s.primary} onPress={save}>
                {busy ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={s.primaryText}>Fahrzeug speichern</Text>
                )}
              </Pressable>
            </ScrollView>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Modal>
    </View>
  );
}
const ink = '#161a20',
  gold = '#aa8345';
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  content: { padding: 24, gap: 18, paddingBottom: 40 },
  title: {
    fontSize: 32,
    lineHeight: 37,
    color: ink,
    fontWeight: '600',
    letterSpacing: -1,
  },
  heading: { color: ink, fontSize: 15, fontWeight: '600' },
  detail: { color: '#7d7e80', fontSize: 13, lineHeight: 20 },
  eyebrow: { color: gold, fontSize: 10, fontWeight: '700', letterSpacing: 1.8 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 13,
    paddingVertical: 13,
  },
  flex: { flex: 1, gap: 7 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 18 },
  chip: {
    padding: 13,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#eee8dc',
  },
  chipActive: { backgroundColor: '#fcf7ed', borderColor: '#c7ac7f' },
  summary: {
    padding: 22,
    backgroundColor: '#fcf8f0',
    borderRadius: 24,
    gap: 10,
  },
  amount: { fontSize: 36, color: ink, fontWeight: '600' },
  add: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    padding: 12,
    borderRadius: 16,
    backgroundColor: ink,
  },
  primaryText: { color: '#fff', fontSize: 14, fontWeight: '600' },
  card: {
    padding: 16,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: '#efe8dc',
  },
  link: { color: gold, fontSize: 14, fontWeight: '600', paddingVertical: 10 },
  error: { color: '#ac493b', fontSize: 13, lineHeight: 20 },
  confirmation: { color: '#347151', fontSize: 14, lineHeight: 22 },
  input: {
    minHeight: 56,
    padding: 17,
    fontSize: 16,
    color: ink,
    borderWidth: 1,
    borderColor: '#e9e3d8',
    borderRadius: 16,
  },
  editorHeader: {
    padding: 24,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  check: {
    width: 26,
    height: 26,
    borderRadius: 7,
    borderWidth: 1,
    borderColor: '#ccb893',
    alignItems: 'center',
    justifyContent: 'center',
  },
  primary: {
    backgroundColor: ink,
    padding: 19,
    borderRadius: 18,
    alignItems: 'center',
    minHeight: 58,
  },
});
