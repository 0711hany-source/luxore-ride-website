import React from 'react';
import { Text, View } from 'react-native';
import type { RouteData } from '../../lib/mobility/domain';
import type { CustomerCoordinate } from './customer-live';
import { space } from './theme';
export type CustomerMapProps = {
  token: string;
  active: boolean;
  bookingId: string;
  /** Stage of the ride; decides what the map keeps in view. */
  status?: string;
  route: RouteData;
  /** The chauffeur's way to the pickup point (only during `accepted`). */
  approach?: { type: 'LineString'; coordinates: number[][] } | null;
  driver: CustomerCoordinate | null;
  nearby: CustomerCoordinate[];
};
export default function CustomerMap(_props: CustomerMapProps) {
  return (
    <View style={{ flex: 1, justifyContent: 'center', padding: space[5] }}>
      <Text>Die native Live-Karte ist in der App verfügbar.</Text>
    </View>
  );
}
