import React from 'react';
import { Text, View } from 'react-native';
import type { RouteData } from '../../lib/mobility/domain';
import type { CustomerCoordinate } from './customer-live';
export type CustomerMapProps = {
  token: string;
  active: boolean;
  bookingId: string;
  route: RouteData;
  driver: CustomerCoordinate | null;
  nearby: CustomerCoordinate[];
};
export default function CustomerMap(_props: CustomerMapProps) {
  return (
    <View style={{ flex: 1, justifyContent: 'center', padding: 24 }}>
      <Text>Die native Live-Karte ist in der Android-App verfügbar.</Text>
    </View>
  );
}
