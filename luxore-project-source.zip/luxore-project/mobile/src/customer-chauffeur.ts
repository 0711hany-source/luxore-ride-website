// Pure rules without device modules: the controllers load this file directly.
import type { Booking } from '../../lib/mobility/domain.ts';
import {
  RATING_COMMENT_MAX,
  RATING_WINDOW_MS,
} from '../../lib/mobility/rating-rules.ts';

export { RATING_COMMENT_MAX };
export type ShownRating = { average: number; count: number };
/**
 * What the customer sees of a chauffeur. `rating`:
 * a value → average and count, `null` → "Neu" (the server says: too few
 * ratings), `undefined` → the server sent no rating field: show nothing.
 */
export type ChauffeurView = {
  /** true: a reservation this chauffeur has taken over (not yet a ride). */
  confirmed: boolean;
  name: string;
  /** "E-Klasse · F-LX 1", only the parts the server delivered. */
  vehicle: string;
  photoId: string | null;
  /** false: an older server without picture/rating fields. */
  profile: boolean;
  rating: ShownRating | null | undefined;
};
const text = (value: unknown) =>
  typeof value === 'string' ? value.trim() : '';
/** Only a complete, plausible server value is shown; never a made-up one. */
export function shownRating(value: unknown): ShownRating | null | undefined {
  if (value === undefined) return undefined;
  if (!value || typeof value !== 'object') return null;
  const { average, count } = value as { average?: unknown; count?: unknown };
  return typeof average === 'number' &&
    Number.isFinite(average) &&
    average >= 1 &&
    average <= 5 &&
    typeof count === 'number' &&
    Number.isInteger(count) &&
    count > 0
    ? { average, count }
    : null;
}
/** Picture ids are opaque server ids; anything else is treated as "none". */
export const photoId = (value: unknown) =>
  typeof value === 'string' && /^[A-Za-z0-9_-]{1,60}$/.test(value)
    ? value
    : null;
const vehicleLine = (vehicle: unknown, plate: unknown) =>
  [text(vehicle), text(plate)].filter(Boolean).join(' · ');
/**
 * The chauffeur of a booking exactly as the server delivers him: the driver
 * of an accepted/running/finished ride, or the chauffeur who has taken a
 * reservation over. `null`: nobody is assigned (request/reservation open).
 */
export function chauffeurOf(
  booking: Booking | null | undefined,
): ChauffeurView | null {
  if (!booking) return null;
  const driver = booking.driver;
  if (driver && text(driver.name)) {
    const profile =
      driver.photo_id !== undefined || driver.rating !== undefined;
    return {
      confirmed: false,
      name: text(driver.name),
      vehicle: vehicleLine(driver.vehicle, driver.plate),
      photoId: photoId(driver.photo_id),
      profile,
      rating: shownRating(driver.rating),
    };
  }
  const chauffeur = booking.chauffeur;
  if (
    booking.status === 'reserved' &&
    chauffeur &&
    typeof chauffeur === 'object' &&
    text(chauffeur.name)
  )
    return {
      confirmed: true,
      name: text(chauffeur.name),
      vehicle: vehicleLine(chauffeur.vehicle, chauffeur.plate),
      photoId: photoId(chauffeur.photo_id),
      profile: true,
      rating: shownRating(chauffeur.rating) ?? null,
    };
  return null;
}
/** Status line of a booking; a taken-over reservation reads "Chauffeur bestätigt". */
export const confirmedTitle = 'Chauffeur bestätigt';
export const isConfirmedReservation = (booking: Booking | null | undefined) =>
  !!chauffeurOf(booking)?.confirmed;
const comma = (value: number) => value.toFixed(1).replace('.', ',');
/** "4,7 (12)" or "Neu"; `undefined` when the server sent nothing to show. */
export function ratingText(rating: ShownRating | null | undefined) {
  if (rating === undefined) return undefined;
  return rating ? `${comma(rating.average)} (${rating.count})` : 'Neu';
}
export function ratingLabel(rating: ShownRating | null | undefined) {
  if (rating === undefined) return undefined;
  return rating
    ? `Bewertung ${comma(rating.average)} von 5 aus ${rating.count} Bewertungen`
    : 'Neu, noch zu wenige Bewertungen';
}
/** Up to two initials for the picture placeholder. */
export function initials(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  const letters = (
    parts.length > 1
      ? [parts[0], parts[parts.length - 1]]
      : parts
  )
    .map((part) => Array.from(part)[0] || '')
    .join('');
  return letters.toUpperCase() || '?';
}
/**
 * Stars this customer already gave, from `GET bookings`. `null`: the server
 * does not deliver ratings yet (older deployment) – no rating is offered.
 */
export function givenRatings(value: unknown): Record<string, number> | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const given: Record<string, number> = {};
  for (const [id, stars] of Object.entries(value))
    if (validStars(stars)) given[id] = stars;
  return given;
}
export const validStars = (value: unknown): value is number =>
  typeof value === 'number' &&
  Number.isInteger(value) &&
  value >= 1 &&
  value <= 5;
export type RatingOffer =
  | { kind: 'none' }
  | { kind: 'given'; stars: number }
  | { kind: 'open' };
/**
 * May the customer rate this ride now? Only a finished ride with a chauffeur,
 * once, within the server's 14 days, and only if the server knows ratings.
 */
export function ratingOffer(
  booking: Booking | null | undefined,
  given: Record<string, number> | null | undefined,
  now: number,
): RatingOffer {
  if (!booking || !given || booking.status !== 'completed')
    return { kind: 'none' };
  const stars = given[booking.id];
  if (validStars(stars)) return { kind: 'given', stars };
  const done = booking.completed_at;
  if (
    !booking.driver_id ||
    typeof done !== 'number' ||
    !Number.isFinite(done) ||
    now - done > RATING_WINDOW_MS
  )
    return { kind: 'none' };
  return { kind: 'open' };
}
export type RatingBody = { bookingId: string; stars: number; comment?: string };
/** The request for `POST ratings`; throws a plain sentence for bad input. */
export function ratingBody(
  bookingId: string,
  stars: number,
  comment: string,
): RatingBody {
  if (!validStars(stars)) throw new Error('Bitte 1 bis 5 Sterne wählen.');
  const note = comment.trim();
  // Same count as the server (string length).
  if (note.length > RATING_COMMENT_MAX)
    throw new Error(
      `Der Kommentar darf höchstens ${RATING_COMMENT_MAX} Zeichen haben.`,
    );
  return note ? { bookingId, stars, comment: note } : { bookingId, stars };
}
/** Merge server stars with ones confirmed in this session (server wins). */
export function mergeRatings(
  server: Record<string, number> | null | undefined,
  local: Record<string, number>,
): Record<string, number> | null {
  return server ? { ...local, ...server } : null;
}
