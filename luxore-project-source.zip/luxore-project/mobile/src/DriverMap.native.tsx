import React, { Suspense, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import type { DriverMapProps } from './DriverMap';
// Keep the native SDK out of module evaluation before Expo registers the app.
const initialLoader = () => import('./NativeDriverMapView');
class MapBoundary extends React.Component<
  { children: React.ReactNode; onRetry: () => void },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <View style={s.wait}>
        <Text style={s.detail}>
          Die native Karte konnte nicht gestartet werden. Dein Fahrerbereich
          bleibt geöffnet.
        </Text>
        <Pressable accessibilityRole="button" onPress={this.props.onRetry}>
          <Text style={s.retry}>Kartenmodul erneut laden</Text>
        </Pressable>
      </View>
    );
  }
}
export function NativeMapGate({
  token,
  position,
  route,
  active,
  loader = initialLoader,
}: DriverMapProps & { loader?: typeof initialLoader }) {
  const [attempt, setAttempt] = useState(() => ({
    key: 0,
    Component: React.lazy(loader),
  }));
  if (!active || !token)
    return (
      <View style={s.wait}>
        <Text style={s.detail}>
          Kartenzugang wird geprüft. GPS und Schichtdienst laufen unabhängig.
        </Text>
      </View>
    );
  const Component = attempt.Component;
  return (
    <MapBoundary
      key={attempt.key}
      onRetry={() =>
        setAttempt((previous) => ({
          key: previous.key + 1,
          Component: React.lazy(loader),
        }))
      }
    >
      <Suspense
        fallback={
          <View style={s.wait}>
            <ActivityIndicator color="#aa8345" />
            <Text style={s.detail}>Native Karte startet …</Text>
          </View>
        }
      >
        <Component
          token={token}
          position={position}
          route={route}
          active={active}
        />
      </Suspense>
    </MapBoundary>
  );
}
export default function DriverMap(props: DriverMapProps) {
  return <NativeMapGate {...props} />;
}
const s = StyleSheet.create({
  wait: {
    flex: 1,
    backgroundColor: '#f5f2eb',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
    gap: 12,
  },
  detail: {
    color: '#806b48',
    fontSize: 13,
    lineHeight: 20,
    textAlign: 'center',
  },
  retry: { color: '#aa8345', padding: 20, fontSize: 14, fontWeight: '600' },
});
