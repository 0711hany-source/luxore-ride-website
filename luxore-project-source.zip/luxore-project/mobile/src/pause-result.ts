export type PauseResult = { active: false; serverStopped: boolean | null };
export function pauseStatusMessage(result: PauseResult | undefined) {
  return result?.serverStopped === true
    ? 'Standortübertragung beendet. Die Pausenmeldung wurde vom Server bestätigt.'
    : 'Standortübertragung auf diesem Gerät beendet. Der Server-Offlinezustand ist nicht bestätigt. Bitte die Schicht in der Fahreransicht prüfen.';
}
