import type { Fleet } from '../../lib/mobility/domain';
export type InvitationAction =
  | { action: 'invite_driver'; fleetId: string }
  | { action: 'join'; code: string };
export type Invitation = {
  code: string;
  expiresAt: number;
  shareText: string;
  fleetId: string;
};
export type InvitationData = { fleets: Fleet[]; userId: string };
export function invitationCode(value: string) {
  return value.trim().toUpperCase();
}
export function validInvitationCode(value: string) {
  return /^LX-[A-F0-9]{32}$/.test(invitationCode(value));
}
export type InvitationState = {
  fleets: Fleet[];
  loading: boolean;
  busy: InvitationAction | null;
  uncertain: InvitationAction | null;
  invitation: Invitation | null;
  joined: boolean;
  error: string;
  notice: string;
  updatedAt: number | null;
  signedOut: boolean;
};
const message = (e: unknown) =>
  e instanceof Error ? e.message : 'Keine Verbindung zur Flotte.';
export class FleetInvitationsController {
  private state: InvitationState = {
    fleets: [],
    loading: false,
    busy: null,
    uncertain: null,
    invitation: null,
    joined: false,
    error: '',
    notice: '',
    updatedAt: null,
    signedOut: false,
  };
  private active = false;
  private disposed = false;
  private revision = 0;
  private abort: AbortController | null = null;
  private read: Promise<void> | null = null;
  private listeners = new Set<() => void>();
  constructor(
    private userId: string,
    private load: (signal: AbortSignal) => Promise<InvitationData>,
    private write: (action: InvitationAction) => Promise<{
      ok?: boolean;
      code?: string;
      expiresAt?: number;
      shareText?: string;
      message?: string;
    }>,
  ) {}
  getSnapshot = () => this.state;
  subscribe = (f: () => void) => {
    this.listeners.add(f);
    return () => {
      this.listeners.delete(f);
    };
  };
  private publish(patch: Partial<InvitationState>) {
    if (this.disposed) return;
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((f) => f());
  }
  setActive(active: boolean) {
    if (this.disposed || this.active === active) return;
    this.active = active;
    this.revision++;
    this.abort?.abort();
    this.abort = null;
    this.read = null;
    this.publish({ loading: false });
    if (active) void this.refresh();
  }
  refresh(): Promise<void> {
    if (
      !this.active ||
      this.disposed ||
      this.state.busy ||
      this.state.signedOut
    )
      return Promise.resolve();
    if (this.read) return this.read;
    const rev = ++this.revision,
      abort = new AbortController();
    this.abort = abort;
    this.publish({ loading: true });
    const task = Promise.resolve().then(async () => {
      try {
        if (abort.signal.aborted) return;
        const data = await this.load(abort.signal);
        if (rev !== this.revision || !this.active || this.disposed) return;
        if (data.userId !== this.userId || !Array.isArray(data.fleets))
          throw new Error('Flottenzugang konnte nicht bestätigt werden.');
        const fleets = data.fleets.filter(
          (f) => f.owner_id === this.userId || f.deputy_id === this.userId,
        );
        this.publish({
          fleets,
          updatedAt: Date.now(),
          ...(this.state.uncertain ? {} : { error: '' }),
          ...(this.state.invitation &&
          !fleets.some((f) => f.id === this.state.invitation?.fleetId)
            ? { invitation: null }
            : {}),
        });
      } catch (e) {
        if (rev !== this.revision || !this.active || this.disposed) return;
        const status = (e as { status?: number }).status;
        this.publish({
          updatedAt: null,
          ...(status === 401
            ? {
                signedOut: true,
                fleets: [],
                invitation: null,
                uncertain: null,
                error: message(e),
              }
            : status === 403
              ? {
                  fleets: [],
                  invitation: null,
                  ...(this.state.uncertain ? {} : { error: '' }),
                }
              : { error: message(e) }),
        });
      } finally {
        if (this.read === task) {
          this.read = null;
          this.abort = null;
          this.publish({ loading: false });
        }
      }
    });
    this.read = task;
    return task;
  }
  canSubmit(action: InvitationAction, now = Date.now()) {
    const s = this.state;
    if (!this.active || this.disposed || s.busy || s.signedOut || s.joined)
      return false;
    if (s.uncertain && JSON.stringify(s.uncertain) !== JSON.stringify(action))
      return false;
    return action.action === 'join'
      ? validInvitationCode(action.code)
      : !s.loading &&
          s.updatedAt !== null &&
          now - s.updatedAt < 30000 &&
          s.fleets.some((f) => f.id === action.fleetId);
  }
  async submit(action: InvitationAction) {
    const intended: InvitationAction =
      action.action === 'join'
        ? { action: 'join', code: invitationCode(action.code) }
        : { ...action };
    if (!this.canSubmit(intended)) return;
    this.revision++;
    this.abort?.abort();
    this.abort = null;
    this.read = null;
    this.publish({
      busy: intended,
      loading: false,
      error: '',
      notice: '',
      invitation: null,
    });
    try {
      const value = await this.write(intended);
      if (value.ok !== true) throw new Error('Die Speicherbestätigung fehlt.');
      if (intended.action === 'invite_driver') {
        if (
          !validInvitationCode(value.code || '') ||
          !Number.isFinite(value.expiresAt) ||
          Number(value.expiresAt) <= Date.now() ||
          typeof value.shareText !== 'string'
        )
          throw new Error('Die Einladungsbestätigung ist unvollständig.');
        this.publish({
          invitation: {
            code: value.code!,
            expiresAt: value.expiresAt!,
            shareText: value.shareText,
            fleetId: intended.fleetId,
          },
          uncertain: null,
          notice: 'Einladung erstellt.',
        });
      } else
        this.publish({
          joined: true,
          uncertain: null,
          notice:
            value.message ||
            'Beitritt bestätigt. Die Leitung prüft dein Fahrerprofil.',
        });
    } catch (e) {
      const status = (e as { status?: number }).status;
      this.publish({
        error: message(e),
        uncertain: !status || status >= 500 ? intended : null,
        ...(status === 401
          ? { signedOut: true, fleets: [], invitation: null }
          : {}),
      });
    } finally {
      this.publish({ busy: null });
      if (this.active && !this.disposed) await this.refresh();
    }
  }
  dispose() {
    this.disposed = true;
    this.active = false;
    this.revision++;
    this.abort?.abort();
    this.read = null;
    this.listeners.clear();
  }
}
