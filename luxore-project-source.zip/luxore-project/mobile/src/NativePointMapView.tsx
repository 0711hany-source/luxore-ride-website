import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Mapbox from '@rnmapbox/maps';
import { MapPin, Minus, Plus } from 'lucide-react-native';
import { MapStartup } from './map-startup';
import type { PointMapProps } from './PointMap';
const startup = new MapStartup(Mapbox);
export default function NativePointMapView(props: PointMapProps) {
  'use no memo';
  const [configured, setConfigured] = useState(''),
    [failed, setFailed] = useState(false),
    [attempt, setAttempt] = useState(0);
  const camera = useRef<React.ComponentRef<typeof Mapbox.Camera>>(null);
  const callbacks = useRef(props);
  const loadingTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    callbacks.current = props;
  }, [props]);
  useEffect(() => {
    let alive = true;
    loadingTimer.current = setTimeout(() => {
      if (alive) {
        setFailed(true);
        callbacks.current.onError();
      }
    }, 20000);
    void startup
      .prepare(props.token, () => alive)
      .then((ok) => {
        if (alive && ok) setConfigured(props.token);
      })
      .catch(() => {
        if (alive) {
          setFailed(true);
          callbacks.current.onError();
        }
      });
    return () => {
      alive = false;
      if (loadingTimer.current) clearTimeout(loadingTimer.current);
    };
  }, [props.token, attempt]);
  if (configured !== props.token || failed)
    return (
      <View style={s.wait}>
        {failed ? (
          <Pressable
            accessibilityRole="button"
            onPress={() => {
              setFailed(false);
              setAttempt((v) => v + 1);
            }}
          >
            <Text style={s.detail}>Karte erneut starten</Text>
          </Pressable>
        ) : (
          <ActivityIndicator color="#aa8345" />
        )}
      </View>
    );
  function zoom(delta: number) {
    callbacks.current.onMoving();
    camera.current?.setCamera({
      zoomLevel: Math.max(0, Math.min(20, props.center.zoom + delta)),
      animationDuration: 300,
    });
  }
  return (
    <View style={s.root}>
      <Mapbox.MapView
        style={s.root}
        styleURL="mapbox://styles/mapbox/streets-v12"
        surfaceView={false}
        compassEnabled={false}
        scaleBarEnabled={false}
        rotateEnabled={false}
        pitchEnabled={false}
        scrollEnabled={!props.locked}
        zoomEnabled={!props.locked}
        logoPosition={{ bottom: 12, left: 10 }}
        attributionPosition={{ bottom: 12, left: 100 }}
        onDidFinishLoadingMap={() => {
          if (loadingTimer.current) clearTimeout(loadingTimer.current);
          callbacks.current.onReady();
        }}
        onMapLoadingError={() => {
          setFailed(true);
          callbacks.current.onError();
        }}
        onCameraChanged={() => callbacks.current.onMoving()}
        onMapIdle={(state) =>
          callbacks.current.onIdle({
            lng: state.properties.center[0],
            lat: state.properties.center[1],
            zoom: state.properties.zoom,
          })
        }
      >
        <Mapbox.Camera
          ref={camera}
          defaultSettings={{
            centerCoordinate: [props.center.lng, props.center.lat],
            zoomLevel: props.center.zoom,
            pitch: 0,
            heading: 0,
          }}
        />
      </Mapbox.MapView>
      <View pointerEvents="none" style={s.crosshair}>
        <View style={s.shadow} />
        <MapPin
          size={48}
          color="#aa8345"
          fill="#fff"
          strokeWidth={2.2}
          style={s.pin}
        />
        <View style={s.dot} />
      </View>
      <View style={s.controls}>
        {[1, -1].map((delta) => (
          <Pressable
            key={delta}
            disabled={props.locked}
            accessibilityRole="button"
            accessibilityLabel={
              delta > 0 ? 'Karte vergrößern' : 'Karte verkleinern'
            }
            style={s.control}
            onPress={() => zoom(delta)}
          >
            {delta > 0 ? (
              <Plus size={23} color="#161a20" />
            ) : (
              <Minus size={23} color="#161a20" />
            )}
          </Pressable>
        ))}
      </View>
    </View>
  );
}
const s = StyleSheet.create({
  root: { flex: 1 },
  wait: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  detail: { padding: 20, color: '#aa8345' },
  crosshair: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    width: 48,
    height: 48,
    marginLeft: -24,
    marginTop: -44,
    alignItems: 'center',
  },
  pin: { position: 'absolute', top: 0 },
  dot: {
    position: 'absolute',
    bottom: 1,
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#aa8345',
  },
  shadow: {
    position: 'absolute',
    bottom: -5,
    width: 26,
    height: 12,
    borderRadius: 13,
    backgroundColor: '#aa834530',
  },
  controls: { position: 'absolute', right: 16, bottom: 44, gap: 10 },
  control: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 3,
  },
});
