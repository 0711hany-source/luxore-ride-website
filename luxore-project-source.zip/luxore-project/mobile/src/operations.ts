import type { Booking, Driver, Fleet } from '../../lib/mobility/domain';
export type OperationsDriver = Driver & {
  fleet_id: string | null;
  fleet_name?: string | null;
};
export type OperationsData = {
  drivers: OperationsDriver[];
  bookings: Booking[];
  fleets: Fleet[];
  revenue: {
    fleet_id: string;
    gross: number;
    collected: number;
    outstanding: number;
    trips: number;
  }[];
};
export type Approval = { driverId: string; approved: boolean };
export type OperationsState = {
  data: OperationsData | null;
  refreshing: boolean;
  changing: Approval | null;
  uncertain: Approval | null;
  loadError: string;
  actionError: string;
  notice: string;
  updatedAt: number | null;
};
const status = (error: unknown) => (error as { status?: number })?.status;
const message = (error: unknown) =>
  error instanceof Error ? error.message : 'Keine Verbindung zur Disposition.';
export function approvalBlocked(driver: OperationsDriver, bookings: Booking[]) {
  return !!(
    driver.online ||
    driver.session_id ||
    bookings.some(
      (b) =>
        b.driver_id === driver.id &&
        (['accepted', 'arrived', 'riding'].includes(b.status) ||
          (b.status === 'completed' && b.payment_status === 'unpaid')),
    )
  );
}
export class OperationsController {
  private state: OperationsState = {
    data: null,
    refreshing: false,
    changing: null,
    uncertain: null,
    loadError: '',
    actionError: '',
    notice: '',
    updatedAt: null,
  };
  private listeners = new Set<() => void>();
  private active = false;
  private disposed = false;
  private revision = 0;
  private read: Promise<void> | null = null;
  private abort: AbortController | null = null;
  constructor(
    private load: (signal: AbortSignal) => Promise<OperationsData>,
    private write: (body: Approval) => Promise<{ ok: boolean }>,
  ) {}
  getSnapshot = () => this.state;
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  private publish(patch: Partial<OperationsState>) {
    if (this.disposed) return;
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((listener) => listener());
  }
  private abandonRead() {
    this.abort?.abort();
    this.abort = null;
    this.read = null;
  }
  setActive(value: boolean) {
    if (this.disposed || this.active === value) return;
    this.active = value;
    this.revision++;
    this.abandonRead();
    this.publish({ refreshing: false });
    if (value) void this.refresh();
  }
  refresh(): Promise<void> {
    if (!this.active || this.disposed || this.state.changing)
      return Promise.resolve();
    if (this.read) return this.read;
    const revision = ++this.revision,
      abort = new AbortController();
    this.abort = abort;
    this.publish({ refreshing: true });
    const task = Promise.resolve().then(async () => {
      try {
        if (abort.signal.aborted) return;
        const data = await this.load(abort.signal);
        if (revision !== this.revision || !this.active || this.disposed) return;
        if (
          ![data?.drivers, data?.bookings, data?.fleets, data?.revenue].every(
            Array.isArray,
          )
        )
          throw new Error(
            'Die Dispositionsdaten sind unvollständig. Bitte neu laden.',
          );
        const pending = this.state.uncertain;
        const confirmed =
          pending &&
          data.drivers.some(
            (d) =>
              d.id === pending.driverId && !!d.approved === pending.approved,
          );
        this.publish({
          data,
          loadError: '',
          updatedAt: Date.now(),
          ...(confirmed
            ? {
                uncertain: null,
                actionError: '',
                notice: 'Der aktuelle Serverstand bestätigt die Änderung.',
              }
            : {}),
        });
      } catch (error) {
        if (revision !== this.revision || !this.active || this.disposed) return;
        abort.abort(); // Cancel the sibling GET when the combined snapshot fails.
        this.publish({
          loadError: message(error),
          ...(status(error) === 401 || status(error) === 403
            ? { data: null, updatedAt: null, uncertain: null, notice: '' }
            : {}),
        });
      } finally {
        // Old finally blocks must not release a foreground replacement request.
        if (this.read === task) {
          this.read = null;
          this.abort = null;
          this.publish({ refreshing: false });
        }
      }
    });
    this.read = task;
    return task;
  }
  canChange(body: Approval, now = Date.now()) {
    const { data, changing, uncertain, loadError, updatedAt, refreshing } =
      this.state;
    const driver = data?.drivers.find((d) => d.id === body.driverId);
    return !!(
      !this.disposed &&
      this.active &&
      data &&
      driver &&
      !changing &&
      !refreshing &&
      !loadError &&
      updatedAt !== null &&
      now - updatedAt < 30000 &&
      (!uncertain ||
        (uncertain.driverId === body.driverId &&
          uncertain.approved === body.approved)) &&
      (body.approved || !approvalBlocked(driver, data.bookings))
    );
  }
  async approve(body: Approval) {
    if (!this.canChange(body)) return;
    const intended = { ...body };
    this.revision++;
    this.abandonRead();
    this.publish({
      changing: intended,
      actionError: '',
      notice: '',
      refreshing: false,
    });
    try {
      const result = await this.write(intended); // Never cancelled as a lifecycle read.
      if (result.ok !== true)
        throw new Error(
          'Keine eindeutige Speicherbestätigung. Bitte Serverstand prüfen.',
        );
      this.publish({
        data: this.state.data && {
          ...this.state.data,
          drivers: this.state.data.drivers.map((d) =>
            d.id === intended.driverId
              ? { ...d, approved: Number(intended.approved) }
              : d,
          ),
        },
        uncertain: null,
        notice: intended.approved
          ? 'Fahrer freigegeben.'
          : 'Fahrerfreigabe zurückgenommen.',
      });
    } catch (error) {
      const code = status(error);
      this.publish({
        actionError: message(error),
        uncertain: !code || code >= 500 ? intended : null,
        ...(code === 401 || code === 403
          ? { data: null, updatedAt: null }
          : {}),
      });
    } finally {
      this.publish({ changing: null });
      if (this.active && !this.disposed) await this.refresh();
    }
  }
  dispose() {
    this.disposed = true;
    this.active = false;
    this.revision++;
    this.abandonRead();
    this.listeners.clear();
  }
}
