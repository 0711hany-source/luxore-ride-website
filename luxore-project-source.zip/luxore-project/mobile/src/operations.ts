import type { Booking, Driver, Fleet } from '../../lib/mobility/domain';
export type OperationsDriver = Driver & {
  fleet_id: string | null;
  fleet_name?: string | null;
};
export type TeamMember = {
  user_id: string;
  name: string;
  fleet_id: string | null;
  role?: 'staff' | 'driver';
  can_remove?: number;
};
export type MembershipChange =
  | {
      action: 'assign';
      userId: string;
      fleetId: string;
      role: 'staff' | 'driver';
    }
  | { action: 'remove_member'; userId: string; fleetId: string };
export type OperationsData = {
  drivers: OperationsDriver[];
  bookings: Booking[];
  fleets: Fleet[];
  userId?: string;
  canManage?: boolean;
  employees?: TeamMember[];
  revenue: {
    fleet_id: string;
    gross: number;
    collected: number;
    outstanding: number;
    trips: number;
  }[];
};
export type Approval = { driverId: string; approved: boolean };
export type DeputyChange = { fleetId: string; deputyId: string | null };
export type OperationsState = {
  data: OperationsData | null;
  refreshing: boolean;
  changing: Approval | null;
  memberChanging: MembershipChange | null;
  memberUncertain: MembershipChange | null;
  deputyChanging: DeputyChange | null;
  deputyUncertain: DeputyChange | null;
  uncertain: Approval | null;
  loadError: string;
  actionError: string;
  notice: string;
  updatedAt: number | null;
};
const status = (error: unknown) => (error as { status?: number })?.status;
const message = (error: unknown) =>
  error instanceof Error ? error.message : 'Keine Verbindung zur Disposition.';
export function approvalBlocked(driver: OperationsDriver, bookings: Booking[]) {
  return !!(
    driver.online ||
    driver.session_id ||
    bookings.some(
      (b) =>
        b.driver_id === driver.id &&
        (['accepted', 'arrived', 'riding'].includes(b.status) ||
          (b.status === 'completed' && b.payment_status === 'unpaid')),
    )
  );
}
export class OperationsController {
  private state: OperationsState = {
    data: null,
    refreshing: false,
    changing: null,
    memberChanging: null,
    memberUncertain: null,
    deputyChanging: null,
    deputyUncertain: null,
    uncertain: null,
    loadError: '',
    actionError: '',
    notice: '',
    updatedAt: null,
  };
  private listeners = new Set<() => void>();
  private active = false;
  private disposed = false;
  private revision = 0;
  private read: Promise<void> | null = null;
  private abort: AbortController | null = null;
  constructor(
    private load: (signal: AbortSignal) => Promise<OperationsData>,
    private write: (body: Approval) => Promise<{ ok: boolean }>,
    private writeDeputy?: (body: DeputyChange) => Promise<{ ok: boolean }>,
    private writeMember?: (body: MembershipChange) => Promise<{ ok: boolean }>,
  ) {}
  getSnapshot = () => this.state;
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  private publish(patch: Partial<OperationsState>) {
    if (this.disposed) return;
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((listener) => listener());
  }
  private abandonRead() {
    this.abort?.abort();
    this.abort = null;
    this.read = null;
  }
  setActive(value: boolean) {
    if (this.disposed || this.active === value) return;
    this.active = value;
    this.revision++;
    this.abandonRead();
    this.publish({ refreshing: false });
    if (value) void this.refresh();
  }
  refresh(): Promise<void> {
    if (
      !this.active ||
      this.disposed ||
      this.state.changing ||
      this.state.deputyChanging ||
      this.state.memberChanging
    )
      return Promise.resolve();
    if (this.read) return this.read;
    const revision = ++this.revision,
      abort = new AbortController();
    this.abort = abort;
    this.publish({ refreshing: true });
    const task = Promise.resolve().then(async () => {
      try {
        if (abort.signal.aborted) return;
        const data = await this.load(abort.signal);
        if (revision !== this.revision || !this.active || this.disposed) return;
        if (
          ![data?.drivers, data?.bookings, data?.fleets, data?.revenue].every(
            Array.isArray,
          ) ||
          (data.employees !== undefined && !Array.isArray(data.employees))
        )
          throw new Error(
            'Die Dispositionsdaten sind unvollständig. Bitte neu laden.',
          );
        const pending = this.state.uncertain;
        const confirmed =
          pending &&
          data.drivers.some(
            (d) =>
              d.id === pending.driverId && !!d.approved === pending.approved,
          );
        const deputyConfirmed =
          this.state.deputyUncertain &&
          data.fleets.some(
            (f) =>
              f.id === this.state.deputyUncertain?.fleetId &&
              f.deputy_id === this.state.deputyUncertain.deputyId,
          );
        const member = this.state.memberUncertain;
        const memberConfirmed =
          member &&
          Array.isArray(data.employees) &&
          data.fleets.some((f) => f.id === member.fleetId) &&
          (member.action === 'assign'
            ? data.employees.some(
                (e) =>
                  e.user_id === member.userId &&
                  e.fleet_id === member.fleetId &&
                  e.role === member.role,
              )
            : !data.employees.some(
                (e) =>
                  e.user_id === member.userId && e.fleet_id === member.fleetId,
              ));
        this.publish({
          ...(memberConfirmed
            ? {
                memberUncertain: null,
                actionError: '',
                notice: 'Der aktuelle Serverstand bestätigt die Teamzuordnung.',
              }
            : {}),
          ...(deputyConfirmed
            ? {
                deputyUncertain: null,
                actionError: '',
                notice:
                  'Der aktuelle Serverstand bestätigt die Stellvertretung.',
              }
            : {}),
          data,
          loadError: '',
          updatedAt: Date.now(),
          ...(confirmed
            ? {
                uncertain: null,
                actionError: '',
                notice: 'Der aktuelle Serverstand bestätigt die Änderung.',
              }
            : {}),
        });
      } catch (error) {
        if (revision !== this.revision || !this.active || this.disposed) return;
        abort.abort(); // Cancel the sibling GET when the combined snapshot fails.
        this.publish({
          loadError: message(error),
          ...(status(error) === 401 || status(error) === 403
            ? {
                data: null,
                updatedAt: null,
                uncertain: null,
                deputyUncertain: null,
                memberUncertain: null,
                notice: '',
              }
            : {}),
        });
      } finally {
        // Old finally blocks must not release a foreground replacement request.
        if (this.read === task) {
          this.read = null;
          this.abort = null;
          this.publish({ refreshing: false });
        }
      }
    });
    this.read = task;
    return task;
  }
  canChange(body: Approval, now = Date.now()) {
    const { data, changing, uncertain, loadError, updatedAt, refreshing } =
      this.state;
    const driver = data?.drivers.find((d) => d.id === body.driverId);
    return !!(
      !this.disposed &&
      this.active &&
      data &&
      driver &&
      !changing &&
      !this.state.deputyChanging &&
      !this.state.deputyUncertain &&
      !this.state.memberChanging &&
      !this.state.memberUncertain &&
      !refreshing &&
      !loadError &&
      updatedAt !== null &&
      now - updatedAt < 30000 &&
      (!uncertain ||
        (uncertain.driverId === body.driverId &&
          uncertain.approved === body.approved)) &&
      (body.approved || !approvalBlocked(driver, data.bookings))
    );
  }
  async approve(body: Approval) {
    if (!this.canChange(body)) return;
    const intended = { ...body };
    this.revision++;
    this.abandonRead();
    this.publish({
      changing: intended,
      actionError: '',
      notice: '',
      refreshing: false,
    });
    try {
      const result = await this.write(intended); // Never cancelled as a lifecycle read.
      if (result.ok !== true)
        throw new Error(
          'Keine eindeutige Speicherbestätigung. Bitte Serverstand prüfen.',
        );
      this.publish({
        data: this.state.data && {
          ...this.state.data,
          drivers: this.state.data.drivers.map((d) =>
            d.id === intended.driverId
              ? { ...d, approved: Number(intended.approved) }
              : d,
          ),
        },
        uncertain: null,
        notice: intended.approved
          ? 'Fahrer freigegeben.'
          : 'Fahrerfreigabe zurückgenommen.',
      });
    } catch (error) {
      const code = status(error);
      this.publish({
        actionError: message(error),
        uncertain: !code || code >= 500 ? intended : null,
        ...(code === 401 || code === 403
          ? { data: null, updatedAt: null }
          : {}),
      });
    } finally {
      this.publish({ changing: null });
      if (this.active && !this.disposed) await this.refresh();
    }
  }
  canSetDeputy(body: DeputyChange, now = Date.now()) {
    const s = this.state,
      data = s.data,
      fleet = data?.fleets.find((f) => f.id === body.fleetId);
    return !!(
      this.writeDeputy &&
      this.active &&
      !this.disposed &&
      data &&
      fleet &&
      data.userId &&
      (data.canManage === true || fleet.owner_id === data.userId) &&
      !s.changing &&
      !s.deputyChanging &&
      !s.memberChanging &&
      !s.memberUncertain &&
      !s.uncertain &&
      !s.refreshing &&
      !s.loadError &&
      s.updatedAt !== null &&
      now - s.updatedAt < 30000 &&
      (!s.deputyUncertain ||
        (s.deputyUncertain.fleetId === body.fleetId &&
          s.deputyUncertain.deputyId === body.deputyId)) &&
      (body.deputyId === null ||
        (body.deputyId !== fleet.owner_id &&
          data.employees?.some(
            (e) => e.user_id === body.deputyId && e.fleet_id === body.fleetId,
          ))) &&
      (body.deputyId !== fleet.deputy_id || !!s.deputyUncertain)
    );
  }
  async setDeputy(body: DeputyChange) {
    if (!this.canSetDeputy(body)) return;
    const intended = { ...body };
    this.revision++;
    this.abandonRead();
    this.publish({
      deputyChanging: intended,
      refreshing: false,
      actionError: '',
      notice: '',
    });
    try {
      const result = await this.writeDeputy!(intended);
      if (result.ok !== true)
        throw new Error(
          'Keine eindeutige Speicherbestätigung. Bitte Serverstand prüfen.',
        );
      this.publish({
        data: this.state.data && {
          ...this.state.data,
          fleets: this.state.data.fleets.map((f) =>
            f.id === intended.fleetId
              ? { ...f, deputy_id: intended.deputyId }
              : f,
          ),
        },
        deputyUncertain: null,
        notice: intended.deputyId
          ? 'Stellvertretung gespeichert.'
          : 'Stellvertretung aufgehoben.',
      });
    } catch (error) {
      const code = status(error);
      this.publish({
        actionError: message(error),
        deputyUncertain: !code || code >= 500 ? intended : null,
        ...(code === 401 || code === 403
          ? { data: null, updatedAt: null }
          : {}),
      });
    } finally {
      this.publish({ deputyChanging: null });
      if (this.active && !this.disposed) await this.refresh();
    }
  }
  canChangeMember(body: MembershipChange, now = Date.now()) {
    const s = this.state,
      data = s.data;
    const fleet = data?.fleets.find((f) => f.id === body.fleetId);
    const employee = data?.employees?.find((e) => e.user_id === body.userId);
    if (
      !this.writeMember ||
      !this.active ||
      this.disposed ||
      !data ||
      !fleet ||
      !employee ||
      !data.userId ||
      s.changing ||
      s.deputyChanging ||
      s.memberChanging ||
      s.uncertain ||
      s.deputyUncertain ||
      s.refreshing ||
      s.loadError ||
      s.updatedAt === null ||
      now - s.updatedAt >= 30000 ||
      (s.memberUncertain && !sameMembership(s.memberUncertain, body))
    )
      return false;
    if (
      data.fleets.some(
        (f) => f.owner_id === body.userId || f.deputy_id === body.userId,
      )
    )
      return false;
    const driver = data.drivers.find((d) => d.id === body.userId);
    if (
      employee.can_remove === 0 ||
      (driver && approvalBlocked(driver, data.bookings))
    )
      return false;
    if (body.action === 'remove_member')
      return (
        employee.fleet_id === body.fleetId &&
        (data.canManage === true ||
          fleet.owner_id === data.userId ||
          fleet.deputy_id === data.userId)
      );
    return (
      body.action === 'assign' &&
      data.canManage === true &&
      (body.role === 'staff' || body.role === 'driver') &&
      (employee.role === 'staff' || employee.role === 'driver') &&
      body.role === employee.role &&
      (employee.fleet_id !== body.fleetId || !!s.memberUncertain)
    );
  }
  async changeMember(body: MembershipChange) {
    if (!this.canChangeMember(body)) return;
    const intended = { ...body };
    this.revision++;
    this.abandonRead();
    this.publish({
      memberChanging: intended,
      refreshing: false,
      actionError: '',
      notice: '',
    });
    try {
      const result = await this.writeMember!(intended); // A confirmation is never a lifecycle read.
      if (result.ok !== true)
        throw new Error(
          'Keine eindeutige Speicherbestätigung. Bitte Serverstand prüfen.',
        );
      // Assignment resets the driver's eligibility/vehicle server-side. Do not act on old lists.
      this.publish({
        memberUncertain: null,
        updatedAt: null,
        notice:
          intended.action === 'assign'
            ? 'Mitarbeiter zugeordnet.'
            : 'Mitarbeiter aus der Flotte entfernt.',
      });
    } catch (error) {
      const code = status(error);
      this.publish({
        actionError: message(error),
        memberUncertain: !code || code >= 500 ? intended : null,
        updatedAt: null,
        ...(code === 401 || code === 403 ? { data: null } : {}),
      });
    } finally {
      this.publish({ memberChanging: null });
      if (this.active && !this.disposed) await this.refresh();
    }
  }
  dispose() {
    this.disposed = true;
    this.active = false;
    this.revision++;
    this.abandonRead();
    this.listeners.clear();
  }
}

function sameMembership(a: MembershipChange, b: MembershipChange) {
  return (
    a.action === b.action &&
    a.userId === b.userId &&
    a.fleetId === b.fleetId &&
    (a.action !== 'assign' || (b.action === 'assign' && a.role === b.role))
  );
}
