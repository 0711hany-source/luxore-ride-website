import * as SecureStore from 'expo-secure-store';
import type { BookingStore, PendingBooking } from './customer-booking';
// Account ID scopes confirmed-address data. Never persist preview suggestions
// or put the account bearer token in a key, URL or public store.
export function bookingStore(accountId: string): BookingStore {
  const key = 'luxore-booking-pending-v1-' + encodeURIComponent(accountId);
  return {
    async load() {
      const value = await SecureStore.getItemAsync(key);
      return value ? (JSON.parse(value) as PendingBooking) : null;
    },
    async save(value) {
      await SecureStore.setItemAsync(key, JSON.stringify(value));
    },
    async clear() {
      await SecureStore.deleteItemAsync(key);
    },
  };
}
