import * as SecureStore from 'expo-secure-store';
import type { BookingStore, PendingBooking } from './customer-booking';
/** SecureStore accepts only [A-Za-z0-9._-]; account IDs look like "account:<uuid>". */
export function secureKeyPart(value: string) {
  return value.replace(
    /[^A-Za-z0-9-]/g,
    (c) => '_' + c.codePointAt(0)!.toString(16) + '.',
  );
}
/** A protected-storage call must never leave a screen waiting forever. */
export function storageDeadline<T>(work: Promise<T>, ms = 8000): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(
      () => reject(new Error('Der Gerätespeicher antwortet nicht.')),
      ms,
    );
    work.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      },
    );
  });
}
// Account ID scopes confirmed-address data. Never persist preview suggestions
// or put the account bearer token in a key, URL or public store.
export const bookingKey = (accountId: string) =>
  'luxore-booking-pending-v1-' + secureKeyPart(accountId);
export function bookingStore(accountId: string): BookingStore {
  const key = bookingKey(accountId);
  return {
    async load() {
      const value = await storageDeadline(SecureStore.getItemAsync(key));
      if (!value) return null;
      try {
        return JSON.parse(value) as PendingBooking;
      } catch {
        // Unreadable text can never be retried; the controller discards it.
        return {} as PendingBooking;
      }
    },
    async save(value) {
      await storageDeadline(
        SecureStore.setItemAsync(key, JSON.stringify(value)),
      );
    },
    async clear() {
      await storageDeadline(SecureStore.deleteItemAsync(key));
    },
  };
}
