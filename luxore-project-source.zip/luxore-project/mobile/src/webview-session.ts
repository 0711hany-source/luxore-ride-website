// Android postUrl drops custom headers. Keep native credentials in a GET
// header, never in the URL, request body, HTML or injected JavaScript.
const origin = 'https://luxoreride.de';
export function webviewSessionSource(path: string, token: string | null) {
  if (
    ![
      '/mobile/customer',
      '/mobile/driver',
      '/disposition',
      '/betreiber',
    ].includes(path)
  )
    throw new Error('Ungültiger App-Bildschirm.');
  if (!token) return { uri: origin + path };
  if (!/^[a-f0-9]{64}$/.test(token)) throw new Error('Bitte erneut anmelden.');
  return {
    uri:
      origin + '/api/mobility/app-session?target=' + encodeURIComponent(path),
    method: 'GET',
    headers: {
      Authorization: 'Bearer ' + token,
      Origin: origin,
      'X-Luxore-Client': 'native-v1',
    },
  };
}
