/** Resume independent native services without waiting for the account network request. */
export class ForegroundRefresh {
  private pending = new Map<string, Promise<void>>();

  private run(key: string, work: () => Promise<void>) {
    const existing = this.pending.get(key);
    if (existing) return existing;
    const task = Promise.resolve()
      .then(work)
      .finally(() => {
        if (this.pending.get(key) === task) this.pending.delete(key);
      });
    this.pending.set(key, task);
    return task;
  }

  refresh(
    session: string | null,
    account: () => Promise<void>,
    location?: () => Promise<void>,
  ) {
    const tasks = [this.run('account:' + (session || 'anonymous'), account)];
    if (location) tasks.push(this.run('location', location));
    // Each caller handles its own UI errors. One failure must not cancel the other lane.
    return Promise.allSettled(tasks);
  }
}
