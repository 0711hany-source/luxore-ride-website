// Ablauf der Anmeldung in drei kurzen Schritten (docs/REDESIGN-KONZEPT.md,
// 4.5 Punkt 7): E-Mail → (nur Registrierung) Angaben → Code. Reine
// Ablaufsteuerung ohne React und ohne Netzwerk: die Server-Aufrufe werden
// unverändert von außen hereingereicht.

export type SignInStep = 'email' | 'details' | 'code';
export type SignInMode = 'login' | 'register';

export type CodeRequest = {
  action: 'code';
  mode: SignInMode;
  email: string;
  name: string;
  phone: string;
  kind: string;
  privacy: boolean;
};

export type SignInState = {
  step: SignInStep;
  mode: SignInMode;
  email: string;
  name: string;
  phone: string;
  kind: string;
  privacy: boolean;
  code: string;
  challengeId: string;
  busy: boolean;
  error: string;
  message: string;
  /** Zeitpunkt (ms), ab dem der Server wieder einen Code verschickt. */
  retryAt: number;
};

export type SignInDeps<Session> = {
  requestCode: (body: CodeRequest) => Promise<{ challengeId: string }>;
  verify: (challengeId: string, code: string) => Promise<Session>;
  onSignedIn: (session: Session) => Promise<void>;
  /** Die Anfrage hat das Gerät verlassen, die Antwort blieb aus. */
  isTimeout: (error: unknown) => boolean;
  defaultKind: string;
  now?: () => number;
};

/** Der Server nimmt je E-Mail-Adresse eine Code-Anfrage pro Minute an. */
export const codeRetryMs = 60000;

export const signInTexts = {
  email: 'Bitte eine gültige E-Mail-Adresse eingeben.',
  details: 'Bitte Name, Telefonnummer und Datenschutz bestätigen.',
  code: 'Bitte den sechsstelligen Code eingeben.',
  sent: 'Dein Code ist unterwegs und 10 Minuten gültig.',
  unclear:
    'Die Bestätigung des Servers steht noch aus – der Versand ist nicht sicher gescheitert. Ein eventuell schon angekommener Code gehört zu dieser unterbrochenen Anfrage und kann nicht eingegeben werden. Bitte nach Ablauf der Wartezeit einen neuen Code anfordern.',
} as const;

export function emailError(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())
    ? ''
    : signInTexts.email;
}

export function detailsError(v: {
  name: string;
  phone: string;
  privacy: boolean;
}) {
  return !v.name.trim() || !/^\+?[\d\s()-]{6,30}$/.test(v.phone) || !v.privacy
    ? signInTexts.details
    : '';
}

/** Verbleibende Wartezeit in ganzen Sekunden. */
export function waitSeconds(retryAt: number, now: number) {
  return Math.max(0, Math.ceil((retryAt - now) / 1000));
}

/** 47 → „0:47“, 60 → „1:00“. */
export function formatWait(seconds: number) {
  const s = Math.max(0, Math.floor(seconds));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

/** Beschriftung des Knopfs zum (erneuten) Anfordern. */
export function requestLabel(seconds: number, idle: string) {
  return seconds > 0 ? `Neuer Code in ${formatWait(seconds)}` : idle;
}

/** Anzahl und Position der Schritte: Anmelden 2, Registrieren 3. */
export function stepPosition(step: SignInStep, mode: SignInMode) {
  const steps: SignInStep[] =
    mode === 'register' ? ['email', 'details', 'code'] : ['email', 'code'];
  return { index: Math.max(0, steps.indexOf(step)) + 1, count: steps.length };
}

export class SignInFlow<Session> {
  private state: SignInState;
  private listeners = new Set<() => void>();
  /** Angaben, zu denen die vorliegende `challengeId` gehört. */
  private challengeFor = '';
  /** Code, der für die vorliegende `challengeId` schon selbst gesendet wurde. */
  private autoSent = '';
  /** Sperrt doppelte Aufrufe sofort, nicht erst nach dem nächsten Zeichnen. */
  private running = false;

  constructor(private deps: SignInDeps<Session>) {
    this.state = {
      step: 'email',
      mode: 'register',
      email: '',
      name: '',
      phone: '',
      kind: deps.defaultKind,
      privacy: false,
      code: '',
      challengeId: '',
      busy: false,
      error: '',
      message: '',
      retryAt: 0,
    };
  }

  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  getState = () => this.state;

  private set(patch: Partial<SignInState>) {
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((listener) => listener());
  }
  private now() {
    return (this.deps.now ?? Date.now)();
  }
  private signature() {
    const { mode, email, name, phone, kind, privacy } = this.state;
    return JSON.stringify([mode, email, name, phone, kind, privacy]);
  }

  wait(now = this.now()) {
    return waitSeconds(this.state.retryAt, now);
  }
  /** Für die jetzigen Angaben liegt schon ein Code-Bezug vor. */
  hasCurrentChallenge() {
    return !!this.state.challengeId && this.challengeFor === this.signature();
  }

  setMode(mode: SignInMode) {
    if (this.state.busy) return;
    this.set({ mode, error: '' });
  }
  setEmail(email: string) {
    this.set({ email, error: '' });
  }
  setName(name: string) {
    this.set({ name, error: '' });
  }
  setPhone(phone: string) {
    this.set({ phone, error: '' });
  }
  setKind(kind: string) {
    if (this.state.busy) return;
    this.set({ kind });
  }
  togglePrivacy() {
    this.set({ privacy: !this.state.privacy });
  }

  /** Eine Seite zurück; alle Eingaben und ein vorliegender Code-Bezug bleiben. */
  back() {
    if (this.state.busy) return;
    const { step, mode } = this.state;
    if (step === 'code')
      this.set({ step: mode === 'register' ? 'details' : 'email', error: '' });
    else if (step === 'details') this.set({ step: 'email', error: '' });
  }

  /** Hauptknopf der Seiten „E-Mail“ und „Angaben“. */
  async next() {
    if (this.running) return;
    const { step, mode } = this.state;
    if (step === 'code') return this.verify();
    const invalidEmail = emailError(this.state.email);
    if (invalidEmail) return this.set({ error: invalidEmail });
    if (step === 'email' && mode === 'register')
      return this.set({ step: 'details', error: '', message: '' });
    if (mode === 'register') {
      const invalid = detailsError(this.state);
      if (invalid) return this.set({ error: invalid });
    }
    // Unveränderte Angaben: der schon angeforderte Code gilt weiter.
    if (this.hasCurrentChallenge()) return this.set({ step: 'code', error: '' });
    await this.requestCode();
  }

  /** „Neuen Code anfordern“ auf der Code-Seite. */
  async resend() {
    await this.requestCode();
  }

  private async requestCode() {
    if (this.running || this.wait() > 0) return;
    this.running = true;
    this.set({ busy: true, error: '', message: '' });
    const { mode, email, name, phone, kind, privacy } = this.state;
    const signature = this.signature();
    try {
      const r = await this.deps.requestCode({
        action: 'code',
        mode,
        email,
        name,
        phone,
        kind,
        privacy,
      });
      this.challengeFor = signature;
      this.autoSent = '';
      this.set({
        challengeId: r.challengeId,
        code: '',
        retryAt: this.now() + codeRetryMs,
        message: signInTexts.sent,
        step: 'code',
      });
    } catch (e) {
      if (this.deps.isTimeout(e)) {
        // Ausgang unbekannt: der Server kann einen Code verschickt haben,
        // dessen Bezug dieses Gerät nie erreicht hat, und sperrt dann eine
        // Minute lang. Ein früherer Bezug bleibt für die Eingabe bestehen.
        this.set({
          retryAt: this.now() + codeRetryMs,
          error: signInTexts.unclear,
        });
      } else {
        const status = (e as { status?: number }).status;
        this.set({
          ...(status === 429 ? { retryAt: this.now() + codeRetryMs } : {}),
          error: (e as Error).message,
        });
      }
    } finally {
      this.running = false;
      this.set({ busy: false });
    }
  }

  /** Eingabe im Code-Feld; sechs Ziffern werden genau einmal selbst gesendet. */
  setCode(value: string) {
    const code = value.replace(/\D/g, '').slice(0, 6);
    if (code === this.state.code && code.length === 6) return;
    this.set({ code, error: '' });
    if (code.length < 6) {
      this.autoSent = '';
      return;
    }
    const key = this.state.challengeId + ':' + code;
    if (!this.state.challengeId || this.running || this.autoSent === key)
      return;
    this.autoSent = key;
    void this.verify();
  }

  /** „Code bestätigen“ (auch von Hand, etwa nach einem Verbindungsfehler). */
  async verify() {
    if (this.running || !this.state.challengeId) return;
    const { challengeId, code } = this.state;
    if (!/^\d{6}$/.test(code)) return this.set({ error: signInTexts.code });
    this.running = true;
    this.set({ busy: true, error: '', message: '' });
    try {
      await this.deps.onSignedIn(await this.deps.verify(challengeId, code));
    } catch (e) {
      this.set({ error: (e as Error).message });
    } finally {
      this.running = false;
      this.set({ busy: false });
    }
  }

  /** Konto gewechselt (angemeldet, abgemeldet, gelöscht): Ablauf von vorn. */
  reset() {
    this.challengeFor = '';
    this.autoSent = '';
    this.set({
      step: 'email',
      name: '',
      phone: '',
      code: '',
      challengeId: '',
      error: '',
      message: '',
    });
  }
}
