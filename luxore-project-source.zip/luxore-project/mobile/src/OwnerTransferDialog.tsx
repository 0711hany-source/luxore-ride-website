import React, { useState } from 'react';
import {
  ActivityIndicator,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ShieldCheck, Users, X } from 'lucide-react-native';
import SwipeAction from './SwipeAction';
import {
  ownerCandidates,
  type OwnerChange,
  type OperationsController,
  type OperationsState,
} from './operations';
export default function OwnerTransferDialog({
  fleetId,
  controller,
  state,
  active,
  now,
  onClose,
}: {
  fleetId: string;
  controller: OperationsController;
  state: OperationsState;
  active: boolean;
  now: number;
  onClose: () => void;
}) {
  const [choice, setChoice] = useState<OwnerChange | null>(null);
  const data = state.data,
    fleet = data?.fleets.find((f) => f.id === fleetId);
  const pending =
    state.ownerUncertain?.fleetId === fleetId ? state.ownerUncertain : null;
  const intended = pending || choice;
  if (data?.canManage !== true && !pending) return null;
  const candidates = data && fleet ? ownerCandidates(data, fleetId) : [];
  const locked =
    !!state.changing ||
    !!state.deputyChanging ||
    !!state.memberChanging ||
    !!state.ownerChanging ||
    !!state.uncertain ||
    !!state.deputyUncertain ||
    !!state.memberUncertain ||
    !!state.ownerUncertain;
  const name = (id: string | null) =>
    data?.employees?.find((e) => e.user_id === id)?.name ||
    (id === data?.userId ? 'Eigenes Profil' : 'Zugeordnetes Profil');
  return (
    <Modal
      visible={active}
      animationType="slide"
      presentationStyle="fullScreen"
      onRequestClose={onClose}
    >
      <SafeAreaView style={s.root} edges={['top', 'bottom']}>
        <View style={s.header}>
          <Text style={s.heading}>Besitzerübergabe</Text>
          <Pressable
            accessibilityLabel="Besitzerübergabe schließen"
            hitSlop={12}
            onPress={onClose}
          >
            <X size={24} color={ink} />
          </Pressable>
        </View>
        <ScrollView contentContainerStyle={s.content}>
          <ShieldCheck size={38} color={gold} />
          <Text style={s.title}>{fleet?.name || 'Übergabestand prüfen'}</Text>
          {fleet && (
            <>
              <Text style={s.muted}>Aktueller Besitzer</Text>
              <Text style={s.heading}>{name(fleet.owner_id)}</Text>
            </>
          )}
          <Text style={s.muted}>
            Die Besitzerrechte wechseln zur gewählten Person. Mitarbeiter,
            Fahrzeuge, Bordbestand, Fahrten und Fahrerfreigaben bleiben
            erhalten. Wird die Stellvertretung Besitzer, entfällt ihre bisherige
            Stellvertretung.
          </Text>
          <Text style={s.heading}>Neuer Besitzer</Text>
          <Text style={s.muted}>
            Nur freigegebene Fahrer dieser Flotte. Beide Fahrer müssen offline,
            ohne GPS-Sitzung und vollständig abgerechnet sein. Der Server prüft
            den bisherigen Besitzer und alle Einsatzsperren erneut.
          </Text>
          {pending ? (
            <View style={s.card}>
              <Users size={23} color={gold} />
              <Text style={s.name}>{name(pending.ownerId)}</Text>
            </View>
          ) : (
            candidates.map((e) => (
              <Pressable
                key={e.user_id}
                accessibilityRole="radio"
                accessibilityLabel={`Besitzer ${e.name || 'Ohne Namen'} auswählen`}
                accessibilityState={{
                  checked: e.user_id === choice?.ownerId,
                  disabled: locked,
                }}
                disabled={locked}
                onPress={() =>
                  setChoice({
                    action: 'transfer_owner',
                    fleetId,
                    previousOwnerId: fleet!.owner_id!,
                    ownerId: e.user_id,
                    confirmed: true,
                  })
                }
                style={[s.card, e.user_id === choice?.ownerId && s.selected]}
              >
                <Users size={23} color={gold} />
                <View style={s.grow}>
                  <Text style={s.name}>{e.name || 'Ohne Namen'}</Text>
                  <Text style={s.muted}>Freigegebener Fahrer · offline</Text>
                </View>
              </Pressable>
            ))
          )}
          {!pending && !candidates.length && (
            <Text style={s.muted}>
              Aktuell ist keine passende Zielperson verfügbar. Bestehende
              Einsätze und Freigaben zuerst in der Flotte prüfen.
            </Text>
          )}
          {!!intended && (
            <Text style={s.muted}>
              Bestätigte Auswahl: {name(intended.previousOwnerId)} →{' '}
              {name(intended.ownerId)}. Der bisherige Besitzer muss bis zur
              Bestätigung unverändert sein.
            </Text>
          )}
          {!!pending && (
            <Text style={s.warning}>
              {!state.ownerChecked
                ? 'Die Antwort fehlt. Zuerst den aktuellen Serverstand laden. Es wird keine Übergabe automatisch wiederholt.'
                : fleet?.owner_id === pending.previousOwnerId
                  ? 'Der geladene Stand zeigt den bisherigen Besitzer. Nur dieselbe Auswahl erneut bestätigen oder die Prüfung beenden. Eine verspätete Änderung kann noch eintreffen.'
                  : 'Der Besitzer oder die Flotte hat sich inzwischen geändert. Diese Übergabe ist gesperrt. Aktuellen Stand prüfen und diese Prüfung beenden.'}
            </Text>
          )}
          {!!state.loadError && (
            <Text accessibilityRole="alert" style={s.warning}>
              {state.loadError}
            </Text>
          )}
          {!!state.actionError && (
            <Text accessibilityRole="alert" style={s.warning}>
              {state.actionError}
            </Text>
          )}
          {!!state.notice && (
            <Text accessibilityRole="alert" style={s.notice}>
              {state.notice}
            </Text>
          )}
        </ScrollView>
        <View style={s.footer}>
          <Pressable
            accessibilityLabel="Übergabestand laden"
            disabled={!!state.ownerChanging || state.refreshing}
            onPress={() => void controller.refresh()}
          >
            {state.refreshing ? (
              <ActivityIndicator color={gold} />
            ) : (
              <Text style={s.refresh}>Aktuellen Serverstand laden</Text>
            )}
          </Pressable>
          {!!pending && (
            <SwipeAction
              label="Geprüfte Anfrage beenden"
              disabled={!controller.canEndOwnerReview(now)}
              onComplete={() => controller.endOwnerReview()}
            />
          )}
          <SwipeAction
            key={JSON.stringify(intended) + !!state.ownerChanging}
            label={pending ? 'Gleiche Übergabe bestätigen' : 'Besitz übergeben'}
            disabled={!intended || !controller.canTransferOwner(intended, now)}
            busy={!!state.ownerChanging}
            onComplete={() => {
              if (intended) void controller.transferOwner(intended);
            }}
          />
        </View>
      </SafeAreaView>
    </Modal>
  );
}
const ink = '#161a20',
  gold = '#aa8345';
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  header: {
    padding: 22,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  heading: { fontSize: 18, fontWeight: '600', color: ink },
  content: { padding: 22, gap: 16, paddingBottom: 32 },
  title: { fontSize: 30, fontWeight: '700', color: ink },
  muted: { fontSize: 13, lineHeight: 20, color: '#737a84' },
  card: {
    padding: 18,
    borderRadius: 24,
    backgroundColor: '#faf8f3',
    flexDirection: 'row',
    gap: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  selected: { borderColor: gold },
  name: { fontSize: 16, fontWeight: '600', color: ink, flexShrink: 1 },
  grow: { flex: 1, minWidth: 0 },
  footer: { padding: 22, gap: 14, backgroundColor: '#fff' },
  refresh: { fontSize: 14, fontWeight: '600', color: gold },
  warning: { fontSize: 13, lineHeight: 20, color: '#8b3a30' },
  notice: { fontSize: 13, lineHeight: 20, color: '#356c4d' },
});
