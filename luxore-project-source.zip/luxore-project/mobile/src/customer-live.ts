import {
  activeStatuses,
  coordinate,
  type Booking,
  type Service,
} from '../../lib/mobility/domain.ts';

export type CustomerCoordinate = { lat: number; lng: number };
export type CustomerLiveState = {
  booking: Booking | null;
  nearby: CustomerCoordinate[];
  active: boolean;
  loaded: boolean;
  refreshing: boolean;
  updatedAt: number | null;
  serverTime: number | null;
  nearbyAt: number | null;
  error: string;
  nearbyError: string;
};
const emptyState = (): CustomerLiveState => ({
  booking: null,
  nearby: [],
  active: false,
  loaded: false,
  refreshing: false,
  updatedAt: null,
  serverTime: null,
  nearbyAt: null,
  error: '',
  nearbyError: '',
});
const assigned = (booking: Booking) =>
  ['accepted', 'arrived', 'riding'].includes(booking.status);
const denied = (error: unknown) =>
  !!error &&
  typeof error === 'object' &&
  'status' in error &&
  (error.status === 401 || error.status === 403);

/** Pure display policy: no identity/exact GPS from the anonymous nearby response. */
export function customerMapSnapshot(state: CustomerLiveState, now: number) {
  const booking = state.booking;
  const connected =
    state.active &&
    !state.error &&
    state.updatedAt !== null &&
    now >= state.updatedAt &&
    now - state.updatedAt <= 20000;
  const driver = booking?.driver;
  // GPS timestamps come from the server's clock. A wrong phone clock must not
  // make an otherwise fresh assigned driver look hours old or in the future.
  const referenceNow =
    state.serverTime !== null && state.updatedAt !== null
      ? state.serverTime + now - state.updatedAt
      : now;
  const freshDriver =
    connected &&
    booking &&
    assigned(booking) &&
    driver &&
    driver.id === booking.driver_id &&
    coordinate(driver.lat, driver.lng) &&
    typeof driver.accuracy === 'number' &&
    Number.isFinite(driver.accuracy) &&
    driver.accuracy >= 0 &&
    driver.accuracy <= 100 &&
    typeof driver.location_at === 'number' &&
    Number.isFinite(driver.location_at) &&
    driver.location_at <= referenceNow + 5000 &&
    referenceNow - driver.location_at <= 45000;
  return {
    booking,
    connected,
    driverPosition: freshDriver
      ? { lat: driver.lat as number, lng: driver.lng as number }
      : null,
    nearby:
      connected &&
      booking?.status === 'requesting' &&
      !state.nearbyError &&
      state.nearbyAt !== null &&
      now >= state.nearbyAt &&
      now - state.nearbyAt <= 20000
        ? state.nearby
        : [],
    canContactDriver: !!(
      connected &&
      booking &&
      assigned(booking) &&
      driver &&
      driver.id === booking.driver_id
    ),
  };
}

/** Read-only, account-bound state for the future native customer live screen. */
export class CustomerLiveController {
  private state = emptyState();
  private listeners = new Set<() => void>();
  private selectedId: string | null = null;
  private revision = 0;
  private disposed = false;
  private read: Promise<void> | null = null;
  private transport: AbortController | null = null;
  private queued = false;
  constructor(
    private ownerId: string,
    private bookings: (
      signal: AbortSignal,
    ) => Promise<{ bookings: Booking[]; serverTime?: number }>,
    private nearby: (
      body: { bookingId: string; service: Service },
      signal: AbortSignal,
    ) => Promise<{ drivers: CustomerCoordinate[] }>,
    private now: () => number = Date.now,
  ) {}
  getSnapshot = () => this.state;
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  private publish(patch: Partial<CustomerLiveState>) {
    if (this.disposed) return;
    this.state = { ...this.state, ...patch };
    for (const listener of this.listeners) listener();
  }
  private abandon() {
    this.revision++;
    this.transport?.abort();
    this.transport = null;
    this.read = null;
    this.queued = false;
  }
  select(id: string | null) {
    if (this.disposed || id === this.selectedId) return;
    this.selectedId = id;
    this.abandon();
    this.publish({ ...emptyState(), active: this.state.active });
    if (this.state.active) void this.refresh();
  }
  setActive(active: boolean) {
    if (this.disposed || this.state.active === active) return;
    this.abandon();
    this.publish({ active, refreshing: false, nearby: [], nearbyAt: null });
    if (active) void this.refresh();
  }
  refresh(): Promise<void> {
    if (this.disposed || !this.state.active) return Promise.resolve();
    if (this.read) {
      this.queued = true;
      return this.read;
    }
    const revision = this.revision;
    const controller = new AbortController();
    this.transport = controller;
    this.queued = false;
    const current = () =>
      !this.disposed && this.state.active && revision === this.revision;
    this.publish({ refreshing: true });
    const task = Promise.resolve().then(async () => {
      try {
        if (controller.signal.aborted) return;
        const response = await this.bookings(controller.signal);
        if (!current()) return;
        if (!Array.isArray(response.bookings))
          throw new Error('Ungültiger Fahrtstand.');
        if (
          response.serverTime !== undefined &&
          (!Number.isFinite(response.serverTime) || response.serverTime < 0)
        )
          throw new Error('Ungültige Serverzeit.');
        const own = response.bookings.filter(
          (b) => b.owner_id === this.ownerId,
        );
        let booking = this.selectedId
          ? own.find((b) => b.id === this.selectedId) || null
          : own
              .filter((b) => activeStatuses.includes(b.status))
              .sort(
                (a, b) =>
                  b.created_at - a.created_at || a.id.localeCompare(b.id),
              )[0] || null;
        const previous = this.state.booking;
        if (booking && previous?.id === booking.id) {
          if (booking.updated_at < previous.updated_at)
            throw new Error(
              'Ein veralteter Fahrtstand wurde empfangen. Erneut laden.',
            );
          // An older telemetry fix must never move a matched driver's marker back.
          if (
            assigned(booking) &&
            booking.driver?.id === previous.driver?.id &&
            typeof booking.driver?.location_at === 'number' &&
            typeof previous.driver?.location_at === 'number' &&
            booking.driver.location_at < previous.driver.location_at
          ) {
            booking = {
              ...booking,
              driver: {
                ...booking.driver,
                lat: previous.driver.lat,
                lng: previous.driver.lng,
                accuracy: previous.driver.accuracy,
                location_at: previous.driver.location_at,
              },
            };
          }
        }
        // Publish the authoritative status before waiting for optional nearby cars.
        this.publish({
          booking,
          loaded: true,
          updatedAt: this.now(),
          serverTime: response.serverTime ?? null,
          error: '',
          nearby: [],
          nearbyAt: null,
          nearbyError: '',
        });
        if (!booking || booking.status !== 'requesting') return;
        try {
          const result = await this.nearby(
            { bookingId: booking.id, service: booking.service },
            controller.signal,
          );
          if (!current()) return;
          if (!Array.isArray(result.drivers))
            throw new Error('Fahrzeuge konnten nicht geladen werden.');
          const drivers = result.drivers
            .filter((p) => coordinate(p.lat, p.lng))
            .slice(0, 3)
            .map((p) => ({ lat: p.lat, lng: p.lng }));
          this.publish({
            nearby: drivers,
            nearbyAt: this.now(),
            nearbyError: '',
          });
        } catch (error) {
          if (current()) {
            if (denied(error))
              this.publish({
                ...emptyState(),
                active: true,
                loaded: true,
                error: 'Bitte erneut anmelden.',
              });
            else
              this.publish({
                nearby: [],
                nearbyAt: null,
                nearbyError:
                  error instanceof Error
                    ? error.message
                    : 'Fahrzeuge konnten nicht geladen werden.',
              });
          }
        }
      } catch (error) {
        if (!current()) return;
        if (denied(error))
          this.publish({
            ...emptyState(),
            active: true,
            loaded: true,
            error: 'Bitte erneut anmelden.',
          });
        else
          this.publish({
            loaded: true,
            error:
              error instanceof Error
                ? error.message
                : 'Fahrtstand konnte nicht geladen werden.',
            nearby: [],
            nearbyAt: null,
          });
      } finally {
        if (this.read === task) {
          this.read = null;
          this.transport = null;
          if (current()) this.publish({ refreshing: false });
          if (current() && this.queued) {
            this.queued = false;
            void this.refresh();
          }
        }
      }
    });
    this.read = task;
    return task;
  }
  dispose() {
    this.abandon();
    this.publish(emptyState());
    this.disposed = true;
    this.listeners.clear();
  }
}
