import React, { useState } from 'react';
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Users, X } from 'lucide-react-native';
import SwipeAction from './SwipeAction';
import type {
  MembershipChange,
  OperationsController,
  OperationsState,
  TeamMember,
} from './operations';

export default function TeamMembershipDialog({
  fleetId,
  controller,
  state,
  active,
  now,
  onClose,
}: {
  fleetId: string;
  controller: OperationsController;
  state: OperationsState;
  active: boolean;
  now: number;
  onClose: () => void;
}) {
  const [choice, setChoice] = useState<MembershipChange | null>(null);
  const data = state.data;
  const fleet = data?.fleets.find((f) => f.id === fleetId);
  const pending =
    state.memberUncertain?.fleetId === fleetId ? state.memberUncertain : null;
  const intended = pending || choice;
  const employee = data?.employees?.find((e) => e.user_id === intended?.userId);
  const allowed =
    !!fleet &&
    !!data?.userId &&
    (data.canManage === true ||
      fleet.owner_id === data.userId ||
      fleet.deputy_id === data.userId);
  const locked =
    !!state.changing ||
    !!state.deputyChanging ||
    !!state.memberChanging ||
    !!state.uncertain ||
    !!state.deputyUncertain ||
    !!state.memberUncertain;
  if (!allowed || !fleet || !data) return null;
  const members = data.employees?.filter((e) => e.fleet_id === fleetId) || [];
  const candidates =
    data.canManage === true
      ? (data.employees || []).filter((e) => e.fleet_id !== fleetId)
      : [];
  function row(e: TeamMember) {
    const leader = data!.fleets.some(
      (f) => f.owner_id === e.user_id || f.deputy_id === e.user_id,
    );
    const current = e.fleet_id === fleetId;
    const selectable =
      !leader && (current || e.role === 'staff' || e.role === 'driver');
    return (
      <Pressable
        key={e.user_id}
        accessibilityRole="radio"
        accessibilityLabel={`Mitarbeiter ${e.name || 'Ohne Namen'} auswählen`}
        accessibilityState={{
          checked: e.user_id === intended?.userId,
          disabled: locked || !selectable,
        }}
        disabled={locked || !selectable}
        onPress={() =>
          setChoice(
            current
              ? { action: 'remove_member', userId: e.user_id, fleetId }
              : {
                  action: 'assign',
                  userId: e.user_id,
                  fleetId,
                  role: e.role as 'staff' | 'driver',
                },
          )
        }
        style={[s.person, e.user_id === intended?.userId && s.selected]}
      >
        <Users color={gold} size={22} />
        <View style={s.grow}>
          <Text style={s.name}>{e.name || 'Ohne Namen'}</Text>
          <Text style={s.muted}>
            {data!.fleets.find((f) => f.id === e.fleet_id)?.name ||
              'Ohne Flotte'}{' '}
            ·{' '}
            {leader
              ? 'Flottenleitung'
              : e.role === 'driver'
                ? 'Fahrer'
                : 'Mitarbeiter'}
          </Text>
          {e.can_remove === 0 && (
            <Text style={s.error}>Noch im Einsatz oder Zahlung offen</Text>
          )}
        </View>
      </Pressable>
    );
  }
  return (
    <Modal
      visible={active}
      animationType="slide"
      presentationStyle="fullScreen"
      onRequestClose={onClose}
    >
      <SafeAreaView style={s.root} edges={['top', 'bottom']}>
        <View style={s.header}>
          <Text style={s.heading}>Team verwalten</Text>
          <Pressable
            accessibilityLabel="Teamverwaltung schließen"
            onPress={onClose}
            hitSlop={12}
          >
            <X color={ink} size={24} />
          </Pressable>
        </View>
        <ScrollView contentContainerStyle={s.content}>
          <Users color={gold} size={38} />
          <Text style={s.title}>{fleet.name}</Text>
          <Text style={s.muted}>
            Wähle die Person für diese Flotte. Besitzer und Stellvertretung
            bleiben geschützt.
          </Text>
          <Text style={s.heading}>In dieser Flotte</Text>
          {members.map(row)}
          {!members.length && (
            <Text style={s.muted}>Noch keine Mitarbeiter zugeordnet.</Text>
          )}
          {data.canManage === true && (
            <>
              <Text style={s.heading}>Für diese Flotte auswählen</Text>
              <Text style={s.muted}>
                Bestehende Profile ohne Flotte oder aus anderen Flotten. Die
                bisherige Rolle bleibt erhalten.
              </Text>
              {candidates.map(row)}
              {!candidates.length && (
                <Text style={s.muted}>Keine weiteren Profile vorhanden.</Text>
              )}
            </>
          )}
          {intended && (
            <View style={s.detail}>
              <Text style={s.name}>
                {employee?.name || 'Gewählter Mitarbeiter'}
              </Text>
              <Text style={s.muted}>
                {intended.action === 'assign'
                  ? `Zuordnung zu ${fleet.name}. Eine bisherige Flottenzuordnung wird ersetzt.`
                  : `Aus ${fleet.name} entfernen. Das Profil bleibt erhalten.`}
              </Text>
              <Text style={s.muted}>
                Die Fahrzeugauswahl und Fahrerfreigabe dieser Person werden
                zurückgesetzt. Fahrzeuge, Bordbestand und Fahrtgeschichte
                bleiben in ihrer bisherigen Flotte. Erst nach Schichtende,
                Fahrtabschluss und Zahlung möglich.
              </Text>
            </View>
          )}
          {!!pending && (
            <Text style={s.error}>
              Die Antwort fehlt. Serverstand neu laden oder ausschließlich
              dieselbe Änderung erneut bestätigen. Andere Änderungen bleiben bis
              zur Klärung gesperrt.
            </Text>
          )}
          {!!state.loadError && (
            <Text accessibilityRole="alert" style={s.error}>
              {state.loadError}
            </Text>
          )}
          {!!state.actionError && (
            <Text accessibilityRole="alert" style={s.error}>
              {state.actionError}
            </Text>
          )}
          {!!state.notice && (
            <Text accessibilityRole="alert" style={s.notice}>
              {state.notice}
            </Text>
          )}
        </ScrollView>
        <View style={s.footer}>
          <Pressable
            accessibilityLabel="Teamstand aktualisieren"
            disabled={
              !!state.memberChanging ||
              !!state.changing ||
              !!state.deputyChanging ||
              state.refreshing
            }
            onPress={() => void controller.refresh()}
          >
            <Text style={s.refresh}>
              {state.refreshing
                ? 'Team wird aktualisiert …'
                : 'Aktuellen Teamstand laden'}
            </Text>
          </Pressable>
          <SwipeAction
            key={JSON.stringify(intended) + !!state.memberChanging}
            label={
              pending
                ? 'Gleiche Änderung erneut bestätigen'
                : intended?.action === 'assign'
                  ? 'Mitarbeiter zuordnen'
                  : 'Aus Flotte entfernen'
            }
            disabled={!intended || !controller.canChangeMember(intended, now)}
            busy={!!state.memberChanging}
            onComplete={() => {
              if (intended) void controller.changeMember(intended);
            }}
          />
        </View>
      </SafeAreaView>
    </Modal>
  );
}
const ink = '#161a20',
  gold = '#aa8345';
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  header: {
    paddingHorizontal: 22,
    paddingVertical: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  content: { padding: 22, gap: 16, paddingBottom: 30 },
  title: { color: ink, fontSize: 32, fontWeight: '700' },
  heading: { color: ink, fontSize: 19, fontWeight: '600' },
  muted: { color: '#777e87', fontSize: 13, lineHeight: 20 },
  name: { color: ink, fontSize: 15, fontWeight: '600', lineHeight: 22 },
  person: {
    flexDirection: 'row',
    gap: 14,
    alignItems: 'center',
    padding: 17,
    borderRadius: 21,
    backgroundColor: '#fbf8f2',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  selected: { borderColor: gold },
  grow: { flex: 1, minWidth: 0 },
  detail: {
    backgroundColor: '#f8f5ef',
    padding: 18,
    gap: 10,
    borderRadius: 20,
  },
  error: { color: '#a04c40', fontSize: 13, lineHeight: 21 },
  notice: { color: '#347961', fontSize: 13, lineHeight: 21 },
  footer: { padding: 22, gap: 14, backgroundColor: '#fff' },
  refresh: { color: gold, fontSize: 13, fontWeight: '600' },
});
