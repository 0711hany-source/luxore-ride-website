import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { nativeApi } from './account-client';
import {
  isOwnCompliance,
  loadFeature,
  readiness,
  refusalTitle,
  type OwnCompliance,
} from './operator-platform';
import { colors, layout, maxFontScale, radii, space, typography } from './theme';

/**
 * „Vor der Schicht“ im Fahrerbereich: Sperren, fehlende Papiere und fällige
 * Wochenkontrolle auf einen Blick. Liest nur; kennt der Server die Route noch
 * nicht oder schlägt das Lesen fehl, bleibt der Block unsichtbar – die Schicht
 * hängt nie davon ab.
 */
export default function ShiftReadiness({
  token,
  active,
  refreshKey,
  onOpen,
}: {
  token: string;
  active: boolean;
  /** Ändert sich nach Fahrzeugwechsel oder einer Ablehnung: neu lesen. */
  refreshKey: string;
  onOpen: () => void;
}) {
  const [data, setData] = useState<OwnCompliance | null>(null);
  useEffect(() => {
    if (!active) return;
    let alive = true;
    const controller = new AbortController();
    void loadFeature(
      () =>
        nativeApi('compliance', token, undefined, undefined, controller.signal),
      isOwnCompliance,
    )
      .then((next) => {
        if (alive) setData(next.kind === 'ready' ? next.data : null);
      })
      .catch(() => {});
    return () => {
      alive = false;
      controller.abort();
    };
  }, [token, active, refreshKey]);
  if (!data) return null;
  const r = readiness(data);
  if (!r.registered) return null;
  const stop = !!r.stops.length;
  const items = stop ? r.stops : r.hints;
  return (
    <View
      style={[
        s.box,
        stop ? s.danger : items.length ? s.warn : s.good,
      ]}
    >
      <Text
        accessibilityRole={stop ? 'alert' : undefined}
        style={[
          s.title,
          { color: stop ? colors.danger : items.length ? colors.goldText : colors.success },
        ]}
        maxFontSizeMultiplier={maxFontScale}
      >
        {stop
          ? `${refusalTitle}:`
          : items.length
            ? `Vor der Schicht · ${r.hintTitle.toLowerCase()}:`
            : 'Vor der Schicht · Papiere und Wochenkontrolle sind in Ordnung.'}
      </Text>
      {items.map((item) => (
        <View key={item} style={s.line}>
          <Text style={s.text}>•</Text>
          <Text style={[s.text, s.flex]} maxFontSizeMultiplier={maxFontScale}>
            {item}
          </Text>
        </View>
      ))}
      <Pressable
        style={s.action}
        accessibilityRole="button"
        accessibilityLabel="Zum Prüf-Bereich"
        onPress={onOpen}
      >
        <Text style={s.link} maxFontSizeMultiplier={maxFontScale}>
          Zum Prüf-Bereich
        </Text>
      </Pressable>
    </View>
  );
}
const s = StyleSheet.create({
  box: { borderRadius: radii.m, padding: space[4], gap: space[1] },
  danger: { backgroundColor: colors.dangerWash },
  warn: { backgroundColor: colors.goldWash },
  good: { backgroundColor: colors.successWash },
  title: { ...typography.subhead, fontWeight: '600' },
  line: { flexDirection: 'row', gap: space[2] },
  flex: { flex: 1 },
  text: { ...typography.subhead, color: colors.ink },
  action: { minHeight: layout.tap, justifyContent: 'center' },
  link: {
    ...typography.subhead,
    fontWeight: '600',
    color: colors.ink,
    textDecorationLine: 'underline',
  },
});
