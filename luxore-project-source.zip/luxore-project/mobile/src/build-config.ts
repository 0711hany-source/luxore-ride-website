import Constants from 'expo-constants';
import { Platform } from 'react-native';

// Native variants come from the signed APK manifest, independent of Metro's
// cached public environment substitutions from a preceding variant build.
export const driverVariant =
  Platform.OS === 'web'
    ? process.env.EXPO_PUBLIC_APP_VARIANT === 'driver'
    : Constants.expoConfig?.extra?.variant === 'driver';
export const designPreview =
  Platform.OS === 'web' && process.env.EXPO_PUBLIC_APP_PREVIEW === 'true';
