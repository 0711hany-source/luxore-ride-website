import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Mapbox from '@rnmapbox/maps';
import { LocateFixed } from 'lucide-react-native';
import type { CustomerMapProps } from './CustomerMap';
import { MapStartup } from './map-startup';
import { coordinate } from '../../lib/mobility/domain';
import { projectRoad } from '../../app/mobility/navigation-motion';
import { colors, typography } from './theme';
const startup = new MapStartup(Mapbox);
// Quiet road map made for navigation; the route is drawn in ink, not gold.
export const mapStyle = 'mapbox://styles/mapbox/navigation-day-v1';
const routeColor = '#151719';
// The chauffeur's way to the pickup point: route blue as in the driver app.
const approachColor = '#3b82d6',
  approachBorder = '#1d4f86';
const noLine = { type: 'FeatureCollection' as const, features: [] };
/**
 * The part of the chauffeur's way that still lies ahead of the car. A car
 * that has left the stored way (a newer one follows within seconds) keeps
 * the whole line instead of a wrong cut.
 */
export function approachAhead(
  approach: CustomerMapProps['approach'],
  car: { lng: number; lat: number } | null,
): number[][] | null {
  const line = approach?.coordinates;
  if (
    approach?.type !== 'LineString' ||
    !Array.isArray(line) ||
    line.length < 2 ||
    !line.every((p) => Array.isArray(p) && coordinate(p[1], p[0]))
  )
    return null;
  if (!car) return line;
  const at = projectRoad(car, line);
  if (!at || at.distance > 60) return line;
  const rest = [[at.lng, at.lat], ...line.slice(at.segment + 1)];
  return rest.length > 1 ? rest : null;
}
// (Plain Node test runs have no bundler `require`; the dot remains visible.)
const carImages: Record<string, number> =
  typeof require === 'function'
    ? { 'luxore-car': require('../assets/map-car.png') }
    : {};
type LngLat = { lng: number; lat: number };
type Shown = LngLat & { bearing: number };
const rad = Math.PI / 180;
function distance(a: LngLat, b: LngLat) {
  const x = (b.lng - a.lng) * rad * Math.cos(((a.lat + b.lat) / 2) * rad),
    y = (b.lat - a.lat) * rad;
  return Math.sqrt(x * x + y * y) * 6371000;
}
function heading(a: LngLat, b: LngLat) {
  const y = Math.sin((b.lng - a.lng) * rad) * Math.cos(b.lat * rad),
    x =
      Math.cos(a.lat * rad) * Math.sin(b.lat * rad) -
      Math.sin(a.lat * rad) *
        Math.cos(b.lat * rad) *
        Math.cos((b.lng - a.lng) * rad);
  return (Math.atan2(y, x) / rad + 360) % 360;
}
const stop = (p: LngLat, label: string, kind: string) => ({
  type: 'Feature' as const,
  properties: { label, kind },
  geometry: { type: 'Point' as const, coordinates: [p.lng, p.lat] },
});
export default function NativeCustomerMapView(props: CustomerMapProps) {
  'use no memo';
  const [configured, setConfigured] = useState(''),
    [failed, setFailed] = useState(false),
    [attempt, setAttempt] = useState(0);
  const camera = useRef<React.ComponentRef<typeof Mapbox.Camera>>(null);
  const ready = useRef(false),
    current = useRef(props),
    gestureUntil = useRef(0);
  useEffect(() => {
    current.current = props;
  }, [props]);
  useEffect(() => {
    let alive = true;
    ready.current = false;
    const timeout = setTimeout(() => {
      if (alive && !ready.current) setFailed(true);
    }, 20000);
    void startup
      .prepare(props.token, () => alive)
      .then((ok) => {
        if (alive && ok) setConfigured(props.token);
      })
      .catch(() => {
        if (alive) setFailed(true);
      });
    return () => {
      alive = false;
      clearTimeout(timeout);
    };
  }, [props.token, attempt]);
  // The car glides from the last shown position to the next GPS fix instead
  // of jumping; its heading follows the direction of travel.
  const [car, setCar] = useState<Shown | null>(null);
  const shown = useRef<Shown | null>(null);
  useEffect(() => {
    const target = props.driver;
    if (!target) {
      shown.current = null;
      setCar(null);
      return;
    }
    const from = shown.current;
    if (!from) {
      shown.current = { lng: target.lng, lat: target.lat, bearing: 0 };
      setCar(shown.current);
      return;
    }
    const metres = distance(from, target);
    // Standing still (GPS noise): the parked car stays exactly where it is.
    if (metres < 4) return;
    const bearing = metres > 8 ? heading(from, target) : from.bearing;
    // A jump after a gap is shown at once, not as a flight across the map.
    if (metres > 600) {
      shown.current = { lng: target.lng, lat: target.lat, bearing };
      setCar(shown.current);
      return;
    }
    let step = 0;
    const steps = 10;
    const timer = setInterval(() => {
      step++;
      const t = step / steps;
      shown.current = {
        lng: from.lng + (target.lng - from.lng) * t,
        lat: from.lat + (target.lat - from.lat) * t,
        bearing,
      };
      setCar(shown.current);
      if (step >= steps) clearInterval(timer);
    }, 100);
    return () => clearInterval(timer);
  }, [props.driver]);
  // Way of the chauffeur to the pickup point, cut off behind the car.
  const ahead = useMemo(
    () =>
      props.status === 'accepted' && props.driver
        ? approachAhead(props.approach, car ?? props.driver)
        : null,
    [props.status, props.approach, props.driver, car],
  );
  const framed = useRef<{ key: string; lng: number; lat: number } | null>(null);
  /** What the customer needs to see depends on the stage of the ride. */
  function frame(force = false) {
    if (!ready.current) return;
    const { route, driver, nearby, status, bookingId } = current.current;
    const pickup = [route.pickup.lng, route.pickup.lat],
      destination = [route.destination.lng, route.destination.lat],
      chauffeur = driver ? [[driver.lng, driver.lat]] : [];
    const points = (
      driver && (status === 'accepted' || status === 'arrived')
        ? // The way to the pickup point: chauffeur and pickup, close up.
          [pickup, ...chauffeur]
        : driver && status === 'riding'
          ? [...chauffeur, destination]
          : [
              ...route.geometry.coordinates,
              pickup,
              destination,
              ...nearby.map((p) => [p.lng, p.lat]),
            ]
    ).filter((p) => coordinate(p[1], p[0]));
    if (!points.length) return;
    // Do not move the map for every small GPS update: only when the stage
    // changes or the car has travelled a noticeable distance.
    const key = `${bookingId}:${status}:${driver ? 1 : 0}`;
    const last = framed.current;
    if (
      !force &&
      last &&
      last.key === key &&
      (!driver || distance(last, driver) < 60)
    )
      return;
    framed.current = {
      key,
      lng: driver?.lng ?? pickup[0],
      lat: driver?.lat ?? pickup[1],
    };
    const east = Math.max(...points.map((p) => p[0])),
      north = Math.max(...points.map((p) => p[1])),
      west = Math.min(...points.map((p) => p[0])),
      south = Math.min(...points.map((p) => p[1]));
    // Chauffeur waiting at the pickup point: a fixed street-level view shows
    // where the car is parked instead of zooming in without limit.
    if (distance({ lng: east, lat: north }, { lng: west, lat: south }) < 120) {
      camera.current?.setCamera({
        centerCoordinate: [(east + west) / 2, (north + south) / 2],
        zoomLevel: 16.5,
        animationDuration: 900,
        animationMode: 'easeTo',
      });
      return;
    }
    camera.current?.fitBounds([east, north], [west, south], [90, 60, 140, 60], 900);
  }
  useEffect(() => {
    if (!props.active) return;
    const timer = setInterval(() => {
      if (gestureUntil.current && Date.now() >= gestureUntil.current) {
        gestureUntil.current = 0;
        frame(true);
      }
    }, 250);
    return () => clearInterval(timer);
  }, [props.active]);
  useEffect(() => {
    if (Date.now() >= gestureUntil.current) frame();
  }, [props.bookingId, props.status, props.driver, props.nearby]);
  if (failed || configured !== props.token)
    return (
      <View style={s.wait}>
        {failed ? (
          <>
            <Text style={s.detail}>
              Karte momentan nicht erreichbar. Der Fahrtstatus bleibt verfügbar.
            </Text>
            <Pressable
              accessibilityRole="button"
              onPress={() => {
                setFailed(false);
                setAttempt((v) => v + 1);
              }}
            >
              <Text style={s.retry}>Karte erneut starten</Text>
            </Pressable>
          </>
        ) : (
          <ActivityIndicator color={colors.gold} />
        )}
      </View>
    );
  const riding = props.status === 'riding';
  const approach = ahead
    ? {
        type: 'Feature' as const,
        properties: {},
        geometry: { type: 'LineString' as const, coordinates: ahead },
      }
    : noLine;
  return (
    <View style={s.root}>
      <Mapbox.MapView
        key={attempt}
        style={s.root}
        styleURL={mapStyle}
        surfaceView={false}
        compassEnabled={false}
        scaleBarEnabled={false}
        rotateEnabled={false}
        pitchEnabled={false}
        logoPosition={{ top: 12, left: 10 }}
        attributionPosition={{ top: 12, left: 100 }}
        onDidFinishLoadingMap={() => {
          ready.current = true;
          frame(true);
        }}
        onMapLoadingError={() => {
          ready.current = false;
          setFailed(true);
        }}
        onCameraChanged={(state) => {
          if (state.gestures.isGestureActive)
            gestureUntil.current = Date.now() + 6000;
        }}
      >
        <Mapbox.Camera
          ref={camera}
          defaultSettings={{
            centerCoordinate: [props.route.pickup.lng, props.route.pickup.lat],
            zoomLevel: 14,
          }}
        />
        <Mapbox.Images images={carImages} />
        <Mapbox.ShapeSource
          id="customer-route"
          shape={{
            type: 'Feature',
            properties: {},
            geometry: props.route.geometry,
          }}
        >
          <Mapbox.LineLayer
            id="customer-outline"
            style={{
              lineColor: '#ffffff',
              lineWidth: 8,
              lineCap: 'round',
              lineJoin: 'round',
            }}
          />
          <Mapbox.LineLayer
            id="customer-line"
            style={{
              lineColor: routeColor,
              lineWidth: 4.5,
              lineCap: 'round',
              lineJoin: 'round',
              // Before the ride starts the trip itself is only a preview.
              lineOpacity: riding || !props.driver ? 1 : 0.45,
            }}
          />
        </Mapbox.ShapeSource>
        {/* Always mounted (empty when there is no way): the layer order
            stays route → way of the chauffeur → stops → car, so the line can
            never lie above the vehicle. */}
        <Mapbox.ShapeSource id="customer-approach" shape={approach}>
          <Mapbox.LineLayer
            id="customer-approach-border"
            style={{
              lineColor: approachBorder,
              lineWidth: 8.5,
              lineCap: 'round',
              lineJoin: 'round',
            }}
          />
          <Mapbox.LineLayer
            id="customer-approach-line"
            style={{
              lineColor: approachColor,
              lineWidth: 5.5,
              lineCap: 'round',
              lineJoin: 'round',
            }}
          />
        </Mapbox.ShapeSource>
        <Mapbox.ShapeSource
          id="customer-stops"
          shape={{
            type: 'FeatureCollection',
            features: [
              stop(props.route.pickup, 'Abholung', 'pickup'),
              stop(props.route.destination, 'Ziel', 'destination'),
            ],
          }}
        >
          <Mapbox.CircleLayer
            id="customer-stop-dot"
            style={{
              circleRadius: 7,
              circleColor: [
                'match',
                ['get', 'kind'],
                'pickup',
                '#ffffff',
                routeColor,
              ],
              circleStrokeColor: [
                'match',
                ['get', 'kind'],
                'pickup',
                routeColor,
                '#ffffff',
              ],
              circleStrokeWidth: 3.5,
            }}
          />
          <Mapbox.SymbolLayer
            id="customer-stop-label"
            style={{
              textField: ['get', 'label'],
              textSize: 13,
              textColor: routeColor,
              textHaloColor: '#ffffff',
              textHaloWidth: 2,
              textOffset: [0, 1.3],
              textAnchor: 'top',
              textAllowOverlap: true,
              textIgnorePlacement: true,
            }}
          />
        </Mapbox.ShapeSource>
        {props.nearby.length > 0 && !props.driver && (
          <Mapbox.ShapeSource
            id="customer-nearby"
            shape={{
              type: 'FeatureCollection',
              features: props.nearby.map((p) => ({
                type: 'Feature',
                properties: {},
                geometry: { type: 'Point', coordinates: [p.lng, p.lat] },
              })),
            }}
          >
            {/* Approximate positions: quiet dots, no vehicles. */}
            <Mapbox.CircleLayer
              id="customer-nearby-dot"
              style={{
                circleRadius: 5,
                circleColor: routeColor,
                circleOpacity: 0.55,
                circleStrokeColor: '#ffffff',
                circleStrokeWidth: 2,
              }}
            />
          </Mapbox.ShapeSource>
        )}
        {car && (
          <Mapbox.ShapeSource
            id="customer-car"
            shape={{
              type: 'Feature',
              properties: { bearing: car.bearing },
              geometry: { type: 'Point', coordinates: [car.lng, car.lat] },
            }}
          >
            {/* Stays visible even if the vehicle image could not be loaded. */}
            <Mapbox.CircleLayer
              id="customer-car-dot"
              style={{
                circleRadius: 8,
                circleColor: routeColor,
                circleStrokeColor: '#ffffff',
                circleStrokeWidth: 3,
              }}
            />
            <Mapbox.SymbolLayer
              id="customer-car-icon"
              style={{
                iconImage: 'luxore-car',
                iconSize: 0.3,
                iconRotate: ['get', 'bearing'],
                iconRotationAlignment: 'map',
                iconAllowOverlap: true,
                iconIgnorePlacement: true,
              }}
            />
          </Mapbox.ShapeSource>
        )}
      </Mapbox.MapView>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Karte wieder auf die Fahrt ausrichten"
        style={s.locate}
        onPress={() => {
          gestureUntil.current = 0;
          frame(true);
        }}
      >
        <LocateFixed color={colors.ink} size={24} />
      </Pressable>
    </View>
  );
}
const s = StyleSheet.create({
  root: { flex: 1 },
  wait: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
    backgroundColor: colors.paper,
  },
  detail: { ...typography.footnote, color: colors.textMuted, textAlign: 'center' },
  retry: { ...typography.footnote, fontWeight: '600', color: colors.gold, padding: 20 },
  locate: {
    position: 'absolute',
    right: 16,
    bottom: 22,
    padding: 16,
    borderRadius: 30,
    backgroundColor: colors.white,
    elevation: 3,
  },
});
