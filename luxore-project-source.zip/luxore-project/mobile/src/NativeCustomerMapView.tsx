import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Mapbox from '@rnmapbox/maps';
import { CarFront, LocateFixed } from 'lucide-react-native';
import type { CustomerMapProps } from './CustomerMap';
import { MapStartup } from './map-startup';
import { coordinate } from '../../lib/mobility/domain';
const startup = new MapStartup(Mapbox);
export default function NativeCustomerMapView(props: CustomerMapProps) {
  'use no memo';
  const [configured, setConfigured] = useState(''),
    [failed, setFailed] = useState(false),
    [attempt, setAttempt] = useState(0);
  const camera = useRef<React.ComponentRef<typeof Mapbox.Camera>>(null);
  const ready = useRef(false),
    current = useRef(props),
    gestureUntil = useRef(0);
  useEffect(() => {
    current.current = props;
  }, [props]);
  useEffect(() => {
    let alive = true;
    ready.current = false;
    const timeout = setTimeout(() => {
      if (alive && !ready.current) setFailed(true);
    }, 20000);
    void startup
      .prepare(props.token, () => alive)
      .then((ok) => {
        if (alive && ok) setConfigured(props.token);
      })
      .catch(() => {
        if (alive) setFailed(true);
      });
    return () => {
      alive = false;
      clearTimeout(timeout);
    };
  }, [props.token, attempt]);
  function frame() {
    if (!ready.current) return;
    const { route, driver, nearby } = current.current;
    const points = [
      ...route.geometry.coordinates,
      [route.pickup.lng, route.pickup.lat],
      [route.destination.lng, route.destination.lat],
      ...[...(driver ? [driver] : []), ...nearby].map((p) => [p.lng, p.lat]),
    ].filter((p) => coordinate(p[1], p[0]));
    if (!points.length) return;
    camera.current?.fitBounds(
      [
        Math.max(...points.map((p) => p[0])),
        Math.max(...points.map((p) => p[1])),
      ],
      [
        Math.min(...points.map((p) => p[0])),
        Math.min(...points.map((p) => p[1])),
      ],
      [60, 45, 120, 45],
      600,
    );
  }
  useEffect(() => {
    if (!props.active) return;
    const timer = setInterval(() => {
      if (gestureUntil.current && Date.now() >= gestureUntil.current) {
        gestureUntil.current = 0;
        frame();
      }
    }, 250);
    return () => clearInterval(timer);
  }, [props.active]);
  useEffect(() => {
    if (Date.now() >= gestureUntil.current) frame();
  }, [props.bookingId, props.driver, props.nearby]);
  if (failed || configured !== props.token)
    return (
      <View style={s.wait}>
        {failed ? (
          <>
            <Text style={s.detail}>
              Karte momentan nicht erreichbar. Der Fahrtstatus bleibt verfügbar.
            </Text>
            <Pressable
              accessibilityRole="button"
              onPress={() => {
                setFailed(false);
                setAttempt((v) => v + 1);
              }}
            >
              <Text style={s.retry}>Karte erneut starten</Text>
            </Pressable>
          </>
        ) : (
          <ActivityIndicator color="#aa8345" />
        )}
      </View>
    );
  return (
    <View style={s.root}>
      <Mapbox.MapView
        key={attempt}
        style={s.root}
        styleURL="mapbox://styles/mapbox/streets-v12"
        surfaceView={false}
        compassEnabled={false}
        scaleBarEnabled={false}
        rotateEnabled={false}
        pitchEnabled={false}
        logoPosition={{ top: 12, left: 10 }}
        attributionPosition={{ top: 12, left: 100 }}
        onDidFinishLoadingMap={() => {
          ready.current = true;
          frame();
        }}
        onMapLoadingError={() => {
          ready.current = false;
          setFailed(true);
        }}
        onCameraChanged={(state) => {
          if (state.gestures.isGestureActive)
            gestureUntil.current = Date.now() + 3000;
        }}
      >
        <Mapbox.Camera
          ref={camera}
          defaultSettings={{
            centerCoordinate: [props.route.pickup.lng, props.route.pickup.lat],
            zoomLevel: 13,
          }}
        />
        <Mapbox.ShapeSource
          id="customer-route"
          shape={{
            type: 'Feature',
            properties: {},
            geometry: props.route.geometry,
          }}
        >
          <Mapbox.LineLayer
            id="customer-outline"
            style={{
              lineColor: '#fff',
              lineWidth: 9,
              lineCap: 'round',
              lineJoin: 'round',
            }}
          />
          <Mapbox.LineLayer
            id="customer-line"
            style={{
              lineColor: '#aa8345',
              lineWidth: 5,
              lineCap: 'round',
              lineJoin: 'round',
            }}
          />
        </Mapbox.ShapeSource>
        {[props.route.pickup, props.route.destination].map((p, i) => (
          <Mapbox.MarkerView key={i} coordinate={[p.lng, p.lat]} allowOverlap>
            <View style={[s.point, i === 1 && s.destination]} />
          </Mapbox.MarkerView>
        ))}
        {[...(props.driver ? [props.driver] : []), ...props.nearby].map(
          (p, i) => (
            <Mapbox.MarkerView
              key={props.driver ? 'assigned' : `nearby-${i}`}
              coordinate={[p.lng, p.lat]}
              allowOverlap
            >
              <View style={s.car}>
                <CarFront color="#fff" size={22} />
              </View>
            </Mapbox.MarkerView>
          ),
        )}
      </Mapbox.MapView>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Gesamte Fahrt auf der Karte anzeigen"
        style={s.locate}
        onPress={() => {
          gestureUntil.current = 0;
          frame();
        }}
      >
        <LocateFixed color="#aa8345" size={24} />
      </Pressable>
    </View>
  );
}
const s = StyleSheet.create({
  root: { flex: 1 },
  wait: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
    backgroundColor: '#f7f4ee',
  },
  detail: { color: '#626875', textAlign: 'center', lineHeight: 22 },
  retry: { color: '#aa8345', padding: 20, fontWeight: '700' },
  locate: {
    position: 'absolute',
    right: 16,
    bottom: 22,
    padding: 16,
    borderRadius: 30,
    backgroundColor: '#fff',
  },
  point: {
    width: 18,
    height: 18,
    borderWidth: 4,
    borderColor: '#fff',
    backgroundColor: '#aa8345',
    borderRadius: 12,
  },
  destination: { backgroundColor: '#161a20', borderRadius: 4 },
  car: {
    padding: 8,
    borderRadius: 24,
    backgroundColor: '#161a20',
    borderWidth: 2,
    borderColor: '#fff',
  },
});
