import type {
  Booking,
  Driver,
  FleetVehicle,
  Offer,
} from '../../lib/mobility/domain';
import type { Position } from './location-service';
export type DriverState = {
  driver: Driver | null;
  offers: Offer[];
  bookings: Booking[];
  payments?: Booking[];
  history?: Booking[];
  today?: {
    gross: number;
    collected: number;
    outstanding: number;
    trips: number;
  };
  inventory?: { initialized: boolean; urgent: number; missing: number } | null;
  vehicles?: FleetVehicle[];
  fleet?: { id: string; name: string } | null;
  serverTime?: number;
};
export function shiftState(
  state: DriverState | null,
  sessionId: string | null,
  fix: Position | null,
  now: number,
) {
  const driver = state?.driver;
  if (!driver) return 'unregistered';
  if (!driver.approved) return 'pending';
  if (!sessionId || sessionId !== driver.session_id) return 'offline';
  if (!fix || now - fix.timestamp > 15000 || fix.accuracy > 100) return 'gps';
  if (!driver.online || !driver.location_at || now - driver.location_at > 45000)
    return 'connecting';
  return 'online';
}
export function shiftLocked(state: DriverState | null) {
  return !!(state?.bookings.length || state?.payments?.length);
}
export function liveOffer(state: DriverState | null, now: number) {
  // Compare to server time: an incorrect phone clock must not hide valid offers.
  return state?.offers.find((offer) => offer.expires_at > now) || null;
}
export function canSelectVehicle(
  state: DriverState | null,
  vehicle: FleetVehicle,
  sessionId: string | null,
) {
  return (
    !!state?.driver?.approved &&
    !state.driver.online &&
    !state.driver.session_id &&
    !sessionId &&
    !shiftLocked(state) &&
    vehicle.status === 'active' &&
    (!vehicle.driver_id || vehicle.driver_id === state.driver.id) &&
    vehicle.fleet_id === state.fleet?.id
  );
}
export const euros = (cents: number) =>
  (cents / 100).toLocaleString('de-DE', { style: 'currency', currency: 'EUR' });
