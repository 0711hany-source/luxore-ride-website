import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, layout, maxFontScale, radii, space } from './theme';

const numbers = [1, 2, 3, 4, 5] as const;
export const starsLabel = (stars: number) => `${stars} von 5 Sternen`;

/** Stars already given (read only): one line for screen readers. */
export function CustomerStarsShown({ stars }: { stars: number }) {
  return (
    <View
      accessible
      accessibilityRole="text"
      accessibilityLabel={starsLabel(stars)}
      style={s.shown}
    >
      {numbers.map((n) => (
        <Text
          key={n}
          maxFontSizeMultiplier={maxFontScale}
          style={[s.small, n <= stars ? s.on : s.off]}
        >
          ★
        </Text>
      ))}
    </View>
  );
}

/**
 * Star input of the customer app: five touch targets of at least 48 pt,
 * each announced as "3 von 5 Sternen".
 */
export default function CustomerRatingStars({
  value,
  onChange,
  disabled,
  label = 'Chauffeur bewerten',
}: {
  value: number;
  onChange: (stars: number) => void;
  disabled?: boolean;
  label?: string;
}) {
  return (
    <View accessibilityRole="radiogroup" accessibilityLabel={label} style={s.row}>
      {numbers.map((n) => (
        <Pressable
          key={n}
          accessibilityRole="radio"
          accessibilityLabel={starsLabel(n)}
          accessibilityState={{ checked: value === n, disabled: !!disabled }}
          disabled={disabled}
          onPress={() => onChange(n)}
          style={s.star}
        >
          <Text
            maxFontSizeMultiplier={maxFontScale}
            style={[s.big, n <= value ? s.on : s.off]}
          >
            ★
          </Text>
        </Pressable>
      ))}
    </View>
  );
}
const s = StyleSheet.create({
  row: { flexDirection: 'row', gap: space[1] },
  star: {
    minWidth: layout.tap,
    minHeight: layout.tap,
    borderRadius: radii.pill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  big: { fontSize: 34, lineHeight: 41 },
  shown: { flexDirection: 'row', gap: 2 },
  small: { fontSize: 17, lineHeight: 22 },
  on: { color: colors.gold },
  off: { color: colors.lineStrong },
});
