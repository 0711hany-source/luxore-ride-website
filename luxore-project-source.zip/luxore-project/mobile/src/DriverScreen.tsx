import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  Linking,
  Modal,
  PanResponder,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from 'react-native';
import * as SecureStore from 'expo-secure-store';
import { keepScreenOn } from './keep-awake';
import {
  CarFront,
  ChevronDown,
  LocateFixed,
  Navigation,
  Phone,
  RefreshCw,
  ShieldCheck,
  X,
} from 'lucide-react-native';
// Icons of the hints on the map, read from the namespace so plain Node test
// runs with a small icon stand-in still load this screen.
import * as Icons from 'lucide-react-native';
const { ArrowUp, CornerUpLeft, CornerUpRight, Flag, GlassWater, MessageCircle, Star, Undo2 } =
  Icons;
import { nativeApi, type NativeAccount } from './account-client';
import {
  type Credential,
  backgroundPermission,
  foregroundPermission,
  startLocation,
  stopLocation,
} from './location-service';
import { abortable, stepDeadline } from './location-request';
import { useDriverGps } from './use-driver-gps';
import {
  canSelectVehicle,
  euros,
  liveOffer,
  shiftLocked,
  shiftState,
  type DriverState,
} from './driver-model';
import type { Booking, RouteData } from '../../lib/mobility/domain';
import { driverNext, statusNames } from '../../lib/mobility/domain';
import {
  adjustmentNote,
  destinationChangeNote,
} from '../../lib/mobility/end-adjustment';
import { menu, cartLabel } from '../../lib/mobility/refreshments';
import { preferenceLabels } from '../../lib/mobility/ride-preferences';
import {
  advanceNavigation,
  compileNavigation,
  navigationDistance,
  remainingDistance,
  type NavigationProgress,
} from '../../app/mobility/navigation-progress';
import { waitingNote } from '../../lib/mobility/waiting';
import {
  laneGlyph,
  LANE_HINT_METERS,
} from '../../lib/mobility/navigation-steps';
import {
  defaultNavigation,
  navigationProviders,
  navigationTarget,
  navigationUrl,
  parseNavigation,
  type NavigationPreferences,
} from '../../app/mobility/navigation-preferences';
import DriverMap from './DriverMap';
import SwipeAction from './SwipeAction';
import { offerAlerts } from './offer-alerts';
import { driverNotice } from './driver-notices';
import RideChat from './RideChat';
import ShiftReadiness from './ShiftReadiness';
import ReservationsEntry from './ReservationsEntry';
import RiderRating from './platform/RiderRating';
import {
  givenStars,
  ratingLabel,
  ratingText,
  riderRatingOf,
} from './driver-reservations';
import { refusalTitle, shiftRefusal } from './operator-platform';
import { colors, layout, radii, space, typography, maxFontScale } from './theme';
import { isIos, platformText } from './platform-text';

export const preferencesKey = 'luxore-native-navigation-v1';
const ratingSeenKey = 'luxore-driver-rating-seen';
/** Large arrow of the next manoeuvre, readable at a glance. */
function TurnIcon({ type, modifier }: { type: string; modifier?: string }) {
  const Icon =
    type === 'arrive'
      ? Flag
      : modifier?.includes('uturn')
        ? Undo2
        : modifier?.includes('left')
          ? CornerUpLeft
          : modifier?.includes('right')
            ? CornerUpRight
            : ArrowUp;
  return <Icon color={colors.white} size={54} strokeWidth={2.6} />;
}
const clockTime = (ms: number) => {
  const seconds = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`;
};
// Fahrersicht auf den Fahrtstatus (die Kundensicht steht in statusNames).
const driverStatus = (status: keyof typeof statusNames) =>
  status === 'accepted'
    ? 'Auf dem Weg zum Fahrgast'
    : status === 'arrived'
      ? 'Am Abholort'
      : statusNames[status];
// Going online is user-paced (Android dialogs, settings page) but never open-ended.
const shiftTotalMs = 180_000;
const onlineSteps = [
  {
    title: 'Standortfreigabe',
    hint: platformText.onlineStepHint,
  },
  {
    title: 'Anmeldung',
    hint: 'Deine Schicht wird bei LUXORÉ angemeldet.',
  },
  {
    title: 'Hintergrunddienst',
    hint: 'Der Standortdienst für gesperrten Bildschirm und Navigation startet.',
  },
  {
    title: 'Bereit',
    hint: 'Standort und Verbindung werden ein letztes Mal geprüft.',
  },
];
const offlineSteps = [
  {
    title: 'Standortdienst beenden',
    hint: 'Die Standortübertragung wird gestoppt.',
  },
  {
    title: 'Abmeldung',
    hint: 'Deine Schicht wird bei LUXORÉ beendet.',
  },
];
type ShiftFlow = { offline: boolean; step: number; ending: boolean };
export default function DriverScreen(
  props: React.ComponentProps<typeof DriverWorkspace>,
) {
  return <DriverWorkspace key={props.token} {...props} />;
}
function DriverWorkspace({
  token,
  profile,
  active,
  settings,
  onFleet,
  onInventory,
  onEarnings,
  onCompliance,
  onReservations,
}: {
  token: string;
  profile: NativeAccount;
  active: boolean;
  settings: boolean;
  onFleet: () => void;
  onInventory: (vehicleId?: string) => void;
  /** „Meine Einnahmen“ bzw. Prüf-Bereich („Vor der Schicht“) öffnen. */
  onEarnings?: () => void;
  onCompliance?: () => void;
  /** Reservierungstafel öffnen. */
  onReservations?: () => void;
}) {
  'use no memo'; // Native gesture/camera commands use mutable imperative handles.
  const gps = useDriverGps();
  const [state, setState] = useState<DriverState | null>(null);
  const [mapToken, setMapToken] = useState('');
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [modal, setModal] = useState<'vehicle' | 'revenue' | null>(null);
  const [connectionError, setConnectionError] = useState('');
  const [flow, setFlow] = useState<ShiftFlow | null>(null);
  const [shiftIssue, setShiftIssue] = useState<{
    message: string;
    settings: boolean;
    /** Ablehnung wegen Prüfpflicht oder Sperre: jeder Grund einzeln. */
    reasons?: string[];
  } | null>(null);
  const [paying, setPaying] = useState<'cash' | 'terminal' | null>(null);
  const flowAbort = useRef<AbortController | null>(null);
  const [guidance, setGuidance] = useState<{
    key: string;
    route: RouteData;
  } | null>(null);
  const [progress, setProgress] = useState<NavigationProgress | null>(null);
  const [prefs, setPrefs] = useState<NavigationPreferences>(defaultNavigation);
  const [clock, setClock] = useState(() => Date.now());
  const [collapsed, setCollapsed] = useState(false);
  const height = Math.min(500, useWindowDimensions().height * 0.61);
  const [drag] = useState(() => new Animated.Value(0));
  const bottom = useRef(0);
  useEffect(() => {
    bottom.current = height - 105;
  }, [height]);
  const collapsedRef = useRef(false);
  const [offset, setOffset] = useState(0);
  const locked = useRef(false),
    readsEnabled = useRef(false),
    driverRead = useRef<AbortController | null>(null),
    configRead = useRef<AbortController | null>(null),
    guidanceRead = useRef<AbortController | null>(null),
    alive = useRef(true);
  const gpsRef = useRef(gps);
  useEffect(() => {
    gpsRef.current = gps;
  }, [gps]);
  const cancelReads = useCallback(() => {
    for (const slot of [driverRead, configRead, guidanceRead]) {
      slot.current?.abort();
      slot.current = null;
    }
  }, []);
  const invalidate = useCallback(() => {
    alive.current = false;
    readsEnabled.current = false;
    cancelReads();
  }, [cancelReads]);
  const loadMapConfig = useCallback(async () => {
    if (
      !alive.current ||
      !readsEnabled.current ||
      locked.current ||
      configRead.current
    )
      return;
    const request = new AbortController();
    configRead.current = request;
    try {
      const config = await nativeApi<{ publicMapToken?: string }>(
        'config',
        token,
        undefined,
        undefined,
        request.signal,
      );
      if (
        alive.current &&
        readsEnabled.current &&
        configRead.current === request &&
        !request.signal.aborted
      )
        setMapToken(config.publicMapToken || '');
    } catch {
      /* GPS and shift actions remain available without map tiles. */
    } finally {
      if (configRead.current === request) configRead.current = null;
    }
  }, [token]);
  const refresh = useCallback(async () => {
    if (
      !alive.current ||
      !readsEnabled.current ||
      locked.current ||
      driverRead.current
    )
      return;
    const request = new AbortController();
    driverRead.current = request;
    try {
      const data = await nativeApi<DriverState>(
        'driver',
        token,
        undefined,
        undefined,
        request.signal,
      );
      if (
        !alive.current ||
        !readsEnabled.current ||
        driverRead.current !== request ||
        request.signal.aborted
      )
        return;
      if (data.serverTime) setOffset(data.serverTime - Date.now());
      setState(data);
      setConnectionError('');
    } catch (e) {
      if (
        alive.current &&
        readsEnabled.current &&
        driverRead.current === request &&
        !request.signal.aborted
      ) {
        if ([401, 403].includes((e as { status?: number }).status || 0)) {
          setState(null);
          setGuidance(null);
          setProgress(null);
          setMapToken('');
          configRead.current?.abort();
          configRead.current = null;
          guidanceRead.current?.abort();
          guidanceRead.current = null;
        }
        setConnectionError((e as Error).message);
      }
    } finally {
      if (driverRead.current === request) driverRead.current = null;
    }
  }, [token]);
  useEffect(() => {
    alive.current = true;
    let current = true;
    void SecureStore.getItemAsync(preferencesKey)
      .then((raw) => {
        if (alive.current && current && raw)
          setPrefs(parseNavigation(JSON.parse(raw)));
      })
      .catch(() => {});
    return () => {
      current = false;
      invalidate();
    };
  }, [invalidate]);
  useEffect(() => {
    readsEnabled.current = active && gps.foreground;
    if (!readsEnabled.current) {
      cancelReads();
      return;
    }
    void refresh();
    void loadMapConfig();
    const poll = setInterval(() => void refresh(), 5000);
    const timer = setInterval(() => setClock(Date.now()), 1000);
    return () => {
      readsEnabled.current = false;
      cancelReads();
      clearInterval(poll);
      clearInterval(timer);
    };
  }, [active, gps.foreground, refresh, loadMapConfig, cancelReads]);
  const trip = state?.bookings[0] || null;
  const phase = trip ? `${trip.id}:${trip.status}` : '';
  const tripId = trip?.id,
    tripStatus = trip?.status;
  const route =
    guidance?.key === phase
      ? guidance.route
      : trip?.status === 'riding'
        ? trip.route
        : null;
  useEffect(() => {
    if (
      !active ||
      !gps.foreground ||
      busy ||
      !tripId ||
      !tripStatus ||
      !['accepted', 'riding'].includes(tripStatus)
    )
      return;
    let cancelled = false;
    let lastAttempt = -Infinity;
    const request = async () => {
      const fix = gpsRef.current.position;
      if (
        !fix ||
        fix.accuracy > 50 ||
        Date.now() - fix.timestamp > 10000 ||
        cancelled ||
        !readsEnabled.current ||
        locked.current ||
        guidanceRead.current ||
        Date.now() - lastAttempt < 20000
      )
        return;
      const reading = new AbortController();
      guidanceRead.current = reading;
      lastAttempt = Date.now();
      try {
        const result = await nativeApi<{
          bookingId: string;
          phase: string;
          route: RouteData;
        }>(
          'guidance',
          token,
          { bookingId: tripId, position: fix },
          undefined,
          reading.signal,
        );
        if (
          !cancelled &&
          alive.current &&
          readsEnabled.current &&
          guidanceRead.current === reading &&
          !reading.signal.aborted &&
          phase === `${result.bookingId}:${result.phase}`
        )
          setGuidance({ key: phase, route: result.route });
      } catch {
        /* Route failure never ends the shift or changes the agreed fare. */
      } finally {
        if (guidanceRead.current === reading) guidanceRead.current = null;
      }
    };
    void request();
    const timer = setInterval(() => void request(), 25000);
    return () => {
      cancelled = true;
      guidanceRead.current?.abort();
      guidanceRead.current = null;
      clearInterval(timer);
    };
  }, [phase, tripId, tripStatus, active, gps.foreground, token, busy]);
  const trackRef = useRef(compileNavigation(null));
  useEffect(() => {
    trackRef.current = compileNavigation(route);
  }, [route]);
  useEffect(() => {
    const track = trackRef.current;
    if (track && gps.position)
      setProgress((previous) =>
        advanceNavigation(track, gps.position!, Date.now(), previous),
      );
  }, [gps.position, route]);
  // The sheet makes room for the map as soon as guidance starts.
  useEffect(() => {
    if (tripStatus === 'accepted' || tripStatus === 'riding')
      slideRef.current(true);
    else slideRef.current(false);
  }, [tripId, tripStatus]);
  // A board order must not be missed while driving: sound, vibration and a
  // banner on the map that stays until every item is handed over.
  const openOrder = trip?.refreshments
    ? menu
        .filter((item) => trip.refreshments!.requested[item.id])
        .map((item) => `${trip.refreshments!.requested[item.id]} × ${item.name}`)
        .join(', ')
    : '';
  const lastOrder = useRef('');
  useEffect(() => {
    const key = tripId ? `${tripId}:${openOrder}` : '';
    if (openOrder && key !== lastOrder.current)
      void driverNotice('luxore-board-order', 'Neue Bordbestellung', openOrder);
    lastOrder.current = key;
  }, [tripId, openOrder]);
  // A new rating is shown once, briefly, at the top.
  const latestRating = state?.latestRating || null;
  const [ratingNotice, setRatingNotice] = useState<string | null>(null);
  const [chatNotice, setChatNotice] = useState('');
  const ratingId = latestRating?.id;
  useEffect(() => {
    if (!ratingId) return;
    let current = true;
    void SecureStore.getItemAsync(ratingSeenKey)
      .then((seen) => {
        if (!current || seen === ratingId) return;
        setRatingNotice(ratingId);
        void SecureStore.setItemAsync(ratingSeenKey, ratingId).catch(() => {});
      })
      .catch(() => {});
    return () => {
      current = false;
    };
  }, [ratingId]);
  const shift = shiftState(state, gps.sessionId, gps.position, clock);
  // Wish of the operator (18.11.2026): while the shift runs the screen
  // must not switch itself off – offers and navigation stay visible.
  const awake = shift === 'online' || shift === 'gps' || shift === 'connecting';
  useEffect(() => {
    if (awake) return keepScreenOn('luxore-shift');
  }, [awake]);
  const offer = liveOffer(state, clock + offset);
  // Follow-up ride: an offer may arrive while a guest is on board.
  const chainOffer = !!offer && trip?.status === 'riding';
  const waiting = state?.queued?.[0] || null;
  const payment = state?.payments?.[0];
  async function navigate(
    action: { action?: string; status?: string },
    booking?: Booking | null,
  ) {
    const target = navigationTarget(action, booking?.route);
    const url =
      target && prefs.autoStart ? navigationUrl(prefs.provider, target) : null;
    if (url)
      await Linking.openURL(url).catch(() =>
        setError(
          'Die ausgewählte Navigation konnte nicht geöffnet werden. Bitte die App installieren oder Standard wählen.',
        ),
      );
  }
  async function perform(
    path: string,
    body: object,
    onSuccess?: () => Promise<void>,
  ) {
    if (locked.current) return;
    locked.current = true;
    setBusy(true);
    setError('');
    cancelReads();
    try {
      await nativeApi(path, token, body);
      if (onSuccess) await onSuccess();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      locked.current = false;
      setBusy(false);
      // Do not let an old GET overwrite a confirmed action.
      await refresh();
    }
  }
  async function pay(method: 'cash' | 'terminal', id: string) {
    if (locked.current) return;
    // Only the chosen confirmation shows progress; the other one stays locked.
    setPaying(method);
    try {
      await perform('payments', { id, method });
    } finally {
      setPaying(null);
    }
  }
  async function toggleShift() {
    if (locked.current) return;
    locked.current = true;
    setBusy(true);
    setError('');
    setShiftIssue(null);
    cancelReads();
    const offline = !!(gps.sessionId || state?.driver?.session_id);
    const steps = offline ? offlineSteps : onlineSteps;
    const attempt = new AbortController();
    flowAbort.current = attempt;
    let step = 1;
    let timedOut = false;
    const enter = (next: number) => {
      step = next;
      setFlow({ offline, step: next, ending: false });
    };
    // Cancel and the overall deadline stop waiting at once, whatever hangs.
    const guard = <T,>(work: Promise<T>) => abortable(work, attempt.signal);
    const total = setTimeout(() => {
      timedOut = true;
      attempt.abort();
    }, shiftTotalMs);
    let started: Credential | null = null;
    let signin: Promise<Credential> | null = null;
    enter(1);
    try {
      if (offline) {
        if (shiftLocked(state))
          throw new Error(
            'Bitte die Fahrt abschließen und den offenen Betrag kassieren, bevor du die Schicht beendest.',
          );
        const sessionId = gps.sessionId || state!.driver!.session_id;
        await guard(
          stepDeadline(
            'Das Beenden des Standortdienstes',
            stopLocation(),
            25_000,
          ),
        );
        enter(2);
        await guard(
          nativeApi('driver', token, { action: 'offline', sessionId }),
        );
      } else {
        await guard(foregroundPermission());
        const fix = gpsRef.current.position;
        if (!fix || Date.now() - fix.timestamp > 15000 || fix.accuracy > 100) {
          void gps.restart();
          throw new Error(
            'GPS sucht deinen genauen Standort. Bitte kurz im Freien warten und erneut online gehen.',
          );
        }
        // Ask for „Immer zulassen“ before the shift exists on the server: a
        // missing permission then leaves nothing behind that must be undone.
        await guard(backgroundPermission(attempt.signal));
        enter(2);
        signin = nativeApi<Credential>('driver', token, {
          action: 'online',
          native: true,
        });
        started = await guard(signin);
        enter(3);
        await guard(startLocation(started));
        enter(4);
      }
      await guard(stepDeadline('Der Standortstatus', gps.sync(), 15_000));
    } catch (e) {
      const cancelled = attempt.signal.aborted && !timedOut;
      setFlow({ offline, step, ending: true });
      // A sign-in that was still on its way may have opened the shift.
      if (!started && signin) started = await signin.catch(() => null);
      if (started) {
        // Cleanup is best effort and bounded: the button must become usable again.
        await stepDeadline(
          'Das Beenden des Standortdienstes',
          stopLocation(),
          25_000,
        ).catch(() => {});
        await nativeApi('driver', token, {
          action: 'offline',
          sessionId: started.sessionId,
        }).catch(() => {});
        await stepDeadline('Der Standortstatus', gps.sync(), 15_000).catch(
          () => {},
        );
      }
      const name = `Schritt ${step}/${steps.length} · ${steps[step - 1].title}`;
      // Nur Darstellung: Der Servertext bleibt vollständig, mehrere Gründe
      // stehen untereinander statt in einer Zeile.
      const reasons =
        cancelled || timedOut ? null : shiftRefusal((e as Error).message);
      setShiftIssue({
        ...(reasons ? { reasons } : {}),
        message: cancelled
          ? 'Online gehen wurde abgebrochen. Du bist offline.'
          : timedOut
            ? `${name}: Der Vorgang hat länger als 3 Minuten gedauert und wurde beendet. ${offline ? 'Bitte erneut versuchen.' : 'Du bist offline.'}`
            : reasons
              ? `${name}: ${refusalTitle}:`
              : `${name}: ${(e as Error).message}`,
        settings:
          !cancelled &&
          !timedOut &&
          (e as { settings?: boolean }).settings === true,
      });
    } finally {
      clearTimeout(total);
      if (flowAbort.current === attempt) flowAbort.current = null;
      locked.current = false;
      setBusy(false);
      setFlow(null);
      await refresh();
    }
  }
  function slide(value: boolean) {
    collapsedRef.current = value;
    setCollapsed(value);
    Animated.spring(drag, {
      toValue: value ? bottom.current : 0,
      useNativeDriver: true,
      bounciness: 0,
    }).start();
  }
  const slideRef = useRef(slide);
  useEffect(() => {
    slideRef.current = slide;
  });
  // PanResponder stores callbacks; it does not execute the gesture refs during render.
  // oxlint-disable-next-line react/react-compiler
  const [pan] = useState(() =>
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) =>
        Math.abs(g.dy) > 6 && Math.abs(g.dy) > Math.abs(g.dx),
      onPanResponderMove: (_, g) =>
        drag.setValue(
          Math.max(
            0,
            Math.min(
              bottom.current,
              (collapsedRef.current ? bottom.current : 0) + g.dy,
            ),
          ),
        ),
      onPanResponderRelease: (_, g) =>
        slideRef.current(
          g.vy > 0.5 ||
            (g.vy > -0.5 &&
              (collapsedRef.current ? bottom.current : 0) + g.dy >
                bottom.current * 0.4),
        ),
      onPanResponderTerminate: () => slideRef.current(collapsedRef.current),
    }),
  );
  async function savePrefs(next: NavigationPreferences) {
    setPrefs(next);
    await SecureStore.setItemAsync(preferencesKey, JSON.stringify(next)).catch(
      () => setError('Navigationseinstellung konnte nicht gespeichert werden.'),
    );
  }
  const guiding = !!progress && !!trip && clock - progress.fix.timestamp < 10000;
  if (settings)
    return (
      <ScrollView contentContainerStyle={s.settings}>
        <Text style={s.eyebrow}>DEINE NAVIGATION</Text>
        <Text style={s.title}>Immer dein Weg.</Text>
        {navigationProviders
          // Apple Karten gibt es nur auf dem iPhone.
          .filter((provider) => isIos || provider.id !== 'apple')
          .map((provider) => (
            <Pressable
              key={provider.id}
              style={[s.row, prefs.provider === provider.id && s.selected]}
              onPress={() =>
                void savePrefs({ ...prefs, provider: provider.id })
              }
            >
              <Navigation color={gold} size={24} />
              <View style={s.flex}>
                <Text style={s.heading}>{provider.name}</Text>
                <Text style={s.detail}>{provider.description}</Text>
              </View>
              <Text style={s.detail}>
                {prefs.provider === provider.id ? '✓' : ''}
              </Text>
            </Pressable>
          ))}
        <Pressable
          style={s.row}
          onPress={() =>
            void savePrefs({ ...prefs, autoStart: !prefs.autoStart })
          }
        >
          <Navigation color={gold} size={22} />
          <Text style={[s.heading, s.flex]}>
            Nach Fahrtannahme automatisch starten
          </Text>
          <Text style={s.detail}>{prefs.autoStart ? 'An' : 'Aus'}</Text>
        </Pressable>
        <Text style={s.detail}>
          {platformText.navigationNote}
        </Text>
        <Pressable style={s.row} onPress={() => void Linking.openSettings().catch(() => {})}>
          <LocateFixed color={gold} size={22} />
          <Text style={s.heading}>{platformText.openPermissions}</Text>
        </Pressable>
        {!!error && <Text style={s.error}>{error}</Text>}
      </ScrollView>
    );
  return (
    <View style={s.root}>
      {/* The map stays mounted: a permission dialog or a short trip to the
          settings pauses its motion instead of rebuilding the whole map. */}
      <DriverMap
        token={mapToken}
        position={gps.position}
        route={route}
        active={active && gps.foreground}
        topInset={guiding ? 190 : 80}
        bottomInset={collapsed ? 105 : height}
        turnIn={guiding ? progress!.distanceToTurn : null}
      />
      <View pointerEvents="box-none" style={s.top}>
        {/* No revenue on screen while a guest is on board or being picked up. */}
        {!trip && (
          <Pressable style={s.revenue} onPress={() => setModal('revenue')}>
            <Text style={s.eyebrow}>HEUTE</Text>
            <Text style={s.revenueText}>{euros(state?.today?.gross || 0)}</Text>
          </Pressable>
        )}
        {guiding && (
          <View
            style={s.guidance}
            accessible
            accessibilityLiveRegion="polite"
            accessibilityLabel={`${navigationDistance(progress!.distanceToTurn)}. ${progress!.next.instruction}`}
          >
            <TurnIcon
              type={progress!.next.type}
              modifier={progress!.next.modifier}
            />
            <View style={s.flex}>
              <Text
                maxFontSizeMultiplier={1.2}
                style={s.turnDistance}
                numberOfLines={1}
              >
                {navigationDistance(progress!.distanceToTurn)}
              </Text>
              <Text
                maxFontSizeMultiplier={1.2}
                style={s.turnText}
                numberOfLines={2}
              >
                {progress!.next.instruction}
              </Text>
              {!!progress!.next.lanes &&
                progress!.distanceToTurn <= LANE_HINT_METERS && (
                  <View
                    style={s.lanes}
                    accessible
                    accessibilityLabel={`Spur: ${progress!.next.lanes
                      .map((l, i) => (l.valid ? i + 1 : 0))
                      .filter(Boolean)
                      .join(' oder ')} von links, ${progress!.next.lanes.length} Spuren`}
                  >
                    {progress!.next.lanes.map((lane, i) => (
                      <View
                        key={i}
                        style={[s.lane, lane.valid && s.laneValid]}
                      >
                        <Text
                          maxFontSizeMultiplier={1}
                          style={[s.laneGlyph, lane.valid && s.laneGlyphValid]}
                        >
                          {laneGlyph(lane.indication)}
                        </Text>
                      </View>
                    ))}
                  </View>
                )}
              <Text maxFontSizeMultiplier={1.2} style={s.turnRest}>
                {Math.max(1, Math.round(progress!.remainingSeconds / 60))} min ·{' '}
                {remainingDistance(progress!.remainingMeters)}
              </Text>
            </View>
          </View>
        )}
        {!!openOrder && (
          <Pressable
            style={s.notice}
            accessibilityRole="button"
            accessibilityLabel={`Bordbestellung: ${openOrder}. Zum Übergeben öffnen.`}
            onPress={() => slide(false)}
          >
            <GlassWater color={ink} size={28} />
            <View style={s.flex}>
              <Text style={s.noticeTitle}>Bordbestellung</Text>
              <Text style={s.noticeText}>{openOrder}</Text>
            </View>
            <Text style={s.noticeAction}>Öffnen</Text>
          </Pressable>
        )}
        {!!chatNotice && !!trip && (
          <Pressable
            style={s.notice}
            accessibilityRole="button"
            accessibilityLabel={`Nachricht vom Fahrgast: ${chatNotice}. Zum Antworten öffnen.`}
            onPress={() => {
              setChatNotice('');
              slide(false);
            }}
          >
            <MessageCircle color={ink} size={26} />
            <View style={s.flex}>
              <Text style={s.noticeTitle}>Nachricht vom Fahrgast</Text>
              <Text style={s.noticeText} numberOfLines={3}>
                {chatNotice}
              </Text>
            </View>
            <Text style={s.noticeAction}>Öffnen</Text>
          </Pressable>
        )}
        {!!latestRating && ratingNotice === latestRating.id && (
          <Pressable
            style={s.notice}
            accessibilityRole="button"
            accessibilityLabel={`Neue Bewertung: ${latestRating.stars} von 5 Sternen. ${latestRating.comment} Tippen zum Ausblenden.`}
            onPress={() => setRatingNotice(null)}
          >
            <Star color={ink} fill={ink} size={26} />
            <View style={s.flex}>
              <Text style={s.noticeTitle}>
                {latestRating.stars} von 5 Sternen erhalten
              </Text>
              {!!latestRating.comment && (
                <Text style={s.noticeText} numberOfLines={3}>
                  „{latestRating.comment}“
                </Text>
              )}
            </View>
            <X color={ink} size={20} />
          </Pressable>
        )}
      </View>
      <Animated.View
        style={[s.sheet, { height, transform: [{ translateY: drag }] }]}
      >
        <View {...pan.panHandlers} style={s.handleArea}>
          <View style={s.handle} />
          <View style={s.sheetHeader}>
            <View style={s.flex}>
              <Text maxFontSizeMultiplier={maxFontScale} style={s.heading}>
                {trip && !payment
                  ? driverStatus(trip.status)
                  : shift === 'online'
                  ? 'Online · bereit für Anfragen'
                  : shift === 'gps'
                    ? 'GPS wird aktualisiert'
                    : shift === 'connecting'
                      ? 'Verbindung wird geprüft'
                      : shift === 'pending'
                        ? 'Freigabe ausstehend'
                        : 'Deine Schicht'}
              </Text>
              <Text
                maxFontSizeMultiplier={maxFontScale}
                style={s.detail}
                numberOfLines={1}
              >
                {trip && !payment
                  ? trip.status === 'riding'
                    ? trip.route.destination.label
                    : trip.route.pickup.label
                  : `${state?.driver?.vehicle || 'Fahrzeug auswählen'} ${
                      state?.driver?.plate ? `· ${state.driver.plate}` : ''
                    }`}
              </Text>
            </View>
            <Pressable
              accessibilityLabel={
                collapsed ? 'Fahrtübersicht ausklappen' : 'Mehr Karte anzeigen'
              }
              onPress={() => slide(!collapsed)}
            >
              <ChevronDown
                color={ink}
                style={{
                  transform: [{ rotate: collapsed ? '180deg' : '0deg' }],
                }}
                size={25}
              />
            </Pressable>
          </View>
        </View>
        <ScrollView
          contentContainerStyle={s.sheetContent}
          showsVerticalScrollIndicator={false}
        >
          {!state && <ActivityIndicator color={gold} />}
          {(error || connectionError || gps.error) && (
            <View style={s.warning}>
              <Text accessibilityRole="alert" style={s.error}>
                {error || connectionError || gps.error}
              </Text>
              <Pressable
                hitSlop={8}
                onPress={() => {
                  setError('');
                  void Promise.resolve().then(refresh);
                  void Promise.resolve().then(loadMapConfig);
                  void gps.restart(true);
                }}
              >
                <Text style={s.link}>Verbindung & GPS erneut prüfen</Text>
              </Pressable>
            </View>
          )}
          {state && !state.driver && (
            <>
              <Text style={s.title}>Dein Fahrerprofil.</Text>
              <Text style={s.detail}>
                Dein Konto ist angemeldet. Für Fahrtangebote benötigst du ein
                Fahrerprofil und die Freigabe deiner Disposition.
              </Text>
              <Button
                title="Fahrerprofil anlegen"
                busy={busy}
                onPress={() =>
                  void perform('driver', {
                    action: 'register',
                    name: profile.name,
                    phone: profile.phone,
                  })
                }
              />
            </>
          )}
          {state?.driver && !state.driver.approved && (
            <>
              <Text style={s.title}>Fast bereit.</Text>
              <Text style={s.detail}>
                Die Disposition muss dein Fahrerprofil freigeben und dich einer
                Flotte zuordnen.
              </Text>
              <Button title="Flotte & Team" onPress={onFleet} />
            </>
          )}
          {payment && (
            <>
              <Text style={s.eyebrow}>FAHRT ABGESCHLOSSEN</Text>
              <Text style={s.title}>{euros(payment.price)}</Text>
              {!!adjustmentNote(payment.route) && (
                <Text style={s.detail}>{adjustmentNote(payment.route)}
              {!!waitingNote(payment.route) && (
                <Text style={s.detail}>{waitingNote(payment.route)}</Text>
              )}</Text>
              )}
              <Text style={s.detail}>
                Diesen Betrag vom Fahrgast kassieren. Erst nach tatsächlicher
                Zahlung bestätigen.
              </Text>
              <SwipeAction
                key={`${payment.id}:cash`}
                label="Barzahlung bestätigen"
                busy={busy && paying === 'cash'}
                disabled={busy && paying !== 'cash'}
                onComplete={() => void pay('cash', payment.id)}
              />
              <SwipeAction
                key={`${payment.id}:terminal`}
                label="Terminalzahlung bestätigen"
                busy={busy && paying === 'terminal'}
                disabled={busy && paying !== 'terminal'}
                onComplete={() => void pay('terminal', payment.id)}
              />
              <RiderRating
                key={`${payment.id}:rating`}
                token={token}
                bookingId={payment.id}
                given={givenStars(state?.ratings, payment.id)}
                completedAt={payment.completed_at}
                collapsed
              />
            </>
          )}
          {!payment && trip && !chainOffer && (
            <>
              <Text style={s.eyebrow}>
                {driverStatus(trip.status).toUpperCase()}
              </Text>
              <Text style={s.title}>{trip.rider_name || 'Dein Fahrgast'}</Text>
              {!!waiting && (
                <Text style={s.detail}>
                  Danach: Abholung {waiting.route.pickup.label}
                </Text>
              )}
              {!!riderRatingOf(state?.riderRatings, trip.id) && (
                <Text
                  style={s.detail}
                  accessibilityLabel={ratingLabel(
                    riderRatingOf(state?.riderRatings, trip.id),
                  )}
                >
                  {ratingText(riderRatingOf(state?.riderRatings, trip.id))}
                </Text>
              )}
              <Text style={s.heading}>
                {trip.status === 'riding'
                  ? trip.route.destination.label
                  : trip.route.pickup.label}
              </Text>
              <Text style={s.detail}>
                Ziel: {trip.route.destination.label}
              </Text>
              {!!destinationChangeNote(trip.route) && (
                <Text style={s.detail}>{destinationChangeNote(trip.route)}</Text>
              )}
              {trip.rider_phone && (
                <Pressable
                  style={s.row}
                  onPress={() =>
                    void Linking.openURL(
                      `tel:${trip.rider_phone!.replace(/[^+\d]/g, '')}`,
                    ).catch(() =>
                      setError(
                        'Die Telefon-App konnte nicht geöffnet werden. Bitte die Nummer über dein Telefon wählen.',
                      ),
                    )
                  }
                >
                  <Phone color={gold} size={21} />
                  <Text style={s.heading}>Fahrgast anrufen</Text>
                </Pressable>
              )}
              <RideChat
                token={token}
                bookingId={trip.id}
                active={['accepted', 'arrived', 'riding'].includes(trip.status)}
                title="Nachrichten mit dem Fahrgast"
                label="Nachricht an Fahrgast"
                onIncoming={(text) => {
                  setChatNotice(text);
                  void driverNotice(
                    'luxore-chat',
                    'Nachricht vom Fahrgast',
                    text,
                  );
                }}
              />
              {preferenceLabels(trip.rider_preferences).length > 0 && (
                <Text style={s.detail}>
                  Fahrtwünsche:{' '}
                  {preferenceLabels(trip.rider_preferences).join(' · ')}
                </Text>
              )}
              {prefs.provider !== 'standard' && (
                <Button
                  title="Navigation öffnen"
                  onPress={() => {
                    const target =
                      trip.status === 'riding'
                        ? trip.route.destination
                        : trip.route.pickup;
                    const url = navigationUrl(prefs.provider, target);
                    if (url)
                      void Linking.openURL(url).catch(() =>
                        setError('Navigation nicht verfügbar.'),
                      );
                  }}
                />
              )}
              {menu
                .filter((item) => trip.refreshments?.requested[item.id])
                .map((item) => (
                  <View key={item.id} style={s.order}>
                    <Text style={s.heading}>
                      {trip.refreshments!.requested[item.id]} × {item.name}
                    </Text>
                    <SwipeAction
                      label="Übergabe bestätigen"
                      busy={busy}
                      onComplete={() =>
                        void perform('refreshments', {
                          action: 'deliver',
                          id: trip.id,
                          revision: trip.refreshments!.revision,
                          itemId: item.id,
                          quantity: trip.refreshments!.requested[item.id],
                        })
                      }
                    />
                    <Pressable
                      hitSlop={8}
                      disabled={busy}
                      onPress={() =>
                        void perform('refreshments', {
                          action: 'unavailable',
                          id: trip.id,
                          revision: trip.refreshments!.revision,
                          itemId: item.id,
                          quantity: trip.refreshments!.requested[item.id],
                        })
                      }
                    >
                      <Text style={s.link}>Artikel nicht verfügbar</Text>
                    </Pressable>
                  </View>
                ))}
              {driverNext[trip.status] && (
                <SwipeAction
                  key={`${trip.id}:${trip.status}`}
                  label={
                    trip.status === 'accepted'
                      ? 'Am Abholort angekommen'
                      : trip.status === 'arrived'
                        ? 'Fahrt starten'
                        : 'Fahrt abschließen'
                  }
                  busy={busy}
                  onComplete={() => {
                    const body = {
                      action: 'status',
                      id: trip.id,
                      from: trip.status,
                      status: driverNext[trip.status],
                    };
                    void perform('driver', body, () => navigate(body, trip));
                  }}
                />
              )}
            </>
          )}
          {!payment && offer && (!trip || chainOffer) && (
            <>
              <Text style={s.eyebrow}>
                {chainOffer ? 'ANSCHLUSSFAHRT' : 'NEUE FAHRT'} ·{' '}
                {clockTime(offer.expires_at - clock - offset)}
              </Text>
              <Text style={s.title}>{euros(offer.booking.price)}</Text>
              <Text style={s.heading}>{offer.booking.route.pickup.label}</Text>
              <Text style={s.detail}>
                → {offer.booking.route.destination.label}
              </Text>
              {offer.booking.refreshments && (
                <Text style={s.detail}>
                  Bordbestellung:{' '}
                  {cartLabel(offer.booking.refreshments.requested) ||
                    'Keine Artikel bestellt'}
                </Text>
              )}
              {preferenceLabels(offer.booking.rider_preferences).length > 0 && (
                <Text style={s.detail}>
                  Fahrtwünsche:{' '}
                  {preferenceLabels(offer.booking.rider_preferences).join(
                    ' · ',
                  )}
                </Text>
              )}
              <SwipeAction
                key={offer.id}
                label="Fahrt annehmen"
                busy={busy}
                disabled={offer.expires_at <= clock + offset}
                onComplete={() =>
                  void perform(
                    'driver',
                    { action: 'accept', offerId: offer.id },
                    async () => {
                      // Answered: the phone stops ringing at once.
                      await offerAlerts.clear().catch(() => {});
                      // The running ride keeps its navigation.
                      if (!chainOffer)
                        await navigate({ action: 'accept' }, offer.booking);
                    },
                  )
                }
              />
              <Pressable
                hitSlop={8}
                disabled={busy}
                onPress={() =>
                  void perform(
                    'driver',
                    { action: 'reject', offerId: offer.id },
                    () => offerAlerts.clear().catch(() => {}),
                  )
                }
              >
                <Text style={s.link}>Angebot ablehnen</Text>
              </Pressable>
            </>
          )}
          {state?.driver?.approved && !payment && !trip && !offer && (
            <>
              <Text style={s.title}>
                {shift === 'online'
                  ? 'Deine nächste\nFahrt wartet.'
                  : 'Bereit für\ndeinen Tag.'}
              </Text>
              <Text style={s.detail}>
                {shift === 'online'
                  ? 'Neue Fahrtangebote erscheinen direkt hier.'
                  : 'Wähle dein Fahrzeug und starte deine Schicht.'}
              </Text>
              {flow ? (
                <View style={s.warning}>
                  <Text accessibilityLiveRegion="polite" style={s.eyebrow}>
                    {flow.ending
                      ? 'VORGANG WIRD BEENDET'
                      : `${flow.offline ? 'PAUSE' : 'ONLINE GEHEN'} · SCHRITT ${flow.step}/${(flow.offline ? offlineSteps : onlineSteps).length}`}
                  </Text>
                  <View style={s.sheetHeader}>
                    <ActivityIndicator color={gold} />
                    <View style={s.flex}>
                      <Text style={s.heading}>
                        {flow.ending
                          ? 'Einen Moment …'
                          : (flow.offline ? offlineSteps : onlineSteps)[
                              flow.step - 1
                            ].title}
                      </Text>
                      <Text style={s.detail}>
                        {flow.ending
                          ? 'Standortdienst und Anmeldung werden sauber beendet. Das dauert höchstens eine Minute.'
                          : (flow.offline ? offlineSteps : onlineSteps)[
                              flow.step - 1
                            ].hint}
                      </Text>
                    </View>
                  </View>
                  {!flow.offline && !flow.ending && (
                    <Pressable
                      hitSlop={8}
                      accessibilityRole="button"
                      onPress={() => flowAbort.current?.abort()}
                    >
                      <Text style={s.link}>Abbrechen</Text>
                    </Pressable>
                  )}
                </View>
              ) : (
                <Button
                  title={
                    busy
                      ? 'Schicht wird geprüft …'
                      : gps.sessionId || state.driver.session_id
                        ? 'Pause machen'
                        : 'Online gehen'
                  }
                  busy={busy}
                  onPress={() => void toggleShift()}
                />
              )}
              {shiftIssue && !flow && (
                <View style={s.warning}>
                  <Text accessibilityRole="alert" style={s.error}>
                    {shiftIssue.message}
                  </Text>
                  {shiftIssue.reasons?.map((reason) => (
                    <View key={reason} style={s.reason}>
                      <Text style={s.error}>•</Text>
                      <Text style={[s.error, s.flex]}>{reason}</Text>
                    </View>
                  ))}
                  {!!shiftIssue.reasons && !!onCompliance && (
                    <Pressable
                      hitSlop={8}
                      accessibilityRole="button"
                      onPress={onCompliance}
                    >
                      <Text style={s.link}>Zum Prüf-Bereich</Text>
                    </Pressable>
                  )}
                  {shiftIssue.settings && (
                    <>
                      <Text style={s.detail}>
                        {platformText.backgroundHowTo}
                      </Text>
                      <Pressable
                        hitSlop={8}
                        accessibilityRole="button"
                        onPress={() => void Linking.openSettings().catch(() => {})}
                      >
                        <Text style={s.link}>Einstellungen öffnen</Text>
                      </Pressable>
                    </>
                  )}
                  <Pressable
                    hitSlop={8}
                    accessibilityRole="button"
                    disabled={busy}
                    onPress={() => void toggleShift()}
                  >
                    <Text style={s.link}>Erneut versuchen</Text>
                  </Pressable>
                </View>
              )}
            </>
          )}
          {state?.driver?.approved && !!onCompliance && (
            <ShiftReadiness
              token={token}
              active={active}
              refreshKey={`${state.driver.vehicle_id || ''}:${shiftIssue?.message || ''}`}
              onOpen={onCompliance}
            />
          )}
          {state?.driver?.approved && !!onReservations && (
            <ReservationsEntry
              token={token}
              active={active}
              refreshKey={state.driver.vehicle_id || ''}
              onOpen={onReservations}
            />
          )}
          {state?.driver?.approved && (
            <Pressable style={s.row} onPress={() => setModal('vehicle')}>
              <CarFront color={gold} size={22} />
              <View style={s.flex}>
                <Text style={s.heading}>Fahrzeug wechseln</Text>
                <Text style={s.detail}>
                  {state.fleet?.name || 'Noch keiner Flotte zugeordnet'}
                </Text>
              </View>
            </Pressable>
          )}
          {state?.driver?.vehicle_id && (
            <Pressable
              style={s.row}
              onPress={() => onInventory(state.driver!.vehicle_id!)}
            >
              <CarFront color={gold} size={22} />
              <View style={s.flex}>
                <Text style={s.heading}>
                  {state.inventory?.urgent
                    ? 'Bitte einkaufen gehen'
                    : 'Bordbestand & Einkauf'}
                </Text>
                <Text style={s.detail}>
                  {state.inventory?.initialized
                    ? `${state.inventory.missing} Artikel bis zum Sollbestand`
                    : 'Gezählten Anfangsbestand erfassen'}
                </Text>
              </View>
            </Pressable>
          )}
          <View style={s.footer}>
            <Text style={s.small}>
              {gps.position && clock - gps.position.timestamp < 15000
                ? `GPS · ± ${Math.round(gps.position.accuracy)} m`
                : 'GPS · wartet auf frischen Standort'}
              {gps.sessionId ? ' · Hintergrunddienst aktiv' : ''}
            </Text>
            <Pressable
              hitSlop={14}
              accessibilityLabel="Notruf 112 öffnen"
              onPress={() => void Linking.openURL('tel:112').catch(() => {})}
            >
              <ShieldCheck color={gold} size={21} />
            </Pressable>
          </View>
        </ScrollView>
      </Animated.View>
      <Modal
        visible={!!modal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setModal(null)}
      >
        <View style={s.modal}>
          <View style={s.modalHeader}>
            <Text style={s.title}>
              {modal === 'vehicle' ? 'Dein Fahrzeug.' : 'Dein Tag.'}
            </Text>
            <Pressable
              hitSlop={12}
              accessibilityLabel="Schließen"
              onPress={() => setModal(null)}
            >
              <X color={ink} size={24} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={s.modalContent}>
            {modal === 'vehicle' ? (
              <>
                <Text style={s.detail}>
                  Ein Fahrzeug gehört zu genau einer Flotte. Wechsel ist nur
                  offline, nach Fahrtabschluss und Kassieren möglich.
                </Text>
                {state?.vehicles?.map((vehicle) => (
                  <Pressable
                    key={vehicle.id}
                    disabled={
                      busy || !canSelectVehicle(state, vehicle, gps.sessionId)
                    }
                    style={[
                      s.row,
                      vehicle.id === state.driver?.vehicle_id && s.selected,
                    ]}
                    onPress={() =>
                      void perform(
                        'vehicles',
                        { action: 'select', vehicleId: vehicle.id },
                        async () => {
                          setModal(null);
                        },
                      )
                    }
                  >
                    <CarFront color={gold} size={27} />
                    <View style={s.flex}>
                      <Text style={s.heading}>{vehicle.model}</Text>
                      <Text style={s.detail}>
                        {vehicle.plate} ·{' '}
                        {vehicle.driver_id &&
                        vehicle.driver_id !== state.driver?.id
                          ? `${vehicle.driver_name || 'Anderer Fahrer'} · belegt`
                          : vehicle.id === state.driver?.vehicle_id
                            ? 'Dein Fahrzeug'
                            : 'Frei'}
                      </Text>
                    </View>
                  </Pressable>
                ))}
                <Button
                  title="Flotte verwalten"
                  onPress={() => {
                    setModal(null);
                    onFleet();
                  }}
                />
              </>
            ) : (
              <>
                <Text style={s.amount}>{euros(state?.today?.gross || 0)}</Text>
                <Text style={s.detail}>
                  {state?.today?.trips || 0} Fahrten heute ·{' '}
                  {euros(state?.today?.collected || 0)} kassiert ·{' '}
                  {euros(state?.today?.outstanding || 0)} offen
                </Text>
                {!!onEarnings && (
                  <Button
                    title="Meine Einnahmen – heute, Woche, Monat"
                    onPress={() => {
                      setModal(null);
                      onEarnings();
                    }}
                  />
                )}
                <Text style={s.heading}>Letzte Fahrten</Text>
                {state?.history?.map((booking) => (
                  <View key={booking.id} style={s.row}>
                    <View style={s.flex}>
                      <Text style={s.heading}>
                        {booking.route.destination.label}
                      </Text>
                      <Text style={s.detail}>
                        {new Date(
                          booking.completed_at || booking.updated_at,
                        ).toLocaleString('de-DE')}{' '}
                        ·{' '}
                        {booking.payment_status === 'paid'
                          ? 'Bezahlt'
                          : 'Zahlung offen'}
                      </Text>
                      {booking.status === 'completed' && (
                        <RiderRating
                          token={token}
                          bookingId={booking.id}
                          given={givenStars(state?.ratings, booking.id)}
                          completedAt={booking.completed_at}
                          collapsed
                        />
                      )}
                    </View>
                    <Text style={s.heading}>{euros(booking.price)}</Text>
                  </View>
                ))}
              </>
            )}
            {!!error && <Text style={s.error}>{error}</Text>}
            <Pressable onPress={() => void refresh()} style={s.row}>
              <RefreshCw color={gold} size={21} />
              <Text style={s.link}>Aktualisieren</Text>
            </Pressable>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}
function Button({
  title,
  busy,
  onPress,
}: {
  title: string;
  busy?: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      disabled={busy}
      style={[s.button, busy && { opacity: 0.6 }]}
      onPress={onPress}
    >
      {busy ? (
        <ActivityIndicator color={colors.white} />
      ) : (
        <Text style={s.buttonText}>{title}</Text>
      )}
    </Pressable>
  );
}
const ink = colors.ink,
  gold = colors.gold;
const s = StyleSheet.create({
  root: { flex: 1, overflow: 'hidden', backgroundColor: colors.sand },
  flex: { flex: 1 },
  top: { position: 'absolute', top: 14, left: 18, right: 18, gap: space[3] },
  revenue: {
    alignSelf: 'center',
    borderRadius: radii.pill,
    paddingHorizontal: space[5],
    paddingVertical: space[3],
    backgroundColor: colors.white,
    flexDirection: 'row',
    gap: space[3],
    alignItems: 'center',
    elevation: 3,
  },
  revenueText: { ...typography.title2, fontVariant: ['tabular-nums'], color: ink },
  eyebrow: { color: colors.goldText, ...typography.label },
  title: {
    color: ink,
    ...typography.title1,
  },
  heading: { color: ink, ...typography.subhead, fontWeight: '600' },
  detail: { color: colors.gray, ...typography.footnote },
  small: { color: colors.gray, ...typography.footnote, flex: 1 },
  sheet: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    borderTopLeftRadius: radii.xl,
    borderTopRightRadius: radii.xl,
    backgroundColor: colors.white,
    elevation: 8,
  },
  handleArea: { height: 105, paddingTop: space[3], paddingHorizontal: layout.screenMargin },
  handle: {
    width: 36,
    height: 4,
    borderRadius: radii.pill,
    backgroundColor: colors.goldLight,
    alignSelf: 'center',
    marginBottom: space[4],
  },
  sheetHeader: { flexDirection: 'row', gap: space[4], alignItems: 'center' },
  sheetContent: { padding: layout.screenMargin, paddingTop: space[3], gap: space[4], paddingBottom: space[6] },
  row: {
    flexDirection: 'row',
    gap: space[4],
    alignItems: 'center',
    paddingVertical: space[4],
    paddingHorizontal: space[1],
    borderRadius: radii.m,
  },
  selected: { backgroundColor: colors.paper, paddingHorizontal: space[4] },
  button: {
    backgroundColor: ink,
    borderRadius: radii.l,
    padding: 20,
    alignItems: 'center',
    minHeight: 60,
  },
  buttonText: { color: colors.white, ...typography.headline },
  warning: { backgroundColor: colors.paper, padding: space[4], borderRadius: radii.l },
  error: { color: colors.danger, ...typography.footnote },
  reason: { flexDirection: 'row', gap: space[2] },
  link: { color: colors.goldText, ...typography.footnote, fontWeight: '600', paddingVertical: space[2] },
  footer: {
    flexDirection: 'row',
    gap: space[3],
    alignItems: 'center',
    paddingTop: space[1],
  },
  order: { padding: space[4], backgroundColor: colors.paper, borderRadius: radii.l, gap: space[3] },
  guidance: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: ink,
    borderRadius: radii.l,
    paddingVertical: space[4],
    paddingHorizontal: space[5],
    gap: space[4],
    elevation: 4,
  },
  // Readable at arm's length while driving, like any navigation app.
  turnDistance: {
    color: colors.white,
    fontSize: 40,
    lineHeight: 46,
    fontWeight: '700',
    fontVariant: ['tabular-nums'],
  },
  turnText: { color: colors.white, fontSize: 21, lineHeight: 27, fontWeight: '600' },
  lanes: { flexDirection: 'row', gap: 4, marginTop: 8 },
  lane: {
    width: 30,
    height: 34,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffffff1f',
  },
  laneValid: { backgroundColor: colors.white },
  laneGlyph: { color: '#ffffff80', fontSize: 20, fontWeight: '700' },
  laneGlyphValid: { color: colors.ink },
  turnRest: { color: '#c9ccd1', fontSize: 15, lineHeight: 20, marginTop: 2 },
  notice: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.gold,
    borderRadius: radii.l,
    padding: space[4],
    gap: space[3],
    elevation: 4,
  },
  noticeTitle: { color: ink, ...typography.headline },
  noticeText: { color: ink, ...typography.body },
  noticeAction: { color: ink, ...typography.subhead, fontWeight: '700' },
  modal: { flex: 1, paddingTop: space[5], backgroundColor: colors.white },
  modalHeader: {
    padding: layout.screenMargin,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  modalContent: { padding: layout.screenMargin, paddingTop: 0, gap: space[4], paddingBottom: 40 },
  amount: { ...typography.largeTitle, fontVariant: ['tabular-nums'], color: ink },
  settings: { padding: layout.screenMargin, paddingBottom: 40, gap: space[4] },
});
