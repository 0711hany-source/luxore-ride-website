import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  Linking,
  Modal,
  PanResponder,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from 'react-native';
import * as SecureStore from 'expo-secure-store';
import {
  CarFront,
  ChevronDown,
  LocateFixed,
  Navigation,
  Phone,
  RefreshCw,
  ShieldCheck,
  X,
} from 'lucide-react-native';
import { nativeApi, type NativeAccount } from './account-client';
import {
  type Credential,
  foregroundPermission,
  startLocation,
  stopLocation,
} from './location-service';
import { useDriverGps } from './use-driver-gps';
import {
  canSelectVehicle,
  euros,
  liveOffer,
  shiftLocked,
  shiftState,
  type DriverState,
} from './driver-model';
import type { Booking, RouteData } from '../../lib/mobility/domain';
import { driverNext, statusNames } from '../../lib/mobility/domain';
import { menu, cartLabel } from '../../lib/mobility/refreshments';
import { preferenceLabels } from '../../lib/mobility/ride-preferences';
import {
  advanceNavigation,
  compileNavigation,
  navigationDistance,
  type NavigationProgress,
} from '../../app/mobility/navigation-progress';
import {
  defaultNavigation,
  navigationProviders,
  navigationTarget,
  navigationUrl,
  parseNavigation,
  type NavigationPreferences,
} from '../../app/mobility/navigation-preferences';
import DriverMap from './DriverMap';
import SwipeAction from './SwipeAction';

const preferencesKey = 'luxore-native-navigation-v1';
export default function DriverScreen({
  token,
  profile,
  active,
  settings,
  onFleet,
  onInventory,
}: {
  token: string;
  profile: NativeAccount;
  active: boolean;
  settings: boolean;
  onFleet: () => void;
  onInventory: (vehicleId?: string) => void;
}) {
  'use no memo'; // Native gesture/camera commands use mutable imperative handles.
  const gps = useDriverGps();
  const [state, setState] = useState<DriverState | null>(null);
  const [mapToken, setMapToken] = useState('');
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [modal, setModal] = useState<'vehicle' | 'revenue' | null>(null);
  const [connectionError, setConnectionError] = useState('');
  const [guidance, setGuidance] = useState<{
    key: string;
    route: RouteData;
  } | null>(null);
  const [progress, setProgress] = useState<NavigationProgress | null>(null);
  const [prefs, setPrefs] = useState<NavigationPreferences>(defaultNavigation);
  const [clock, setClock] = useState(() => Date.now());
  const [collapsed, setCollapsed] = useState(false);
  const height = Math.min(500, useWindowDimensions().height * 0.61);
  const [drag] = useState(() => new Animated.Value(0));
  const bottom = useRef(0);
  useEffect(() => {
    bottom.current = height - 105;
  }, [height]);
  const collapsedRef = useRef(false);
  const [offset, setOffset] = useState(0);
  const locked = useRef(false),
    pollBusy = useRef(false),
    generation = useRef(0),
    alive = useRef(true);
  const gpsRef = useRef(gps),
    phaseRef = useRef('');
  useEffect(() => {
    gpsRef.current = gps;
  }, [gps]);
  const invalidate = useCallback(() => {
    alive.current = false;
    generation.current++;
  }, []);
  const loadMapConfig = useCallback(async () => {
    try {
      const config = await nativeApi<{ publicMapToken?: string }>(
        'config',
        token,
      );
      if (alive.current) setMapToken(config.publicMapToken || '');
    } catch {
      /* GPS and shift actions remain available without map tiles. */
    }
  }, [token]);
  const refresh = useCallback(async () => {
    if (pollBusy.current) return;
    pollBusy.current = true;
    const current = generation.current;
    try {
      const data = await nativeApi<DriverState>('driver', token);
      if (!alive.current || current !== generation.current) return;
      if (data.serverTime) setOffset(data.serverTime - Date.now());
      setState(data);
      setConnectionError('');
    } catch (e) {
      if (alive.current && current === generation.current)
        setConnectionError((e as Error).message);
    } finally {
      if (current === generation.current) pollBusy.current = false;
    }
  }, [token]);
  useEffect(() => {
    alive.current = true;
    void Promise.resolve().then(refresh);
    void Promise.resolve().then(loadMapConfig);
    void SecureStore.getItemAsync(preferencesKey)
      .then((raw) => {
        if (alive.current && raw) setPrefs(parseNavigation(JSON.parse(raw)));
      })
      .catch(() => {});
    return invalidate;
  }, [token, refresh, invalidate, loadMapConfig]);
  useEffect(() => {
    if (!gps.foreground) return;
    void Promise.resolve().then(refresh);
    const poll = setInterval(() => void refresh(), 5000);
    const timer = setInterval(() => setClock(Date.now()), 1000);
    return () => {
      clearInterval(poll);
      clearInterval(timer);
    };
  }, [gps.foreground, refresh]);
  const trip = state?.bookings[0] || null;
  const phase = trip ? `${trip.id}:${trip.status}` : '';
  const tripId = trip?.id,
    tripStatus = trip?.status;
  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);
  const route =
    guidance?.key === phase
      ? guidance.route
      : trip?.status === 'riding'
        ? trip.route
        : null;
  const guidanceBusy = useRef(false),
    guidanceAttempt = useRef(-Infinity);
  useEffect(() => {
    if (
      !active ||
      !gps.foreground ||
      !tripId ||
      !tripStatus ||
      !['accepted', 'riding'].includes(tripStatus)
    )
      return;
    let cancelled = false;
    const request = async () => {
      const fix = gpsRef.current.position;
      if (
        !fix ||
        fix.accuracy > 50 ||
        Date.now() - fix.timestamp > 10000 ||
        guidanceBusy.current ||
        Date.now() - guidanceAttempt.current < 20000
      )
        return;
      guidanceBusy.current = true;
      guidanceAttempt.current = Date.now();
      try {
        const result = await nativeApi<{
          bookingId: string;
          phase: string;
          route: RouteData;
        }>('guidance', token, { bookingId: tripId, position: fix });
        if (
          !cancelled &&
          phaseRef.current === `${result.bookingId}:${result.phase}`
        )
          setGuidance({ key: phase, route: result.route });
      } catch {
        /* Route failure never ends the shift or changes the agreed fare. */
      } finally {
        guidanceBusy.current = false;
      }
    };
    void request();
    const timer = setInterval(() => void request(), 25000);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [phase, tripId, tripStatus, active, gps.foreground, token]);
  const trackRef = useRef(compileNavigation(null));
  useEffect(() => {
    trackRef.current = compileNavigation(route);
  }, [route]);
  useEffect(() => {
    const track = trackRef.current;
    if (track && gps.position)
      setProgress((previous) =>
        advanceNavigation(track, gps.position!, Date.now(), previous),
      );
  }, [gps.position, route]);
  const shift = shiftState(state, gps.sessionId, gps.position, clock);
  const offer = liveOffer(state, clock + offset);
  const payment = state?.payments?.[0];
  async function navigate(
    action: { action?: string; status?: string },
    booking?: Booking | null,
  ) {
    const target = navigationTarget(action, booking?.route);
    const url =
      target && prefs.autoStart ? navigationUrl(prefs.provider, target) : null;
    if (url)
      await Linking.openURL(url).catch(() =>
        setError(
          'Die ausgewählte Navigation konnte nicht geöffnet werden. Bitte die App installieren oder Standard wählen.',
        ),
      );
  }
  async function perform(
    path: string,
    body: object,
    onSuccess?: () => Promise<void>,
  ) {
    if (locked.current) return;
    locked.current = true;
    setBusy(true);
    setError('');
    generation.current++;
    try {
      await nativeApi(path, token, body);
      if (onSuccess) await onSuccess();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      locked.current = false;
      setBusy(false);
      // Do not let an old GET overwrite a confirmed action.
      pollBusy.current = false;
      await refresh();
    }
  }
  async function toggleShift() {
    if (locked.current) return;
    locked.current = true;
    setBusy(true);
    setError('');
    generation.current++;
    let started: Credential | null = null;
    try {
      if (gps.sessionId || state?.driver?.session_id) {
        if (shiftLocked(state))
          throw new Error(
            'Bitte die Fahrt abschließen und den offenen Betrag kassieren, bevor du die Schicht beendest.',
          );
        const sessionId = gps.sessionId || state!.driver!.session_id;
        await stopLocation();
        await nativeApi('driver', token, { action: 'offline', sessionId });
      } else {
        await foregroundPermission();
        const fix = gpsRef.current.position;
        if (!fix || clock - fix.timestamp > 15000 || fix.accuracy > 100) {
          void gps.restart();
          throw new Error(
            'GPS sucht deinen genauen Standort. Bitte kurz im Freien warten und erneut online gehen.',
          );
        }
        started = await nativeApi<Credential>('driver', token, {
          action: 'online',
          native: true,
        });
        await startLocation(started);
      }
      await gps.sync();
    } catch (e) {
      if (started) {
        await stopLocation();
        await nativeApi('driver', token, {
          action: 'offline',
          sessionId: started.sessionId,
        }).catch(() => {});
        await gps.sync().catch(() => {});
      }
      setError((e as Error).message);
    } finally {
      locked.current = false;
      setBusy(false);
      pollBusy.current = false;
      await refresh();
    }
  }
  function slide(value: boolean) {
    collapsedRef.current = value;
    setCollapsed(value);
    Animated.spring(drag, {
      toValue: value ? bottom.current : 0,
      useNativeDriver: true,
      bounciness: 0,
    }).start();
  }
  const slideRef = useRef(slide);
  useEffect(() => {
    slideRef.current = slide;
  });
  // PanResponder stores callbacks; it does not execute the gesture refs during render.
  // oxlint-disable-next-line react/react-compiler
  const [pan] = useState(() =>
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) =>
        Math.abs(g.dy) > 6 && Math.abs(g.dy) > Math.abs(g.dx),
      onPanResponderMove: (_, g) =>
        drag.setValue(
          Math.max(
            0,
            Math.min(
              bottom.current,
              (collapsedRef.current ? bottom.current : 0) + g.dy,
            ),
          ),
        ),
      onPanResponderRelease: (_, g) =>
        slideRef.current(
          g.vy > 0.5 ||
            (g.vy > -0.5 &&
              (collapsedRef.current ? bottom.current : 0) + g.dy >
                bottom.current * 0.4),
        ),
      onPanResponderTerminate: () => slideRef.current(collapsedRef.current),
    }),
  );
  async function savePrefs(next: NavigationPreferences) {
    setPrefs(next);
    await SecureStore.setItemAsync(preferencesKey, JSON.stringify(next)).catch(
      () => setError('Navigationseinstellung konnte nicht gespeichert werden.'),
    );
  }
  if (settings)
    return (
      <ScrollView contentContainerStyle={s.settings}>
        <Text style={s.eyebrow}>DEINE NAVIGATION</Text>
        <Text style={s.title}>Immer dein Weg.</Text>
        {navigationProviders
          .filter((provider) => provider.id !== 'apple')
          .map((provider) => (
            <Pressable
              key={provider.id}
              style={[s.row, prefs.provider === provider.id && s.selected]}
              onPress={() =>
                void savePrefs({ ...prefs, provider: provider.id })
              }
            >
              <Navigation color={gold} size={24} />
              <View style={s.flex}>
                <Text style={s.heading}>{provider.name}</Text>
                <Text style={s.detail}>{provider.description}</Text>
              </View>
              <Text style={s.detail}>
                {prefs.provider === provider.id ? '✓' : ''}
              </Text>
            </Pressable>
          ))}
        <Pressable
          style={s.row}
          onPress={() =>
            void savePrefs({ ...prefs, autoStart: !prefs.autoStart })
          }
        >
          <Navigation color={gold} size={22} />
          <Text style={[s.heading, s.flex]}>
            Nach Fahrtannahme automatisch starten
          </Text>
          <Text style={s.detail}>{prefs.autoStart ? 'An' : 'Aus'}</Text>
        </Pressable>
        <Text style={s.detail}>
          Der native Standortdienst läuft während deiner gestarteten Schicht
          auch beim Wechsel zu Waze oder Google Maps. Android muss Standort
          „Immer zulassen“ erlauben. Ein erzwungenes Beenden oder entzogene
          Berechtigungen unterbrechen den Dienst.
        </Text>
        <Pressable style={s.row} onPress={() => void Linking.openSettings()}>
          <LocateFixed color={gold} size={22} />
          <Text style={s.heading}>Android-Berechtigungen öffnen</Text>
        </Pressable>
        {!!error && <Text style={s.error}>{error}</Text>}
      </ScrollView>
    );
  return (
    <View style={s.root}>
      {active && gps.foreground && (
        <DriverMap
          token={mapToken}
          position={gps.position}
          route={route}
          active
        />
      )}
      <View pointerEvents="box-none" style={s.top}>
        <Pressable style={s.revenue} onPress={() => setModal('revenue')}>
          <Text style={s.eyebrow}>HEUTE</Text>
          <Text style={s.revenueText}>{euros(state?.today?.gross || 0)}</Text>
        </Pressable>
        {progress && clock - progress.fix.timestamp < 10000 && (
          <View style={s.guidance}>
            <Navigation color={gold} size={25} />
            <View style={s.flex}>
              <Text style={s.heading}>
                {navigationDistance(progress.distanceToTurn)}
              </Text>
              <Text style={s.detail}>{progress.next.instruction}</Text>
            </View>
          </View>
        )}
      </View>
      <Animated.View
        style={[s.sheet, { height, transform: [{ translateY: drag }] }]}
      >
        <View {...pan.panHandlers} style={s.handleArea}>
          <View style={s.handle} />
          <View style={s.sheetHeader}>
            <View style={s.flex}>
              <Text style={s.heading}>
                {shift === 'online'
                  ? 'Online · bereit für Anfragen'
                  : shift === 'gps'
                    ? 'GPS wird aktualisiert'
                    : shift === 'connecting'
                      ? 'Verbindung wird geprüft'
                      : shift === 'pending'
                        ? 'Freigabe ausstehend'
                        : 'Deine Schicht'}
              </Text>
              <Text style={s.detail}>
                {state?.driver?.vehicle || 'Fahrzeug auswählen'}{' '}
                {state?.driver?.plate ? `· ${state.driver.plate}` : ''}
              </Text>
            </View>
            <Pressable
              accessibilityLabel={
                collapsed ? 'Fahrtübersicht ausklappen' : 'Mehr Karte anzeigen'
              }
              onPress={() => slide(!collapsed)}
            >
              <ChevronDown
                color={ink}
                style={{
                  transform: [{ rotate: collapsed ? '180deg' : '0deg' }],
                }}
                size={25}
              />
            </Pressable>
          </View>
        </View>
        <ScrollView
          contentContainerStyle={s.sheetContent}
          showsVerticalScrollIndicator={false}
        >
          {!state && <ActivityIndicator color={gold} />}
          {(error || connectionError || gps.error) && (
            <View style={s.warning}>
              <Text accessibilityRole="alert" style={s.error}>
                {error || connectionError || gps.error}
              </Text>
              <Pressable
                onPress={() => {
                  setError('');
                  void Promise.resolve().then(refresh);
                  void Promise.resolve().then(loadMapConfig);
                  void gps.restart();
                }}
              >
                <Text style={s.link}>Verbindung & GPS erneut prüfen</Text>
              </Pressable>
            </View>
          )}
          {state && !state.driver && (
            <>
              <Text style={s.title}>Dein Fahrerprofil.</Text>
              <Text style={s.detail}>
                Dein Konto ist angemeldet. Für Fahrtangebote benötigst du ein
                Fahrerprofil und die Freigabe deiner Disposition.
              </Text>
              <Button
                title="Fahrerprofil anlegen"
                busy={busy}
                onPress={() =>
                  void perform('driver', {
                    action: 'register',
                    name: profile.name,
                    phone: profile.phone,
                  })
                }
              />
            </>
          )}
          {state?.driver && !state.driver.approved && (
            <>
              <Text style={s.title}>Fast bereit.</Text>
              <Text style={s.detail}>
                Die Disposition muss dein Fahrerprofil freigeben und dich einer
                Flotte zuordnen.
              </Text>
              <Button title="Flotte & Team" onPress={onFleet} />
            </>
          )}
          {payment && (
            <>
              <Text style={s.eyebrow}>FAHRT ABGESCHLOSSEN</Text>
              <Text style={s.title}>{euros(payment.price)}</Text>
              <Text style={s.detail}>
                Diesen Betrag vom Fahrgast kassieren. Erst nach tatsächlicher
                Zahlung bestätigen.
              </Text>
              <SwipeAction
                key={`${payment.id}:cash`}
                label="Barzahlung bestätigen"
                busy={busy}
                onComplete={() =>
                  void perform('payments', { id: payment.id, method: 'cash' })
                }
              />
              <SwipeAction
                key={`${payment.id}:terminal`}
                label="Terminalzahlung bestätigen"
                busy={busy}
                onComplete={() =>
                  void perform('payments', {
                    id: payment.id,
                    method: 'terminal',
                  })
                }
              />
            </>
          )}
          {!payment && trip && (
            <>
              <Text style={s.eyebrow}>
                {statusNames[trip.status].toUpperCase()}
              </Text>
              <Text style={s.title}>{trip.rider_name || 'Dein Fahrgast'}</Text>
              <Text style={s.heading}>
                {trip.status === 'riding'
                  ? trip.route.destination.label
                  : trip.route.pickup.label}
              </Text>
              <Text style={s.detail}>
                Ziel: {trip.route.destination.label} · {euros(trip.price)}
              </Text>
              {trip.rider_phone && (
                <Pressable
                  style={s.row}
                  onPress={() =>
                    void Linking.openURL(
                      `tel:${trip.rider_phone!.replace(/[^+\d]/g, '')}`,
                    )
                  }
                >
                  <Phone color={gold} size={21} />
                  <Text style={s.heading}>Fahrgast anrufen</Text>
                </Pressable>
              )}
              {preferenceLabels(trip.rider_preferences).length > 0 && (
                <Text style={s.detail}>
                  Fahrtwünsche:{' '}
                  {preferenceLabels(trip.rider_preferences).join(' · ')}
                </Text>
              )}
              {prefs.provider !== 'standard' && (
                <Button
                  title="Navigation öffnen"
                  onPress={() => {
                    const target =
                      trip.status === 'riding'
                        ? trip.route.destination
                        : trip.route.pickup;
                    const url = navigationUrl(prefs.provider, target);
                    if (url)
                      void Linking.openURL(url).catch(() =>
                        setError('Navigation nicht verfügbar.'),
                      );
                  }}
                />
              )}
              {menu
                .filter((item) => trip.refreshments?.requested[item.id])
                .map((item) => (
                  <View key={item.id} style={s.order}>
                    <Text style={s.heading}>
                      {trip.refreshments!.requested[item.id]} × {item.name}
                    </Text>
                    <SwipeAction
                      label="Übergabe bestätigen"
                      busy={busy}
                      onComplete={() =>
                        void perform('refreshments', {
                          action: 'deliver',
                          id: trip.id,
                          revision: trip.refreshments!.revision,
                          itemId: item.id,
                          quantity: trip.refreshments!.requested[item.id],
                        })
                      }
                    />
                    <Pressable
                      disabled={busy}
                      onPress={() =>
                        void perform('refreshments', {
                          action: 'unavailable',
                          id: trip.id,
                          revision: trip.refreshments!.revision,
                          itemId: item.id,
                          quantity: trip.refreshments!.requested[item.id],
                        })
                      }
                    >
                      <Text style={s.link}>Artikel nicht verfügbar</Text>
                    </Pressable>
                  </View>
                ))}
              {driverNext[trip.status] && (
                <SwipeAction
                  key={`${trip.id}:${trip.status}`}
                  label={
                    trip.status === 'accepted'
                      ? 'Am Abholort angekommen'
                      : trip.status === 'arrived'
                        ? 'Fahrt starten'
                        : 'Fahrt abschließen'
                  }
                  busy={busy}
                  onComplete={() => {
                    const body = {
                      action: 'status',
                      id: trip.id,
                      from: trip.status,
                      status: driverNext[trip.status],
                    };
                    void perform('driver', body, () => navigate(body, trip));
                  }}
                />
              )}
            </>
          )}
          {!payment && !trip && offer && (
            <>
              <Text style={s.eyebrow}>
                NEUE FAHRT ·{' '}
                {Math.max(
                  0,
                  Math.ceil((offer.expires_at - clock - offset) / 1000),
                )}{' '}
                S
              </Text>
              <Text style={s.title}>{euros(offer.booking.price)}</Text>
              <Text style={s.heading}>{offer.booking.route.pickup.label}</Text>
              <Text style={s.detail}>
                → {offer.booking.route.destination.label}
              </Text>
              {offer.booking.refreshments && (
                <Text style={s.detail}>
                  Bordbestellung:{' '}
                  {cartLabel(offer.booking.refreshments.requested) ||
                    'Keine Artikel bestellt'}
                </Text>
              )}
              {preferenceLabels(offer.booking.rider_preferences).length > 0 && (
                <Text style={s.detail}>
                  Fahrtwünsche:{' '}
                  {preferenceLabels(offer.booking.rider_preferences).join(
                    ' · ',
                  )}
                </Text>
              )}
              <SwipeAction
                key={offer.id}
                label="Fahrt annehmen"
                busy={busy}
                disabled={offer.expires_at <= clock + offset}
                onComplete={() =>
                  void perform(
                    'driver',
                    { action: 'accept', offerId: offer.id },
                    () => navigate({ action: 'accept' }, offer.booking),
                  )
                }
              />
              <Pressable
                disabled={busy}
                onPress={() =>
                  void perform('driver', {
                    action: 'reject',
                    offerId: offer.id,
                  })
                }
              >
                <Text style={s.link}>Angebot ablehnen</Text>
              </Pressable>
            </>
          )}
          {state?.driver?.approved && !payment && !trip && !offer && (
            <>
              <Text style={s.title}>
                {shift === 'online'
                  ? 'Deine nächste\nFahrt wartet.'
                  : 'Bereit für\ndeinen Tag.'}
              </Text>
              <Text style={s.detail}>
                {shift === 'online'
                  ? 'Neue Fahrtangebote erscheinen direkt hier.'
                  : 'Wähle dein Fahrzeug und starte deine Schicht.'}
              </Text>
              <Button
                title={
                  busy
                    ? 'Schicht wird geprüft …'
                    : gps.sessionId || state.driver.session_id
                      ? 'Pause machen'
                      : 'Online gehen'
                }
                busy={busy}
                onPress={() => void toggleShift()}
              />
            </>
          )}
          {state?.driver?.approved && (
            <Pressable style={s.row} onPress={() => setModal('vehicle')}>
              <CarFront color={gold} size={22} />
              <View style={s.flex}>
                <Text style={s.heading}>Fahrzeug wechseln</Text>
                <Text style={s.detail}>
                  {state.fleet?.name || 'Noch keiner Flotte zugeordnet'}
                </Text>
              </View>
            </Pressable>
          )}
          {state?.driver?.vehicle_id && (
            <Pressable
              style={s.row}
              onPress={() => onInventory(state.driver!.vehicle_id!)}
            >
              <CarFront color={gold} size={22} />
              <View style={s.flex}>
                <Text style={s.heading}>
                  {state.inventory?.urgent
                    ? 'Bitte einkaufen gehen'
                    : 'Bordbestand & Einkauf'}
                </Text>
                <Text style={s.detail}>
                  {state.inventory?.initialized
                    ? `${state.inventory.missing} Artikel bis zum Sollbestand`
                    : 'Gezählten Anfangsbestand erfassen'}
                </Text>
              </View>
            </Pressable>
          )}
          <View style={s.footer}>
            <Text style={s.small}>
              {gps.position && clock - gps.position.timestamp < 15000
                ? `GPS · ± ${Math.round(gps.position.accuracy)} m`
                : 'GPS · wartet auf frischen Standort'}
              {gps.sessionId ? ' · Hintergrunddienst aktiv' : ''}
            </Text>
            <Pressable
              accessibilityLabel="Notruf 112 öffnen"
              onPress={() => void Linking.openURL('tel:112')}
            >
              <ShieldCheck color={gold} size={21} />
            </Pressable>
          </View>
        </ScrollView>
      </Animated.View>
      <Modal
        visible={!!modal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setModal(null)}
      >
        <View style={s.modal}>
          <View style={s.modalHeader}>
            <Text style={s.title}>
              {modal === 'vehicle' ? 'Dein Fahrzeug.' : 'Dein Tag.'}
            </Text>
            <Pressable
              accessibilityLabel="Schließen"
              onPress={() => setModal(null)}
            >
              <X color={ink} size={24} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={s.modalContent}>
            {modal === 'vehicle' ? (
              <>
                <Text style={s.detail}>
                  Ein Fahrzeug gehört zu genau einer Flotte. Wechsel ist nur
                  offline, nach Fahrtabschluss und Kassieren möglich.
                </Text>
                {state?.vehicles?.map((vehicle) => (
                  <Pressable
                    key={vehicle.id}
                    disabled={
                      busy || !canSelectVehicle(state, vehicle, gps.sessionId)
                    }
                    style={[
                      s.row,
                      vehicle.id === state.driver?.vehicle_id && s.selected,
                    ]}
                    onPress={() =>
                      void perform(
                        'vehicles',
                        { action: 'select', vehicleId: vehicle.id },
                        async () => {
                          setModal(null);
                        },
                      )
                    }
                  >
                    <CarFront color={gold} size={27} />
                    <View style={s.flex}>
                      <Text style={s.heading}>{vehicle.model}</Text>
                      <Text style={s.detail}>
                        {vehicle.plate} ·{' '}
                        {vehicle.driver_id &&
                        vehicle.driver_id !== state.driver?.id
                          ? `${vehicle.driver_name || 'Anderer Fahrer'} · belegt`
                          : vehicle.id === state.driver?.vehicle_id
                            ? 'Dein Fahrzeug'
                            : 'Frei'}
                      </Text>
                    </View>
                  </Pressable>
                ))}
                <Button
                  title="Flotte verwalten"
                  onPress={() => {
                    setModal(null);
                    onFleet();
                  }}
                />
              </>
            ) : (
              <>
                <Text style={s.amount}>{euros(state?.today?.gross || 0)}</Text>
                <Text style={s.detail}>
                  {state?.today?.trips || 0} Fahrten heute ·{' '}
                  {euros(state?.today?.collected || 0)} kassiert ·{' '}
                  {euros(state?.today?.outstanding || 0)} offen
                </Text>
                <Text style={s.heading}>Letzte Fahrten</Text>
                {state?.history?.map((booking) => (
                  <View key={booking.id} style={s.row}>
                    <View style={s.flex}>
                      <Text style={s.heading}>
                        {booking.route.destination.label}
                      </Text>
                      <Text style={s.detail}>
                        {new Date(
                          booking.completed_at || booking.updated_at,
                        ).toLocaleString('de-DE')}{' '}
                        ·{' '}
                        {booking.payment_status === 'paid'
                          ? 'Bezahlt'
                          : 'Zahlung offen'}
                      </Text>
                    </View>
                    <Text style={s.heading}>{euros(booking.price)}</Text>
                  </View>
                ))}
              </>
            )}
            {!!error && <Text style={s.error}>{error}</Text>}
            <Pressable onPress={() => void refresh()} style={s.row}>
              <RefreshCw color={gold} size={21} />
              <Text style={s.link}>Aktualisieren</Text>
            </Pressable>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}
function Button({
  title,
  busy,
  onPress,
}: {
  title: string;
  busy?: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      disabled={busy}
      style={[s.button, busy && { opacity: 0.6 }]}
      onPress={onPress}
    >
      {busy ? (
        <ActivityIndicator color="#fff" />
      ) : (
        <Text style={s.buttonText}>{title}</Text>
      )}
    </Pressable>
  );
}
const ink = '#161a20',
  gold = '#aa8345';
const s = StyleSheet.create({
  root: { flex: 1, overflow: 'hidden', backgroundColor: '#f5f2eb' },
  flex: { flex: 1 },
  top: { position: 'absolute', top: 14, left: 18, right: 18, gap: 12 },
  revenue: {
    alignSelf: 'center',
    borderRadius: 28,
    paddingHorizontal: 24,
    paddingVertical: 12,
    backgroundColor: '#fff',
    flexDirection: 'row',
    gap: 13,
    alignItems: 'center',
    elevation: 3,
  },
  revenueText: { fontSize: 22, fontWeight: '600', color: ink },
  eyebrow: { color: gold, fontSize: 10, fontWeight: '700', letterSpacing: 1.8 },
  title: {
    color: ink,
    fontSize: 29,
    lineHeight: 34,
    fontWeight: '600',
    letterSpacing: -0.9,
  },
  heading: { color: ink, fontSize: 15, fontWeight: '600', lineHeight: 21 },
  detail: { color: '#797b7e', fontSize: 13, lineHeight: 20 },
  small: { color: '#8b8171', fontSize: 11, lineHeight: 17, flex: 1 },
  sheet: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    backgroundColor: '#fff',
    elevation: 8,
  },
  handleArea: { height: 105, paddingTop: 11, paddingHorizontal: 24 },
  handle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#cbb793',
    alignSelf: 'center',
    marginBottom: 18,
  },
  sheetHeader: { flexDirection: 'row', gap: 14, alignItems: 'center' },
  sheetContent: { padding: 24, paddingTop: 10, gap: 16, paddingBottom: 34 },
  row: {
    flexDirection: 'row',
    gap: 14,
    alignItems: 'center',
    paddingVertical: 17,
    paddingHorizontal: 4,
    borderRadius: 16,
  },
  selected: { backgroundColor: '#fbf7ef', paddingHorizontal: 15 },
  button: {
    backgroundColor: ink,
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    minHeight: 60,
  },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  warning: { backgroundColor: '#fff6ed', padding: 16, borderRadius: 18 },
  error: { color: '#ac493b', fontSize: 13, lineHeight: 20 },
  link: { color: gold, fontWeight: '600', fontSize: 14, paddingVertical: 9 },
  footer: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'center',
    paddingTop: 4,
  },
  order: { padding: 15, backgroundColor: '#fcf9f3', borderRadius: 20, gap: 12 },
  guidance: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 16,
    gap: 13,
    elevation: 3,
  },
  modal: { flex: 1, paddingTop: 26, backgroundColor: '#fff' },
  modalHeader: {
    padding: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  modalContent: { padding: 24, paddingTop: 0, gap: 18, paddingBottom: 40 },
  amount: { fontSize: 43, color: ink, fontWeight: '600', letterSpacing: -1.5 },
  settings: { padding: 24, paddingBottom: 40, gap: 18 },
});
