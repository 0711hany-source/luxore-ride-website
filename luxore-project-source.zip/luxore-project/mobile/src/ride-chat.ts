import { useCallback, useEffect, useRef, useState } from 'react';
import {
  NativeApiError,
  NativeRequestAborted,
  NativeRouteMissingError,
  nativeApi,
  routeMissingText,
} from './account-client';

/** Chat zwischen Fahrgast und Chauffeur einer Fahrt (Server: /api/mobility/chat). */
export type ChatMessage = {
  id: string;
  mine: boolean;
  body: string;
  created_at: number;
};
export type ChatFeed = {
  serverTime: number;
  /** false: Die Fahrt hat (noch/mehr) keinen Chat; messages ist dann leer. */
  open?: boolean;
  messages: ChatMessage[];
};
/** Fenster offen: alle 4 s. Fenster zu: alle 15 s, nur für den Zähler. */
export const CHAT_OPEN_POLL_MS = 4000;
export const CHAT_CLOSED_POLL_MS = 15000;
export const CHAT_BODY_MAX = 500;

export const fetchChat = (
  token: string,
  bookingId: string,
  after: number,
  signal?: AbortSignal,
) =>
  nativeApi<ChatFeed>(
    'chat',
    token,
    undefined,
    { bookingId, after: String(after) },
    signal,
  );
export const sendChat = (token: string, bookingId: string, body: string) =>
  nativeApi<{ ok: true; message: ChatMessage }>('chat', token, {
    bookingId,
    body,
  });

/** Jüngster Zeitstempel – der Wert für `after` beim nächsten Abruf. */
export const chatCursor = (messages: readonly ChatMessage[]) =>
  messages.reduce((max, m) => Math.max(max, m.created_at), 0);
/** Fügt neue Nachrichten ohne Doppelte ein, älteste zuerst. */
export function mergeChat(
  current: readonly ChatMessage[],
  incoming: readonly ChatMessage[],
) {
  const known = new Set(current.map((m) => m.id));
  const fresh = incoming.filter(
    (m) => m && typeof m.id === 'string' && !known.has(m.id),
  );
  return {
    fresh,
    messages: fresh.length
      ? [...current, ...fresh].sort((a, b) => a.created_at - b.created_at)
      : (current as ChatMessage[]),
  };
}
/** Fremde Nachrichten, die nach dem zuletzt gelesenen Stand kamen. */
export const unreadCount = (messages: readonly ChatMessage[], seen: number) =>
  messages.filter((m) => !m.mine && m.created_at > seen).length;
/** Gekürzt auf die erlaubte Länge; leer, wenn nichts zu senden ist. */
export const chatDraft = (text: string) => text.trim().slice(0, CHAT_BODY_MAX);

// Gelesen-Stand je Fahrt für die laufende App-Sitzung: Der Zähler bleibt
// richtig, auch wenn der Bildschirm zwischendurch neu aufgebaut wird.
const seenByBooking = new Map<string, number>();

export type RideChatState = {
  /** Älteste zuerst. */
  messages: ChatMessage[];
  unread: number;
  /** false: Der Server kennt den Chat noch nicht. */
  available: boolean;
  /** false: Für diese Fahrt ist der Chat (noch/mehr) nicht offen. */
  rideOpen: boolean;
  /** Letzter Abruf ohne Verbindung. */
  offline: boolean;
  sending: boolean;
  error: string;
  /** true, wenn die Nachricht gespeichert ist. */
  send: (text: string) => Promise<boolean>;
  clearError: () => void;
};

/**
 * Hält den Chat einer Fahrt aktuell. Abgerufen wird nur, solange `active`
 * gilt: bei offenem Fenster alle 4 s, sonst alle 15 s für den Zähler.
 * `onIncoming` meldet eine neue fremde Nachricht, während das Fenster zu ist
 * (nicht für den Bestand beim ersten Laden).
 */
export function useRideChat({
  token,
  bookingId,
  active,
  open,
  onIncoming,
}: {
  token: string | null;
  bookingId: string | null;
  active: boolean;
  open: boolean;
  onIncoming?: (text: string) => void;
}): RideChatState {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [unread, setUnread] = useState(0);
  const [available, setAvailable] = useState(true);
  const [rideOpen, setRideOpen] = useState(true);
  const [offline, setOffline] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const store = useRef<ChatMessage[]>([]);
  const loaded = useRef(false);
  // Nur Abrufe schieben den Zeiger weiter, nie die eigene gesendete Nachricht.
  const cursor = useRef(0);
  const openRef = useRef(open);
  openRef.current = open;
  const incoming = useRef(onIncoming);
  incoming.current = onIncoming;
  const current = useRef({ token, bookingId });
  current.current = { token, bookingId };

  const markRead = useCallback((id: string) => {
    seenByBooking.set(
      id,
      Math.max(seenByBooking.get(id) ?? 0, chatCursor(store.current)),
    );
    setUnread(0);
  }, []);

  // Andere Fahrt: nichts von der vorigen bleibt stehen.
  useEffect(() => {
    store.current = [];
    loaded.current = false;
    cursor.current = 0;
    setMessages([]);
    setUnread(0);
    setRideOpen(true);
    setError('');
  }, [bookingId]);

  useEffect(() => {
    if (!active || !token || !bookingId) return;
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout> | undefined;
    let stopped = false;
    const tick = async () => {
      try {
        const feed = await fetchChat(
          token,
          bookingId,
          cursor.current,
          controller.signal,
        );
        if (stopped) return;
        setOffline(false);
        setAvailable(true);
        if (feed.open === false) {
          store.current = [];
          cursor.current = 0;
          setMessages([]);
          setUnread(0);
          setRideOpen(false);
        } else {
          setRideOpen(true);
          const first = !loaded.current;
          loaded.current = true;
          const list = Array.isArray(feed.messages) ? feed.messages : [];
          cursor.current = Math.max(cursor.current, chatCursor(list));
          const merged = mergeChat(store.current, list);
          if (merged.fresh.length) {
            store.current = merged.messages;
            setMessages(merged.messages);
            if (openRef.current) markRead(bookingId);
            else {
              setUnread(
                unreadCount(
                  merged.messages,
                  seenByBooking.get(bookingId) ?? 0,
                ),
              );
              const foreign = merged.fresh.filter((m) => !m.mine);
              if (!first && foreign.length)
                incoming.current?.(foreign[foreign.length - 1].body);
            }
          }
        }
      } catch (e) {
        if (stopped || e instanceof NativeRequestAborted) return;
        if (e instanceof NativeRouteMissingError) {
          // Älterer Server ohne Chat: nicht weiter anfragen.
          setAvailable(false);
          return;
        }
        if (e instanceof NativeApiError && [401, 403, 404].includes(e.status)) {
          // Fahrt gehört (nicht mehr) zu diesem Konto.
          setRideOpen(false);
          return;
        }
        setOffline(true);
      }
      if (!stopped)
        timer = setTimeout(
          tick,
          open ? CHAT_OPEN_POLL_MS : CHAT_CLOSED_POLL_MS,
        );
    };
    void tick();
    return () => {
      stopped = true;
      controller.abort();
      if (timer) clearTimeout(timer);
    };
  }, [token, bookingId, active, open, markRead]);

  // Beim Öffnen gilt alles Vorhandene als gelesen.
  useEffect(() => {
    if (open && bookingId) markRead(bookingId);
  }, [open, bookingId, markRead]);

  const send = useCallback(async (text: string) => {
    const { token: t, bookingId: id } = current.current;
    const body = chatDraft(text);
    if (!t || !id || !body) return false;
    setSending(true);
    setError('');
    try {
      const saved = await sendChat(t, id, body);
      if (current.current.bookingId === id && saved?.message?.id) {
        // Der Abruf-Zeiger bleibt stehen: Eine fremde Nachricht, die knapp
        // davor gespeichert wurde, kommt mit dem nächsten Abruf noch an.
        const merged = mergeChat(store.current, [
          { ...saved.message, mine: true },
        ]);
        store.current = merged.messages;
        setMessages(merged.messages);
      }
      return true;
    } catch (e) {
      setError(
        e instanceof NativeRouteMissingError
          ? routeMissingText
          : e instanceof Error && e.message
            ? e.message
            : 'Die Nachricht konnte nicht gesendet werden. Bitte erneut versuchen.',
      );
      return false;
    } finally {
      setSending(false);
    }
  }, []);
  const clearError = useCallback(() => setError(''), []);

  return {
    messages,
    unread,
    available,
    rideOpen,
    offline,
    sending,
    error,
    send,
    clearError,
  };
}
