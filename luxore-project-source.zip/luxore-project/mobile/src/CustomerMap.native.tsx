import React, { Suspense, useState } from 'react';
import { ActivityIndicator, Pressable, Text, View } from 'react-native';
import type { CustomerMapProps } from './CustomerMap';
import { colors, space } from './theme';
const load = () => import('./NativeCustomerMapView');
class Boundary extends React.Component<
  { children: React.ReactNode; retry: () => void; onError: () => void },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch() {
    this.props.onError();
  }
  render() {
    return this.state.failed ? (
      <View style={{ flex: 1, justifyContent: 'center', padding: space[5] }}>
        <Text>Die Karte konnte nicht gestartet werden.</Text>
        <Pressable accessibilityRole="button" onPress={this.props.retry}>
          <Text style={{ padding: 20, color: colors.gold }}>
            Kartenmodul erneut laden
          </Text>
        </Pressable>
      </View>
    ) : (
      this.props.children
    );
  }
}
export default function CustomerMap(
  props: CustomerMapProps & { loader?: typeof load },
) {
  const [attempt, setAttempt] = useState(() => ({
    key: 0,
    Component: React.lazy(props.loader || load),
  }));
  if (!props.active || !props.token) return null;
  const Component = attempt.Component;
  return (
    <Boundary
      key={attempt.key}
      onError={() => {}}
      retry={() =>
        setAttempt((v) => ({
          key: v.key + 1,
          Component: React.lazy(props.loader || load),
        }))
      }
    >
      <Suspense
        fallback={
          <View style={{ flex: 1, justifyContent: 'center' }}>
            <ActivityIndicator color={colors.gold} />
          </View>
        }
      >
        <Component {...props} />
      </Suspense>
    </Boundary>
  );
}
