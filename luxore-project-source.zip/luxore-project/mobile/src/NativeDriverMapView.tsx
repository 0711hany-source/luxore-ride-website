import React, { useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Mapbox from '@rnmapbox/maps';
import { LocateFixed, Navigation, Route } from 'lucide-react-native';
import {
  NavigationMotion,
  projectRoad,
  type Pose,
} from '../../app/mobility/navigation-motion';
import type { DriverMapProps } from './DriverMap';
import { MapStartup } from './map-startup';
import { colors, typography } from './theme';
const startup = new MapStartup(Mapbox);
// Drawn by the map itself. A React view on the map (MarkerView) had to be
// re-rendered for every movement and made the map flicker on weaker phones.
// (Plain Node test runs have no bundler `require`; the dot below remains.)
const arrowImages: Record<string, number> =
  typeof require === 'function'
    ? { 'luxore-arrow': require('../assets/driver-arrow.png') }
    : {};
const nothing = { type: 'FeatureCollection' as const, features: [] };
/** Further out on fast roads, close in town and before a turn. */
function zoomFor(speed: number, turnIn: number | null) {
  const cruise =
    speed < 7 ? 17.1 : speed < 14 ? 16.5 : speed < 22 ? 15.8 : speed < 31 ? 15.1 : 14.4;
  return turnIn !== null && turnIn < 200 ? Math.max(cruise, 16.9) : cruise;
}

export default function NativeDriverMap({
  token,
  position,
  route,
  active,
  topInset = 80,
  bottomInset = 220,
  turnIn = null,
}: DriverMapProps) {
  'use no memo'; // Native gesture/camera commands use mutable imperative handles.
  const [configured, setConfigured] = useState('');
  const [error, setError] = useState(false);
  const [generation, setGeneration] = useState(0);
  const [pose, setPose] = useState<Pose | null>(null);
  const [following, setFollowing] = useState(true);
  // Whole route at a glance; the locate button returns to guidance.
  const [overview, setOverview] = useState(false);
  // The part of the route still ahead; what was driven disappears.
  const [ahead, setAhead] = useState<number[][] | null>(null);
  const cut = useRef<{ line: number[][]; segment: number } | null>(null);
  const size = useRef({ width: 0, height: 0 });
  const zoom = useRef(16.5);
  const live = useRef({ topInset, bottomInset, turnIn, speed: 0, overview });
  useEffect(() => {
    live.current = {
      topInset,
      bottomInset,
      turnIn,
      speed: Math.max(0, position?.speed ?? 0),
      overview,
    };
  }, [topInset, bottomInset, turnIn, position, overview]);
  function showOverview() {
    const line = routeRef.current?.geometry.coordinates;
    if (!line?.length || !ready.current) return;
    const here = motion.current.position;
    const points = here ? [...line, [here.lng, here.lat]] : line;
    const lngs = points.map((c) => c[0]),
      lats = points.map((c) => c[1]);
    camera.current?.setCamera({
      bounds: {
        ne: [Math.max(...lngs), Math.max(...lats)],
        sw: [Math.min(...lngs), Math.min(...lats)],
        paddingTop: live.current.topInset + 30,
        paddingBottom: live.current.bottomInset + 30,
        paddingLeft: 40,
        paddingRight: 40,
      },
      heading: 0,
      pitch: 0,
      animationDuration: 700,
      animationMode: 'easeTo',
    });
  }
  const camera = useRef<React.ComponentRef<typeof Mapbox.Camera>>(null);
  const motion = useRef(new NavigationMotion(true));
  const lastCut = useRef(0);
  const gestureUntil = useRef(0),
    lastCamera = useRef(0),
    ready = useRef(false);
  const routeRef = useRef(route);
  useEffect(() => {
    routeRef.current = route;
  }, [route]);
  useEffect(() => {
    let alive = true;
    if (!token) return;
    void startup
      .prepare(token, () => alive)
      .then((prepared) => {
        if (alive && prepared) setConfigured(token);
      })
      .catch(() => {
        if (alive) setError(true);
      });
    return () => {
      alive = false;
    };
  }, [token, generation]);
  useEffect(() => {
    if (position)
      motion.current.push(
        position,
        Date.now(),
        route?.geometry.coordinates,
        route?.geometry.coordinates,
      );
  }, [position, route]);
  useEffect(() => {
    if (!active || configured !== token || !token) return;
    // Native Mapbox draws tiles and 3D. Only the single displayed pose is sampled
    // here; animation never rewrites raw GPS or keeps advancing through a blackout.
    const timer = setInterval(() => {
      const now = Date.now(),
        next = motion.current.sample(now);
      if (!next) return;
      // A standing car causes no redraw at all.
      setPose((previous) =>
        previous &&
        previous.lat === next.lat &&
        previous.lng === next.lng &&
        previous.bearing === next.bearing
          ? previous
          : next,
      );
      // Erase the driven part: the line starts at the arrow, never behind it.
      const line = routeRef.current?.geometry.coordinates;
      if (!line || line.length < 2) {
        cut.current = null;
        setAhead((previous) => (previous ? null : previous));
      } else {
        const known = cut.current?.line === line ? cut.current.segment : 0;
        // Search forward from the last known place first (loops, overlaps).
        const near = projectRoad(next, line.slice(known, known + 80));
        const hit =
          near && near.distance <= 35
            ? { ...near, segment: near.segment + known }
            : projectRoad(next, line);
        if (hit && hit.distance <= 35) {
          if (
            cut.current?.line !== line ||
            cut.current.segment !== hit.segment ||
            now - lastCut.current >= 300
          ) {
            lastCut.current = now;
            cut.current = { line, segment: hit.segment };
            setAhead([[hit.lng, hit.lat], ...line.slice(hit.segment + 1)]);
          }
        } else if (cut.current?.line !== line) {
          cut.current = { line, segment: 0 };
          setAhead(line);
        }
      }
      if (live.current.overview) return;
      if (
        now >= gestureUntil.current &&
        ready.current &&
        now - lastCamera.current >= 250
      ) {
        lastCamera.current = now;
        setFollowing(true);
        const guiding = !!routeRef.current;
        const { topInset: top, bottomInset: bottom } = live.current;
        // Visible strip between the turn banner and the sheet.
        const visible = Math.max(140, size.current.height - top - bottom);
        const wanted = guiding
          ? zoomFor(live.current.speed, live.current.turnIn)
          : 15.5;
        // Zoom changes glide; they never jump with every speed reading.
        zoom.current += (wanted - zoom.current) * 0.12;
        camera.current?.setCamera({
          centerCoordinate: [next.lng, next.lat],
          heading: guiding ? next.bearing : 0,
          pitch: guiding ? 50 : 0,
          zoomLevel: zoom.current,
          animationDuration: 250,
          animationMode: 'linearTo',
          padding: {
            // While guiding the arrow sits in the lower part of the visible
            // map, so the road and the next turn lie ahead of it.
            paddingTop: top + (guiding ? visible * 0.5 : 0),
            paddingBottom: bottom,
            paddingLeft: 0,
            paddingRight: 0,
          },
        });
      }
    }, 100);
    return () => clearInterval(timer);
  }, [active, configured, token]);
  if (configured !== token || !token)
    return (
      <View style={s.wait}>
        <Text style={s.detail}>
          {error
            ? 'Die Karte konnte nicht initialisiert werden. Dein Fahrerbereich bleibt geöffnet.'
            : token
              ? 'Native Karte wird vorbereitet …'
              : 'Karte derzeit nicht verfügbar. Schichtstatus und GPS bleiben unabhängig.'}
        </Text>
        {error && (
          <Pressable
            accessibilityRole="button"
            onPress={() => {
              setError(false);
              setGeneration((previous) => previous + 1);
            }}
          >
            <Text style={s.retry}>Karte erneut starten</Text>
          </Pressable>
        )}
      </View>
    );
  return (
    <View
      style={s.root}
      onLayout={(event) => {
        size.current = event.nativeEvent.layout;
      }}
    >
      <Mapbox.MapView
        key={generation}
        style={s.root}
        styleURL="mapbox://styles/mapbox/navigation-day-v1"
        surfaceView={false}
        compassEnabled={false}
        scaleBarEnabled={false}
        attributionPosition={{ top: topInset, left: 100 }}
        logoPosition={{ top: topInset, left: 10 }}
        onDidFinishLoadingMap={() => {
          ready.current = true;
          setError(false);
        }}
        onMapLoadingError={() => setError(true)}
        onCameraChanged={(state) => {
          if (state.gestures.isGestureActive) {
            // Looking around stays possible for a while before guidance returns.
            gestureUntil.current = Date.now() + 8000;
            setFollowing(false);
          }
        }}
      >
        <Mapbox.Camera
          ref={camera}
          defaultSettings={{
            centerCoordinate: position
              ? [position.lng, position.lat]
              : [8.6821, 50.1109],
            zoomLevel: 14,
            pitch: 0,
          }}
        />
        {/* Always mounted, so the layers keep their order: the line lies
            below the arrow no matter when the route arrives. */}
        <Mapbox.ShapeSource
          id="luxore-route"
          shape={
            route
              ? {
                  type: 'Feature',
                  properties: {},
                  geometry: {
                    type: 'LineString',
                    coordinates:
                      ahead && ahead.length > 1
                        ? ahead
                        : route.geometry.coordinates,
                  },
                }
              : nothing
          }
        >
          <Mapbox.LineLayer
            id="luxore-route-outline"
            style={{
              lineColor: '#1d4f86',
              lineWidth: 11,
              lineCap: 'round',
              lineJoin: 'round',
            }}
          />
          <Mapbox.LineLayer
            id="luxore-route-line"
            style={{
              lineColor: '#3b82d6',
              lineWidth: 7.5,
              lineCap: 'round',
              lineJoin: 'round',
            }}
          />
        </Mapbox.ShapeSource>
        <Mapbox.ShapeSource
          id="luxore-destination"
          shape={
            route
              ? {
                  type: 'Feature',
                  properties: {},
                  geometry: {
                    type: 'Point',
                    coordinates: [route.destination.lng, route.destination.lat],
                  },
                }
              : nothing
          }
        >
          <Mapbox.CircleLayer
            id="luxore-destination-dot"
            style={{
              circleRadius: 8,
              circleColor: '#151719',
              circleStrokeColor: '#ffffff',
              circleStrokeWidth: 4,
              circlePitchAlignment: 'map',
            }}
          />
        </Mapbox.ShapeSource>
        <Mapbox.Images images={arrowImages} />
        {pose && (
          <Mapbox.ShapeSource
            id="luxore-driver"
            shape={{
              type: 'Feature',
              properties: { bearing: pose.bearing },
              geometry: { type: 'Point', coordinates: [pose.lng, pose.lat] },
            }}
          >
            {/* Stays visible even if the arrow image could not be loaded. */}
            <Mapbox.CircleLayer
              id="luxore-driver-dot"
              style={{
                circleRadius: 9,
                circleColor: '#151719',
                circleStrokeColor: '#ffffff',
                circleStrokeWidth: 3,
                circlePitchAlignment: 'map',
              }}
            />
            <Mapbox.SymbolLayer
              id="luxore-driver-arrow"
              style={{
                iconImage: 'luxore-arrow',
                iconSize: 0.46,
                iconPitchAlignment: 'map',
                iconRotate: ['get', 'bearing'],
                iconRotationAlignment: 'map',
                iconAllowOverlap: true,
                iconIgnorePlacement: true,
              }}
            />
          </Mapbox.ShapeSource>
        )}
      </Mapbox.MapView>
      <Pressable
        style={[s.locate, { top: topInset + 12 }]}
        accessibilityLabel="Karte auf meinen Standort zurücksetzen"
        onPress={() => {
          gestureUntil.current = 0;
          lastCamera.current = 0;
          setOverview(false);
          setFollowing(true);
        }}
      >
        <LocateFixed color={following ? colors.ink : colors.gray} size={23} />
      </Pressable>
      {route && (
        <Pressable
          style={[
            s.locate,
            { top: topInset + 70 },
            overview && s.overviewOn,
          ]}
          accessibilityRole="button"
          accessibilityLabel={
            overview ? 'Zurück zur Navigation' : 'Gesamte Route anzeigen'
          }
          onPress={() => {
            if (overview) {
              gestureUntil.current = 0;
              lastCamera.current = 0;
              setOverview(false);
              setFollowing(true);
            } else {
              setOverview(true);
              setFollowing(false);
              showOverview();
            }
          }}
        >
          {overview ? (
            <Navigation color={colors.white} size={22} />
          ) : (
            <Route color={colors.ink} size={22} />
          )}
        </Pressable>
      )}
      {error && (
        <Pressable
          style={s.warning}
          onPress={() => {
            ready.current = false;
            setGeneration((v) => v + 1);
          }}
        >
          <Text style={s.detail}>
            Karte konnte nicht geladen werden · erneut laden
          </Text>
        </Pressable>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1 },
  retry: { color: colors.gold, padding: 20, ...typography.footnote, fontWeight: '600', textAlign: 'center' },
  wait: {
    flex: 1,
    backgroundColor: colors.sand,
    justifyContent: 'center',
    padding: 32,
  },
  detail: {
    color: colors.goldText,
    ...typography.footnote,
    textAlign: 'center',
  },
  locate: {
    position: 'absolute',
    right: 16,
    backgroundColor: colors.white,
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 3,
  },
  overviewOn: { backgroundColor: colors.ink },
  warning: {
    position: 'absolute',
    top: 165,
    left: 16,
    right: 16,
    padding: 13,
    borderRadius: 16,
    backgroundColor: colors.paper,
  },
});
