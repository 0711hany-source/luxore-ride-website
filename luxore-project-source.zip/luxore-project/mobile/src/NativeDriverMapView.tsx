import React, { useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Mapbox from '@rnmapbox/maps';
import { LocateFixed } from 'lucide-react-native';
import Svg, { Defs, LinearGradient, Path, Stop } from 'react-native-svg';
import {
  NavigationMotion,
  type Pose,
} from '../../app/mobility/navigation-motion';
import type { DriverMapProps } from './DriverMap';
import { MapStartup } from './map-startup';
const startup = new MapStartup(Mapbox);

export default function NativeDriverMap({
  token,
  position,
  route,
  active,
}: DriverMapProps) {
  'use no memo'; // Native gesture/camera commands use mutable imperative handles.
  const [configured, setConfigured] = useState('');
  const [error, setError] = useState(false);
  const [generation, setGeneration] = useState(0);
  const [pose, setPose] = useState<Pose | null>(null);
  const [following, setFollowing] = useState(true);
  const [mapHeading, setMapHeading] = useState(0);
  const camera = useRef<React.ComponentRef<typeof Mapbox.Camera>>(null);
  const motion = useRef(new NavigationMotion(true));
  const gestureUntil = useRef(0),
    lastCamera = useRef(0),
    ready = useRef(false);
  const routeRef = useRef(route);
  useEffect(() => {
    routeRef.current = route;
  }, [route]);
  useEffect(() => {
    let alive = true;
    if (!token) return;
    void startup
      .prepare(token, () => alive)
      .then((prepared) => {
        if (alive && prepared) setConfigured(token);
      })
      .catch(() => {
        if (alive) setError(true);
      });
    return () => {
      alive = false;
    };
  }, [token, generation]);
  useEffect(() => {
    if (position)
      motion.current.push(
        position,
        Date.now(),
        route?.geometry.coordinates,
        route?.geometry.coordinates,
      );
  }, [position, route]);
  useEffect(() => {
    if (!active || configured !== token || !token) return;
    // Native Mapbox draws tiles and 3D. Only the single displayed pose is sampled
    // here; animation never rewrites raw GPS or keeps advancing through a blackout.
    const timer = setInterval(() => {
      const now = Date.now(),
        next = motion.current.sample(now);
      if (!next) return;
      setPose(next);
      if (
        now >= gestureUntil.current &&
        ready.current &&
        now - lastCamera.current >= 250
      ) {
        lastCamera.current = now;
        setFollowing(true);
        camera.current?.setCamera({
          centerCoordinate: [next.lng, next.lat],
          heading: routeRef.current ? next.bearing : 0,
          pitch: routeRef.current ? 52 : 0,
          zoomLevel: routeRef.current ? 17 : 15.8,
          animationDuration: 250,
          animationMode: 'linearTo',
          padding: {
            paddingTop: 80,
            paddingBottom: 220,
            paddingLeft: 0,
            paddingRight: 0,
          },
        });
      }
    }, 50);
    return () => clearInterval(timer);
  }, [active, configured, token]);
  if (configured !== token || !token)
    return (
      <View style={s.wait}>
        <Text style={s.detail}>
          {error
            ? 'Die Karte konnte nicht initialisiert werden. Dein Fahrerbereich bleibt geöffnet.'
            : token
              ? 'Native Karte wird vorbereitet …'
              : 'Karte derzeit nicht verfügbar. Schichtstatus und GPS bleiben unabhängig.'}
        </Text>
        {error && (
          <Pressable
            accessibilityRole="button"
            onPress={() => {
              setError(false);
              setGeneration((previous) => previous + 1);
            }}
          >
            <Text style={s.retry}>Karte erneut starten</Text>
          </Pressable>
        )}
      </View>
    );
  return (
    <View style={s.root}>
      <Mapbox.MapView
        key={generation}
        style={s.root}
        styleURL="mapbox://styles/mapbox/streets-v12"
        surfaceView={false}
        compassEnabled={false}
        scaleBarEnabled={false}
        attributionPosition={{ top: 80, left: 100 }}
        logoPosition={{ top: 80, left: 10 }}
        onDidFinishLoadingMap={() => {
          ready.current = true;
          setError(false);
        }}
        onMapLoadingError={() => setError(true)}
        onCameraChanged={(state) => {
          setMapHeading(state.properties.heading);
          if (state.gestures.isGestureActive) {
            gestureUntil.current = Date.now() + 3000;
            setFollowing(false);
          }
        }}
      >
        <Mapbox.Camera
          ref={camera}
          defaultSettings={{
            centerCoordinate: position
              ? [position.lng, position.lat]
              : [8.6821, 50.1109],
            zoomLevel: 14,
            pitch: 0,
          }}
        />
        <Mapbox.FillExtrusionLayer
          id="luxore-buildings"
          sourceID="composite"
          sourceLayerID="building"
          minZoomLevel={15}
          maxZoomLevel={22}
          filter={['==', ['get', 'extrude'], 'true']}
          style={{
            fillExtrusionColor: '#e6ddcc',
            fillExtrusionHeight: ['get', 'height'],
            fillExtrusionBase: ['get', 'min_height'],
            fillExtrusionOpacity: 0.65,
          }}
        />
        {route && (
          <Mapbox.ShapeSource
            id="luxore-route"
            shape={{
              type: 'Feature',
              properties: {},
              geometry: route.geometry,
            }}
          >
            <Mapbox.LineLayer
              id="luxore-route-outline"
              style={{
                lineColor: '#fff',
                lineWidth: 9,
                lineCap: 'round',
                lineJoin: 'round',
              }}
            />
            <Mapbox.LineLayer
              id="luxore-route-line"
              style={{
                lineColor: '#ae8549',
                lineWidth: 5,
                lineCap: 'round',
                lineJoin: 'round',
              }}
            />
          </Mapbox.ShapeSource>
        )}
        {route && (
          <Mapbox.PointAnnotation
            id="luxore-destination"
            coordinate={[route.destination.lng, route.destination.lat]}
          >
            <View style={s.destination} />
          </Mapbox.PointAnnotation>
        )}
        {pose && (
          <Mapbox.MarkerView coordinate={[pose.lng, pose.lat]} allowOverlap>
            <View
              pointerEvents="none"
              style={[
                s.arrow,
                { transform: [{ rotate: `${pose.bearing - mapHeading}deg` }] },
              ]}
            >
              <Svg width={52} height={60} viewBox="0 0 52 60">
                <Defs>
                  <LinearGradient id="arrow" x1="0" y1="0" x2="1" y2="1">
                    <Stop offset="0" stopColor="#f0d89f" />
                    <Stop offset="1" stopColor="#a77931" />
                  </LinearGradient>
                </Defs>
                <Path
                  d="M26 3 L47 51 Q48 56 43 54 L26 45 L9 54 Q4 56 5 51 Z"
                  fill="url(#arrow)"
                  stroke="#fff"
                  strokeWidth={3}
                />
                <Path d="M26 7 L26 43 L9 51 Z" fill="#fff" opacity={0.18} />
              </Svg>
            </View>
          </Mapbox.MarkerView>
        )}
      </Mapbox.MapView>
      <Pressable
        style={s.locate}
        accessibilityLabel="Karte auf meinen Standort zurücksetzen"
        onPress={() => {
          gestureUntil.current = 0;
          lastCamera.current = 0;
          setFollowing(true);
        }}
      >
        <LocateFixed color={following ? '#aa8345' : '#252a30'} size={23} />
      </Pressable>
      {error && (
        <Pressable
          style={s.warning}
          onPress={() => {
            ready.current = false;
            setGeneration((v) => v + 1);
          }}
        >
          <Text style={s.detail}>
            Karte konnte nicht geladen werden · erneut laden
          </Text>
        </Pressable>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1 },
  retry: { color: '#aa8345', padding: 20, fontSize: 14, fontWeight: '600', textAlign: 'center' },
  wait: {
    flex: 1,
    backgroundColor: '#f5f2eb',
    justifyContent: 'center',
    padding: 32,
  },
  detail: {
    color: '#806b48',
    fontSize: 13,
    lineHeight: 19,
    textAlign: 'center',
  },
  locate: {
    position: 'absolute',
    top: 105,
    right: 16,
    backgroundColor: '#fff',
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 3,
  },
  arrow: {
    width: 56,
    height: 64,
    alignItems: 'center',
    justifyContent: 'center',
  },
  destination: {
    width: 20,
    height: 20,
    backgroundColor: '#161a20',
    borderWidth: 4,
    borderColor: '#fff',
    borderRadius: 10,
  },
  warning: {
    position: 'absolute',
    top: 165,
    left: 16,
    right: 16,
    padding: 13,
    borderRadius: 16,
    backgroundColor: '#fff9ef',
  },
});
