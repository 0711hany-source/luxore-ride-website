import React, { useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Mapbox from '@rnmapbox/maps';
import { LocateFixed } from 'lucide-react-native';
import {
  NavigationMotion,
  type Pose,
} from '../../app/mobility/navigation-motion';
import type { DriverMapProps } from './DriverMap';
import { MapStartup } from './map-startup';
import { colors, typography } from './theme';
const startup = new MapStartup(Mapbox);
// Drawn by the map itself. A React view on the map (MarkerView) had to be
// re-rendered for every movement and made the map flicker on weaker phones.
// (Plain Node test runs have no bundler `require`; the dot below remains.)
const arrowImages: Record<string, number> =
  typeof require === 'function'
    ? { 'luxore-arrow': require('../assets/driver-arrow.png') }
    : {};

export default function NativeDriverMap({
  token,
  position,
  route,
  active,
}: DriverMapProps) {
  'use no memo'; // Native gesture/camera commands use mutable imperative handles.
  const [configured, setConfigured] = useState('');
  const [error, setError] = useState(false);
  const [generation, setGeneration] = useState(0);
  const [pose, setPose] = useState<Pose | null>(null);
  const [following, setFollowing] = useState(true);
  const camera = useRef<React.ComponentRef<typeof Mapbox.Camera>>(null);
  const motion = useRef(new NavigationMotion(true));
  const gestureUntil = useRef(0),
    lastCamera = useRef(0),
    ready = useRef(false);
  const routeRef = useRef(route);
  useEffect(() => {
    routeRef.current = route;
  }, [route]);
  useEffect(() => {
    let alive = true;
    if (!token) return;
    void startup
      .prepare(token, () => alive)
      .then((prepared) => {
        if (alive && prepared) setConfigured(token);
      })
      .catch(() => {
        if (alive) setError(true);
      });
    return () => {
      alive = false;
    };
  }, [token, generation]);
  useEffect(() => {
    if (position)
      motion.current.push(
        position,
        Date.now(),
        route?.geometry.coordinates,
        route?.geometry.coordinates,
      );
  }, [position, route]);
  useEffect(() => {
    if (!active || configured !== token || !token) return;
    // Native Mapbox draws tiles and 3D. Only the single displayed pose is sampled
    // here; animation never rewrites raw GPS or keeps advancing through a blackout.
    const timer = setInterval(() => {
      const now = Date.now(),
        next = motion.current.sample(now);
      if (!next) return;
      // A standing car causes no redraw at all.
      setPose((previous) =>
        previous &&
        previous.lat === next.lat &&
        previous.lng === next.lng &&
        previous.bearing === next.bearing
          ? previous
          : next,
      );
      if (
        now >= gestureUntil.current &&
        ready.current &&
        now - lastCamera.current >= 250
      ) {
        lastCamera.current = now;
        setFollowing(true);
        camera.current?.setCamera({
          centerCoordinate: [next.lng, next.lat],
          heading: routeRef.current ? next.bearing : 0,
          pitch: routeRef.current ? 52 : 0,
          zoomLevel: routeRef.current ? 17 : 15.8,
          animationDuration: 250,
          animationMode: 'linearTo',
          padding: {
            paddingTop: 80,
            paddingBottom: 220,
            paddingLeft: 0,
            paddingRight: 0,
          },
        });
      }
    }, 100);
    return () => clearInterval(timer);
  }, [active, configured, token]);
  if (configured !== token || !token)
    return (
      <View style={s.wait}>
        <Text style={s.detail}>
          {error
            ? 'Die Karte konnte nicht initialisiert werden. Dein Fahrerbereich bleibt geöffnet.'
            : token
              ? 'Native Karte wird vorbereitet …'
              : 'Karte derzeit nicht verfügbar. Schichtstatus und GPS bleiben unabhängig.'}
        </Text>
        {error && (
          <Pressable
            accessibilityRole="button"
            onPress={() => {
              setError(false);
              setGeneration((previous) => previous + 1);
            }}
          >
            <Text style={s.retry}>Karte erneut starten</Text>
          </Pressable>
        )}
      </View>
    );
  return (
    <View style={s.root}>
      <Mapbox.MapView
        key={generation}
        style={s.root}
        styleURL="mapbox://styles/mapbox/streets-v12"
        surfaceView={false}
        compassEnabled={false}
        scaleBarEnabled={false}
        attributionPosition={{ top: 80, left: 100 }}
        logoPosition={{ top: 80, left: 10 }}
        onDidFinishLoadingMap={() => {
          ready.current = true;
          setError(false);
        }}
        onMapLoadingError={() => setError(true)}
        onCameraChanged={(state) => {
          if (state.gestures.isGestureActive) {
            gestureUntil.current = Date.now() + 3000;
            setFollowing(false);
          }
        }}
      >
        <Mapbox.Camera
          ref={camera}
          defaultSettings={{
            centerCoordinate: position
              ? [position.lng, position.lat]
              : [8.6821, 50.1109],
            zoomLevel: 14,
            pitch: 0,
          }}
        />
        <Mapbox.FillExtrusionLayer
          id="luxore-buildings"
          sourceID="composite"
          sourceLayerID="building"
          minZoomLevel={15}
          maxZoomLevel={22}
          filter={['==', ['get', 'extrude'], 'true']}
          style={{
            fillExtrusionColor: '#e0dcd2',
            fillExtrusionHeight: ['get', 'height'],
            fillExtrusionBase: ['get', 'min_height'],
            fillExtrusionOpacity: 0.65,
          }}
        />
        {route && (
          <Mapbox.ShapeSource
            id="luxore-route"
            shape={{
              type: 'Feature',
              properties: {},
              geometry: route.geometry,
            }}
          >
            <Mapbox.LineLayer
              id="luxore-route-outline"
              style={{
                lineColor: '#ffffff',
                lineWidth: 9,
                lineCap: 'round',
                lineJoin: 'round',
              }}
            />
            <Mapbox.LineLayer
              id="luxore-route-line"
              style={{
                lineColor: '#b99a60',
                lineWidth: 5,
                lineCap: 'round',
                lineJoin: 'round',
              }}
            />
          </Mapbox.ShapeSource>
        )}
        {route && (
          <Mapbox.PointAnnotation
            id="luxore-destination"
            coordinate={[route.destination.lng, route.destination.lat]}
          >
            <View style={s.destination} />
          </Mapbox.PointAnnotation>
        )}
        <Mapbox.Images images={arrowImages} />
        {pose && (
          <Mapbox.ShapeSource
            id="luxore-driver"
            shape={{
              type: 'Feature',
              properties: { bearing: pose.bearing },
              geometry: { type: 'Point', coordinates: [pose.lng, pose.lat] },
            }}
          >
            {/* Stays visible even if the arrow image could not be loaded. */}
            <Mapbox.CircleLayer
              id="luxore-driver-dot"
              style={{
                circleRadius: 9,
                circleColor: '#b99a60',
                circleStrokeColor: '#ffffff',
                circleStrokeWidth: 3,
                circlePitchAlignment: 'map',
              }}
            />
            <Mapbox.SymbolLayer
              id="luxore-driver-arrow"
              style={{
                iconImage: 'luxore-arrow',
                iconSize: 0.36,
                iconRotate: ['get', 'bearing'],
                iconRotationAlignment: 'map',
                iconAllowOverlap: true,
                iconIgnorePlacement: true,
              }}
            />
          </Mapbox.ShapeSource>
        )}
      </Mapbox.MapView>
      <Pressable
        style={s.locate}
        accessibilityLabel="Karte auf meinen Standort zurücksetzen"
        onPress={() => {
          gestureUntil.current = 0;
          lastCamera.current = 0;
          setFollowing(true);
        }}
      >
        <LocateFixed color={following ? colors.gold : colors.inkSoft} size={23} />
      </Pressable>
      {error && (
        <Pressable
          style={s.warning}
          onPress={() => {
            ready.current = false;
            setGeneration((v) => v + 1);
          }}
        >
          <Text style={s.detail}>
            Karte konnte nicht geladen werden · erneut laden
          </Text>
        </Pressable>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1 },
  retry: { color: colors.gold, padding: 20, ...typography.footnote, fontWeight: '600', textAlign: 'center' },
  wait: {
    flex: 1,
    backgroundColor: colors.sand,
    justifyContent: 'center',
    padding: 32,
  },
  detail: {
    color: colors.goldText,
    ...typography.footnote,
    textAlign: 'center',
  },
  locate: {
    position: 'absolute',
    top: 105,
    right: 16,
    backgroundColor: colors.white,
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 3,
  },
  destination: {
    width: 20,
    height: 20,
    backgroundColor: colors.ink,
    borderWidth: 4,
    borderColor: colors.white,
    borderRadius: 10,
  },
  warning: {
    position: 'absolute',
    top: 165,
    left: 16,
    right: 16,
    padding: 13,
    borderRadius: 16,
    backgroundColor: colors.paper,
  },
});
