import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Minus, Plus } from 'lucide-react-native';
import { nativeApi } from './account-client';
import { menu } from '../../lib/mobility/refreshments';
import {
  STOCK_COUNT_MAX,
  validateStock,
  type Stock,
} from '../../lib/mobility/inventory';
import { colors, layout, radii, space, typography } from './theme';
type Inventory = {
  vehicleId: string;
  vehicles: { id: string; model: string; plate: string }[];
  revision: number;
  initialized: boolean;
  stock: Stock;
};
type Counts = Record<string, number>;
const countsOf = (stock: Stock): Counts =>
  Object.fromEntries(
    menu.map((item) => [item.id, stock.items[item.id]?.count ?? 0]),
  );
/**
 * Simple stock keeping for the driver: one line per article with the pieces
 * that are in the car right now. Planned stock, thresholds and storage plan
 * stay untouched on the server and are sent back unchanged.
 */
export default function StockScreen({
  token,
  vehicleId,
}: {
  token: string;
  vehicleId?: string;
}) {
  const [data, setData] = useState<Inventory | null>(null),
    [counts, setCounts] = useState<Counts>({}),
    [selected, setSelected] = useState(vehicleId || '');
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [dirty, setDirty] = useState(false),
    [saved, setSaved] = useState(false);
  const alive = useRef(true),
    lock = useRef(false),
    request = useRef(0);
  const adopt = useCallback((reply: Inventory) => {
    setData(reply);
    setCounts(countsOf(reply.stock));
    setDirty(false);
    setError('');
  }, []);
  const load = useCallback(async () => {
    const attempt = ++request.current;
    try {
      const reply = await nativeApi<Inventory>(
        'inventory',
        token,
        undefined,
        selected ? { vehicleId: selected } : undefined,
      );
      if (!alive.current || request.current !== attempt) return;
      adopt(reply);
      setSaved(false);
    } catch (e) {
      if (alive.current && request.current === attempt)
        setError((e as Error).message);
    }
  }, [token, selected, adopt]);
  useEffect(() => {
    alive.current = true;
    void Promise.resolve().then(load);
    return () => {
      alive.current = false;
    };
  }, [load]);
  function change(id: string, delta: number) {
    const next = Math.max(
      0,
      Math.min(STOCK_COUNT_MAX, (counts[id] || 0) + delta),
    );
    if (next === (counts[id] || 0)) return;
    setCounts({ ...counts, [id]: next });
    setDirty(true);
    setSaved(false);
  }
  async function save() {
    if (!data || lock.current) return;
    lock.current = true;
    setBusy(true);
    setError('');
    try {
      const stock = validateStock({
        ...data.stock,
        items: Object.fromEntries(
          menu.map((item) => [
            item.id,
            { ...data.stock.items[item.id], count: counts[item.id] || 0 },
          ]),
        ),
      });
      const reply = await nativeApi<Inventory>('inventory', token, {
        action: 'save',
        vehicleId: data.vehicleId,
        revision: data.revision,
        stock,
        note: data.initialized
          ? 'Bestand im Fahrzeug gezählt'
          : 'Anfangsbestand gezählt',
      });
      if (alive.current) {
        adopt(reply);
        setSaved(true);
      }
    } catch (e) {
      if (alive.current) setError((e as Error).message);
    } finally {
      lock.current = false;
      if (alive.current) setBusy(false);
    }
  }
  function confirmDiscard(callback: () => void) {
    if (dirty)
      Alert.alert(
        'Ungespeicherte Zählung verwerfen?',
        'Deine Eingaben werden durch den gespeicherten Bestand ersetzt.',
        [
          { text: 'Abbrechen', style: 'cancel' },
          { text: 'Verwerfen', onPress: callback },
        ],
      );
    else callback();
  }
  const total = Object.values(counts).reduce((sum, n) => sum + n, 0);
  const canSave = !!data && !busy && (dirty || !data.initialized);
  return (
    <View style={s.root}>
      <ScrollView contentContainerStyle={s.content}>
        <Text style={s.eyebrow}>BORDSERVICE</Text>
        <Text style={s.title}>Bestand im Fahrzeug</Text>
        <Text style={s.detail}>
          Trage ein, was gerade im Fahrzeug liegt. Deine Fahrgäste können nur
          bestellen, was hier vorrätig ist.
        </Text>
        {!data && !error && <ActivityIndicator color={colors.gold} />}
        {data && (
          <>
            {data.vehicles.length > 1 && (
              <View style={s.chips}>
                {data.vehicles.map((car) => (
                  <Pressable
                    key={car.id}
                    disabled={busy}
                    accessibilityRole="button"
                    accessibilityState={{
                      selected: car.id === data.vehicleId,
                    }}
                    style={[s.chip, car.id === data.vehicleId && s.active]}
                    onPress={() => confirmDiscard(() => setSelected(car.id))}
                  >
                    <Text style={s.name}>{car.model}</Text>
                    <Text style={s.detail}>{car.plate}</Text>
                  </Pressable>
                ))}
              </View>
            )}
            {!data.initialized && (
              <Text style={s.notice}>
                Für dieses Fahrzeug ist noch nichts gezählt. Zähle einmal durch
                und speichere.
              </Text>
            )}
            <View style={s.list}>
              {menu.map((item) => {
                const count = counts[item.id] || 0;
                return (
                  <View key={item.id} style={s.item}>
                    <View style={s.flex}>
                      <Text style={s.name}>{item.name}</Text>
                      <Text style={s.detail}>{item.detail}</Text>
                    </View>
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel={`${item.name} verringern`}
                      disabled={busy || count <= 0}
                      onPress={() => change(item.id, -1)}
                      style={[s.step, (busy || count <= 0) && s.off]}
                    >
                      <Minus color={colors.ink} size={24} />
                    </Pressable>
                    <Text
                      style={s.count}
                      accessibilityLabel={`${item.name}: ${count} im Fahrzeug`}
                    >
                      {count}
                    </Text>
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel={`${item.name} erhöhen`}
                      disabled={busy || count >= STOCK_COUNT_MAX}
                      onPress={() => change(item.id, 1)}
                      style={[
                        s.step,
                        (busy || count >= STOCK_COUNT_MAX) && s.off,
                      ]}
                    >
                      <Plus color={colors.ink} size={24} />
                    </Pressable>
                  </View>
                );
              })}
            </View>
            <Text style={s.detail}>
              {total === 1
                ? '1 Artikel im Fahrzeug'
                : `${total} Artikel im Fahrzeug`}
            </Text>
          </>
        )}
        {!!error && (
          <Text style={s.error} accessibilityRole="alert">
            {error}
          </Text>
        )}
        {saved && !dirty && !error && (
          <Text style={s.success} accessibilityRole="alert">
            Bestand gespeichert.
          </Text>
        )}
        {data && (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Bestand speichern"
            accessibilityState={{ disabled: !canSave, busy }}
            disabled={!canSave}
            onPress={() => void save()}
            style={[s.save, !canSave && s.off]}
          >
            {busy ? (
              <ActivityIndicator color={colors.ink} />
            ) : (
              <Text style={s.saveText}>Bestand speichern</Text>
            )}
          </Pressable>
        )}
        <Pressable
          hitSlop={8}
          accessibilityRole="button"
          disabled={busy}
          onPress={() => confirmDiscard(() => void load())}
          style={s.reload}
        >
          <Text style={s.link}>Gespeicherten Bestand neu laden</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
  content: { padding: layout.screenMargin, gap: space[4], paddingBottom: 40 },
  flex: { flex: 1 },
  eyebrow: { color: colors.goldText, ...typography.label },
  title: { color: colors.ink, ...typography.largeTitle },
  name: { color: colors.ink, ...typography.headline },
  detail: { color: colors.gray, ...typography.footnote },
  notice: {
    color: colors.ink,
    ...typography.subhead,
    backgroundColor: colors.paper,
    borderRadius: radii.m,
    padding: space[4],
  },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: space[3] },
  chip: {
    minHeight: layout.tap,
    padding: space[3],
    borderWidth: 1,
    borderColor: colors.sand,
    borderRadius: radii.m,
    gap: space[1],
  },
  active: { backgroundColor: colors.paper, borderColor: colors.goldLight },
  list: { gap: space[2] },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space[3],
    paddingVertical: space[3],
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.line,
  },
  step: {
    width: 52,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radii.pill,
    backgroundColor: colors.paper,
  },
  off: { opacity: 0.35 },
  count: {
    minWidth: 40,
    textAlign: 'center',
    color: colors.ink,
    ...typography.title2,
    fontVariant: ['tabular-nums'],
  },
  save: {
    minHeight: 56,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radii.pill,
    backgroundColor: colors.gold,
    paddingHorizontal: space[4],
  },
  saveText: { color: colors.ink, ...typography.headline },
  reload: { minHeight: layout.tap, justifyContent: 'center' },
  link: { color: colors.goldText, ...typography.footnote, fontWeight: '600' },
  error: { color: colors.danger, ...typography.footnote },
  success: { color: colors.success, ...typography.subhead },
});
