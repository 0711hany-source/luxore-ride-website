import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { nativeApi } from './account-client';
import { menu } from '../../lib/mobility/refreshments';
import {
  shoppingList,
  stockUsage,
  validateStock,
  type Stock,
} from '../../lib/mobility/inventory';
import SwipeAction from './SwipeAction';
type Inventory = {
  vehicleId: string;
  vehicles: { id: string; model: string; plate: string }[];
  revision: number;
  initialized: boolean;
  stock: Stock;
  movements: {
    kind: string;
    actor_name: string;
    note: string;
    created_at: number;
  }[];
};
export default function StockScreen({
  token,
  vehicleId,
}: {
  token: string;
  vehicleId?: string;
}) {
  const [data, setData] = useState<Inventory | null>(null),
    [draft, setDraft] = useState<Stock | null>(null),
    [selected, setSelected] = useState(vehicleId || ''),
    [quantities, setQuantities] = useState<Record<string, number>>({});
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [dirty, setDirty] = useState(false),
    [note, setNote] = useState('');
  const alive = useRef(true),
    lock = useRef(false),
    request = useRef(0);
  const load = useCallback(async () => {
    const attempt = ++request.current;
    try {
      const reply = await nativeApi<Inventory>(
        'inventory',
        token,
        undefined,
        selected ? { vehicleId: selected } : undefined,
      );
      if (!alive.current || request.current !== attempt) return;
      setData(reply);
      setDraft(reply.stock);
      setDirty(false);
      setError('');
      setQuantities({});
    } catch (e) {
      if (alive.current && request.current === attempt)
        setError((e as Error).message);
    }
  }, [token, selected]);
  useEffect(() => {
    alive.current = true;
    void Promise.resolve().then(load);
    return () => {
      alive.current = false;
    };
  }, [load]);
  async function save(
    action: 'save' | 'personal' | 'restock',
    values?: Record<string, number>,
  ) {
    if (!data || !draft || lock.current) return;
    lock.current = true;
    setBusy(true);
    setError('');
    try {
      if (action === 'save' && !note.trim())
        throw new Error(
          'Bitte kurz angeben, warum du den gezählten Bestand erfasst oder korrigierst.',
        );
      const reply = await nativeApi<Inventory>('inventory', token, {
        action,
        vehicleId: data.vehicleId,
        revision: data.revision,
        ...(action === 'save'
          ? { stock: validateStock(draft), note }
          : {
              quantities: values,
              note:
                action === 'personal'
                  ? 'Eigenverbrauch des Fahrers'
                  : 'Einkauf nachgefüllt',
            }),
      });
      if (alive.current) {
        setData(reply);
        setDraft(reply.stock);
        setDirty(false);
        setQuantities({});
        setNote('');
      }
    } catch (e) {
      if (alive.current) setError((e as Error).message);
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  function confirmDiscard(callback: () => void) {
    if (dirty)
      Alert.alert(
        'Ungespeicherte Zählung verwerfen?',
        'Deine Eingaben werden durch den aktuellen Bestand ersetzt.',
        [
          { text: 'Abbrechen', style: 'cancel' },
          { text: 'Verwerfen', onPress: callback },
        ],
      );
    else callback();
  }
  const shopping = data ? shoppingList(data.stock) : [];
  const usage = draft ? stockUsage(draft, 'count') : { drink: 0, snack: 0 };
  return (
    <KeyboardAvoidingView
      style={s.root}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        contentContainerStyle={s.content}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={s.eyebrow}>BORDSERVICE</Text>
        <Text style={s.title}>Gut versorgt.</Text>
        {!data && !error && <ActivityIndicator color="#aa8345" />}
        {data && draft && (
          <>
            <View style={s.chips}>
              {data.vehicles.map((car) => (
                <Pressable
                  key={car.id}
                  disabled={busy}
                  style={[s.chip, car.id === data.vehicleId && s.active]}
                  onPress={() => confirmDiscard(() => setSelected(car.id))}
                >
                  <Text style={s.heading}>{car.model}</Text>
                  <Text style={s.detail}>{car.plate}</Text>
                </Pressable>
              ))}
            </View>
            <View style={s.card}>
              <Text style={s.heading}>
                {shopping.some((item) => item.urgent)
                  ? 'Bitte einkaufen gehen'
                  : 'Deine Einkaufsliste'}
              </Text>
              <Text style={s.detail}>
                {shopping.length
                  ? shopping
                      .map(
                        (item) =>
                          `${item.quantity} × ${item.name}${item.urgent ? ' · knapp' : ''}`,
                      )
                      .join('\n')
                  : 'Alles ausreichend vorhanden.'}
              </Text>
              <Text style={s.detail}>
                Nur tatsächlich eingekaufte und eingeräumte Artikel als
                nachgefüllt bestätigen.
              </Text>
              <Pressable
                onPress={() =>
                  void Share.share({
                    message: `Luxóre · ${data.vehicles.find((car) => car.id === data.vehicleId)?.plate || ''}\n${shopping.map((item) => `${item.quantity} × ${item.name}`).join('\n')}`,
                  })
                }
              >
                <Text style={s.link}>Einkaufsliste mitnehmen / teilen</Text>
              </Pressable>
              {shopping.length > 0 && (
                <SwipeAction
                  label="Einkauf komplett eingeräumt"
                  busy={busy}
                  disabled={dirty || !data.initialized}
                  onComplete={() =>
                    void save(
                      'restock',
                      Object.fromEntries(
                        shopping.map((item) => [item.id, item.quantity]),
                      ),
                    )
                  }
                />
              )}
            </View>
            <Text style={s.heading}>
              {data.initialized
                ? 'Gezählten Bestand bearbeiten'
                : 'Anfangsbestand erfassen'}
            </Text>
            <Text style={s.detail}>
              Kühlschrank: {usage.drink} / 24 Kühlplätze · Snacks: {usage.snack}{' '}
              / {draft.snackCapacity} Plätze. Größere Flaschen benötigen mehrere
              Kühlplätze.
            </Text>
            <Text style={s.eyebrow}>SNACKPLÄTZE</Text>
            <TextInput
              accessibilityLabel="Snackkapazität"
              keyboardType="number-pad"
              value={String(draft.snackCapacity)}
              editable={!busy}
              style={s.input}
              onChangeText={(text) => {
                setDirty(true);
                setDraft({
                  ...draft,
                  snackCapacity: Number(text.replace(/\D/g, '')),
                });
              }}
            />
            {menu.map((item) => (
              <View key={item.id} style={s.item}>
                <Text style={s.heading}>{item.name}</Text>
                <Text style={s.detail}>{item.detail}</Text>
                <View style={s.fields}>
                  {(['count', 'target', 'minimum', 'slots'] as const).map(
                    (field) => (
                      <View style={s.field} key={field}>
                        <Text style={s.eyebrow}>
                          {field === 'count'
                            ? 'IST'
                            : field === 'target'
                              ? 'SOLL'
                              : field === 'minimum'
                                ? 'SCHWELLE'
                                : 'PLATZ'}
                        </Text>
                        <TextInput
                          accessibilityLabel={`${item.name} ${field}`}
                          keyboardType="number-pad"
                          maxLength={3}
                          editable={!busy}
                          style={s.input}
                          value={String(draft.items[item.id][field])}
                          onChangeText={(text) => {
                            setDirty(true);
                            setDraft({
                              ...draft,
                              items: {
                                ...draft.items,
                                [item.id]: {
                                  ...draft.items[item.id],
                                  [field]: Number(text.replace(/\D/g, '')),
                                },
                              },
                            });
                          }}
                        />
                      </View>
                    ),
                  )}
                </View>
                {data.initialized && (
                  <View style={s.personal}>
                    <Text style={s.detail}>Eigenverbrauch · Stückzahl</Text>
                    <TextInput
                      keyboardType="number-pad"
                      maxLength={2}
                      editable={!busy && !dirty}
                      style={[s.input, { width: 66 }]}
                      accessibilityLabel={`${item.name} Eigenverbrauch`}
                      value={String(quantities[item.id] || 0)}
                      onChangeText={(text) =>
                        setQuantities({
                          ...quantities,
                          [item.id]: Number(text.replace(/\D/g, '')),
                        })
                      }
                    />
                  </View>
                )}
              </View>
            ))}
            <TextInput
              value={note}
              onChangeText={setNote}
              maxLength={160}
              editable={!busy}
              style={s.input}
              placeholder="Grund der Zählung / Korrektur"
              accessibilityLabel="Grund der Bestandskorrektur"
            />
            <SwipeAction
              label="Gezählten Bestand speichern"
              busy={busy}
              disabled={!dirty && data.initialized}
              onComplete={() => void save('save')}
            />
            {data.initialized && (
              <SwipeAction
                label="Eigenverbrauch dokumentieren"
                busy={busy}
                disabled={
                  dirty || !Object.values(quantities).some((value) => value > 0)
                }
                onComplete={() =>
                  void save(
                    'personal',
                    Object.fromEntries(
                      Object.entries(quantities).filter(
                        ([, value]) => value > 0,
                      ),
                    ),
                  )
                }
              />
            )}
            <Text style={s.heading}>Letzte Bestandsbewegungen</Text>
            {data.movements.slice(0, 8).map((movement, index) => (
              <View key={index} style={s.item}>
                <Text style={s.heading}>
                  {movement.actor_name} · {movement.kind}
                </Text>
                <Text style={s.detail}>
                  {movement.note} ·{' '}
                  {new Date(movement.created_at).toLocaleString('de-DE')}
                </Text>
              </View>
            ))}
          </>
        )}
        {!!error && (
          <Text style={s.error} accessibilityRole="alert">
            {error}
          </Text>
        )}
        <Pressable
          disabled={busy}
          onPress={() => confirmDiscard(() => void load())}
        >
          <Text style={s.link}>Aktuellen Bestand neu laden</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  content: { padding: 24, gap: 18, paddingBottom: 40 },
  eyebrow: {
    color: '#aa8345',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.2,
  },
  title: {
    color: '#161a20',
    fontSize: 32,
    fontWeight: '600',
    letterSpacing: -1,
  },
  heading: { color: '#161a20', fontSize: 15, fontWeight: '600' },
  detail: { color: '#7b7d80', fontSize: 13, lineHeight: 21 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  chip: {
    padding: 12,
    borderWidth: 1,
    borderColor: '#eee7dc',
    borderRadius: 16,
    gap: 6,
  },
  active: { backgroundColor: '#faf4e8', borderColor: '#c8b48f' },
  card: { backgroundColor: '#fcf7ed', padding: 19, borderRadius: 24, gap: 14 },
  item: { paddingVertical: 15, gap: 12 },
  fields: { flexDirection: 'row', gap: 10 },
  field: { flex: 1, gap: 7 },
  input: {
    borderWidth: 1,
    borderColor: '#e9e3d8',
    borderRadius: 13,
    padding: 13,
    minHeight: 49,
    fontSize: 16,
    color: '#161a20',
  },
  personal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  link: {
    color: '#aa8345',
    fontWeight: '600',
    fontSize: 14,
    paddingVertical: 9,
  },
  error: { color: '#ac493b', fontSize: 13, lineHeight: 20 },
});
