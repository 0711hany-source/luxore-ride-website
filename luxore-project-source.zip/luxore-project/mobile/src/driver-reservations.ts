// Reservierungen, Kundenbewertung und Profilbild in der Fahrer-App. Reine
// Logik ohne React Native, damit Tests sie direkt laden können. Regeln,
// Fristen und Meldungen kommen vom Server; hier wird nur gelesen, geprüft und
// für die Anzeige aufbereitet.
import {
  euros,
  featurePendingText,
  isRouteMissing,
  tripStamp,
} from './operator-platform.ts';

const record = (value: unknown): value is Record<string, unknown> =>
  !!value && typeof value === 'object' && !Array.isArray(value);
const amount = (value: unknown): value is number =>
  typeof value === 'number' && Number.isFinite(value);
const text = (value: unknown): value is string => typeof value === 'string';
const optionalText = (value: unknown) => value == null || text(value);

// ------------------------------------------------------------ Bewertung --

export type RiderRating = { average: number; count: number };
export const isRating = (value: unknown): value is RiderRating =>
  record(value) &&
  amount(value.average) &&
  value.average >= 1 &&
  value.average <= 5 &&
  amount(value.count) &&
  value.count >= 1;
const comma = (value: number) => value.toFixed(1).replace('.', ',');
const ratingCount = (count: number) =>
  `${count} ${count === 1 ? 'Bewertung' : 'Bewertungen'}`;
/** „★ 4,5 (2 Bewertungen)“ – ohne Bewertung der ruhige Ersatztext. */
export const ratingText = (
  rating: RiderRating | null | undefined,
  empty = 'Noch keine Bewertung',
) => (rating ? `★ ${comma(rating.average)} (${ratingCount(rating.count)})` : empty);
export const ratingLabel = (
  rating: RiderRating | null | undefined,
  empty = 'Noch keine Bewertung',
) =>
  rating
    ? `Bewertung ${comma(rating.average)} von 5 aus ${ratingCount(rating.count)}`
    : empty;

// -------------------------------------------------------- Reservierungen --

export type ReservationCard = {
  id: string;
  pickup: string;
  destination: string;
  scheduledAt: number;
  distanceMeters: number;
  durationSeconds: number;
  price: number;
  service: string;
  className: string;
  capacity: string;
  wishes: string[];
  boardOrder: string | null;
  /** Nur in der offenen Liste: überschneidet sich mit einer eigenen. */
  conflict?: boolean;
};
export type OwnReservation = ReservationCard & {
  assignedAt: number;
  releaseUntil: number;
  riderName: string | null;
  riderPhone: string | null;
  riderRating: RiderRating | null;
  /** Warum die Zuteilung Aufmerksamkeit braucht (Satz des Servers). */
  check?: string | null;
  /** Name und Telefon sind zurückgehalten (nicht freigegeben/gesperrt). */
  contactHidden?: boolean;
};
export type ReservationBoard = {
  ready: boolean;
  reason: string | null;
  open: ReservationCard[];
  mine: OwnReservation[];
  rules: { releaseMinutes: number; bufferMinutes: number };
  serverTime: number;
};
const card = (value: unknown): value is ReservationCard =>
  record(value) &&
  text(value.id) &&
  !!value.id &&
  text(value.pickup) &&
  text(value.destination) &&
  amount(value.scheduledAt) &&
  amount(value.distanceMeters) &&
  amount(value.durationSeconds) &&
  amount(value.price) &&
  text(value.className) &&
  text(value.capacity) &&
  Array.isArray(value.wishes) &&
  value.wishes.every(text) &&
  optionalText(value.boardOrder);
const own = (value: unknown): value is OwnReservation =>
  card(value) &&
  amount((value as Record<string, unknown>).releaseUntil) &&
  optionalText((value as Record<string, unknown>).riderName) &&
  optionalText((value as Record<string, unknown>).riderPhone) &&
  optionalText((value as Record<string, unknown>).check) &&
  ['undefined', 'boolean'].includes(
    typeof (value as Record<string, unknown>).contactHidden,
  ) &&
  ((value as Record<string, unknown>).riderRating == null ||
    isRating((value as Record<string, unknown>).riderRating));
/** Eine Antwort in unerwarteter Form wird nie angezeigt. */
export function isReservationBoard(value: unknown): value is ReservationBoard {
  return (
    record(value) &&
    typeof value.ready === 'boolean' &&
    optionalText(value.reason) &&
    Array.isArray(value.open) &&
    value.open.every(card) &&
    Array.isArray(value.mine) &&
    value.mine.every(own) &&
    record(value.rules) &&
    amount(value.rules.releaseMinutes) &&
    amount(value.rules.bufferMinutes) &&
    amount(value.serverTime)
  );
}

export type BoardView = 'open' | 'mine';
export const boardOptions = (board: ReservationBoard) =>
  [
    { key: 'open', label: `Offen (${board.open.length})` },
    { key: 'mine', label: `Meine (${board.mine.length})` },
  ] as const;
/** „Mo., 16.11., 14:05 Uhr“ in Frankfurter Zeit. */
export const reservationWhen = (at: number) => tripStamp(at) + ' Uhr';
export const kilometres = (metres: number) =>
  (metres / 1000).toLocaleString('de-DE', { maximumFractionDigits: 1 }) + ' km';
export function driveTime(seconds: number) {
  const total = Math.max(1, Math.round(seconds / 60));
  return total < 60
    ? `${total} Min.`
    : `${Math.floor(total / 60)} Std. ${total % 60} Min.`;
}
export const routeFacts = (r: ReservationCard) =>
  `${kilometres(r.distanceMeters)} · ${driveTime(r.durationSeconds)}`;
export const classFacts = (r: ReservationCard) =>
  [r.className, r.capacity && `bis zu ${r.capacity}`].filter(Boolean).join(' · ');
export const reservationPrice = (r: ReservationCard) => euros(r.price);
/** Vorlesetext einer Karte: alles, was die Liste zeigt, in einem Satz. */
export const reservationLabel = (r: ReservationCard) =>
  [
    reservationWhen(r.scheduledAt),
    `von ${r.pickup} nach ${r.destination}`,
    routeFacts(r),
    reservationPrice(r),
    classFacts(r),
  ].join(', ');

/**
 * Abgeben ist bis zur Frist des Servers möglich. Verglichen wird mit der
 * Serverzeit plus der seither vergangenen Zeit – eine falsch gehende Uhr des
 * Handys ändert nichts; endgültig entscheidet ohnehin der Server.
 */
export const mayRelease = (
  r: OwnReservation,
  serverTime: number,
  elapsedMs = 0,
) => serverTime + Math.max(0, elapsedMs) < r.releaseUntil;
export const conflictText = (board: ReservationBoard) =>
  `Überschneidet sich mit einer Reservierung, die du schon übernommen hast (Fahrzeit plus ${board.rules.bufferMinutes} Minuten Abstand).`;
export const claimHint = (board: ReservationBoard) =>
  `Mit dem Übernehmen ist diese Fahrt fest dir zugeteilt. Der Fahrgast sieht deinen Namen, dein Fahrzeug und dein Profilbild. Abgeben kannst du bis ${board.rules.releaseMinutes} Minuten vor der Abholung.`;
export const releaseClosedText = (board: ReservationBoard) =>
  `Abgeben ist nur bis ${board.rules.releaseMinutes} Minuten vor der Abholung möglich. Bitte wende dich an deine Flottenleitung.`;
export const contactHiddenText =
  'Name und Telefonnummer des Fahrgasts siehst du wieder, sobald das geklärt ist.';
export const claimedText =
  'Übernommen. Die Reservierung steht jetzt unter „Meine“.';
export const releasedText = 'Abgegeben. Die Reservierung ist wieder offen.';
export const offerFirstText =
  '15 Minuten vor der Abholung bekommst du das Fahrtangebot zuerst. Sei dann online – sonst geht die Fahrt an einen anderen Fahrer.';
export const claimBody = (id: string) => ({ action: 'claim', id });
export const releaseBody = (id: string) => ({ action: 'release', id });
/** Nur Ziffern und ein führendes Plus; sonst wird nicht gewählt. */
export function phoneLink(phone: string | null | undefined) {
  const digits = (phone || '').replace(/[^+\d]/g, '');
  return /^\+?\d{5,20}$/.test(digits) ? 'tel:' + digits : null;
}

export type ActionNotice = { tone: 'info' | 'error'; title: string; text: string };
const status = (error: unknown) =>
  (error as { status?: unknown } | null)?.status;
/**
 * Meldung nach „Übernehmen“/„Abgeben“. Ein 409 (schon vergeben,
 * Überschneidung, Frist vorbei) und ein 404 (nicht mehr sichtbar) sind
 * gewöhnliche Antworten und bleiben ruhig; der Satz kommt vom Server.
 */
export function actionNotice(
  action: 'claim' | 'release',
  error: unknown,
): ActionNotice {
  const text =
    (error as Error | null)?.message ||
    'Anfrage fehlgeschlagen. Bitte erneut versuchen.';
  if (isRouteMissing(error))
    return { tone: 'info', title: 'Bald verfügbar', text: featurePendingText };
  if (status(error) === 409 || status(error) === 404)
    return {
      tone: 'info',
      title: action === 'claim' ? 'Nicht übernommen' : 'Nicht abgegeben',
      text,
    };
  return { tone: 'error', title: 'Das hat nicht geklappt', text };
}
/** Zeile der Einstiegskarte im Fahrerbereich. */
export const boardSummary = (board: ReservationBoard) =>
  `${board.open.length} offen · ${board.mine.length} übernommen`;

// ----------------------------------------------- Fahrgast bewerten (Fahrer) --

export const ratingCommentMax = 300;
export const ratingWindowMs = 14 * 24 * 3600e3;
export const starValues = [1, 2, 3, 4, 5] as const;
const validStars = (value: unknown): value is number =>
  typeof value === 'number' && Number.isInteger(value) && value >= 1 && value <= 5;
/** „3 von 5 Sternen“ */
export const starsLabel = (stars: number) =>
  `${stars} von 5 ${stars === 1 ? 'Stern' : 'Sternen'}`;
export const starsShown = (stars: number) =>
  '★'.repeat(stars) + '☆'.repeat(5 - stars);
export const sendLabel = (stars: number) =>
  `${stars} ${stars === 1 ? 'Stern' : 'Sterne'} abgeben`;
/** Schon vergebene Sterne aus `GET driver` (`ratings`); 0 = noch keine. */
export function givenStars(ratings: unknown, bookingId: string) {
  const value =
    record(ratings) && Object.hasOwn(ratings, bookingId)
      ? ratings[bookingId]
      : null;
  return validStars(value) ? value : 0;
}
/** Bewertung des Fahrgasts aus `GET driver` (`riderRatings`), geprüft. */
export function riderRatingOf(ratings: unknown, bookingId: string) {
  const value =
    record(ratings) && Object.hasOwn(ratings, bookingId)
      ? ratings[bookingId]
      : null;
  return isRating(value) ? value : null;
}
/** Eingabe nur für abgeschlossene Fahrten innerhalb der Frist des Servers. */
export const canRate = (completedAt: number | null | undefined, now: number) =>
  amount(completedAt) && completedAt > 0 && now - completedAt <= ratingWindowMs;
export function ratingProblem(stars: number, comment: string): string | null {
  if (!validStars(stars)) return 'Bitte 1 bis 5 Sterne vergeben.';
  if (comment.trim().length > ratingCommentMax)
    return `Der Kommentar darf höchstens ${ratingCommentMax} Zeichen haben.`;
  return null;
}
export function ratingBody(bookingId: string, stars: number, comment: string) {
  const note = comment.trim();
  return { bookingId, stars, ...(note ? { comment: note } : {}) };
}
export const isRatingSaved = (
  value: unknown,
): value is { ok: true; stars: number } =>
  record(value) && value.ok === true && validStars(value.stars);
export const ratingErrorText = (error: unknown) =>
  isRouteMissing(error)
    ? featurePendingText
    : (error as Error | null)?.message ||
      'Speichern fehlgeschlagen. Bitte erneut versuchen.';

// ------------------------------------------------------------- Profilbild --

/** Wortgleich mit dem Pflichtpunkt des Servers (`lib/mobility/profile.ts`). */
export const profileMissingText = 'Profilbild fehlt';
/** Ältere Server senden das Feld nicht; dann gibt es keinen Hinweis. */
export const knowsProfilePhoto = (value: unknown) =>
  record(value) && 'profilePhotoId' in value;
/** Bild-ID aus `GET compliance`/`GET driver`; alles andere gilt als „fehlt“. */
export const profilePhotoId = (value: unknown) => {
  const id = record(value) ? value.profilePhotoId : null;
  return text(id) && /^[A-Za-z0-9_-]{1,60}$/.test(id) ? id : null;
};
/**
 * Quelle für das eigene Profilbild. Der Server liefert es nur mit Anmeldung;
 * die Sitzung steht deshalb im Kopf der Anfrage, nie in der Adresse.
 */
export const profilePhotoSource = (origin: string, id: string, token: string) => ({
  uri: `${origin}/api/mobility/images?id=${encodeURIComponent(id)}`,
  headers: {
    Authorization: 'Bearer ' + token,
    'X-Luxore-Client': 'native-v1',
  },
});
