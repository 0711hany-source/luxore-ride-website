import { useCallback, useEffect, useRef, useState } from 'react';
import { AppState } from 'react-native';
import { driverVariant as isDriver, designPreview } from './build-config';
import { registerDriverPush, unregisterDriverPush } from './driver-push';
import {
  cacheProfile,
  cachedProfile,
  forgetDeviceData,
  forgetSession,
  NativeTimeoutError,
  nativeApi,
  saveSession,
  storedSession,
  type AccountState,
  type NativeAccount,
} from './account-client';
import { preferencesKey } from './DriverScreen';
import { bookingKey } from './booking-store';
import { boardKey } from './board-store';
import { fleetCreateKey } from './fleet-creation-store';
import { stateKey as offerAlertKey } from './offer-alert-policy';
import { pauseStatusMessage } from './pause-result';
import { ForegroundRefresh } from './foreground-refresh';
import {
  resumeLocation,
  stopLocation,
  type Position,
} from './location-service';

/** Wohin die App nach einem Wechsel der Anmeldung springt. */
export type SessionTargets = {
  /** Nach Anmeldung und Abmeldung: Startansicht, Verlauf leer. */
  home: () => void;
  /** Nach der Löschanfrage: Konto-Ansicht mit der Bestätigung. */
  account: () => void;
};

/**
 * Anmeldung der App: gespeicherte Sitzung, Profil, Abgleich mit dem Server
 * beim Start und bei jeder Rückkehr in den Vordergrund, Abmelden,
 * Kontolöschung und (Fahrer) Stand des Standortdienstes. Unverändert aus der
 * früheren App.tsx übernommen.
 */
export function useSession(targets: { current: SessionTargets }) {
  // Set when the embedded workspace was opened; every session change resets it.
  const [hasOpened, setHasOpened] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const tokenRef = useRef<string | null>(null);
  const [profile, setProfile] = useState<NativeAccount | null>(null);
  const [admin, setAdmin] = useState(false),
    [ready, setReady] = useState(false);
  const [loaded, setLoaded] = useState(false),
    [error, setError] = useState('');
  const [busy, setBusy] = useState(false),
    [tracking, setTracking] = useState(false);
  const [notice, setNotice] = useState('');
  const [position, setPosition] = useState<Position | null>(null);
  const foregroundRefresh = useRef(new ForegroundRefresh());
  const refresh = useCallback(async () => {
    const session = tokenRef.current;
    await foregroundRefresh.current.refresh(
      session,
      async () => {
        try {
          const r = await nativeApi<AccountState>('account', session);
          // An older response must not replace a newly verified session.
          if (session !== tokenRef.current) return;
          setProfile(r.account);
          setAdmin(r.isAdmin);
          setReady(r.registrationReady);
          setError('');
          if (session && r.account)
            void cacheProfile(session, r.account).catch(() => {});
          // Inactive unless this driver build was made with Firebase.
          if (isDriver && session && r.account) void registerDriverPush(session);
          if (session && !r.account) {
            setHasOpened(false);
            await forgetSession();
            tokenRef.current = null;
            setToken(null);
          }
        } catch (e) {
          if (session === tokenRef.current) setError((e as Error).message);
        } finally {
          setLoaded(true);
        }
      },
      isDriver
        ? async () => {
            const status = await resumeLocation().catch(() => null);
            if (status) {
              setTracking(status.active);
              if ('position' in status) setPosition(status.position || null);
            }
          }
        : undefined,
    );
  }, []);
  useEffect(() => {
    if (designPreview) {
      setLoaded(true);
      return;
    }
    let alive = true;
    void storedSession()
      .then(async (value) => {
        if (!alive) return;
        tokenRef.current = value;
        setToken(value);
        const cached = await cachedProfile(value);
        if (alive && tokenRef.current === value && cached) setProfile(cached);
        await refresh();
      })
      .catch(() => {
        if (alive) {
          setLoaded(true);
          setError(
            'Der geschützte Gerätespeicher ist nicht verfügbar. Bitte erneut starten.',
          );
        }
      });
    const state = AppState.addEventListener('change', (next) => {
      if (alive && next === 'active') void refresh();
    });
    return () => {
      alive = false;
      state.remove();
    };
  }, [refresh]);
  async function signedIn(value: {
    account: NativeAccount;
    sessionToken: string;
    isAdmin: boolean;
  }) {
    await saveSession(value.sessionToken);
    setHasOpened(false);
    tokenRef.current = value.sessionToken;
    setToken(value.sessionToken);
    await cacheProfile(value.sessionToken, value.account);
    setProfile(value.account);
    setAdmin(value.isAdmin);
    setError('');
    setNotice('');
    targets.current.home();
  }
  async function logout() {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      if (isDriver) await unregisterDriverPush(tokenRef.current);
      // Server refuses logout while a ride or unsettled driver payment is active.
      try {
        await nativeApi('account', tokenRef.current, { action: 'logout' });
      } catch (e) {
        if (isDriver) void registerDriverPush(tokenRef.current);
        throw e;
      }
      if (isDriver) await stopLocation();
      setHasOpened(false);
      await forgetSession();
      tokenRef.current = null;
      setToken(null);
      setProfile(null);
      setAdmin(false);
      setTracking(false);
      targets.current.home();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  // Same server action as „Löschung anfordern“ on luxoreride.de/konto: the
  // account is blocked and marked for deletion, every sign-in ends and
  // reserved rides are cancelled. The server refuses while a ride is active.
  async function deleteAccount() {
    if (busy) return;
    const session = tokenRef.current,
      accountId = profile?.id;
    if (!session || !accountId) return;
    setBusy(true);
    setError('');
    try {
      // Open board orders are stored per ride; collect their keys beforehand.
      const rides = isDriver
        ? []
        : await nativeApi<{ bookings?: { id: string }[] }>(
            'bookings',
            session,
            undefined,
            undefined,
            undefined,
            8000,
          )
            .then((r) => (Array.isArray(r.bookings) ? r.bookings : []))
            .catch(() => []);
      if (isDriver) await unregisterDriverPush(session);
      try {
        await nativeApi('account', session, {
          action: 'delete',
          confirmation: 'LÖSCHEN',
        });
      } catch (e) {
        if (isDriver) void registerDriverPush(session);
        throw e;
      }
      // The server sessions are gone now: always finish the local sign-out.
      if (isDriver) await stopLocation().catch(() => null);
      setHasOpened(false);
      await forgetDeviceData([
        bookingKey(accountId),
        fleetCreateKey(accountId),
        preferencesKey,
        offerAlertKey,
        ...rides
          .filter((ride) => typeof ride?.id === 'string')
          .map((ride) => boardKey(accountId, ride.id)),
      ]);
      await forgetSession().catch(() => {});
      if (tokenRef.current === session) {
        tokenRef.current = null;
        setToken(null);
        setProfile(null);
        setAdmin(false);
      }
      setTracking(false);
      setPosition(null);
      setNotice(
        'Deine Löschanfrage ist eingegangen. Dein Konto wurde gesperrt und alle Anmeldungen wurden beendet. Vorgemerkte Reservierungen wurden storniert. Wir bearbeiten die Löschung; gesetzlich aufzubewahrende Fahrt- und Zahlungsbelege bleiben erhalten.',
      );
      targets.current.account();
    } catch (e) {
      setError(
        e instanceof NativeTimeoutError
          ? 'Die Antwort des Servers steht noch aus. Bitte die Verbindung prüfen und die App erneut öffnen: Bist du dann abgemeldet, ist die Löschanfrage eingegangen. Sonst bitte erneut bestätigen.'
          : (e as Error).message,
      );
    } finally {
      setBusy(false);
    }
  }
  async function pauseTracking() {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      const result = await stopLocation();
      setHasOpened(false);
      setTracking(false);
      setPosition(null);
      if (result?.serverStopped !== true) setError(pauseStatusMessage(result));
    } catch {
      setError(
        'Die Ortung konnte nicht beendet werden. Bitte Standortfreigabe in den Systemeinstellungen prüfen.',
      );
    } finally {
      setBusy(false);
    }
  }
  return {
    token,
    tokenRef,
    profile,
    admin,
    ready,
    loaded,
    error,
    busy,
    tracking,
    notice,
    position,
    hasOpened,
    setHasOpened,
    refresh,
    signedIn,
    logout,
    deleteAccount,
    pauseTracking,
  };
}
