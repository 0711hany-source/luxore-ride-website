import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';
import * as SecureStore from 'expo-secure-store';
import { Alert } from 'react-native';
import { offerAlerts, alertStatus, requestAlerts } from './offer-alerts';
import { parseLocationAlertUpdate } from './offer-alert-policy';
import { freshNativePosition } from './position-cache';
import { LocationLifecycle } from './location-lifecycle';
import { PermissionMissingError, stepDeadline } from './location-request';
import { isIos, platformText } from './platform-text';
import { acceptFix, usableFix } from '../../app/mobility/gps-quality';
import {
  travelTelemetry,
  type TravelTelemetry,
} from '../../lib/mobility/gps-telemetry';
export const locationOrigin = 'https://luxoreride.de';
const taskName = 'luxore-driver-location-v1';
const storageKey = 'luxore-driver-location-session';
const positionKey = 'luxore-driver-background-position';
const lifecycle = new LocationLifecycle();
const queueStepMs = 8000;
export type Credential = {
  sessionId: string;
  nativeToken: string;
  expiresAt: number;
};
export type Position = TravelTelemetry & {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
};
export const point = (location: Location.LocationObject): Position => ({
  ...travelTelemetry(location.coords),
  lat: location.coords.latitude,
  lng: location.coords.longitude,
  accuracy: location.coords.accuracy ?? 9999,
  timestamp: location.timestamp,
});
async function credential(): Promise<Credential | null> {
  const raw = await SecureStore.getItemAsync(storageKey);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as Credential;
  } catch {
    return null;
  }
}
function deliveryAllowed(
  version: number,
  expected: Credential,
  current: Credential | null,
) {
  // Evaluate version/intent after the asynchronous credential read has settled.
  return (
    lifecycle.canDeliver(version) &&
    current?.sessionId === expected.sessionId &&
    current.nativeToken === expected.nativeToken &&
    current.expiresAt > Date.now()
  );
}
async function post(c: Credential, body: object) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    return await fetch(`${locationOrigin}/api/mobility/location`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${c.nativeToken}`,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timeout);
  }
}
export async function stopLocation(
  notifyServer = true,
  expectedSession?: string,
  expectedVersion?: number,
) {
  if (!expectedSession) lifecycle.begin();
  const result = await lifecycle.run(async () => {
    const errors: unknown[] = [];
    let c: Credential | null = null;
    try {
      c = await credential();
    } catch (error) {
      // A conditional old request must verify its target before any mutation.
      if (expectedSession) throw error;
      errors.push(error);
    }
    if (
      expectedSession &&
      (c?.sessionId !== expectedSession || !lifecycle.current(expectedVersion!))
    )
      return null;
    if (expectedSession) lifecycle.begin();
    const attempt = async (work: () => Promise<unknown>) => {
      try {
        await work();
      } catch (error) {
        errors.push(error);
      }
    };
    // Revoke first, but a failed storage step must not skip native shutdown.
    // Every native step is bounded: one hung call must not block the queue
    // (and with it every later start or pause) until the app is restarted.
    await attempt(() =>
      stepDeadline(
        'Der Gerätespeicher',
        SecureStore.deleteItemAsync(storageKey),
        queueStepMs,
      ),
    );
    await attempt(() =>
      stepDeadline(
        'Der Gerätespeicher',
        SecureStore.deleteItemAsync(positionKey),
        queueStepMs,
      ),
    );
    await stepDeadline(
      'Benachrichtigungen',
      offerAlerts.clear(),
      queueStepMs,
    ).catch(() => {});
    let shouldStop = true;
    try {
      shouldStop = await stepDeadline(
        platformText.locationService,
        Location.hasStartedLocationUpdatesAsync(taskName),
        queueStepMs,
      );
    } catch (error) {
      errors.push(error);
    }
    if (shouldStop)
      await attempt(() =>
        stepDeadline(
          platformText.locationService,
          Location.stopLocationUpdatesAsync(taskName),
          queueStepMs,
        ),
      );
    return { credential: c, errors };
  });
  // Use only the credential captured for this stop, outside the mutation lock.
  // Local failures cannot suppress the existing best-effort server revocation.
  let serverStopped: boolean | null = notifyServer ? false : null;
  if (result?.credential && notifyServer) {
    try {
      const response = await post(result.credential, { action: 'stop' });
      serverStopped = response.ok && (await response.json())?.ok === true;
    } catch {
      // A completed local stop is not a confirmed server-side offline state.
      // Do not restore credentials or automatically repeat a mutating request.
    }
  }
  if (result?.errors.length) throw result.errors[0];
  if (result) return { active: false as const, serverStopped };
}
async function deliver(locations: Location.LocationObject[]) {
  const version = lifecycle.version;
  if (!lifecycle.canDeliver(version)) return;
  const c = await credential();
  if (!c || !lifecycle.canDeliver(version)) return;
  if (c.expiresAt <= Date.now()) {
    await stopLocation(true, c.sessionId, version);
    return;
  }
  // Persist a fresh native fix before upload: waking the cockpit never has to
  // wait for a new one-shot GPS query, including after a renderer restart.
  const p = await lifecycle.run(async (): Promise<Position | null> => {
    if (!deliveryAllowed(version, c, await credential())) return null;
    const now = Date.now();
    let previous: Position | null = null;
    try {
      const cached = JSON.parse(
        (await SecureStore.getItemAsync(positionKey)) || 'null',
      );
      if (cached?.sessionId === c.sessionId && usableFix(cached.position, now))
        previous = cached.position;
    } catch {}
    // Background batches and foreground callbacks share the same raw-fix
    // filter and cache lock. A bad final sample cannot hide an earlier good one.
    let accepted: Position | null = null;
    for (const candidate of locations
      .map(point)
      .sort((a, b) => a.timestamp - b.timestamp)) {
      if (!acceptFix(accepted || previous, candidate, now)) continue;
      accepted = candidate;
    }
    if (!accepted || !deliveryAllowed(version, c, await credential()))
      return null;
    await SecureStore.setItemAsync(
      positionKey,
      JSON.stringify({ sessionId: c.sessionId, position: accepted }),
    );
    return accepted;
  });
  if (!p || !deliveryAllowed(version, c, await credential())) return;
  const startedAt = Date.now();
  const response = await post(c, p);
  if (response.ok) {
    const reply = parseLocationAlertUpdate(await response.json());
    if (reply)
      await offerAlerts.sync(
        c.sessionId,
        reply,
        Date.now() - startedAt,
        async () => {
          return deliveryAllowed(version, c, await credential());
        },
      );
  }
  if (response.status === 401 || response.status === 409) {
    // An old in-flight request must never stop a newly started shift.
    if ((await credential())?.sessionId === c.sessionId)
      await stopLocation(false, c.sessionId, version);
  }
}
// The native cockpit feeds the same capability-bound service as the background
// task. No cookies, embedded renderer, or second driver heartbeat is involved.
export async function deliverForeground(location: Location.LocationObject) {
  await deliver([location]);
}
TaskManager.defineTask<{ locations: Location.LocationObject[] }>(
  taskName,
  async ({ data, error }) => {
    if (error || !data?.locations) return;
    // Network loss does not stop tracking; the next fresh fix retries without replaying a stale queue.
    await deliver(data.locations).catch(() => {});
  },
);
export async function locationStatus() {
  const version = lifecycle.version;
  const c = await credential();
  // Notification availability must not turn a valid GPS shift into a failed one.
  const alerts = await alertStatus().catch(() => ({
    enabled: false,
    sound: false,
    unavailable: true,
  }));
  if (!c || !lifecycle.canDeliver(version)) return { active: false, alerts };
  const permissions = await Location.getBackgroundPermissionsAsync();
  if (
    !lifecycle.canDeliver(version) ||
    c.expiresAt <= Date.now() ||
    !permissions.granted ||
    !(await Location.hasStartedLocationUpdatesAsync(taskName))
  ) {
    return { active: false, alerts };
  }
  let position: Position | null = null;
  try {
    const cached = JSON.parse(
      (await SecureStore.getItemAsync(positionKey)) || 'null',
    );
    if (cached?.sessionId === c.sessionId)
      position = freshNativePosition(cached.position);
  } catch {}
  if (!deliveryAllowed(version, c, await credential()))
    return { active: false, alerts };
  return {
    active: true,
    sessionId: c.sessionId,
    expiresAt: c.expiresAt,
    alerts,
    position,
  };
}
// Recovery runs only after returning to the foreground, with existing permissions.
export async function resumeLocation() {
  const version = lifecycle.version;
  await lifecycle.run(async () => {
    const c = await credential();
    if (!c || c.expiresAt <= Date.now() || !lifecycle.canDeliver(version))
      return;
    const permission = await stepDeadline(
      'Die Prüfung der Hintergrund-Standortfreigabe',
      Location.getBackgroundPermissionsAsync(),
      queueStepMs,
    );
    if (!permission.granted || !lifecycle.current(version)) return;
    if (
      !(await stepDeadline(
        platformText.locationService,
        Location.hasStartedLocationUpdatesAsync(taskName),
        queueStepMs,
      )) &&
      lifecycle.current(version)
    )
      await stepDeadline(
        platformText.locationService,
        Location.startLocationUpdatesAsync(taskName, backgroundOptions),
        20_000,
      );
  });
  return locationStatus();
}
const backgroundOptions: Location.LocationTaskOptions = {
  accuracy: Location.Accuracy.BestForNavigation,
  timeInterval: 5000,
  distanceInterval: 0,
  deferredUpdatesInterval: 0,
  pausesUpdatesAutomatically: false,
  // iOS only; Android receives exactly the options it always had: car
  // navigation profile and the blue status bar marker that tells the driver
  // the shift is still sharing the location.
  ...(isIos && {
    activityType: Location.ActivityType.AutomotiveNavigation,
    showsBackgroundLocationIndicator: true,
  }),
  foregroundService: {
    notificationTitle: 'LUXORÉ Driver · Standort aktiv',
    notificationBody:
      'Deine Schicht läuft. Zum Beenden in LUXORÉ Driver „Pause machen“ wählen.',
    notificationColor: '#b99a60',
    killServiceOnDestroy: false,
  },
};
/** Reads the permission without ever opening a system dialog. */
export async function foregroundGranted() {
  const permission = await stepDeadline(
    'Die Prüfung der Standortfreigabe',
    Location.getForegroundPermissionsAsync(),
  );
  return permission.granted;
}
export const FOREGROUND_MISSING =
  'Standortfreigabe fehlt. Bitte den genauen Standort für LUXORÉ Driver erlauben.';
export async function foregroundPermission() {
  // Interactive on first use; otherwise it answers at once.
  const permission = await stepDeadline(
    'Die Standortfreigabe',
    Location.requestForegroundPermissionsAsync(),
    60_000,
  );
  if (!permission.granted)
    throw new PermissionMissingError(
      'Bitte den genauen Standort für LUXORÉ Driver erlauben.',
    );
}
/**
 * „Immer zulassen“. Android 11+ shows no dialog for it: the request opens the
 * system settings and answers when the driver returns. After an earlier refusal
 * it answers at once without opening anything, so the caller offers the settings.
 * iOS shows its own „Immer erlauben“ prompt once (after „Beim Verwenden“ was
 * granted) and afterwards answers at once; the same settings fallback applies.
 */
export async function backgroundPermission(signal?: AbortSignal) {
  let background = await stepDeadline(
    'Die Prüfung der Hintergrund-Standortfreigabe',
    Location.getBackgroundPermissionsAsync(),
  );
  if (background.granted) return;
  const accepted = await new Promise<boolean>((resolve) => {
    // A dialog Android never shows must not hold the shift start forever.
    signal?.addEventListener('abort', () => resolve(false), { once: true });
    if (signal?.aborted) return resolve(false);
    Alert.alert(
      'Standort während deiner Schicht',
      platformText.backgroundAlert,
      [
        { text: 'Abbrechen', style: 'cancel', onPress: () => resolve(false) },
        { text: 'Weiter', onPress: () => resolve(true) },
      ],
      { cancelable: false },
    );
  });
  if (!accepted)
    throw new Error(
      'Hintergrundstandort wurde nicht aktiviert. Du bleibst offline.',
    );
  // Opens the Android settings page; give the driver time to choose.
  background = await stepDeadline(
    'Die Hintergrund-Standortfreigabe',
    Location.requestBackgroundPermissionsAsync(),
    120_000,
  );
  if (!background.granted)
    throw new PermissionMissingError(
      platformText.backgroundMissing,
    );
}
export async function startLocation(c: Credential) {
  const version = lifecycle.begin();
  if (
    !/^[a-f0-9]{64}$/.test(c.nativeToken) ||
    typeof c.sessionId !== 'string' ||
    !Number.isFinite(c.expiresAt) ||
    c.expiresAt <= Date.now()
  )
    throw new Error('Ungültige Standortfreigabe. Bitte erneut online gehen.');
  await foregroundPermission();
  await backgroundPermission();
  // Denied alarms already permit tracking. A native alarm API failure has the
  // same isolation: status reports unavailable, while real GPS errors still fail.
  await stepDeadline('Benachrichtigungen', requestAlerts(), 60_000).catch(
    () => {},
  );
  try {
    const transition = lifecycle.run(async () => {
      const requireCurrent = () => {
        if (!lifecycle.current(version))
          throw new Error('Die Standortfreigabe wurde inzwischen beendet.');
      };
      requireCurrent();
      await stepDeadline('Benachrichtigungen', offerAlerts.clear(), 8000).catch(
        () => {},
      );
      requireCurrent();
      await stepDeadline(
        'Der Gerätespeicher',
        SecureStore.deleteItemAsync(positionKey),
      );
      requireCurrent();
      await stepDeadline(
        'Der Gerätespeicher',
        SecureStore.setItemAsync(storageKey, JSON.stringify(c)),
      );
      requireCurrent();
      await stepDeadline(
        platformText.locationService,
        Location.startLocationUpdatesAsync(taskName, backgroundOptions),
        20_000,
        () => {
          // Started after we gave up: never leave an unowned service running.
          if (!lifecycle.canDeliver(version))
            void Location.stopLocationUpdatesAsync(taskName).catch(() => {});
        },
      ).catch((error) => {
        // Android 12+ refuses a foreground service while the app is not visible.
        if (/foreground service/i.test(String((error as Error)?.message)))
          throw new Error(
            /manifest/i.test((error as Error).message)
              ? platformText.serviceManifestMissing
              : platformText.serviceNeedsForeground,
          );
        throw error;
      });
      // An already-started native call may finish, but it cannot confirm an old
      // transition or launch its initial query after a newer pause/start.
      requireCurrent();
      lifecycle.activate(version);
    });
    // Also covers an earlier native call that still occupies the queue.
    await stepDeadline('Der Standortdienst', transition, 45_000);
    void Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High })
      .then((p) => {
        // A one-shot query may settle after pause, credential renewal or a new
        // shift. Never bind that old result to whatever capability exists now.
        if (lifecycle.current(version)) return deliver([p]);
      })
      .catch(() => {});
  } catch (error) {
    await stepDeadline(
      'Das Beenden des Standortdienstes',
      stopLocation(true, c.sessionId, version),
      25_000,
    );
    throw error;
  }
  return stepDeadline('Der Standortstatus', locationStatus(), 15_000);
}
