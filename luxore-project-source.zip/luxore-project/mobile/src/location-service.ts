import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';
import * as SecureStore from 'expo-secure-store';
import { Alert } from 'react-native';
import { offerAlerts, alertStatus, requestAlerts } from './offer-alerts';
import { parseAlertReply } from './offer-alert-policy';
import { freshNativePosition } from './position-cache';
import { LocationLifecycle } from './location-lifecycle';
import {
  travelTelemetry,
  type TravelTelemetry,
} from '../../lib/mobility/gps-telemetry';
export const locationOrigin =
  'https://luxore-ride-frankfurt.lucky-goose-6238.chatgpt.site';
const taskName = 'luxore-driver-location-v1';
const storageKey = 'luxore-driver-location-session';
const positionKey = 'luxore-driver-background-position';
const lifecycle = new LocationLifecycle();
export type Credential = {
  sessionId: string;
  nativeToken: string;
  expiresAt: number;
};
export type Position = TravelTelemetry & {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
};
export const point = (location: Location.LocationObject): Position => ({
  ...travelTelemetry(location.coords),
  lat: location.coords.latitude,
  lng: location.coords.longitude,
  accuracy: location.coords.accuracy ?? 9999,
  timestamp: location.timestamp,
});
async function credential(): Promise<Credential | null> {
  const raw = await SecureStore.getItemAsync(storageKey);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as Credential;
  } catch {
    return null;
  }
}
async function post(c: Credential, body: object) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    return await fetch(`${locationOrigin}/api/mobility/location`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${c.nativeToken}`,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timeout);
  }
}
export async function stopLocation(
  notifyServer = true,
  expectedSession?: string,
  expectedVersion?: number,
) {
  if (!expectedSession) lifecycle.begin();
  const c = await lifecycle.run(async () => {
    const c = await credential();
    if (
      expectedSession &&
      (c?.sessionId !== expectedSession || !lifecycle.current(expectedVersion!))
    )
      return null;
    if (expectedSession) lifecycle.begin();
    // Clear the capability first: queued callbacks may no longer send locations.
    await SecureStore.deleteItemAsync(storageKey);
    await SecureStore.deleteItemAsync(positionKey);
    await offerAlerts.clear().catch(() => {});
    if (await Location.hasStartedLocationUpdatesAsync(taskName))
      await Location.stopLocationUpdatesAsync(taskName);
    return c;
  });
  if (c && notifyServer) await post(c, { action: 'stop' }).catch(() => {});
}
async function deliver(locations: Location.LocationObject[]) {
  const version = lifecycle.version;
  const c = await credential();
  if (!c) return;
  if (c.expiresAt <= Date.now()) {
    await stopLocation(true, c.sessionId, version);
    return;
  }
  const latest = locations.reduce<Location.LocationObject | null>(
    (a, b) => (!a || b.timestamp > a.timestamp ? b : a),
    null,
  );
  if (!latest) return;
  const p = point(latest);
  if (Date.now() - p.timestamp > 30000 || p.accuracy > 100) return;
  // Persist a fresh native fix before upload: waking the WebView never has to
  // wait for a new one-shot GPS query, including after a renderer restart.
  await lifecycle.run(async () => {
    if (
      !lifecycle.current(version) ||
      (await credential())?.sessionId !== c.sessionId
    )
      return;
    const previous = await SecureStore.getItemAsync(positionKey);
    let previousTime = 0;
    try {
      previousTime = JSON.parse(previous || 'null')?.position?.timestamp || 0;
    } catch {}
    if (p.timestamp > previousTime)
      await SecureStore.setItemAsync(
        positionKey,
        JSON.stringify({ sessionId: c.sessionId, position: p }),
      );
  });
  if (
    !lifecycle.current(version) ||
    (await credential())?.sessionId !== c.sessionId
  )
    return;
  const startedAt = Date.now();
  const response = await post(c, p);
  if (response.ok) {
    const reply = parseAlertReply(await response.json());
    if (reply)
      await offerAlerts.sync(
        c.sessionId,
        reply,
        Date.now() - startedAt,
        async () => {
          const current = await credential();
          return (
            current?.sessionId === c.sessionId && current.expiresAt > Date.now()
          );
        },
      );
  }
  if (response.status === 401 || response.status === 409) {
    // An old in-flight request must never stop a newly started shift.
    if ((await credential())?.sessionId === c.sessionId)
      await stopLocation(false, c.sessionId, version);
  }
}
TaskManager.defineTask<{ locations: Location.LocationObject[] }>(
  taskName,
  async ({ data, error }) => {
    if (error || !data?.locations) return;
    // Network loss does not stop tracking; the next fresh fix retries without replaying a stale queue.
    await deliver(data.locations).catch(() => {});
  },
);
export async function locationStatus() {
  const c = await credential();
  const alerts = await alertStatus();
  if (!c) return { active: false, alerts };
  const permissions = await Location.getBackgroundPermissionsAsync();
  if (
    c.expiresAt <= Date.now() ||
    !permissions.granted ||
    !(await Location.hasStartedLocationUpdatesAsync(taskName))
  ) {
    return { active: false, alerts };
  }
  let position: Position | null = null;
  try {
    const cached = JSON.parse(
      (await SecureStore.getItemAsync(positionKey)) || 'null',
    );
    if (cached?.sessionId === c.sessionId)
      position = freshNativePosition(cached.position);
  } catch {}
  return {
    active: true,
    sessionId: c.sessionId,
    expiresAt: c.expiresAt,
    alerts,
    position,
  };
}
// Recovery runs only after returning to the foreground, with existing permissions.
export async function resumeLocation() {
  const version = lifecycle.version;
  await lifecycle.run(async () => {
    const c = await credential();
    if (!c || c.expiresAt <= Date.now() || !lifecycle.current(version)) return;
    const permission = await Location.getBackgroundPermissionsAsync();
    if (!permission.granted || !lifecycle.current(version)) return;
    if (
      !(await Location.hasStartedLocationUpdatesAsync(taskName)) &&
      lifecycle.current(version)
    )
      await Location.startLocationUpdatesAsync(taskName, backgroundOptions);
  });
  return locationStatus();
}
const backgroundOptions: Location.LocationTaskOptions = {
  accuracy: Location.Accuracy.BestForNavigation,
  timeInterval: 5000,
  distanceInterval: 0,
  deferredUpdatesInterval: 0,
  pausesUpdatesAutomatically: false,
  foregroundService: {
    notificationTitle: 'Luxóre Driver · Standort aktiv',
    notificationBody:
      'Deine Schicht läuft. Zum Beenden in Luxóre Driver „Pause machen“ wählen.',
    notificationColor: '#b89658',
    killServiceOnDestroy: false,
  },
};
export async function foregroundPermission() {
  const permission = await Location.requestForegroundPermissionsAsync();
  if (!permission.granted)
    throw new Error('Bitte den genauen Standort für Luxóre Driver erlauben.');
}
export async function startLocation(c: Credential) {
  const version = lifecycle.begin();
  if (
    !/^[a-f0-9]{64}$/.test(c.nativeToken) ||
    typeof c.sessionId !== 'string' ||
    !Number.isFinite(c.expiresAt) ||
    c.expiresAt <= Date.now()
  )
    throw new Error('Ungültige Standortfreigabe. Bitte erneut online gehen.');
  await foregroundPermission();
  let background = await Location.getBackgroundPermissionsAsync();
  if (!background.granted) {
    const accepted = await new Promise<boolean>((resolve) =>
      Alert.alert(
        'Standort während deiner Schicht',
        'Luxóre Driver überträgt deinen Standort auch bei gesperrtem Bildschirm und während der Navigation, damit Fahrgast und Disposition dich sehen. Wähle in den Einstellungen „Immer zulassen“. Mit „Pause machen“ endet die Übertragung.',
        [
          { text: 'Abbrechen', style: 'cancel', onPress: () => resolve(false) },
          { text: 'Weiter', onPress: () => resolve(true) },
        ],
        { cancelable: false },
      ),
    );
    if (!accepted)
      throw new Error(
        'Hintergrundstandort wurde nicht aktiviert. Du bleibst offline.',
      );
    background = await Location.requestBackgroundPermissionsAsync();
  }
  if (!background.granted)
    throw new Error(
      'Bitte unter App-Berechtigungen → Standort „Immer zulassen“ wählen und erneut online gehen.',
    );
  await requestAlerts();
  try {
    await lifecycle.run(async () => {
      if (!lifecycle.current(version))
        throw new Error('Die Standortfreigabe wurde inzwischen beendet.');
      await offerAlerts.clear().catch(() => {});
      await SecureStore.deleteItemAsync(positionKey);
      await SecureStore.setItemAsync(storageKey, JSON.stringify(c));
      await Location.startLocationUpdatesAsync(taskName, backgroundOptions);
    });
    void Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High })
      .then((p) => deliver([p]))
      .catch(() => {});
  } catch (error) {
    await stopLocation(true, c.sessionId, version);
    throw error;
  }
  return locationStatus();
}
