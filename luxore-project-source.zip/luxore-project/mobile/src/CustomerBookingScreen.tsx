import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import {
  ActivityIndicator,
  AppState,
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import {
  CalendarDays,
  Check,
  ChevronRight,
  LocateFixed,
  MapPin,
  Minus,
  Plus,
} from 'lucide-react-native';
import * as Location from 'expo-location';
import { classes } from '../../lib/ride-domain';
import {
  statusNames,
  type Point,
  type Service,
} from '../../lib/mobility/domain';
import {
  menu,
  allowance,
  cartPrice as refreshmentPrice,
} from '../../lib/mobility/refreshments';
import {
  preferenceOptions,
  type RidePreferences,
} from '../../lib/mobility/ride-preferences';
import { nativeApi, type NativeAccount } from './account-client';
import { bookingStore } from './booking-store';
import { CustomerBookingController } from './customer-booking';
import NativeAddressPicker from './NativeAddressPicker';
import SwipeAction from './SwipeAction';
import { euros } from './driver-model';
const ink = '#161a20',
  gold = '#aa8345';
const cars = {
  // oxlint-disable-next-line typescript/no-require-imports -- Metro bundles the static asset.
  premium: require('../assets/business.png'),
  // oxlint-disable-next-line typescript/no-require-imports -- Metro bundles the static asset.
  first: require('../assets/first-class.png'),
  // oxlint-disable-next-line typescript/no-require-imports -- Metro bundles the static asset.
  van: require('../assets/van.png'),
};
function reservation(day: string, time: string) {
  if (!/^\d{2}\.\d{2}\.\d{4}$/.test(day) || !/^\d{2}:\d{2}$/.test(time))
    return null;
  const [d, m, y] = day.split('.').map(Number),
    [h, min] = time.split(':').map(Number);
  const date = new Date(y, m - 1, d, h, min);
  return date.getFullYear() === y &&
    date.getMonth() === m - 1 &&
    date.getDate() === d &&
    date.getHours() === h &&
    date.getMinutes() === min
    ? date.getTime()
    : null;
}
export default function CustomerBookingScreen({
  token,
  profile,
  active,
  planned = false,
  onTrips,
  onLive,
}: {
  token: string;
  profile: NativeAccount;
  active: boolean;
  planned?: boolean;
  onTrips: () => void;
  onLive: () => void;
}) {
  'use no memo'; // Lifecycle and GPS use native imperative handles.
  const [initialProfile] = useState(profile);
  const controller = useMemo(
    () =>
      new CustomerBookingController(
        {
          quote: (body, signal) =>
            nativeApi('quote', token, body, undefined, signal),
          book: (body) => nativeApi('bookings', token, body),
        },
        bookingStore(initialProfile.id),
        initialProfile,
      ),
    [token, initialProfile],
  );
  const state = useSyncExternalStore(
    controller.subscribe,
    controller.getSnapshot,
    controller.getSnapshot,
  );
  const visible = useRef(active);
  const [picker, setPicker] = useState<'pickup' | 'destination' | null>(null),
    [day, setDay] = useState(''),
    [time, setTime] = useState('');
  const [locating, setLocating] = useState(false),
    [locationError, setLocationError] = useState('');
  const locationRevision = useRef(0);
  useEffect(() => {
    visible.current = active;
    controller.setActive(active && AppState.currentState === 'active');
    if (!active) {
      locationRevision.current++;
      queueMicrotask(() => {
        if (!visible.current) {
          setLocating(false);
          setPicker(null);
        }
      });
    }
  }, [active, controller]);
  useEffect(() => {
    void controller.restore();
    const subscription = AppState.addEventListener('change', (value) => {
      controller.setActive(visible.current && value === 'active');
      if (value !== 'active') {
        locationRevision.current++;
        setLocating(false);
      }
    });
    return () => {
      // oxlint-disable-next-line react-hooks/exhaustive-deps -- Generation counter, not a DOM ref.
      locationRevision.current++;
      subscription.remove();
      controller.setActive(false);
    };
  }, [controller]);
  useEffect(() => {
    if (active && planned && !state.restoring)
      controller.setDeparture('reservation', reservation(day, time));
  }, [active, planned, state.restoring, controller, day, time]);
  const locked =
    state.restoring || state.submitting || !!state.pending || !!state.booking;
  function setDate(nextDay: string, nextTime: string) {
    setDay(nextDay);
    setTime(nextTime);
    controller.setDeparture('reservation', reservation(nextDay, nextTime));
  }
  async function locate() {
    if (locating || locked || !active) return;
    const revision = ++locationRevision.current;
    setLocating(true);
    setLocationError('');
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      const task = (async () => {
        const permission = await Location.requestForegroundPermissionsAsync();
        if (permission.status !== 'granted')
          throw new Error(
            'Standortfreigabe fehlt. Du kannst den Abholort als Adresse auswählen.',
          );
        if (revision !== locationRevision.current) return null;
        const point = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.High,
        });
        if (revision !== locationRevision.current) return null;
        return nativeApi<{ results: Point[] }>('places', token, {
          kind: 'location',
          lat: point.coords.latitude,
          lng: point.coords.longitude,
        });
      })();
      const result = await Promise.race([
        task,
        new Promise<never>((_, reject) => {
          timer = setTimeout(
            () =>
              reject(
                new Error(
                  'GPS dauert zu lange. Bitte erneut versuchen oder eine Adresse auswählen.',
                ),
              ),
            20000,
          );
        }),
      ]);
      if (revision === locationRevision.current && result) {
        if (result.results.length !== 1)
          throw new Error('Abholort konnte nicht bestätigt werden.');
        controller.selectPlace('pickup', result.results[0]);
      }
    } catch (error) {
      if (revision === locationRevision.current)
        setLocationError((error as Error).message);
    } finally {
      if (timer) clearTimeout(timer);
      if (revision === locationRevision.current) {
        locationRevision.current++;
        setLocating(false);
      }
    }
  }
  const extras = refreshmentPrice(state.refreshments, state.service);
  const tier = classes.find((c) => c.id === state.service)!;
  return (
    <KeyboardAvoidingView
      style={s.root}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={s.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <Text style={s.eyebrow}>DEINE NÄCHSTE ANKUNFT</Text>
        <Text style={s.title}>
          {state.booking
            ? 'Deine Anfrage ist angekommen.'
            : 'Wohin darf es gehen?'}
        </Text>
        {state.restoring ? (
          <>
            <ActivityIndicator color={gold} />
            <Pressable onPress={() => void controller.restore()}>
              <Text style={s.link}>Gespeicherte Anfrage erneut prüfen</Text>
            </Pressable>
          </>
        ) : state.booking ? (
          <>
            <Text style={s.section}>{statusNames[state.booking.status]}</Text>
            <Text style={s.label}>{state.booking.route.destination.label}</Text>
            <Text style={s.detail}>
              {state.booking.status === 'reserved'
                ? 'Reservierung vorgemerkt. Erst mit Fahrerzusage bestätigt.'
                : state.booking.status === 'unavailable'
                  ? 'Aktuell ist kein passender Fahrer verfügbar.'
                  : 'Der tatsächliche Status steht unter deinen Fahrten.'}
            </Text>
            <Text style={s.price}>{euros(state.booking.price)}</Text>
            <Pressable
              accessibilityRole="button"
              onPress={onTrips}
              style={s.primary}
            >
              <Text style={s.primaryText}>Status & Fahrtdetails</Text>
              <ChevronRight color="#fff" size={20} />
            </Pressable>
            <Pressable
              accessibilityRole="button"
              onPress={() => controller.newDraft()}
              disabled={state.submitting}
            >
              <Text style={s.link}>Eine weitere Fahrt planen</Text>
            </Pressable>
            <Pressable
              accessibilityRole="button"
              onPress={onLive}
              style={s.row}
            >
              <MapPin color={gold} size={21} />
              <Text style={s.link}>Live-Karte öffnen</Text>
            </Pressable>
          </>
        ) : state.pending ? (
          <>
            <Text style={s.section}>Anfrage noch nicht bestätigt</Text>
            <Text style={s.label}>{state.pending.destination}</Text>
            <Text style={s.detail}>
              Die Antwort fehlt. Bestätige dieselbe Anfrage erneut; deine Klasse
              und Buchungsnummer bleiben erhalten.
            </Text>
            <SwipeAction
              label="Dieselbe Anfrage bestätigen"
              busy={state.submitting}
              onComplete={() => void controller.submit()}
            />
          </>
        ) : (
          <>
            <View style={s.row}>
              {(['now', 'reservation'] as const).map((mode) => (
                <Pressable
                  key={mode}
                  accessibilityRole="button"
                  accessibilityState={{ selected: state.mode === mode }}
                  disabled={locked}
                  onPress={() =>
                    controller.setDeparture(
                      mode,
                      mode === 'reservation' ? reservation(day, time) : null,
                    )
                  }
                  style={[s.mode, state.mode === mode && s.selected]}
                >
                  <Text style={s.label}>
                    {mode === 'now' ? 'Jetzt fahren' : 'Reservieren'}
                  </Text>
                </Pressable>
              ))}
            </View>
            {state.mode === 'reservation' && (
              <View style={s.group}>
                <View style={s.row}>
                  <CalendarDays size={20} color={gold} />
                  <Text style={s.section}>Deine Abholzeit</Text>
                </View>
                <View style={s.row}>
                  <TextInput
                    accessibilityLabel="Abholdatum"
                    placeholder="TT.MM.JJJJ"
                    keyboardType="numbers-and-punctuation"
                    value={day}
                    onChangeText={(v) => setDate(v, time)}
                    maxLength={10}
                    style={s.input}
                  />
                  <TextInput
                    accessibilityLabel="Abholzeit"
                    placeholder="HH:MM"
                    keyboardType="numbers-and-punctuation"
                    value={time}
                    onChangeText={(v) => setDate(day, v)}
                    maxLength={5}
                    style={s.input}
                  />
                </View>
                <Text style={s.detail}>
                  Lokale Uhrzeit · 30 Minuten bis 90 Tage im Voraus
                </Text>
              </View>
            )}
            {(['pickup', 'destination'] as const).map((key) => (
              <Pressable
                key={key}
                accessibilityRole="button"
                accessibilityLabel={
                  key === 'pickup' ? 'Abholort auswählen' : 'Ziel auswählen'
                }
                disabled={locked}
                onPress={() => setPicker(key)}
                style={s.place}
              >
                <MapPin size={22} color={gold} />
                <View style={s.flex}>
                  <Text style={s.eyebrow}>
                    {key === 'pickup' ? 'ABHOLORT' : 'ZIEL'}
                  </Text>
                  <Text style={s.label}>
                    {state[key]?.label || 'Adresse auswählen'}
                  </Text>
                </View>
                <ChevronRight size={20} color={ink} />
              </Pressable>
            ))}
            <Pressable
              accessibilityRole="button"
              disabled={locked || locating}
              onPress={() => void locate()}
              style={s.row}
            >
              <LocateFixed size={21} color={gold} />
              <Text style={s.link}>
                {locating
                  ? 'Standort wird gesucht …'
                  : 'Meinen Standort als Abholort verwenden'}
              </Text>
            </Pressable>
            {!!locationError && (
              <Text accessibilityRole="alert" style={s.error}>
                {locationError}
              </Text>
            )}
            <Pressable
              accessibilityRole="button"
              disabled={locked || state.loading || locating}
              onPress={() => void controller.calculate()}
              style={s.primary}
            >
              <Text style={s.primaryText}>
                {state.loading
                  ? 'Route wird berechnet …'
                  : state.quote
                    ? 'Route neu berechnen'
                    : 'Route & Preise ansehen'}
              </Text>
              {state.loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <ChevronRight color="#fff" size={20} />
              )}
            </Pressable>
            {state.quote && (
              <>
                <Text style={s.detail}>
                  {(state.quote.distanceMeters / 1000).toFixed(1)} km · etwa{' '}
                  {Math.ceil(state.quote.durationSeconds / 60)} Minuten ·{' '}
                  {state.quote.mode === 'reservation'
                    ? 'Reservierung'
                    : 'Jetzt fahren'}
                </Text>
                {classes.map((c) => (
                  <Pressable
                    key={c.id}
                    accessibilityRole="button"
                    accessibilityLabel={c.name}
                    accessibilityState={{ selected: state.service === c.id }}
                    disabled={locked}
                    onPress={() =>
                      controller.setDetails({ service: c.id as Service })
                    }
                    style={[s.tier, state.service === c.id && s.tierSelected]}
                  >
                    <Image
                      source={cars[c.id]}
                      style={s.car}
                      resizeMode="contain"
                    />
                    <View style={s.flex}>
                      <Text style={s.section}>{c.name}</Text>
                      <Text style={s.detail}>{c.capacity}</Text>
                      <Text style={s.detail}>
                        {euros(c.perKm)} / km · mindestens 15 €
                      </Text>
                    </View>
                    <Text style={s.price}>
                      {euros(state.quote!.prices[c.id])}
                    </Text>
                  </Pressable>
                ))}
                <Text style={s.section}>Für deinen Komfort</Text>
                {(
                  Object.keys(preferenceOptions) as (keyof RidePreferences)[]
                ).map((key) => (
                  <View style={s.group} key={key}>
                    <Text style={s.detail}>
                      {key === 'temperature'
                        ? 'Temperatur'
                        : key === 'conversation'
                          ? 'Gespräch'
                          : 'Musik'}
                    </Text>
                    <View style={s.options}>
                      {Object.entries(preferenceOptions[key]).map(
                        ([value, label]) => (
                          <Pressable
                            key={value}
                            accessibilityRole="button"
                            accessibilityLabel={label + ' · ' + key}
                            accessibilityState={{
                              selected: state.preferences[key] === value,
                            }}
                            disabled={locked}
                            onPress={() =>
                              controller.setDetails({
                                preferences: {
                                  ...state.preferences,
                                  [key]: value,
                                },
                              })
                            }
                            style={[
                              s.option,
                              state.preferences[key] === value && s.selected,
                            ]}
                          >
                            <Text style={s.small}>{label}</Text>
                          </Pressable>
                        ),
                      )}
                    </View>
                  </View>
                ))}
                <Text style={s.section}>Deine Bordkarte</Text>
                <Text style={s.detail}>
                  {tier.name}: {allowance[state.service].drink} Getränke und{' '}
                  {allowance[state.service].snack} Snacks inklusive. Weitere
                  Getränke 2,50 €, Snacks 1,50 €. Nach Verfügbarkeit; berechnet
                  werden nur tatsächlich ausgegebene Artikel.
                </Text>
                <View style={s.menu}>
                  {menu.map((item) => (
                    <View key={item.id} style={s.product}>
                      <Image
                        source={{
                          uri:
                            'https://luxoreride.de/board-products/' +
                            item.id +
                            '.png',
                        }}
                        style={s.productImage}
                        resizeMode="contain"
                      />
                      <Text style={s.label}>{item.name}</Text>
                      <Text style={s.detail}>{item.detail}</Text>
                      <View style={s.row}>
                        <Pressable
                          accessibilityLabel={item.name + ' entfernen'}
                          disabled={locked || !state.refreshments[item.id]}
                          style={s.quantity}
                          onPress={() =>
                            controller.setDetails({
                              refreshments: {
                                ...state.refreshments,
                                [item.id]: Math.max(
                                  0,
                                  (state.refreshments[item.id] || 0) - 1,
                                ),
                              },
                            })
                          }
                        >
                          <Minus color={ink} size={20} />
                        </Pressable>
                        <Text>{state.refreshments[item.id] || 0}</Text>
                        <Pressable
                          accessibilityLabel={item.name + ' hinzufügen'}
                          disabled={
                            locked || (state.refreshments[item.id] || 0) >= 12
                          }
                          style={s.quantity}
                          onPress={() =>
                            controller.setDetails({
                              refreshments: {
                                ...state.refreshments,
                                [item.id]:
                                  (state.refreshments[item.id] || 0) + 1,
                              },
                            })
                          }
                        >
                          <Plus color={ink} size={20} />
                        </Pressable>
                      </View>
                    </View>
                  ))}
                </View>
                <Text style={s.section}>Wer fährt mit?</Text>
                <TextInput
                  accessibilityLabel="Fahrgastname"
                  style={s.input}
                  value={state.riderName}
                  maxLength={80}
                  editable={!locked}
                  onChangeText={(riderName) =>
                    controller.setDetails({ riderName })
                  }
                />
                <TextInput
                  accessibilityLabel="Telefonnummer"
                  style={s.input}
                  value={state.riderPhone}
                  maxLength={30}
                  editable={!locked}
                  keyboardType="phone-pad"
                  onChangeText={(riderPhone) =>
                    controller.setDetails({ riderPhone })
                  }
                />
                <View style={s.row}>
                  <Check size={19} color={gold} />
                  <Text style={[s.detail, s.flex]}>
                    Zahlung beim Fahrer · Deine Nummer erhält der zugewiesene
                    Fahrer für die Abholung.
                  </Text>
                </View>
                <Text style={s.price}>
                  Fahrt {euros(state.quote.prices[state.service])}
                </Text>
                <Text style={s.detail}>
                  Bordkarte bei vollständiger Ausgabe zusätzlich {euros(extras)}
                  . Das Streckenangebot ist fünf Minuten gültig.
                </Text>
                <SwipeAction
                  label={
                    state.mode === 'reservation'
                      ? 'Reservierung anfragen'
                      : 'Fahrt anfragen'
                  }
                  disabled={locked || locating}
                  busy={state.submitting}
                  onComplete={() => void controller.submit()}
                />
              </>
            )}
          </>
        )}
        {!!state.error && (
          <Text accessibilityRole="alert" style={s.error}>
            {state.error}
          </Text>
        )}
      </ScrollView>
      <NativeAddressPicker
        visible={active && !!picker && !locked}
        token={token}
        title={picker === 'pickup' ? 'Abholort' : 'Ziel'}
        initialQuery={picker ? state[picker]?.label || '' : ''}
        onClose={() => setPicker(null)}
        onSelected={(point) => {
          if (picker) controller.selectPlace(picker, point);
          setPicker(null);
        }}
      />
    </KeyboardAvoidingView>
  );
}
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  content: { padding: 24, gap: 20, paddingBottom: 40 },
  eyebrow: { fontSize: 10, letterSpacing: 1.6, fontWeight: '700', color: gold },
  title: { fontSize: 30, lineHeight: 36, fontWeight: '600', color: ink },
  section: { fontSize: 16, fontWeight: '600', color: ink },
  label: { fontSize: 15, lineHeight: 22, color: ink },
  detail: { fontSize: 12, lineHeight: 19, color: '#737984' },
  small: { fontSize: 12, color: ink },
  price: { fontSize: 20, fontWeight: '600', color: ink },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  flex: { flex: 1, minWidth: 0, gap: 5 },
  group: { gap: 10 },
  mode: {
    flex: 1,
    paddingVertical: 15,
    alignItems: 'center',
    borderRadius: 24,
    borderWidth: 1,
    borderColor: '#ede6db',
  },
  selected: { backgroundColor: '#fbf5e9', borderColor: gold },
  place: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#d1bd97',
  },
  link: {
    fontSize: 13,
    lineHeight: 21,
    fontWeight: '600',
    color: gold,
    flexShrink: 1,
  },
  primary: {
    minHeight: 56,
    borderRadius: 28,
    paddingHorizontal: 22,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: ink,
  },
  primaryText: { fontSize: 15, fontWeight: '600', color: '#fff' },
  input: {
    minHeight: 52,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#c9b48a',
    fontSize: 16,
    color: ink,
    flex: 1,
    minWidth: 0,
  },
  tier: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    gap: 10,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: '#ede6db',
  },
  tierSelected: { borderColor: ink, borderWidth: 2 },
  car: { width: 70, height: 50 },
  options: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  option: {
    minHeight: 42,
    paddingHorizontal: 12,
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#ede6db',
    borderRadius: 21,
  },
  menu: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  product: {
    width: '48%',
    padding: 12,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#eee5d6',
    gap: 8,
  },
  productImage: { height: 65, width: '100%' },
  quantity: {
    height: 40,
    width: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  error: { fontSize: 14, lineHeight: 22, color: '#a13b34' },
});
