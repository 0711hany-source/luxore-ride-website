import React, { Suspense, useState } from 'react';
import { ActivityIndicator, Pressable, Text, View } from 'react-native';
import type { PointMapProps } from './PointMap';
const load = () => import('./NativePointMapView');
class Boundary extends React.Component<
  { children: React.ReactNode; retry: () => void; onError: () => void },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch() {
    this.props.onError();
  }
  render() {
    return this.state.failed ? (
      <View style={{ flex: 1, justifyContent: 'center', padding: 24 }}>
        <Text>Die Karte konnte nicht gestartet werden.</Text>
        <Pressable accessibilityRole="button" onPress={this.props.retry}>
          <Text style={{ padding: 20, color: '#aa8345' }}>
            Kartenmodul erneut laden
          </Text>
        </Pressable>
      </View>
    ) : (
      this.props.children
    );
  }
}
export default function PointMap(
  props: PointMapProps & { loader?: typeof load },
) {
  const [attempt, setAttempt] = useState(() => ({
    key: 0,
    Component: React.lazy(props.loader || load),
  }));
  if (!props.active || !props.token) return null;
  const Component = attempt.Component;
  return (
    <Boundary
      key={attempt.key}
      onError={props.onError}
      retry={() =>
        setAttempt((v) => ({
          key: v.key + 1,
          Component: React.lazy(props.loader || load),
        }))
      }
    >
      <Suspense
        fallback={
          <View style={{ flex: 1, justifyContent: 'center' }}>
            <ActivityIndicator color="#aa8345" />
          </View>
        }
      >
        <Component {...props} />
      </Suspense>
    </Boundary>
  );
}
