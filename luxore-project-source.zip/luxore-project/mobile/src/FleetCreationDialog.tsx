import React from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ShieldCheck, Users, X } from 'lucide-react-native';
import SwipeAction from './SwipeAction';
import {
  availableFleetOwners,
  type FleetCreateState,
  type FleetCreationController,
} from './fleet-creation';
export default function FleetCreationDialog({
  controller,
  state,
  open,
  active,
  now,
  onClose,
}: {
  controller: FleetCreationController;
  state: FleetCreateState;
  open: boolean;
  active: boolean;
  now: number;
  onClose: () => void;
}) {
  const locked =
    !state.restored || !!state.pending || state.busy || !!state.confirmed;
  const owners = state.data ? availableFleetOwners(state.data) : [];
  const ownerId = state.pending?.ownerId || state.ownerId;
  const saved =
    state.pending &&
    state.data?.fleets.find((f) => f.id === state.pending?.requestId);
  return (
    <Modal
      visible={open && active}
      animationType="slide"
      presentationStyle="fullScreen"
      onRequestClose={onClose}
    >
      <SafeAreaView style={s.root} edges={['top', 'bottom']}>
        <KeyboardAvoidingView
          style={s.root}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <View style={s.header}>
            <Text style={s.heading}>Neue Flotte</Text>
            <Pressable
              accessibilityLabel="Flottengründung schließen"
              onPress={onClose}
              hitSlop={12}
            >
              <X color={ink} size={24} />
            </Pressable>
          </View>
          <ScrollView
            contentContainerStyle={s.content}
            keyboardShouldPersistTaps="handled"
          >
            <ShieldCheck color={gold} size={38} />
            <Text style={s.title}>Deine neue Flotte.</Text>
            <Text style={s.muted}>
              Name und Besitzer bestimmen. Bestehende Fahrzeuge und Mitarbeiter
              behalten ihre Zuordnung.
            </Text>
            <Text style={s.heading}>Flottenname</Text>
            <TextInput
              accessibilityLabel="Name der neuen Flotte"
              placeholder="Zum Beispiel Luxóre · Berlin"
              maxLength={100}
              value={state.pending?.name || state.name}
              editable={!locked}
              onChangeText={(name) => controller.edit(name, state.ownerId)}
              style={s.input}
            />
            <Text style={s.heading}>Besitzer</Text>
            <Text style={s.muted}>
              Ein noch nicht zugeordnetes Profil wählen. Eine bestehende Leitung
              oder laufende Schicht bleibt geschützt.
            </Text>
            {state.pending ? (
              <View style={s.card}>
                <Users color={gold} size={22} />
                <Text style={s.name}>
                  {state.data?.employees.find((e) => e.user_id === ownerId)
                    ?.name ||
                    (ownerId === state.data?.userId
                      ? 'Eigenes Betreiberprofil'
                      : 'Gespeicherte Besitzerwahl')}
                </Text>
              </View>
            ) : (
              owners.map((e) => (
                <Pressable
                  key={e.user_id}
                  accessibilityRole="radio"
                  accessibilityLabel={`Besitzer ${e.name || 'Ohne Namen'} auswählen`}
                  accessibilityState={{
                    checked: e.user_id === ownerId,
                    disabled: locked,
                  }}
                  disabled={locked}
                  onPress={() => controller.edit(state.name, e.user_id)}
                  style={[s.card, e.user_id === ownerId && s.selected]}
                >
                  <Users color={gold} size={22} />
                  <View style={s.grow}>
                    <Text style={s.name}>{e.name || 'Ohne Namen'}</Text>
                    <Text style={s.muted}>
                      {e.user_id === state.data?.userId
                        ? 'Eigenes Betreiberprofil'
                        : 'Ohne Flottenzuordnung'}
                    </Text>
                  </View>
                </Pressable>
              ))
            )}
            {!state.pending && state.data && !owners.length && (
              <Text style={s.muted}>
                Kein passendes freies Profil vorhanden. Bereits zugeordnete
                Besitzer können keine zweite Flotte erhalten.
              </Text>
            )}
            {!!state.pending && !state.confirmed && (
              <Text style={s.muted}>
                Diese Geräteanfrage ist noch offen. Name und Besitzer bleiben
                fest. Beim erneuten Bestätigen wird dieselbe Anfrage verwendet.
              </Text>
            )}
            {!!saved &&
              (saved.name !== state.pending?.name ||
                saved.owner_id !== state.pending?.ownerId) && (
                <Text style={s.error}>
                  Der aktuelle Serverstand zeigt eine geänderte Flotte „
                  {saved.name}“. Bitte den bestehenden Stand prüfen.
                </Text>
              )}
            {!state.restored && (
              <Pressable
                accessibilityLabel="Gespeicherte Gründung erneut prüfen"
                onPress={() => void controller.restore()}
              >
                <Text style={s.refresh}>
                  Gespeicherte Anfrage erneut prüfen
                </Text>
              </Pressable>
            )}
            {state.loading && <ActivityIndicator color={gold} />}
            {!!state.loadError && (
              <Text accessibilityRole="alert" style={s.error}>
                {state.loadError}
              </Text>
            )}
            {!!state.error && (
              <Text accessibilityRole="alert" style={s.error}>
                {state.error}
              </Text>
            )}
            {!!state.notice && (
              <Text accessibilityRole="alert" style={s.notice}>
                {state.notice}
              </Text>
            )}
            {!!state.confirmed && (
              <View style={s.card}>
                <ShieldCheck color={gold} size={24} />
                <Text style={[s.name, s.grow]}>{state.confirmed.name}</Text>
              </View>
            )}
            {!!state.confirmed && !!state.pending && (
              <Pressable
                accessibilityLabel="Bestätigte Geräteanfrage abschließen"
                disabled={state.busy}
                onPress={() => void controller.finishConfirmed()}
              >
                <Text style={s.refresh}>Gerätespeicher erneut prüfen</Text>
              </Pressable>
            )}
            {!!state.confirmed && !state.pending && (
              <Pressable
                accessibilityLabel="Weitere Flotte vorbereiten"
                onPress={() => controller.reset()}
              >
                <Text style={s.refresh}>Weitere Flotte vorbereiten</Text>
              </Pressable>
            )}
          </ScrollView>
          <View style={s.footer}>
            <Pressable
              accessibilityLabel="Gründungszugang aktualisieren"
              disabled={state.busy || state.loading}
              onPress={() => void controller.refresh()}
            >
              <Text style={s.refresh}>
                {state.loading
                  ? 'Zugang wird geprüft …'
                  : 'Aktuellen Serverstand laden'}
              </Text>
            </Pressable>
            {state.discardable && !!state.pending && !state.confirmed && (
              <>
                <Text style={s.muted}>
                  Der Server hat die Anfrage abgelehnt. Du kannst die offene
                  Geräteanfrage beenden; bestehende Flotten bleiben erhalten.
                </Text>
                <SwipeAction
                  label="Offene Geräteanfrage beenden"
                  disabled={!controller.canDiscard(now)}
                  busy={state.busy}
                  onComplete={() => void controller.discard()}
                />
              </>
            )}
            {!state.confirmed && (
              <SwipeAction
                key={
                  (state.pending?.requestId ||
                    state.name + ':' + state.ownerId) + state.busy
                }
                label={
                  state.pending
                    ? 'Gleiche Gründung erneut bestätigen'
                    : 'Flotte gründen'
                }
                disabled={!controller.canSubmit(now)}
                busy={state.busy}
                onComplete={() => void controller.submit()}
              />
            )}
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </Modal>
  );
}
const ink = '#161a20',
  gold = '#aa8345';
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },
  header: {
    paddingHorizontal: 22,
    paddingVertical: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  content: { padding: 22, gap: 16, paddingBottom: 30 },
  title: { color: ink, fontSize: 32, fontWeight: '700' },
  heading: { color: ink, fontSize: 19, fontWeight: '600' },
  muted: { color: '#777e87', fontSize: 13, lineHeight: 20 },
  name: { color: ink, fontSize: 15, fontWeight: '600', lineHeight: 22 },
  input: {
    borderWidth: 1,
    borderColor: '#e6ded1',
    borderRadius: 17,
    padding: 17,
    color: ink,
    fontSize: 16,
  },
  card: {
    flexDirection: 'row',
    gap: 14,
    alignItems: 'center',
    padding: 17,
    borderRadius: 21,
    backgroundColor: '#fbf8f2',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  selected: { borderColor: gold },
  grow: { flex: 1, minWidth: 0 },
  error: { color: '#a04c40', fontSize: 13, lineHeight: 21 },
  notice: { color: '#347961', fontSize: 13, lineHeight: 21 },
  footer: { padding: 22, gap: 14, backgroundColor: '#fff' },
  refresh: { color: gold, fontSize: 13, fontWeight: '600' },
});
