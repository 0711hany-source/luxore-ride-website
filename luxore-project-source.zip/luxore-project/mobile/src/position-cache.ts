import {
  travelTelemetry,
  type TravelTelemetry,
} from '../../lib/mobility/gps-telemetry.ts';
export type CachedPosition = TravelTelemetry & {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
};
export function freshNativePosition(
  value: unknown,
  now = Date.now(),
): CachedPosition | null {
  if (!value || typeof value !== 'object') return null;
  const p = value as CachedPosition;
  if (
    ![p.lat, p.lng, p.accuracy, p.timestamp].every(Number.isFinite) ||
    Math.abs(p.lat) > 90 ||
    Math.abs(p.lng) > 180 ||
    p.accuracy < 0 ||
    p.accuracy > 100 ||
    now - p.timestamp > 10000 ||
    p.timestamp > now + 5000
  )
    return null;
  return {
    lat: p.lat,
    lng: p.lng,
    accuracy: p.accuracy,
    timestamp: p.timestamp,
    ...travelTelemetry(p),
  };
}
export function newestNativePosition(
  current: CachedPosition | null,
  next: unknown,
  now = Date.now(),
) {
  const fresh = freshNativePosition(next, now);
  return fresh && (!current || fresh.timestamp > current.timestamp)
    ? fresh
    : current;
}
