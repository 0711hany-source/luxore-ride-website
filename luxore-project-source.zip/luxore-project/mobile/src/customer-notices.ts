// Local ride notices of LUXORÉ Ride (no server push): shown by the app itself
// when the live view sees the ride change. Rules: customer-notice-policy.ts.
import * as Notifications from 'expo-notifications';
import * as SecureStore from 'expo-secure-store';
import { createNoticeTracker } from './customer-notice-policy';
import { isIos } from './platform-text';
export const rideChannelId = 'luxore-ride-status-v1';
const seenKey = 'luxore-ride-notices-v1';
const askedKey = 'luxore-ride-notice-asked-v1';
let prepared: Promise<void> | null = null;
/** Channel and foreground behaviour; safe to call often. */
function prepare() {
  prepared ??= (async () => {
    // Without a handler a notice would stay silent while the app is open.
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldPlaySound: true,
        shouldSetBadge: false,
        shouldShowBanner: true,
        shouldShowList: true,
        priority: Notifications.AndroidNotificationPriority.HIGH,
      }),
    });
    // Notification channels exist on Android only.
    if (isIos) return;
    await Notifications.setNotificationChannelAsync(rideChannelId, {
      name: 'Fahrtstatus',
      description: 'Hinweise zum Stand deiner Fahrt',
      importance: Notifications.AndroidImportance.HIGH,
      sound: 'default',
      enableVibrate: true,
      vibrationPattern: [0, 200, 120, 200],
      lockscreenVisibility: Notifications.AndroidNotificationVisibility.PRIVATE,
      bypassDnd: false,
    });
  })().catch(() => {
    prepared = null;
  });
  return prepared;
}
let asking: Promise<void> | null = null;
/**
 * Asks for the notification permission (Android 13+, iOS) at most once per
 * installation: when a booking is sent or the live view opens. A "no" is
 * respected – the app never asks again by itself.
 */
export function requestRideNotices(): Promise<void> {
  asking ??= (async () => {
    try {
      await prepare();
      const permission = await Notifications.getPermissionsAsync();
      if (permission.granted || !permission.canAskAgain) return;
      if (await SecureStore.getItemAsync(askedKey)) return;
      // Remembered before the dialog: an interrupted dialog is not repeated.
      await SecureStore.setItemAsync(askedKey, '1');
      await Notifications.requestPermissionsAsync();
    } catch {
      // No notices on this device; the live view works without them.
    }
  })();
  return asking;
}
export const rideNotices = createNoticeTracker({
  load: () => SecureStore.getItemAsync(seenKey),
  save: (raw) => SecureStore.setItemAsync(seenKey, raw),
  present: async (bookingId, event, text) => {
    await prepare();
    if (!(await Notifications.getPermissionsAsync()).granted) return;
    await Notifications.scheduleNotificationAsync({
      // One notice per ride: the newer state replaces the older one.
      identifier: 'luxore-ride-' + bookingId,
      content: {
        title: text.title,
        body: text.body,
        sound: 'default',
        priority: Notifications.AndroidNotificationPriority.HIGH,
        autoDismiss: true,
        data: { kind: 'luxore-ride-status', bookingId, event },
      },
      // `channelId` alone means „show now“; iOS ignores the channel.
      trigger: { channelId: rideChannelId },
    });
  },
});

/** A message of the chauffeur while the chat window is closed. Never throws. */
export async function chatNotice(text: string) {
  try {
    if (!(await Notifications.getPermissionsAsync()).granted) return;
    await Notifications.scheduleNotificationAsync({
      identifier: 'luxore-ride-chat',
      content: {
        title: 'Nachricht von deinem Chauffeur',
        body: text,
        sound: 'default',
        autoDismiss: true,
        data: { kind: 'luxore-chat' },
      },
      trigger: { channelId: rideChannelId },
    });
  } catch {
    /* The counter on the chat button still shows the message. */
  }
}
