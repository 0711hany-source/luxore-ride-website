// Screens, Tabs und Titel der beiden App-Varianten. Reine Daten ohne React
// Native, damit Tests sie direkt laden können.
import type { NavConfig } from './history';

export type Route =
  | 'home'
  | 'account'
  | 'workspace'
  | 'fleet'
  | 'operations'
  | 'invitations'
  | 'inventory'
  | 'navigation'
  | 'trips'
  | 'booking'
  | 'live'
  | 'design'
  // Betreiberplattform (Fahrer-App)
  | 'earnings'
  | 'compliance'
  | 'fleetIncome'
  | 'fleetCompliance'
  | 'photos'
  // Reservierungen für Fahrer (Fahrer-App)
  | 'reservations';

export type TabKey = 'start' | 'trips' | 'earnings' | 'fleet' | 'account';

export type AppTab = { key: TabKey; root: Route; label: string };

export type AppNavConfig = Omit<NavConfig, 'tabs'> & {
  tabs: readonly AppTab[];
};

/**
 * Kunde: Fahrt · Fahrten · Konto. Fahrer: Fahren · Umsatz · Flotte · Konto –
 * „Umsatz“ (eigene Einnahmen) nur mit Anmeldung, der Flotte-Tab nur für
 * angemeldete Flottenleiter und Betreiber; alle anderen erreichen die
 * Disposition wie bisher über den Eintrag im Konto-Tab.
 */
export function navConfig(input: {
  driver: boolean;
  signedIn: boolean;
  fleetRole: boolean;
}): AppNavConfig {
  if (!input.driver)
    return {
      tabs: [
        { key: 'start', root: 'home', label: 'Fahrt' },
        { key: 'trips', root: 'trips', label: 'Fahrten' },
        { key: 'account', root: 'account', label: 'Konto' },
      ],
      // Buchung und Sonderpfade gehören zum Tab „Fahrt“, auch wenn sie aus
      // „Fahrten“ heraus geöffnet werden.
      owners: { booking: 'start', workspace: 'start' },
    };
  return {
    tabs: [
      { key: 'start', root: 'home', label: 'Fahren' },
      ...(input.signedIn
        ? [{ key: 'earnings', root: 'earnings', label: 'Umsatz' } as const]
        : []),
      ...(input.signedIn && input.fleetRole
        ? [{ key: 'fleet', root: 'operations', label: 'Flotte' } as const]
        : []),
      { key: 'account', root: 'account', label: 'Konto' },
    ],
  };
}

const titles: Record<Route, string | null> = {
  home: null, // Startansicht zeigt die Marke
  account: 'Konto',
  trips: 'Fahrten',
  booking: 'Fahrt buchen',
  live: 'Deine Fahrt',
  workspace: 'Übersicht',
  operations: 'Disposition',
  fleet: 'Flotte',
  invitations: 'Einladungen',
  inventory: 'Bordbestand',
  navigation: 'Navigation',
  design: 'Design-Muster',
  earnings: 'Meine Einnahmen',
  compliance: 'Vor der Schicht',
  fleetIncome: 'Einnahmen',
  fleetCompliance: 'Prüfung',
  photos: 'Fotos hochladen',
  reservations: 'Reservierungen',
};

/** Titel für die Kopfzeile; `null` = Marke anzeigen. */
export function screenTitle(route: Route): string | null {
  return titles[route];
}

const embeddedWeb = (route: Route) => route === 'workspace' || route === 'photos';

/** Auf der eingebetteten Web-Ansicht bleibt die Tab-Leiste wie bisher weg. */
export function showsTabs(route: Route): boolean {
  return !embeddedWeb(route);
}

/** Randwischen: wie bisher nicht auf der eingebetteten Web-Ansicht. */
export function allowsEdgeBack(route: Route): boolean {
  return !embeddedWeb(route);
}
