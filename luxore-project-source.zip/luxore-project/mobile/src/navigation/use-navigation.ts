import { useEffect, useMemo, useRef, useState } from 'react';
import { BackHandler } from 'react-native';
import * as history from './history';
import type { AppNavConfig, Route, TabKey } from './routes';

export type Motion = 'forward' | 'back' | 'tab';

export type Navigation = {
  route: Route;
  tab: TabKey;
  /** Es gibt im aktiven Tab eine Ebene darunter (Zurück-Pfeil). */
  canPop: boolean;
  /** Richtung des letzten Wechsels, für den Übergang. */
  motion: Motion;
  push: (route: Route) => void;
  replace: (route: Route) => void;
  /** Eine Ebene zurück; `false`, wenn es nichts mehr gibt. */
  back: () => boolean;
  canGoBack: () => boolean;
  selectTab: (tab: TabKey) => void;
  reset: () => void;
};

/**
 * Hält den Verlauf (`history.ts`) als React-Zustand und bindet die
 * Android-Zurück-Taste an. Die Aktionen bleiben über alle Render hinweg
 * dieselben Funktionen und arbeiten immer auf dem neuesten Stand.
 */
export function useNavigation(config: AppNavConfig): Navigation {
  const configRef = useRef(config);
  configRef.current = config;
  const stateRef = useRef<history.NavState | null>(null);
  if (!stateRef.current) stateRef.current = history.initial(config);
  const [state, setState] = useState(stateRef.current);
  const [motion, setMotion] = useState<Motion>('forward');

  const actions = useMemo(() => {
    const apply = (
      change: (
        state: history.NavState,
        config: history.NavConfig,
      ) => history.NavState,
      kind: Motion,
    ) => {
      const before = stateRef.current!;
      const next = change(before, configRef.current);
      if (next === before) return false;
      stateRef.current = next;
      setMotion(kind);
      setState(next);
      return true;
    };
    return {
      push: (route: Route) => {
        apply((s, c) => history.push(s, c, route), 'forward');
      },
      replace: (route: Route) => {
        apply((s, c) => history.replace(s, c, route), 'forward');
      },
      back: () => apply(history.pop, 'back'),
      canGoBack: () => history.canGoBack(stateRef.current!, configRef.current),
      selectTab: (tab: TabKey) => {
        apply((s, c) => history.selectTab(s, c, tab), 'tab');
      },
      reset: () => {
        apply(history.reset, 'tab');
      },
    };
  }, []);

  const { back } = actions;
  useEffect(() => {
    // Auf der Wurzel des Start-Tabs meldet `back` false: Android beendet
    // die App wie bisher. Wie bisher wird nach jedem Screenwechsel neu
    // angemeldet: Android fragt den zuletzt angemeldeten Empfänger zuerst,
    // so behält die App-Navigation Vorrang vor einzelnen Screens.
    const listener = BackHandler.addEventListener('hardwareBackPress', back);
    return () => listener.remove();
  }, [back, state]);

  return {
    route: history.current(state, config) as Route,
    tab: history.activeTab(state, config) as TabKey,
    canPop: history.canPop(state, config),
    motion,
    ...actions,
  };
}
