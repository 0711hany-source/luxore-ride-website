import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { ArrowLeft } from 'lucide-react-native';
import { colors, layout, maxFontScale, typography, space } from '../theme';

/**
 * Kopfzeile: Titel des aktuellen Screens; die Marke nur auf der Startansicht
 * (`title` = null). Der Zurück-Knopf erscheint nur, wenn es im Tab eine Ebene
 * darunter gibt.
 */
export default function Header({
  title,
  product,
  onBack,
}: {
  title: string | null;
  /** Zusatz der Wortmarke: „RIDE“ oder „DRIVER“. */
  product: string;
  onBack?: () => void;
}) {
  // Die Marke steht nur auf der Wurzel des Start-Tabs – dort gibt es nie
  // einen Zurück-Knopf, sie bekommt die ganze Breite.
  if (title === null)
    return (
      <View style={s.header}>
        <View style={s.center}>
          <Text style={s.brand} accessibilityRole="header">
            LUXORÉ <Text style={s.brandFine}>{product}</Text>
          </Text>
        </View>
      </View>
    );
  return (
    <View style={s.header}>
      <View style={s.side}>
        {onBack ? (
          <Pressable
            style={s.back}
            onPress={onBack}
            accessibilityRole="button"
            accessibilityLabel="Zurück"
            hitSlop={8}
          >
            <ArrowLeft
              color={colors.ink}
              size={layout.icon}
              strokeWidth={layout.iconStroke}
            />
            <Text style={s.backText} maxFontSizeMultiplier={maxFontScale}>
              Zurück
            </Text>
          </Pressable>
        ) : null}
      </View>
      <View style={s.center}>
        <Text
          style={s.title}
          accessibilityRole="header"
          numberOfLines={1}
          maxFontSizeMultiplier={maxFontScale}
        >
          {title}
        </Text>
      </View>
      <View style={s.side} />
    </View>
  );
}

const s = StyleSheet.create({
  header: {
    height: 58,
    paddingHorizontal: layout.screenMargin,
    flexDirection: 'row',
    alignItems: 'center',
  },
  side: { width: 88, justifyContent: 'center' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  back: {
    minHeight: layout.tap,
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: space[1],
    paddingRight: space[2],
  },
  backText: { ...typography.subhead, color: colors.ink },
  brand: {
    color: colors.ink,
    fontSize: 20,
    fontWeight: '600',
    letterSpacing: 2.3,
  },
  brandFine: { fontSize: 11, letterSpacing: 2.8, color: colors.goldText },
  title: { ...typography.headline, color: colors.ink },
});
