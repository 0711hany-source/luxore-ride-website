import React, { useEffect, useRef } from 'react';
import { Animated, View } from 'react-native';
import { durations } from '../theme';
import type { Motion } from './use-navigation';

const offset = 16;

/**
 * Platz eines Screens unter der Kopfzeile. Versteckte Screens bleiben wie
 * bisher mit `display: 'none'` eingehängt, damit ihr Zustand weiterläuft.
 * Beim Sichtbarwerden blendet der Screen ein und schiebt sich leicht herein;
 * bei „Bewegung reduzieren“ nur Überblenden. `animated={false}` (Karte,
 * Web-Ansicht) wechselt ohne Übergang.
 */
export default function ScreenSlot({
  visible,
  animated = true,
  motion,
  reduceMotion,
  children,
}: {
  visible: boolean;
  animated?: boolean;
  motion: Motion;
  reduceMotion: boolean;
  children?: React.ReactNode;
}) {
  // Der Wert steht vor dem Einblenden schon auf 0: kein Aufblitzen des
  // fertigen Bildes. `animated` muss je Platz fest sein.
  const progress = useRef(new Animated.Value(0)).current;
  const shown = useRef(false);
  useEffect(() => {
    if (!animated) return;
    if (!visible) {
      shown.current = false;
      progress.setValue(0);
      return;
    }
    if (shown.current) return;
    shown.current = true;
    progress.setValue(0);
    const animation = Animated.timing(progress, {
      toValue: 1,
      duration: reduceMotion ? durations.fade : durations.screen,
      useNativeDriver: true,
    });
    animation.start();
    // Ein abgebrochener Übergang darf nie einen unsichtbaren Screen hinterlassen.
    return () => {
      animation.stop();
      progress.setValue(1);
    };
  }, [visible, animated, progress]);
  if (!animated)
    return (
      <View style={[{ flex: 1 }, !visible && { display: 'none' }]}>
        {children}
      </View>
    );
  const from =
    reduceMotion || motion === 'tab'
      ? 0
      : motion === 'back'
        ? -offset
        : offset;
  return (
    <Animated.View
      style={[
        { flex: 1 },
        !visible && { display: 'none' },
        {
          opacity: progress,
          transform: [
            {
              translateX: progress.interpolate({
                inputRange: [0, 1],
                outputRange: [from, 0],
              }),
            },
          ],
        },
      ]}
    >
      {children}
    </Animated.View>
  );
}
