// Verlauf der App: je Tab ein kleiner Stapel von Screens. Reine Logik ohne
// React und ohne React Native, damit sie einzeln getestet werden kann.
//
// Regeln:
// - Der erste Tab ist der Start-Tab. Jeder Tab hat eine feste Wurzel.
// - Ein Screen liegt höchstens einmal im Verlauf (die Screens sind einzelne,
//   teils versteckt weiterlaufende Instanzen).
// - Zurück geht genau eine Ebene; auf der Wurzel eines anderen Tabs führt es
//   zum Start-Tab; auf der Wurzel des Start-Tabs bleibt der Verlauf gleich
//   (dieselbe Referenz) – die Android-Taste beendet dann die App.

export type NavTab = { key: string; root: string };

export type NavConfig = {
  /** Sichtbare Tabs in Reihenfolge; der erste ist der Start-Tab. */
  tabs: readonly NavTab[];
  /** Screens, die immer in einem bestimmten Tab geöffnet werden. */
  owners?: Readonly<Record<string, string>>;
};

export type NavState = {
  tab: string;
  stacks: Readonly<Record<string, readonly string[]>>;
};

export function initial(config: NavConfig): NavState {
  return { tab: config.tabs[0].key, stacks: {} };
}

const homeTab = (config: NavConfig) => config.tabs[0].key;

/** Aktiver Tab; fällt auf den Start-Tab zurück, wenn es den Tab nicht mehr gibt. */
export function activeTab(state: NavState, config: NavConfig): string {
  return config.tabs.some((tab) => tab.key === state.tab)
    ? state.tab
    : homeTab(config);
}

export function stackOf(
  state: NavState,
  config: NavConfig,
  tab: string,
): readonly string[] {
  const root = config.tabs.find((item) => item.key === tab)?.root;
  if (!root) return [];
  const stack = state.stacks[tab];
  return stack && stack.length && stack[0] === root ? stack : [root];
}

export function current(state: NavState, config: NavConfig): string {
  const stack = stackOf(state, config, activeTab(state, config));
  return stack[stack.length - 1];
}

/** Gibt es im aktiven Tab eine Ebene darunter? (Zurück-Pfeil) */
export function canPop(state: NavState, config: NavConfig): boolean {
  return stackOf(state, config, activeTab(state, config)).length > 1;
}

/** Bewirkt Zurück überhaupt etwas? (Android-Taste, Randwischen) */
export function canGoBack(state: NavState, config: NavConfig): boolean {
  return canPop(state, config) || activeTab(state, config) !== homeTab(config);
}

/** Tab wechseln: setzt dessen Stapel fort; erneutes Antippen führt zur Wurzel. */
export function selectTab(
  state: NavState,
  config: NavConfig,
  tab: string,
): NavState {
  const target = config.tabs.find((item) => item.key === tab);
  if (!target) return state;
  if (activeTab(state, config) !== tab) return { tab, stacks: state.stacks };
  if (stackOf(state, config, tab).length === 1) return state;
  return { tab, stacks: { ...state.stacks, [tab]: [target.root] } };
}

/**
 * Screen öffnen. Die Wurzel eines Tabs öffnet diesen Tab von vorn; jeder
 * andere Screen kommt oben auf den Stapel seines Tabs (`owners`) bzw. des
 * aktiven Tabs.
 */
export function push(
  state: NavState,
  config: NavConfig,
  route: string,
): NavState {
  const active = activeTab(state, config);
  const asRoot = config.tabs.find((item) => item.root === route);
  if (asRoot) {
    if (active === asRoot.key && !canPop(state, config)) return state;
    return {
      tab: asRoot.key,
      stacks: { ...state.stacks, [asRoot.key]: [route] },
    };
  }
  const owner = config.owners?.[route];
  const target =
    owner && config.tabs.some((item) => item.key === owner) ? owner : active;
  if (target === active && current(state, config) === route) return state;
  const stacks: Record<string, readonly string[]> = {};
  for (const { key } of config.tabs)
    stacks[key] = stackOf(state, config, key).filter((item) => item !== route);
  stacks[target] = [...stacks[target], route];
  return { tab: target, stacks };
}

/** Eine Ebene zurück. Unveränderte Referenz = nichts mehr zum Zurückgehen. */
export function pop(state: NavState, config: NavConfig): NavState {
  const active = activeTab(state, config);
  const stack = stackOf(state, config, active);
  if (stack.length > 1)
    return {
      tab: active,
      stacks: { ...state.stacks, [active]: stack.slice(0, -1) },
    };
  if (active !== homeTab(config))
    return { tab: homeTab(config), stacks: state.stacks };
  return state;
}

/** Obersten Screen ersetzen: Zurück führt danach nicht mehr zu ihm. */
export function replace(
  state: NavState,
  config: NavConfig,
  route: string,
): NavState {
  return push(
    canPop(state, config) ? pop(state, config) : state,
    config,
    route,
  );
}

/** Alles verwerfen und zur Wurzel des Start-Tabs (An-/Abmeldung). */
export function reset(state: NavState, config: NavConfig): NavState {
  if (
    activeTab(state, config) === homeTab(config) &&
    config.tabs.every(({ key }) => stackOf(state, config, key).length === 1)
  )
    return state;
  return initial(config);
}
