import { useEffect, useRef } from 'react';
import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';

/**
 * Fahrer-App: Antippen einer Fahrtangebot-Benachrichtigung öffnet den
 * Fahrerbereich. Kommt das Antippen vor dem Laden der Anmeldung, wird es
 * nachgeholt, sobald sie geladen ist. Unverändert aus der früheren App.tsx.
 */
export function useOfferNotification(input: {
  enabled: boolean;
  loaded: boolean;
  signedIn: () => boolean;
  openDriver: () => void;
}) {
  const { enabled, loaded, signedIn, openDriver } = input;
  const pendingOffer = useRef(false);
  useEffect(() => {
    if (!enabled || Platform.OS === 'web') return;
    const openOffer = (response: Notifications.NotificationResponse) => {
      if (response.notification.request.content.data?.kind !== 'luxore-offer')
        return;
      pendingOffer.current = true;
      if (signedIn()) {
        pendingOffer.current = false;
        openDriver();
      }
      Notifications.clearLastNotificationResponse();
    };
    const old = Notifications.getLastNotificationResponse();
    if (old) openOffer(old);
    const listener =
      Notifications.addNotificationResponseReceivedListener(openOffer);
    return () => listener.remove();
  }, [enabled, signedIn, openDriver]);
  useEffect(() => {
    if (loaded && pendingOffer.current) {
      pendingOffer.current = false;
      openDriver();
    }
  }, [loaded, openDriver]);
}
