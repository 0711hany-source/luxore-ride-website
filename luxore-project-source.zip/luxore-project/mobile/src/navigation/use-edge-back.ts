import { useRef } from 'react';
import {
  Keyboard,
  PanResponder,
  type GestureResponderHandlers,
} from 'react-native';

/** Breite der Randzone links, in der das Zurück-Wischen beginnt. */
export const edgeWidth = 20;

/**
 * Randwischen „eine Ebene zurück“. Der Erkenner wird genau einmal erzeugt und
 * liest den aktuellen Stand über Referenzen. Er greift nur, wenn die Geste in
 * den äußeren 20 pt links beginnt und waagerecht verläuft – Wischknöpfe,
 * Sheets und die Kartenfläche beginnen weiter innen.
 */
export function useEdgeBack(
  enabled: () => boolean,
  onBack: () => void,
): GestureResponderHandlers {
  const latest = useRef({ enabled, onBack });
  latest.current = { enabled, onBack };
  const handlers = useRef<GestureResponderHandlers | null>(null);
  if (!handlers.current)
    handlers.current = PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) =>
        latest.current.enabled() &&
        g.x0 < edgeWidth &&
        g.dx > 24 &&
        Math.abs(g.dy) < 18,
      onPanResponderRelease: (_, g) => {
        if (g.dx > 90 && Math.abs(g.dy) < 45 && latest.current.enabled()) {
          Keyboard.dismiss();
          latest.current.onBack();
        }
      },
    }).panHandlers;
  return handlers.current;
}
