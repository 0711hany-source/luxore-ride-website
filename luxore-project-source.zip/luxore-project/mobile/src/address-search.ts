import { coordinate, type Point } from '../../lib/mobility/domain.ts';
export type AddressSearchState = {
  query: string;
  results: Point[];
  searching: boolean;
  confirming: string | null;
  confirmed: Point | null;
  error: string;
};
type SearchBody = { kind: 'search'; query: string };
type SelectedBody = {
  kind: 'selected';
  query: string;
  lat: number;
  lng: number;
};
export type AddressRequest = (
  body: SearchBody | SelectedBody,
  signal?: AbortSignal,
) => Promise<{ results: Point[] }>;
function validPoint(value: unknown): value is Point {
  if (!value || typeof value !== 'object') return false;
  const p = value as Point;
  return (
    typeof p.id === 'string' &&
    !!p.id &&
    typeof p.label === 'string' &&
    !!p.label.trim() &&
    coordinate(p.lat, p.lng) &&
    (p.attribution === undefined ||
      p.attribution === null ||
      typeof p.attribution === 'string')
  );
}
/** Screen/account-bound address selection; temporary suggestions never reach storage. */
export class AddressSearchController {
  private state: AddressSearchState = {
    query: '',
    results: [],
    searching: false,
    confirming: null,
    confirmed: null,
    error: '',
  };
  private listeners = new Set<() => void>();
  private active = false;
  private disposed = false;
  private revision = 0;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private pending: AbortController | null = null;
  constructor(private request: AddressRequest) {}
  getSnapshot = () => this.state;
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  private publish(patch: Partial<AddressSearchState>) {
    if (this.disposed) return;
    this.state = { ...this.state, ...patch };
    for (const listener of this.listeners) listener();
  }
  private stopSearch() {
    if (this.timer !== null) clearTimeout(this.timer);
    this.timer = null;
    this.pending?.abort();
    this.pending = null;
  }
  setActive(value: boolean) {
    if (this.disposed || value === this.active) return;
    this.active = value;
    this.stopSearch();
    this.publish({ searching: false });
    if (value && !this.state.confirming && !this.state.confirmed)
      this.schedule();
  }
  setQuery(query: string) {
    if (this.disposed || query === this.state.query) return;
    this.revision++;
    this.stopSearch();
    this.publish({
      query,
      results: [],
      searching: false,
      confirming: null,
      confirmed: null,
      error: '',
    });
    this.schedule();
  }
  private schedule() {
    const query = this.state.query.trim();
    if (!this.active || this.disposed || query.length < 3 || query.length > 256)
      return;
    this.timer = setTimeout(() => {
      this.timer = null;
      void this.search();
    }, 600);
  }
  async search() {
    if (
      !this.active ||
      this.disposed ||
      this.state.confirming ||
      this.state.confirmed
    )
      return;
    const query = this.state.query.trim();
    this.stopSearch();
    if (query.length < 3 || query.length > 256) {
      this.publish({
        searching: false,
        results: [],
        error: 'Bitte 3 bis 256 Zeichen eingeben.',
      });
      return;
    }
    const revision = this.revision;
    const controller = new AbortController();
    this.pending = controller;
    this.publish({ searching: true, results: [], error: '' });
    try {
      const data = await this.request(
        { kind: 'search', query },
        controller.signal,
      );
      if (
        controller.signal.aborted ||
        this.disposed ||
        !this.active ||
        revision !== this.revision
      )
        return;
      if (!Array.isArray(data.results) || !data.results.every(validPoint))
        throw new Error(
          'Die Adresssuche lieferte keine gültige Antwort. Bitte erneut versuchen.',
        );
      this.publish({
        results: data.results.slice(0, 10),
        error: data.results.length
          ? ''
          : 'Keine Adresse gefunden. Bitte Straße, Hausnummer und Ort eingeben.',
      });
    } catch (error) {
      if (
        !controller.signal.aborted &&
        !this.disposed &&
        this.active &&
        revision === this.revision
      )
        this.publish({
          error:
            error instanceof Error
              ? error.message
              : 'Die Adresssuche ist gerade nicht erreichbar.',
        });
    } finally {
      if (this.pending === controller) {
        this.pending = null;
        this.publish({ searching: false });
      }
    }
  }
  async select(point: Point) {
    if (
      !this.active ||
      this.disposed ||
      this.state.confirming ||
      !this.state.results.some(
        (p) => p.id === point.id && p.lat === point.lat && p.lng === point.lng,
      )
    )
      return;
    this.stopSearch();
    const revision = ++this.revision;
    const query = this.state.query.trim();
    this.publish({
      confirming: point.id,
      searching: false,
      confirmed: null,
      error: '',
    });
    try {
      // This POST obtains licensed, owner-bound storage for the chosen address.
      // Backgrounding does not undo a submitted write; never abort it as a read.
      const data = await this.request({
        kind: 'selected',
        query,
        lat: point.lat,
        lng: point.lng,
      });
      if (this.disposed || revision !== this.revision) return;
      if (
        !Array.isArray(data.results) ||
        data.results.length !== 1 ||
        !validPoint(data.results[0])
      )
        throw new Error(
          'Die Adresse konnte nicht bestätigt werden. Bitte erneut auswählen.',
        );
      const confirmed = data.results[0];
      this.publish({ confirmed, query: confirmed.label, results: [] });
    } catch (error) {
      if (!this.disposed && revision === this.revision)
        this.publish({
          error:
            error instanceof Error
              ? error.message
              : 'Die Adresse konnte nicht bestätigt werden.',
        });
    } finally {
      if (!this.disposed && revision === this.revision)
        this.publish({ confirming: null });
    }
  }
  dispose() {
    this.disposed = true;
    this.active = false;
    this.revision++;
    this.stopSearch();
    this.listeners.clear();
  }
}
