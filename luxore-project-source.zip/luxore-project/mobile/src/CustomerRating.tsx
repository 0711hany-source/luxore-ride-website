import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { nativeApi } from './account-client';
import {
  RATING_COMMENT_MAX,
  ratingBody,
  validStars,
  type RatingOffer,
} from './customer-chauffeur';
import CustomerRatingStars, {
  CustomerStarsShown,
} from './customer-rating-stars';
import { colors, layout, maxFontScale, radii, space, typography } from './theme';

/**
 * The customer rates the chauffeur of a finished ride: once, 1–5 stars and
 * an optional comment. Shows the given stars afterwards; nothing when the
 * server does not (or no longer) allow a rating.
 */
export default function CustomerRating({
  token,
  bookingId,
  offer,
  onSaved,
}: {
  token: string;
  bookingId: string;
  offer: RatingOffer;
  onSaved?: (bookingId: string, stars: number) => void;
}) {
  const [stars, setStars] = useState(0),
    [comment, setComment] = useState(''),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [saved, setSaved] = useState<number | null>(null);
  const sending = useRef(false),
    mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  const done = offer.kind === 'given' ? offer.stars : saved;
  if (done)
    return (
      <View style={s.given}>
        <Text maxFontSizeMultiplier={maxFontScale} style={s.detail}>
          Deine Bewertung
        </Text>
        <CustomerStarsShown stars={done} />
      </View>
    );
  if (offer.kind !== 'open') return null;
  async function send() {
    // One request at a time; a rating is final once the server stored it.
    if (sending.current) return;
    let body;
    try {
      body = ratingBody(bookingId, stars, comment);
    } catch (e) {
      setError((e as Error).message);
      return;
    }
    sending.current = true;
    setBusy(true);
    setError('');
    try {
      const result = await nativeApi<{ stars?: number }>(
        'ratings',
        token,
        body,
      );
      const stored = validStars(result?.stars) ? result.stars : body.stars;
      onSaved?.(bookingId, stored);
      if (mounted.current) setSaved(stored);
    } catch (e) {
      // Includes the "next server update" sentence of NativeRouteMissingError.
      if (mounted.current)
        setError(
          e instanceof Error && e.message
            ? e.message
            : 'Die Bewertung konnte nicht gespeichert werden.',
        );
    } finally {
      sending.current = false;
      if (mounted.current) setBusy(false);
    }
  }
  return (
    <View style={s.box}>
      <Text maxFontSizeMultiplier={maxFontScale} style={s.title}>
        Wie war deine Fahrt?
      </Text>
      <CustomerRatingStars value={stars} onChange={setStars} disabled={busy} />
      {stars > 0 && (
        <>
          <Text maxFontSizeMultiplier={maxFontScale} style={s.label}>
            Kommentar (freiwillig)
          </Text>
          <TextInput
            accessibilityLabel="Kommentar, freiwillig"
            value={comment}
            onChangeText={setComment}
            maxLength={RATING_COMMENT_MAX}
            multiline
            editable={!busy}
            placeholderTextColor={colors.gray}
            maxFontSizeMultiplier={maxFontScale}
            style={s.input}
          />
          <Text maxFontSizeMultiplier={maxFontScale} style={s.detail}>
            Wird nie veröffentlicht. Nur Betreiber und Flottenleitung lesen
            ihn. {comment.length}/{RATING_COMMENT_MAX}
          </Text>
          <Pressable
            accessibilityRole="button"
            accessibilityState={{ disabled: busy, busy }}
            disabled={busy}
            onPress={() => void send()}
            style={[s.send, busy && s.sendBusy]}
          >
            {busy && <ActivityIndicator color={colors.white} />}
            <Text maxFontSizeMultiplier={maxFontScale} style={s.sendText}>
              {busy
                ? 'Wird gespeichert …'
                : `${stars} ${stars === 1 ? 'Stern' : 'Sterne'} abgeben`}
            </Text>
          </Pressable>
          <Text maxFontSizeMultiplier={maxFontScale} style={s.detail}>
            Die Bewertung kann danach nicht mehr geändert werden.
          </Text>
        </>
      )}
      {!!error && (
        <Text
          accessibilityRole="alert"
          maxFontSizeMultiplier={maxFontScale}
          style={s.error}
        >
          {error}
        </Text>
      )}
    </View>
  );
}
const s = StyleSheet.create({
  box: { gap: space[3] },
  given: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: space[3],
    minHeight: layout.tap,
  },
  title: { ...typography.headline, color: colors.ink },
  label: { ...typography.footnote, fontWeight: '600', color: colors.ink },
  detail: { ...typography.footnote, color: colors.textMuted },
  input: {
    ...typography.body,
    color: colors.ink,
    minHeight: 96,
    textAlignVertical: 'top',
    borderWidth: 1,
    borderColor: colors.lineStrong,
    borderRadius: radii.m,
    backgroundColor: colors.white,
    padding: space[3],
  },
  send: {
    minHeight: 54,
    borderRadius: radii.m,
    backgroundColor: colors.ink,
    flexDirection: 'row',
    gap: space[3],
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: space[4],
  },
  sendBusy: { backgroundColor: colors.inkSoft },
  sendText: { ...typography.subhead, fontWeight: '600', color: colors.white },
  error: { ...typography.footnote, color: colors.danger },
});
