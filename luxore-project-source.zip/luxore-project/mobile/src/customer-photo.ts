import { companyOrigin } from './account-client';
import { photoId } from './customer-chauffeur';

/**
 * Guarded picture: fetched with the app session in the Authorization header,
 * like every other protected request. The token never enters the address.
 */
export function photoSource(id: string | null, token: string | null) {
  const safe = photoId(id);
  if (!safe || !token || !/^[a-f0-9]{64}$/.test(token)) return null;
  return {
    uri: companyOrigin + '/api/mobility/images?id=' + encodeURIComponent(safe),
    headers: {
      Authorization: 'Bearer ' + token,
      Origin: companyOrigin,
      'X-Luxore-Client': 'native-v1',
    },
  };
}
