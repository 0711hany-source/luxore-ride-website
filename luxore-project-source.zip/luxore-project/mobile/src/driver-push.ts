import Constants from 'expo-constants';
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { nativeApi } from './account-client';
import { driverVariant } from './build-config';

// Server push „Eine Fahrtanfrage wartet. Bitte online gehen.“ (Firebase Cloud
// Messaging, Android first). Completely inactive unless this build contains a
// google-services file: then `extra.push` is true (see app.config.ts).
// The local offer alarm in offer-alerts.ts is independent and unchanged.
const channelId = 'luxore-driver-wake-v1';
const built =
  Platform.OS === 'android' &&
  driverVariant &&
  Constants.expoConfig?.extra?.push === true;
let registered: string | null = null;
let running = false;

function within<T>(work: Promise<T>, ms: number): Promise<T | null> {
  let timer: ReturnType<typeof setTimeout>;
  return Promise.race([
    work,
    new Promise<null>((resolve) => {
      timer = setTimeout(() => resolve(null), ms);
    }),
  ]).finally(() => clearTimeout(timer));
}

/** Best effort after sign-in and on every return to the app. Never throws. */
export async function registerDriverPush(session: string | null) {
  if (!built || !session || running) return;
  running = true;
  try {
    // Never prompt here: the permission is asked where the driver enables
    // offer alerts. Without it Android would not show the message anyway.
    const permission = await within(Notifications.getPermissionsAsync(), 4000);
    if (!permission?.granted) return;
    await within(
      Notifications.setNotificationChannelAsync(channelId, {
        name: 'Fahrtanfrage wartet',
        description: 'Hinweis, online zu gehen, wenn eine Fahrtanfrage wartet',
        importance: Notifications.AndroidImportance.HIGH,
        sound: 'default',
        enableVibrate: true,
        lockscreenVisibility:
          Notifications.AndroidNotificationVisibility.PRIVATE,
        bypassDnd: false,
      }),
      4000,
    );
    // Hangs or throws without a working Firebase setup: bounded and caught.
    const device = await within(Notifications.getDevicePushTokenAsync(), 8000);
    const token = device?.type === 'android' ? device.data : null;
    if (typeof token !== 'string' || token.length < 20) return;
    const key = session + ':' + token;
    if (registered === key) return;
    // The server stores it only for a signed-in, approved driver (else 403).
    await nativeApi(
      'push',
      session,
      { action: 'register', token, platform: 'android' },
      undefined,
      undefined,
      8000,
    );
    registered = key;
  } catch {
    // Push is an addition; the app works without it.
  } finally {
    running = false;
  }
}
/** Before sign-out: this phone must no longer be woken for the account. */
export async function unregisterDriverPush(session: string | null) {
  if (!built || !session) return;
  registered = null;
  try {
    await nativeApi(
      'push',
      session,
      { action: 'unregister' },
      undefined,
      undefined,
      4000,
    );
  } catch {
    // The server also replaces the token at the next registration.
  }
}
