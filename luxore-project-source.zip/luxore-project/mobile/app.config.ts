import type { ExpoConfig } from 'expo/config';
const driver = process.env.APP_VARIANT === 'driver';
const internal = process.env.APP_CHANNEL === 'internal';
const config: ExpoConfig = {
  name: `${driver ? 'LUXORÉ Driver' : 'LUXORÉ Ride'}${internal ? ' Test' : ''}`,
  slug: driver ? 'luxore-driver' : 'luxore-ride',
  version: '0.6.3',
  icon: driver ? './assets/icon-driver.png' : './assets/icon-ride.png',
  orientation: 'portrait',
  userInterfaceStyle: 'light',
  platforms: ['android', 'ios'],
  scheme: driver ? 'luxoredriver' : 'luxoreride',
  ios: {
    bundleIdentifier: `${driver ? 'de.luxoreride.driver' : 'de.luxoreride.customer'}${internal ? '.preview' : ''}`,
    buildNumber: '17',
    supportsTablet: false,
  },
  android: {
    package: `${driver ? 'de.luxoreride.driver' : 'de.luxoreride.customer'}${internal ? '.preview' : ''}`,
    versionCode: 17,
    adaptiveIcon: {
      foregroundImage: driver
        ? './assets/icon-driver-adaptive.png'
        : './assets/icon-ride-adaptive.png',
      backgroundColor: driver ? '#e4cba0' : '#11151c',
      monochromeImage: './assets/icon-monochrome.png',
    },
    allowBackup: false,
    blockedPermissions: [
      'android.permission.RECORD_AUDIO',
      'android.permission.SYSTEM_ALERT_WINDOW',
      ...(driver
        ? []
        : [
            'android.permission.VIBRATE',
            'android.permission.POST_NOTIFICATIONS',
          ]),
      'android.permission.READ_EXTERNAL_STORAGE',
      'android.permission.WRITE_EXTERNAL_STORAGE',
    ],
  },
  plugins: [
    '@rnmapbox/maps',
    'expo-secure-store',
    ...(driver
      ? [
          [
            'expo-notifications',
            { color: '#b89658', defaultChannel: 'luxore-ride-offers-v1' },
          ] as [string, object],
        ]
      : []),
    [
      'expo-location',
      {
        isAndroidBackgroundLocationEnabled: driver,
        isAndroidForegroundServiceEnabled: driver,
        isIosBackgroundLocationEnabled: driver,
        locationWhenInUsePermission: driver
          ? 'LUXORÉ Driver verwendet deinen Standort während deiner gestarteten Schicht zur Fahrtvermittlung, Navigation und Anzeige der Anfahrt für deinen Fahrgast.'
          : 'LUXORÉ Ride verwendet deinen Standort, um deinen Abholort zu bestimmen. Eine manuelle Adresseingabe ist auch ohne Standortfreigabe möglich.',
        locationAlwaysAndWhenInUsePermission: driver
          ? 'LUXORÉ Driver übermittelt deinen Standort während deiner gestarteten Schicht auch bei gesperrtem Bildschirm oder Nutzung einer anderen App für Fahrtangebote und die Anfahrtanzeige. Mit dem Beenden der Schicht endet die Ortung.'
          : false,
      },
    ],
  ],
  extra: {
    variant: driver ? 'driver' : 'customer',
    preview: process.env.APP_PREVIEW === 'true',
  },
};
export default config;
