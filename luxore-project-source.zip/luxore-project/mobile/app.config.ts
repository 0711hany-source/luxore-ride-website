import type { ExpoConfig } from 'expo/config';
import {
  withAppDelegate,
  withEntitlementsPlist,
  withInfoPlist,
  type ConfigPlugin,
} from 'expo/config-plugins';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
const driver = process.env.APP_VARIANT === 'driver';
// Firebase push (driver only) is built in only when this file exists. It is
// not part of the repository; see docs/PUSH-EINRICHTUNG.md. Without it the
// app is built exactly as before and never asks for a push token.
const googleServicesFile = './google-services.driver.json';
const pushReady =
  driver &&
  existsSync(
    join(
      typeof __dirname === 'string' ? __dirname : process.cwd(),
      googleServicesFile,
    ),
  );
const internal = process.env.APP_CHANNEL === 'internal';
// One build counter for both stores: Android versionCode = iOS buildNumber.
const buildCode = driver ? 62 : 44;
const driverBackgroundLocation =
  'LUXORÉ Driver übermittelt deinen Standort während deiner gestarteten Schicht auch bei gesperrtem Bildschirm oder Nutzung einer anderen App für Fahrtangebote und die Anfahrtanzeige. Mit dem Beenden der Schicht endet die Ortung.';
// iOS only. Expo applies the plugins of expo-task-manager and
// expo-notifications automatically because the packages are installed:
// - "fetch" background mode: no background fetch is used in either app.
// - push entitlement: LUXORÉ Ride receives no server push; its ride notices
//   (src/customer-notices.ts) are local notifications and need none.
// Android files are not touched by these two modifiers.
const withLeanIosCapabilities: ConfigPlugin = (config) => {
  config = withInfoPlist(config, (c) => {
    const modes = c.modResults.UIBackgroundModes?.filter(
      (mode) => mode !== 'fetch',
    );
    if (modes?.length) c.modResults.UIBackgroundModes = modes;
    else delete c.modResults.UIBackgroundModes;
    return c;
  });
  return withEntitlementsPlist(config, (c) => {
    // A free Apple ID (personal team) cannot sign the push entitlement.
    if (!driver || process.env.IOS_FREE_SIGNING === '1')
      delete c.modResults['aps-environment'];
    return c;
  });
};
const config: ExpoConfig = {
  name: `${driver ? 'LUXORÉ Driver' : 'LUXORÉ Ride'}${internal ? ' Test' : ''}`,
  slug: driver ? 'luxore-driver' : 'luxore-ride',
  version: '1.0.0',
  icon: driver ? './assets/icon-driver.png' : './assets/icon-ride.png',
  orientation: 'portrait',
  userInterfaceStyle: 'light',
  platforms: ['android', 'ios'],
  scheme: driver ? 'luxoredriver' : 'luxoreride',
  ios: {
    bundleIdentifier: `${driver ? 'de.luxoreride.driver' : 'de.luxoreride.customer'}${internal ? '.preview' : ''}`,
    buildNumber: String(buildCode),
    supportsTablet: false,
    infoPlist: {
      // Only standard HTTPS/TLS of the system; no own cryptography.
      ITSAppUsesNonExemptEncryption: false,
      CFBundleDevelopmentRegion: 'de',
      CFBundleLocalizations: ['de'],
      // UIBackgroundModes ("location", driver only) comes from the
      // expo-location plugin below. Navigation apps are opened through
      // https links, so no LSApplicationQueriesSchemes are needed.
    },
    // "Required reason" APIs, copied from the PrivacyInfo.xcprivacy files of
    // the installed packages (react-native, expo-constants, expo-system-ui,
    // expo-task-manager, expo-notifications, expo-application,
    // expo-file-system). Re-check after every package update.
    privacyManifests: {
      NSPrivacyAccessedAPITypes: [
        {
          NSPrivacyAccessedAPIType: 'NSPrivacyAccessedAPICategoryUserDefaults',
          NSPrivacyAccessedAPITypeReasons: ['CA92.1'],
        },
        {
          NSPrivacyAccessedAPIType: 'NSPrivacyAccessedAPICategoryFileTimestamp',
          NSPrivacyAccessedAPITypeReasons: ['C617.1', '0A2A.1', '3B52.1'],
        },
        {
          NSPrivacyAccessedAPIType: 'NSPrivacyAccessedAPICategoryDiskSpace',
          NSPrivacyAccessedAPITypeReasons: ['E174.1', '85F4.1'],
        },
        {
          NSPrivacyAccessedAPIType: 'NSPrivacyAccessedAPICategorySystemBootTime',
          NSPrivacyAccessedAPITypeReasons: ['35F9.1'],
        },
      ],
    },
  },
  android: {
    package: `${driver ? 'de.luxoreride.driver' : 'de.luxoreride.customer'}${internal ? '.preview' : ''}`,
    versionCode: buildCode,
    ...(pushReady ? { googleServicesFile } : {}),
    adaptiveIcon: {
      foregroundImage: driver
        ? './assets/icon-driver-adaptive.png'
        : './assets/icon-ride-adaptive.png',
      backgroundColor: driver ? '#e4cba0' : '#11151c',
      monochromeImage: './assets/icon-monochrome.png',
    },
    allowBackup: false,
    blockedPermissions: [
      'android.permission.RECORD_AUDIO',
      'android.permission.SYSTEM_ALERT_WINDOW',
      // VIBRATE and POST_NOTIFICATIONS stay allowed in both apps: the driver
      // app for offer alerts, LUXORÉ Ride for its local ride notices.
      'android.permission.READ_EXTERNAL_STORAGE',
      'android.permission.WRITE_EXTERNAL_STORAGE',
    ],
  },
  plugins: [
    '@rnmapbox/maps',
    // faceIDPermission is iOS only: the apps never ask for Face ID.
    ['expo-secure-store', { faceIDPermission: false }],
    [
      'expo-notifications',
      {
        color: '#b89658',
        defaultChannel: driver
          ? 'luxore-ride-offers-v1'
          : 'luxore-ride-status-v1',
      },
    ],
    [
      'expo-location',
      {
        isAndroidBackgroundLocationEnabled: driver,
        isAndroidForegroundServiceEnabled: driver,
        isIosBackgroundLocationEnabled: driver,
        locationWhenInUsePermission: driver
          ? 'LUXORÉ Driver verwendet deinen Standort während deiner gestarteten Schicht zur Fahrtvermittlung, Navigation und Anzeige der Anfahrt für deinen Fahrgast.'
          : 'LUXORÉ Ride verwendet deinen Standort, um deinen Abholort zu bestimmen. Eine manuelle Adresseingabe ist auch ohne Standortfreigabe möglich.',
        locationAlwaysAndWhenInUsePermission: driver
          ? driverBackgroundLocation
          : false,
        // iOS only: without these the plugin writes English default texts.
        locationAlwaysPermission: driver ? driverBackgroundLocation : false,
        motionUsagePermission: false,
      },
    ],
  ],
  extra: {
    variant: driver ? 'driver' : 'customer',
    preview: process.env.APP_PREVIEW === 'true',
    push: pushReady,
  },
};
// iOS only. iOS 27 ends an app at launch unless it uses the scene-based life
// cycle. Expo ships the scene delegate (`EXExpoAppSceneDelegate`), but the
// generated project does not use it yet: declare it in Info.plist and let it
// create the window instead of the app delegate. Throws if the generated
// AppDelegate no longer has the expected shape, so a build never silently
// ships the crashing variant.
const withIosSceneLifecycle: ConfigPlugin = (config) => {
  config = withInfoPlist(config, (c) => {
    c.modResults.UIApplicationSceneManifest = {
      UIApplicationSupportsMultipleScenes: false,
      UISceneConfigurations: {
        UIWindowSceneSessionRoleApplication: [
          {
            UISceneConfigurationName: 'Default Configuration',
            UISceneDelegateClassName: 'EXExpoAppSceneDelegate',
          },
        ],
      },
    };
    return c;
  });
  return withAppDelegate(config, (c) => {
    let source = c.modResults.contents;
    if (source.includes('ExpoReactNativeFactoryProvider')) return c;
    const declaration = 'class AppDelegate: ExpoAppDelegate {';
    const ownWindow =
      /#if os\(iOS\) \|\| os\(tvOS\)\s+window = UIWindow\(frame: UIScreen\.main\.bounds\)\s+factory\.startReactNative\([^)]*\)\s+#endif\n/;
    if (!source.includes(declaration) || !ownWindow.test(source))
      throw new Error(
        'AppDelegate.swift hat eine unerwartete Form: Szenen-Umstellung prüfen.',
      );
    source = source
      .replace(
        declaration,
        'class AppDelegate: ExpoAppDelegate, ExpoReactNativeFactoryProvider {',
      )
      .replace(ownWindow, '');
    c.modResults.contents = source;
    return c;
  });
};
export default withIosSceneLifecycle(withLeanIosCapabilities(config));
