# Store-Texte – Entwurf zur Einreichung

Noch keine Store-Veröffentlichung. Aussagen vor Einreichung mit dem freigegebenen Gerätetest abgleichen. Keine Downloadlinks, Bewertungen oder Zulassungen erfinden.

## LUXORÉ Ride

Kurzbeschreibung: Persönlicher Chauffeurservice in Frankfurt und Rhein-Main.

Beschreibung:

Mit LUXORÉ Ride planst du deinen Chauffeurservice in Frankfurt am Main und der Rhein-Main-Region. Wähle deinen Abholort und dein Ziel, sieh den berechneten Streckenpreis und entscheide dich für Business Class, First Class oder First Class Van.

- Freie Adresseingabe und optionaler Standort als Abholort.
- Sofortanfrage oder Reservierung für einen späteren Zeitpunkt.
- Anzeige der Fahrerzuweisung und des Status deiner Fahrt.
- Persönliche Fahrtpräferenzen und Bordbestellungen.
- Fahrtenübersicht, persönliches Profil und Kontakt zum Kundenservice.

Eine Sofortfahrt hängt von der Verfügbarkeit freigegebener Chauffeure ab. Eine Fahrtanfrage ist noch keine Fahrerzusage. Der konkret berechnete Preis wird vor der Anfrage angezeigt. Zusätzliche Leistungen sind gesondert ausgewiesen.

## LUXORÉ Driver

Kurzbeschreibung: Fahrtangebote, Flotte und Fahrtabschluss für Luxóre-Chauffeure.

Beschreibung:

LUXORÉ Driver begleitet freigegebene Chauffeure und Flotten von der Schicht bis zum Fahrtabschluss. Wähle ein Fahrzeug deiner Flotte, starte deine Schicht und bearbeite aktuelle Fahrtangebote.

- Fahrtangebote durch eine bewusste Wischgeste annehmen.
- Abholung, Fahrtstatus und Kundenwünsche einsehen.
- Fahrzeugwechsel innerhalb der eigenen Flotte.
- Kartenansicht und Übergabe an auswählbare Navigations-Apps.
- Tagesumsatz und Beträge, die am Fahrtende zu kassieren sind.
- Bordbestellungen, Bestand und Einkaufsbedarf verwalten.
- Disposition für Flottenbesitzer und ihre Stellvertretung.

Ein Fahrerprofil benötigt die betriebliche Freigabe und ein aktives zugeordnetes Fahrzeug. LUXORÉ Driver verwendet deinen Standort während einer gestarteten Schicht für die Vermittlung und Anfahrtanzeige, auch im Hintergrund nach entsprechender Berechtigung. Mit dem Beenden der Schicht endet die Ortung.

## Öffentliche URLs

- Website: https://luxore-ride-frankfurt.lucky-goose-6238.chatgpt.site/
- Hilfe: https://luxore-ride-frankfurt.lucky-goose-6238.chatgpt.site/hilfe
- Datenschutz: https://luxore-ride-frankfurt.lucky-goose-6238.chatgpt.site/datenschutz
- Kontolöschung: https://luxore-ride-frankfurt.lucky-goose-6238.chatgpt.site/konto

Diese URLs nach einer späteren, gesondert vorgenommenen Domainumstellung aktualisieren. Es wurde keine Änderung an DNS oder luxoreride.de vorgenommen.

## Noch kein Einreichungspaket

Echte App-Screenshots, Datenschutzprüfung, Bestätigung des Betreibers, Geräteprüfungen und Zugang für den Store-Reviewer fehlen noch. Keine Test-APK als signiertes Store-Release ausgeben. iOS ist vorbereitet, aber nicht auf einem iPhone geprüft.
