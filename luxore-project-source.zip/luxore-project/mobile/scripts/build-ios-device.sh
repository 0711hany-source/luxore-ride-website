#!/bin/bash
# Baut eine App-Variante für ein angeschlossenes iPhone und installiert sie.
# Kostenlose Apple-ID (Personal Team): läuft 7 Tage, ohne Push-Mitteilungen.
# Aufruf: IOS_TEAM=<Team-ID> bash build-ios-device.sh <customer|driver> "<Gerätename>"
set -euo pipefail
v="${1:-customer}"; device="${2:?Gerätename fehlt}"; team="${IOS_TEAM:?IOS_TEAM fehlt}"
export LANG=en_US.UTF-8 PATH="$HOME/.gem/ruby/2.6.0/bin:$PATH"
export APP_VARIANT="$v" EXPO_PUBLIC_APP_VARIANT="$v" EXPO_PUBLIC_APP_PREVIEW=false APP_PREVIEW=false APP_CHANNEL=internal CI=1 IOS_FREE_SIGNING=1
cd "$(cd "$(dirname "$0")/.." && pwd)"
node node_modules/expo/bin/cli prebuild --platform ios --no-install --clean
cd ios && pod install
ws=$(ls -d *.xcworkspace | head -1); scheme="${ws%.xcworkspace}"
derived="$HOME/LuxoreRide-Bau/ios-device-$v"
xcodebuild -workspace "$ws" -scheme "$scheme" -configuration Release -sdk iphoneos \
  -destination 'generic/platform=iOS' -derivedDataPath "$derived" \
  -allowProvisioningUpdates DEVELOPMENT_TEAM="$team" CODE_SIGN_STYLE=Automatic \
  COMPILER_INDEX_STORE_ENABLE=NO -jobs 4 build
app="$derived/Build/Products/Release-iphoneos/$scheme.app"
# Bauen geht auch ohne angeschlossenes iPhone; aufgespielt wird, sobald es da ist.
if xcrun devicectl device install app --device "$device" "$app"; then
  echo "FERTIG: $scheme auf $device installiert"
else
  echo "GEBAUT, NICHT INSTALLIERT: $app (iPhone anschließen, entsperren, dann: xcrun devicectl device install app --device \"$device\" \"$app\")"
fi
