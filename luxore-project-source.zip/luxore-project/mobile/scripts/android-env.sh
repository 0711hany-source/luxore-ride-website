#!/usr/bin/env bash
# Source from the project-local Android build scripts.
set -euo pipefail
mobile_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export JAVA_HOME="$mobile_root/.toolchain/jdk/Contents/Home"
export ANDROID_HOME="$mobile_root/.toolchain/android-sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export ANDROID_USER_HOME="$mobile_root/.toolchain/android-user"
export GRADLE_USER_HOME="$mobile_root/.gradle-local"
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"
