#!/usr/bin/env bash
# Runs the real installed Mapbox SDK on an isolated emulator, never a user's phone.
set -euo pipefail
source "$(dirname "$0")/android-env.sh"
serial="${1:-emulator-5554}"
[[ "$serial" == emulator-* ]] || { echo 'Use an isolated test emulator.' >&2; exit 1; }
probe="$mobile_root/artifacts/startup-probe"
tools="$ANDROID_HOME/build-tools/36.0.0"
mkdir -p "$probe/classes" "$probe/dex"
javac -source 8 -target 8 -classpath "$ANDROID_HOME/platforms/android-36/android.jar" -d "$probe/classes" "$mobile_root/tests/mapbox-startup/StartupProbe.java"
"$tools/d8" --lib "$ANDROID_HOME/platforms/android-36/android.jar" --output "$probe/dex" "$probe/classes/de/luxoreride/startuptest/StartupProbe.class"
"$tools/aapt" package -f -M "$mobile_root/tests/mapbox-startup/AndroidManifest.xml" -I "$ANDROID_HOME/platforms/android-36/android.jar" -F "$probe/probe.apk"
(cd "$probe/dex"; zip -q -j ../probe.apk classes.dex)
"$tools/apksigner" sign --ks "$mobile_root/android/app/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android "$probe/probe.apk"
adb -s "$serial" install -r "$probe/probe.apk"
result="$(adb -s "$serial" shell am instrument -w de.luxoreride.startuptest/.StartupProbe)"
printf '%s\n' "$result"
[[ "$result" == *'withoutToken=com.mapbox.maps.MapboxConfigurationException'* && "$result" == *'afterToken=native MapView constructed and destroyed'* && "$result" != *'INSTRUMENTATION_RESULT: failure='* ]] || exit 1
