#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/android-env.sh"
variant="${1:-customer}"
case "$variant" in customer|driver) ;; *) exit 2;; esac
apk="$mobile_root/artifacts/luxore-${variant}-preview-arm64.apk"
expected="de.luxoreride.${variant}.preview"
actual="$(apkanalyzer manifest application-id "$apk")"
[[ "$actual" == "$expected" ]] || { echo "Unexpected application ID: $actual" >&2; exit 1; }
[[ "$(apkanalyzer manifest debuggable "$apk")" == 'false' ]] || { echo 'APK is debuggable' >&2; exit 1; }
permissions="$(apkanalyzer manifest permissions "$apk")"
if [[ "$permissions" == *RECORD_AUDIO* || "$permissions" == *SYSTEM_ALERT_WINDOW* ]]; then
  echo 'Unexpected privileged permission in internal APK' >&2
  exit 1
fi
if [[ "$variant" == driver ]]; then
  [[ "$permissions" == *POST_NOTIFICATIONS* && "$permissions" == *VIBRATE* ]] || { echo 'Driver alert permissions missing' >&2; exit 1; }
  [[ "$permissions" == *ACCESS_BACKGROUND_LOCATION* && "$permissions" == *FOREGROUND_SERVICE_LOCATION* ]] || { echo 'Driver background location permissions missing' >&2; exit 1; }
else
  [[ "$permissions" != *ACCESS_BACKGROUND_LOCATION* ]] || { echo 'Customer must not request background location' >&2; exit 1; }
fi
python3 - "$apk" "$variant" <<'VERIFY_CONFIG'
import json, sys, zipfile
with zipfile.ZipFile(sys.argv[1]) as archive:
    config = json.loads(archive.read('assets/app.config'))
assert config['extra']['variant'] == sys.argv[2], 'Wrong runtime app variant'
assert config['extra']['preview'] is False, 'Design preview unexpectedly enabled'
assert config['version'] == '0.5.2' and config['android']['versionCode'] == 12, 'Unexpected APK version'
assert config['android']['adaptiveIcon']['foregroundImage'].endswith('-adaptive.png'), 'Adaptive icon missing'
assert config['android']['adaptiveIcon']['monochromeImage'].endswith('icon-monochrome.png'), 'Monochrome icon missing'
assert config['name'].endswith(' Test'), 'Missing internal test label'
assert config['android']['allowBackup'] is False, 'Backup unexpectedly enabled'
VERIFY_CONFIG
unzip -l "$apk" assets/index.android.bundle | rg -q 'assets/index.android.bundle'
unzip -l "$apk" 'lib/arm64-v8a/*' | rg -q 'lib/arm64-v8a/'
"$ANDROID_HOME/build-tools/36.0.0/apksigner" verify "$apk"
printf 'PASS: %s; standalone bundle; ARM64 libraries; restricted permissions; APK signature verified.\n' "$expected"
