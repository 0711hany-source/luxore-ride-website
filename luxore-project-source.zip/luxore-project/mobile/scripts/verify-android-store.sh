#!/usr/bin/env bash
# Checks a store bundle built by build-android-store.sh.
set -euo pipefail
source "$(dirname "$0")/android-env.sh"
variant="${1:-customer}"
case "$variant" in customer|driver) ;; *) exit 2;; esac
aab="$mobile_root/artifacts/luxore-${variant}-store.aab"
keystore="$mobile_root/.toolchain/store-signing/luxore-upload.jks"
secret="$mobile_root/.toolchain/store-signing/upload-password"
work="$(mktemp -d)"; trap 'rm -rf "$work"' EXIT
unzip -q "$aab" 'base/assets/app.config' 'base/manifest/AndroidManifest.xml' -d "$work"
python3 - "$work/base/assets/app.config" "$variant" <<'VERIFY_CONFIG'
import json, sys
config = json.load(open(sys.argv[1]))
driver = sys.argv[2] == 'driver'
assert config['extra']['variant'] == sys.argv[2], 'Wrong runtime app variant'
assert config['extra']['preview'] is False, 'Design preview unexpectedly enabled'
assert config['name'] == ('LUXORÉ Driver' if driver else 'LUXORÉ Ride'), 'Store name must not carry a test label'
assert config['android']['package'] == ('de.luxoreride.driver' if driver else 'de.luxoreride.customer'), 'Wrong package'
assert config['android']['allowBackup'] is False, 'Backup unexpectedly enabled'
print('version', config['version'], 'code', config['android']['versionCode'])
VERIFY_CONFIG
manifest="$(strings "$work/base/manifest/AndroidManifest.xml")"
[[ "$manifest" != *RECORD_AUDIO* && "$manifest" != *SYSTEM_ALERT_WINDOW* ]] || { echo 'Unexpected privileged permission' >&2; exit 1; }
if [[ "$variant" == driver ]]; then
  [[ "$manifest" == *ACCESS_BACKGROUND_LOCATION* && "$manifest" == *FOREGROUND_SERVICE_LOCATION* ]] || { echo 'Driver background location permissions missing' >&2; exit 1; }
else
  [[ "$manifest" != *ACCESS_BACKGROUND_LOCATION* ]] || { echo 'Customer must not request background location' >&2; exit 1; }
fi
unzip -l "$aab" | grep 'base/assets/index.android.bundle' >/dev/null
unzip -l "$aab" | grep 'base/lib/arm64-v8a/' >/dev/null
unzip -l "$aab" | grep 'base/lib/armeabi-v7a/' >/dev/null
jarsigner -verify "$aab" >/dev/null
bundle_cert="$(unzip -p "$aab" 'META-INF/*.RSA' | keytool -printcert 2>/dev/null | grep 'SHA256:' | head -1)"
upload_cert="$(keytool -list -v -keystore "$keystore" -storepass:file "$secret" 2>/dev/null | grep 'SHA256:' | head -1)"
[[ -n "$bundle_cert" && "$bundle_cert" == "$upload_cert" ]] || { echo 'Bundle is not signed with the upload key' >&2; exit 1; }
printf 'PASS: %s store bundle; production name and package; arm64 + armv7; restricted permissions; signed with upload key.\n' "$variant"
