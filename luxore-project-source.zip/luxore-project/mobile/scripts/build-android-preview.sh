#!/usr/bin/env bash
# Creates standalone, debug-key-signed INTERNAL TEST APKs, never store releases.
set -euo pipefail
source "$(dirname "$0")/android-env.sh"
variant="${1:-customer}"
case "$variant" in customer|driver) ;; *) echo 'Use customer or driver' >&2; exit 2;; esac
if [[ ! -x "$JAVA_HOME/bin/java" || ! -d "$ANDROID_HOME/platforms/android-36" ]]; then
  echo 'Project-local JDK or Android SDK missing. See README.md.' >&2
  exit 1
fi
cd "$mobile_root"
if [[ -n "$(git ls-files android)" ]]; then
  echo 'Refusing to regenerate tracked native Android source.' >&2
  exit 1
fi
export APP_VARIANT="$variant"
export APP_CHANNEL=internal
export CI=1
pnpm exec expo prebuild --platform android --no-install --clean
cd android
./gradlew :app:assembleRelease -PreactNativeArchitectures=arm64-v8a --no-daemon --max-workers=2 '-Dorg.gradle.jvmargs=-Xmx3072m -XX:MaxMetaspaceSize=1024m -Dfile.encoding=UTF-8'
cd "$mobile_root"
mkdir -p artifacts
cp android/app/build/outputs/apk/release/app-release.apk "artifacts/luxore-${variant}-preview-arm64.apk"
"$ANDROID_HOME/build-tools/36.0.0/apksigner" verify --verbose "artifacts/luxore-${variant}-preview-arm64.apk"
shasum -a 256 "artifacts/luxore-${variant}-preview-arm64.apk"
