#!/usr/bin/env bash
# Builds a Play Store upload bundle (AAB) signed with the local upload key.
# Uploads nothing. The upload key lives outside git in .toolchain/store-signing.
set -euo pipefail
source "$(dirname "$0")/android-env.sh"
variant="${1:-customer}"
case "$variant" in customer|driver) ;; *) echo 'Use customer or driver' >&2; exit 2;; esac
cd "$mobile_root"
if [[ -n "$(git ls-files android)" ]]; then
  echo 'Refusing to regenerate tracked native Android source.' >&2
  exit 1
fi
signing="$mobile_root/.toolchain/store-signing"
keystore="$signing/luxore-upload.jks"
secret="$signing/upload-password"
alias_name=luxore-upload
mkdir -p "$signing" && chmod 700 "$signing"
if [[ ! -f "$keystore" ]]; then
  umask 077
  openssl rand -hex 24 > "$secret"
  keytool -genkeypair -keystore "$keystore" -storetype JKS -alias "$alias_name" \
    -keyalg RSA -keysize 4096 -validity 10950 \
    -storepass:file "$secret" -keypass:file "$secret" \
    -dname 'CN=LUXORE RIDE Upload, O=LUXORE RIDE, L=Frankfurt am Main, C=DE' >/dev/null 2>&1
  echo "Created new upload key: $keystore (keep a backup, never commit)."
fi
export APP_VARIANT="$variant"
export EXPO_PUBLIC_APP_VARIANT="$variant"
export EXPO_PUBLIC_APP_PREVIEW=false
export APP_PREVIEW=false
export APP_CHANNEL=production
export CI=1
node node_modules/expo/bin/cli prebuild --platform android --no-install --clean
cd android
./gradlew :app:bundleRelease -PreactNativeArchitectures=arm64-v8a,armeabi-v7a --no-daemon --max-workers=2 '-Dorg.gradle.jvmargs=-Xmx3072m -XX:MaxMetaspaceSize=1024m -Dfile.encoding=UTF-8'
cd "$mobile_root"
mkdir -p artifacts
out="artifacts/luxore-${variant}-store.aab"
cp android/app/build/outputs/bundle/release/app-release.aab "$out"
# Gradle signs with the debug key; replace it with the upload key.
zip -q -d "$out" 'META-INF/*' >/dev/null 2>&1 || true
jarsigner -keystore "$keystore" -storepass:file "$secret" -keypass:file "$secret" \
  -sigalg SHA256withRSA -digestalg SHA-256 "$out" "$alias_name" >/dev/null
jarsigner -verify "$out" >/dev/null
shasum -a 256 "$out"
