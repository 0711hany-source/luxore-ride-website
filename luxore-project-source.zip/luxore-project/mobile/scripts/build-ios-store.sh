#!/bin/bash
# Baut das Paket für TestFlight / App Store (.ipa) einer App-Variante.
# Lädt NICHTS hoch: Das Hochladen zu Apple braucht jedes Mal die ausdrückliche
# Freigabe von Hanan und einen in App Store Connect angelegten App-Eintrag.
# Braucht das bezahlte Apple-Entwicklerteam. Beim ersten Lauf legt Xcode im
# Apple-Konto die App-Kennung und ein Verteilungszertifikat an.
# Aufruf: IOS_TEAM=<Team-ID> bash scripts/build-ios-store.sh <customer|driver>
# NICHT mit vorangestelltem CommandLineTools-PATH starten (pod install scheitert).
set -euo pipefail
v="${1:-customer}"; team="${IOS_TEAM:?IOS_TEAM fehlt}"
case "$v" in customer|driver) ;; *) echo 'customer oder driver angeben' >&2; exit 2;; esac
export LANG=en_US.UTF-8 PATH="$HOME/.gem/ruby/2.6.0/bin:$PATH"
export APP_VARIANT="$v" EXPO_PUBLIC_APP_VARIANT="$v" EXPO_PUBLIC_APP_PREVIEW=false APP_PREVIEW=false APP_CHANNEL=production CI=1 IOS_FREE_SIGNING=0
cd "$(cd "$(dirname "$0")/.." && pwd)"
node node_modules/expo/bin/cli prebuild --platform ios --no-install --clean
cd ios && pod install
ws=$(ls -d *.xcworkspace | head -1); scheme="${ws%.xcworkspace}"
out="$HOME/LuxoreRide-Bau/ios-store-$v"
mkdir -p "$out"
rm -rf "$out/$scheme.xcarchive" "$out/export"
# Same derived data as the device build: the compiled libraries are reused.
xcodebuild -workspace "$ws" -scheme "$scheme" -configuration Release -sdk iphoneos \
  -destination 'generic/platform=iOS' -derivedDataPath "$HOME/LuxoreRide-Bau/ios-device-$v" \
  -archivePath "$out/$scheme.xcarchive" -allowProvisioningUpdates \
  DEVELOPMENT_TEAM="$team" CODE_SIGN_STYLE=Automatic COMPILER_INDEX_STORE_ENABLE=NO -jobs 4 archive
cat > "$out/export-options.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>method</key><string>app-store-connect</string>
  <key>destination</key><string>export</string>
  <key>teamID</key><string>$team</string>
  <key>signingStyle</key><string>automatic</string>
  <key>manageAppVersionAndBuildNumber</key><false/>
</dict></plist>
EOF
xcodebuild -exportArchive -archivePath "$out/$scheme.xcarchive" -exportPath "$out/export" \
  -exportOptionsPlist "$out/export-options.plist" -allowProvisioningUpdates
ipa=$(ls "$out/export"/*.ipa | head -1)
echo "FERTIG (nicht hochgeladen): $ipa"
