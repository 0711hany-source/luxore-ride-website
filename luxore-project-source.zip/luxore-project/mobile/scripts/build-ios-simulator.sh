#!/bin/bash
# Baut eine App-Variante für den iPhone-Simulator (kein Apple-Konto nötig).
set -euo pipefail
v="${1:-customer}"
export LANG=en_US.UTF-8 PATH="$HOME/.gem/ruby/2.6.0/bin:$PATH"
export APP_VARIANT="$v" EXPO_PUBLIC_APP_VARIANT="$v" EXPO_PUBLIC_APP_PREVIEW=false APP_PREVIEW=false APP_CHANNEL=internal CI=1
cd "$(cd "$(dirname "$0")/.." && pwd)"
node node_modules/expo/bin/cli prebuild --platform ios --no-install --clean
cd ios && pod install
ws=$(ls -d *.xcworkspace | head -1); scheme="${ws%.xcworkspace}"
xcodebuild -workspace "$ws" -scheme "$scheme" -configuration Release -sdk iphonesimulator \
  -destination 'platform=iOS Simulator,name=iPhone 17' -derivedDataPath "$HOME/LuxoreRide-Bau/ios-derived-$v" \
  ARCHS=arm64 ONLY_ACTIVE_ARCH=YES COMPILER_INDEX_STORE_ENABLE=NO -jobs 4 build
mkdir -p "$HOME/LuxoreRide-Bau/ios-apps"
name=$([ "$v" = driver ] && echo LUXORE-Driver-Simulator || echo LUXORE-Ride-Simulator)
rm -rf "$HOME/LuxoreRide-Bau/ios-apps/$name.app"
cp -R "$HOME/LuxoreRide-Bau/ios-derived-$v/Build/Products/Release-iphonesimulator/$scheme.app" "$HOME/LuxoreRide-Bau/ios-apps/$name.app"
echo "FERTIG: $name.app ($scheme)"
