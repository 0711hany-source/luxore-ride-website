# LUXORÉ Launcher-Icons — Stand 0.5.2

Die aktiven Icons stammen aus eigenen editierbaren SVG-Vektoren. Es werden keine Schriftdateien, Bildgeneratoren oder externen Grafikdienste benötigt.

`node scripts/render-app-icons.mjs` erzeugt die Quellen unter `mobile/assets/source/`, quadratische opake 1024px-PNGs für Ride und Driver, transparente adaptive Vordergründe und eine gemeinsame monochrome Android-Ebene. Die Website-Kopien und das Favicon verwenden dasselbe Monogramm.

Ride: Champagnergold auf dunklem Graphit. Driver: Graphit auf Champagner. Beide besitzen exakt dieselbe L-Silhouette mit einer angedeuteten Straßenkurve, ohne kleine Beschriftung im Launcher. Die Form bleibt innerhalb der Android-Sicherheitszone. Die App-Namen unterscheiden die Varianten zusätzlich.

Die App-Konfiguration wählt die Variante; Android übernimmt Form und Farbe der monochromen Ebene. Eine Änderung des installierten Launcher-Icons erfordert eine neue APK. Die bisherigen rasterbasierten Icons sind durch diese Quellen ersetzt.

Prüfung: `node --test tests/app-icon-assets.test.mjs` kontrolliert Exportgröße, Deckkraft, identische Masken und den sicheren Abstand für runde adaptive Icons. Geräte-Launcher unterscheiden sich; reale Geräteprüfung bleibt erforderlich.
