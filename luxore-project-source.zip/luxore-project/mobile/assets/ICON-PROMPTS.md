# LUXORÉ Launcher-Icons

Erstellt mit dem eingebauten Bildgenerator, keine CLI/API. Ride: icon-ride.png. Driver: icon-driver.png.

## Ride — Generierung

Use case: logo-brand. Create one finished square 1024x1024 Android/iOS launcher icon asset for LUXORÉ RIDE, a Frankfurt luxury chauffeur brand. Full bleed uniform rich black background with a beautifully drawn large warm metallic champagne-gold capital L monogram in the center, refined high contrast modern serif, strong readable silhouette at 48px. Tiny geometric accent suggesting a road integrated subtly into the lower stroke, no vehicle picture. The monogram occupies central 55 percent, generous safe margin for circular Android mask. Flat frontal graphic, restrained luxury, crisp smooth edges. No additional letters, words, labels, watermark, mockup, outer rounded frame, shadows outside icon or surrounding page. Actual usable icon artwork only.

## Driver — Bearbeitung des Ride-Icons

Create the matching DRIVER variant of this LUXORÉ RIDE app icon. Preserve the exact centered serif L and road detail silhouette. Reverse colors: large elegant rich black L on full-bleed warm champagne-gold background. Flat square usable launcher icon, no external rounded frame, no surrounding scene. Make the monogram slightly smaller: contained inside central 55% of square for safe Android circular masking, generous margins. Add the word DRIVER in small but bold black sans-serif directly underneath within the central safe area. No other text. Premium clear high contrast; output square.
