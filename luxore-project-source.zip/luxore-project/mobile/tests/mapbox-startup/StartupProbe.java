package de.luxoreride.startuptest;
import android.app.Instrumentation;
import android.os.Bundle;
import android.content.Context;
import android.util.AttributeSet;
import java.lang.reflect.*;
/** Isolated SDK constructor probe. No account, ride, paid token or GPS writes. */
public class StartupProbe extends Instrumentation {
 public void onCreate(Bundle args) { super.onCreate(args); start(); }
 public void onStart() {
  final Bundle result = new Bundle();
  runOnMainSync(() -> {
   try {
    Context context = getTargetContext();
    ClassLoader loader = context.getClassLoader();
    Class<?> options = loader.loadClass("com.mapbox.common.MapboxOptions");
    Method get = options.getMethod("getAccessToken"), set = options.getMethod("setAccessToken", String.class);
    Class<?> map = loader.loadClass("com.mapbox.maps.MapView");
    Constructor<?> constructor = map.getConstructor(Context.class, AttributeSet.class);
    Object original = get.invoke(null);
    try {
     set.invoke(null, "");
     try {
      Object view = constructor.newInstance(context, null);
      map.getMethod("onDestroy").invoke(view);
      result.putString("withoutToken", "unexpected success");
     } catch (InvocationTargetException e) {
      result.putString("withoutToken", e.getCause().toString());
     }
     // Constructor validation only: synthetic key cannot authorize API usage.
     set.invoke(null, "pk.startup-probe-not-a-real-account-token");
     Object view = constructor.newInstance(context, null);
     map.getMethod("onDestroy").invoke(view);
     result.putString("afterToken", "native MapView constructed and destroyed");
    } finally { set.invoke(null, original); }
   } catch (Throwable e) { result.putString("failure", e.toString()); }
  });
  finish(result.containsKey("failure") ? 1 : 0, result);
 }
}
