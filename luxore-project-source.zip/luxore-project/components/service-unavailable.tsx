import Link from 'next/link';
export default function ServiceUnavailable() {
  return <main className="legal-page"><header className="portal-header"><Link href="/" className="lux-logo">LUXORÉ <span>RIDE</span></Link></header><article className="legal-content"><span className="portal-eyebrow">PERSÖNLICH FÜR DICH DA</span><h1>Deine Fahrt. Unser Service.</h1><p>Die Online-Buchung wird gerade eingerichtet. Während der Umstellung erreichst du uns direkt für deine Fahrt.</p><p><a className="lux-button" href="tel:+491605083829">Jetzt anrufen</a></p><p><a href="mailto:booking@luxoreride.de">booking@luxoreride.de</a></p><p>App Store & Google Play: bald verfügbar.</p><Link href="/">Zur Startseite</Link></article></main>;
}
