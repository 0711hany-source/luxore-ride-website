# LUXORÉ RIDE

Private Entwicklungsumgebung für einen Fahrdienst in Frankfurt am Main. Premium und First Class, zunächst eigener Betrieb, später Partnerunternehmen.

Stand, Grenzen und nächste Umsetzung: [Produktumfang](docs/PRODUCT.md).

## Entwicklung
`pnpm install`, `pnpm dev`, `pnpm build`, `pnpm exec tsc --noEmit`, `node --experimental-strip-types --test tests/domain.test.ts`.

D1-Schema: `db/schema.ts`; Migrationen: `pnpm db:generate`. Lokale Migrationen über Wrangler auf DB anwenden. Gastfahrten verwenden geschützte Gerätesitzungen. Eigene Konten verwenden verifizierte E-Mail-Codes und gesonderte Kontositzungen; der Versanddienst muss dafür aktiviert sein. Betreiberzugriff ist serverseitig auf die konfigurierte Betreiberadresse beschränkt. Kunden, Fahrer und Flotten haben getrennte Rechte und Daten. Details zum offiziellen Start: [OFFICIAL-LAUNCH.md](docs/OFFICIAL-LAUNCH.md).

## Aktueller Stand 0.3
Die neue Routenbuchung und getrennte Fahrer-/Dispositionslogik sind unter `app/mobility` und `app/api/mobility` umgesetzt. [Einrichtung, Tests und Betriebsgrenzen](docs/MOBILITY-SETUP.md). Ohne Kartenkonto bleiben echte Routensuche und neue Buchungen gesperrt. Die bisherigen API-Schreibzugriffe für Festpreis-Testfahrten sind deaktiviert. Die alten Testskripte dokumentieren v0.1/v0.2; für den aktuellen Ablauf gelten `tests/mobility.test.ts` und `tests/mobility-api-local.py`.
