export const inquiryClasses = {
  premium: { label: 'Business Class', capacity: 4 },
  first: { label: 'First Class', capacity: 3 },
  van: { label: 'First Class Van', capacity: 6 },
} as const;
export type InquiryClass = keyof typeof inquiryClasses;
export type Inquiry = {
  pickup: string;
  destination: string;
  date: string;
  time: string;
  guests: number;
  service: InquiryClass;
  name: string;
  phone: string;
  notes: string;
};
export function berlinMinute(now: Date): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Berlin',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(now);
  const get = (key: string) => parts.find((p) => p.type === key)?.value;
  return `${get('year')}-${get('month')}-${get('day')}T${get('hour')}:${get('minute')}`;
}
export function prepareInquiry(value: Inquiry, now = new Date()) {
  const tier = inquiryClasses[value.service];
  if (!tier) throw new Error('Bitte wähle eine Fahrzeugklasse.');
  if (!value.pickup.trim() || !value.destination.trim() || !value.name.trim())
    throw new Error('Bitte ergänze Abholort, Ziel und deinen Namen.');
  if (
    value.pickup.trim().toLocaleLowerCase('de') ===
    value.destination.trim().toLocaleLowerCase('de')
  )
    throw new Error('Abholort und Ziel müssen unterschiedlich sein.');
  const instant = `${value.date}T${value.time}`;
  const parsed = new Date(`${instant}:00Z`);
  if (
    !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(instant) ||
    !Number.isFinite(parsed.getTime()) ||
    parsed.toISOString().slice(0, 16) !== instant
  )
    throw new Error('Bitte gib ein gültiges Datum und eine Uhrzeit ein.');
  if (instant <= berlinMinute(now))
    throw new Error(
      'Bitte wähle einen zukünftigen Abholzeitpunkt (Ortszeit Frankfurt).',
    );
  if (
    !Number.isInteger(value.guests) ||
    value.guests < 1 ||
    value.guests > tier.capacity
  )
    throw new Error(
      `${tier.label} bietet Platz für maximal ${tier.capacity} Gäste. Bitte passe die Gästezahl oder Fahrzeugklasse an.`,
    );
  if (
    [value.pickup, value.destination, value.name, value.phone].some(
      (s) => s.length > 180,
    ) ||
    value.notes.length > 600
  )
    throw new Error('Bitte kürze deine Angaben.');
  const date = value.date.split('-').reverse().join('.');
  const subject = `Fahrtanfrage ${tier.label} · ${date}`;
  const body = `Guten Tag LUXORÉ RIDE,\n\nich möchte folgende Fahrt anfragen:\n\nAbholort: ${value.pickup.trim()}\nZiel: ${value.destination.trim()}\nDatum: ${date}\nUhrzeit: ${value.time} Uhr (Ortszeit Frankfurt, Europe/Berlin)\nGäste: ${value.guests}\nFahrzeugklasse: ${tier.label}\n\nName: ${value.name.trim()}\nTelefon: ${value.phone.trim() || 'Nicht angegeben'}\nWünsche / Flugnummer: ${value.notes.trim() || 'Keine Angabe'}\n\nBitte bestätigt mir Verfügbarkeit, Fahrpreis und Konditionen.\nMir ist bekannt, dass dies eine Anfrage und noch keine bestätigte Buchung ist.\n\nVielen Dank!`;
  return {
    subject,
    body,
    mailto: `mailto:booking@luxoreride.de?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`,
  };
}
