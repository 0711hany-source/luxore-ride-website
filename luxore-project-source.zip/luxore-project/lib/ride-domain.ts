export const locations = [
  'Frankfurt Flughafen · Terminal 1',
  'Frankfurt Hauptbahnhof',
  'Alte Oper · Opernplatz',
  'Messe Frankfurt',
  'Westend · Palmengarten',
] as const;
// Keep the original IDs (premium/first/van) so existing bookings remain compatible.
// Display order: Business, Electric, First Class Van, First Class.
// `onRequest` classes are never shown as immediately available.
export const classes = [
  {
    id: 'premium',
    name: 'Business Class',
    detail: 'Mercedes E-Klasse / Audi A6',
    capacity: '4 Gäste · 2 Koffer',
    image: '/brand/business.png',
    transfer: 7500,
    perKm: 250,
    note: 'Souverän durch den Tag.',
    onRequest: false,
  },
  {
    id: 'electric',
    name: 'Electric Class',
    detail: 'Mercedes EQE 300',
    capacity: '4 Gäste · 2 Koffer',
    image: '/brand/electric.png',
    // Legacy reference value only, set in proportion to the kilometre price.
    transfer: 8400,
    perKm: 280,
    note: 'Leise und elektrisch unterwegs.',
    onRequest: false,
  },
  {
    id: 'van',
    name: 'First Class Van',
    detail: 'Mercedes V-Klasse',
    capacity: '6 Gäste · 6 Koffer',
    image: '/brand/van.png',
    transfer: 8500,
    perKm: 300,
    note: 'Gemeinsam erstklassig reisen.',
    onRequest: false,
  },
  {
    id: 'first',
    name: 'First Class',
    detail: 'Mercedes S-Klasse',
    capacity: '3 Gäste · 2 Koffer',
    image: '/brand/first-class.png',
    transfer: 9500,
    perKm: 350,
    note: 'Raum für das Besondere.',
    onRequest: true,
  },
] as const;
export type RideClass = 'premium' | 'electric' | 'van' | 'first';
/** Shown wherever First Class appears: it is never offered as immediately available. */
export const ON_REQUEST_LABEL = 'nur auf Anfrage';
export const BUSY_LABEL = 'besetzt';
export const BUSY_HINT =
  'Aktuell ist kein freier Chauffeur dieser Klasse online. Du kannst trotzdem anfragen – die Fahrt ist erst zugesagt, wenn ein Chauffeur annimmt.';
export const ON_REQUEST_HINT =
  'First Class ist nur auf Anfrage erhältlich. Die Fahrt ist erst zugesagt, wenn ein Chauffeur annimmt.';
export const isOnRequest = (id: string) =>
  classes.some((c) => c.id === id && c.onRequest);
export const className = (id: RideClass) =>
  classes.find((c) => c.id === id)?.name ?? 'Unbekannte Klasse';
export type Status =
  | 'requested'
  | 'accepted'
  | 'arrived'
  | 'riding'
  | 'completed'
  | 'cancelled';
export const labels: Record<Status, string> = {
  requested: 'Angefragt',
  accepted: 'Fahrer unterwegs',
  arrived: 'Fahrer angekommen',
  riding: 'Fahrt läuft',
  completed: 'Abgeschlossen',
  cancelled: 'Storniert',
};
export const transitions: Record<Status, Status[]> = {
  requested: ['accepted', 'cancelled'],
  accepted: ['arrived', 'cancelled'],
  arrived: ['riding', 'cancelled'],
  riding: ['completed'],
  completed: [],
  cancelled: [],
};
export type Ride = {
  id: string;
  pickup: string;
  destination: string;
  service: RideClass;
  price: number;
  status: Status;
  created_at: number;
  scheduled_at: string | null;
};
export function quote(pickup: string, destination: string, service: string) {
  if (
    !locations.includes(pickup as (typeof locations)[number]) ||
    !locations.includes(destination as (typeof locations)[number]) ||
    pickup === destination
  )
    throw new Error('Bitte unterschiedliche Start- und Zielorte auswählen.');
  const tier = classes.find((c) => c.id === service);
  if (!tier) throw new Error('Unbekannte Fahrzeugklasse.');
  // Published transfer reference only, not a route-specific fare calculation.
  return tier.transfer;
}
export const money = (cents: number) =>
  new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(
    cents / 100,
  );
