export const locations = [
  'Frankfurt Flughafen · Terminal 1',
  'Frankfurt Hauptbahnhof',
  'Alte Oper · Opernplatz',
  'Messe Frankfurt',
  'Westend · Palmengarten',
] as const;
// Keep the original premium ID so existing Business test bookings remain compatible.
export const classes = [
  {
    id: 'premium',
    name: 'Business Class',
    detail: 'Mercedes E-Klasse / Audi A6',
    capacity: '4 Gäste · 2 Koffer',
    image: '/brand/business.png',
    transfer: 7500,
    perKm: 250,
    note: 'Souverän durch den Tag.',
  },
  {
    id: 'first',
    name: 'First Class',
    detail: 'Mercedes S-Klasse',
    capacity: '3 Gäste · 2 Koffer',
    image: '/brand/first-class.png',
    transfer: 9500,
    perKm: 350,
    note: 'Raum für das Besondere.',
  },
  {
    id: 'van',
    name: 'First Class Van',
    detail: 'Mercedes V-Klasse',
    capacity: '6 Gäste · 6 Koffer',
    image: '/brand/van.png',
    transfer: 8500,
    perKm: 300,
    note: 'Gemeinsam erstklassig reisen.',
  },
] as const;
export type RideClass = 'premium' | 'first' | 'van';
export const className = (id: RideClass) =>
  classes.find((c) => c.id === id)?.name ?? 'Unbekannte Klasse';
export type Status =
  | 'requested'
  | 'accepted'
  | 'arrived'
  | 'riding'
  | 'completed'
  | 'cancelled';
export const labels: Record<Status, string> = {
  requested: 'Angefragt',
  accepted: 'Fahrer unterwegs',
  arrived: 'Fahrer angekommen',
  riding: 'Fahrt läuft',
  completed: 'Abgeschlossen',
  cancelled: 'Storniert',
};
export const transitions: Record<Status, Status[]> = {
  requested: ['accepted', 'cancelled'],
  accepted: ['arrived', 'cancelled'],
  arrived: ['riding', 'cancelled'],
  riding: ['completed'],
  completed: [],
  cancelled: [],
};
export type Ride = {
  id: string;
  pickup: string;
  destination: string;
  service: RideClass;
  price: number;
  status: Status;
  created_at: number;
  scheduled_at: string | null;
};
export function quote(pickup: string, destination: string, service: string) {
  if (
    !locations.includes(pickup as (typeof locations)[number]) ||
    !locations.includes(destination as (typeof locations)[number]) ||
    pickup === destination
  )
    throw new Error('Bitte unterschiedliche Start- und Zielorte auswählen.');
  const tier = classes.find((c) => c.id === service);
  if (!tier) throw new Error('Unbekannte Fahrzeugklasse.');
  // Published transfer reference only, not a route-specific fare calculation.
  return tier.transfer;
}
export const money = (cents: number) =>
  new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(
    cents / 100,
  );
