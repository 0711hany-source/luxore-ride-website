import type { SqlDatabase, SqlStatement } from '@/db/sqlite';
import { ApiError } from './server';
import { berlinDate, validDate } from './settlement';
import { PROFILE_MISSING, PROFILE_OWNER, profilePhotoId } from './profile';

export type SubjectType = 'driver' | 'vehicle' | 'fleet';
export type KindRule = {
  label: string;
  required: boolean;
  /** Whether an expiry date must, may or cannot be given. */
  expiry: 'required' | 'optional' | 'none';
};
/** Which papers exist per subject. Single place to change the rules. */
export const DOCUMENT_KINDS: Record<SubjectType, Record<string, KindRule>> = {
  driver: {
    license: { label: 'Führerschein', required: true, expiry: 'required' },
    pbs: {
      label: 'Personenbeförderungsschein',
      required: true,
      expiry: 'required',
    },
    id: { label: 'Ausweis', required: false, expiry: 'optional' },
  },
  vehicle: {
    registration: {
      label: 'Fahrzeugschein (Zulassung Teil I)',
      required: true,
      expiry: 'none',
    },
    insurance: {
      label: 'Versicherungsnachweis',
      required: true,
      expiry: 'optional',
    },
    concession: {
      label: 'Konzession / Genehmigungsurkunde',
      required: true,
      expiry: 'required',
    },
    hu: { label: 'HU-Nachweis', required: true, expiry: 'required' },
  },
  fleet: {
    business: {
      label: 'Gewerbeanmeldung / Genehmigung',
      required: true,
      expiry: 'optional',
    },
  },
};
export const INSPECTION_INTERVAL_DAYS = 7;
/** Papers: warn this many days before expiry. */
export const EXPIRY_WARNING_DAYS = 14;
/** Weekly check: warn this many days before it is due. */
export const INSPECTION_WARNING_DAYS = 3;
export const INSPECTION_ITEMS = {
  front: 'Außen vorne',
  rear: 'Außen hinten',
  left: 'Außen links',
  right: 'Außen rechts',
  clean: 'Innenraum sauber',
  equipment: 'Ausstattung vollständig',
  tires: 'Reifen',
  lights: 'Licht',
} as const;
export type InspectionItem = keyof typeof INSPECTION_ITEMS;
export const INSPECTION_SLOTS = {
  front: 'Vorne',
  rear: 'Hinten',
  left: 'Links',
  right: 'Rechts',
  interior: 'Innenraum',
  extra: 'Weiteres Foto',
} as const;
export const isSubjectType = (v: unknown): v is SubjectType =>
  v === 'driver' || v === 'vehicle' || v === 'fleet';
const ENFORCED_KEY = 'compliance_enforced_since';
const germanDate = (date: string) => date.split('-').reverse().join('.');
const dayMs = 86400000;
const daysBetween = (from: string, to: string) =>
  Math.round((Date.parse(to + 'T12:00:00Z') - Date.parse(from + 'T12:00:00Z')) / dayMs);

/** Enforcement is off unless the operator switched it on. */
export async function enforcedSince(database: SqlDatabase) {
  const row = await database
    .prepare('SELECT value FROM mobility_settings WHERE key=?')
    .bind(ENFORCED_KEY)
    .first<{ value: string }>();
  const value = row?.value;
  const at = Number(value);
  return value && Number.isFinite(at) && at > 0 ? at : null;
}
export async function setEnforcement(
  database: SqlDatabase,
  enabled: boolean,
  actorId: string,
  now = Date.now(),
) {
  await database
    .prepare(
      'INSERT INTO mobility_settings(key,value,updated_at,updated_by) VALUES(?,?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at,updated_by=excluded.updated_by',
    )
    .bind(ENFORCED_KEY, enabled ? String(now) : '', now, actorId)
    .run();
}
export type DocumentRow = {
  id: string;
  subject_type: SubjectType;
  subject_id: string;
  fleet_id: string | null;
  kind: string;
  number: string | null;
  expires_on: string | null;
  status: 'submitted' | 'approved' | 'rejected';
  reason: string | null;
  uploaded_by: string;
  created_at: number;
  reviewed_by: string | null;
  reviewed_at: number | null;
};
export type PaperState = {
  kind: string;
  label: string;
  required: boolean;
  state: 'missing' | 'submitted' | 'rejected' | 'approved' | 'expired';
  expiresOn: string | null;
  daysLeft: number | null;
  reason: string | null;
};
/** Pure: the state of each paper kind from the stored documents. */
export function paperStates(
  type: SubjectType,
  documents: Pick<
    DocumentRow,
    'kind' | 'status' | 'expires_on' | 'reason' | 'created_at'
  >[],
  today: string,
): PaperState[] {
  return Object.entries(DOCUMENT_KINDS[type]).map(([kind, rule]) => {
    const own = documents
      .filter((d) => d.kind === kind)
      .sort((a, b) => b.created_at - a.created_at);
    const approved = own.filter((d) => d.status === 'approved');
    // A valid approved paper counts even while a newer one is under review.
    const valid = approved
      .filter((d) => !d.expires_on || d.expires_on >= today)
      .sort((a, b) =>
        (b.expires_on || '9999').localeCompare(a.expires_on || '9999'),
      )[0];
    const base = { kind, label: rule.label, required: rule.required };
    if (valid)
      return {
        ...base,
        state: 'approved',
        expiresOn: valid.expires_on,
        daysLeft: valid.expires_on ? daysBetween(today, valid.expires_on) : null,
        reason: null,
      };
    const latest = own[0];
    if (!latest)
      return {
        ...base,
        state: 'missing',
        expiresOn: null,
        daysLeft: null,
        reason: null,
      };
    if (latest.status === 'approved')
      return {
        ...base,
        state: 'expired',
        expiresOn: latest.expires_on,
        daysLeft: latest.expires_on
          ? daysBetween(today, latest.expires_on)
          : null,
        reason: null,
      };
    return {
      ...base,
      state: latest.status,
      expiresOn: latest.expires_on,
      daysLeft: null,
      reason: latest.status === 'rejected' ? latest.reason : null,
    };
  });
}
/** German sentence for a paper that does not (yet) permit driving. */
export function paperProblem(paper: PaperState) {
  if (paper.state === 'approved') return null;
  if (paper.state === 'expired')
    return `${paper.label} abgelaufen am ${paper.expiresOn ? germanDate(paper.expiresOn) : '–'}`;
  if (paper.state === 'submitted') return `${paper.label} wird noch geprüft`;
  if (paper.state === 'rejected')
    return `${paper.label} wurde abgelehnt${paper.reason ? ': ' + paper.reason : ''}`;
  return `${paper.label} fehlt`;
}
export function paperWarning(paper: PaperState) {
  if (
    paper.state !== 'approved' ||
    paper.daysLeft === null ||
    paper.daysLeft > EXPIRY_WARNING_DAYS
  )
    return null;
  return paper.daysLeft === 0
    ? `${paper.label} läuft heute ab`
    : `${paper.label} läuft in ${paper.daysLeft} ${paper.daysLeft === 1 ? 'Tag' : 'Tagen'} ab`;
}
export async function subjectPapers(
  database: SqlDatabase,
  type: SubjectType,
  id: string,
  today: string,
) {
  const rows = await database
    .prepare(
      'SELECT kind,status,expires_on,reason,created_at FROM mobility_documents WHERE subject_type=? AND subject_id=?',
    )
    .bind(type, id)
    .all<DocumentRow>();
  return paperStates(type, rows.results, today);
}
export type InspectionState = {
  lastPassedAt: number | null;
  dueAt: number | null;
  state: 'ok' | 'due' | 'never';
  daysLeft: number | null;
  latestResult: 'ok' | 'defect' | null;
  latestAt: number | null;
};
export function inspectionState(
  lastPassedAt: number | null,
  latest: { result: string; created_at: number } | null,
  now: number,
): InspectionState {
  const dueAt =
    lastPassedAt === null
      ? null
      : lastPassedAt + INSPECTION_INTERVAL_DAYS * dayMs;
  return {
    lastPassedAt,
    dueAt,
    state: dueAt === null ? 'never' : dueAt > now ? 'ok' : 'due',
    daysLeft:
      dueAt === null || dueAt <= now ? null : Math.floor((dueAt - now) / dayMs),
    latestResult: latest ? (latest.result === 'ok' ? 'ok' : 'defect') : null,
    latestAt: latest ? Number(latest.created_at) : null,
  };
}
export async function vehicleInspection(
  database: SqlDatabase,
  vehicleId: string,
  now: number,
) {
  const passedRow = await database
    .prepare(
      "SELECT MAX(created_at) AS at FROM mobility_inspections WHERE vehicle_id=? AND result='ok'",
    )
    .bind(vehicleId)
    .first<{ at: number | null }>();
  const passed = passedRow?.at ?? null;
  const latest = await database
    .prepare(
      'SELECT result,created_at FROM mobility_inspections WHERE vehicle_id=? ORDER BY created_at DESC LIMIT 1',
    )
    .bind(vehicleId)
    .first<{ result: string; created_at: number }>();
  return inspectionState(passed === null ? null : Number(passed), latest, now);
}
export type SuspensionRow = {
  id: string;
  subject_type: SubjectType;
  subject_id: string;
  fleet_id: string | null;
  level: 'operator' | 'fleet';
  reason: string;
  created_by: string;
  created_by_name: string;
  created_at: number;
  lifted_by: string | null;
  lifted_by_name: string | null;
  lifted_at: number | null;
};
const by = (level: string) =>
  level === 'operator' ? 'den Betreiber' : 'die Flottenleitung';
export type DriverCompliance = {
  enforcedSince: number | null;
  /** Always stop the next shift start (explicit holds). */
  holds: string[];
  /** Stop the next shift start only while enforcement is on. */
  requirements: string[];
  /** Friendly hints: papers and checks that are due soon. */
  warnings: string[];
  vehicle: { id: string; plate: string } | null;
  inspection: InspectionState | null;
};
/** Everything that decides whether this driver may start a shift. */
export async function driverCompliance(
  database: SqlDatabase,
  driverId: string,
  now = Date.now(),
): Promise<DriverCompliance> {
  const today = berlinDate(now);
  const context = await database
    .prepare(
      `SELECT d.vehicle_id,v.plate,e.fleet_id FROM mobility_drivers d
       LEFT JOIN mobility_employees e ON e.user_id=d.id
       LEFT JOIN mobility_vehicles v ON v.id=d.vehicle_id WHERE d.id=?`,
    )
    .bind(driverId)
    .first<{
      vehicle_id: string | null;
      plate: string | null;
      fleet_id: string | null;
    }>();
  const vehicleId = context?.vehicle_id || null,
    fleetId = context?.fleet_id || null,
    plate = context?.plate || 'dein Fahrzeug';
  const suspensions = await database
    .prepare(
      `SELECT subject_type,level,reason FROM mobility_suspensions WHERE lifted_at IS NULL AND
       ((subject_type='driver' AND subject_id=?) OR (subject_type='vehicle' AND subject_id=?) OR (subject_type='fleet' AND subject_id=?))
       ORDER BY CASE level WHEN 'operator' THEN 0 ELSE 1 END,created_at`,
    )
    .bind(driverId, vehicleId ?? '', fleetId ?? '')
    .all<Pick<SuspensionRow, 'subject_type' | 'level' | 'reason'>>();
  const holds = suspensions.results.map((s) =>
    s.subject_type === 'driver'
      ? `Du bist durch ${by(s.level)} gesperrt: ${s.reason}`
      : s.subject_type === 'vehicle'
        ? `Fahrzeug ${plate} ist durch ${by(s.level)} gesperrt: ${s.reason}`
        : `Deine Flotte ist durch den Betreiber gesperrt: ${s.reason}`,
  );
  const requirements: string[] = [],
    warnings: string[] = [];
  const collect = (papers: PaperState[], suffix = '') => {
    for (const paper of papers) {
      if (!paper.required && paper.state !== 'approved') continue;
      const problem = paper.required ? paperProblem(paper) : null;
      if (problem) requirements.push(problem + suffix);
      const warning = paperWarning(paper);
      if (warning) warnings.push(warning + suffix);
    }
  };
  collect(await subjectPapers(database, 'driver', driverId, today));
  // The profile picture is a required item like a paper: it stops a shift
  // only while enforcement is on, otherwise it is a hint.
  if (!(await profilePhotoId(database, driverId)))
    requirements.push(PROFILE_MISSING);
  let inspection: InspectionState | null = null;
  if (vehicleId) {
    collect(
      await subjectPapers(database, 'vehicle', vehicleId, today),
      ` (Fahrzeug ${plate})`,
    );
    inspection = await vehicleInspection(database, vehicleId, now);
    if (inspection.state !== 'ok')
      requirements.push(`Wochenkontrolle für ${plate} fällig`);
    else if (
      inspection.daysLeft !== null &&
      inspection.daysLeft < INSPECTION_WARNING_DAYS
    )
      warnings.push(
        inspection.daysLeft === 0
          ? `Wochenkontrolle für ${plate} ist heute fällig`
          : `Wochenkontrolle für ${plate} in ${inspection.daysLeft} ${inspection.daysLeft === 1 ? 'Tag' : 'Tagen'} fällig`,
      );
  }
  if (fleetId)
    collect(await subjectPapers(database, 'fleet', fleetId, today), ' (Flotte)');
  return {
    enforcedSince: await enforcedSince(database),
    holds,
    requirements,
    warnings,
    vehicle: vehicleId ? { id: vehicleId, plate } : null,
    inspection,
  };
}
/**
 * Called inside the shift-start transaction. Explicit holds always refuse;
 * papers and the weekly check refuse only while enforcement is switched on.
 * A running ride or shift is never touched here.
 */
export async function assertMayGoOnline(
  transaction: SqlDatabase,
  driverId: string,
  now: number,
) {
  const state = await driverCompliance(transaction, driverId, now);
  const reasons = [
    ...state.holds,
    ...(state.enforcedSince ? state.requirements : []),
  ];
  if (reasons.length)
    throw new ApiError(
      403,
      'Online gehen ist gerade nicht möglich: ' + reasons.join(' · ') + '.',
    );
}
export type Access = {
  /** May upload and see: operator, fleet lead of the subject, or the subject. */
  allowed: boolean;
  fleetId: string | null;
  exists: boolean;
};
/**
 * Server-side rights for papers, photos and checks of one subject.
 * scope: 'all' for the operator, a fleet id for its owner/deputy, else null.
 */
export async function subjectAccess(
  database: SqlDatabase,
  userId: string,
  scope: string | null,
  type: SubjectType,
  id: string,
): Promise<Access> {
  let fleetId: string | null = null,
    exists = false,
    own = false;
  if (type === 'driver') {
    const row = await database
      .prepare(
        'SELECT d.id,e.fleet_id FROM mobility_drivers d LEFT JOIN mobility_employees e ON e.user_id=d.id WHERE d.id=?',
      )
      .bind(id)
      .first<{ id: string; fleet_id: string | null }>();
    exists = !!row;
    fleetId = row?.fleet_id || null;
    own = exists && id === userId;
  } else if (type === 'vehicle') {
    const row = await database
      .prepare('SELECT fleet_id FROM mobility_vehicles WHERE id=?')
      .bind(id)
      .first<{ fleet_id: string }>();
    exists = !!row;
    fleetId = row?.fleet_id || null;
  } else {
    const fleet = await database
      .prepare('SELECT id FROM mobility_fleets WHERE id=?')
      .bind(id)
      .first();
    if (fleet) {
      exists = true;
      fleetId = id;
    } else {
      // The future fleet of a pending application: its applicant may add papers.
      const application = await database
        .prepare(
          "SELECT account_id FROM mobility_fleet_applications WHERE fleet_id=? AND status='submitted'",
        )
        .bind(id)
        .first<{ account_id: string }>();
      exists = !!application;
      own = application?.account_id === userId;
    }
  }
  return {
    exists,
    fleetId,
    allowed:
      exists && (scope === 'all' || own || (!!fleetId && scope === fleetId)),
  };
}
export function parseExpiry(value: unknown, rule: KindRule) {
  if (value === undefined || value === null || value === '') {
    if (rule.expiry === 'required')
      throw new ApiError(400, `Bitte das Ablaufdatum für „${rule.label}“ angeben.`);
    return null;
  }
  if (rule.expiry === 'none') return null;
  if (!validDate(value))
    throw new ApiError(400, 'Bitte ein gültiges Ablaufdatum angeben.');
  return value;
}
const idleRide = (alias: string) =>
  `NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.driver_id=${alias}.id AND (b.status IN ('accepted','arrived','riding') OR (b.status='completed' AND b.completed_at IS NOT NULL AND b.payment_status='unpaid')))`;
const affected = (type: SubjectType) =>
  type === 'driver'
    ? 'mobility_drivers.id=?'
    : type === 'vehicle'
      ? 'mobility_drivers.vehicle_id=?'
      : 'EXISTS(SELECT 1 FROM mobility_employees e WHERE e.user_id=mobility_drivers.id AND e.fleet_id=?)';
/**
 * Places a hold. Affected drivers without a running ride or open payment go
 * offline at once; a running ride is never interrupted — for those the hold
 * applies at the next shift start.
 */
export async function suspend(
  transaction: SqlDatabase,
  actor: { userId: string; name: string },
  level: 'operator' | 'fleet',
  type: SubjectType,
  id: string,
  fleetId: string | null,
  reason: string,
  now = Date.now(),
) {
  const existing = await transaction
    .prepare(
      'SELECT id FROM mobility_suspensions WHERE subject_type=? AND subject_id=? AND level=? AND lifted_at IS NULL',
    )
    .bind(type, id, level)
    .first<{ id: string }>();
  if (existing) return { id: existing.id, replayed: true };
  const suspensionId = crypto.randomUUID();
  await transaction.batch([
    transaction
      .prepare(
        'INSERT INTO mobility_suspensions(id,subject_type,subject_id,fleet_id,level,reason,created_by,created_by_name,created_at) VALUES(?,?,?,?,?,?,?,?,?)',
      )
      .bind(
        suspensionId,
        type,
        id,
        fleetId,
        level,
        reason,
        actor.userId,
        actor.name,
        now,
      ),
    transaction
      .prepare(
        `UPDATE mobility_offers SET status='withdrawn' WHERE status='pending' AND driver_id IN (SELECT id FROM mobility_drivers WHERE ${affected(type)} AND ${idleRide('mobility_drivers')})`,
      )
      .bind(id),
    transaction
      .prepare(
        `DELETE FROM mobility_location_sessions WHERE driver_id IN (SELECT id FROM mobility_drivers WHERE ${affected(type)} AND ${idleRide('mobility_drivers')})`,
      )
      .bind(id),
    transaction
      .prepare(
        `UPDATE mobility_drivers SET online=0,session_id=NULL WHERE ${affected(type)} AND ${idleRide('mobility_drivers')}`,
      )
      .bind(id),
  ]);
  return { id: suspensionId };
}
/** A fleet lead lifts only fleet-level holds; an operator hold stays. */
export async function liftSuspension(
  transaction: SqlDatabase,
  actor: { userId: string; name: string },
  scope: string,
  suspensionId: string,
  now = Date.now(),
) {
  const row = await transaction
    .prepare('SELECT * FROM mobility_suspensions WHERE id=?')
    .bind(suspensionId)
    .first<SuspensionRow>();
  if (!row || (scope !== 'all' && row.fleet_id !== scope))
    throw new ApiError(404, 'Sperre nicht gefunden.');
  if (scope !== 'all' && row.level !== 'fleet')
    throw new ApiError(
      403,
      'Diese Sperre hat der Betreiber gesetzt. Nur der Betreiber kann sie aufheben.',
    );
  if (row.lifted_at !== null) return row;
  await transaction
    .prepare(
      'UPDATE mobility_suspensions SET lifted_by=?,lifted_by_name=?,lifted_at=? WHERE id=? AND lifted_at IS NULL',
    )
    .bind(actor.userId, actor.name, now, suspensionId)
    .run();
  return row;
}
/** Statements that remove all papers, checks and photos of one subject. */
export function purgeStatements(
  database: SqlDatabase,
  type: SubjectType,
  id: string,
): SqlStatement[] {
  const statements = [
    database
      .prepare(
        "DELETE FROM mobility_images WHERE owner_type='document' AND owner_id IN (SELECT id FROM mobility_documents WHERE subject_type=? AND subject_id=?)",
      )
      .bind(type, id),
    database
      .prepare(
        'DELETE FROM mobility_documents WHERE subject_type=? AND subject_id=?',
      )
      .bind(type, id),
  ];
  if (type === 'vehicle')
    statements.push(
      database
        .prepare(
          "DELETE FROM mobility_images WHERE owner_type='inspection' AND owner_id IN (SELECT id FROM mobility_inspections WHERE vehicle_id=?)",
        )
        .bind(id),
      database
        .prepare('DELETE FROM mobility_inspections WHERE vehicle_id=?')
        .bind(id),
    );
  return statements;
}
/** Appended to the existing account erasure: papers go, names are blanked. */
export function accountErasureStatements(
  database: SqlDatabase,
  accountId: string,
): SqlStatement[] {
  const gone = 'Gelöschtes Profil';
  return [
    ...purgeStatements(database, 'driver', accountId),
    // Profile picture, taken-over reservations and written comments (0021).
    database
      .prepare('DELETE FROM mobility_images WHERE owner_type=? AND owner_id=?')
      .bind(PROFILE_OWNER, accountId),
    database
      .prepare(
        "UPDATE mobility_bookings SET assigned_driver_id=NULL,assigned_fleet_id=NULL,assigned_vehicle_id=NULL,assigned_at=NULL WHERE assigned_driver_id=? AND status='reserved'",
      )
      .bind(accountId),
    database
      .prepare('UPDATE mobility_ratings SET comment=NULL WHERE rater_id=?')
      .bind(accountId),
    // Papers of an unanswered application belong to the applicant alone.
    database
      .prepare(
        "DELETE FROM mobility_images WHERE owner_type='document' AND owner_id IN (SELECT d.id FROM mobility_documents d JOIN mobility_fleet_applications a ON a.fleet_id=d.subject_id AND d.subject_type='fleet' WHERE a.account_id=? AND a.status<>'approved')",
      )
      .bind(accountId),
    database
      .prepare(
        "DELETE FROM mobility_documents WHERE subject_type='fleet' AND subject_id IN (SELECT fleet_id FROM mobility_fleet_applications WHERE account_id=? AND status<>'approved')",
      )
      .bind(accountId),
    database
      .prepare(
        "UPDATE mobility_fleet_applications SET contact=?,phone='',status=CASE WHEN status='submitted' THEN 'withdrawn' ELSE status END WHERE account_id=?",
      )
      .bind(gone, accountId),
    database
      .prepare(
        'UPDATE mobility_inspections SET inspector_name=? WHERE inspector_id=?',
      )
      .bind(gone, accountId),
    database
      .prepare(
        'UPDATE mobility_suspensions SET created_by_name=? WHERE created_by=?',
      )
      .bind(gone, accountId),
    database
      .prepare(
        'UPDATE mobility_suspensions SET lifted_by_name=? WHERE lifted_by=?',
      )
      .bind(gone, accountId),
    database
      .prepare(
        "DELETE FROM mobility_suspensions WHERE subject_type='driver' AND subject_id=?",
      )
      .bind(accountId),
  ];
}
/** Name shown in histories: staff or driver profile, else the account name. */
export async function actorName(
  database: SqlDatabase,
  user: { userId: string; displayName: string },
) {
  const row = await database
    .prepare(
      'SELECT name FROM mobility_employees WHERE user_id=? UNION ALL SELECT name FROM mobility_drivers WHERE id=? LIMIT 1',
    )
    .bind(user.userId, user.userId)
    .first<{ name: string }>();
  return (row?.name || user.displayName || 'Mitarbeiter').slice(0, 80);
}
