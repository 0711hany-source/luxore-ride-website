import type { Service } from './domain';
export type VehicleInput = {
  model: string;
  plate: string;
  services: Service[];
};
export type VehicleErrors = Partial<Record<keyof VehicleInput, string>>;
export function validateVehicleInput(input: {
  model?: unknown;
  plate?: unknown;
  services?: unknown;
}) {
  const errors: VehicleErrors = {};
  const model =
    typeof input.model === 'string'
      ? input.model.trim().replace(/\s+/g, ' ')
      : '';
  const plate =
    typeof input.plate === 'string'
      ? input.plate
          .normalize('NFKC')
          .trim()
          .toUpperCase()
          .replace(/[‐‑‒–—−]/g, '-')
          .replace(/\s+/g, ' ')
      : '';
  if (!model || model.length > 80)
    errors.model = 'Bitte das Fahrzeugmodell angeben (höchstens 80 Zeichen).';
  if (!plate || plate.length > 20 || !/[\p{L}\p{N}]/u.test(plate))
    errors.plate = 'Bitte ein Kennzeichen mit höchstens 20 Zeichen angeben.';
  const services = Array.isArray(input.services)
    ? [...new Set(input.services)]
    : [];
  if (
    !services.length ||
    !services.every(
      (s) => typeof s === 'string' && ['premium', 'first', 'van'].includes(s),
    )
  )
    errors.services = 'Bitte mindestens eine gültige Fahrzeugklasse wählen.';
  return {
    errors,
    value: Object.keys(errors).length
      ? null
      : { model, plate, services: services as Service[] },
  };
}
