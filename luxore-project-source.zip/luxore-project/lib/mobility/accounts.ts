import type { AppUser } from '@/lib/identity';
import { ApiError, settings, tokenHash } from './server';
import { accountsConfigured, runtimeDatabase } from '@/db/sqlite';
export const accountDb = () => runtimeDatabase('account');
const db = accountDb;

export const accountCookie = 'luxore_account';
export type Account = {
  id: string;
  email: string;
  name: string;
  phone: string;
  kind: 'customer' | 'driver' | 'fleet';
  status: 'active' | 'blocked' | 'deletion_pending';
  verified_at: number;
  created_at: number;
  deletion_requested_at: number | null;
};
export function cookieToken(h: Headers, name = accountCookie) {
  const bearer = name === accountCookie ? h.get('authorization') : null;
  if (bearer !== null)
    return /^Bearer [a-f0-9]{64}$/.test(bearer) ? bearer.slice(7) : null;
  const token = h
    .get('cookie')
    ?.split(';')
    .map((v) => v.trim())
    .find((v) => v.startsWith(name + '='))
    ?.slice(name.length + 1);
  return token && /^[a-f0-9]{64}$/.test(token) ? token : null;
}
export function randomToken() {
  return Array.from(crypto.getRandomValues(new Uint8Array(32)), (b) =>
    b.toString(16).padStart(2, '0'),
  ).join('');
}
export function normalizeEmail(v: unknown) {
  if (typeof v !== 'string')
    throw new ApiError(400, 'Bitte eine gültige E-Mail-Adresse eingeben.');
  const email = v.trim().toLowerCase();
  if (email.length > 254 || !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(email))
    throw new ApiError(400, 'Bitte eine gültige E-Mail-Adresse eingeben.');
  return email;
}
export function mailSender() {
  const config = settings();
  if (config.LUXORE_MAIL_FROM?.trim()) return config.LUXORE_MAIL_FROM.trim();
  const domain = config.RESEND_EMAIL_DOMAIN?.trim().toLowerCase();
  return domain && /^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}$/.test(domain)
    ? `LUXORÉ RIDE <konto@${domain}>`
    : null;
}
export function mailReady() {
  return (
    accountsConfigured() && Boolean(settings().RESEND_API_KEY && mailSender())
  );
}
export async function sessionAccount(h: Headers): Promise<Account | null> {
  const token = cookieToken(h);
  if (!token) return null;
  return db()
    .prepare(`SELECT a.* FROM mobility_accounts a JOIN mobility_account_sessions s ON s.account_id=a.id
    WHERE s.token_hash=? AND s.expires_at>? AND a.status='active'`)
    .bind(await tokenHash(token), Date.now())
    .first<Account>();
}
export async function accountUser(h: Headers): Promise<AppUser | null> {
  const a = await sessionAccount(h);
  return a
    ? { userId: a.id, email: a.email, displayName: a.name, fullName: a.name }
    : null;
}
export function publicAccount(a: Account) {
  return {
    id: a.id,
    email: a.email,
    name: a.name,
    phone: a.phone,
    kind: a.kind,
    status: a.status,
    verifiedAt: a.verified_at,
    createdAt: a.created_at,
  };
}
export function setAccountCookie(
  response: Response,
  request: Request,
  token: string,
  maxAge = 30 * 86400,
) {
  response.headers.append(
    'Set-Cookie',
    `${accountCookie}=${token}; Path=/; Max-Age=${maxAge}; HttpOnly; SameSite=Strict${new URL(request.url).protocol === 'https:' ? '; Secure' : ''}`,
  );
}
export function clearDeviceCookie(response: Response, request: Request) {
  response.headers.append(
    'Set-Cookie',
    `luxore_device=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict${new URL(request.url).protocol === 'https:' ? '; Secure' : ''}`,
  );
}
export async function assertAccountIdle(id: string) {
  const active = await db()
    .prepare(`SELECT id FROM mobility_bookings WHERE
    (owner_id=? AND status IN ('requesting','accepted','arrived','riding')) OR
    (driver_id=? AND (status IN ('accepted','arrived','riding') OR (status='completed' AND payment_status='unpaid'))) LIMIT 1`)
    .bind(id, id)
    .first();
  if (active)
    throw new ApiError(
      409,
      'Bitte zuerst die laufende Fahrt beenden beziehungsweise stornieren und offene Fahrten kassieren.',
    );
  const driver = await db()
    .prepare('SELECT online,session_id FROM mobility_drivers WHERE id=?')
    .bind(id)
    .first<{ online: number; session_id: string | null }>();
  if (driver?.online || driver?.session_id)
    throw new ApiError(409, 'Bitte zuerst die Fahrerschicht pausieren.');
}
export async function audit(
  actorId: string,
  subjectId: string,
  action: string,
) {
  await db()
    .prepare(
      'INSERT INTO mobility_operator_audit(id,actor_id,subject_id,action,created_at) VALUES(?,?,?,?,?)',
    )
    .bind(crypto.randomUUID(), actorId, subjectId, action, Date.now())
    .run();
}
export async function sendCode(
  email: string,
  code: string,
  challengeId: string,
) {
  if (!mailReady())
    throw new ApiError(
      503,
      'Der E-Mail-Zugang wird noch eingerichtet. Bitte versuche es nach der Freischaltung erneut.',
    );
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      signal: controller.signal,
      headers: {
        Authorization: `Bearer ${settings().RESEND_API_KEY}`,
        'Content-Type': 'application/json',
        'Idempotency-Key': `luxore-login/${challengeId}`,
      },
      body: JSON.stringify({
        from: mailSender(),
        to: [email],
        subject: 'Dein LUXORÉ RIDE Anmeldecode',
        text: `Dein Anmeldecode: ${code}\n\nEr ist 10 Minuten gültig und kann einmal verwendet werden. Gib ihn ausschließlich in LUXORÉ RIDE ein. Unser Team fragt dich niemals nach diesem Code.\n\nWenn du keine Anmeldung angefordert hast, ignoriere diese Nachricht.\nLUXORÉ RIDE · booking@luxoreride.de`,
      }),
    });
    if (!response.ok) throw new Error('mail failed');
  } catch {
    throw new ApiError(
      502,
      'Der Anmeldecode konnte gerade nicht versendet werden. Bitte später erneut versuchen.',
    );
  } finally {
    clearTimeout(timeout);
  }
}
