export type VehicleBody = 'sedan' | 'van' | 'suv' | 'wagon' | 'coupe';
/** The physical model determines the picture, never its first enabled service class. */
export function vehicleArtwork(model: string) {
  const normalized = model
    .normalize('NFKD')
    .replace(/\p{M}/gu, '')
    .toLowerCase()
    .replace(/[‐‑‒–—−_-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  const body: VehicleBody = /\b(avant|touring|kombi|estate)\b/.test(normalized)
    ? 'wagon'
    : /\b(coupe|coupé|cabrio|cabriolet)\b/.test(normalized)
      ? 'coupe'
      : /\b(v klasse|v class|vito|sprinter|multivan|transporter|van)\b/.test(
            normalized,
          )
        ? 'van'
        : /\b(suv|q[3578]|x[1-7]|gl[abces]|model [xy])\b/.test(normalized)
          ? 'suv'
          : 'sedan';
  let image: string | null = null;
  if (/\bmercedes(?: benz)?\b/.test(normalized)) {
    if (/\bv (klasse|class)\b/.test(normalized)) image = '/brand/van.png';
    else if (body === 'sedan' && /\be (klasse|class)\b/.test(normalized))
      image = '/brand/business.png';
    else if (body === 'sedan' && /\bs (klasse|class)\b/.test(normalized))
      image = '/brand/first-class.png';
  } else if (body === 'sedan' && /\baudi\s*a6\b/.test(normalized))
    image = '/vehicles/audi-a6.svg';
  let seed = 2166136261;
  for (const c of normalized)
    seed = Math.imul(seed ^ c.charCodeAt(0), 16777619) >>> 0;
  return { image, body, seed, label: model.trim() || 'Fahrzeug' };
}
