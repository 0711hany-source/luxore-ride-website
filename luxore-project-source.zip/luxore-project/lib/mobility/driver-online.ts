import { ApiError, db, tokenHash } from './server';
import { vehicleEligible } from './vehicles';

export async function startDriverShift(
  userId: string,
  expectedSessionId: string | null,
  native: boolean,
  now: number,
) {
  const sessionId = crypto.randomUUID();
  const nativeToken = native
    ? (crypto.randomUUID() + crypto.randomUUID()).replaceAll('-', '')
    : null;
  const expiresAt = now + 24 * 60 * 60 * 1000;
  // Prepare credentials before acquiring the write transaction. An old shift
  // stays usable until its replacement and native capability commit together.
  const hash = nativeToken ? await tokenHash(nativeToken) : null;
  await db().writeTransaction(async (transaction) => {
    // Identity/profile reads may predate a block. Keep legacy identities with
    // no local account row compatible, as with the authenticated shift stop.
    if (
      await transaction
        .prepare(
          "SELECT id FROM mobility_accounts WHERE id=? AND status<>'active'",
        )
        .bind(userId)
        .first()
    )
      throw new ApiError(
        403,
        'Dein Konto ist nicht aktiv. Bitte erneut anmelden.',
      );
    const driver = await transaction
      .prepare('SELECT approved,session_id FROM mobility_drivers WHERE id=?')
      .bind(userId)
      .first<{ approved: number; session_id: string | null }>();
    if (!driver?.approved)
      throw new ApiError(
        403,
        'Dein Fahrerprofil muss zuerst von der Disposition freigegeben werden.',
      );
    if (driver.session_id !== expectedSessionId)
      throw new ApiError(
        409,
        'Die Schicht wurde inzwischen geändert. Bitte die Fahreransicht aktualisieren.',
      );
    const statements = [
      transaction
        .prepare(
          `UPDATE mobility_drivers SET online=0,lat=NULL,lng=NULL,location_at=NULL,session_id=? WHERE id=? AND approved=1 AND session_id IS ? AND ${vehicleEligible('mobility_drivers')}`,
        )
        .bind(sessionId, userId, expectedSessionId),
      transaction
        .prepare(
          'DELETE FROM mobility_location_sessions WHERE (driver_id=? OR expires_at<=?) AND EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND session_id=?)',
        )
        .bind(userId, now, userId, sessionId),
    ];
    if (hash)
      statements.push(
        transaction
          .prepare(
            'INSERT INTO mobility_location_sessions(token_hash,driver_id,session_id,expires_at) SELECT ?,?,?,? WHERE EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND session_id=?)',
          )
          .bind(hash, userId, sessionId, expiresAt, userId, sessionId),
      );
    const started = await transaction.batch(statements);
    if (started[0].meta.changes !== 1)
      throw new ApiError(
        409,
        'Bitte zuerst ein aktives Fahrzeug deiner Flotte wählen.',
      );
  });
  return nativeToken ? { sessionId, nativeToken, expiresAt } : { sessionId };
}
