export const COLLECT_SQL = `UPDATE mobility_bookings SET payment_status='paid',payment_method=?,paid_at=?
 WHERE id=? AND driver_id=? AND status='completed' AND completed_at IS NOT NULL AND payment_status='unpaid'`;
export async function collect(
  db: D1Database,
  id: string,
  driverId: string,
  method: 'cash' | 'terminal',
  now = Date.now(),
) {
  const result = await db.batch([
    db.prepare(COLLECT_SQL).bind(method, now, id, driverId),
    db
      .prepare(
        "INSERT OR IGNORE INTO mobility_events(id,booking_id,actor_id,action,created_at) SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM mobility_bookings WHERE id=? AND driver_id=? AND payment_status='paid' AND paid_at=? AND payment_method=?)",
      )
      .bind(
        'payment:' + id,
        id,
        driverId,
        'collected:' + method,
        now,
        id,
        driverId,
        now,
        method,
      ),
  ]);
  if (result[0].meta.changes) return true;
  return Boolean(
    await db
      .prepare(
        "SELECT id FROM mobility_bookings WHERE id=? AND driver_id=? AND status='completed' AND payment_status='paid' AND payment_method=?",
      )
      .bind(id, driverId, method)
      .first(),
  );
}
