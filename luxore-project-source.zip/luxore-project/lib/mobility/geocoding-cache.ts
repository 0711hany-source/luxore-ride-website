import { db, settings, tokenHash, ApiError } from './server';
import { geocode } from './provider';
import {
  geocodeKey,
  permanentDailyLimit,
  type GeocodeQuery,
} from './geocoding-policy';
import type { Point } from './domain';
type Results = Omit<Point, 'id'>[];
const ttl = 30 * 86400000;
export async function permanentGeocode(query: GeocodeQuery): Promise<Results> {
  const now = Date.now();
  const key = await tokenHash(geocodeKey(query));
  const cached = await db()
    .prepare(
      'SELECT payload FROM mobility_geocodes WHERE key=? AND expires_at>?',
    )
    .bind(key, now)
    .first<{ payload: string }>();
  if (cached) return JSON.parse(cached.payload) as Results;
  // A lease prevents concurrent devices paying for the same lookup twice.
  const claim = crypto.randomUUID();
  const acquired = await db()
    .prepare(
      `INSERT INTO mobility_geocodes(key,payload,expires_at,claim,claimed_until) VALUES(?,NULL,0,?,?) ON CONFLICT(key) DO UPDATE SET claim=excluded.claim,claimed_until=excluded.claimed_until WHERE expires_at<=? AND claimed_until<=? RETURNING key`,
    )
    .bind(key, claim, now + 15000, now, now)
    .first();
  if (!acquired)
    throw new ApiError(
      409,
      'Diese Adresse wird gerade geprüft. Bitte gleich erneut auswählen.',
    );
  try {
    const maximum = permanentDailyLimit(
      settings().MAPBOX_PERMANENT_DAILY_LIMIT,
    );
    if (!maximum)
      throw new ApiError(
        429,
        'Das Tageskontingent für neue Adressen ist ausgeschöpft. Bereits gespeicherte Adressen bleiben verfügbar.',
      );
    const counter = `geocode-permanent:${Math.floor(now / 86400000)}`;
    const reserved = await db()
      .prepare(
        'INSERT INTO mobility_limits(key,count) VALUES(?,1) ON CONFLICT(key) DO UPDATE SET count=count+1 WHERE count < ? RETURNING count',
      )
      .bind(counter, maximum)
      .first();
    if (!reserved)
      throw new ApiError(
        429,
        'Das Tageskontingent für neue Adressen ist ausgeschöpft. Bitte die Flottenleitung informieren.',
      );
    const results = await geocode(query, true);
    await db()
      .prepare(
        'UPDATE mobility_geocodes SET payload=?,expires_at=?,claim=NULL,claimed_until=0 WHERE key=? AND claim=?',
      )
      .bind(JSON.stringify(results), now + ttl, key, claim)
      .run();
    return results;
  } finally {
    await db()
      .prepare(
        'UPDATE mobility_geocodes SET claim=NULL,claimed_until=0 WHERE key=? AND claim=?',
      )
      .bind(key, claim)
      .run();
  }
}
