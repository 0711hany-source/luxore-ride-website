import { vehicleEligible } from './vehicles.ts';
import { distance, type Driver } from './domain.ts';
export const OFFER_MS = 25000;
export const FRESH_MS = 45000;
export const SEARCH_MS = 180000;
export const RESERVATION_LEAD_MS = 15 * 60000;
export const ACCEPT_SQL = `UPDATE mobility_bookings SET status='accepted',driver_id=?,updated_at=?,fleet_id=(SELECT fleet_id FROM mobility_employees WHERE user_id=?),vehicle_id=(SELECT vehicle_id FROM mobility_drivers WHERE id=?),vehicle_snapshot=(SELECT json_object('model',vehicle,'plate',plate,'services',services) FROM mobility_drivers WHERE id=?)
 WHERE id=? AND status='requesting' AND EXISTS (
 SELECT 1 FROM mobility_offers o JOIN mobility_drivers d ON d.id=o.driver_id
 WHERE o.id=? AND o.booking_id=mobility_bookings.id AND o.driver_id=? AND o.status='pending' AND o.expires_at>?
 AND ${vehicleEligible('d')} AND d.approved=1 AND d.online=1 AND d.location_at>? AND d.accuracy<=100 AND EXISTS(SELECT 1 FROM json_each(COALESCE(d.services,json_array(d.service))) WHERE value=mobility_bookings.service))
 AND NOT EXISTS (SELECT 1 FROM mobility_bookings b WHERE b.driver_id=? AND (b.status IN ('accepted','arrived','riding') OR (b.status='completed' AND b.completed_at IS NOT NULL AND b.payment_status='unpaid')))`;
export async function accept(
  db: D1Database,
  offerId: string,
  driverId: string,
  now = Date.now(),
) {
  const offer = await db
    .prepare(
      'SELECT booking_id FROM mobility_offers WHERE id=? AND driver_id=?',
    )
    .bind(offerId, driverId)
    .first<{ booking_id: string }>();
  if (!offer) return false;
  const result = await db.batch([
    db
      .prepare(ACCEPT_SQL)
      .bind(
        driverId,
        now,
        driverId,
        driverId,
        driverId,
        offer.booking_id,
        offerId,
        driverId,
        now,
        now - FRESH_MS,
        driverId,
      ),
    db
      .prepare(
        "UPDATE mobility_offers SET status='accepted' WHERE id=? AND driver_id=? AND status='pending' AND EXISTS(SELECT 1 FROM mobility_bookings WHERE id=mobility_offers.booking_id AND driver_id=? AND status='accepted')",
      )
      .bind(offerId, driverId, driverId),
    db
      .prepare(
        "INSERT INTO mobility_events(id,booking_id,actor_id,action,created_at) SELECT ?,?,?, 'accepted',? WHERE EXISTS(SELECT 1 FROM mobility_bookings WHERE id=? AND driver_id=? AND status='accepted' AND updated_at=?)",
      )
      .bind(
        crypto.randomUUID(),
        offer.booking_id,
        driverId,
        now,
        offer.booking_id,
        driverId,
        now,
      ),
  ]);
  return result[0].meta.changes === 1;
}
export async function dispatch(db: D1Database, now = Date.now()) {
  await db.batch([
    db
      .prepare(
        "UPDATE mobility_offers SET status='expired' WHERE status='pending' AND (expires_at<=? OR NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.id=mobility_offers.booking_id AND b.status='requesting') OR NOT EXISTS(SELECT 1 FROM mobility_drivers d WHERE d.id=mobility_offers.driver_id AND d.online=1 AND d.approved=1 AND d.location_at>?))",
      )
      .bind(now, now - FRESH_MS),
    db
      .prepare('DELETE FROM mobility_limits WHERE key < ?')
      .bind(String(Math.floor(now / 60000) - 10) + ':'),
    db
      .prepare('DELETE FROM mobility_quotes WHERE expires_at < ?')
      .bind(now - 86400000),
    db
      .prepare('DELETE FROM mobility_places WHERE created_at < ?')
      .bind(now - 7 * 86400000),
    db
      .prepare(
        'UPDATE mobility_drivers SET lat=NULL,lng=NULL,accuracy=NULL,online=0 WHERE location_at < ?',
      )
      .bind(now - 24 * 3600000),
    db.prepare(
      "UPDATE mobility_bookings SET rider_lat=NULL,rider_lng=NULL,rider_location_at=NULL WHERE status IN ('completed','cancelled','unavailable') AND rider_lat IS NOT NULL",
    ),
  ]);
  // Activate reservations individually so one customer conflict cannot block the queue.
  const due = await db
    .prepare(
      "SELECT id,owner_id FROM mobility_bookings WHERE status='reserved' AND scheduled_at<=? ORDER BY scheduled_at LIMIT 30",
    )
    .bind(now + RESERVATION_LEAD_MS)
    .all<{ id: string; owner_id: string }>();
  for (const r of due.results)
    await db
      .prepare(
        "UPDATE OR IGNORE mobility_bookings SET status='requesting',dispatch_at=?,updated_at=? WHERE id=? AND status='reserved' AND NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.owner_id=? AND b.status IN ('requesting','accepted','arrived','riding'))",
      )
      .bind(now, now, r.id, r.owner_id)
      .run();
  await db
    .prepare(
      "UPDATE mobility_bookings SET status='unavailable',updated_at=? WHERE status='requesting' AND dispatch_at<? AND NOT EXISTS(SELECT 1 FROM mobility_offers o WHERE o.booking_id=mobility_bookings.id AND o.status='pending' AND o.expires_at>?)",
    )
    .bind(now, now - SEARCH_MS, now)
    .run();
  const pending = await db
    .prepare(
      "SELECT id,owner_id,service,route FROM mobility_bookings b WHERE status='requesting' AND NOT EXISTS(SELECT 1 FROM mobility_offers o WHERE o.booking_id=b.id AND o.status='pending') ORDER BY created_at LIMIT 20",
    )
    .all<{ id: string; owner_id: string; service: string; route: string }>();
  for (const booking of pending.results) {
    const pickup = JSON.parse(booking.route).pickup as {
      lat: number;
      lng: number;
    };
    const candidates = await db
      .prepare(`SELECT * FROM mobility_drivers d WHERE ${vehicleEligible('d')} AND approved=1 AND online=1 AND EXISTS(SELECT 1 FROM json_each(COALESCE(d.services,json_array(d.service))) WHERE value=?) AND id<>? AND lat IS NOT NULL AND lng IS NOT NULL AND accuracy<=100 AND location_at>?
   AND NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.driver_id=d.id AND (b.status IN ('accepted','arrived','riding') OR (b.status='completed' AND b.completed_at IS NOT NULL AND b.payment_status='unpaid')))
   AND NOT EXISTS(SELECT 1 FROM mobility_offers o WHERE o.driver_id=d.id AND (o.status='pending' OR o.booking_id=?)) LIMIT 200`)
      .bind(booking.service, booking.owner_id, now - FRESH_MS, booking.id)
      .all<Driver>();
    const sorted = candidates.results
      .map((d) => ({
        d,
        metres: distance(pickup, { lat: d.lat!, lng: d.lng! }),
      }))
      .filter((x) => x.metres <= 50000)
      .sort((a, b) => a.metres - b.metres || a.d.id.localeCompare(b.d.id));
    for (const { d } of sorted) {
      const result = await db
        .prepare(`INSERT OR IGNORE INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at)
    SELECT ?,?,?,'pending',?,? WHERE EXISTS(SELECT 1 FROM mobility_bookings WHERE id=? AND status='requesting')
    AND EXISTS(SELECT 1 FROM mobility_drivers d WHERE ${vehicleEligible('d')} AND id=? AND approved=1 AND online=1 AND location_at>? AND EXISTS(SELECT 1 FROM json_each(COALESCE(services,json_array(service))) WHERE value=?))
    AND NOT EXISTS(SELECT 1 FROM mobility_bookings WHERE driver_id=? AND (status IN ('accepted','arrived','riding') OR (status='completed' AND completed_at IS NOT NULL AND payment_status='unpaid')))`)
        .bind(
          crypto.randomUUID(),
          booking.id,
          d.id,
          now + OFFER_MS,
          now,
          booking.id,
          d.id,
          now - FRESH_MS,
          booking.service,
          d.id,
        )
        .run();
      if (result.meta.changes === 1) break;
    }
  }
}
