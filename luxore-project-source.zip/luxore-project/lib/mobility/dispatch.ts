import type { SqlDatabase } from '@/db/sqlite';
import { vehicleEligible } from './vehicles.ts';
import { distance, type Driver, type RouteData } from './domain.ts';
import { chainEta, CHAIN_MAX_ETA_SECONDS, driveSeconds } from './chain.ts';
import {
  driverSearchArea,
  DRIVER_SEARCH_RADIUS_METERS,
} from './driver-search.ts';
// Decision of the operator (16.11.2026): a driver gets two minutes to answer.
export const OFFER_MS = 120000;
export const FRESH_MS = 45000;
export const SEARCH_MS = 180000;
export const RESERVATION_LEAD_MS = 15 * 60000;
export const ACCEPT_SQL = `UPDATE mobility_bookings SET status='accepted',driver_id=?,updated_at=?,fleet_id=(SELECT fleet_id FROM mobility_employees WHERE user_id=?),vehicle_id=(SELECT vehicle_id FROM mobility_drivers WHERE id=?),vehicle_snapshot=(SELECT json_object('model',vehicle,'plate',plate,'services',services) FROM mobility_drivers WHERE id=?)
 WHERE id=? AND status='requesting' AND EXISTS (
 SELECT 1 FROM mobility_offers o JOIN mobility_drivers d ON d.id=o.driver_id
 WHERE o.id=? AND o.booking_id=mobility_bookings.id AND o.driver_id=? AND o.status='pending' AND o.expires_at>?
 AND ${vehicleEligible('d')} AND d.approved=1 AND d.online=1 AND d.location_at>? AND d.accuracy<=100 AND EXISTS(SELECT 1 FROM json_each(COALESCE(d.services,json_array(d.service))) WHERE value=mobility_bookings.service))
 AND NOT EXISTS (SELECT 1 FROM mobility_bookings b WHERE b.driver_id=? AND (b.status IN ('accepted','arrived') OR (b.status='completed' AND b.completed_at IS NOT NULL AND b.payment_status='unpaid')))
 AND (SELECT COUNT(*) FROM mobility_bookings b WHERE b.driver_id=? AND b.status='riding')<=1`;
export async function accept(
  db: SqlDatabase,
  offerId: string,
  driverId: string,
  now = Date.now(),
) {
  const offer = await db
    .prepare(
      'SELECT booking_id FROM mobility_offers WHERE id=? AND driver_id=?',
    )
    .bind(offerId, driverId)
    .first<{ booking_id: string }>();
  if (!offer) return false;
  const result = await db.batch([
    db
      .prepare(ACCEPT_SQL)
      .bind(
        driverId,
        now,
        driverId,
        driverId,
        driverId,
        offer.booking_id,
        offerId,
        driverId,
        now,
        now - FRESH_MS,
        driverId,
        driverId,
      ),
    db
      .prepare(
        "UPDATE mobility_offers SET status='accepted' WHERE id=? AND driver_id=? AND status='pending' AND EXISTS(SELECT 1 FROM mobility_bookings WHERE id=mobility_offers.booking_id AND driver_id=? AND status='accepted')",
      )
      .bind(offerId, driverId, driverId),
    db
      .prepare(
        "INSERT INTO mobility_events(id,booking_id,actor_id,action,created_at) SELECT ?,?,?, 'accepted',? WHERE EXISTS(SELECT 1 FROM mobility_bookings WHERE id=? AND driver_id=? AND status='accepted' AND updated_at=?)",
      )
      .bind(
        crypto.randomUUID(),
        offer.booking_id,
        driverId,
        now,
        offer.booking_id,
        driverId,
        now,
      ),
  ]);
  return result[0].meta.changes === 1;
}
/**
 * First offer of an activated reservation for the driver who took it over.
 * Same conditions as a normal offer (approved, online, fresh and accurate
 * position, suitable active vehicle, no running ride or open payment), but
 * without the distance limit, and only while nobody has been asked yet.
 * Returns false when the driver cannot be asked: the normal search follows.
 */
async function offerAssignedDriver(
  db: SqlDatabase,
  booking: { id: string; service: string },
  driverId: string,
  now: number,
) {
  const result = await db
    .prepare(`INSERT OR IGNORE INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at)
    SELECT ?,?,?,'pending',?,? WHERE EXISTS(SELECT 1 FROM mobility_bookings WHERE id=? AND status='requesting' AND assigned_driver_id=? AND owner_id<>?)
    AND NOT EXISTS(SELECT 1 FROM mobility_offers WHERE booking_id=?)
    AND EXISTS(SELECT 1 FROM mobility_drivers d WHERE ${vehicleEligible('d')} AND id=? AND approved=1 AND online=1 AND lat IS NOT NULL AND lng IS NOT NULL AND accuracy<=100 AND location_at>? AND EXISTS(SELECT 1 FROM json_each(COALESCE(services,json_array(service))) WHERE value=?))
    AND NOT EXISTS(SELECT 1 FROM mobility_bookings WHERE driver_id=? AND (status IN ('accepted','arrived','riding') OR (status='completed' AND completed_at IS NOT NULL AND payment_status='unpaid')))`)
    .bind(
      crypto.randomUUID(),
      booking.id,
      driverId,
      now + OFFER_MS,
      now,
      booking.id,
      driverId,
      driverId,
      booking.id,
      driverId,
      now - FRESH_MS,
      booking.service,
      driverId,
    )
    .run();
  return result.meta.changes === 1;
}
export async function dispatch(db: SqlDatabase, now = Date.now()) {
  await db.batch([
    db
      .prepare(
        "UPDATE mobility_offers SET status='expired' WHERE status='pending' AND (expires_at<=? OR NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.id=mobility_offers.booking_id AND b.status='requesting') OR NOT EXISTS(SELECT 1 FROM mobility_drivers d WHERE d.id=mobility_offers.driver_id AND d.online=1 AND d.approved=1 AND d.location_at>?))",
      )
      .bind(now, now - FRESH_MS),
    db
      .prepare('DELETE FROM mobility_limits WHERE key < ?')
      .bind(String(Math.floor(now / 60000) - 10) + ':'),
    db
      .prepare('DELETE FROM mobility_quotes WHERE expires_at < ?')
      .bind(now - 86400000),
    db
      .prepare('DELETE FROM mobility_places WHERE created_at < ?')
      .bind(now - 7 * 86400000),
    db
      .prepare(
        'UPDATE mobility_drivers SET lat=NULL,lng=NULL,accuracy=NULL,online=0 WHERE location_at < ?',
      )
      .bind(now - 24 * 3600000),
    db.prepare(
      "UPDATE mobility_bookings SET rider_lat=NULL,rider_lng=NULL,rider_location_at=NULL WHERE status IN ('completed','cancelled','unavailable') AND rider_lat IS NOT NULL",
    ),
  ]);
  // Activate reservations individually so one customer conflict cannot block the queue.
  const due = await db
    .prepare(
      "SELECT id,owner_id FROM mobility_bookings WHERE status='reserved' AND scheduled_at<=? ORDER BY scheduled_at LIMIT 30",
    )
    .bind(now + RESERVATION_LEAD_MS)
    .all<{ id: string; owner_id: string }>();
  for (const r of due.results)
    await db
      .prepare(
        "UPDATE OR IGNORE mobility_bookings SET status='requesting',dispatch_at=?,updated_at=? WHERE id=? AND status='reserved' AND NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.owner_id=? AND b.status IN ('requesting','accepted','arrived','riding'))",
      )
      .bind(now, now, r.id, r.owner_id)
      .run();
  await db
    .prepare(
      "UPDATE mobility_bookings SET status='unavailable',updated_at=? WHERE status='requesting' AND dispatch_at<? AND NOT EXISTS(SELECT 1 FROM mobility_offers o WHERE o.booking_id=mobility_bookings.id AND o.status='pending' AND o.expires_at>?)",
    )
    .bind(now, now - SEARCH_MS, now)
    .run();
  const pending = await db
    .prepare(
      "SELECT id,owner_id,service,route FROM mobility_bookings b WHERE status='requesting' AND NOT EXISTS(SELECT 1 FROM mobility_offers o WHERE o.booking_id=b.id AND o.status='pending') ORDER BY created_at LIMIT 20",
    )
    .all<{ id: string; owner_id: string; service: string; route: string }>();
  // Reservations a driver has taken over: the very first offer goes to that
  // driver. Everything else below stays the normal search.
  const assigned = new Map<string, string>();
  try {
    const rows = await db
      .prepare(
        "SELECT id,assigned_driver_id FROM mobility_bookings WHERE status='requesting' AND assigned_driver_id IS NOT NULL",
      )
      .all<{ id: string; assigned_driver_id: string }>();
    for (const row of rows.results) assigned.set(row.id, row.assigned_driver_id);
  } catch {
    /* Database without migration 0021: no assignments exist yet. */
  }
  for (const booking of pending.results) {
    const preferred = assigned.get(booking.id);
    if (
      preferred &&
      (await offerAssignedDriver(db, booking, preferred, now))
    )
      continue;
    const pickup = JSON.parse(booking.route).pickup as {
      lat: number;
      lng: number;
    };
    const area = driverSearchArea(pickup);
    const candidates = await db
      .prepare(`SELECT * FROM mobility_drivers d WHERE ${area.sql} AND ${vehicleEligible('d')} AND approved=1 AND online=1 AND EXISTS(SELECT 1 FROM json_each(COALESCE(d.services,json_array(d.service))) WHERE value=?) AND id<>? AND lat IS NOT NULL AND lng IS NOT NULL AND accuracy<=100 AND location_at>?
   AND NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.driver_id=d.id AND (b.status IN ('accepted','arrived','riding') OR (b.status='completed' AND b.completed_at IS NOT NULL AND b.payment_status='unpaid')))
   AND NOT EXISTS(SELECT 1 FROM mobility_offers o WHERE o.driver_id=d.id AND (o.status='pending' OR o.booking_id=?))`)
      .bind(
        ...area.parameters,
        booking.service,
        booking.owner_id,
        now - FRESH_MS,
        booking.id,
      )
      .all<Driver>();
    const sorted = candidates.results
      .map((d) => ({
        d,
        metres: distance(pickup, { lat: d.lat!, lng: d.lng! }),
      }))
      .filter((x) => x.metres <= DRIVER_SEARCH_RADIUS_METERS)
      .sort((a, b) => a.metres - b.metres || a.d.id.localeCompare(b.d.id));
    // Always the chauffeur who can be there first (wish of the operator,
    // 18.11.2026): free chauffeurs by distance, chauffeurs finishing a ride
    // by the rest of that ride. The latter is less certain, hence a margin.
    const order = [
      ...sorted.map(({ d, metres }) => ({
        id: d.id,
        eta: driveSeconds(metres),
        chained: false,
      })),
      ...(await followUpCandidates(db, booking, pickup, now)).map((c) => ({
        id: c.id,
        eta: c.eta + CHAIN_MARGIN_SECONDS,
        chained: true,
      })),
    ].sort(
      (a, b) =>
        a.eta - b.eta ||
        Number(a.chained) - Number(b.chained) ||
        a.id.localeCompare(b.id),
    );
    for (const c of order) {
      if (c.chained) {
        if (await offerFollowUp(db, booking, c.id, now)) break;
        continue;
      }
      const result = await db
        .prepare(`INSERT OR IGNORE INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at)
    SELECT ?,?,?,'pending',?,? WHERE EXISTS(SELECT 1 FROM mobility_bookings WHERE id=? AND status='requesting')
    AND EXISTS(SELECT 1 FROM mobility_drivers d WHERE ${vehicleEligible('d')} AND id=? AND approved=1 AND online=1 AND location_at>? AND EXISTS(SELECT 1 FROM json_each(COALESCE(services,json_array(service))) WHERE value=?))
    AND NOT EXISTS(SELECT 1 FROM mobility_bookings WHERE driver_id=? AND (status IN ('accepted','arrived','riding') OR (status='completed' AND completed_at IS NOT NULL AND payment_status='unpaid')))`)
        .bind(
          crypto.randomUUID(),
          booking.id,
          c.id,
          now + OFFER_MS,
          now,
          booking.id,
          c.id,
          now - FRESH_MS,
          booking.service,
          c.id,
        )
        .run();
      if (result.meta.changes === 1) break;
    }
  }
}
const ready = new WeakSet<object>();
/**
 * Follow-up rides need migration 0024 (a waiting ride beside the running
 * one). On a database without it the search behaves exactly as before.
 */
async function followUpReady(db: SqlDatabase) {
  if (ready.has(db)) return true;
  const index = await db
    .prepare(
      "SELECT 1 AS ok FROM sqlite_master WHERE type='index' AND name='idx_one_riding_driver'",
    )
    .first<{ ok: number }>()
    .catch(() => null);
  if (index) ready.add(db);
  return !!index;
}
/** A follow-up ride competes with a free chauffeur only when clearly faster. */
const CHAIN_MARGIN_SECONDS = 120;
/**
 * Chauffeurs who are driving a guest and whose ride ends close to this
 * pickup point, with the time until they could be there. One waiting ride
 * per chauffeur at most.
 */
async function followUpCandidates(
  db: SqlDatabase,
  booking: { id: string; owner_id: string; service: string; route: string },
  pickup: { lat: number; lng: number },
  now: number,
) {
  if (!(await followUpReady(db))) return [];
  const rows = await db
    .prepare(`SELECT d.id,d.lat,d.lng,r.route FROM mobility_drivers d JOIN mobility_bookings r ON r.driver_id=d.id AND r.status='riding'
   WHERE ${vehicleEligible('d')} AND d.approved=1 AND d.online=1 AND EXISTS(SELECT 1 FROM json_each(COALESCE(d.services,json_array(d.service))) WHERE value=?) AND d.id<>? AND d.lat IS NOT NULL AND d.lng IS NOT NULL AND d.accuracy<=100 AND d.location_at>?
   AND NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.driver_id=d.id AND (b.status IN ('accepted','arrived') OR (b.status='completed' AND b.completed_at IS NOT NULL AND b.payment_status='unpaid')))
   AND NOT EXISTS(SELECT 1 FROM mobility_offers o WHERE o.driver_id=d.id AND (o.status='pending' OR o.booking_id=?)) LIMIT 50`)
    .bind(booking.service, booking.owner_id, now - FRESH_MS, booking.id)
    .all<{ id: string; lat: number; lng: number; route: string }>();
  const next = JSON.parse(booking.route) as RouteData;
  return rows.results.flatMap((d) => {
    try {
      const running = JSON.parse(d.route) as RouteData;
      const metres = distance(pickup, running.destination);
      const eta = chainEta(running, next, { lat: d.lat, lng: d.lng }, now);
      return metres <= DRIVER_SEARCH_RADIUS_METERS &&
        eta <= CHAIN_MAX_ETA_SECONDS
        ? [{ id: d.id, eta }]
        : [];
    } catch {
      return [];
    }
  });
}
async function offerFollowUp(
  db: SqlDatabase,
  booking: { id: string; service: string },
  driverId: string,
  now: number,
) {
  const result = await db
    .prepare(`INSERT OR IGNORE INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at)
    SELECT ?,?,?,'pending',?,? WHERE EXISTS(SELECT 1 FROM mobility_bookings WHERE id=? AND status='requesting')
    AND EXISTS(SELECT 1 FROM mobility_drivers d WHERE ${vehicleEligible('d')} AND id=? AND approved=1 AND online=1 AND location_at>? AND EXISTS(SELECT 1 FROM json_each(COALESCE(services,json_array(service))) WHERE value=?))
    AND EXISTS(SELECT 1 FROM mobility_bookings WHERE driver_id=? AND status='riding')
    AND NOT EXISTS(SELECT 1 FROM mobility_bookings WHERE driver_id=? AND (status IN ('accepted','arrived') OR (status='completed' AND completed_at IS NOT NULL AND payment_status='unpaid')))`)
    .bind(
      crypto.randomUUID(),
      booking.id,
      driverId,
      now + OFFER_MS,
      now,
      booking.id,
      driverId,
      now - FRESH_MS,
      booking.service,
      driverId,
      driverId,
    )
    .run();
  return result.meta.changes === 1;
}
