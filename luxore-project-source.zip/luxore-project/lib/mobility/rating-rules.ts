/** Rating rules. Single place to change them; safe to import in the browser. */
export const RATING_WINDOW_MS = 14 * 86400000;
/** A driver's average is shown to customers only from this many ratings. */
export const RATING_PUBLIC_MIN = 3;
export const RATING_COMMENT_MAX = 300;
