import { coordinate } from './domain.ts';
import { vehicleEligible } from './vehicles.ts';
export function freshLocation(b: Record<string, unknown>, now: number) {
  return (
    coordinate(b.lat, b.lng) &&
    typeof b.accuracy === 'number' &&
    Number.isFinite(b.accuracy) &&
    b.accuracy >= 0 &&
    b.accuracy <= 100 &&
    typeof b.timestamp === 'number' &&
    Number.isFinite(b.timestamp) &&
    b.timestamp <= now + 5000 &&
    b.timestamp >= now - 30000
  );
}
// Authorization is repeated inside the write so pause/session changes cannot be undone by an in-flight fix.
export const saveNativeLocationSql = `UPDATE mobility_drivers SET lat=?,lng=?,accuracy=?,location_at=?,online=1
 WHERE id=? AND approved=1 AND session_id=? AND (location_at IS NULL OR location_at<?)
 AND ${vehicleEligible('mobility_drivers')}
 AND EXISTS(SELECT 1 FROM mobility_location_sessions s WHERE s.token_hash=? AND s.driver_id=mobility_drivers.id AND s.session_id=mobility_drivers.session_id AND s.expires_at>?)`;

// Only opaque offer metadata, never customer names, addresses, prices or contact details.
export const nativeOfferSql = `SELECT o.id,o.expires_at AS expiresAt FROM mobility_offers o
 JOIN mobility_bookings b ON b.id=o.booking_id
 JOIN mobility_drivers d ON d.id=o.driver_id
 JOIN mobility_location_sessions s ON s.driver_id=d.id AND s.session_id=d.session_id
 WHERE d.id=? AND d.session_id=? AND s.token_hash=? AND s.expires_at>?
 AND d.approved=1 AND d.online=1 AND d.location_at>? AND d.accuracy<=100
 AND ${vehicleEligible('d')}
 AND EXISTS(SELECT 1 FROM json_each(COALESCE(d.services,json_array(d.service))) WHERE value=b.service)
 AND o.status='pending' AND b.status='requesting' AND o.expires_at>?
 ORDER BY o.expires_at LIMIT 1`;
