import type { SqlDatabase } from '@/db/sqlite';
import { ApiError } from './server';

/** Chat between the customer and the driver of one ride, without phone numbers. */
export const CHAT_BODY_MAX = 500;
export const CHAT_MAX_PER_RIDE = 200;
export const CHAT_RATE_PER_MINUTE = 20;
/** Only while a driver is on the job; before and after there is no chat. */
export const CHAT_STATUSES = ['accepted', 'arrived', 'riding'] as const;
export type ChatRole = 'rider' | 'driver';
export type ChatMessage = {
  id: string;
  mine: boolean;
  body: string;
  created_at: number;
};
export type ChatFeed = {
  serverTime: number;
  /** false: the ride has no chat (any more); messages is then empty. */
  open: boolean;
  messages: ChatMessage[];
};

export const chatOpen = (status: string) =>
  (CHAT_STATUSES as readonly string[]).includes(status);

/** A database without migration 0022 must never break anything else. */
export function chatTableMissing(error: unknown) {
  const seen = new Set<unknown>();
  for (let e = error; e && !seen.has(e); e = (e as { cause?: unknown }).cause) {
    seen.add(e);
    if (
      /no such table: mobility_messages/i.test(
        String((e as { message?: unknown }).message ?? e),
      )
    )
      return true;
  }
  return false;
}
/** 1–500 characters after trimming; line breaks stay, other control characters go. */
export function parseChatBody(value: unknown) {
  if (typeof value !== 'string' || value.length > CHAT_BODY_MAX * 4)
    throw new ApiError(
      400,
      `Die Nachricht darf höchstens ${CHAT_BODY_MAX} Zeichen haben.`,
    );
  const clean = value
    .replace(/[\u0000-\u0009\u000B-\u001F\u007F]/g, ' ')
    .trim();
  if (!clean) throw new ApiError(400, 'Bitte eine Nachricht eingeben.');
  if (clean.length > CHAT_BODY_MAX)
    throw new ApiError(
      400,
      `Die Nachricht darf höchstens ${CHAT_BODY_MAX} Zeichen haben.`,
    );
  return clean;
}
export function parseChatAfter(value: unknown) {
  const n = Number(value ?? 0);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
}
type Party = {
  role: ChatRole;
  ownerId: string;
  driverId: string | null;
  open: boolean;
};
/** The caller's side of the ride. Unknown and foreign rides answer alike. */
async function party(
  database: SqlDatabase,
  userId: string,
  bookingId: string,
): Promise<Party> {
  const booking = await database
    .prepare('SELECT owner_id,driver_id,status FROM mobility_bookings WHERE id=?')
    .bind(bookingId)
    .first<{ owner_id: string; driver_id: string | null; status: string }>();
  const role: ChatRole | null = !booking
    ? null
    : booking.owner_id === userId
      ? 'rider'
      : booking.driver_id && booking.driver_id === userId
        ? 'driver'
        : null;
  if (!booking || !role) throw new ApiError(404, 'Fahrt nicht gefunden.');
  return {
    role,
    ownerId: booking.owner_id,
    driverId: booking.driver_id,
    open: chatOpen(booking.status) && Boolean(booking.driver_id),
  };
}
/**
 * Messages of one ride newer than `after`, oldest first. Outside an active
 * ride the list is empty: stored messages are no longer handed out.
 * Only what the customer and the *current* driver wrote is delivered, so a
 * driver who takes the ride over never reads a predecessor's messages.
 */
export async function chatMessages(
  database: SqlDatabase,
  userId: string,
  bookingId: string,
  after = 0,
  now = Date.now(),
): Promise<ChatFeed> {
  const p = await party(database, userId, bookingId);
  if (!p.open) return { serverTime: now, open: false, messages: [] };
  try {
    const rows = await database
      .prepare(
        'SELECT id,sender_id,body,created_at FROM mobility_messages WHERE booking_id=? AND created_at>? AND sender_id IN (?,?) ORDER BY created_at LIMIT ?',
      )
      .bind(bookingId, after, p.ownerId, p.driverId, CHAT_MAX_PER_RIDE)
      .all<{ id: string; sender_id: string; body: string; created_at: number }>();
    return {
      serverTime: now,
      open: true,
      messages: rows.results.map((r) => ({
        id: r.id,
        mine: r.sender_id === userId,
        body: r.body,
        created_at: Number(r.created_at),
      })),
    };
  } catch (error) {
    if (chatTableMissing(error))
      return { serverTime: now, open: true, messages: [] };
    throw error;
  }
}
/**
 * Stores one message. The ride state and the cap of 200 per ride are checked
 * again inside the insert, so two simultaneous senders cannot slip past them.
 * created_at rises strictly within a ride: `after` never skips a message.
 */
export async function sendChatMessage(
  database: SqlDatabase,
  userId: string,
  bookingId: string,
  body: string,
  now = Date.now(),
): Promise<ChatMessage> {
  const p = await party(database, userId, bookingId);
  const closed = () =>
    new ApiError(
      409,
      'Nachrichten sind nur während einer laufenden Fahrt möglich.',
    );
  if (!p.open) throw closed();
  const id = crypto.randomUUID();
  let saved: { created_at: number } | null;
  try {
    saved = await database
      .prepare(
        `INSERT INTO mobility_messages(id,booking_id,sender_id,sender_role,body,created_at)
         SELECT ?,?,?,?,?,MAX(?,COALESCE((SELECT MAX(created_at) FROM mobility_messages WHERE booking_id=?),0)+1)
         WHERE (SELECT COUNT(*) FROM mobility_messages WHERE booking_id=?)<?
           AND EXISTS(SELECT 1 FROM mobility_bookings WHERE id=? AND status IN ('accepted','arrived','riding') AND (owner_id=? OR driver_id=?))
         RETURNING created_at`,
      )
      .bind(
        id,
        bookingId,
        userId,
        p.role,
        body,
        now,
        bookingId,
        bookingId,
        CHAT_MAX_PER_RIDE,
        bookingId,
        userId,
        userId,
      )
      .first<{ created_at: number }>();
  } catch (error) {
    if (chatTableMissing(error))
      throw new ApiError(
        503,
        'Der Chat ist auf diesem Server noch nicht eingerichtet. Bitte später erneut versuchen.',
      );
    throw error;
  }
  if (!saved) {
    // Either the ride just ended or the cap is reached.
    if (!(await party(database, userId, bookingId)).open) throw closed();
    throw new ApiError(
      409,
      `Für diese Fahrt sind höchstens ${CHAT_MAX_PER_RIDE} Nachrichten möglich.`,
    );
  }
  return { id, mine: true, body, created_at: Number(saved.created_at) };
}
