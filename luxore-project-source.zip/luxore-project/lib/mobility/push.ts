import type { SqlDatabase } from '@/db/sqlite';
import { vehicleEligible } from './vehicles.ts';
import { freeOnlineDriver } from './availability.ts';
import { FRESH_MS } from './dispatch.ts';
import { isService, type Service } from './domain.ts';

/** At most one "please go online" message per driver in this period. */
export const WAKE_INTERVAL_MS = 10 * 60000;
export const WAKE_TITLE = 'LUXORÉ Driver';
// No customer data, address, price or class: only the request to go online.
export const WAKE_BODY = 'Eine Fahrtanfrage wartet. Bitte online gehen.';
export const WAKE_CHANNEL = 'luxore-driver-wake-v1';

export type PushConfig = {
  projectId: string;
  clientEmail: string;
  privateKey: string;
};
type Env = Record<string, string | undefined>;
/** Without all three values every push function is a silent no-op. */
export function pushConfig(env: Env = process.env): PushConfig | null {
  const projectId = env.FCM_PROJECT_ID?.trim();
  const clientEmail = env.FCM_CLIENT_EMAIL?.trim();
  // Hosting panels store the key on one line with literal "\n".
  const privateKey = env.FCM_PRIVATE_KEY?.replace(/\\n/g, '\n').trim();
  if (!projectId || !clientEmail || !privateKey) return null;
  if (!/^[a-z0-9-]{4,40}$/.test(projectId)) return null;
  if (!privateKey.includes('BEGIN PRIVATE KEY')) return null;
  return { projectId, clientEmail, privateKey };
}

export class PushForbidden extends Error {}
export class PushInvalid extends Error {}
/** Only an approved driver may store a token, and only for their own row. */
export async function registerPushToken(
  db: SqlDatabase,
  userId: string,
  token: unknown,
  platform: unknown,
  now = Date.now(),
) {
  if (
    typeof token !== 'string' ||
    token.length < 20 ||
    token.length > 4096 ||
    !/^[\w:.\-]+$/.test(token)
  )
    throw new PushInvalid('Ungültige Geräteadresse für Benachrichtigungen.');
  if (platform !== 'android' && platform !== 'ios')
    throw new PushInvalid('Unbekannte Plattform.');
  const driver = await db
    .prepare('SELECT approved FROM mobility_drivers WHERE id=?')
    .bind(userId)
    .first<{ approved: number }>();
  if (!driver || driver.approved !== 1)
    throw new PushForbidden(
      'Benachrichtigungen sind nur für freigegebene Fahrer möglich.',
    );
  await db.batch([
    // A phone handed to another driver must stop waking the previous one.
    db
      .prepare('DELETE FROM mobility_push_tokens WHERE token=? AND driver_id<>?')
      .bind(token, userId),
    db
      .prepare(
        'INSERT INTO mobility_push_tokens(driver_id,token,platform,created_at,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(driver_id) DO UPDATE SET token=excluded.token,platform=excluded.platform,updated_at=excluded.updated_at',
      )
      .bind(userId, token, platform, now, now),
  ]);
}
export async function removePushToken(db: SqlDatabase, userId: string) {
  await db
    .prepare('DELETE FROM mobility_push_tokens WHERE driver_id=?')
    .bind(userId)
    .run();
}

export type WakeRecipient = { driverId: string; token: string };
/**
 * Classes with a waiting request (no pending offer) and no free online driver.
 * For these, offline approved drivers with an active vehicle of the class are
 * claimed atomically: the claim itself is the 10-minute lock.
 */
export async function claimWakeRecipients(
  db: SqlDatabase,
  now = Date.now(),
): Promise<WakeRecipient[]> {
  const waiting = await db
    .prepare(
      "SELECT DISTINCT b.service FROM mobility_bookings b WHERE b.status='requesting' AND NOT EXISTS(SELECT 1 FROM mobility_offers o WHERE o.booking_id=b.id AND o.status='pending' AND o.expires_at>?)",
    )
    .bind(now)
    .all<{ service: string }>();
  const recipients = new Map<string, string>();
  for (const service of waiting.results
    .map((r) => r.service)
    .filter(isService) as Service[]) {
    const free = await db
      .prepare(
        `SELECT 1 AS free FROM mobility_drivers d WHERE ${freeOnlineDriver('d')} AND EXISTS(SELECT 1 FROM json_each(COALESCE(d.services,json_array(d.service))) WHERE value=?) LIMIT 1`,
      )
      .bind(now - FRESH_MS, service)
      .first();
    if (free) continue;
    const claimed = await db
      .prepare(
        `UPDATE mobility_push_tokens SET last_wake_at=? WHERE (last_wake_at IS NULL OR last_wake_at<=?) AND driver_id IN (
 SELECT d.id FROM mobility_drivers d WHERE ${vehicleEligible('d')} AND d.approved=1
 AND NOT (d.online=1 AND d.location_at IS NOT NULL AND d.location_at>?)
 AND EXISTS(SELECT 1 FROM json_each(COALESCE(d.services,json_array(d.service))) WHERE value=?)
 AND NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.driver_id=d.id AND (b.status IN ('accepted','arrived','riding') OR (b.status='completed' AND b.completed_at IS NOT NULL AND b.payment_status='unpaid')))
 AND NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.owner_id=d.id AND b.status='requesting' AND b.service=?)
 ) RETURNING driver_id,token`,
      )
      .bind(now, now - WAKE_INTERVAL_MS, now - FRESH_MS, service, service)
      .all<{ driver_id: string; token: string }>();
    for (const row of claimed.results) recipients.set(row.driver_id, row.token);
  }
  return [...recipients].map(([driverId, token]) => ({ driverId, token }));
}

const base64url = (bytes: Uint8Array | string) =>
  Buffer.from(bytes).toString('base64url');
/** Service-account assertion (RS256) signed with WebCrypto; no extra package. */
export async function serviceJwt(config: PushConfig, now = Date.now()) {
  const der = Buffer.from(
    config.privateKey.replace(/-----[A-Z ]+-----/g, '').replace(/\s+/g, ''),
    'base64',
  );
  const key = await crypto.subtle.importKey(
    'pkcs8',
    der,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign'],
  );
  const iat = Math.floor(now / 1000);
  const unsigned =
    base64url(JSON.stringify({ alg: 'RS256', typ: 'JWT' })) +
    '.' +
    base64url(
      JSON.stringify({
        iss: config.clientEmail,
        scope: 'https://www.googleapis.com/auth/firebase.messaging',
        aud: 'https://oauth2.googleapis.com/token',
        iat,
        exp: iat + 3600,
      }),
    );
  const signature = await crypto.subtle.sign(
    'RSASSA-PKCS1-v1_5',
    key,
    new TextEncoder().encode(unsigned),
  );
  return unsigned + '.' + base64url(new Uint8Array(signature));
}
let cachedAccess: { key: string; token: string; expiresAt: number } | null =
  null;
export function forgetPushAccess() {
  cachedAccess = null;
}
async function accessToken(
  config: PushConfig,
  request: typeof fetch,
  now: number,
) {
  const key = config.projectId + ':' + config.clientEmail;
  if (cachedAccess?.key === key && cachedAccess.expiresAt > now + 60000)
    return cachedAccess.token;
  const response = await request('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion: await serviceJwt(config, now),
    }),
    signal: AbortSignal.timeout(8000),
  });
  if (!response.ok) throw new Error('FCM-Anmeldung: HTTP ' + response.status);
  const value = (await response.json()) as {
    access_token?: string;
    expires_in?: number;
  };
  if (!value.access_token) throw new Error('FCM-Anmeldung ohne Zugriffstoken.');
  cachedAccess = {
    key,
    token: value.access_token,
    expiresAt: now + (value.expires_in ?? 3600) * 1000,
  };
  return value.access_token;
}
export function wakeMessage(token: string) {
  return {
    message: {
      token,
      // A notification message: Android shows it itself and a tap opens the
      // app's start activity, even when the app process is not running.
      notification: { title: WAKE_TITLE, body: WAKE_BODY },
      data: { kind: 'luxore-wake' },
      android: {
        priority: 'HIGH',
        // A request is searched for three minutes; later delivery is useless.
        ttl: '180s',
        collapse_key: 'luxore-wake',
        notification: { channel_id: WAKE_CHANNEL, tag: 'luxore-wake' },
      },
    },
  };
}
export type WakeResult = {
  configured: boolean;
  sent: number;
  failed: number;
  removed: number;
};
/**
 * Never throws and never touches the database without configuration.
 * Callers run it after the response (`after()`), so bookings are not delayed.
 */
export async function wakeOfflineDrivers(
  db: SqlDatabase,
  now = Date.now(),
  deps: { env?: Env; fetch?: typeof fetch } = {},
): Promise<WakeResult> {
  const result: WakeResult = {
    configured: false,
    sent: 0,
    failed: 0,
    removed: 0,
  };
  const config = pushConfig(deps.env);
  if (!config) return result;
  result.configured = true;
  const request = deps.fetch ?? fetch;
  try {
    const recipients = await claimWakeRecipients(db, now);
    if (!recipients.length) return result;
    const bearer = await accessToken(config, request, now);
    await Promise.all(
      recipients.map(async ({ driverId, token }) => {
        try {
          const response = await request(
            `https://fcm.googleapis.com/v1/projects/${config.projectId}/messages:send`,
            {
              method: 'POST',
              headers: {
                Authorization: 'Bearer ' + bearer,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(wakeMessage(token)),
              signal: AbortSignal.timeout(8000),
            },
          );
          if (response.ok) {
            result.sent++;
            return;
          }
          result.failed++;
          const detail = await response.text().catch(() => '');
          // The app was removed or the token replaced: forget this address.
          if (response.status === 404 || detail.includes('UNREGISTERED')) {
            await db
              .prepare(
                'DELETE FROM mobility_push_tokens WHERE driver_id=? AND token=?',
              )
              .bind(driverId, token)
              .run();
            result.removed++;
          } else if (response.status === 401) forgetPushAccess();
        } catch {
          result.failed++;
        }
      }),
    );
  } catch (error) {
    // Tokens and keys never reach the log.
    console.error('Push: Versand nicht möglich.', (error as Error).message);
  }
  return result;
}
