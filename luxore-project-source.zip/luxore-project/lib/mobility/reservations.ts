import type { SqlDatabase } from '@/db/sqlite';
import { ApiError } from './server';
import { vehicleEligible } from './vehicles';
import { RESERVATION_LEAD_MS } from './dispatch';
import type { RouteData, Service } from './domain';
import { classes } from '@/lib/ride-domain';
import { cartLabel, countCart, storedOrder } from './refreshments';
import { preferenceLabels, storedRidePreferences } from './ride-preferences';
import { driverCard, type DriverCard } from './profile';
import { ratingSummary, type RatingSummary } from './ratings';

/** Reservation board rules. Single place to change the time values. */
/** Drivers of other fleets see a reservation once it is this old … */
export const FOREIGN_FLEET_MIN_AGE_MS = 2 * 3600000;
/** … or once the pick-up is closer than this. */
export const FOREIGN_FLEET_PICKUP_WINDOW_MS = 3 * 3600000;
/** A driver may hand a reservation back until this long before pick-up. */
export const RELEASE_DEADLINE_MS = 90 * 60000;
/** Two reservations of one driver need the driving time plus this gap. */
export const OVERLAP_BUFFER_MS = 30 * 60000;
const OWN_FLEET_KEY = 'own_fleet_id';

/** The operator's own fleet (priority on the board); null when not set. */
export async function ownFleetId(database: SqlDatabase) {
  const row = await database
    .prepare(
      'SELECT f.id FROM mobility_settings s JOIN mobility_fleets f ON f.id=s.value WHERE s.key=?',
    )
    .bind(OWN_FLEET_KEY)
    .first<{ id: string }>();
  return row?.id || null;
}
export async function setOwnFleet(
  database: SqlDatabase,
  fleetId: string | null,
  actorId: string,
  now = Date.now(),
) {
  if (
    fleetId &&
    !(await database
      .prepare('SELECT id FROM mobility_fleets WHERE id=?')
      .bind(fleetId)
      .first())
  )
    throw new ApiError(404, 'Flotte nicht gefunden.');
  await database
    .prepare(
      'INSERT INTO mobility_settings(key,value,updated_at,updated_by) VALUES(?,?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at,updated_by=excluded.updated_by',
    )
    .bind(OWN_FLEET_KEY, fleetId || '', now, actorId)
    .run();
}
// SQL fragments. `b` is an internal table name or alias, never request input.
/** Binds: now + lead time. */
const open = (b: string) =>
  `${b}.status='reserved' AND ${b}.assigned_driver_id IS NULL AND ${b}.scheduled_at>?`;
/**
 * Same suitability as live dispatch (approved, active vehicle of the own
 * fleet, class of the current vehicle, not the customer) plus active holds.
 * Binds: driver id.
 */
const suitable = (b: string) =>
  `EXISTS(SELECT 1 FROM mobility_drivers d WHERE d.id=? AND d.approved=1 AND d.id<>${b}.owner_id AND ${vehicleEligible('d')}
   AND EXISTS(SELECT 1 FROM json_each(COALESCE(d.services,json_array(d.service))) WHERE value=${b}.service)
   AND NOT EXISTS(SELECT 1 FROM mobility_suspensions s WHERE s.lifted_at IS NULL AND (
     (s.subject_type='driver' AND s.subject_id=d.id) OR (s.subject_type='vehicle' AND s.subject_id=d.vehicle_id)
     OR (s.subject_type='fleet' AND s.subject_id=(SELECT fleet_id FROM mobility_employees WHERE user_id=d.id)))))`;
/**
 * Priority of the operator's own fleet. Without an own fleet everybody sees
 * everything at once. Binds: driver id, now - min age, now + pick-up window.
 */
const visible = (b: string) =>
  `(NOT EXISTS(SELECT 1 FROM mobility_settings st JOIN mobility_fleets f ON f.id=st.value WHERE st.key='${OWN_FLEET_KEY}')
   OR EXISTS(SELECT 1 FROM mobility_settings st JOIN mobility_employees e ON e.fleet_id=st.value WHERE st.key='${OWN_FLEET_KEY}' AND e.user_id=?)
   OR ${b}.created_at<=? OR ${b}.scheduled_at<?)`;
const span = (b: string) =>
  `COALESCE(json_extract(${b}.route,'$.durationSeconds'),0)*1000+${OVERLAP_BUFFER_MS}`;
/** No other reservation of this driver overlaps. Binds: driver id. */
const free = (b: string) =>
  `NOT EXISTS(SELECT 1 FROM mobility_bookings o WHERE o.assigned_driver_id=? AND o.status='reserved' AND o.id<>${b}.id
   AND o.scheduled_at<${b}.scheduled_at+${span(b)} AND ${b}.scheduled_at<o.scheduled_at+${span('o')})`;

/**
 * State of the driver a reservation is assigned to, read with the booking.
 * `d` must be mobility_drivers joined on ${b}.assigned_driver_id.
 */
const assignmentState = (b: string) =>
  `d.id AS a_driver,d.approved AS a_approved,
   (d.id IS NOT NULL AND ${vehicleEligible('d')}) AS a_vehicle,
   EXISTS(SELECT 1 FROM json_each(COALESCE(d.services,json_array(d.service))) WHERE value=${b}.service) AS a_fits,
   EXISTS(SELECT 1 FROM mobility_suspensions s WHERE s.lifted_at IS NULL AND (
     (s.subject_type='driver' AND s.subject_id=d.id) OR (s.subject_type='vehicle' AND s.subject_id=d.vehicle_id)
     OR (s.subject_type='fleet' AND s.subject_id=(SELECT fleet_id FROM mobility_employees WHERE user_id=d.id)))) AS a_held,
   (SELECT fleet_id FROM mobility_employees WHERE user_id=d.id) AS a_fleet`;
type AssignmentState = {
  a_driver: string | null;
  a_approved: number | null;
  a_vehicle: number;
  a_fits: number;
  a_held: number;
  a_fleet: string | null;
  assigned_fleet_id: string | null;
};
export type AssignmentIssue = {
  /** Not approved or on hold: the customer's contact is withheld. */
  blocked: boolean;
  /** For fleet lead and operator. */
  staff: string;
  /** For the driver, under "Meine". */
  driver: string;
};
const DRIVER_HINT =
  ' Ohne Klärung geht die Fahrt 15 Minuten vor der Abholung an einen anderen Fahrer. Bitte kläre das mit deiner Flottenleitung oder gib die Reservierung ab.';
/**
 * Pure: does a taken-over reservation still fit its driver? The assignment
 * is never lifted automatically; it is marked ("Zuteilung prüfen").
 */
export function assignmentIssue(state: AssignmentState): AssignmentIssue | null {
  const issue = (blocked: boolean, staff: string, driver: string) => ({
    blocked,
    staff,
    driver: driver + DRIVER_HINT,
  });
  if (!state.a_driver)
    return issue(true, 'Das Fahrerprofil gibt es nicht mehr.', 'Dein Fahrerprofil fehlt.');
  if (!state.a_approved)
    return issue(
      true,
      'Der Fahrer ist nicht mehr freigegeben.',
      'Dein Fahrerprofil ist zurzeit nicht freigegeben.',
    );
  if (state.a_held)
    return issue(
      true,
      'Fahrer, Fahrzeug oder Flotte sind gesperrt.',
      'Du, dein Fahrzeug oder deine Flotte sind zurzeit gesperrt.',
    );
  if ((state.a_fleet || null) !== (state.assigned_fleet_id || null))
    return issue(
      false,
      'Der Fahrer gehört nicht mehr zu dieser Flotte.',
      'Du hast seit dem Übernehmen die Flotte gewechselt.',
    );
  if (!state.a_vehicle)
    return issue(
      false,
      'Der Fahrer hat kein aktives Fahrzeug gewählt.',
      'Du hast kein aktives Fahrzeug gewählt.',
    );
  if (!state.a_fits)
    return issue(
      false,
      'Das aktuelle Fahrzeug des Fahrers passt nicht zur Klasse.',
      'Dein aktuelles Fahrzeug passt nicht zur Klasse dieser Reservierung.',
    );
  return null;
}

/**
 * Why the board is closed for this driver, as a plain sentence; null when he
 * may take reservations over. `needsVehicle` offers the vehicle choice.
 */
export async function boardBlock(database: SqlDatabase, driverId: string) {
  const row = await database
    .prepare(
      `SELECT d.approved,${vehicleEligible('d')} AS vehicle,
       EXISTS(SELECT 1 FROM mobility_suspensions s WHERE s.lifted_at IS NULL AND (
         (s.subject_type='driver' AND s.subject_id=d.id) OR (s.subject_type='vehicle' AND s.subject_id=d.vehicle_id)
         OR (s.subject_type='fleet' AND s.subject_id=(SELECT fleet_id FROM mobility_employees WHERE user_id=d.id)))) AS held
       FROM mobility_drivers d WHERE d.id=?`,
    )
    .bind(driverId)
    .first<{ approved: number; vehicle: number; held: number }>();
  if (!row?.approved)
    return {
      profile: !!row,
      needsVehicle: false,
      reason:
        'Reservierungen siehst du, sobald dein Fahrerprofil freigegeben ist.',
    };
  if (row.held)
    return {
      profile: true,
      needsVehicle: false,
      reason:
        'Du, dein Fahrzeug oder deine Flotte sind zurzeit gesperrt. Offene Reservierungen siehst du wieder, sobald die Sperre aufgehoben ist.',
    };
  if (!row.vehicle)
    return {
      profile: true,
      needsVehicle: true,
      reason:
        'Bitte zuerst ein Fahrzeug wählen. Du siehst dann die Reservierungen, die zu diesem Fahrzeug passen.',
    };
  return null;
}

type Row = {
  id: string;
  owner_id: string;
  service: Service;
  price: number;
  route: string;
  scheduled_at: number;
  created_at: number;
  rider_name: string | null;
  rider_phone: string | null;
  rider_preferences: string | null;
  refreshments: string | null;
  assigned_driver_id: string | null;
  assigned_fleet_id: string | null;
  assigned_vehicle_id: string | null;
  assigned_at: number | null;
};
/** What every suitable driver may see before taking over. No customer data. */
export type ReservationCard = {
  id: string;
  pickup: string;
  destination: string;
  scheduledAt: number;
  distanceMeters: number;
  durationSeconds: number;
  price: number;
  service: Service;
  className: string;
  capacity: string;
  wishes: string[];
  boardOrder: string | null;
  /** Overlaps one of the caller's own reservations. */
  conflict?: boolean;
};
export type OwnReservation = ReservationCard & {
  assignedAt: number;
  /** Until then the driver may hand it back himself. */
  releaseUntil: number;
  riderName: string | null;
  riderPhone: string | null;
  riderRating: RatingSummary | null;
  /** Why this assignment needs attention (plain sentence), else null. */
  check: string | null;
  /** True while name and phone are withheld (not approved or on hold). */
  contactHidden: boolean;
};
/** Pure: the public card of a reservation. Never name, phone or notes. */
export function reservationCard(row: Row): ReservationCard {
  const route = JSON.parse(row.route) as RouteData;
  const cls = classes.find((c) => c.id === row.service);
  const requested = storedOrder(row.refreshments).requested;
  return {
    id: row.id,
    pickup: route.pickup.label,
    destination: route.destination.label,
    scheduledAt: Number(row.scheduled_at),
    distanceMeters: route.distanceMeters,
    durationSeconds: route.durationSeconds,
    price: Number(row.price),
    service: row.service,
    className: cls?.name || row.service,
    capacity: cls?.capacity || '',
    wishes: preferenceLabels(storedRidePreferences(row.rider_preferences)),
    boardOrder: countCart(requested) ? cartLabel(requested) : null,
  };
}
const busyUntil = (c: Pick<ReservationCard, 'scheduledAt' | 'durationSeconds'>) =>
  c.scheduledAt + c.durationSeconds * 1000 + OVERLAP_BUFFER_MS;
/** Pure: do two reservations collide (driving time plus 30 minutes)? */
export const overlaps = (
  a: Pick<ReservationCard, 'scheduledAt' | 'durationSeconds'>,
  b: Pick<ReservationCard, 'scheduledAt' | 'durationSeconds'>,
) => a.scheduledAt < busyUntil(b) && b.scheduledAt < busyUntil(a);

/** The driver's own, taken-over reservations with the customer's contact. */
export async function ownReservations(
  database: SqlDatabase,
  driverId: string,
): Promise<OwnReservation[]> {
  const rows = await database
    .prepare(
      `SELECT b.*,${assignmentState('b')} FROM mobility_bookings b LEFT JOIN mobility_drivers d ON d.id=b.assigned_driver_id
       WHERE b.assigned_driver_id=? AND b.status='reserved' ORDER BY b.scheduled_at LIMIT 100`,
    )
    .bind(driverId)
    .all<Row & AssignmentState>();
  return Promise.all(
    rows.results.map(async (row) => {
      const issue = assignmentIssue(row);
      // The name for the driver – but not while he is not approved or on hold.
      // The phone number never: it follows only once the ride has started and
      // the driver has marked "angekommen" (see hydrate in bookings.ts).
      const hidden = !!issue?.blocked;
      return {
        ...reservationCard(row),
        assignedAt: Number(row.assigned_at),
        releaseUntil: Number(row.scheduled_at) - RELEASE_DEADLINE_MS,
        riderName: hidden ? null : row.rider_name,
        riderPhone: null,
        riderRating: hidden
          ? null
          : await ratingSummary(database, row.owner_id, 'driver'),
        check: issue?.driver || null,
        contactHidden: hidden,
      };
    }),
  );
}
/** Open reservations this driver may take over right now. */
export async function openReservations(
  database: SqlDatabase,
  driverId: string,
  now = Date.now(),
  mine: Pick<ReservationCard, 'scheduledAt' | 'durationSeconds'>[] = [],
): Promise<ReservationCard[]> {
  const rows = await database
    .prepare(
      `SELECT * FROM mobility_bookings b WHERE ${open('b')} AND ${suitable('b')} AND ${visible('b')} ORDER BY b.scheduled_at LIMIT 100`,
    )
    .bind(
      now + RESERVATION_LEAD_MS,
      driverId,
      driverId,
      now - FOREIGN_FLEET_MIN_AGE_MS,
      now + FOREIGN_FLEET_PICKUP_WINDOW_MS,
    )
    .all<Row>();
  return rows.results.map((row) => {
    const card = reservationCard(row);
    return { ...card, conflict: mine.some((m) => overlaps(card, m)) };
  });
}
/**
 * Takes a reservation over. One guarded UPDATE decides: of two drivers who
 * swipe at the same moment exactly one wins.
 */
export async function claimReservation(
  database: SqlDatabase,
  driverId: string,
  bookingId: string,
  now = Date.now(),
) {
  const t = 'mobility_bookings';
  const results = await database.batch([
    database
      .prepare(
        `UPDATE ${t} SET assigned_driver_id=?,assigned_at=?,updated_at=?,
         assigned_fleet_id=(SELECT fleet_id FROM mobility_employees WHERE user_id=?),
         assigned_vehicle_id=(SELECT vehicle_id FROM mobility_drivers WHERE id=?)
         WHERE id=? AND ${open(t)} AND ${suitable(t)} AND ${visible(t)} AND ${free(t)}`,
      )
      .bind(
        driverId,
        now,
        now,
        driverId,
        driverId,
        bookingId,
        now + RESERVATION_LEAD_MS,
        driverId,
        driverId,
        now - FOREIGN_FLEET_MIN_AGE_MS,
        now + FOREIGN_FLEET_PICKUP_WINDOW_MS,
        driverId,
      ),
    database
      .prepare(
        "INSERT INTO mobility_events(id,booking_id,actor_id,action,created_at) SELECT ?,?,?,'reservation.claimed',? WHERE changes()>0 AND EXISTS(SELECT 1 FROM mobility_bookings WHERE id=? AND assigned_driver_id=? AND assigned_at=?)",
      )
      .bind(crypto.randomUUID(), bookingId, driverId, now, bookingId, driverId, now),
  ]);
  if (results[0].meta.changes === 1) return { ok: true as const };
  // Explain calmly why nothing changed, without revealing hidden reservations.
  const seen = await database
    .prepare(
      `SELECT b.status,b.assigned_driver_id,b.scheduled_at,${free('b')} AS free,${open('b')} AS open FROM mobility_bookings b
       WHERE b.id=? AND b.mode='reservation' AND ${suitable('b')} AND ${visible('b')}`,
    )
    .bind(
      driverId,
      now + RESERVATION_LEAD_MS,
      bookingId,
      driverId,
      driverId,
      now - FOREIGN_FLEET_MIN_AGE_MS,
      now + FOREIGN_FLEET_PICKUP_WINDOW_MS,
    )
    .first<{
      status: string;
      assigned_driver_id: string | null;
      free: number;
      open: number;
    }>();
  if (!seen) throw new ApiError(404, 'Diese Reservierung ist für dich nicht verfügbar.');
  // A lost answer: the reservation is already this driver's.
  if (seen.status === 'reserved' && seen.assigned_driver_id === driverId)
    return { ok: true as const, replayed: true };
  if (seen.status !== 'reserved')
    throw new ApiError(409, 'Diese Reservierung ist nicht mehr offen.');
  if (seen.assigned_driver_id)
    throw new ApiError(
      409,
      'Diese Reservierung wurde gerade von einem anderen Fahrer übernommen.',
    );
  if (!seen.free)
    throw new ApiError(
      409,
      'Du hast in dieser Zeit bereits eine Reservierung übernommen (Fahrzeit plus 30 Minuten Abstand).',
    );
  throw new ApiError(
    409,
    'Diese Reservierung beginnt in Kürze und kann nicht mehr übernommen werden.',
  );
}
const CLEAR =
  'assigned_driver_id=NULL,assigned_fleet_id=NULL,assigned_vehicle_id=NULL,assigned_at=NULL';
const released = (
  database: SqlDatabase,
  bookingId: string,
  actorId: string,
  action: string,
  now: number,
) =>
  database
    .prepare(
      "INSERT INTO mobility_events(id,booking_id,actor_id,action,created_at) SELECT ?,?,?,?,? WHERE changes()>0",
    )
    .bind(crypto.randomUUID(), bookingId, actorId, action, now);
/** The driver hands a reservation back; only until 90 minutes before pick-up. */
export async function releaseReservation(
  database: SqlDatabase,
  driverId: string,
  bookingId: string,
  now = Date.now(),
) {
  const results = await database.batch([
    database
      .prepare(
        `UPDATE mobility_bookings SET ${CLEAR},updated_at=? WHERE id=? AND assigned_driver_id=? AND status='reserved' AND scheduled_at-?>=${RELEASE_DEADLINE_MS}`,
      )
      .bind(now, bookingId, driverId, now),
    released(database, bookingId, driverId, 'reservation.released', now),
  ]);
  if (results[0].meta.changes === 1) return;
  const own = await database
    .prepare(
      "SELECT id FROM mobility_bookings WHERE id=? AND assigned_driver_id=? AND status='reserved'",
    )
    .bind(bookingId, driverId)
    .first();
  throw new ApiError(
    409,
    own
      ? 'Abgeben ist nur bis 90 Minuten vor der Abholung möglich. Bitte wende dich an deine Flottenleitung.'
      : 'Diese Reservierung ist dir nicht mehr zugeteilt.',
  );
}
/** Fleet lead (own fleet) or operator ('all') lifts an assignment at any time. */
export async function unassignReservation(
  database: SqlDatabase,
  scope: string,
  actorId: string,
  bookingId: string,
  now = Date.now(),
) {
  const results = await database.batch([
    database
      .prepare(
        `UPDATE mobility_bookings SET ${CLEAR},updated_at=? WHERE id=? AND assigned_driver_id IS NOT NULL AND status='reserved' AND (?='all' OR assigned_fleet_id=?)`,
      )
      .bind(now, bookingId, scope, scope),
    released(database, bookingId, actorId, 'reservation.unassigned', now),
  ]);
  if (results[0].meta.changes !== 1)
    throw new ApiError(
      409,
      'Diese Reservierung ist nicht (mehr) einem Fahrer deiner Flotte zugeteilt.',
    );
}
export type StaffReservation = ReservationCard & {
  createdAt: number;
  riderName: string | null;
  riderRating: RatingSummary | null;
  assigned: {
    driverId: string;
    driverName: string;
    fleetId: string | null;
    fleetName: string | null;
    vehicle: string | null;
    plate: string | null;
    at: number;
    /** "Zuteilung prüfen": why the driver no longer fits, else null. */
    check: string | null;
  } | null;
};
/**
 * Disposition view. Operator: every upcoming reservation, open or taken.
 * Fleet lead: the reservations taken over by drivers of the own fleet.
 */
export async function staffReservations(
  database: SqlDatabase,
  scope: string,
): Promise<StaffReservation[]> {
  const rows = await database
    .prepare(
      `SELECT b.*,d.name AS driver_name,f.name AS fleet_name,v.model AS vehicle_model,v.plate AS vehicle_plate,${assignmentState('b')}
       FROM mobility_bookings b LEFT JOIN mobility_drivers d ON d.id=b.assigned_driver_id
       LEFT JOIN mobility_fleets f ON f.id=b.assigned_fleet_id LEFT JOIN mobility_vehicles v ON v.id=b.assigned_vehicle_id
       WHERE b.status='reserved' AND (?='all' OR b.assigned_fleet_id=?) ORDER BY b.scheduled_at LIMIT 200`,
    )
    .bind(scope, scope)
    .all<
      Row & AssignmentState & {
        driver_name: string | null;
        fleet_name: string | null;
        vehicle_model: string | null;
        vehicle_plate: string | null;
      }
    >();
  return Promise.all(
    rows.results.map(async (row) => ({
      ...reservationCard(row),
      createdAt: Number(row.created_at),
      riderName: row.rider_name,
      riderRating: await ratingSummary(database, row.owner_id, 'driver'),
      assigned: row.assigned_driver_id
        ? {
            driverId: row.assigned_driver_id,
            driverName: row.driver_name || 'Fahrer',
            fleetId: row.assigned_fleet_id,
            fleetName: row.fleet_name,
            vehicle: row.vehicle_model,
            plate: row.vehicle_plate,
            at: Number(row.assigned_at),
            check: assignmentIssue(row)?.staff || null,
          }
        : null,
    })),
  );
}
export type Chauffeur = DriverCard & {
  name: string;
  vehicle: string | null;
  plate: string | null;
};
/** For the customer's own reservation: the confirmed chauffeur, no phone. */
export async function confirmedChauffeur(
  database: SqlDatabase,
  driverId: string,
  vehicleId: string | null,
): Promise<Chauffeur | null> {
  const driver = await database
    .prepare(
      'SELECT d.name,v.model,v.plate FROM mobility_drivers d LEFT JOIN mobility_vehicles v ON v.id=? WHERE d.id=?',
    )
    .bind(vehicleId ?? '', driverId)
    .first<{ name: string; model: string | null; plate: string | null }>();
  if (!driver) return null;
  return {
    name: driver.name,
    vehicle: driver.model,
    plate: driver.plate,
    ...(await driverCard(database, driverId)),
  };
}
