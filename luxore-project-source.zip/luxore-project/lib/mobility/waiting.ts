import { isService, type RouteData, type Service } from './domain';

/**
 * Wish of the operator (18.11.2026): once the chauffeur is at the pickup
 * point the first ten minutes of waiting are free. After that every started
 * minute is charged, differently per class.
 *
 * THE AMOUNTS ARE NOT DECIDED YET: every rate is 0, so nothing is charged
 * and nothing about a price changes. Enter the cents per minute here once
 * the operator has named them – the rest is built and tested.
 */
export const WAIT_FREE_SECONDS = 10 * 60;
export const WAIT_RATES: Record<Service, number> = {
  premium: 0,
  electric: 0,
  van: 0,
  first: 0,
};
/** A forgotten "Fahrt starten" must not produce an absurd bill. */
export const WAIT_MAX_MINUTES = 120;

export type WaitingCharge = {
  /** Whole waiting time at the pickup point. */
  seconds: number;
  freeSeconds: number;
  /** Started minutes after the free time. */
  minutes: number;
  /** Cents per minute at the time of the ride. */
  rate: number;
  fee: number;
  at: number;
};
/** True when waiting is charged for at least one class. */
export const waitingCharged = (rates: Record<Service, number> = WAIT_RATES) =>
  Object.values(rates).some((rate) => rate > 0);
/** The charge for a ride that starts now; null when nothing is charged. */
export function waitingCharge(
  service: unknown,
  arrivedAt: number,
  startedAt: number,
  rates: Record<Service, number> = WAIT_RATES,
): WaitingCharge | null {
  if (!isService(service)) return null;
  const rate = rates[service];
  if (!Number.isInteger(rate) || rate <= 0) return null;
  if (!Number.isFinite(arrivedAt) || !Number.isFinite(startedAt)) return null;
  const seconds = Math.max(0, Math.round((startedAt - arrivedAt) / 1000));
  const billable = seconds - WAIT_FREE_SECONDS;
  if (billable <= 0) return null;
  const minutes = Math.min(WAIT_MAX_MINUTES, Math.ceil(billable / 60));
  return {
    seconds,
    freeSeconds: WAIT_FREE_SECONDS,
    minutes,
    rate,
    fee: minutes * rate,
    at: startedAt,
  };
}
/** Waiting fee that is already part of this ride's fare, in cents. */
export function waitingFee(route: RouteData | null | undefined) {
  const fee = route?.waiting?.fee;
  return typeof fee === 'number' && Number.isInteger(fee) && fee > 0 ? fee : 0;
}
const euro = (cents: number) =>
  (cents / 100).toLocaleString('de-DE', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }) + ' €';
/** One sentence for the bill; null when no waiting was charged. */
export function waitingNote(route: RouteData | null | undefined) {
  const w = route?.waiting;
  if (!w || !waitingFee(route)) return null;
  return `Wartezeit am Abholort: ${Math.round(w.freeSeconds / 60)} Min. kostenlos, danach ${w.minutes} Min. zu ${euro(w.rate)} = ${euro(w.fee)}.`;
}
/** What the customer is told before booking; empty while nothing is charged. */
export function waitingTerms(
  service: unknown,
  rates: Record<Service, number> = WAIT_RATES,
) {
  if (!isService(service) || !(rates[service] > 0)) return '';
  return `Wartezeit am Abholort: ${WAIT_FREE_SECONDS / 60} Min. kostenlos, danach ${euro(rates[service])} je angefangene Minute.`;
}
