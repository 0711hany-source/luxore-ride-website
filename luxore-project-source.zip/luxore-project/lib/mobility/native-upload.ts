import { ApiError, db } from './server';
import { nativeUploadSessionSql, saveNativeLocationSql } from './location';

export async function saveNativeLocation(
  hash: string,
  expected: { driver_id: string; session_id: string },
  point: Record<string, unknown>,
) {
  return db().writeTransaction(async (transaction) => {
    // Preliminary capability/body/rate-limit work may predate revocation.
    const now = Date.now();
    const session = await transaction
      .prepare(nativeUploadSessionSql)
      .bind(hash, now)
      .first<{ driver_id: string; session_id: string }>();
    if (
      !session ||
      session.driver_id !== expected.driver_id ||
      session.session_id !== expected.session_id
    )
      throw new ApiError(
        401,
        'Standortfreigabe beendet. Bitte erneut online gehen.',
      );
    const saved = await transaction
      .prepare(saveNativeLocationSql)
      .bind(
        point.lat,
        point.lng,
        point.accuracy,
        point.timestamp,
        session.driver_id,
        session.session_id,
        point.timestamp,
        hash,
        now,
      )
      .run();
    // Valid old/duplicate points remain acknowledged no-ops. Revoked authority
    // above is a 401, so the client can distinguish it from timestamp ordering.
    return saved.meta.changes === 1;
  });
}
