import type { SqlDatabase } from '@/db/sqlite';
import { ApiError } from './server';
import { berlinDayStart } from './time';

/**
 * Servicepauschale der Plattform gegenüber der Flotte, in Basispunkten
 * (1500 = 15 %). Einzige Stelle für den Satz. Der Fahrpreis des Kunden und die
 * Preislogik bleiben davon unberührt.
 */
export const SERVICE_FEE_BPS = 1500;
export const SERVICE_FEE_LABEL = 'Servicepauschale 15 %';
export const SETTLEMENT_NOTICE =
  'Abrechnungsübersicht – keine Rechnung im steuerlichen Sinn';

/** Kaufmännisch auf Cent gerundet (halbe Cent aufwärts), je Fahrt. */
export function serviceFee(fareCents: number, bps = SERVICE_FEE_BPS) {
  if (!Number.isSafeInteger(fareCents) || fareCents <= 0) return 0;
  return Math.floor((fareCents * bps + 5000) / 10000);
}
// Same rounding inside SQL: integer division truncates, values are positive.
const FEE_SQL = `((COALESCE(b.fare_price,b.price)*${SERVICE_FEE_BPS}+5000)/10000)`;
const SETTLED = "b.status='completed' AND b.payment_status='paid'";

const dateParts = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Europe/Berlin',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
});
/** Calendar day in Frankfurt as YYYY-MM-DD. */
export const berlinDate = (at: number) => dateParts.format(at);
const utcNoon = (date: string) => {
  const [y, m, d] = date.split('-').map(Number);
  return Date.UTC(y, m - 1, d, 12);
};
export function validDate(value: unknown): value is string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value))
    return false;
  const at = utcNoon(value);
  return (
    Number.isFinite(at) && new Date(at).toISOString().slice(0, 10) === value
  );
}
export const addDays = (date: string, days: number) =>
  new Date(utcNoon(date) + days * 86400000).toISOString().slice(0, 10);
/** 00:00 Frankfurt time of that calendar day, also on 23/25-hour days. */
export const berlinDateStart = (date: string) => berlinDayStart(utcNoon(date));
/** Monday (YYYY-MM-DD) of the Frankfurt week containing the instant. */
export function berlinWeek(at: number) {
  const date = berlinDate(at);
  const weekday = new Date(utcNoon(date)).getUTCDay();
  return addDays(date, -((weekday + 6) % 7));
}
export const validWeek = (value: unknown): value is string =>
  validDate(value) && new Date(utcNoon(value)).getUTCDay() === 1;
/** Monday 00:00 (inclusive) to next Monday 00:00 (exclusive), Europe/Berlin. */
export const weekRange = (week: string) => ({
  start: berlinDateStart(week),
  end: berlinDateStart(addDays(week, 7)),
});
export const berlinMonth = (at: number) => berlinDate(at).slice(0, 7);
export const monthStart = (month: string) => berlinDateStart(month + '-01');

export type SettledTrip = {
  id: string;
  completedAt: number;
  paidAt: number;
  service: string;
  from: string;
  to: string;
  fare: number;
  method: 'cash' | 'terminal';
  fee: number;
  driverId: string;
  driverName: string;
};
export type Totals = {
  trips: number;
  revenue: number;
  fee: number;
  net: number;
  cash: number;
  terminal: number;
};
export type Statement = Totals & {
  fleetId: string;
  fleetName: string;
  week: string;
  start: number;
  end: number;
  rateBps: number;
  drivers: (Totals & { driverId: string; name: string; rides: SettledTrip[] })[];
};
export type Settlement = {
  statement: Statement;
  status: 'open' | 'paid';
  paidAt: number | null;
  /** The week has ended; only then may a payment be recorded. */
  closed: boolean;
};
const empty = (): Totals => ({
  trips: 0,
  revenue: 0,
  fee: 0,
  net: 0,
  cash: 0,
  terminal: 0,
});
function add(total: Totals, fare: number, fee: number, method: string) {
  total.trips += 1;
  total.revenue += fare;
  total.fee += fee;
  total.net += fare - fee;
  if (method === 'terminal') total.terminal += fare;
  else total.cash += fare;
}
const short = (label: unknown) =>
  String(label ?? '')
    .split(',')[0]
    .trim()
    .slice(0, 48);
type TripRow = {
  id: string;
  completed_at: number | null;
  paid_at: number;
  service: string;
  route: string;
  price: number;
  fare_price: number | null;
  payment_method: string | null;
  driver_id: string | null;
  driver_name: string | null;
};
function trip(row: TripRow): SettledTrip {
  let from = '',
    to = '';
  try {
    const route = JSON.parse(row.route) as {
      pickup?: { label?: string };
      destination?: { label?: string };
    };
    from = short(route.pickup?.label);
    to = short(route.destination?.label);
  } catch {}
  // Board products are not part of the fee base: fare_price holds the pure
  // fare whenever products were added to price.
  const fare = Number(row.fare_price ?? row.price);
  return {
    id: row.id,
    completedAt: Number(row.completed_at ?? row.paid_at),
    paidAt: Number(row.paid_at),
    service: row.service,
    from,
    to,
    fare,
    method: row.payment_method === 'terminal' ? 'terminal' : 'cash',
    fee: serviceFee(fare),
    driverId: row.driver_id || '',
    driverName: row.driver_name || 'Fahrer',
  };
}
const TRIP_SQL = `SELECT b.id,b.completed_at,b.paid_at,b.service,b.route,b.price,b.fare_price,b.payment_method,b.driver_id,d.name AS driver_name
  FROM mobility_bookings b LEFT JOIN mobility_drivers d ON d.id=b.driver_id
  WHERE b.fleet_id=? AND ${SETTLED} AND b.paid_at>=? AND b.paid_at<? ORDER BY b.paid_at,b.id`;

/** Computed from the trips themselves; nothing is booked twice. */
export async function computeStatement(
  database: SqlDatabase,
  fleet: { id: string; name: string },
  week: string,
): Promise<Statement> {
  const { start, end } = weekRange(week);
  const rows = await database
    .prepare(TRIP_SQL)
    .bind(fleet.id, start, end)
    .all<TripRow>();
  const total = empty();
  const drivers = new Map<string, Statement['drivers'][number]>();
  for (const row of rows.results) {
    const ride = trip(row);
    add(total, ride.fare, ride.fee, ride.method);
    let driver = drivers.get(ride.driverId);
    if (!driver)
      drivers.set(
        ride.driverId,
        (driver = {
          ...empty(),
          driverId: ride.driverId,
          name: ride.driverName,
          rides: [],
        }),
      );
    add(driver, ride.fare, ride.fee, ride.method);
    driver.rides.push(ride);
  }
  return {
    ...total,
    fleetId: fleet.id,
    fleetName: fleet.name,
    week,
    start,
    end,
    rateBps: SERVICE_FEE_BPS,
    drivers: [...drivers.values()].sort((a, b) => b.revenue - a.revenue),
  };
}
type SettlementRow = {
  status: string;
  paid_at: number | null;
  snapshot: string | null;
};
/** A paid week answers from its frozen snapshot, never from live trips. */
export async function settlementFor(
  database: SqlDatabase,
  fleet: { id: string; name: string },
  week: string,
  now = Date.now(),
): Promise<Settlement> {
  const row = await database
    .prepare(
      'SELECT status,paid_at,snapshot FROM mobility_settlements WHERE fleet_id=? AND week=?',
    )
    .bind(fleet.id, week)
    .first<SettlementRow>();
  const closed = now >= weekRange(week).end;
  if (row?.status === 'paid' && row.snapshot)
    return {
      statement: JSON.parse(row.snapshot) as Statement,
      status: 'paid',
      paidAt: Number(row.paid_at),
      closed,
    };
  return {
    statement: await computeStatement(database, fleet, week),
    status: 'open',
    paidAt: null,
    closed,
  };
}
async function fleetRow(database: SqlDatabase, fleetId: string) {
  const fleet = await database
    .prepare('SELECT id,name FROM mobility_fleets WHERE id=?')
    .bind(fleetId)
    .first<{ id: string; name: string }>();
  if (!fleet) throw new ApiError(404, 'Flotte nicht gefunden.');
  return fleet;
}
/**
 * Records the incoming payment and freezes the sums. Only a finished week can
 * be frozen: its trips are assigned by collection time, so none can be added
 * afterwards. Run inside a write transaction.
 */
export async function markSettlementPaid(
  transaction: SqlDatabase,
  fleetId: string,
  week: string,
  actorId: string,
  now = Date.now(),
) {
  const fleet = await fleetRow(transaction, fleetId);
  const { start, end } = weekRange(week);
  if (now < end)
    throw new ApiError(
      409,
      'Diese Woche läuft noch. Der Zahlungseingang kann erst nach Sonntag 24:00 Uhr vermerkt werden.',
    );
  const current = await settlementFor(transaction, fleet, week, now);
  if (current.status === 'paid') return current;
  await transaction
    .prepare(
      `INSERT INTO mobility_settlements(fleet_id,week,start_at,end_at,status,paid_at,paid_by,snapshot,updated_at) VALUES(?,?,?,?,'paid',?,?,?,?)
       ON CONFLICT(fleet_id,week) DO UPDATE SET status='paid',paid_at=excluded.paid_at,paid_by=excluded.paid_by,snapshot=excluded.snapshot,updated_at=excluded.updated_at`,
    )
    .bind(
      fleetId,
      week,
      start,
      end,
      now,
      actorId,
      JSON.stringify(current.statement),
      now,
    )
    .run();
  return {
    statement: current.statement,
    status: 'paid' as const,
    paidAt: now,
    closed: true,
  };
}
export async function reopenSettlement(
  transaction: SqlDatabase,
  fleetId: string,
  week: string,
  now = Date.now(),
) {
  await transaction
    .prepare(
      "UPDATE mobility_settlements SET status='open',paid_at=NULL,paid_by=NULL,snapshot=NULL,updated_at=? WHERE fleet_id=? AND week=? AND status='paid'",
    )
    .bind(now, fleetId, week)
    .run();
}
export type WeekSummary = Totals & {
  week: string;
  start: number;
  end: number;
  status: 'open' | 'paid';
  paidAt: number | null;
  closed: boolean;
};
/** Recent weeks and months of one fleet plus the fee that is still open. */
export async function fleetIncome(
  database: SqlDatabase,
  fleetId: string,
  now = Date.now(),
  weekCount = 12,
  monthCount = 6,
) {
  const fleet = await fleetRow(database, fleetId);
  const currentWeek = berlinWeek(now);
  const weeks = Array.from({ length: weekCount }, (_, i) =>
    addDays(currentWeek, -7 * i),
  );
  const months: string[] = [];
  let month = berlinMonth(now);
  for (let i = 0; i < monthCount; i++) {
    months.push(month);
    month = berlinMonth(monthStart(month) - 86400000);
  }
  const since = Math.min(
    weekRange(weeks[weeks.length - 1]).start,
    monthStart(months[months.length - 1]),
  );
  const rows = await database
    .prepare(TRIP_SQL)
    .bind(fleetId, since, now + 1)
    .all<TripRow>();
  const paid = await database
    .prepare(
      "SELECT week,paid_at,snapshot FROM mobility_settlements WHERE fleet_id=? AND status='paid'",
    )
    .bind(fleetId)
    .all<{ week: string; paid_at: number; snapshot: string | null }>();
  const frozen = new Map(paid.results.map((r) => [r.week, r]));
  const weekTotals = new Map(weeks.map((w) => [w, empty()]));
  const monthTotals = new Map(months.map((m) => [m, empty()]));
  for (const row of rows.results) {
    const ride = trip(row);
    const w = weekTotals.get(berlinWeek(ride.paidAt));
    if (w) add(w, ride.fare, ride.fee, ride.method);
    const m = monthTotals.get(berlinMonth(ride.paidAt));
    if (m) add(m, ride.fare, ride.fee, ride.method);
  }
  const weekList: WeekSummary[] = weeks.map((week) => {
    const range = weekRange(week);
    const snap = frozen.get(week);
    const statement = snap?.snapshot
      ? (JSON.parse(snap.snapshot) as Statement)
      : null;
    const totals = statement
      ? {
          trips: statement.trips,
          revenue: statement.revenue,
          fee: statement.fee,
          net: statement.net,
          cash: statement.cash,
          terminal: statement.terminal,
        }
      : weekTotals.get(week)!;
    return {
      ...totals,
      week,
      ...range,
      status: statement ? 'paid' : 'open',
      paidAt: statement ? Number(snap!.paid_at) : null,
      closed: now >= range.end,
    };
  });
  // Fee of finished, not yet settled weeks; the running week is shown apart.
  const currentStart = weekRange(currentWeek).start;
  const open = await database
    .prepare(
      `SELECT COALESCE(SUM(${FEE_SQL}),0) AS fee FROM mobility_bookings b WHERE b.fleet_id=? AND ${SETTLED} AND b.paid_at<?
       AND NOT EXISTS(SELECT 1 FROM mobility_settlements s WHERE s.fleet_id=b.fleet_id AND s.status='paid' AND b.paid_at>=s.start_at AND b.paid_at<s.end_at)`,
    )
    .bind(fleetId, currentStart)
    .first<{ fee: number }>();
  return {
    fleet,
    weeks: weekList,
    months: months.map((m) => ({ month: m, ...monthTotals.get(m)! })),
    openFee: Number(open?.fee || 0),
    currentFee: weekList[0].status === 'paid' ? 0 : weekList[0].fee,
    rateBps: SERVICE_FEE_BPS,
  };
}
const SERVICE_NAMES: Record<string, string> = {
  premium: 'Business Class',
  electric: 'Electric Class',
  van: 'First Class Van',
  first: 'First Class',
};
export const serviceName = (id: string) => SERVICE_NAMES[id] || id;
export const methodName = (method: string) =>
  method === 'terminal' ? 'Terminal' : 'Bar';
const euro = (cents: number) => (cents / 100).toFixed(2).replace('.', ',');
// Spreadsheet programs must never read a cell as a formula.
const cell = (value: string | number) => {
  let v = String(value);
  if (/^[=+\-@\t\r]/.test(v)) v = "'" + v;
  return /[";\n\r]/.test(v) ? '"' + v.replaceAll('"', '""') + '"' : v;
};
const stamp = (at: number) => {
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat('de-DE', {
      timeZone: 'Europe/Berlin',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hourCycle: 'h23',
    })
      .formatToParts(at)
      .map((p) => [p.type, p.value]),
  );
  return {
    date: `${parts.day}.${parts.month}.${parts.year}`,
    time: `${parts.hour}:${parts.minute}`,
  };
};
/** One week as CSV (semicolon, comma decimals, UTF-8 with BOM for Excel). */
export function statementCsv(settlement: Settlement) {
  const s = settlement.statement;
  const lines: (string | number)[][] = [
    [SETTLEMENT_NOTICE],
    ['Flotte', s.fleetName],
    [
      'Woche',
      `${stamp(s.start).date} bis ${stamp(s.end - 1).date} (Montag bis Sonntag, Europe/Berlin)`,
    ],
    [
      'Status',
      settlement.status === 'paid'
        ? 'bezahlt am ' + stamp(settlement.paidAt!).date
        : 'offen',
    ],
    [],
    [
      'Datum',
      'Uhrzeit',
      'Fahrer',
      'Klasse',
      'Von',
      'Nach',
      'Fahrpreis EUR',
      'Zahlart',
      'Servicepauschale 15 % EUR',
    ],
  ];
  for (const driver of s.drivers)
    for (const ride of driver.rides) {
      const at = stamp(ride.completedAt);
      lines.push([
        at.date,
        at.time,
        ride.driverName,
        serviceName(ride.service),
        ride.from,
        ride.to,
        euro(ride.fare),
        methodName(ride.method),
        euro(ride.fee),
      ]);
    }
  lines.push(
    [],
    ['Fahrten', s.trips],
    ['Umsatz EUR', euro(s.revenue)],
    ['davon bar EUR', euro(s.cash)],
    ['davon Terminal EUR', euro(s.terminal)],
    ['Servicepauschale 15 % EUR', euro(s.fee)],
    ['Rest für die Flotte EUR', euro(s.net)],
  );
  return (
    '﻿' + lines.map((line) => line.map(cell).join(';')).join('\r\n') + '\r\n'
  );
}
export type EarningsTotals = {
  trips: number;
  total: number;
  cash: number;
  terminal: number;
  open: number;
};
/** A driver's own completed trips only; no statement about pay or share. */
export async function driverEarnings(
  database: SqlDatabase,
  driverId: string,
  now = Date.now(),
) {
  const today = berlinDayStart(now),
    week = weekRange(berlinWeek(now)).start,
    month = monthStart(berlinMonth(now));
  const since = Math.min(week, month);
  const rows = await database
    .prepare(
      `SELECT id,completed_at,service,route,price,fare_price,payment_status,payment_method FROM mobility_bookings
       WHERE driver_id=? AND status='completed' AND completed_at>=? ORDER BY completed_at DESC LIMIT 1000`,
    )
    .bind(driverId, since)
    .all<{
      id: string;
      completed_at: number;
      service: string;
      route: string;
      price: number;
      fare_price: number | null;
      payment_status: string;
      payment_method: string | null;
    }>();
  const totals = (): EarningsTotals => ({
    trips: 0,
    total: 0,
    cash: 0,
    terminal: 0,
    open: 0,
  });
  const periods = { today: totals(), week: totals(), month: totals() };
  const rides = rows.results.map((row) => {
    let from = '',
      to = '';
    try {
      const route = JSON.parse(row.route);
      from = short(route.pickup?.label);
      to = short(route.destination?.label);
    } catch {}
    const paid = row.payment_status === 'paid';
    const ride = {
      id: row.id,
      completedAt: Number(row.completed_at),
      service: row.service,
      from,
      to,
      price: Number(row.price),
      extras:
        row.fare_price != null && row.price > row.fare_price
          ? Number(row.price) - Number(row.fare_price)
          : 0,
      method: paid
        ? row.payment_method === 'terminal'
          ? ('terminal' as const)
          : ('cash' as const)
        : null,
    };
    for (const [key, start] of [
      ['today', today],
      ['week', week],
      ['month', month],
    ] as const) {
      if (ride.completedAt < start) continue;
      const t = periods[key];
      t.trips += 1;
      t.total += ride.price;
      if (ride.method === 'cash') t.cash += ride.price;
      else if (ride.method === 'terminal') t.terminal += ride.price;
      else t.open += ride.price;
    }
    return ride;
  });
  return {
    periods,
    since: { today, week, month },
    rides,
    serverTime: now,
  };
}
