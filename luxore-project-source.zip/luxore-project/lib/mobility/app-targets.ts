/**
 * Screens a native session may be handed over to. Fixed paths only; the one
 * target with parameters is rebuilt from validated values, so nothing the
 * caller sends is ever copied into the redirect.
 */
const screens = ['/mobile/customer', '/mobile/driver', '/disposition', '/betreiber'];

export const REVIEW_PATH = '/pruefung';
export const REVIEW_AREAS = ['papiere', 'kontrolle'] as const;
export type ReviewArea = (typeof REVIEW_AREAS)[number];
// Record ids look like "vehicle:3f0c…"; nothing that could leave the query.
const idPattern = /^[A-Za-z0-9_:.-]{1,80}$/;

export type ReviewQuery = {
  bereich: ReviewArea | null;
  fahrzeug: string | null;
  fahrer: string | null;
};
/** Reads the three known parameters; anything else makes the query invalid. */
export function reviewQuery(query: string): ReviewQuery | null {
  const result: ReviewQuery = { bereich: null, fahrzeug: null, fahrer: null };
  if (!query) return result;
  // Only plain "name=value" pairs: no encoding, no fragments, no repeats.
  if (!/^[A-Za-z0-9_:.=&-]{1,260}$/.test(query)) return null;
  for (const pair of query.split('&')) {
    const [name, value, ...rest] = pair.split('=');
    if (rest.length || !value) return null;
    if (name === 'bereich') {
      if (result.bereich || !REVIEW_AREAS.includes(value as ReviewArea)) return null;
      result.bereich = value as ReviewArea;
    } else if (name === 'fahrzeug' || name === 'fahrer') {
      if (result[name] || !idPattern.test(value)) return null;
      result[name] = value;
    } else return null;
  }
  return result;
}
export function reviewPath(query: Partial<ReviewQuery> = {}) {
  const parts = (['bereich', 'fahrzeug', 'fahrer'] as const)
    .filter((name) => query[name])
    .map((name) => name + '=' + query[name]);
  return REVIEW_PATH + (parts.length ? '?' + parts.join('&') : '');
}
/** The canonical same-site path for an allowed target, otherwise null. */
export function appSessionTarget(target: unknown): string | null {
  if (typeof target !== 'string') return null;
  if (screens.includes(target)) return target;
  if (target === REVIEW_PATH) return target;
  if (!target.startsWith(REVIEW_PATH + '?')) return null;
  const text = target.slice(REVIEW_PATH.length + 1);
  const query = text ? reviewQuery(text) : null;
  return query ? reviewPath(query) : null;
}
