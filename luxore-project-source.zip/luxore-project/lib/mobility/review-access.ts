import { settings } from './server';
import { accountsConfigured } from '@/db/sqlite';
/**
 * Store reviewers (Google Play, App Store) must be able to sign in without a
 * mailbox of ours. For the few addresses named in LUXORE_REVIEW_EMAILS the
 * sign-in code is the fixed LUXORE_REVIEW_CODE; no mail is sent for them.
 *
 * Off unless both settings are present and valid. Everything else of the
 * sign-in stays as it is: five tries per code, one code a minute, eight codes
 * a day per address. Never for the operator's address.
 */
const MAX_REVIEW_ADDRESSES = 6;
const weak = (code: string) =>
  /^(\d)\1{5}$/.test(code) ||
  '0123456789012345'.includes(code) ||
  '9876543210987654'.includes(code);
function configured() {
  if (!accountsConfigured()) return null;
  const config = settings();
  const code = config.LUXORE_REVIEW_CODE?.trim() || '';
  if (!/^\d{6}$/.test(code) || weak(code)) return null;
  const admin = config.LUXORE_ADMIN_EMAIL?.trim().toLowerCase();
  const addresses = (config.LUXORE_REVIEW_EMAILS || '')
    .split(',')
    .map((v) => v.trim().toLowerCase())
    .filter((v) => v && v !== admin);
  if (!addresses.length || addresses.length > MAX_REVIEW_ADDRESSES)
    return null;
  return { code, addresses };
}
/** True when at least one reviewer address can sign in without mail. */
export const reviewAccessReady = () => configured() !== null;
/** The fixed code for this (already normalised) address, or null. */
export function reviewCode(email: string): string | null {
  const access = configured();
  return access && access.addresses.includes(email) ? access.code : null;
}
