import type { AppUser } from '@/lib/identity';
import type { SqlDatabase } from '@/db/sqlite';
import { ApiError, db, isAdmin } from './server';
import { audit } from './accounts';
import { operatorScope } from './fleets';
import { driverIdle } from './vehicles';
async function activeActor(user: AppUser, transaction: SqlDatabase) {
  if (
    await transaction
      .prepare(
        "SELECT id FROM mobility_accounts WHERE id=? AND status<>'active'",
      )
      .bind(user.userId)
      .first()
  )
    throw new ApiError(
      403,
      'Dein Konto ist nicht aktiv. Bitte erneut anmelden.',
    );
}
export async function changeDeputy(
  user: AppUser,
  fleetId: string,
  deputyId: string | null,
) {
  await db().writeTransaction(async (transaction) => {
    const scope = await operatorScope(user, () => transaction);
    if (!scope) throw new ApiError(403, 'Nur die Flottenleitung hat Zugriff.');
    await activeActor(user, transaction);
    const fleet = await transaction
      .prepare('SELECT owner_id,deputy_id FROM mobility_fleets WHERE id=?')
      .bind(fleetId)
      .first<{ owner_id: string; deputy_id: string | null }>();
    if (!fleet || (!isAdmin(user) && fleet.owner_id !== user.userId))
      throw new ApiError(
        403,
        'Nur der Flottenbesitzer darf die Stellvertretung bestimmen.',
      );
    if (
      deputyId &&
      (deputyId === fleet.owner_id ||
        !(await transaction
          .prepare(
            'SELECT user_id FROM mobility_employees WHERE user_id=? AND fleet_id=?',
          )
          .bind(deputyId, fleetId)
          .first()))
    )
      throw new ApiError(
        400,
        'Bitte einen anderen Mitarbeiter dieser Flotte auswählen.',
      );
    if (
      deputyId &&
      (await transaction
        .prepare(
          "SELECT id FROM mobility_accounts WHERE id=? AND status<>'active'",
        )
        .bind(deputyId)
        .first())
    )
      throw new ApiError(409, 'Dieses Konto ist gesperrt oder wird gelöscht.');
    // Repeating the same selection must not create a second audit entry.
    if (fleet.deputy_id === deputyId) return;
    const changed = await transaction
      .prepare(`UPDATE mobility_fleets SET deputy_id=? WHERE id=? AND (owner_id=? OR ?=1)
      AND (? IS NULL OR (owner_id<>? AND EXISTS(SELECT 1 FROM mobility_employees WHERE user_id=? AND fleet_id=mobility_fleets.id)
      AND NOT EXISTS(SELECT 1 FROM mobility_accounts WHERE id=? AND status<>'active')))`)
      .bind(
        deputyId,
        fleetId,
        user.userId,
        Number(isAdmin(user)),
        deputyId,
        deputyId,
        deputyId,
        deputyId,
      )
      .run();
    if (!changed.meta.changes)
      throw new ApiError(
        409,
        'Die Mitarbeiterzuordnung hat sich geändert. Bitte neu laden.',
      );
    await audit(
      user.userId,
      fleetId,
      deputyId ? 'fleet.deputy_changed' : 'fleet.deputy_removed',
      () => transaction,
    );
  });
}
export async function transferFleetOwner(
  user: AppUser,
  fleetId: string,
  previous: string,
  next: string,
) {
  await db().writeTransaction(async (transaction) => {
    if (!isAdmin(user))
      throw new ApiError(
        403,
        'Flotten und Zuordnungen verwaltet der Plattformbetreiber.',
      );
    await activeActor(user, transaction);
    const changed = await transaction
      .prepare(`UPDATE mobility_fleets SET owner_id=?,deputy_id=CASE WHEN deputy_id=? THEN NULL ELSE deputy_id END
        WHERE id=? AND owner_id=? AND EXISTS(SELECT 1 FROM mobility_employees e JOIN mobility_drivers d ON d.id=e.user_id WHERE e.user_id=? AND e.fleet_id=mobility_fleets.id AND d.approved=1 AND ${driverIdle('d')})
        AND NOT EXISTS(SELECT 1 FROM mobility_drivers d WHERE d.id=mobility_fleets.owner_id AND NOT (${driverIdle('d')}))
        AND NOT EXISTS(SELECT 1 FROM mobility_accounts a WHERE a.id=? AND a.status<>'active')
        AND NOT EXISTS(SELECT 1 FROM mobility_fleets other WHERE other.owner_id=? AND other.id<>mobility_fleets.id) RETURNING id`)
      .bind(next, next, fleetId, previous, next, next, next)
      .first();
    if (!changed)
      throw new ApiError(
        409,
        'Übergabe nicht möglich: Besitzer geändert, Ziel gehört nicht zur Flotte, ist nicht freigegeben oder noch im Einsatz. Beide Fahrer müssen offline und fertig abgerechnet sein.',
      );
    await audit(
      user.userId,
      fleetId,
      'fleet.owner_transferred',
      () => transaction,
    );
  });
}
