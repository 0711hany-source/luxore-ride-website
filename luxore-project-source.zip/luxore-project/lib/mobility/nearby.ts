import { distance, type Driver, type Point } from './domain.ts';
import { DRIVER_SEARCH_RADIUS_METERS } from './driver-search.ts';
export function nearestDrivers(
  drivers: Driver[],
  pickup: Pick<Point, 'lat' | 'lng'>,
) {
  return (
    drivers
      .filter((d) => d.lat !== null && d.lng !== null)
      .map((d) => ({
        d,
        metres: distance(pickup, { lat: d.lat!, lng: d.lng! }),
      }))
      .filter((x) => x.metres <= DRIVER_SEARCH_RADIUS_METERS)
      .sort((a, b) => a.metres - b.metres || a.d.id.localeCompare(b.d.id))
      .slice(0, 3)
      // About 200–330 m grid: never disclose identities or exact positions before assignment.
      .map(({ d }) => ({
        lat: Math.round(d.lat! / 0.003) * 0.003,
        lng: Math.round(d.lng! / 0.003) * 0.003,
      }))
  );
}
