import { db, isAdmin } from './server';
import type { AppUser } from '@/lib/identity';
export async function operatorScope(user: AppUser): Promise<string | null> {
  if (isAdmin(user)) return 'all';
  const row = await db()
    .prepare(
      'SELECT f.id FROM mobility_fleets f JOIN mobility_employees e ON e.fleet_id=f.id AND e.user_id=? WHERE f.owner_id=? OR f.deputy_id=?',
    )
    .bind(user.userId, user.userId, user.userId)
    .first<{ id: string }>();
  return row?.id || null;
}
