// SQL aliases are internal constants, never request input.
export function vehicleEligible(alias: string) {
  return `EXISTS(SELECT 1 FROM mobility_vehicles v JOIN mobility_employees e ON e.fleet_id=v.fleet_id JOIN mobility_fleets f ON f.id=v.fleet_id WHERE e.user_id=${alias}.id AND v.id=${alias}.vehicle_id AND v.status='active')`;
}
export function driverIdle(alias: string) {
  return `${alias}.online=0 AND ${alias}.session_id IS NULL AND NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.driver_id=${alias}.id AND (b.status IN ('accepted','arrived','riding') OR (b.status='completed' AND b.completed_at IS NOT NULL AND b.payment_status='unpaid')))`;
}
