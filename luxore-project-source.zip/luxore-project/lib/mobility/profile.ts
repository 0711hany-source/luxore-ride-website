import type { SqlDatabase } from '@/db/sqlite';
import { driverPublicRating, type RatingSummary } from './ratings';
import { RATING_WINDOW_MS } from './rating-rules';

/** Photo slot and owner type of a driver's profile picture in mobility_images. */
export const PROFILE_OWNER = 'driver';
export const PROFILE_SLOT = 'profile';
export const PROFILE_MISSING = 'Profilbild fehlt';

export async function profilePhotoId(database: SqlDatabase, driverId: string) {
  const row = await database
    .prepare(
      'SELECT id FROM mobility_images WHERE owner_type=? AND owner_id=? AND slot=? ORDER BY created_at DESC LIMIT 1',
    )
    .bind(PROFILE_OWNER, driverId, PROFILE_SLOT)
    .first<{ id: string }>();
  return row?.id || null;
}
export type DriverCard = {
  photo_id: string | null;
  /** null means fewer than three ratings: shown as "Neu". */
  rating: RatingSummary | null;
};
/** What a customer may see next to the driver's name. */
export async function driverCard(
  database: SqlDatabase,
  driverId: string,
): Promise<DriverCard> {
  // Before migration 0021 there is no ratings table; the ride view must
  // still load, so a failure here means "nothing to show".
  const [photo_id, rating] = await Promise.all([
    profilePhotoId(database, driverId).catch(() => null),
    driverPublicRating(database, driverId).catch(() => null),
  ]);
  return { photo_id, rating };
}
/**
 * May this customer see the driver's picture? Only through an own ride or
 * reservation that is assigned to this driver — never by guessing an address.
 */
export async function customerMaySeeDriver(
  database: SqlDatabase,
  customerId: string,
  driverId: string,
  now = Date.now(),
) {
  const row = await database
    .prepare(
      `SELECT 1 AS ok FROM mobility_bookings WHERE owner_id=? AND (
        (driver_id=? AND (status IN ('accepted','arrived','riding') OR (status='completed' AND completed_at>=?)))
        OR (assigned_driver_id=? AND status='reserved')) LIMIT 1`,
    )
    .bind(customerId, driverId, now - RATING_WINDOW_MS, driverId)
    .first();
  return !!row;
}
