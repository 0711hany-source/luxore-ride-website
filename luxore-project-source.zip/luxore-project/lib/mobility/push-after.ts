import { db } from './server';
import { pushConfig, wakeOfflineDrivers } from './push';
/**
 * Schedules the "please go online" push for after the response has been sent
 * (`after()` from next/server), so a booking is never delayed or failed by it.
 * Without Firebase configuration nothing is loaded or scheduled at all.
 */
export async function wakeDriversAfterResponse() {
  if (!pushConfig()) return;
  try {
    const { after } = await import('next/server');
    after(async () => {
      await wakeOfflineDrivers(db()).catch(() => {});
    });
  } catch {
    // Outside a request scope (tests, scripts) there is nothing to schedule.
  }
}
