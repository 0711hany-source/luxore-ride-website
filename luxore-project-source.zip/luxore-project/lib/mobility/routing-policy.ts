import type { RouteData } from './domain';
export type TrafficRoute = {
  distance: number;
  duration: number;
  duration_typical?: number;
  geometry: RouteData['geometry'];
  legs?: {
    steps?: unknown[];
    notifications?: { type?: string; subtype?: string }[];
  }[];
};
export function routingParameters(
  scheduledAt: number | null,
  course: number | null = null,
  navigation = false,
): Record<string, string> {
  return {
    ...(course !== null &&
    Number.isFinite(course) &&
    course >= 0 &&
    course < 360
      ? { bearings: `${Math.round(course) % 360},60;` }
      : {}),
    geometries: 'geojson',
    overview: 'full',
    alternatives: 'true',
    steps: String(navigation),
    ...(navigation ? { roundabout_exits: 'true' } : {}),
    language: 'de',
    exclude: 'unpaved',
    // No main-road preference or exclusion of legal residential streets.
    depart_at: scheduledAt ? new Date(scheduledAt).toISOString() : 'now',
  };
}
export function includesUnpaved(route: TrafficRoute) {
  return !!route.legs?.some((leg) =>
    leg.notifications?.some(
      (n) => n.type === 'violation' && n.subtype === 'unpaved',
    ),
  );
}
export function chooseTrafficRoute(
  routes: TrafficRoute[],
): TrafficRoute | null {
  const valid = routes.filter(
    (r) =>
      r &&
      Number.isFinite(r.distance) &&
      r.distance >= 1 &&
      r.distance <= 2000000 &&
      Number.isFinite(r.duration) &&
      r.duration > 0 &&
      r.geometry?.type === 'LineString' &&
      Array.isArray(r.geometry.coordinates) &&
      r.geometry.coordinates.length >= 2 &&
      r.geometry.coordinates.every(
        (c) =>
          Array.isArray(c) &&
          c.length >= 2 &&
          Number.isFinite(c[0]) &&
          Math.abs(c[0]) <= 180 &&
          Number.isFinite(c[1]) &&
          Math.abs(c[1]) <= 90,
      ),
  );
  const paved = valid.filter((r) => !includesUnpaved(r));
  const candidates = paved.length ? paved : valid;
  if (!candidates.length) return null;
  const fastest = Math.min(...candidates.map((r) => r.duration));
  // Prefer fewer kilometres only when arrival differs by <= 30 s AND <= 5%.
  return candidates
    .filter((r) => r.duration <= fastest + Math.min(30, fastest * 0.05))
    .sort((a, b) => a.distance - b.distance || a.duration - b.duration)[0];
}
