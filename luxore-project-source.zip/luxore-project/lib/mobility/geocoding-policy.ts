import type { Point } from './domain';
import { distance } from './domain.ts';
export type GeocodeQuery = string | { lat: number; lng: number };
export function geocodeKey(query: GeocodeQuery) {
  return typeof query === 'string'
    ? 'forward-global:' +
        query
          .trim()
          .normalize('NFC')
          .toLocaleLowerCase('de-DE')
          .replace(/\s+/g, ' ')
    : `reverse:${query.lat.toFixed(6)},${query.lng.toFixed(6)}`;
}
export function selectedGeocode(
  results: Omit<Point, 'id'>[],
  selected: { lat: number; lng: number },
) {
  return (
    results
      .filter((p) => distance(p, selected) <= 25)
      .sort((a, b) => distance(a, selected) - distance(b, selected))[0] || null
  );
}
export function permanentDailyLimit(value: unknown) {
  const n = typeof value === 'string' && value.trim() ? Number(value) : NaN;
  return Number.isInteger(n) && n >= 0 && n <= 10000 ? n : 0;
}
