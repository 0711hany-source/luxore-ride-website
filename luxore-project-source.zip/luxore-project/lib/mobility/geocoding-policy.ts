import type { Point } from "./domain";
import { distance } from "./domain.ts";
export type GeocodeQuery = string | { lat: number; lng: number };
/** Soft ranking hint only (never a filter); rounded so cache keys stay few. */
export type GeocodeNear = { lat: number; lng: number };
export function roundedNear(near: unknown): GeocodeNear | undefined {
  if (!near || typeof near !== "object") return undefined;
  const { lat, lng } = near as Record<string, unknown>;
  if (
    typeof lat !== "number" ||
    typeof lng !== "number" ||
    !Number.isFinite(lat) ||
    !Number.isFinite(lng) ||
    Math.abs(lat) > 90 ||
    Math.abs(lng) > 180
  )
    return undefined;
  return { lat: Math.round(lat * 100) / 100, lng: Math.round(lng * 100) / 100 };
}
/**
 * Stable partition: European hits first, all others kept after them. Nothing
 * is removed, so every country stays bookable.
 */
export function preferEurope<T extends { lat: number; lng: number }>(
  results: T[],
): T[] {
  const europe = (p: T) =>
    p.lat >= 34 && p.lat <= 72 && p.lng >= -25 && p.lng <= 45;
  return [...results.filter(europe), ...results.filter((p) => !europe(p))];
}
export function geocodeKey(query: GeocodeQuery, near?: GeocodeNear) {
  return typeof query === "string"
    ? "forward-global:" +
        query
          .trim()
          .normalize("NFC")
          .toLocaleLowerCase("de-DE")
          .replace(/\s+/g, " ") +
        (near ? `|near:${near.lat.toFixed(2)},${near.lng.toFixed(2)}` : "")
    : `reverse:${query.lat.toFixed(6)},${query.lng.toFixed(6)}`;
}
export function selectedGeocode(
  results: Omit<Point, "id">[],
  selected: { lat: number; lng: number },
) {
  return (
    results
      .filter((p) => distance(p, selected) <= 25)
      .sort((a, b) => distance(a, selected) - distance(b, selected))[0] || null
  );
}
export function permanentDailyLimit(value: unknown) {
  const n = typeof value === "string" && value.trim() ? Number(value) : NaN;
  return Number.isInteger(n) && n >= 0 && n <= 10000 ? n : 0;
}
