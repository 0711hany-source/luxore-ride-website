// The chauffeur's way to the pickup point, as last calculated for the driver
// app's navigation. Stored at the ride (`approach_route`) and shown to the
// customer while the chauffeur is on the way. No own routing request.
export type ApproachLine = { type: 'LineString'; coordinates: number[][] };
/** Older than this the stored way no longer matches where the car is. */
export const APPROACH_MAX_AGE_MS = 120000;
const MAX_POINTS = 1500;
const valid = (p: unknown): p is number[] =>
  Array.isArray(p) &&
  typeof p[0] === 'number' &&
  typeof p[1] === 'number' &&
  Math.abs(p[0]) <= 180 &&
  Math.abs(p[1]) <= 90;
/** A usable line (two or more valid points, five decimals) or null. */
export function approachLine(value: unknown): ApproachLine | null {
  const g = value as { type?: unknown; coordinates?: unknown } | null;
  if (!g || g.type !== 'LineString' || !Array.isArray(g.coordinates))
    return null;
  const coordinates: number[][] = [];
  for (const p of g.coordinates) {
    if (!valid(p)) return null;
    const point = [
      Math.round(p[0] * 1e5) / 1e5,
      Math.round(p[1] * 1e5) / 1e5,
    ];
    const last = coordinates.at(-1);
    // Identical neighbours after rounding carry no shape.
    if (!last || last[0] !== point[0] || last[1] !== point[1])
      coordinates.push(point);
  }
  if (coordinates.length < 2 || coordinates.length > MAX_POINTS) return null;
  return { type: 'LineString', coordinates };
}
/** Text for the column `approach_route`; null clears an unusable route. */
export function storedApproach(geometry: unknown, at: number): string | null {
  const line = approachLine(geometry);
  return line ? JSON.stringify({ at, geometry: line }) : null;
}
/**
 * What the customer may see: only while the chauffeur is on the way
 * (`accepted`) and only a way calculated within the last two minutes.
 */
export function customerApproach(
  row: { status?: unknown; approach_route?: unknown },
  now: number,
): ApproachLine | null {
  if (row.status !== 'accepted' || typeof row.approach_route !== 'string')
    return null;
  try {
    const stored = JSON.parse(row.approach_route) as {
      at?: unknown;
      geometry?: unknown;
    };
    if (
      typeof stored?.at !== 'number' ||
      !Number.isFinite(stored.at) ||
      stored.at > now + 5000 ||
      now - stored.at > APPROACH_MAX_AGE_MS
    )
      return null;
    return approachLine(stored.geometry);
  } catch {
    return null;
  }
}
