// An overview, not a service-area boundary. Actual coordinates stay unrestricted.
export const EUROPE_MAP_VIEW = {
  center: [10, 52] as [number, number],
  zoom: 3.5,
};
