import { readNavigationSteps } from './navigation-steps';
import { ApiError, settings } from './server';
import { coordinate, type Point, type RouteData } from './domain';
import {
  chooseTrafficRoute,
  includesUnpaved,
  routingParameters,
  type TrafficRoute,
} from './routing-policy';
async function provider(path: string, params: Record<string, string>) {
  const token = settings().MAPBOX_ACCESS_TOKEN;
  if (!token)
    throw new ApiError(
      503,
      'Der Kartendienst ist noch nicht aktiviert. Freie Adressen und Streckenpreise benötigen das Kartenkonto.',
    );
  const url = new URL(path, 'https://api.mapbox.com');
  for (const [key, value] of Object.entries({ ...params, access_token: token }))
    url.searchParams.set(key, value);
  let response: Response;
  try {
    response = await fetch(url, { signal: AbortSignal.timeout(12000) });
  } catch {
    throw new ApiError(
      502,
      'Der Kartendienst antwortet gerade nicht. Bitte erneut versuchen.',
    );
  }
  if (!response.ok)
    throw new ApiError(
      502,
      'Der Kartendienst ist nicht verfügbar. Bitte die Kartenkonfiguration prüfen.',
    );
  return response.json() as Promise<Record<string, unknown>>;
}
export async function geocode(
  query: string | { lat: number; lng: number },
  permanent = false,
): Promise<Omit<Point, 'id'>[]> {
  const data = await provider(
    '/search/geocode/v6/' + (typeof query === 'string' ? 'forward' : 'reverse'),
    {
      ...(typeof query === 'string'
        ? {
            q: query,
            autocomplete: 'false',
            limit: '5',
            proximity: '8.6821,50.1109',
          }
        : { latitude: String(query.lat), longitude: String(query.lng) }),
      language: 'de',
      permanent: String(permanent),
    },
  );
  const features = data.features as {
    properties?: {
      full_address?: string;
      name?: string;
      place_formatted?: string;
    };
    geometry?: { coordinates?: number[] };
  }[];
  if (!Array.isArray(features))
    throw new ApiError(502, 'Adresssuche konnte nicht ausgewertet werden.');
  return features.flatMap((f) => {
    const c = f.geometry?.coordinates;
    const p = f.properties;
    if (!c || !coordinate(c[1], c[0]) || !p) return [];
    return [
      {
        label:
          p.full_address ||
          [p.name, p.place_formatted].filter(Boolean).join(', '),
        lat: c[1],
        lng: c[0],
      },
    ];
  });
}
export async function route(
  pickup: Point,
  destination: Point,
  scheduledAt: number | null,
  course: number | null = null,
  navigation = false,
): Promise<RouteData> {
  const params = routingParameters(scheduledAt, course, navigation);
  const data = await provider(
    `/directions/v5/mapbox/driving-traffic/${pickup.lng},${pickup.lat};${destination.lng},${destination.lat}`,
    params,
  );
  const r =
    data.code === 'Ok' && Array.isArray(data.routes)
      ? chooseTrafficRoute(data.routes as TrafficRoute[])
      : null;
  if (!r)
    throw new ApiError(
      422,
      'Für diese Orte wurde keine befahrbare Route gefunden.',
    );
  return {
    pickup,
    destination,
    distanceMeters: Math.round(r.distance),
    durationSeconds: Math.round(r.duration),
    geometry: r.geometry,
    ...(navigation ? { navigation: readNavigationSteps(r.legs) } : {}),
    traffic: {
      typicalSeconds: Number.isFinite(r.duration_typical)
        ? Math.round(r.duration_typical!)
        : null,
      unpaved: includesUnpaved(r),
    },
    calculatedAt: Date.now(),
  };
}
