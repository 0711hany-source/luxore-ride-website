import { headers } from 'next/headers';
import { env } from 'cloudflare:workers';
import { getChatGPTUser, type ChatGPTUser } from '@/app/chatgpt-auth';
import { accountUser } from './accounts';
export type Settings = {
  MAPBOX_ACCESS_TOKEN?: string;
  MAPBOX_PUBLIC_TOKEN?: string;
  MAPBOX_PERMANENT_DAILY_LIMIT?: string;
  LUXORE_ADMIN_EMAIL?: string;
  DISPATCH_SECRET?: string;
  RESEND_API_KEY?: string;
  LUXORE_MAIL_FROM?: string;
};
export const settings = () => env as typeof env & Settings;
export const db = () => env.DB;
export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}
export const json = (v: unknown, status = 200) =>
  Response.json(v, {
    status,
    headers: { 'Cache-Control': 'private, no-store' },
  });
export const sessionCookie = 'luxore_device';
export async function tokenHash(token: string) {
  const bytes = await crypto.subtle.digest(
    'SHA-256',
    new TextEncoder().encode(token),
  );
  return Array.from(new Uint8Array(bytes), (b) =>
    b.toString(16).padStart(2, '0'),
  ).join('');
}
export function checkOrigin(request: Request) {
  if (
    request.method !== 'GET' &&
    request.headers.get('origin') !== new URL(request.url).origin
  )
    throw new ApiError(403, 'Anfrageursprung nicht erlaubt.');
}
export async function deviceUser(
  requestHeaders: Headers,
): Promise<ChatGPTUser | null> {
  const token = requestHeaders
    .get('cookie')
    ?.split(';')
    .map((v) => v.trim())
    .find((v) => v.startsWith(sessionCookie + '='))
    ?.slice(sessionCookie.length + 1);
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const session = await db()
    .prepare(
      'SELECT user_id FROM mobility_sessions WHERE token_hash=? AND expires_at>?',
    )
    .bind(await tokenHash(token), Date.now())
    .first<{ user_id: string }>();
  return session
    ? {
        userId: session.user_id,
        email: '',
        displayName: 'Gast',
        fullName: null,
      }
    : null;
}
export async function identity(request?: Request) {
  if (request) checkOrigin(request);
  const h = await headers();
  const user =
    (await accountUser(h)) || (await getChatGPTUser()) || (await deviceUser(h));
  if (!user)
    throw new ApiError(
      401,
      'Die Gerätesitzung fehlt oder ist abgelaufen. Bitte die App neu öffnen.',
    );
  return user;
}
export const isAdmin = (user: ChatGPTUser) =>
  Boolean(settings().LUXORE_ADMIN_EMAIL) &&
  user.email.toLowerCase() ===
    settings().LUXORE_ADMIN_EMAIL!.trim().toLowerCase();
export async function body(request: Request) {
  if (Number(request.headers.get('content-length') || 0) > 8192)
    throw new ApiError(413, 'Anfrage zu groß.');
  let value: unknown;
  try {
    const text = await request.text();
    if (text.length > 8192) throw new ApiError(413, 'Anfrage zu groß.');
    value = JSON.parse(text);
  } catch (e) {
    if (e instanceof ApiError) throw e;
    throw new ApiError(400, 'Ungültige Anfrage.');
  }
  if (!value || typeof value !== 'object' || Array.isArray(value))
    throw new ApiError(400, 'Ungültige Anfrage.');
  return value as Record<string, unknown>;
}
export async function handled(fn: () => Promise<Response>) {
  try {
    return await fn();
  } catch (e) {
    if (e instanceof ApiError) return json({ error: e.message }, e.status);
    console.error('API Server Error:', e);
    return json(
      {
        error:
          'Die Anfrage konnte nicht verarbeitet werden. Bitte erneut versuchen.',
      },
      500,
    );
  }
}
export function text(value: unknown, max = 160) {
  if (typeof value !== 'string' || !value.trim() || value.length > max)
    throw new ApiError(400, 'Bitte alle Angaben vollständig ausfüllen.');
  return value.trim();
}
export async function limit(userId: string, scope: string, max = 30) {
  const key = `${Math.floor(Date.now() / 60000)}:${userId}:${scope}`;
  const result = await db()
    .prepare(
      'INSERT INTO mobility_limits(key,count) VALUES(?,1) ON CONFLICT(key) DO UPDATE SET count=count+1 WHERE count < ? RETURNING count',
    )
    .bind(key, max)
    .first();
  if (!result)
    throw new ApiError(
      429,
      'Zu viele Anfragen. Bitte in einer Minute erneut versuchen.',
    );
}
