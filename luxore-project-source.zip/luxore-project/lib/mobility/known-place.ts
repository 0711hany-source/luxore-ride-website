import type { SqlDatabase } from '@/db/sqlite';
import type { Point } from '@/lib/mobility/domain';

/**
 * The address behind a place id of this user. A searched address is kept for
 * 7 days (see dispatch); a "recent destination" may be older, so the point is
 * then read from the user's own stored rides. Never from another user.
 */
export async function knownPlace(
  db: SqlDatabase,
  id: string,
  ownerId: string,
): Promise<Point | null> {
  if (!id || !ownerId) return null;
  const fresh = await db
    .prepare(
      'SELECT id,label,lat,lng,attribution FROM mobility_places WHERE id=? AND owner_id=?',
    )
    .bind(id, ownerId)
    .first<Point>();
  if (fresh) return fresh;
  const past = await db
    .prepare(
      "SELECT route FROM mobility_bookings WHERE owner_id=? AND (json_extract(route,'$.destination.id')=? OR json_extract(route,'$.pickup.id')=?) ORDER BY created_at DESC LIMIT 1",
    )
    .bind(ownerId, id, id)
    .first<{ route: string }>();
  if (!past) return null;
  try {
    const r = JSON.parse(past.route) as { pickup?: Point; destination?: Point };
    const point = [r.destination, r.pickup].find((x) => x?.id === id);
    if (
      !point ||
      typeof point.label !== 'string' ||
      !point.label ||
      !Number.isFinite(point.lat) ||
      !Number.isFinite(point.lng)
    )
      return null;
    return {
      id: point.id,
      label: point.label,
      lat: point.lat,
      lng: point.lng,
      attribution: point.attribution ?? null,
    };
  } catch {
    return null;
  }
}
