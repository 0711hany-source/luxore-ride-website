export type RoadFix = {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
};
export type RoadMatch = { timestamp: number; coordinates: [number, number][] };
export function parseRoadTrace(value: unknown, now: number): RoadFix[] {
  if (!Array.isArray(value) || value.length < 3 || value.length > 12)
    throw new Error('Drei bis zwölf Standortpunkte erforderlich.');
  const trace = value.map((point: RoadFix, index) => {
    if (
      !point ||
      ![point.lat, point.lng, point.accuracy, point.timestamp].every(
        Number.isFinite,
      ) ||
      Math.abs(point.lat) > 85 ||
      Math.abs(point.lng) > 180 ||
      point.accuracy < 0 ||
      point.accuracy > 50 ||
      point.timestamp < now - 90000 ||
      point.timestamp > now + 5000 ||
      (index > 0 &&
        Math.floor(point.timestamp / 1000) <=
          Math.floor(value[index - 1].timestamp / 1000))
    )
      throw new Error('Ungültige oder veraltete Standortfolge.');
    return {
      lat: point.lat,
      lng: point.lng,
      accuracy: point.accuracy,
      timestamp: point.timestamp,
    };
  });
  if (now - trace.at(-1)!.timestamp > 15000)
    throw new Error('Aktueller Standort fehlt.');
  return trace;
}
export function readRoadMatch(
  value: unknown,
  trace: RoadFix[],
): RoadMatch | null {
  const data = value as {
    code?: string;
    tracepoints?: ({
      matchings_index: number;
      alternatives_count: number;
      location: [number, number];
    } | null)[];
    matchings?: {
      confidence: number;
      geometry?: { type: string; coordinates: [number, number][] };
    }[];
  };
  if (!data || data.code !== 'Ok' || data.tracepoints?.length !== trace.length)
    return null;
  const last = data.tracepoints.at(-1),
    previous = data.tracepoints.at(-2);
  if (
    !last ||
    !previous ||
    last.alternatives_count !== 0 ||
    previous.matchings_index !== last.matchings_index
  )
    return null;
  const matching = data.matchings?.[last.matchings_index];
  if (
    !matching ||
    !Number.isFinite(matching.confidence) ||
    matching.confidence < 0.8 ||
    matching.geometry?.type !== 'LineString'
  )
    return null;
  const coordinates = matching.geometry.coordinates;
  if (
    !Array.isArray(coordinates) ||
    coordinates.length < 2 ||
    coordinates.length > 4000 ||
    coordinates.some(
      (p) =>
        !Array.isArray(p) ||
        p.length < 2 ||
        !p.every(Number.isFinite) ||
        Math.abs(p[0]) > 180 ||
        Math.abs(p[1]) > 85,
    )
  )
    return null;
  return { timestamp: trace.at(-1)!.timestamp, coordinates };
}
