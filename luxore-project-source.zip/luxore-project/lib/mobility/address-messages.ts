/** Shared by server and client so the UI can recognise this rejection. */
export const TEXT_ADDRESS_UNAVAILABLE =
  "Neue Textadressen sind derzeit nicht verfügbar. Bitte den Punkt auf der Karte wählen. Bereits gespeicherte Adressen bleiben verfügbar.";
