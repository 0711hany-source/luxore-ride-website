import type { SqlDatabase } from '@/db/sqlite';

export const mailBudgetLimits = { day: 90, month: 2800 } as const;
function buckets(now: number) {
  return {
    day: `account-mail:${Math.floor(now / 86400000)}`,
    month: `account-mail-month:${new Date(now).toISOString().slice(0, 7)}`,
  };
}
/** Both allowances are reserved in one write transaction, including concurrent requests. */
export async function reserveMailBudget(db: SqlDatabase, now = Date.now()) {
  const keys = buckets(now);
  const result = await db.batch([
    db
      .prepare(`INSERT INTO mobility_limits(key,count)
      SELECT ?,1 WHERE COALESCE((SELECT count FROM mobility_limits WHERE key=?),0)<?
      ON CONFLICT(key) DO UPDATE SET count=count+1 WHERE count<?`)
      .bind(keys.day, keys.month, mailBudgetLimits.month, mailBudgetLimits.day),
    db
      .prepare(`INSERT INTO mobility_limits(key,count)
      SELECT ?,1 WHERE changes()>0
      ON CONFLICT(key) DO UPDATE SET count=count+1`)
      .bind(keys.month),
  ]);
  return result.every((r) => r.meta.changes === 1);
}
/** App-owned counters, not a provider invoice or global Resend usage meter. */
export async function mailBudgetStatus(db: SqlDatabase, now = Date.now()) {
  const keys = buckets(now);
  const rows = await db
    .prepare('SELECT key,count FROM mobility_limits WHERE key IN (?,?)')
    .bind(keys.day, keys.month)
    .all<{ key: string; count: number }>();
  const counts = new Map(rows.results.map((row) => [row.key, row.count]));
  const dayRemaining = Math.max(
    0,
    mailBudgetLimits.day - (counts.get(keys.day) || 0),
  );
  const monthRemaining = Math.max(
    0,
    mailBudgetLimits.month - (counts.get(keys.month) || 0),
  );
  return {
    dayLimit: mailBudgetLimits.day,
    monthLimit: mailBudgetLimits.month,
    dayRemaining,
    monthRemaining,
    available: dayRemaining > 0 && monthRemaining > 0,
  };
}
