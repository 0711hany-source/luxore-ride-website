import { menu } from './refreshments.ts';

export type StockItem = {
  count: number;
  target: number;
  minimum: number;
  slots: number;
};
export type Stock = { snackCapacity: number; items: Record<string, StockItem> };
export type StockRow = {
  vehicle_id: string;
  data: string;
  revision: number;
  operation_id: string;
};
export function defaultStock(): Stock {
  const targets: Record<string, number> = {
    water: 3,
    sparkling: 3,
    cola: 4,
    'cola-zero': 4,
    apple: 2,
    energy: 2,
  };
  return {
    snackCapacity: 8,
    items: Object.fromEntries(
      menu.map((i) => [
        i.id,
        {
          count: 0,
          target: targets[i.id] ?? 2,
          minimum: i.group === 'drink' ? 1 : 0,
          slots: i.id === 'water' || i.id === 'sparkling' ? 2 : 1,
        },
      ]),
    ),
  };
}
function integer(value: unknown, max: number) {
  if (!Number.isInteger(value) || Number(value) < 0 || Number(value) > max)
    throw new Error('Bitte gültige ganze Stückzahlen eintragen.');
  return Number(value);
}
export function stockUsage(stock: Stock, field: 'count' | 'target') {
  return menu.reduce(
    (used, item) => {
      used[item.group] +=
        stock.items[item.id][field] * stock.items[item.id].slots;
      return used;
    },
    { drink: 0, snack: 0 },
  );
}
export function validateStock(value: unknown): Stock {
  if (!value || typeof value !== 'object') throw new Error('Bestand fehlt.');
  const raw = value as Stock;
  const snackCapacity = integer(raw.snackCapacity, 30);
  if (
    snackCapacity < 1 ||
    !raw.items ||
    typeof raw.items !== 'object' ||
    Object.keys(raw.items).length !== menu.length
  )
    throw new Error('Bitte alle Bordartikel erfassen.');
  const items = Object.fromEntries(
    menu.map((item) => {
      const v = raw.items[item.id];
      if (!v) throw new Error('Bitte alle Bordartikel erfassen.');
      const count = integer(v.count, 100),
        target = integer(v.target, 100),
        minimum = integer(v.minimum, 100),
        slots = integer(v.slots, 4);
      if (slots < 1 || (target === 0 ? minimum !== 0 : minimum >= target))
        throw new Error(
          'Die Meldeschwelle muss kleiner als der Sollbestand sein. Platzbedarf: 1 bis 4.',
        );
      return [item.id, { count, target, minimum, slots }];
    }),
  );
  const stock = { snackCapacity, items };
  for (const field of ['count', 'target'] as const) {
    const used = stockUsage(stock, field);
    if (used.drink > 24 || used.snack > snackCapacity)
      throw new Error(
        `${field === 'count' ? 'Istbestand' : 'Sollbestand'} überschreitet den Stauraum: maximal 24 Kühlplätze und ${snackCapacity} Snackplätze.`,
      );
  }
  return stock;
}
export function shoppingList(stock: Stock) {
  return menu.flatMap((item) => {
    const s = stock.items[item.id],
      quantity = Math.max(0, s.target - s.count);
    return quantity
      ? [
          {
            id: item.id,
            name: item.name,
            quantity,
            urgent: s.target > 0 && s.count <= s.minimum,
          },
        ]
      : [];
  });
}
export function moveStock(
  stock: Stock,
  quantities: unknown,
  direction: 1 | -1,
): Stock {
  if (
    !quantities ||
    typeof quantities !== 'object' ||
    Array.isArray(quantities)
  )
    throw new Error('Bitte Artikel auswählen.');
  const entries = Object.entries(quantities);
  if (!entries.length || entries.length > menu.length)
    throw new Error('Bitte Artikel auswählen.');
  const next = structuredClone(stock);
  for (const [id, value] of entries) {
    if (!menu.some((i) => i.id === id))
      throw new Error('Unbekannter Bordartikel.');
    const amount = integer(value, 100);
    if (amount < 1) throw new Error('Bitte mindestens ein Stück auswählen.');
    next.items[id].count += amount * direction;
    if (next.items[id].count < 0)
      throw new Error(
        'Nicht genug Bestand. Bitte zuerst nachfüllen oder den gezählten Bestand korrigieren.',
      );
  }
  return validateStock(next);
}
