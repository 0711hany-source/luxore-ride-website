import { ApiError, db } from './server';

export async function stopDriverShift(userId: string, sessionId: string) {
  return db().writeTransaction(async (transaction) => {
    // Account identity and the route's driver read may predate a block/restart.
    // Preserve legacy identities without a local account row.
    if (
      await transaction
        .prepare(
          "SELECT id FROM mobility_accounts WHERE id=? AND status<>'active'",
        )
        .bind(userId)
        .first()
    )
      throw new ApiError(
        403,
        'Dein Konto ist nicht aktiv. Bitte erneut anmelden.',
      );
    const driver = await transaction
      .prepare(
        'SELECT approved,online,session_id FROM mobility_drivers WHERE id=?',
      )
      .bind(userId)
      .first<{ approved: number; online: number; session_id: string | null }>();
    if (!driver?.approved)
      throw new ApiError(
        403,
        'Dein Fahrerprofil muss zuerst von der Disposition freigegeben werden.',
      );
    // Native pause may already have revoked this shift. This confirms only the
    // current offline state, not a durable receipt for a particular old session.
    if (driver.session_id === null && driver.online === 0) return false;
    if (driver.session_id !== sessionId)
      throw new ApiError(
        409,
        'Die Schicht wurde inzwischen geändert. Bitte die Fahreransicht aktualisieren.',
      );
    if (
      await transaction
        .prepare(
          "SELECT id FROM mobility_bookings WHERE driver_id=? AND (status IN ('accepted','arrived','riding') OR (status='completed' AND completed_at IS NOT NULL AND payment_status='unpaid')) LIMIT 1",
        )
        .bind(userId)
        .first()
    )
      throw new ApiError(
        409,
        'Bitte die Fahrt abschließen und den offenen Betrag kassieren, bevor du die Schicht beendest.',
      );
    const changed = await transaction.batch([
      transaction
        .prepare(
          'UPDATE mobility_drivers SET online=0,session_id=NULL WHERE id=? AND session_id=? AND approved=1',
        )
        .bind(userId, sessionId),
      transaction
        .prepare(
          'DELETE FROM mobility_location_sessions WHERE driver_id=? AND session_id=?',
        )
        .bind(userId, sessionId),
      transaction
        .prepare(
          "UPDATE mobility_offers SET status='rejected' WHERE driver_id=? AND status='pending'",
        )
        .bind(userId),
    ]);
    if (changed[0].meta.changes !== 1)
      throw new ApiError(
        409,
        'Die Schicht wurde inzwischen geändert. Bitte die Fahreransicht aktualisieren.',
      );
    return true;
  });
}
