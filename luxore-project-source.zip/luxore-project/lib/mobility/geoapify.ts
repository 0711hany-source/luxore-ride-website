import { ApiError, db, settings, tokenHash } from './server';
import { coordinate, type Point } from './domain';
import { geocodeKey, type GeocodeQuery } from './geocoding-policy';

type Results = Omit<Point, 'id'>[];
/** Opt-in free-plan adapter. No paid fallback, key never reaches the browser. */
export async function geoapifyGeocode(query: GeocodeQuery): Promise<Results> {
  const token = settings().GEOAPIFY_API_KEY;
  if (!token)
    throw new ApiError(
      503,
      'Die kostenlose Adresssuche ist noch nicht eingerichtet.',
    );
  const now = Date.now();
  const key = await tokenHash('geoapify:' + geocodeKey(query));
  const cached = await db()
    .prepare(
      'SELECT payload FROM mobility_geocodes WHERE key=? AND expires_at>?',
    )
    .bind(key, now)
    .first<{ payload: string }>();
  if (cached) return JSON.parse(cached.payload) as Results;
  const claim = crypto.randomUUID();
  const acquired = await db()
    .prepare(
      'INSERT INTO mobility_geocodes(key,payload,expires_at,claim,claimed_until) VALUES(?,NULL,0,?,?) ON CONFLICT(key) DO UPDATE SET claim=excluded.claim,claimed_until=excluded.claimed_until WHERE expires_at<=? AND claimed_until<=? RETURNING key',
    )
    .bind(key, claim, now + 15000, now, now)
    .first();
  if (!acquired)
    throw new ApiError(
      409,
      'Diese Adresse wird gerade gesucht. Bitte gleich erneut versuchen.',
    );
  try {
    // Keep 500 of the Free plan's 3,000 daily credits as headroom. Use a dedicated
    // project/key; unrelated provider usage cannot be measured by this counter.
    for (const [counter, maximum] of [
      [`geoapify-day:${Math.floor(now / 86400000)}`, 2500],
      [`geoapify-second:${Math.floor(now / 1000)}`, 4],
    ] as const) {
      const allowed = await db()
        .prepare(
          'INSERT INTO mobility_limits(key,count) VALUES(?,1) ON CONFLICT(key) DO UPDATE SET count=count+1 WHERE count < ? RETURNING count',
        )
        .bind(counter, maximum)
        .first();
      if (!allowed)
        throw new ApiError(
          429,
          maximum === 2500
            ? 'Das kostenlose Adresskontingent ist heute ausgeschöpft. Bitte einen Kartenpunkt wählen.'
            : 'Die Adresssuche ist gerade ausgelastet. Bitte gleich erneut versuchen.',
        );
    }
    const url = new URL(
      typeof query === 'string'
        ? 'https://api.geoapify.com/v1/geocode/autocomplete'
        : 'https://api.geoapify.com/v1/geocode/reverse',
    );
    url.searchParams.set('apiKey', token);
    url.searchParams.set('format', 'json');
    url.searchParams.set('lang', 'de');
    url.searchParams.set('limit', '5');
    if (typeof query === 'string') {
      url.searchParams.set('text', query);
      url.searchParams.set('bias', 'proximity:8.6821,50.1109');
    } else {
      url.searchParams.set('lat', String(query.lat));
      url.searchParams.set('lon', String(query.lng));
    }
    let response: Response;
    try {
      response = await fetch(url, { signal: AbortSignal.timeout(12000) });
    } catch {
      throw new ApiError(
        502,
        'Die Adresssuche antwortet gerade nicht. Bitte erneut versuchen oder einen Kartenpunkt wählen.',
      );
    }
    if (!response.ok)
      throw new ApiError(
        response.status === 429 ? 429 : 502,
        'Die kostenlose Adresssuche ist gerade nicht verfügbar. Bitte erneut versuchen oder einen Kartenpunkt wählen.',
      );
    const data = await response.json().catch(() => {
      throw new ApiError(502, 'Adresssuche konnte nicht ausgewertet werden.');
    });
    if (!Array.isArray(data.results))
      throw new ApiError(502, 'Adresssuche konnte nicht ausgewertet werden.');
    const results: Results = data.results
      .slice(0, 5)
      .flatMap(
        (p: {
          formatted?: unknown;
          lat?: unknown;
          lon?: unknown;
          datasource?: { attribution?: unknown };
        }) => {
          if (
            !coordinate(p.lat, p.lon) ||
            typeof p.formatted !== 'string' ||
            !p.formatted.trim()
          )
            return [];
          const source =
            typeof p.datasource?.attribution === 'string'
              ? p.datasource.attribution.slice(0, 512)
              : '© OpenStreetMap contributors';
          return [
            {
              label: p.formatted.trim().slice(0, 512),
              lat: p.lat as number,
              lng: p.lon as number,
              attribution: 'Powered by Geoapify · ' + source,
            },
          ];
        },
      );
    // Open-data results may be reused; a short cache reduces typeahead credits.
    await db()
      .prepare(
        'UPDATE mobility_geocodes SET payload=?,expires_at=?,claim=NULL,claimed_until=0 WHERE key=? AND claim=?',
      )
      .bind(JSON.stringify(results), now + 5 * 60000, key, claim)
      .run();
    return results;
  } finally {
    await db()
      .prepare(
        'UPDATE mobility_geocodes SET claim=NULL,claimed_until=0 WHERE key=? AND claim=?',
      )
      .bind(key, claim)
      .run();
  }
}
