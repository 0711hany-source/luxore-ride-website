import { storedOrder } from './refreshments';
import { storedRidePreferences } from './ride-preferences';
import { db } from './server';
import type { Booking, Driver, RouteData } from './domain';
export async function hydrate(row: Record<string, unknown>): Promise<Booking> {
  const booking = {
    ...row,
    route: JSON.parse(row.route as string) as RouteData,
    driver: null,
    refreshments: storedOrder(row.refreshments),
    rider_preferences: storedRidePreferences(row.rider_preferences),
  } as Booking;
  if (!['accepted', 'arrived', 'riding'].includes(booking.status)) {
    booking.rider_phone = null;
  }
  if (booking.driver_id) {
    const driver = await db()
      .prepare(
        'SELECT id,name,phone,vehicle,plate,service,approved,online,lat,lng,accuracy,location_at FROM mobility_drivers WHERE id=?',
      )
      .bind(booking.driver_id)
      .first<Driver>();
    if (driver) {
      const active = ['accepted', 'arrived', 'riding'].includes(booking.status);
      const vehicle = booking.vehicle_snapshot
        ? (JSON.parse(booking.vehicle_snapshot) as {
            model: string;
            plate: string;
          })
        : null;
      booking.driver = {
        ...driver,
        ...(vehicle ? { vehicle: vehicle.model, plate: vehicle.plate } : {}),
        ...(!active
          ? {
              lat: null,
              lng: null,
              accuracy: null,
              location_at: null,
              phone: '',
            }
          : {}),
      };
    }
  }
  return booking;
}
