import { storedOrder } from './refreshments';
import { storedRidePreferences } from './ride-preferences';
import { db } from './server';
import {
  arrivalWindow,
  distance,
  type Booking,
  type Driver,
  type RouteData,
} from './domain';
import { driverCard } from './profile';
import { RATING_WINDOW_MS } from './rating-rules';
import { confirmedChauffeur } from './reservations';
import { availableStock, type Stock } from './inventory';
import { customerApproach } from './approach';
import { chainEta, driveSeconds, runningRide } from './chain';
/** Stock of the car that serves this ride; `null` while no car is assigned. */
export async function boardStock(row: Record<string, unknown>) {
  if (
    !['accepted', 'arrived', 'riding'].includes(String(row.status)) ||
    typeof row.vehicle_id !== 'string' ||
    !row.vehicle_id
  )
    return null;
  const stock = await db()
    .prepare('SELECT data FROM mobility_stock WHERE vehicle_id=?')
    .bind(row.vehicle_id)
    .first<{ data: string }>();
  if (!stock) return {};
  try {
    return availableStock(JSON.parse(stock.data) as Stock);
  } catch {
    return {};
  }
}
export async function hydrate(row: Record<string, unknown>): Promise<Booking> {
  const booking = {
    ...row,
    route: JSON.parse(row.route as string) as RouteData,
    driver: null,
    refreshments: storedOrder(row.refreshments),
    rider_preferences: storedRidePreferences(row.rider_preferences),
  } as Booking;
  // The stored way of the chauffeur never leaves the server in raw form; the
  // customer's view adds `approach` (see hydrateForCustomer).
  delete (booking as { approach_route?: unknown }).approach_route;
  // An unconfirmed price offer is answered to the customer directly and is
  // nobody else's business.
  delete booking.route.pendingDestination;
  booking.approach = null;
  // Decision of the operator (15.11.2026): the driver gets the customer's
  // phone number only once he has marked "angekommen" – not on acceptance and
  // never for a reservation he has merely taken over.
  if (!['arrived', 'riding'].includes(booking.status)) {
    booking.rider_phone = null;
  }
  // The guest may only order what the assigned car really carries.
  booking.board_stock = await boardStock(row);
  // A reservation a driver has taken over: the customer sees who is coming
  // (name, vehicle, picture, rating) — never the phone before the ride.
  booking.chauffeur =
    booking.status === 'reserved' && booking.assigned_driver_id
      ? await confirmedChauffeur(
          db(),
          booking.assigned_driver_id,
          booking.assigned_vehicle_id ?? null,
        ).catch(() => null)
      : null;
  if (booking.driver_id) {
    const driver = await db()
      .prepare(
        'SELECT id,name,phone,vehicle,plate,service,approved,online,lat,lng,accuracy,location_at FROM mobility_drivers WHERE id=?',
      )
      .bind(booking.driver_id)
      .first<Driver>();
    if (driver) {
      const active = ['accepted', 'arrived', 'riding'].includes(booking.status);
      const vehicle = booking.vehicle_snapshot
        ? (JSON.parse(booking.vehicle_snapshot) as {
            model: string;
            plate: string;
          })
        : null;
      // Picture and rating only while they matter; history lists stay lean.
      const card =
        active ||
        (booking.status === 'completed' &&
          (booking.completed_at || 0) > Date.now() - RATING_WINDOW_MS)
          ? await driverCard(db(), driver.id)
          : null;
      booking.driver = {
        ...driver,
        ...card,
        ...(vehicle ? { vehicle: vehicle.model, plate: vehicle.plate } : {}),
        ...(!active
          ? {
              lat: null,
              lng: null,
              accuracy: null,
              location_at: null,
              phone: '',
            }
          : {}),
      };
    }
  }
  // Follow-up ride: the chauffeur still drives another guest. The waiting
  // customer gets the arrival time, not the position of somebody else's ride.
  const running =
    booking.status === 'accepted' && booking.driver_id
      ? await runningRide(db(), booking.driver_id).catch(() => null)
      : null;
  if (running && running.id !== booking.id) {
    const car =
      booking.driver &&
      typeof booking.driver.lat === 'number' &&
      typeof booking.driver.lng === 'number'
        ? { lat: booking.driver.lat, lng: booking.driver.lng }
        : null;
    booking.queue = {
      etaSeconds: chainEta(running.route, booking.route, car, Date.now()),
    };
    booking.eta = arrivalWindow(booking.queue.etaSeconds);
    booking.approach = null;
    if (booking.driver)
      booking.driver = {
        ...booking.driver,
        lat: null,
        lng: null,
        accuracy: null,
        location_at: null,
      };
  } else {
    booking.queue = null;
    // On the way: a span from the distance, no routing request.
    booking.eta =
      booking.status === 'accepted' &&
      typeof booking.driver?.lat === 'number' &&
      typeof booking.driver?.lng === 'number'
        ? arrivalWindow(
            driveSeconds(
              distance(booking.route.pickup, {
                lat: booking.driver.lat,
                lng: booking.driver.lng,
              }),
            ),
          )
        : null;
  }
  // Internal ids of the reservation board stay on the server; the customer
  // gets `chauffeur`, staff gets the reservation views.
  delete booking.assigned_driver_id;
  delete booking.assigned_fleet_id;
  delete booking.assigned_vehicle_id;
  delete booking.assigned_at;
  return booking;
}
/**
 * The customer's own rides: additionally the way the chauffeur is driving to
 * the pickup point – only during `accepted` and only if it is fresh.
 */
export async function hydrateForCustomer(
  row: Record<string, unknown>,
): Promise<Booking> {
  const booking = await hydrate(row);
  booking.approach = customerApproach(row, Date.now());
  if (booking.queue) booking.approach = null;
  return booking;
}
