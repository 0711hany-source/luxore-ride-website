/**
 * One look for every map: website, web apps, Android and iPhone use the same
 * two Mapbox styles, so colours never differ between devices (17.11.2026).
 * The chauffeur's own driving view keeps its turn-by-turn style.
 */
export const MAP_STYLE = 'mapbox://styles/mapbox/streets-v12';
export const MAP_STYLE_SATELLITE =
  'mapbox://styles/mapbox/satellite-streets-v12';
export const mapStyleFor = (satellite: boolean) =>
  satellite ? MAP_STYLE_SATELLITE : MAP_STYLE;
