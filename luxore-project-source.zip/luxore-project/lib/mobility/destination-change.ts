import { ApiError, db } from './server';
import { knownPlace } from './known-place';
import {
  distance,
  fare,
  isService,
  type Point,
  type RouteData,
} from './domain';

/**
 * Decision of the operator (17.11.2026): the price may only rise with the
 * customer's consent. A new destination during the ride is therefore chosen
 * by the customer: the app first shows the new price (offer, five minutes),
 * and only the confirmation of exactly that amount changes ride and price.
 */
export const DESTINATION_OFFER_MS = 5 * 60000;
const OPEN = "status IN ('accepted','arrived','riding')";

type Row = {
  route: string;
  service: string;
  price: number;
  fare_price: number | null;
};
async function activeRide(id: string, ownerId: string) {
  const row = await db()
    .prepare(
      `SELECT route,service,price,fare_price FROM mobility_bookings WHERE id=? AND owner_id=? AND ${OPEN}`,
    )
    .bind(id, ownerId)
    .first<Row>();
  if (!row || !isService(row.service))
    throw new ApiError(
      409,
      'Das Ziel kann nur bei einer laufenden, zugewiesenen Fahrt geändert werden.',
    );
  let route: RouteData;
  try {
    route = JSON.parse(row.route) as RouteData;
  } catch {
    throw new ApiError(409, 'Diese Fahrt kann nicht geändert werden.');
  }
  return { row, route };
}

/** Step 1: price for the new destination; nothing about the ride changes. */
export async function offerDestination(
  id: string,
  ownerId: string,
  destinationId: string,
  now: number,
) {
  const { row, route } = await activeRide(id, ownerId);
  const place = await knownPlace(db(), destinationId, ownerId);
  if (!place)
    throw new ApiError(400, 'Bitte das neue Ziel aus der Adresssuche auswählen.');
  if (distance(route.pickup, place) < 30)
    throw new ApiError(400, 'Abholort und Ziel liegen zu nah beieinander.');
  if (distance(route.destination, place) < 30)
    throw new ApiError(400, 'Das ist bereits das Ziel dieser Fahrt.');
  // Loaded on demand: only an offer needs the routing provider.
  const { route: calculateRoute } = await import('./provider');
  const next = await calculateRoute(route.pickup, place, null);
  const service = row.service as Parameters<typeof fare>[1];
  const originalFare = Number(row.fare_price ?? row.price);
  const offer = {
    destination: place as Point,
    distanceMeters: next.distanceMeters,
    durationSeconds: next.durationSeconds,
    geometry: next.geometry,
    fare: fare(next.distanceMeters, service),
    expiresAt: now + DESTINATION_OFFER_MS,
  };
  const saved = await db()
    .prepare(
      `UPDATE mobility_bookings SET route=?,updated_at=? WHERE id=? AND owner_id=? AND ${OPEN} AND route=?`,
    )
    .bind(
      JSON.stringify({ ...route, pendingDestination: offer }),
      now,
      id,
      ownerId,
      row.route,
    )
    .run();
  if (!saved.meta.changes)
    throw new ApiError(409, 'Die Fahrt wurde gerade geändert. Bitte erneut versuchen.');
  return {
    destination: { id: place.id, label: place.label },
    distanceMeters: offer.distanceMeters,
    fare: offer.fare,
    currentFare: originalFare,
    // Board products stay on the bill unchanged.
    price: offer.fare + (Number(row.price) - originalFare),
    currentPrice: Number(row.price),
    expiresAt: offer.expiresAt,
  };
}

/** Step 2: the customer confirms exactly the fare that was shown. */
export async function confirmDestination(
  id: string,
  ownerId: string,
  confirmedFare: unknown,
  now: number,
) {
  const { row, route } = await activeRide(id, ownerId);
  const offer = route.pendingDestination;
  if (!offer || offer.expiresAt < now)
    throw new ApiError(
      409,
      'Das Preisangebot ist abgelaufen. Bitte das neue Ziel erneut wählen.',
    );
  if (confirmedFare !== offer.fare)
    throw new ApiError(409, 'Der Preis hat sich geändert. Bitte erneut prüfen.');
  const originalFare = Number(row.fare_price ?? row.price);
  const {
    pendingDestination: _offer,
    navigation: _navigation,
    traffic: _traffic,
    ...kept
  } = route;
  void _offer;
  void _navigation;
  void _traffic;
  const changed: RouteData = {
    ...kept,
    destination: offer.destination,
    distanceMeters: offer.distanceMeters,
    durationSeconds: offer.durationSeconds,
    geometry: offer.geometry,
    calculatedAt: now,
    destinationChanges: [
      ...(route.destinationChanges ?? []),
      {
        from: route.destination,
        to: offer.destination,
        originalFare,
        fare: offer.fare,
        at: now,
      },
    ],
  };
  const r = await db().batch([
    db()
      .prepare(
        `UPDATE mobility_bookings SET route=?,price=price-?+?,fare_price=CASE WHEN fare_price IS NULL THEN NULL ELSE ? END,updated_at=? WHERE id=? AND owner_id=? AND ${OPEN} AND route=? AND COALESCE(fare_price,price)=?`,
      )
      .bind(
        JSON.stringify(changed),
        originalFare,
        offer.fare,
        offer.fare,
        now,
        id,
        ownerId,
        row.route,
        originalFare,
      ),
    db()
      .prepare(
        "INSERT INTO mobility_events(id,booking_id,actor_id,action,created_at) SELECT ?,?,?,'destination_changed',? WHERE EXISTS(SELECT 1 FROM mobility_bookings WHERE id=? AND owner_id=? AND updated_at=?)",
      )
      .bind(crypto.randomUUID(), id, ownerId, now, id, ownerId, now),
  ]);
  if (!r[0].meta.changes)
    throw new ApiError(409, 'Die Fahrt wurde gerade geändert. Bitte erneut versuchen.');
  return {
    destination: { id: offer.destination.id, label: offer.destination.label },
    fare: offer.fare,
    price: Number(row.price) - originalFare + offer.fare,
  };
}
