import type { NavigationStep } from './navigation-steps';
import type { RefreshmentOrder } from './refreshments';
import type { RidePreferences } from './ride-preferences';
// Cents per kilometre. Keys are the stable class IDs stored with bookings.
export const tariffs = {
  premium: 250,
  electric: 280,
  van: 300,
  first: 350,
} as const;
/**
 * Minimum fare per class in cents. Wish of the operator (18.11.2026): First
 * Class is to get a higher minimum – the amount is not decided yet, so every
 * class still has 15 €. Texts that name the minimum must follow a change.
 */
export const MIN_FARES: Record<keyof typeof tariffs, number> = {
  premium: 1500,
  electric: 1500,
  van: 1500,
  first: 1500,
};
// Shared validation for cross-border car journeys; matches Directions' driving limit.
export const MAX_ROUTE_METERS = 10_000_000;
export type Service = keyof typeof tariffs;
export type Point = {
  id: string;
  label: string;
  lat: number;
  lng: number;
  attribution?: string | null;
};
export type RouteData = {
  pickup: Point;
  destination: Point;
  distanceMeters: number;
  durationSeconds: number;
  geometry: { type: 'LineString'; coordinates: number[][] };
  calculatedAt: number;
  navigation?: NavigationStep[];
  traffic?: { typicalSeconds: number | null; unpaved: boolean };
  /** Price offer for a new destination, waiting for the customer (server only). */
  pendingDestination?: {
    destination: Point;
    distanceMeters: number;
    durationSeconds: number;
    geometry: { type: 'LineString'; coordinates: number[][] };
    fare: number;
    expiresAt: number;
  };
  /** Destinations the customer changed during the ride, with both fares. */
  destinationChanges?: {
    from: Point;
    to: Point;
    originalFare: number;
    fare: number;
    at: number;
  }[];
  /** Waiting at the pickup point that was charged (see waiting.ts). */
  waiting?: {
    seconds: number;
    freeSeconds: number;
    minutes: number;
    rate: number;
    fee: number;
    at: number;
  };
  /** Follow-up ride: calculated way from the running ride's destination. */
  chain?: {
    fromLat: number;
    fromLng: number;
    legSeconds: number;
    legMeters: number;
    at: number;
  };
  /** Set when the ride ended elsewhere and the fare was calculated anew. */
  adjustment?: {
    reason: 'ended_elsewhere';
    originalFare: number;
    fare: number;
    end: { lat: number; lng: number };
    distanceMeters: number;
    at: number;
  };
};
export type Quote = RouteData & {
  id: string;
  expiresAt: number;
  prices: Record<Service, number>;
  mode: 'now' | 'reservation';
  scheduledAt: number | null;
  // Answer-only hint for immediate rides: is a free chauffeur of the class
  // online right now? Never stored with the quote, never positions or people.
  availability?: Record<Service, boolean>;
  // Answer-only: span until the nearest free chauffeur of the class could
  // be at the pickup point. Never positions, names or counts.
  arrival?: Partial<Record<Service, ArrivalWindow>>;
};
export type BookingStatus =
  | 'requesting'
  | 'reserved'
  | 'accepted'
  | 'arrived'
  | 'riding'
  | 'completed'
  | 'cancelled'
  | 'unavailable';
export const statusNames: Record<BookingStatus, string> = {
  requesting: 'Fahrer wird gesucht',
  reserved: 'Reservierung vorgemerkt',
  accepted: 'Fahrer auf dem Weg',
  arrived: 'Fahrer am Abholort',
  riding: 'Fahrt läuft',
  completed: 'Fahrt abgeschlossen',
  cancelled: 'Storniert',
  unavailable: 'Kein Fahrer verfügbar',
};
export const activeStatuses = ['requesting', 'accepted', 'arrived', 'riding'];
export const driverNext: Partial<Record<BookingStatus, BookingStatus>> = {
  accepted: 'arrived',
  arrived: 'riding',
  riding: 'completed',
};
export const isService = (v: unknown): v is Service =>
  typeof v === 'string' && Object.hasOwn(tariffs, v);
export const services = Object.keys(tariffs) as Service[];
export function fares(distanceMeters: number) {
  return Object.fromEntries(
    services.map((s) => [s, fare(distanceMeters, s)]),
  ) as Record<Service, number>;
}
export function fare(distanceMeters: number, service: Service) {
  if (
    !Number.isFinite(distanceMeters) ||
    distanceMeters < 1 ||
    distanceMeters > MAX_ROUTE_METERS ||
    !isService(service)
  )
    throw new Error('Ungültige Routendaten.');
  return Math.max(
    MIN_FARES[service],
    Math.round((distanceMeters * tariffs[service]) / 1000),
  );
}
export function coordinate(lat: unknown, lng: unknown): lat is number {
  return (
    typeof lat === 'number' &&
    typeof lng === 'number' &&
    Number.isFinite(lat) &&
    Number.isFinite(lng) &&
    Math.abs(lat) <= 90 &&
    Math.abs(lng) <= 180
  );
}
export function distance(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
) {
  const r = Math.PI / 180;
  const s =
    Math.sin(((b.lat - a.lat) * r) / 2) ** 2 +
    Math.cos(a.lat * r) *
      Math.cos(b.lat * r) *
      Math.sin(((b.lng - a.lng) * r) / 2) ** 2;
  return 6371000 * 2 * Math.asin(Math.sqrt(Math.min(1, s)));
}
export function departure(mode: unknown, value: unknown, now: number) {
  if (mode === 'now') return null;
  if (
    mode !== 'reservation' ||
    typeof value !== 'number' ||
    !Number.isFinite(value) ||
    value < now + 30 * 60000 ||
    value > now + 90 * 86400000
  )
    throw new Error(
      'Reservierungen sind ab 30 Minuten bis 90 Tage im Voraus möglich.',
    );
  return value;
}
export type Driver = {
  // Local display telemetry; raw dispatch coordinates keep their existing storage.
  heading?: number;
  speed?: number;
  session_id?: string | null;
  vehicle_id?: string | null;
  services?: string | null;
  id: string;
  name: string;
  phone: string;
  vehicle: string;
  plate: string;
  service: Service;
  approved: number;
  online: number;
  lat: number | null;
  lng: number | null;
  location_at: number | null;
  accuracy: number | null;
  /** Profile picture (guarded photo route) and rating as customers see it. */
  photo_id?: string | null;
  rating?: { average: number; count: number } | null;
};
/** The chauffeur who has taken a reservation over, as the customer sees him. */
export type ConfirmedChauffeur = {
  name: string;
  vehicle: string | null;
  plate: string | null;
  photo_id: string | null;
  /** null: fewer than three ratings ("Neu"). */
  rating: { average: number; count: number } | null;
};
export type Booking = {
  assigned_driver_id?: string | null;
  assigned_fleet_id?: string | null;
  assigned_vehicle_id?: string | null;
  assigned_at?: number | null;
  chauffeur?: ConfirmedChauffeur | null;
  refreshments?: RefreshmentOrder;
  /**
   * Pieces per article in the assigned car (only counts > 0). `null` until a
   * car is assigned (accepted/arrived/riding) – then nothing can be ordered.
   */
  board_stock?: Record<string, number> | null;
  /**
   * The chauffeur's current way to the pickup point (GeoJSON LineString).
   * Only in the customer's own ride list, only during `accepted` and only
   * when calculated within the last two minutes; otherwise null/absent.
   */
  approach?: { type: 'LineString'; coordinates: number[][] } | null;
  /**
   * Set while the chauffeur still drives another guest: seconds until he is
   * at the pickup point. His position is not shown during that time.
   */
  queue?: { etaSeconds: number } | null;
  /** While the chauffeur is on the way: span until he is at the pickup. */
  eta?: ArrivalWindow | null;
  fare_price?: number | null;
  rider_preferences?: RidePreferences;
  vehicle_id?: string | null;
  vehicle_snapshot?: string | null;
  payment_status: 'unpaid' | 'paid';
  payment_method: 'cash' | 'terminal' | null;
  paid_at: number | null;
  completed_at: number | null;
  fleet_id: string | null;
  rider_name?: string | null;
  rider_phone?: string | null;
  id: string;
  quote_id: string;
  owner_id: string;
  service: Service;
  price: number;
  route: RouteData;
  mode: 'now' | 'reservation';
  scheduled_at: number | null;
  status: BookingStatus;
  driver_id: string | null;
  created_at: number;
  updated_at: number;
  dispatch_at: number | null;
  rider_lat: number | null;
  rider_lng: number | null;
  rider_location_at: number | null;
  driver: Driver | null;
};
export type Offer = { id: string; expires_at: number; booking: Booking };

export function driverServices(
  driver: Pick<Driver, 'service' | 'services'>,
): Service[] {
  if (!driver.services) return [driver.service];
  try {
    const values: unknown = JSON.parse(driver.services);
    return Array.isArray(values) ? values.filter(isService) : [];
  } catch {
    return [];
  }
}
export function parseServices(value: unknown): Service[] {
  if (
    !Array.isArray(value) ||
    !value.length ||
    value.length > Object.keys(tariffs).length ||
    !value.every(isService)
  )
    throw new Error('Bitte mindestens eine gültige Fahrzeugklasse wählen.');
  return [...new Set(value)];
}

export type Fleet = {
  id: string;
  name: string;
  created_at: number;
  owner_id: string | null;
  deputy_id: string | null;
};
export type Employee = {
  user_id: string;
  name: string;
  phone: string;
  fleet_id: string | null;
  role: 'staff' | 'driver';
};

export type FleetVehicle = {
  id: string;
  fleet_id: string;
  model: string;
  plate: string;
  services: string;
  status: 'active' | 'archived';
  archived_reason: string | null;
  blocking_reason?: string | null;
  driver_id: string | null;
  driver_name: string | null;
  online: number | null;
};
export type ArrivalWindow = { minSeconds: number; maxSeconds: number };
/** Drive time is never exact: the customer gets a small span of minutes. */
export function arrivalWindow(seconds: number): ArrivalWindow {
  const s = Math.max(0, seconds);
  const min = Math.max(1, Math.floor((s * 0.8) / 60));
  const max = Math.max(min + 1, Math.ceil((s * 1.25) / 60) + 1);
  return { minSeconds: min * 60, maxSeconds: max * 60 };
}
export function arrivalText(w: ArrivalWindow | null | undefined) {
  return w &&
    Number.isFinite(w.minSeconds) &&
    Number.isFinite(w.maxSeconds) &&
    w.maxSeconds >= w.minSeconds
    ? `ca. ${Math.round(w.minSeconds / 60)}–${Math.round(w.maxSeconds / 60)} Min.`
    : '';
}
/**
 * Short heading for a customer whose chauffeur is on the way ("Chauffeur in
 * ca. 4–6 Min."); null otherwise. Short on purpose: headings are one line.
 */
export function queueText(booking: {
  status?: unknown;
  queue?: { etaSeconds: number } | null;
  eta?: ArrivalWindow | null;
}) {
  const span = arrivalText(booking.eta);
  return booking.status === 'accepted' && span ? `Chauffeur in ${span}` : null;
}
/** A follow-up ride: why the chauffeur is not on the map yet. */
export const QUEUE_STATUS = 'Chauffeur beendet noch eine Fahrt';
export const QUEUE_NOTE =
  'Dein Chauffeur lässt noch einen Gast aussteigen und kommt dann zu dir. Seine Position siehst du, sobald er zu dir unterwegs ist.';
