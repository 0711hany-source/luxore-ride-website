import type { NavigationStep } from './navigation-steps';
import type { RefreshmentOrder } from './refreshments';
import type { RidePreferences } from './ride-preferences';
// Cents per kilometre. Keys are the stable class IDs stored with bookings.
export const tariffs = {
  premium: 250,
  electric: 280,
  van: 300,
  first: 350,
} as const;
// Shared validation for cross-border car journeys; matches Directions' driving limit.
export const MAX_ROUTE_METERS = 10_000_000;
export type Service = keyof typeof tariffs;
export type Point = {
  id: string;
  label: string;
  lat: number;
  lng: number;
  attribution?: string | null;
};
export type RouteData = {
  pickup: Point;
  destination: Point;
  distanceMeters: number;
  durationSeconds: number;
  geometry: { type: 'LineString'; coordinates: number[][] };
  calculatedAt: number;
  navigation?: NavigationStep[];
  traffic?: { typicalSeconds: number | null; unpaved: boolean };
};
export type Quote = RouteData & {
  id: string;
  expiresAt: number;
  prices: Record<Service, number>;
  mode: 'now' | 'reservation';
  scheduledAt: number | null;
  // Answer-only hint for immediate rides: is a free chauffeur of the class
  // online right now? Never stored with the quote, never positions or people.
  availability?: Record<Service, boolean>;
};
export type BookingStatus =
  | 'requesting'
  | 'reserved'
  | 'accepted'
  | 'arrived'
  | 'riding'
  | 'completed'
  | 'cancelled'
  | 'unavailable';
export const statusNames: Record<BookingStatus, string> = {
  requesting: 'Fahrer wird gesucht',
  reserved: 'Reservierung vorgemerkt',
  accepted: 'Fahrer auf dem Weg',
  arrived: 'Fahrer am Abholort',
  riding: 'Fahrt läuft',
  completed: 'Fahrt abgeschlossen',
  cancelled: 'Storniert',
  unavailable: 'Kein Fahrer verfügbar',
};
export const activeStatuses = ['requesting', 'accepted', 'arrived', 'riding'];
export const driverNext: Partial<Record<BookingStatus, BookingStatus>> = {
  accepted: 'arrived',
  arrived: 'riding',
  riding: 'completed',
};
export const isService = (v: unknown): v is Service =>
  typeof v === 'string' && Object.hasOwn(tariffs, v);
export const services = Object.keys(tariffs) as Service[];
export function fares(distanceMeters: number) {
  return Object.fromEntries(
    services.map((s) => [s, fare(distanceMeters, s)]),
  ) as Record<Service, number>;
}
export function fare(distanceMeters: number, service: Service) {
  if (
    !Number.isFinite(distanceMeters) ||
    distanceMeters < 1 ||
    distanceMeters > MAX_ROUTE_METERS ||
    !isService(service)
  )
    throw new Error('Ungültige Routendaten.');
  return Math.max(1500, Math.round((distanceMeters * tariffs[service]) / 1000));
}
export function coordinate(lat: unknown, lng: unknown): lat is number {
  return (
    typeof lat === 'number' &&
    typeof lng === 'number' &&
    Number.isFinite(lat) &&
    Number.isFinite(lng) &&
    Math.abs(lat) <= 90 &&
    Math.abs(lng) <= 180
  );
}
export function distance(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
) {
  const r = Math.PI / 180;
  const s =
    Math.sin(((b.lat - a.lat) * r) / 2) ** 2 +
    Math.cos(a.lat * r) *
      Math.cos(b.lat * r) *
      Math.sin(((b.lng - a.lng) * r) / 2) ** 2;
  return 6371000 * 2 * Math.asin(Math.sqrt(Math.min(1, s)));
}
export function departure(mode: unknown, value: unknown, now: number) {
  if (mode === 'now') return null;
  if (
    mode !== 'reservation' ||
    typeof value !== 'number' ||
    !Number.isFinite(value) ||
    value < now + 30 * 60000 ||
    value > now + 90 * 86400000
  )
    throw new Error(
      'Reservierungen sind ab 30 Minuten bis 90 Tage im Voraus möglich.',
    );
  return value;
}
export type Driver = {
  // Local display telemetry; raw dispatch coordinates keep their existing storage.
  heading?: number;
  speed?: number;
  session_id?: string | null;
  vehicle_id?: string | null;
  services?: string | null;
  id: string;
  name: string;
  phone: string;
  vehicle: string;
  plate: string;
  service: Service;
  approved: number;
  online: number;
  lat: number | null;
  lng: number | null;
  location_at: number | null;
  accuracy: number | null;
  /** Profile picture (guarded photo route) and rating as customers see it. */
  photo_id?: string | null;
  rating?: { average: number; count: number } | null;
};
/** The chauffeur who has taken a reservation over, as the customer sees him. */
export type ConfirmedChauffeur = {
  name: string;
  vehicle: string | null;
  plate: string | null;
  photo_id: string | null;
  /** null: fewer than three ratings ("Neu"). */
  rating: { average: number; count: number } | null;
};
export type Booking = {
  assigned_driver_id?: string | null;
  assigned_fleet_id?: string | null;
  assigned_vehicle_id?: string | null;
  assigned_at?: number | null;
  chauffeur?: ConfirmedChauffeur | null;
  refreshments?: RefreshmentOrder;
  /**
   * Pieces per article in the assigned car (only counts > 0). `null` until a
   * car is assigned (accepted/arrived/riding) – then nothing can be ordered.
   */
  board_stock?: Record<string, number> | null;
  /**
   * The chauffeur's current way to the pickup point (GeoJSON LineString).
   * Only in the customer's own ride list, only during `accepted` and only
   * when calculated within the last two minutes; otherwise null/absent.
   */
  approach?: { type: 'LineString'; coordinates: number[][] } | null;
  fare_price?: number | null;
  rider_preferences?: RidePreferences;
  vehicle_id?: string | null;
  vehicle_snapshot?: string | null;
  payment_status: 'unpaid' | 'paid';
  payment_method: 'cash' | 'terminal' | null;
  paid_at: number | null;
  completed_at: number | null;
  fleet_id: string | null;
  rider_name?: string | null;
  rider_phone?: string | null;
  id: string;
  quote_id: string;
  owner_id: string;
  service: Service;
  price: number;
  route: RouteData;
  mode: 'now' | 'reservation';
  scheduled_at: number | null;
  status: BookingStatus;
  driver_id: string | null;
  created_at: number;
  updated_at: number;
  dispatch_at: number | null;
  rider_lat: number | null;
  rider_lng: number | null;
  rider_location_at: number | null;
  driver: Driver | null;
};
export type Offer = { id: string; expires_at: number; booking: Booking };

export function driverServices(
  driver: Pick<Driver, 'service' | 'services'>,
): Service[] {
  if (!driver.services) return [driver.service];
  try {
    const values: unknown = JSON.parse(driver.services);
    return Array.isArray(values) ? values.filter(isService) : [];
  } catch {
    return [];
  }
}
export function parseServices(value: unknown): Service[] {
  if (
    !Array.isArray(value) ||
    !value.length ||
    value.length > Object.keys(tariffs).length ||
    !value.every(isService)
  )
    throw new Error('Bitte mindestens eine gültige Fahrzeugklasse wählen.');
  return [...new Set(value)];
}

export type Fleet = {
  id: string;
  name: string;
  created_at: number;
  owner_id: string | null;
  deputy_id: string | null;
};
export type Employee = {
  user_id: string;
  name: string;
  phone: string;
  fleet_id: string | null;
  role: 'staff' | 'driver';
};

export type FleetVehicle = {
  id: string;
  fleet_id: string;
  model: string;
  plate: string;
  services: string;
  status: 'active' | 'archived';
  archived_reason: string | null;
  blocking_reason?: string | null;
  driver_id: string | null;
  driver_name: string | null;
  online: number | null;
};
