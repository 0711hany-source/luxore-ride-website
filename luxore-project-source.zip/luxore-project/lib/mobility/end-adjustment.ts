import {
  distance,
  fare,
  isService,
  type RouteData,
  type Service,
} from './domain';

/**
 * Decision of the operator (17.11.2026): the ordered price holds for the
 * ordered way, whatever roads the chauffeur takes. Only when the ride ends
 * somewhere else — more than one kilometre from the ordered destination — the
 * fare is calculated anew for the way from the pickup point to the place the
 * ride really ended. Without the customer's consent the price never rises.
 */
export const END_TOLERANCE_METERS = 1000;
/** A position older than this says nothing about where the ride ended. */
export const END_POSITION_MAX_AGE_MS = 2 * 60000;

export type EndAdjustment = {
  reason: 'ended_elsewhere';
  /** Pure fare before and after, in cents (board products are not included). */
  originalFare: number;
  fare: number;
  end: { lat: number; lng: number };
  distanceMeters: number;
  at: number;
};

export type EndPosition = {
  lat: number | null;
  lng: number | null;
  location_at: number | null;
};

/** Where the ride ended, if it ended elsewhere and the position is fresh. */
export function endedElsewhere(
  route: RouteData,
  position: EndPosition | null,
  now: number,
): { lat: number; lng: number } | null {
  if (
    !position ||
    typeof position.lat !== 'number' ||
    typeof position.lng !== 'number' ||
    !Number.isFinite(position.lat) ||
    !Number.isFinite(position.lng) ||
    typeof position.location_at !== 'number' ||
    now - position.location_at > END_POSITION_MAX_AGE_MS
  )
    return null;
  const end = { lat: position.lat, lng: position.lng };
  return distance(end, route.destination) > END_TOLERANCE_METERS ? end : null;
}

/**
 * New amounts for a ride that ended elsewhere. `null` when nothing changes:
 * the way to the real end is not shorter in price than the ordered one.
 */
export function adjustedAmounts(
  row: { price: number; fare_price: number | null; service: string },
  end: { lat: number; lng: number },
  distanceMeters: number,
  now: number,
  /** Waiting fee already charged: it stays, whatever way was driven. */
  waiting = 0,
): {
  price: number;
  fare_price: number | null;
  adjustment: EndAdjustment;
} | null {
  if (!isService(row.service)) return null;
  const originalFare = Number(row.fare_price ?? row.price);
  // At the pickup point itself there is no way to price: the minimum fare.
  const next =
    (distanceMeters < 1
      ? fare(1, row.service as Service)
      : fare(distanceMeters, row.service as Service)) + waiting;
  if (!(next < originalFare)) return null;
  const products = Number(row.price) - originalFare;
  return {
    price: next + products,
    fare_price: row.fare_price == null ? null : next,
    adjustment: {
      reason: 'ended_elsewhere',
      originalFare,
      fare: next,
      end,
      distanceMeters: Math.max(0, Math.round(distanceMeters)),
      at: now,
    },
  };
}

const euro = (cents: number) =>
  (cents / 100).toLocaleString('de-DE', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }) + ' €';
/** One sentence for the bill of a ride whose fare was calculated anew. */
export function adjustmentNote(route: RouteData | null | undefined) {
  const a = route?.adjustment;
  if (!a || a.reason !== 'ended_elsewhere') return null;
  return `Die Fahrt endete nicht am bestellten Ziel. Der Fahrpreis wurde für die gefahrene Strecke neu berechnet: ${euro(a.fare)} statt ${euro(a.originalFare)}.`;
}
/** Notice for the chauffeur: the customer confirmed a new destination. */
export function destinationChangeNote(route: RouteData | null | undefined) {
  const last = route?.destinationChanges?.at(-1);
  if (!last) return null;
  return `Neues Ziel vom Fahrgast bestätigt: ${last.to.label} (vorher ${last.from.label}). Neuer Fahrpreis: ${euro(last.fare)}.`;
}
