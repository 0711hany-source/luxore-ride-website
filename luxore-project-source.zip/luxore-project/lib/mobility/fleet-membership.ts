import type { AppUser } from '@/lib/identity';
import type { SqlDatabase } from '@/db/sqlite';
import { ApiError, db, isAdmin } from './server';
import { audit } from './accounts';
import { operatorScope } from './fleets';
import { driverIdle } from './vehicles';

async function activeActor(user: AppUser, transaction: SqlDatabase) {
  if (
    await transaction
      .prepare(
        "SELECT id FROM mobility_accounts WHERE id=? AND status<>'active'",
      )
      .bind(user.userId)
      .first()
  )
    throw new ApiError(
      403,
      'Dein Konto ist nicht aktiv. Bitte erneut anmelden.',
    );
}
async function resetDriver(transaction: SqlDatabase, id: string) {
  await transaction.batch([
    transaction
      .prepare(
        `UPDATE mobility_drivers SET approved=0,online=0,session_id=NULL,vehicle_id=NULL,vehicle='',plate='',services='[]' WHERE id=? AND ${driverIdle('mobility_drivers')}`,
      )
      .bind(id),
    transaction
      .prepare(
        "UPDATE mobility_offers SET status='withdrawn' WHERE driver_id=? AND status='pending'",
      )
      .bind(id),
  ]);
}
export async function removeFleetMember(
  user: AppUser,
  fleetId: string,
  id: string,
) {
  await db().writeTransaction(async (transaction) => {
    await activeActor(user, transaction);
    const scope = await operatorScope(user, () => transaction);
    if (!scope || (scope !== 'all' && scope !== fleetId))
      throw new ApiError(403, 'Diese Flotte gehört nicht zu deinem Zugang.');
    const changed = await transaction
      .prepare(`UPDATE mobility_employees SET fleet_id=NULL WHERE user_id=? AND fleet_id=?
      AND NOT EXISTS(SELECT 1 FROM mobility_fleets f WHERE f.owner_id=mobility_employees.user_id OR f.deputy_id=mobility_employees.user_id)
      AND NOT EXISTS(SELECT 1 FROM mobility_drivers d WHERE d.id=mobility_employees.user_id AND NOT (${driverIdle('d')}))`)
      .bind(id, fleetId)
      .run();
    if (!changed.meta.changes)
      throw new ApiError(
        409,
        'Entfernen nicht möglich: Mitarbeiter nicht zugeordnet, noch im Einsatz oder Zahlung offen. Eine Stellvertretung muss zuerst aufgehoben werden; der Besitzer bleibt in seiner Flotte.',
      );
    await resetDriver(transaction, id);
    await audit(user.userId, id, 'fleet.member_removed', () => transaction);
  });
}
export async function assignFleetMember(
  user: AppUser,
  id: string,
  fleetId: string | null,
  role: 'staff' | 'driver',
) {
  await db().writeTransaction(async (transaction) => {
    if (!isAdmin(user))
      throw new ApiError(
        403,
        'Flotten und Zuordnungen verwaltet der Plattformbetreiber.',
      );
    await activeActor(user, transaction);
    if (
      fleetId &&
      !(await transaction
        .prepare('SELECT id FROM mobility_fleets WHERE id=?')
        .bind(fleetId)
        .first())
    )
      throw new ApiError(404, 'Flotte nicht gefunden.');
    if (
      await transaction
        .prepare(
          'SELECT id FROM mobility_fleets WHERE owner_id=? OR deputy_id=?',
        )
        .bind(id, id)
        .first()
    )
      throw new ApiError(
        409,
        'Besitzer können nicht umgehängt werden. Bei Stellvertretern zuerst die Stellvertretung aufheben.',
      );
    // Detaching an inactive member remains possible; assigning new access does not.
    if (
      fleetId &&
      (await transaction
        .prepare(
          "SELECT id FROM mobility_accounts WHERE id=? AND status<>'active'",
        )
        .bind(id)
        .first())
    )
      throw new ApiError(409, 'Dieses Konto ist gesperrt oder wird gelöscht.');
    const existing = await transaction
      .prepare('SELECT fleet_id,role FROM mobility_employees WHERE user_id=?')
      .bind(id)
      .first<{ fleet_id: string | null; role: string }>();
    // Confirm current identical state without resetting a later vehicle or shift.
    if (existing && existing.fleet_id === fleetId && existing.role === role)
      return;
    if (
      await transaction
        .prepare(
          `SELECT id FROM mobility_drivers WHERE id=? AND NOT (${driverIdle('mobility_drivers')})`,
        )
        .bind(id)
        .first()
    )
      throw new ApiError(
        409,
        'Flottenwechsel erst offline, nach Fahrtabschluss und Kassieren.',
      );
    const member = await transaction
      .prepare(
        'SELECT name,phone FROM mobility_employees WHERE user_id=? UNION ALL SELECT name,phone FROM mobility_drivers WHERE id=? LIMIT 1',
      )
      .bind(id, id)
      .first<{ name: string; phone: string }>();
    if (!member) throw new ApiError(404, 'Mitarbeiterprofil nicht gefunden.');
    await transaction
      .prepare(
        `INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET fleet_id=excluded.fleet_id,role=excluded.role`,
      )
      .bind(id, member.name, member.phone, fleetId, role, Date.now())
      .run();
    await resetDriver(transaction, id);
    await audit(
      user.userId,
      id,
      fleetId ? 'fleet.member_assigned' : 'fleet.member_detached',
      () => transaction,
    );
  });
}
