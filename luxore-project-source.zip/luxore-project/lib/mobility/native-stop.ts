import { ApiError, db } from './server';
import { nativeSessionSql } from './location';

export async function stopNativeLocation(hash: string) {
  await db().writeTransaction(async (transaction) => {
    // The request's initial read is not authority for a later stop. Rotation,
    // expiry, approval and vehicle changes must be checked under the write lock.
    const session = await transaction
      .prepare(nativeSessionSql)
      .bind(hash, Date.now())
      .first<{ driver_id: string; session_id: string }>();
    if (!session)
      throw new ApiError(
        401,
        'Standortfreigabe beendet. Bitte erneut online gehen.',
      );
    await transaction.batch([
      transaction
        .prepare(
          'UPDATE mobility_drivers SET online=0,session_id=NULL WHERE id=? AND session_id=?',
        )
        .bind(session.driver_id, session.session_id),
      transaction
        .prepare('DELETE FROM mobility_location_sessions WHERE token_hash=?')
        .bind(hash),
      transaction
        .prepare(
          "UPDATE mobility_offers SET status='rejected' WHERE driver_id=? AND status='pending' AND EXISTS(SELECT 1 FROM mobility_drivers WHERE id=? AND online=0)",
        )
        .bind(session.driver_id, session.driver_id),
    ]);
  });
}
