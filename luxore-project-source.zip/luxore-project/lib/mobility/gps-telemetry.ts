// Both browser and Android report course over ground, not the phone's compass.
export type TravelTelemetry = { heading?: number; speed?: number };
export function travelTelemetry(coords: {
  heading?: number | null;
  speed?: number | null;
}): TravelTelemetry {
  const speed =
    typeof coords.speed === 'number' &&
    Number.isFinite(coords.speed) &&
    coords.speed >= 0 &&
    coords.speed <= 70
      ? coords.speed
      : undefined;
  const heading =
    typeof coords.heading === 'number' &&
    Number.isFinite(coords.heading) &&
    coords.heading >= 0 &&
    coords.heading < 360
      ? coords.heading
      : undefined;
  return { speed, heading };
}
export function reliableCourse(
  fix: TravelTelemetry & { accuracy: number },
): number | null {
  const { speed, heading } = travelTelemetry(fix);
  return speed != null && speed >= 1.5 && heading != null && fix.accuracy <= 30
    ? heading
    : null;
}
