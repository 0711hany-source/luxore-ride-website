export type NavigationStep = {
  distanceMeters: number;
  durationSeconds: number;
  coordinates: [number, number][];
  instruction: string;
  street: string;
  type: string;
  modifier?: string;
  exit?: number;
};
const position = (c: unknown): c is [number, number] =>
  Array.isArray(c) &&
  c.length >= 2 &&
  Number.isFinite(c[0]) &&
  Math.abs(c[0]) <= 180 &&
  Number.isFinite(c[1]) &&
  Math.abs(c[1]) <= 85;
/** Incomplete guidance is omitted rather than skipping a malformed turn. */
export function readNavigationSteps(
  legs: unknown,
): NavigationStep[] | undefined {
  if (
    !Array.isArray(legs) ||
    legs.length !== 1 ||
    !Array.isArray(legs[0]?.steps)
  )
    return;
  const steps = legs[0].steps;
  if (steps.length < 2 || steps.length > 2000) return;
  let points = 0;
  const result: NavigationStep[] = [];
  for (const step of steps) {
    const m = step?.maneuver,
      c = step?.geometry?.coordinates;
    if (
      !m ||
      typeof m.type !== 'string' ||
      m.type.length > 50 ||
      typeof m.instruction !== 'string' ||
      !m.instruction.trim() ||
      m.instruction.length > 600 ||
      !position(m.location) ||
      step.geometry?.type !== 'LineString' ||
      !Array.isArray(c) ||
      c.length < 2 ||
      c.length > 10000 ||
      !c.every(position) ||
      !Number.isFinite(step.distance) ||
      step.distance < 0 ||
      !Number.isFinite(step.duration) ||
      step.duration < 0
    )
      return;
    points += c.length;
    if (points > 100000) return;
    result.push({
      distanceMeters: step.distance,
      durationSeconds: step.duration,
      coordinates: c.map(([lng, lat]: number[]) => [lng, lat]),
      instruction: m.instruction.trim(),
      street: typeof step.name === 'string' ? step.name.slice(0, 200) : '',
      type: m.type,
      ...(typeof m.modifier === 'string' && m.modifier.length <= 30
        ? { modifier: m.modifier }
        : {}),
      ...(Number.isInteger(m.exit) && m.exit > 0 && m.exit < 100
        ? { exit: m.exit }
        : {}),
    });
  }
  if (result[0].type !== 'depart' || result.at(-1)!.type !== 'arrive') return;
  return result;
}
