export const preferenceOptions = {
  temperature: { standard: 'Keine Vorgabe', cool: 'Kühl', warm: 'Warm' },
  conversation: {
    standard: 'Keine Vorgabe',
    quiet: 'Lieber Ruhe',
    chat: 'Gerne unterhalten',
  },
  music: { standard: 'Keine Vorgabe', off: 'Keine Musik', soft: 'Leise Musik' },
} as const;
export type RidePreferences = {
  [K in keyof typeof preferenceOptions]: keyof (typeof preferenceOptions)[K];
};
export const defaultPreferences: RidePreferences = {
  temperature: 'standard',
  conversation: 'standard',
  music: 'standard',
};
export function parseRidePreferences(value: unknown): RidePreferences {
  if (value == null) return { ...defaultPreferences };
  if (typeof value !== 'object' || Array.isArray(value))
    throw new Error('Ungültige Fahrtwünsche.');
  const data = value as Record<string, unknown>;
  if (Object.keys(data).some((key) => !Object.hasOwn(defaultPreferences, key)))
    throw new Error('Unbekannter Fahrtwunsch.');
  for (const key of Object.keys(
    defaultPreferences,
  ) as (keyof RidePreferences)[]) {
    const option = data[key];
    if (
      option !== undefined &&
      (typeof option !== 'string' ||
        !Object.hasOwn(preferenceOptions[key], option))
    )
      throw new Error('Bitte gültige Fahrtwünsche auswählen.');
  }
  return { ...defaultPreferences, ...data } as RidePreferences;
}
export function storedRidePreferences(value: unknown): RidePreferences {
  try {
    return parseRidePreferences(
      typeof value === 'string' ? JSON.parse(value) : value,
    );
  } catch {
    return { ...defaultPreferences };
  }
}
export function preferenceLabels(value?: RidePreferences | null): string[] {
  const prefs = parseRidePreferences(value);
  return (Object.keys(defaultPreferences) as (keyof RidePreferences)[])
    .filter((key) => prefs[key] !== 'standard')
    .map(
      (key) => (preferenceOptions[key] as Record<string, string>)[prefs[key]],
    );
}
