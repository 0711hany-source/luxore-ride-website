// Follow-up ride (wish of the operator, 18.11.2026): a chauffeur who is
// driving a guest may already accept the next ride. The waiting customer sees
// when the chauffeur will be there: rest of the running ride, one minute for
// letting the guest out, then the way from that destination to the pickup.
import type { SqlDatabase } from '@/db/sqlite';
import { distance, type RouteData } from './domain.ts';
/** Stop for letting the guest out. */
export const CHAIN_STOP_SECONDS = 60;
/** A follow-up ride is only offered when the chauffeur can be there in time. */
export const CHAIN_MAX_ETA_SECONDS = 20 * 60;
/** Rough town speed for the estimate without a routing request (m/s). */
const ESTIMATE_SPEED = 7;
type Point = { lat: number; lng: number };
const point = (p: unknown): p is Point =>
  !!p &&
  Number.isFinite((p as Point).lat) &&
  Number.isFinite((p as Point).lng);
/** Seconds the running ride still needs, from where the car is now. */
export function remainingSeconds(running: RouteData, car: Point | null) {
  const total = Math.max(0, running.durationSeconds || 0);
  if (!point(car)) return total;
  const whole = distance(running.pickup, running.destination);
  if (!(whole > 0)) return total;
  const left = distance(car, running.destination);
  return Math.round(total * Math.min(1, Math.max(0, left / whole)));
}
/** Drive time for a straight-line distance, without a routing request. */
export const driveSeconds = (metres: number) =>
  Math.round((Math.max(0, metres) * 1.3) / ESTIMATE_SPEED);
/** Way from the running ride's destination to the next pickup, estimated. */
export function estimatedLegSeconds(running: RouteData, next: RouteData) {
  return driveSeconds(distance(running.destination, next.pickup));
}
/** Seconds until the chauffeur is at the next pickup point. */
export function chainEta(
  running: RouteData,
  next: RouteData,
  car: Point | null,
  now: number,
) {
  const leg = next.chain;
  const legSeconds =
    leg &&
    Number.isFinite(leg.legSeconds) &&
    leg.legSeconds >= 0 &&
    // A calculated way only fits the destination it was calculated from.
    leg.fromLat === running.destination.lat &&
    leg.fromLng === running.destination.lng
      ? leg.legSeconds
      : estimatedLegSeconds(running, next);
  void now;
  return remainingSeconds(running, car) + CHAIN_STOP_SECONDS + legSeconds;
}
/** The ride this chauffeur is driving right now, if any. */
export async function runningRide(db: SqlDatabase, driverId: string) {
  const row = await db
    .prepare(
      "SELECT id,route FROM mobility_bookings WHERE driver_id=? AND status='riding' LIMIT 1",
    )
    .bind(driverId)
    .first<{ id: string; route: string }>();
  if (!row) return null;
  try {
    return { id: row.id, route: JSON.parse(row.route) as RouteData };
  } catch {
    return null;
  }
}
/** The driver's list: the ride at hand first, the waiting one after it. */
export function rideOrder<T extends { status?: unknown; updated_at?: unknown }>(
  rows: T[],
) {
  const rank = (s: unknown) => (s === 'riding' ? 0 : s === 'arrived' ? 1 : 2);
  return [...rows].sort(
    (a, b) =>
      rank(a.status) - rank(b.status) ||
      Number(a.updated_at || 0) - Number(b.updated_at || 0),
  );
}
