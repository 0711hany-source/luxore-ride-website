import { driverIdle } from './vehicles';
import { ApiError, db, tokenHash } from './server';
export async function joinFleet(userId: string, code: string) {
  const now = Date.now();
  if (!/^LX-[A-F0-9]{32}$/.test(code))
    throw new ApiError(400, 'Dieser Einladungscode ist ungültig.');
  const hash = await tokenHash(code);
  // Evaluate the inviter's current authority and membership in the same write as joining.
  const results = await db().batch([
    db()
      .prepare(`
    INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at)
    SELECT d.id,d.name,d.phone,i.fleet_id,'driver',? FROM mobility_drivers d
    JOIN mobility_fleet_invites i ON i.token_hash=? AND i.expires_at>?
    JOIN mobility_fleets f ON f.id=i.fleet_id
    JOIN mobility_employees inviter ON inviter.user_id=i.inviter_id AND inviter.fleet_id=f.id
    WHERE d.id=? AND (f.owner_id=i.inviter_id OR f.deputy_id=i.inviter_id)
    AND NOT EXISTS(SELECT 1 FROM mobility_employees e WHERE e.user_id=d.id AND e.fleet_id IS NOT NULL AND e.fleet_id<>i.fleet_id)
    AND NOT EXISTS(SELECT 1 FROM mobility_fleets owned WHERE owned.owner_id=d.id OR owned.deputy_id=d.id)
    AND ${driverIdle('d')}
    ON CONFLICT(user_id) DO UPDATE SET fleet_id=excluded.fleet_id,role='driver' WHERE mobility_employees.fleet_id IS NULL
  `)
      .bind(now, hash, now, userId),
    db()
      .prepare(
        `UPDATE mobility_drivers SET approved=0,vehicle_id=NULL,vehicle='',plate='',services='[]',session_id=NULL WHERE id=? AND changes()>0 AND ${driverIdle('mobility_drivers')}`,
      )
      .bind(userId),
    db()
      .prepare(
        "UPDATE mobility_offers SET status='withdrawn' WHERE driver_id=? AND status='pending' AND changes()>0",
      )
      .bind(userId),
  ]);
  if (!results[0].meta.changes)
    throw new ApiError(
      409,
      'Einladung abgelaufen oder Beitritt nicht möglich. Bitte Fahrerprofil, Flottenzuordnung und laufende Fahrt prüfen.',
    );
  return {
    ok: true,
    message:
      'Flotte beigetreten. Die Flottenleitung prüft dein Profil. Wähle nach der Freigabe dein Fahrzeug.',
  };
}
