import { driverIdle } from './vehicles';
import { ApiError, db, tokenHash } from './server';
import { audit } from './accounts';
export async function createFleetInvite(userId: string, fleetId: string) {
  const code = 'LX-' + crypto.randomUUID().replaceAll('-', '').toUpperCase();
  const hash = await tokenHash(code);
  return db().writeTransaction(async (transaction) => {
    const fleet = await transaction
      .prepare(`SELECT f.id,f.name FROM mobility_fleets f
      JOIN mobility_employees e ON e.fleet_id=f.id AND e.user_id=?
      WHERE f.id=? AND (f.owner_id=? OR f.deputy_id=?)
      AND NOT EXISTS(SELECT 1 FROM mobility_accounts a WHERE a.id=e.user_id AND a.status<>'active')`)
      .bind(userId, fleetId, userId, userId)
      .first<{ id: string; name: string }>();
    if (!fleet)
      throw new ApiError(
        403,
        'Nur die aktive Leitung dieser Flotte kann Einladungen ausstellen.',
      );
    const now = Date.now(),
      expiresAt = now + 86400000;
    await transaction.batch([
      transaction
        .prepare('DELETE FROM mobility_fleet_invites WHERE expires_at<=?')
        .bind(now),
      transaction
        .prepare(
          'INSERT INTO mobility_fleet_invites(token_hash,fleet_id,inviter_id,expires_at) VALUES(?,?,?,?)',
        )
        .bind(hash, fleetId, userId, expiresAt),
    ]);
    await audit(userId, fleetId, 'fleet.invite_created', () => transaction);
    return {
      ok: true,
      code,
      expiresAt,
      shareText: `Einladung zu ${fleet.name}\n\nCode: ${code}\n\n24 Stunden gültig. Öffne Luxóre Driver, lege dein Fahrerprofil an und wähle „Flotte beitreten“. Die Flottenleitung prüft und aktiviert anschließend dein Profil.`,
    };
  });
}
export async function joinFleet(userId: string, code: string) {
  if (!/^LX-[A-F0-9]{32}$/.test(code))
    throw new ApiError(400, 'Dieser Einladungscode ist ungültig.');
  const hash = await tokenHash(code);
  return db().writeTransaction(async (transaction) => {
    const now = Date.now();
    if (
      await transaction
        .prepare(
          "SELECT id FROM mobility_accounts WHERE id=? AND status<>'active'",
        )
        .bind(userId)
        .first()
    )
      throw new ApiError(
        403,
        'Dein Konto ist nicht aktiv. Bitte erneut anmelden.',
      );
    const invite = await transaction
      .prepare(`SELECT i.fleet_id FROM mobility_fleet_invites i
      JOIN mobility_fleets f ON f.id=i.fleet_id
      JOIN mobility_employees inviter ON inviter.user_id=i.inviter_id AND inviter.fleet_id=f.id
      WHERE i.token_hash=? AND i.expires_at>? AND (f.owner_id=i.inviter_id OR f.deputy_id=i.inviter_id)
      AND NOT EXISTS(SELECT 1 FROM mobility_accounts a WHERE a.id=i.inviter_id AND a.status<>'active')`)
      .bind(hash, now)
      .first<{ fleet_id: string }>();
    const conflict = () =>
      new ApiError(
        409,
        'Einladung abgelaufen oder Beitritt nicht möglich. Bitte Fahrerprofil, Flottenzuordnung und laufende Fahrt prüfen.',
      );
    if (!invite) throw conflict();
    if (
      !(await transaction
        .prepare('SELECT id FROM mobility_drivers WHERE id=?')
        .bind(userId)
        .first()) ||
      (await transaction
        .prepare(
          'SELECT id FROM mobility_fleets WHERE owner_id=? OR deputy_id=?',
        )
        .bind(userId, userId)
        .first())
    )
      throw conflict();
    const member = await transaction
      .prepare('SELECT fleet_id FROM mobility_employees WHERE user_id=?')
      .bind(userId)
      .first<{ fleet_id: string | null }>();
    // Only confirm the current same-fleet state. Never reset a later approval,
    // car selection or GPS shift when the original response was lost.
    if (member?.fleet_id === invite.fleet_id)
      return {
        ok: true,
        replayed: true,
        message: 'Du bist bereits Mitglied dieser Flotte.',
      };
    if (member?.fleet_id) throw conflict();
    const results = await transaction.batch([
      transaction
        .prepare(`INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at)
      SELECT d.id,d.name,d.phone,i.fleet_id,'driver',? FROM mobility_drivers d
      JOIN mobility_fleet_invites i ON i.token_hash=? AND i.expires_at>?
      JOIN mobility_fleets f ON f.id=i.fleet_id
      JOIN mobility_employees inviter ON inviter.user_id=i.inviter_id AND inviter.fleet_id=f.id
      WHERE d.id=? AND (f.owner_id=i.inviter_id OR f.deputy_id=i.inviter_id)
      AND NOT EXISTS(SELECT 1 FROM mobility_employees e WHERE e.user_id=d.id AND e.fleet_id IS NOT NULL)
      AND NOT EXISTS(SELECT 1 FROM mobility_fleets owned WHERE owned.owner_id=d.id OR owned.deputy_id=d.id)
      AND NOT EXISTS(SELECT 1 FROM mobility_accounts a WHERE a.id IN (d.id,i.inviter_id) AND a.status<>'active')
      AND ${driverIdle('d')}
      ON CONFLICT(user_id) DO UPDATE SET fleet_id=excluded.fleet_id,role='driver' WHERE mobility_employees.fleet_id IS NULL`)
        .bind(now, hash, now, userId),
      transaction
        .prepare(
          `UPDATE mobility_drivers SET approved=0,vehicle_id=NULL,vehicle='',plate='',services='[]',session_id=NULL WHERE id=? AND changes()>0 AND ${driverIdle('mobility_drivers')}`,
        )
        .bind(userId),
      transaction
        .prepare(
          "UPDATE mobility_offers SET status='withdrawn' WHERE driver_id=? AND status='pending' AND changes()>0",
        )
        .bind(userId),
    ]);
    if (!results[0].meta.changes) throw conflict();
    await audit(userId, userId, 'fleet.member_joined', () => transaction);
    return {
      ok: true,
      message:
        'Flotte beigetreten. Die Flottenleitung prüft dein Profil. Wähle nach der Freigabe dein Fahrzeug.',
    };
  });
}
