import { coordinate } from './domain';
import { freshLocation } from './location';
import { ApiError, db, text } from './server';
import { vehicleEligible } from './vehicles';

export async function saveDriverHeartbeat(
  userId: string,
  point: Record<string, unknown>,
  now: number,
) {
  // Preserve the legacy optional timestamp and the existing raw GPS guards.
  if (point.timestamp !== undefined && !freshLocation(point, now))
    throw new ApiError(
      400,
      'Der GPS-Standort ist veraltet oder ungenau. Bitte Standort aktualisieren.',
    );
  if (
    !coordinate(point.lat, point.lng) ||
    typeof point.accuracy !== 'number' ||
    !Number.isFinite(point.accuracy) ||
    point.accuracy < 0 ||
    point.accuracy > 100
  )
    throw new ApiError(
      400,
      'Der Standort ist zu ungenau. Bitte GPS aktivieren und erneut versuchen.',
    );
  const sessionId = text(point.sessionId);
  await db().writeTransaction(async (transaction) => {
    // Authentication/profile reads can predate an account block or withdrawal.
    // Legacy authenticated drivers without a local account row remain valid.
    if (
      await transaction
        .prepare(
          "SELECT id FROM mobility_accounts WHERE id=? AND status<>'active'",
        )
        .bind(userId)
        .first()
    )
      throw new ApiError(
        403,
        'Dein Konto ist nicht aktiv. Bitte erneut anmelden.',
      );
    const driver = await transaction
      .prepare('SELECT approved FROM mobility_drivers WHERE id=?')
      .bind(userId)
      .first<{ approved: number }>();
    if (!driver?.approved)
      throw new ApiError(
        403,
        'Dein Fahrerprofil muss zuerst von der Disposition freigegeben werden.',
      );
    const saved = await transaction
      .prepare(
        `UPDATE mobility_drivers SET lat=?,lng=?,accuracy=?,location_at=?,online=1 WHERE id=? AND approved=1 AND session_id=? AND ${vehicleEligible('mobility_drivers')}`,
      )
      .bind(point.lat, point.lng, point.accuracy, now, userId, sessionId)
      .run();
    if (saved.meta.changes !== 1)
      throw new ApiError(
        409,
        'Diese Standortfreigabe ist beendet. Bitte erneut online gehen.',
      );
  });
}
