import { coordinate } from './domain.ts';

export const DRIVER_SEARCH_RADIUS_METERS = 50_000;

// SQL only removes points outside the spherical bounding box. The final ranking
// still uses exact great-circle distance, with no arbitrary driver-count cutoff.
export function driverSearchArea(pickup: { lat: number; lng: number }) {
  if (!coordinate(pickup.lat, pickup.lng))
    throw new Error('Ungültiger Abholpunkt.');
  const radians = Math.PI / 180;
  const angularRadius = DRIVER_SEARCH_RADIUS_METERS / 6_371_000;
  const latitudeDelta = angularRadius / radians;
  const latitudeMin = Math.max(-90, pickup.lat - latitudeDelta - 1e-9);
  const latitudeMax = Math.min(90, pickup.lat + latitudeDelta + 1e-9);
  const parameters = [latitudeMin, latitudeMax];
  let sql = 'd.lat BETWEEN ? AND ?';
  if (latitudeMin === -90 || latitudeMax === 90) return { sql, parameters };
  const longitudeDelta =
    Math.asin(
      Math.min(1, Math.sin(angularRadius) / Math.cos(pickup.lat * radians)),
    ) /
      radians +
    1e-9;
  const longitudeMin = pickup.lng - longitudeDelta;
  const longitudeMax = pickup.lng + longitudeDelta;
  if (longitudeMin < -180) {
    sql += ' AND (d.lng >= ? OR d.lng <= ?)';
    parameters.push(longitudeMin + 360, longitudeMax);
  } else if (longitudeMax > 180) {
    sql += ' AND (d.lng >= ? OR d.lng <= ?)';
    parameters.push(longitudeMin, longitudeMax - 360);
  } else {
    sql += ' AND d.lng BETWEEN ? AND ?';
    parameters.push(longitudeMin, longitudeMax);
  }
  return { sql, parameters };
}
