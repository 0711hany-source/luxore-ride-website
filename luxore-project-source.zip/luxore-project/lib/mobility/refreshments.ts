import type { Service } from './domain';
// Version 1 prices remain fixed for existing orders; add a new version for future tariff changes.
export const menu = [
  {
    id: 'water',
    name: 'Wasser still',
    detail: '0,5 l',
    group: 'drink',
    cents: 250,
  },
  {
    id: 'sparkling',
    name: 'Wasser sprudel',
    detail: '0,5 l',
    group: 'drink',
    cents: 250,
  },
  { id: 'cola', name: 'Cola', detail: '0,33 l', group: 'drink', cents: 250 },
  {
    id: 'cola-zero',
    name: 'Cola Zero',
    detail: '0,33 l · ohne Zucker',
    group: 'drink',
    cents: 250,
  },
  {
    id: 'apple',
    name: 'Apfelschorle',
    detail: '0,33 l',
    group: 'drink',
    cents: 250,
  },
  {
    id: 'energy',
    name: 'Energy Drink',
    detail: '0,25 l · koffeinhaltig',
    group: 'drink',
    cents: 250,
  },
  {
    id: 'pretzels',
    name: 'Salzstangen',
    detail: 'Kleine Packung · enthält Gluten',
    group: 'snack',
    cents: 150,
  },
  {
    id: 'trail-mix',
    name: 'Studentenfutter',
    detail: 'Kleine Packung · enthält Nüsse',
    group: 'snack',
    cents: 150,
  },
  {
    id: 'fruit-bar',
    name: 'Fruchtriegel',
    detail: 'Einzeln verpackt',
    group: 'snack',
    cents: 150,
  },
  {
    id: 'cookies',
    name: 'Mini-Kekse',
    detail: 'Kleine Packung · enthält Gluten',
    group: 'snack',
    cents: 150,
  },
] as const;
export type Cart = Record<string, number>;
export type RefreshmentOrder = {
  version: 1;
  revision: number;
  requested: Cart;
  delivered: Cart;
  unavailable: Cart;
};
export const allowance = {
  premium: { drink: 2, snack: 0 },
  first: { drink: 4, snack: 2 },
  van: { drink: 4, snack: 1 },
};
export const emptyOrder = (): RefreshmentOrder => ({
  version: 1,
  revision: 0,
  requested: {},
  delivered: {},
  unavailable: {},
});
export function parseCart(value: unknown): Cart {
  if (value === undefined) return {};
  if (!value || typeof value !== 'object' || Array.isArray(value))
    throw new Error('Bitte eine gültige Bordbestellung auswählen.');
  const result: Cart = {};
  for (const [id, quantity] of Object.entries(value)) {
    if (
      !menu.some((i) => i.id === id) ||
      !Number.isInteger(quantity) ||
      quantity < 0 ||
      quantity > 12
    )
      throw new Error('Ungültiger Artikel oder ungültige Menge.');
    if (quantity) result[id] = quantity;
  }
  if (countCart(result) > 24) throw new Error('Maximal 24 Artikel pro Fahrt.');
  return result;
}
export const countCart = (cart: Cart) =>
  Object.values(cart).reduce((sum, n) => sum + n, 0);
export function combined(a: Cart, b: Cart): Cart {
  return Object.fromEntries(
    menu
      .map((i) => [i.id, (a[i.id] || 0) + (b[i.id] || 0)])
      .filter(([, n]) => Number(n) > 0),
  );
}
export function cartPrice(cart: Cart, service: Service) {
  const quantities = { drink: 0, snack: 0 };
  for (const item of menu) quantities[item.group] += cart[item.id] || 0;
  return (
    Math.max(0, quantities.drink - allowance[service].drink) * 250 +
    Math.max(0, quantities.snack - allowance[service].snack) * 150
  );
}
export function storedOrder(value: unknown): RefreshmentOrder {
  if (!value) return emptyOrder();
  const v = typeof value === 'string' ? JSON.parse(value) : value;
  if (v.version !== 1 || !Number.isInteger(v.revision) || v.revision < 0)
    throw new Error('Ungültige Bordbestellung.');
  return {
    version: 1,
    revision: v.revision,
    requested: parseCart(v.requested),
    delivered: parseCart(v.delivered),
    unavailable: parseCart(v.unavailable),
  };
}
export function updateOrder(
  order: RefreshmentOrder,
  action: 'request' | 'deliver' | 'unavailable',
  data: { cart?: unknown; itemId?: unknown; quantity?: unknown },
): RefreshmentOrder {
  const next = structuredClone(order);
  if (action === 'request') {
    next.requested = parseCart(data.cart);
    parseCart(combined(next.delivered, next.requested));
    next.unavailable = {};
  } else {
    const id = String(data.itemId);
    const quantity = data.quantity;
    if (!menu.some((item) => item.id === id))
      throw new Error('Unbekannter Bordartikel.');
    if (
      !Number.isInteger(quantity) ||
      Number(quantity) < 1 ||
      Number(quantity) > (next.requested[id] || 0)
    )
      throw new Error('Diese Menge ist nicht mehr offen.');
    next.requested[id] -= Number(quantity);
    if (!next.requested[id]) delete next.requested[id];
    const target = action === 'deliver' ? next.delivered : next.unavailable;
    target[id] = (target[id] || 0) + Number(quantity);
  }
  next.revision++;
  return next;
}
export function cartLabel(cart: Cart) {
  return menu
    .filter((i) => cart[i.id])
    .map((i) => `${cart[i.id]} × ${i.name}`)
    .join(', ');
}
