import { ApiError, settings } from './server';
import { geocode } from './provider';
import { permanentGeocode } from './geocoding-cache';
import { geoapifyGeocode } from './geoapify';
import { permanentDailyLimit, type GeocodeQuery } from './geocoding-policy';

/** Mapbox first when licensed booking-address confirmation is enabled. */
export async function bookingGeocode(query: GeocodeQuery, preview: boolean) {
  const fallbackReady = Boolean(settings().GEOAPIFY_API_KEY);
  // Keep suggestions and their confirmation on the same licensed provider.
  // A temporary Mapbox result cannot be saved as a permanent booking address.
  if (
    fallbackReady &&
    !permanentDailyLimit(settings().MAPBOX_PERMANENT_DAILY_LIMIT)
  )
    return geoapifyGeocode(query);
  try {
    const points = preview
      ? await geocode(query, false, true)
      : await permanentGeocode(query);
    if (points.length || !fallbackReady) return points;
  } catch (error) {
    // Validation and cache-lease conflicts must not switch the chosen address
    // or consume another provider's quota. Never fall back in the paid direction.
    if (
      !fallbackReady ||
      !(error instanceof ApiError) ||
      (error.status !== 429 && error.status < 500)
    )
      throw error;
  }
  return geoapifyGeocode(query);
}
