import type { AppUser } from '@/lib/identity';
import { db, ApiError } from './server';
import { operatorScope } from './fleets';
import {
  defaultStock,
  shoppingList,
  type Stock,
  type StockRow,
} from './inventory';

export async function stockVehicles(user: AppUser) {
  const scope = await operatorScope(user);
  const rows = await db()
    .prepare(`SELECT v.id,v.plate,v.model,v.fleet_id FROM mobility_vehicles v
    WHERE v.status='active' AND (?='all' OR v.fleet_id=? OR EXISTS(
      SELECT 1 FROM mobility_drivers d JOIN mobility_employees e ON e.user_id=d.id AND e.fleet_id=v.fleet_id
      WHERE d.id=? AND d.approved=1 AND d.vehicle_id=v.id)) ORDER BY v.plate`)
    .bind(scope, scope, user.userId)
    .all<{ id: string; plate: string; model: string; fleet_id: string }>();
  return rows.results;
}
export async function stockFor(vehicleId: string) {
  return db()
    .prepare('SELECT * FROM mobility_stock WHERE vehicle_id=?')
    .bind(vehicleId)
    .first<StockRow>();
}
export async function stockReminder(vehicleId: string | null) {
  if (!vehicleId) return null;
  const row = await stockFor(vehicleId);
  if (!row) return { initialized: false, urgent: 0, missing: 0 };
  const list = shoppingList(JSON.parse(row.data) as Stock);
  return {
    initialized: true,
    urgent: list.filter((i) => i.urgent).length,
    missing: list.reduce((n, i) => n + i.quantity, 0),
  };
}
export async function inventoryView(
  user: AppUser,
  vehicleId?: string,
  fleetId?: string,
) {
  const vehicles = (await stockVehicles(user)).filter(
    (v) => !fleetId || v.fleet_id === fleetId,
  );
  const selected = vehicleId
    ? vehicles.find((v) => v.id === vehicleId)
    : vehicles[0];
  if (!selected)
    throw new ApiError(
      vehicleId ? 403 : 409,
      'Bitte zuerst ein freigegebenes Fahrzeug deiner Flotte auswählen.',
    );
  const row = await stockFor(selected.id);
  const movements = await db()
    .prepare(
      'SELECT actor_name,kind,note,details,created_at FROM mobility_stock_movements WHERE vehicle_id=? ORDER BY created_at DESC LIMIT 25',
    )
    .bind(selected.id)
    .all();
  return {
    vehicles,
    vehicleId: selected.id,
    initialized: !!row,
    revision: row?.revision ?? 0,
    stock: row ? (JSON.parse(row.data) as Stock) : defaultStock(),
    movements: movements.results,
  };
}
