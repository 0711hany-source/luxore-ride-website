/** Photo rules for papers and vehicle checks. Stored in the existing database. */
export const MAX_IMAGE_BYTES = 400 * 1024;
export const MAX_IMAGE_EDGE = 1600;
export const MAX_DOCUMENT_IMAGES = 4;
export const MAX_INSPECTION_IMAGES = 6;
export type ImageMime = 'image/jpeg' | 'image/png' | 'image/webp';

/** Decides the type from the file's first bytes, never from a header or name. */
export function sniffImage(bytes: Uint8Array): ImageMime | null {
  if (bytes.length < 12) return null;
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff)
    return 'image/jpeg';
  if (
    [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a].every(
      (v, i) => bytes[i] === v,
    )
  )
    return 'image/png';
  const ascii = (from: number) =>
    String.fromCharCode(...bytes.subarray(from, from + 4));
  if (ascii(0) === 'RIFF' && ascii(8) === 'WEBP') return 'image/webp';
  return null;
}
/** Returns the accepted type or a German reason for refusing the upload. */
export function checkImage(
  bytes: Uint8Array,
): { mime: ImageMime } | { error: string; status: number } {
  if (!bytes.length) return { error: 'Das Foto ist leer.', status: 400 };
  if (bytes.length > MAX_IMAGE_BYTES)
    return {
      error: 'Das Foto ist zu groß (höchstens 400 KB). Bitte erneut aufnehmen.',
      status: 413,
    };
  const mime = sniffImage(bytes);
  return mime
    ? { mime }
    : {
        error: 'Nur Fotos im Format JPEG, PNG oder WebP sind erlaubt.',
        status: 415,
      };
}
