import type { SqlDatabase } from '@/db/sqlite';
import { ApiError } from './server';

import {
  RATING_COMMENT_MAX,
  RATING_PUBLIC_MIN,
  RATING_WINDOW_MS,
} from './rating-rules';
export { RATING_COMMENT_MAX, RATING_PUBLIC_MIN, RATING_WINDOW_MS };
export type RaterRole = 'customer' | 'driver';
export type RatingSummary = { average: number; count: number };

const round1 = (value: number) => Math.round(value * 10) / 10;
/** Pure: what customers may see. Below the minimum nothing is shown ("Neu"). */
export function publicRating(
  count: number,
  average: number | null,
): RatingSummary | null {
  return count >= RATING_PUBLIC_MIN && average !== null
    ? { average: round1(average), count }
    : null;
}
/** All ratings a person received in one role; null when there are none. */
export async function ratingSummary(
  database: SqlDatabase,
  subjectId: string,
  raterRole: RaterRole,
): Promise<RatingSummary | null> {
  const row = await database
    .prepare(
      'SELECT COUNT(*) AS count,AVG(stars) AS average FROM mobility_ratings WHERE subject_id=? AND rater_role=?',
    )
    .bind(subjectId, raterRole)
    .first<{ count: number; average: number | null }>();
  const count = Number(row?.count || 0);
  return count && row?.average != null
    ? { average: round1(Number(row.average)), count }
    : null;
}
/** The driver's rating as customers see it: only from three ratings. */
export async function driverPublicRating(
  database: SqlDatabase,
  driverId: string,
) {
  const all = await ratingSummary(database, driverId, 'customer');
  return all ? publicRating(all.count, all.average) : null;
}
/** Stars the caller has given, keyed by booking. Never anyone else's. */
export async function givenRatings(database: SqlDatabase, raterId: string) {
  const rows = await database
    .prepare(
      'SELECT booking_id,stars FROM mobility_ratings WHERE rater_id=? ORDER BY created_at DESC LIMIT 300',
    )
    .bind(raterId)
    .all<{ booking_id: string; stars: number }>();
  return Object.fromEntries(
    rows.results.map((r) => [r.booking_id, Number(r.stars)]),
  ) as Record<string, number>;
}
export function parseStars(value: unknown) {
  if (!Number.isInteger(value) || (value as number) < 1 || (value as number) > 5)
    throw new ApiError(400, 'Bitte 1 bis 5 Sterne vergeben.');
  return value as number;
}
export function parseComment(value: unknown) {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value !== 'string' || value.length > RATING_COMMENT_MAX)
    throw new ApiError(
      400,
      `Der Kommentar darf höchstens ${RATING_COMMENT_MAX} Zeichen haben.`,
    );
  return value.trim() || null;
}
/**
 * Stores one rating. Only the customer or the driver of a completed ride,
 * within 14 days of its end, once per side; never changed afterwards.
 */
export async function rate(
  database: SqlDatabase,
  userId: string,
  bookingId: string,
  stars: number,
  comment: string | null,
  now = Date.now(),
) {
  const booking = await database
    .prepare(
      'SELECT owner_id,driver_id,status,completed_at FROM mobility_bookings WHERE id=?',
    )
    .bind(bookingId)
    .first<{
      owner_id: string;
      driver_id: string | null;
      status: string;
      completed_at: number | null;
    }>();
  const role: RaterRole | null = !booking
    ? null
    : booking.owner_id === userId
      ? 'customer'
      : booking.driver_id === userId
        ? 'driver'
        : null;
  // Unknown and foreign rides answer alike.
  if (!booking || !role) throw new ApiError(404, 'Fahrt nicht gefunden.');
  if (
    booking.status !== 'completed' ||
    !booking.completed_at ||
    !booking.driver_id
  )
    throw new ApiError(
      409,
      'Eine Bewertung ist erst nach abgeschlossener Fahrt möglich.',
    );
  if (now - Number(booking.completed_at) > RATING_WINDOW_MS)
    throw new ApiError(
      409,
      'Die Frist von 14 Tagen für eine Bewertung ist abgelaufen.',
    );
  const subjectId = role === 'customer' ? booking.driver_id : booking.owner_id;
  // The ride's state is re-checked in the insert itself; the unique index
  // (booking, side) lets exactly one of two concurrent ratings through.
  const saved = await database
    .prepare(
      `INSERT INTO mobility_ratings(id,booking_id,rater_role,rater_id,subject_id,stars,comment,created_at)
       SELECT ?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM mobility_bookings WHERE id=? AND status='completed' AND completed_at IS NOT NULL AND completed_at>=?
       AND ((?='customer' AND owner_id=?) OR (?='driver' AND driver_id=?)))
       ON CONFLICT(booking_id,rater_role) DO NOTHING`,
    )
    .bind(
      crypto.randomUUID(),
      bookingId,
      role,
      userId,
      subjectId,
      stars,
      comment,
      now,
      bookingId,
      now - RATING_WINDOW_MS,
      role,
      userId,
      role,
      userId,
    )
    .run();
  if (!saved.meta.changes)
    throw new ApiError(
      409,
      'Diese Fahrt hast du bereits bewertet. Eine Bewertung kann nicht geändert werden.',
    );
  return { role, stars };
}
type CommentRow = {
  subject_id: string;
  stars: number;
  comment: string;
  created_at: number;
};
const grouped = (rows: CommentRow[], perSubject = 5) => {
  const map = new Map<
    string,
    { stars: number; comment: string; createdAt: number }[]
  >();
  for (const row of rows) {
    const list = map.get(row.subject_id) || [];
    if (list.length < perSubject)
      list.push({
        stars: Number(row.stars),
        comment: row.comment,
        createdAt: Number(row.created_at),
      });
    map.set(row.subject_id, list);
  }
  return map;
};
/**
 * Overview for the operator ('all') or one fleet lead (fleet id): every driver
 * with average, count and the latest comments; and the customers that drivers
 * of this scope have rated.
 */
export async function ratingsOverview(database: SqlDatabase, scope: string) {
  const drivers = await database
    .prepare(
      `SELECT d.id,d.name,f.name AS fleet_name,COUNT(r.id) AS count,AVG(r.stars) AS average
       FROM mobility_drivers d LEFT JOIN mobility_employees e ON e.user_id=d.id LEFT JOIN mobility_fleets f ON f.id=e.fleet_id
       LEFT JOIN mobility_ratings r ON r.subject_id=d.id AND r.rater_role='customer'
       WHERE ?='all' OR e.fleet_id=? GROUP BY d.id ORDER BY d.name LIMIT 300`,
    )
    .bind(scope, scope)
    .all<{
      id: string;
      name: string;
      fleet_name: string | null;
      count: number;
      average: number | null;
    }>();
  const driverComments = grouped(
    (
      await database
        .prepare(
          `SELECT r.subject_id,r.stars,r.comment,r.created_at FROM mobility_ratings r
           WHERE r.rater_role='customer' AND r.comment IS NOT NULL AND r.comment<>''
           AND (?='all' OR EXISTS(SELECT 1 FROM mobility_employees e WHERE e.user_id=r.subject_id AND e.fleet_id=?))
           ORDER BY r.created_at DESC LIMIT 500`,
        )
        .bind(scope, scope)
        .all<CommentRow>()
    ).results,
  );
  const customers = await database
    .prepare(
      `SELECT r.subject_id AS id,COUNT(*) AS count,AVG(r.stars) AS average,
       (SELECT b2.rider_name FROM mobility_bookings b2 WHERE b2.owner_id=r.subject_id AND b2.rider_name IS NOT NULL ORDER BY b2.created_at DESC LIMIT 1) AS name
       FROM mobility_ratings r JOIN mobility_bookings b ON b.id=r.booking_id
       WHERE r.rater_role='driver' AND (?='all' OR b.fleet_id=?) GROUP BY r.subject_id ORDER BY MAX(r.created_at) DESC LIMIT 200`,
    )
    .bind(scope, scope)
    .all<{
      id: string;
      count: number;
      average: number | null;
      name: string | null;
    }>();
  const customerComments = grouped(
    (
      await database
        .prepare(
          `SELECT r.subject_id,r.stars,r.comment,r.created_at FROM mobility_ratings r JOIN mobility_bookings b ON b.id=r.booking_id
           WHERE r.rater_role='driver' AND r.comment IS NOT NULL AND r.comment<>'' AND (?='all' OR b.fleet_id=?)
           ORDER BY r.created_at DESC LIMIT 500`,
        )
        .bind(scope, scope)
        .all<CommentRow>()
    ).results,
  );
  const summary = (count: number, average: number | null) => ({
    count: Number(count),
    average:
      Number(count) && average !== null ? round1(Number(average)) : null,
  });
  return {
    drivers: drivers.results.map((d) => ({
      id: d.id,
      name: d.name,
      fleetName: d.fleet_name,
      ...summary(d.count, d.average),
      comments: driverComments.get(d.id) || [],
    })),
    customers: customers.results.map((c) => ({
      id: c.id,
      name: c.name || 'Fahrgast',
      ...summary(c.count, c.average),
      comments: customerComments.get(c.id) || [],
    })),
  };
}
