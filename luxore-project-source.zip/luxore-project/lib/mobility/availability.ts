import type { SqlDatabase } from '@/db/sqlite';
import { vehicleEligible } from './vehicles.ts';
import { isService, services, type Service } from './domain.ts';
import { FRESH_MS } from './dispatch.ts';
/**
 * Same yardstick as dispatch: approved, active vehicle, shift running, fresh
 * and precise location, no running ride and no uncollected payment. One bind
 * parameter: the freshness limit (now - FRESH_MS). Aliases are constants.
 */
export function freeOnlineDriver(alias: string) {
  return `${vehicleEligible(alias)} AND ${alias}.approved=1 AND ${alias}.online=1 AND ${alias}.lat IS NOT NULL AND ${alias}.lng IS NOT NULL AND ${alias}.accuracy<=100 AND ${alias}.location_at>? AND NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.driver_id=${alias}.id AND (b.status IN ('accepted','arrived','riding') OR (b.status='completed' AND b.completed_at IS NOT NULL AND b.payment_status='unpaid')))`;
}
/**
 * True/false per class only: never positions, names or counts. One database
 * read, no map-provider request. The search radius around a pickup point is
 * deliberately not applied here.
 */
export async function classAvailability(
  db: SqlDatabase,
  now = Date.now(),
): Promise<Record<Service, boolean>> {
  const rows = await db
    .prepare(
      `SELECT DISTINCT j.value AS service FROM mobility_drivers d, json_each(COALESCE(d.services,json_array(d.service))) j WHERE ${freeOnlineDriver('d')}`,
    )
    .bind(now - FRESH_MS)
    .all<{ service: string }>();
  const online = new Set(rows.results.map((r) => r.service).filter(isService));
  return Object.fromEntries(
    services.map((s) => [s, online.has(s)]),
  ) as Record<Service, boolean>;
}
