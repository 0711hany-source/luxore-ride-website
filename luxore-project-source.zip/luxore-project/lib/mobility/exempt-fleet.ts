/**
 * Decision of the operator (18.11.2026): the main fleet has no review area
 * for now — no papers, no weekly check, no hints. Explicit holds (a blocked
 * driver, car or fleet) still apply. Remove the id here to end the exception.
 */
export const EXEMPT_FLEET_IDS: readonly string[] = ['luxore-frankfurt'];
export const isExemptFleet = (fleetId: string | null | undefined) =>
  !!fleetId && EXEMPT_FLEET_IDS.includes(fleetId);
