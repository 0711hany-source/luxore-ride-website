import type { AppUser } from '@/lib/identity';
import { ApiError, db, isAdmin } from './server';
import { audit } from './accounts';
import { driverIdle } from './vehicles';

export async function createFleet(
  user: AppUser,
  id: string,
  name: string,
  ownerId: string,
): Promise<{ id: string; name: string; replayed?: true }> {
  return db().writeTransaction(async (transaction) => {
    if (!isAdmin(user))
      throw new ApiError(
        403,
        'Flotten und Zuordnungen verwaltet der Plattformbetreiber.',
      );
    if (
      await transaction
        .prepare(
          "SELECT id FROM mobility_accounts WHERE id=? AND status<>'active'",
        )
        .bind(user.userId)
        .first()
    )
      throw new ApiError(
        403,
        'Dein Konto ist nicht aktiv. Bitte erneut anmelden.',
      );
    const existing = await transaction
      .prepare('SELECT id,name,owner_id FROM mobility_fleets WHERE id=?')
      .bind(id)
      .first<{ id: string; name: string; owner_id: string }>();
    if (existing) {
      if (existing.owner_id === ownerId && existing.name === name)
        return { id, name, replayed: true }; // Current record confirmation; never recreate membership or reset shifts.
      throw new ApiError(
        409,
        'Diese Speicheranfrage wurde bereits verarbeitet. Bitte die Flottenansicht aktualisieren.',
      );
    }
    if (
      await transaction
        .prepare(
          "SELECT id FROM mobility_accounts WHERE id=? AND status<>'active'",
        )
        .bind(ownerId)
        .first()
    )
      throw new ApiError(409, 'Dieses Konto ist gesperrt oder wird gelöscht.');
    const owner =
      ownerId === user.userId
        ? { name: user.displayName, phone: '' }
        : await transaction
            .prepare(
              'SELECT name,phone FROM mobility_employees WHERE user_id=? UNION ALL SELECT name,phone FROM mobility_drivers WHERE id=? LIMIT 1',
            )
            .bind(ownerId, ownerId)
            .first<{ name: string; phone: string }>();
    if (!owner)
      throw new ApiError(
        404,
        'Besitzer muss zuerst ein Mitarbeiter- oder Fahrerprofil einreichen.',
      );
    if (
      (await transaction
        .prepare(
          'SELECT user_id FROM mobility_employees WHERE user_id=? AND fleet_id IS NOT NULL',
        )
        .bind(ownerId)
        .first()) ||
      (await transaction
        .prepare(
          'SELECT id FROM mobility_fleets WHERE owner_id=? OR deputy_id=?',
        )
        .bind(ownerId, ownerId)
        .first()) ||
      (await transaction
        .prepare(
          `SELECT id FROM mobility_drivers WHERE id=? AND NOT (${driverIdle('mobility_drivers')})`,
        )
        .bind(ownerId)
        .first())
    )
      throw new ApiError(
        409,
        'Besitzer bereits zugeordnet oder noch im Einsatz. Bitte zuerst offline gehen und offene Fahrten abrechnen.',
      );
    const now = Date.now();
    await transaction
      .prepare(
        'INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES(?,?,?,?)',
      )
      .bind(id, name, ownerId, now)
      .run();
    await transaction
      .prepare(
        "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,?,?,?,'staff',?) ON CONFLICT(user_id) DO UPDATE SET fleet_id=excluded.fleet_id",
      )
      .bind(ownerId, owner.name, owner.phone, id, now)
      .run();
    await audit(user.userId, ownerId, 'fleet.created', () => transaction);
    return { id, name };
  });
}
