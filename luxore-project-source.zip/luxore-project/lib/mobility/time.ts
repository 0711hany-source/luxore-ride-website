/** Midnight in Frankfurt's calendar day, including 23/25-hour DST days. */
export function berlinDayStart(now = Date.now()) {
  const fmt = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/Berlin',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  });
  const parts = (t: number) =>
    Object.fromEntries(fmt.formatToParts(t).map((p) => [p.type, p.value]));
  const day = parts(now);
  const target = Date.UTC(+day.year, +day.month - 1, +day.day);
  let result = target;
  for (let i = 0; i < 3; i++) {
    const p = parts(result);
    const local = Date.UTC(
      +p.year,
      +p.month - 1,
      +p.day,
      +p.hour,
      +p.minute,
      +p.second,
    );
    result += target - local;
  }
  return result;
}
