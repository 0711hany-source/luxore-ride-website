export type AppUser = {
  userId: string;
  displayName: string;
  email: string;
  fullName: string | null;
};
