import test from 'node:test';
import assert from 'node:assert/strict';
import { validateVehicleInput } from '../lib/mobility/vehicle-input.ts';
const valid = {
  model: 'Mercedes-Benz E-Klasse',
  plate: 'GG HY 711',
  services: ['premium'],
};
void test('vehicle input normalizes mobile keyboard spacing, case and dashes and multiple classes', () => {
  const result = validateVehicleInput({
    model: ' Mercedes   E ',
    plate: ' gg‑hy\u00a0711 ',
    services: ['premium', 'first', 'premium'],
  });
  assert.deepEqual(result.value, {
    model: 'Mercedes E',
    plate: 'GG-HY 711',
    services: ['premium', 'first'],
  });
});
void test('invalid vehicle fields produce specific visible errors instead of a silent native validation block', () => {
  for (const [key, value] of [
    ['model', '   '],
    ['model', 'x'.repeat(81)],
    ['plate', '   '],
    ['plate', '-'],
    ['plate', 'x'.repeat(21)],
    ['services', []],
    ['services', ['taxi']],
    ['services', [['premium']]],
    ['services', [{ toString: () => 'premium' }]],
    ['services', [1]],
    ['services', [true]],
    ['services', null],
  ] as const) {
    const result = validateVehicleInput({ ...valid, [key]: value });
    assert.equal(result.value, null);
    assert.ok(result.errors[key]);
  }
});
void test('all existing classes and German characters remain supported', () => {
  assert.ok(
    validateVehicleInput({
      ...valid,
      plate: 'MÜ AB 12',
      services: ['van', 'premium', 'first'],
    }).value,
  );
  assert.equal(validateVehicleInput({}).value, null);
});
