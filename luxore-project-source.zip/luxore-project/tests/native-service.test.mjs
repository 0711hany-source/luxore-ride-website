import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import test from 'node:test';
import assert from 'node:assert/strict';
import { ForegroundRefresh } from '../mobile/src/foreground-refresh.ts';
let task;
globalThis.nativeTest = {
  defineTask: (_name, handler) => {
    task = handler;
  },
};
const virtual = (source) => ({
  url: 'data:text/javascript,' + encodeURIComponent(source),
  shortCircuit: true,
});
registerHooks({
  resolve(specifier, context, next) {
    if (specifier === 'expo-location')
      return virtual(
        `export const Accuracy={High:4,BestForNavigation:6};export const requestForegroundPermissionsAsync=async()=>({granted:true});export const getBackgroundPermissionsAsync=async()=>globalThis.nativeTest.permission;export const hasStartedLocationUpdatesAsync=async()=>globalThis.nativeTest.active;export const startLocationUpdatesAsync=(...a)=>globalThis.nativeTest.start(...a);export const stopLocationUpdatesAsync=async()=>{globalThis.nativeTest.active=false;};export const getCurrentPositionAsync=()=>new Promise(()=>{});`,
      );
    if (specifier === 'expo-task-manager')
      return virtual(
        `export const defineTask=(...a)=>globalThis.nativeTest.defineTask(...a);`,
      );
    if (specifier === 'expo-secure-store')
      return virtual(
        `export const getItemAsync=async key=>globalThis.nativeTest.store.get(key)||null;export const setItemAsync=async(key,value)=>{globalThis.nativeTest.store.set(key,value);};export const deleteItemAsync=async key=>{globalThis.nativeTest.store.delete(key);};`,
      );
    if (specifier === 'react-native')
      return virtual(
        `export const Alert={alert(){throw new Error('Unexpected permission dialog in test');}};`,
      );
    return next(specifier, context);
  },
  load(url, context, next) {
    if (url.endsWith('/mobile/src/offer-alerts.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `export const offerAlerts={clear:async()=>{},sync:async()=>{}};export const alertStatus=async()=>({granted:true});export const requestAlerts=async()=>{};`,
      };
    return next(url, context);
  },
});
const {
  startLocation,
  stopLocation,
  locationStatus,
  resumeLocation,
  deliverForeground,
} = await import('../mobile/src/location-service.ts');
const c = () => ({
  nativeToken: 'a'.repeat(64),
  sessionId: 'test-native-shift',
  expiresAt: Date.now() + 60000,
});
const originalFetch = globalThis.fetch;
function fixture() {
  const f = {
    store: new Map(),
    active: false,
    permission: { granted: true },
    starts: 0,
    start: async () => {
      f.starts++;
      f.active = true;
    },
  };
  globalThis.nativeTest = f;
  globalThis.fetch = async () =>
    Response.json({ ok: true, offer: null, serverTime: Date.now() });
  return f;
}
test('foreground recovery restores an existing shift before a slow account request returns', async () => {
  const f = fixture();
  f.store.set('luxore-driver-location-session', JSON.stringify(c()));
  let releaseAccount;
  const account = new Promise((resolve) => {
    releaseAccount = resolve;
  });
  let status;
  try {
    const foreground = new ForegroundRefresh().refresh(
      'test-account',
      () => account,
      async () => {
        status = await resumeLocation();
      },
    );
    await new Promise((resolve) => setImmediate(resolve));
    assert.equal(status?.active, true);
    assert.equal(f.starts, 1);
    assert.ok(f.store.has('luxore-driver-location-session'));
    releaseAccount();
    await foreground;
  } finally {
    releaseAccount();
    await stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
test('status during service startup is read-only and cannot delete a newly written shift', async () => {
  const f = fixture();
  let release;
  let enter;
  const ready = new Promise((resolve) => {
    enter = resolve;
  });
  f.start = async () => {
    enter();
    await new Promise((resolve) => {
      release = resolve;
    });
    f.active = true;
  };
  const starting = startLocation(c());
  await ready;
  assert.equal((await locationStatus()).active, false);
  assert.ok(f.store.has('luxore-driver-location-session'));
  release();
  assert.equal((await starting).active, true);
  await stopLocation(false);
  globalThis.fetch = originalFetch;
});
function fix(timestamp, lng = 8, accuracy = 6) {
  return {
    coords: { latitude: 50, longitude: lng, accuracy, heading: 90, speed: 8 },
    timestamp,
  };
}
test('native foreground and background share raw-fix quality: no stale, duplicate or jumping uploads', async () => {
  const f = fixture();
  f.store.set('luxore-driver-location-session', JSON.stringify(c()));
  f.active = true;
  const sent = [];
  globalThis.fetch = async (_url, request) => {
    sent.push(JSON.parse(request.body));
    return Response.json({ ok: true, offer: null, serverTime: Date.now() });
  };
  try {
    const time = Date.now() - 3000;
    await deliverForeground(fix(time));
    await task({ data: { locations: [fix(time), fix(time - 1000)] } });
    await task({ data: { locations: [fix(time + 1000, 9)] } });
    await deliverForeground(fix(time + 2000, 8.0001));
    assert.deepEqual(
      sent.map((p) => [p.timestamp, p.lng]),
      [
        [time, 8],
        [time + 2000, 8.0001],
      ],
    );
    assert.equal((await locationStatus()).position.lng, 8.0001);
  } finally {
    await stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
test('a delayed GPS batch keeps its newest plausible sample rather than an invalid final sample', async () => {
  const f = fixture();
  f.store.set('luxore-driver-location-session', JSON.stringify(c()));
  f.active = true;
  const sent = [];
  globalThis.fetch = async (_url, request) => {
    sent.push(JSON.parse(request.body));
    return Response.json({ ok: true, offer: null, serverTime: Date.now() });
  };
  try {
    const time = Date.now() - 3000;
    await deliverForeground(fix(time));
    await task({
      data: {
        locations: [
          fix(time + 2000, 9),
          fix(time + 1000, 8.0001),
          fix(Date.now() + 60000, 8),
        ],
      },
    });
    assert.equal(sent.length, 2);
    assert.equal(sent[1].timestamp, time + 1000);
    assert.equal((await locationStatus()).position.lng, 8.0001);
    for (const invalid of [
      fix(Date.now(), 181),
      fix(Date.now(), 8, -1),
      fix(Date.now(), NaN),
      fix(Date.now() - 31000),
      fix(Date.now(), 8, 101),
    ])
      await deliverForeground(invalid);
    assert.equal(sent.length, 2);
  } finally {
    await stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
test('expired or foreign shift cache cannot reject a fresh relocation; network loss retains the valid fix', async () => {
  const f = fixture();
  const credential = c();
  f.store.set('luxore-driver-location-session', JSON.stringify(credential));
  f.active = true;
  try {
    const time = Date.now() - 1000;
    f.store.set(
      'luxore-driver-background-position',
      JSON.stringify({
        sessionId: 'old-shift',
        position: { lat: 50, lng: 9, accuracy: 6, timestamp: time + 500 },
      }),
    );
    await deliverForeground(fix(time));
    assert.equal((await locationStatus()).position.lng, 8);
    f.store.set(
      'luxore-driver-background-position',
      JSON.stringify({
        sessionId: credential.sessionId,
        position: { lat: 50, lng: 9, accuracy: 6, timestamp: time - 31000 },
      }),
    );
    globalThis.fetch = async () => {
      throw new Error('synthetic network loss');
    };
    await assert.rejects(deliverForeground(fix(time + 100)), /network loss/);
    assert.equal((await locationStatus()).position.lng, 8);
    const sent = [];
    globalThis.fetch = async (_url, request) => {
      sent.push(JSON.parse(request.body));
      return Response.json({ ok: true, offer: null, serverTime: Date.now() });
    };
    await deliverForeground(fix(time + 200, 8.00001));
    assert.equal(sent.length, 1);
    assert.equal(sent[0].lng, 8.00001);
  } finally {
    await stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
test('simultaneous native callbacks cannot persist or send the same measurement twice', async () => {
  const f = fixture();
  f.store.set('luxore-driver-location-session', JSON.stringify(c()));
  f.active = true;
  let calls = 0;
  globalThis.fetch = async () => {
    calls++;
    return Response.json({ ok: true, offer: null, serverTime: Date.now() });
  };
  try {
    const location = fix(Date.now());
    await Promise.all([
      deliverForeground(location),
      task({ data: { locations: [location] } }),
    ]);
    assert.equal(calls, 1);
    assert.equal(
      (await locationStatus()).position.timestamp,
      location.timestamp,
    );
  } finally {
    await stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
test('returning to app recovers an interrupted native service, while a queued pause always wins', async () => {
  const f = fixture();
  f.store.set('luxore-driver-location-session', JSON.stringify(c()));
  let release;
  let enter;
  const ready = new Promise((resolve) => {
    enter = resolve;
  });
  f.start = async () => {
    enter();
    await new Promise((resolve) => {
      release = resolve;
    });
    f.active = true;
  };
  const recovery = resumeLocation();
  await ready;
  const pause = stopLocation(false);
  release();
  await recovery;
  await pause;
  assert.equal(f.active, false);
  assert.equal(f.store.has('luxore-driver-location-session'), false);
  assert.equal((await resumeLocation()).active, false);
  globalThis.fetch = originalFetch;
});
test('background fix is preserved through network loss and handed back fresh without another GPS query', async () => {
  const f = fixture();
  const credential = c();
  f.store.set('luxore-driver-location-session', JSON.stringify(credential));
  f.active = true;
  globalThis.fetch = async () => {
    throw new Error('synthetic network loss');
  };
  const timestamp = Date.now();
  await task({
    data: {
      locations: [
        {
          coords: {
            latitude: 50,
            longitude: 8.001,
            accuracy: 6,
            heading: 90,
            speed: 8,
          },
          timestamp,
        },
      ],
    },
  });
  const status = await locationStatus();
  assert.equal(status.active, true);
  assert.equal(status.position.timestamp, timestamp);
  assert.equal(status.position.lng, 8.001);
  await task({
    data: {
      locations: [
        {
          coords: { latitude: 50, longitude: 8, accuracy: 6 },
          timestamp: timestamp - 1000,
        },
      ],
    },
  });
  assert.equal((await locationStatus()).position.timestamp, timestamp);
  await stopLocation(false);
  assert.equal(f.store.has('luxore-driver-background-position'), false);
  globalThis.fetch = originalFetch;
});
