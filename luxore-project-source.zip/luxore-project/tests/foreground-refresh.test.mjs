import './support/tsx-loader.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import { ForegroundRefresh } from '../mobile/src/foreground-refresh.ts';

const deferred = () => {
  let resolve, reject;
  const promise = new Promise((yes, no) => {
    resolve = yes;
    reject = no;
  });
  return { promise, resolve, reject };
};
const tick = () => new Promise((resolve) => setImmediate(resolve));

test('foreground GPS recovery finishes while the account network is still pending', async () => {
  const refresh = new ForegroundRefresh();
  const account = deferred();
  let resumed = false,
    finished = false;
  const result = refresh
    .refresh(
      'session-a',
      () => account.promise,
      async () => {
        resumed = true;
      },
    )
    .then(() => {
      finished = true;
    });
  await tick();
  assert.equal(resumed, true);
  assert.equal(finished, false);
  account.resolve();
  await result;
});

test('repeated foreground events share in-flight work and a later foreground can retry', async () => {
  const refresh = new ForegroundRefresh();
  const account = deferred(),
    gps = deferred();
  let accounts = 0,
    locations = 0;
  const accountWork = () => {
    accounts++;
    return account.promise;
  };
  const locationWork = () => {
    locations++;
    return gps.promise;
  };
  const first = refresh.refresh('session-a', accountWork, locationWork);
  const second = refresh.refresh('session-a', accountWork, locationWork);
  await tick();
  assert.equal(accounts, 1);
  assert.equal(locations, 1);
  account.reject(new Error('offline'));
  gps.reject(new Error('permission unavailable'));
  assert.deepEqual(
    (await first).map((r) => r.status),
    ['rejected', 'rejected'],
  );
  await second;
  await refresh.refresh(
    'session-a',
    async () => {
      accounts++;
    },
    async () => {
      locations++;
    },
  );
  assert.equal(accounts, 2);
  assert.equal(locations, 2);
});

test('a newly signed-in session is checked immediately without waiting for its predecessor', async () => {
  const refresh = new ForegroundRefresh();
  const old = deferred(),
    gps = deferred();
  let newChecked = false,
    locations = 0;
  const location = () => {
    locations++;
    return gps.promise;
  };
  const first = refresh.refresh('session-old', () => old.promise, location);
  const second = refresh.refresh(
    'session-new',
    async () => {
      newChecked = true;
    },
    location,
  );
  await tick();
  assert.equal(newChecked, true);
  assert.equal(locations, 1);
  gps.resolve();
  await second;
  old.resolve();
  await first;
});

test('a synchronous account failure does not prevent location recovery', async () => {
  let resumed = false;
  const result = await new ForegroundRefresh().refresh(
    null,
    () => {
      throw new Error('storage failure');
    },
    async () => {
      resumed = true;
    },
  );
  assert.equal(resumed, true);
  assert.deepEqual(
    result.map((r) => r.status),
    ['rejected', 'fulfilled'],
  );
});

test('customer refresh needs no driver location task', async () => {
  let checked = false;
  const result = await new ForegroundRefresh().refresh(null, async () => {
    checked = true;
  });
  assert.equal(checked, true);
  assert.equal(result.length, 1);
  assert.equal(result[0].status, 'fulfilled');
});
