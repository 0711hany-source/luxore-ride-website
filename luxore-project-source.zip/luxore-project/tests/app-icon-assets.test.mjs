import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
const sharp = createRequire(import.meta.resolve('next/package.json'))('sharp');

test('store icon exports are square opaque 1024px artwork; adaptive glyphs fit the safe circle', async () => {
  for (const variant of ['ride', 'driver']) {
    const icon = sharp(readFileSync(`mobile/assets/icon-${variant}.png`));
    const metadata = await icon.metadata();
    assert.equal(metadata.width, 1024);
    assert.equal(metadata.height, 1024);
    assert.equal(metadata.hasAlpha, false);
  }
  const layers = [];
  for (const name of [
    'icon-ride-adaptive',
    'icon-driver-adaptive',
    'icon-monochrome',
  ]) {
    const { data, info } = await sharp(
      readFileSync(`mobile/assets/${name}.png`),
    )
      .raw()
      .toBuffer({ resolveWithObject: true });
    assert.equal(info.channels, 4);
    let visible = 0;
    const alpha = Buffer.alloc(1024 * 1024);
    for (let y = 0; y < 1024; y++)
      for (let x = 0; x < 1024; x++) {
        const a = data[(y * 1024 + x) * 4 + 3];
        alpha[y * 1024 + x] = a;
        if (a > 32) {
          visible++;
          assert.ok(
            Math.hypot(x - 512, y - 512) < 313,
            `${name}: glyph clipped by safe mask`,
          );
        }
      }
    assert.ok(visible > 50000);
    layers.push(alpha);
  }
  assert.deepEqual(layers[0], layers[1]);
  assert.deepEqual(layers[0], layers[2]);
});
