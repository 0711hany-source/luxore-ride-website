import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { createClient } from '@libsql/client';
import { readFileSync, readdirSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
import { sqliteDatabase } from '../db/sqlite.ts';
registerHooks({
  load(url, context, next) {
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `
      export class ApiError extends Error {constructor(status,message){super(message);this.status=status;}}
      export const db=()=>globalThis.cancelTest.db;
      export const identity=async()=>({userId:globalThis.cancelTest.user});
      export const limit=async()=>{};
      export const body=r=>r.json();
      export const json=(v,status=200)=>Response.json(v,{status});
      export const text=v=>{if(typeof v!=='string'||!v.trim())throw new ApiError(400,'empty');return v.trim();};
      export const handled=async work=>{try{return await work();}catch(e){return json({error:e.message},e.status||500);}};
      `,
      };
    return next(url, context);
  },
});
const { POST } = await import('../app/api/mobility/bookings/route.ts');
const request = (id = 'trip') =>
  new Request('https://test.invalid/api/mobility/bookings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'cancel', id }),
  });
async function fixture(status = 'requesting') {
  const client = createClient({ url: ':memory:' }),
    db = sqliteDatabase(client);
  const dir = new URL('../drizzle/', import.meta.url);
  for (const name of readdirSync(dir)
    .filter((n) => n.endsWith('.sql'))
    .sort())
    await client.executeMultiple(readFileSync(new URL(name, dir), 'utf8'));
  globalThis.cancelTest = { db, user: 'customer-a' };
  await client.execute({
    sql: `INSERT INTO mobility_bookings(id,quote_id,owner_id,service,price,route,mode,status,created_at,updated_at,rider_lat,rider_lng,rider_location_at,rider_share_id) VALUES('trip','quote','customer-a','premium',1500,'{}','now',?,0,1,50,8,1,'share')`,
    args: [status],
  });
  for (const [id, state] of [
    ['pending', 'pending'],
    ['declined', 'declined'],
    ['accepted', 'accepted'],
  ])
    await client.execute({
      sql: `INSERT INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at) VALUES(?,'trip',?,?,10000,0)`,
      args: [id, 'driver-' + id, state],
    });
  const snapshot = async () => ({
    booking: await db.prepare('SELECT * FROM mobility_bookings').first(),
    offers: (
      await db.prepare('SELECT * FROM mobility_offers ORDER BY id').all()
    ).results,
    events: (
      await db.prepare('SELECT * FROM mobility_events ORDER BY id').all()
    ).results,
  });
  return { client, db, snapshot, close: () => client.close() };
}
test('lost cancellation response retries at the same millisecond without a duplicate event', async () => {
  const f = await fixture(),
    original = Date.now;
  Date.now = () => 123456;
  try {
    assert.equal((await POST(request())).status, 200);
    const saved = await f.snapshot();
    assert.equal(saved.events.length, 1);
    assert.equal((await POST(request())).status, 200);
    assert.deepEqual(await f.snapshot(), saved);
  } finally {
    Date.now = original;
    f.close();
  }
});
test('later cancellation replay preserves saved time, offers and cleared customer location', async () => {
  const f = await fixture('accepted');
  try {
    assert.equal((await POST(request())).status, 200);
    const saved = await f.snapshot();
    assert.equal(saved.booking.status, 'cancelled');
    for (const key of [
      'rider_lat',
      'rider_lng',
      'rider_location_at',
      'rider_share_id',
    ])
      assert.equal(saved.booking[key], null);
    assert.equal(
      saved.offers.find((o) => o.id === 'pending').status,
      'withdrawn',
    );
    assert.equal(
      saved.offers.find((o) => o.id === 'declined').status,
      'declined',
    );
    assert.equal(
      saved.offers.find((o) => o.id === 'accepted').status,
      'accepted',
    );
    assert.equal((await POST(request())).status, 200);
    assert.deepEqual(await f.snapshot(), saved);
  } finally {
    f.close();
  }
});
test('cancelled trips belonging to another customer and missing trips stay inaccessible', async () => {
  const f = await fixture('cancelled');
  try {
    const before = await f.snapshot();
    globalThis.cancelTest.user = 'customer-b';
    assert.equal((await POST(request())).status, 409);
    assert.equal((await POST(request('missing'))).status, 409);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
test('riding, completed and unavailable trips never become cancelled on retry', async () => {
  for (const status of ['riding', 'completed', 'unavailable']) {
    const f = await fixture(status);
    try {
      const before = await f.snapshot();
      assert.equal((await POST(request())).status, 409);
      assert.deepEqual(await f.snapshot(), before);
    } finally {
      f.close();
    }
  }
});
test('event failure rolls back cancellation, offer withdrawal and location removal', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    await f.client.executeMultiple(
      "CREATE TRIGGER fail_cancel BEFORE INSERT ON mobility_events BEGIN SELECT RAISE(ABORT,'synthetic event failure'); END;",
    );
    assert.equal((await POST(request())).status, 500);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute('DROP TRIGGER fail_cancel');
    assert.equal((await POST(request())).status, 200);
    assert.equal((await f.snapshot()).events.length, 1);
  } finally {
    f.close();
  }
});
test('all supported pre-ride states cancel and acknowledge the same saved result', async () => {
  for (const status of ['reserved', 'requesting', 'accepted', 'arrived']) {
    const f = await fixture(status);
    try {
      assert.equal((await POST(request())).status, 200);
      const saved = await f.snapshot();
      assert.equal(saved.booking.status, 'cancelled');
      assert.equal((await POST(request())).status, 200);
      assert.deepEqual(await f.snapshot(), saved);
    } finally {
      f.close();
    }
  }
});
