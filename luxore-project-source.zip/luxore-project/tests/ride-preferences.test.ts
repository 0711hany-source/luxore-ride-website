import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  parseRidePreferences,
  storedRidePreferences,
  preferenceLabels,
} from '../lib/mobility/ride-preferences.ts';
void test('legacy bookings have no wishes and partial requests get defaults', () => {
  assert.deepEqual(preferenceLabels(storedRidePreferences(null)), []);
  assert.deepEqual(preferenceLabels(storedRidePreferences('{bad')), []);
  assert.deepEqual(
    preferenceLabels(
      parseRidePreferences({ temperature: 'cool', conversation: 'quiet' }),
    ),
    ['Kühl', 'Lieber Ruhe'],
  );
});
void test('only supported enum values and fields can be stored', () => {
  for (const invalid of [
    false,
    'cool',
    [],
    { temperature: 'freezing' },
    { temperature: 18 },
    { music: '__proto__' },
    { conversation: null },
    { freeText: 'x' },
    JSON.parse('{"__proto__":"x"}'),
  ]) {
    assert.throws(() => parseRidePreferences(invalid));
  }
});
void test('booking preferences survive JSON storage', () => {
  const input = { temperature: 'warm', conversation: 'chat', music: 'soft' };
  assert.deepEqual(
    storedRidePreferences(JSON.stringify(parseRidePreferences(input))),
    input,
  );
});
