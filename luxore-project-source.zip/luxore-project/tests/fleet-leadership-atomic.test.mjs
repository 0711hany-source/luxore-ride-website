import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { createClient } from '@libsql/client';
import { readFileSync, readdirSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  resolve(s, c, next) {
    if (s === '#leadership-adapter')
      return {
        url: new URL('../db/sqlite.ts?leadership-adapter', import.meta.url)
          .href,
        shortCircuit: true,
      };
    return next(s, c);
  },
  load(url, c, next) {
    if (url.endsWith('/db/sqlite.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `export const accountsConfigured=()=>true,runtimeDatabase=()=>globalThis.leadershipTest.db; export class DatabaseUnavailable extends Error {}`,
      };
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `
      export class ApiError extends Error {constructor(status,message){super(message);this.status=status}}
      export const limit=async()=>{}; export const db=()=>globalThis.leadershipTest.db,settings=()=>({}),tokenHash=async()=>'',isAdmin=u=>u.userId==='operator';
      export const identity=async()=>({userId:globalThis.leadershipTest.user}),body=r=>r.json(),json=(v,status=200)=>Response.json(v,{status});
      export const text=v=>{if(typeof v!=='string'||!v.trim())throw new ApiError(400,'empty');return v.trim()};
      export const handled=async fn=>{try{return await fn()}catch(e){return json({error:e.message},e.status||500)}};
    `,
      };
    return next(url, c);
  },
});
const { sqliteDatabase } = await import('#leadership-adapter');
const { POST } = await import('../app/api/mobility/fleets/route.ts');

const send = (input) =>
  POST(
    new Request('https://test.invalid/api/mobility/fleets', {
      method: 'POST',
      body: JSON.stringify(input),
    }),
  );
const deputy = (deputyId = 'driver-a', fleetId = 'fleet-a') =>
  send({ action: 'deputy', fleetId, deputyId });
const transfer = (extra = {}) =>
  send({
    action: 'transfer_owner',
    fleetId: 'fleet-a',
    previousOwnerId: 'owner-a',
    ownerId: 'driver-a',
    confirmed: true,
    ...extra,
  });
async function fixture() {
  const client = createClient({ url: ':memory:' }),
    db = sqliteDatabase(client);
  for (const name of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((n) => n.endsWith('.sql'))
    .sort())
    await client.executeMultiple(
      readFileSync(new URL('../drizzle/' + name, import.meta.url), 'utf8'),
    );
  globalThis.leadershipTest = { db, user: 'owner-a' };
  for (const suffix of ['a', 'b']) {
    await client.execute({
      sql: 'INSERT INTO mobility_fleets(id,name,owner_id,deputy_id,created_at) VALUES(?,?,?,?,0)',
      args: [
        'fleet-' + suffix,
        'Synthetic ' + suffix,
        'owner-' + suffix,
        'deputy-' + suffix,
      ],
    });
    for (const prefix of ['owner-', 'deputy-', 'driver-']) {
      const id = prefix + suffix;
      await client.execute({
        sql: "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,'Test','000',?,'driver',0)",
        args: [id, 'fleet-' + suffix],
      });
      await client.execute({
        sql: "INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,session_id) VALUES(?,'Test','000','Test','TEST','premium',1,0,NULL)",
        args: [id],
      });
      await client.execute({
        sql: "INSERT INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES(?,?,'Test','000','driver','active',0,0)",
        args: [id, id + '@example.test'],
      });
    }
  }
  await client.execute(
    "INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('car','fleet-a','Test Audi','TEST A','[\"premium\"]','active',0)",
  );
  await client.execute(
    "UPDATE mobility_drivers SET vehicle_id='car',vehicle='Test Audi',plate='TEST A',services='[\"premium\"]' WHERE id='driver-a'",
  );
  await client.execute(
    "INSERT INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at) VALUES('offer','trip','driver-a','pending',9999999999999,0)",
  );
  const snapshot = async () =>
    Object.fromEntries(
      await Promise.all(
        [
          'mobility_fleets',
          'mobility_employees',
          'mobility_drivers',
          'mobility_vehicles',
          'mobility_bookings',
          'mobility_offers',
          'mobility_operator_audit',
        ].map(async (table) => [
          table,
          (await db.prepare('SELECT * FROM ' + table + ' ORDER BY 1').all())
            .results,
        ]),
      ),
    );
  return { client, db, snapshot, close: () => client.close() };
}
const failAudit = (f) =>
  f.client.executeMultiple(
    "CREATE TRIGGER fail_leadership_audit BEFORE INSERT ON mobility_operator_audit BEGIN SELECT RAISE(ABORT,'synthetic audit failure'); END;",
  );
void test('deputy and real audit save together; identical selection is a no-op without stopping GPS', async () => {
  const f = await fixture();
  try {
    await f.client.execute(
      "UPDATE mobility_drivers SET online=1,session_id='shift',lat=50,lng=8,accuracy=5,location_at=100 WHERE id='driver-a'",
    );
    const before = await f.snapshot();
    await failAudit(f);
    assert.equal((await deputy()).status, 500);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute('DROP TRIGGER fail_leadership_audit');
    assert.equal((await deputy()).status, 200);
    const saved = await f.snapshot();
    assert.equal(saved.mobility_fleets[0].deputy_id, 'driver-a');
    assert.equal(saved.mobility_operator_audit.length, 1);
    assert.deepEqual(saved.mobility_drivers, before.mobility_drivers);
    assert.equal((await deputy()).status, 200);
    assert.deepEqual(await f.snapshot(), saved);
  } finally {
    f.close();
  }
});
void test('failed real audit rolls back removal of deputy, then clear/repeat commit once', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    await failAudit(f);
    assert.equal((await deputy(null)).status, 500);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute('DROP TRIGGER fail_leadership_audit');
    assert.equal((await deputy(null)).status, 200);
    const saved = await f.snapshot();
    assert.equal(saved.mobility_fleets[0].deputy_id, null);
    assert.equal(
      saved.mobility_operator_audit[0].action,
      'fleet.deputy_removed',
    );
    assert.equal((await deputy(null)).status, 200);
    assert.deepEqual(await f.snapshot(), saved);
  } finally {
    f.close();
  }
});
void test('only owner/operator can select another current member; no foreign fleet or deputy self-promotion', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    for (const actor of ['driver-a', 'deputy-a', 'owner-b']) {
      globalThis.leadershipTest.user = actor;
      assert.equal((await deputy()).status, 403);
    }
    globalThis.leadershipTest.user = 'owner-a';
    for (const id of ['owner-a', 'driver-b', 'missing'])
      assert.equal((await deputy(id)).status, 400);
    assert.equal((await deputy('driver-b', 'fleet-b')).status, 403);
    assert.equal((await deputy('driver-a', 'missing')).status, 403);
    assert.deepEqual(await f.snapshot(), before);
    globalThis.leadershipTest.user = 'operator';
    assert.equal((await deputy('driver-b', 'fleet-b')).status, 200);
  } finally {
    f.close();
  }
});
void test('inactive deputy accounts and inactive owner/operator accounts cannot receive or grant rights', async () => {
  for (const status of ['blocked', 'deletion_pending']) {
    const f = await fixture();
    try {
      await f.client.execute({
        sql: 'UPDATE mobility_accounts SET status=? WHERE id=?',
        args: [status, 'driver-a'],
      });
      const before = await f.snapshot();
      assert.equal((await deputy()).status, 409);
      assert.deepEqual(await f.snapshot(), before);
      await f.client.execute({
        sql: 'UPDATE mobility_accounts SET status=? WHERE id=?',
        args: [status, 'owner-a'],
      });
      const blocked = await f.snapshot();
      assert.equal((await deputy(null)).status, 403);
      assert.deepEqual(await f.snapshot(), blocked);
      globalThis.leadershipTest.user = 'operator';
      await f.client.execute({
        sql: "INSERT INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES('operator','operator@example.test','Test','000','customer',?,0,0)",
        args: [status],
      });
      const op = await f.snapshot();
      assert.equal((await deputy(null)).status, 403);
      assert.equal((await transfer()).status, 403);
      assert.deepEqual(await f.snapshot(), op);
    } finally {
      f.close();
    }
  }
});
void test('current owner permission is read inside the write transaction after an intervening handover', async () => {
  const f = await fixture();
  try {
    await f.client.execute(
      "UPDATE mobility_fleets SET deputy_id=NULL WHERE id='fleet-a'",
    );
    let intervened = false;
    const intervene = async () => {
      if (intervened) return;
      intervened = true;
      await f.client.execute(
        "UPDATE mobility_fleets SET owner_id='driver-a' WHERE id='fleet-a'",
      );
    };
    const write = f.db.writeTransaction;
    f.db.writeTransaction = async (work) => {
      await intervene();
      return write(work);
    };
    // The old endpoint had no transaction: inject the same external handover
    // after its owner read, just before its unguarded deputy UPDATE.
    const prepare = f.db.prepare;
    f.db.prepare = (sql) => {
      const statement = prepare(sql);
      if (sql.startsWith('UPDATE mobility_fleets SET deputy_id')) {
        const bind = statement.bind.bind(statement);
        statement.bind = (...args) => {
          const bound = bind(...args),
            run = bound.run.bind(bound);
          bound.run = async () => {
            await intervene();
            return run();
          };
          return bound;
        };
      }
      return statement;
    };
    assert.equal((await deputy('deputy-a')).status, 403);
    const saved = await f.snapshot();
    assert.equal(intervened, true);
    assert.equal(saved.mobility_fleets[0].owner_id, 'driver-a');
    assert.equal(saved.mobility_fleets[0].deputy_id, null);
    assert.equal(saved.mobility_operator_audit.length, 0);
  } finally {
    f.close();
  }
});
void test('failed owner transfer audit rolls back both owner and deputy; success preserves fleet assets and shifts', async () => {
  const f = await fixture();
  try {
    globalThis.leadershipTest.user = 'operator';
    await f.client.execute(
      "UPDATE mobility_fleets SET deputy_id='driver-a' WHERE id='fleet-a'",
    );
    const before = await f.snapshot();
    await failAudit(f);
    assert.equal((await transfer()).status, 500);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute('DROP TRIGGER fail_leadership_audit');
    assert.equal((await transfer()).status, 200);
    const saved = await f.snapshot();
    assert.equal(saved.mobility_fleets[0].owner_id, 'driver-a');
    assert.equal(saved.mobility_fleets[0].deputy_id, null);
    assert.equal(saved.mobility_operator_audit.length, 1);
    for (const table of [
      'mobility_employees',
      'mobility_drivers',
      'mobility_vehicles',
      'mobility_bookings',
      'mobility_offers',
    ])
      assert.deepEqual(saved[table], before[table]);
    assert.equal((await transfer()).status, 409);
    assert.deepEqual(await f.snapshot(), saved);
  } finally {
    f.close();
  }
});
void test('owner transfer keeps operator-only authority, explicit confirmation, membership and inactive target checks', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    assert.equal((await transfer()).status, 403);
    globalThis.leadershipTest.user = 'operator';
    for (const extra of [
      { confirmed: false },
      { confirmed: 'yes' },
      { ownerId: 'owner-a' },
    ])
      assert.equal((await transfer(extra)).status, 400);
    for (const extra of [
      { previousOwnerId: 'wrong' },
      { ownerId: 'driver-b' },
      { ownerId: 'missing' },
      { fleetId: 'missing' },
    ])
      assert.equal((await transfer(extra)).status, 409);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute(
      "UPDATE mobility_accounts SET status='blocked' WHERE id='driver-a'",
    );
    const blocked = await f.snapshot();
    assert.equal((await transfer()).status, 409);
    assert.deepEqual(await f.snapshot(), blocked);
  } finally {
    f.close();
  }
});
void test('online, GPS sessions, active rides and unpaid completions on either owner block handover', async () => {
  for (const who of ['owner-a', 'driver-a'])
    for (const condition of [
      'online',
      'session',
      'accepted',
      'arrived',
      'riding',
      'completed',
    ]) {
      const f = await fixture();
      try {
        globalThis.leadershipTest.user = 'operator';
        if (condition === 'online')
          await f.client.execute({
            sql: 'UPDATE mobility_drivers SET online=1 WHERE id=?',
            args: [who],
          });
        else if (condition === 'session')
          await f.client.execute({
            sql: "UPDATE mobility_drivers SET session_id='shift' WHERE id=?",
            args: [who],
          });
        else
          await f.client.execute({
            sql: "INSERT INTO mobility_bookings(id,quote_id,owner_id,driver_id,service,price,route,mode,status,created_at,updated_at,completed_at,payment_status) VALUES('trip','q','customer',?,'premium',1500,'{}','now',?,0,0,1,'unpaid')",
            args: [who, condition],
          });
        const before = await f.snapshot();
        assert.equal((await transfer()).status, 409);
        assert.deepEqual(await f.snapshot(), before);
      } finally {
        f.close();
      }
    }
});
void test('unapproved new owners and another existing owned fleet block handover without touching bookings', async () => {
  const f = await fixture();
  try {
    globalThis.leadershipTest.user = 'operator';
    await f.client.execute(
      "UPDATE mobility_drivers SET approved=0 WHERE id='driver-a'",
    );
    let before = await f.snapshot();
    assert.equal((await transfer()).status, 409);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute(
      "UPDATE mobility_drivers SET approved=1 WHERE id='driver-a'",
    );
    await f.client.execute(
      "INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES('other','Other','driver-a',0)",
    );
    before = await f.snapshot();
    assert.equal((await transfer()).status, 409);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
void test('target membership change at the write boundary is honored, while removing blocked deputy stays possible', async () => {
  const f = await fixture();
  try {
    const write = f.db.writeTransaction;
    let intervened = false;
    const intervene = async () => {
      if (intervened) return;
      intervened = true;
      await f.client.execute(
        "UPDATE mobility_employees SET fleet_id='fleet-b' WHERE user_id='driver-a'",
      );
    };
    f.db.writeTransaction = async (work) => {
      await intervene();
      return write(work);
    };
    const prepare = f.db.prepare;
    f.db.prepare = (sql) => {
      const statement = prepare(sql);
      if (sql.startsWith('UPDATE mobility_fleets SET deputy_id')) {
        const bind = statement.bind.bind(statement);
        statement.bind = (...args) => {
          const bound = bind(...args),
            run = bound.run.bind(bound);
          bound.run = async () => {
            await intervene();
            return run();
          };
          return bound;
        };
      }
      return statement;
    };
    assert.ok([400, 409].includes((await deputy()).status));
    assert.equal(intervened, true);
    assert.equal((await f.snapshot()).mobility_fleets[0].deputy_id, 'deputy-a');
    f.db.writeTransaction = write;
    await f.client.execute(
      "UPDATE mobility_accounts SET status='blocked' WHERE id='deputy-a'",
    );
    assert.equal((await deputy(null)).status, 200);
    assert.equal((await f.snapshot()).mobility_fleets[0].deputy_id, null);
  } finally {
    f.close();
  }
});
