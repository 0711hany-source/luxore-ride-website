import test from 'node:test';
import assert from 'node:assert/strict';
import {
  AddressSearchController,
  type AddressRequest,
} from '../mobile/src/address-search.ts';
const a = {
  id: 'a',
  label: 'Alte Oper, Frankfurt',
  lat: 50.115,
  lng: 8.671,
  attribution: '© OpenStreetMap contributors · Powered by Geoapify',
};
const b = {
  ...a,
  id: 'b',
  label: 'Berlin Hauptbahnhof',
  lat: 52.525,
  lng: 13.369,
};
const flush = async () => {
  for (let i = 0; i < 6; i++) await Promise.resolve();
};
function deferred<T>() {
  let resolve!: (v: T) => void;
  let reject!: (e: Error) => void;
  const promise = new Promise<T>((r, j) => {
    resolve = r;
    reject = j;
  });
  return { promise, resolve, reject };
}

void test('typing is debounced, trimmed, limited and never confirms a temporary suggestion', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const calls: unknown[] = [];
  const c = new AddressSearchController(async (body) => {
    calls.push(body);
    return { results: [a] };
  });
  c.setActive(true);
  c.setQuery('Al');
  t.mock.timers.tick(1000);
  await flush();
  assert.equal(calls.length, 0);
  c.setQuery('Alt');
  t.mock.timers.tick(500);
  c.setQuery(' Alte Oper ');
  t.mock.timers.tick(599);
  await flush();
  assert.equal(calls.length, 0);
  t.mock.timers.tick(1);
  await flush();
  assert.deepEqual(calls, [{ kind: 'search', query: 'Alte Oper' }]);
  assert.equal(c.getSnapshot().confirmed, null);
  assert.deepEqual(c.getSnapshot().results, [a]);
  c.setQuery('x'.repeat(257));
  t.mock.timers.tick(1000);
  await flush();
  assert.equal(calls.length, 1);
  c.dispose();
});
void test('an older ignored-abort response cannot replace newer suggestions or release its busy state', async () => {
  const old = deferred<{ results: (typeof a)[] }>(),
    fresh = deferred<{ results: (typeof a)[] }>();
  const signals: AbortSignal[] = [];
  let i = 0;
  const c = new AddressSearchController(async (_, s) => {
    signals.push(s!);
    return ++i === 1 ? old.promise : fresh.promise;
  });
  c.setActive(true);
  c.setQuery('Frankfurt');
  void c.search();
  c.setQuery('Berlin');
  void c.search();
  assert.equal(signals[0].aborted, true);
  old.resolve({ results: [a] });
  await flush();
  assert.equal(c.getSnapshot().searching, true);
  assert.deepEqual(c.getSnapshot().results, []);
  fresh.resolve({ results: [b] });
  await flush();
  assert.deepEqual(c.getSnapshot().results, [b]);
  assert.equal(c.getSnapshot().searching, false);
  c.dispose();
});
void test('background cancels only search and immediately allows a fresh request on return', async () => {
  const old = deferred<{ results: (typeof a)[] }>();
  const signals: AbortSignal[] = [];
  let i = 0;
  const c = new AddressSearchController(async (_, s) => {
    signals.push(s!);
    return ++i === 1 ? old.promise : { results: [b] };
  });
  c.setActive(true);
  c.setQuery('Berlin');
  void c.search();
  c.setActive(false);
  assert.equal(signals[0].aborted, true);
  assert.equal(c.getSnapshot().searching, false);
  c.setActive(true);
  await c.search();
  assert.deepEqual(c.getSnapshot().results, [b]);
  old.reject(new Error('late offline'));
  await flush();
  assert.equal(c.getSnapshot().error, '');
  assert.deepEqual(c.getSnapshot().results, [b]);
  c.dispose();
});
void test('selection needs an offered point and the actual server-confirmed address, without cancelling its write', async () => {
  const selected = deferred<{ results: (typeof a)[] }>();
  const calls: unknown[] = [];
  const c = new AddressSearchController(async (body, signal) => {
    calls.push({ body, signal });
    return body.kind === 'search' ? { results: [a] } : selected.promise;
  });
  c.setActive(true);
  c.setQuery('Alte Oper');
  await c.search();
  await c.select(b);
  assert.equal(calls.length, 1);
  void c.select(a);
  void c.select(a);
  assert.equal(calls.length, 2);
  assert.equal(c.getSnapshot().confirmed, null);
  c.setActive(false);
  assert.deepEqual(calls[1], {
    body: { kind: 'selected', query: 'Alte Oper', lat: a.lat, lng: a.lng },
    signal: undefined,
  });
  const saved = {
    ...a,
    id: 'saved-address',
    label: 'Opernplatz, Frankfurt am Main',
  };
  selected.resolve({ results: [saved] });
  await flush();
  assert.deepEqual(c.getSnapshot().confirmed, saved);
  assert.equal(c.getSnapshot().query, saved.label);
  assert.equal(c.getSnapshot().confirming, null);
  c.dispose();
});
void test('editing invalidates a confirmed point immediately and rejects a delayed confirmation for older text', async () => {
  const selected = deferred<{ results: (typeof a)[] }>();
  const c = new AddressSearchController(async (body) =>
    body.kind === 'search' ? { results: [a] } : selected.promise,
  );
  c.setActive(true);
  c.setQuery('Alte Oper');
  await c.search();
  void c.select(a);
  c.setQuery('Berlin');
  selected.resolve({ results: [a] });
  await flush();
  assert.equal(c.getSnapshot().confirmed, null);
  assert.equal(c.getSnapshot().query, 'Berlin');
  await c.search();
  await c.select(a);
  assert.deepEqual(c.getSnapshot().confirmed, a);
  c.setQuery('Neu');
  assert.equal(c.getSnapshot().confirmed, null);
  c.dispose();
});
void test('failures remain retryable and invalid provider responses never become an address', async () => {
  let bad = true;
  const c = new AddressSearchController((async (body) => {
    if (body.kind === 'search') return { results: [a] };
    return { results: bad ? [{ ...a, lat: 999 }] : [{ ...a, id: 'saved' }] };
  }) as AddressRequest);
  c.setActive(true);
  c.setQuery('Alte Oper');
  await c.search();
  await c.select(a);
  assert.equal(c.getSnapshot().confirmed, null);
  assert.match(c.getSnapshot().error, /nicht bestätigt/);
  assert.equal(c.getSnapshot().confirming, null);
  assert.deepEqual(c.getSnapshot().results, [a]);
  bad = false;
  await c.select(a);
  assert.equal(c.getSnapshot().confirmed?.id, 'saved');
  assert.equal(c.getSnapshot().error, '');
  c.dispose();
});
void test('empty, malformed and quota responses display truthful current-query errors and allow retries', async () => {
  let kind = 0;
  const c = new AddressSearchController((async () => {
    if (kind === 0) return { results: [] };
    if (kind === 1) return { results: [{ ...a, lng: 500 }] };
    if (kind === 2) throw new Error('Suchkontingent ausgeschöpft.');
    return { results: [a] };
  }) as AddressRequest);
  c.setActive(true);
  c.setQuery('Frankfurt');
  await c.search();
  assert.match(c.getSnapshot().error, /Keine Adresse/);
  kind = 1;
  await c.search();
  assert.match(c.getSnapshot().error, /gültige Antwort/);
  kind = 2;
  await c.search();
  assert.equal(c.getSnapshot().error, 'Suchkontingent ausgeschöpft.');
  kind = 3;
  await c.search();
  assert.equal(c.getSnapshot().error, '');
  assert.deepEqual(c.getSnapshot().results, [a]);
  c.dispose();
});
void test('disposing drops delayed search/confirmation results and never publishes into a new account', async () => {
  const selected = deferred<{ results: (typeof a)[] }>();
  const c = new AddressSearchController(async (body) =>
    body.kind === 'search' ? { results: [a] } : selected.promise,
  );
  let updates = 0;
  c.subscribe(() => updates++);
  c.setActive(true);
  c.setQuery('Alte Oper');
  await c.search();
  void c.select(a);
  c.dispose();
  const n = updates;
  selected.resolve({ results: [a] });
  await flush();
  assert.equal(updates, n);
  assert.equal(c.getSnapshot().confirmed, null);
  await c.select(a);
  await c.search();
  assert.equal(updates, n);
});
