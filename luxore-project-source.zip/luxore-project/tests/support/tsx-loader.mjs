// Server-render real React controls in Node; no browser or DOM emulation.
import { registerHooks } from 'node:module';
import { readFileSync, existsSync } from 'node:fs';
import { pathToFileURL, fileURLToPath } from 'node:url';
import ts from 'typescript';
const root = new URL('../../', import.meta.url);
registerHooks({
  resolve(specifier, context, nextResolve) {
    let candidate;
    if (specifier.startsWith('@/'))
      candidate = new URL(specifier.slice(2), root);
    else if (
      specifier.startsWith('.') &&
      context.parentURL?.startsWith(root.href)
    )
      candidate = new URL(specifier, context.parentURL);
    if (candidate) {
      for (const suffix of ['', '.ts', '.tsx']) {
        const path = fileURLToPath(candidate) + suffix;
        if (existsSync(path) && /\.(ts|tsx)$/.test(path))
          return { url: pathToFileURL(path).href, shortCircuit: true };
      }
    }
    return nextResolve(specifier, context);
  },
  load(url, context, nextLoad) {
    if (
      url.startsWith(root.href) &&
      !url.includes('/node_modules/') &&
      /\.(ts|tsx)$/.test(url)
    ) {
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(readFileSync(new URL(url), 'utf8'), {
          fileName: fileURLToPath(url),
          compilerOptions: {
            module: ts.ModuleKind.ESNext,
            target: ts.ScriptTarget.ES2022,
            jsx: ts.JsxEmit.ReactJSX,
          },
        }).outputText,
      };
    }
    return nextLoad(url, context);
  },
});
