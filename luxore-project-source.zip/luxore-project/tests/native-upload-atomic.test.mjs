import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { createClient } from '@libsql/client';
import { readFileSync, readdirSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  resolve(s, c, next) {
    if (s === '#upload-adapter')
      return {
        url: new URL('../db/sqlite.ts?upload-adapter', import.meta.url).href,
        shortCircuit: true,
      };
    return next(s, c);
  },
  load(url, c, next) {
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `export class ApiError extends Error {constructor(status,message){super(message);this.status=status}};export const db=()=>globalThis.uploadTest.db,tokenHash=async token=>token,limit=(...args)=>globalThis.uploadTest.limit(...args),body=r=>r.json(),json=(v,status=200)=>Response.json(v,{status}),handled=async fn=>{try{return await fn()}catch(e){return json({error:e.message},e.status||500)}};`,
      };
    if (
      url.endsWith('/lib/mobility/location.ts') &&
      process.env.TEST_ORIGINAL_NATIVE_LOCATION
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_NATIVE_LOCATION, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    if (
      url.endsWith('/app/api/mobility/location/route.ts') &&
      process.env.TEST_ORIGINAL_NATIVE_UPLOAD
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_NATIVE_UPLOAD, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
const { sqliteDatabase } = await import('#upload-adapter');
const { POST } = await import('../app/api/mobility/location/route.ts');
const token = 'a'.repeat(64),
  nextToken = 'b'.repeat(64);
const point = () => ({
  lat: 50.112,
  lng: 8.681,
  accuracy: 6,
  timestamp: Date.now(),
});
const send = (extra = {}, value = token) =>
  POST(
    new Request('https://test.invalid/api/mobility/location', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + value },
      body: JSON.stringify({ ...point(), ...extra }),
    }),
  );
async function fixture() {
  const client = createClient({ url: ':memory:' }),
    db = sqliteDatabase(client);
  for (const f of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((n) => n.endsWith('.sql'))
    .sort())
    await client.executeMultiple(
      readFileSync(new URL('../drizzle/' + f, import.meta.url), 'utf8'),
    );
  const now = Date.now() - 1000;
  await client.execute(
    "INSERT INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES('driver','driver@example.test','Synthetic','000','driver','active',0,0)",
  );
  await client.executeMultiple(`INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES('fleet','Synthetic Fleet','owner',0);
 INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('driver','Synthetic Driver','000','fleet','driver',0);
 INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('car','fleet','Synthetic Audi','TEST','["premium"]','active',0);
 INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,services,approved,online,session_id,vehicle_id,lat,lng,accuracy,location_at) VALUES('driver','Synthetic Driver','000','Synthetic Audi','TEST','premium','["premium"]',1,1,'old','car',50.11,8.68,8,${now});
 INSERT INTO mobility_location_sessions(token_hash,driver_id,session_id,expires_at) VALUES('${token}','driver','old',${now + 3600000});
 INSERT INTO mobility_bookings(id,quote_id,owner_id,mode,service,status,route,price,payment_status,created_at,updated_at,dispatch_at) VALUES('booking','quote','customer','now','premium','requesting','{"pickup":{"lat":50.11,"lng":8.68}}',1000,'unpaid',${now},${now},${now});
 INSERT INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at) VALUES('offer','booking','driver','pending',${now + 25000},${now});`);
  globalThis.uploadTest = { db, limit: async () => {} };
  const snapshot = async () =>
    Object.fromEntries(
      await Promise.all(
        [
          'mobility_accounts',
          'mobility_drivers',
          'mobility_location_sessions',
          'mobility_offers',
          'mobility_bookings',
          'mobility_employees',
          'mobility_vehicles',
        ].map(async (table) => [
          table,
          (await db.prepare('SELECT * FROM ' + table + ' ORDER BY 1').all())
            .results,
        ]),
      ),
    );
  const race = (work) => {
    const prepare = db.prepare;
    let fired = false;
    db.prepare = (sql) => {
      const stmt = prepare(sql);
      if (!sql.includes('SELECT s.driver_id,s.session_id')) return stmt;
      const bind = stmt.bind.bind(stmt);
      stmt.bind = (...args) => {
        const bound = bind(...args),
          first = bound.first.bind(bound);
        bound.first = async (...params) => {
          const row = await first(...params);
          if (!fired) {
            fired = true;
            await work();
          }
          return row;
        };
        return bound;
      };
      return stmt;
    };
  };
  return { client, db, snapshot, race, close: () => client.close() };
}
void test('valid native upload preserves raw point, capability and rights and exposes only opaque offer metadata', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot(),
      p = point(),
      r = await send({ ...p, driverId: 'foreign', sessionId: 'foreign' });
    assert.equal(r.status, 200);
    const b = await r.json(),
      after = await f.snapshot();
    assert.equal(b.ok, true);
    assert.equal(b.updated, true);
    assert.deepEqual(b.offer, {
      id: 'offer',
      expiresAt: before.mobility_offers[0].expires_at,
    });
    assert.equal(typeof b.serverTime, 'number');
    assert.deepEqual(after.mobility_drivers[0], {
      ...before.mobility_drivers[0],
      lat: p.lat,
      lng: p.lng,
      accuracy: p.accuracy,
      location_at: p.timestamp,
      online: 1,
    });
    for (const table of [
      'mobility_accounts',
      'mobility_location_sessions',
      'mobility_offers',
      'mobility_bookings',
      'mobility_employees',
      'mobility_vehicles',
    ])
      assert.deepEqual(after[table], before[table]);
  } finally {
    f.close();
  }
});
for (const [name, sql] of [
  [
    'blocked account',
    "UPDATE mobility_accounts SET status='blocked' WHERE id='driver'",
  ],
  [
    'pending account deletion',
    "UPDATE mobility_accounts SET status='deletion_pending' WHERE id='driver'",
  ],
  [
    'revoked approval',
    "UPDATE mobility_drivers SET approved=0 WHERE id='driver'",
  ],
  [
    'renewed token',
    `UPDATE mobility_location_sessions SET token_hash='${nextToken}'`,
  ],
  [
    'replacement shift',
    `UPDATE mobility_drivers SET session_id='new',online=0;DELETE FROM mobility_location_sessions;INSERT INTO mobility_location_sessions VALUES('${nextToken}','driver','new',${Date.now() + 3600000})`,
  ],
  [
    'completed pause',
    'UPDATE mobility_drivers SET session_id=NULL,online=0;DELETE FROM mobility_location_sessions',
  ],
  ['expired capability', 'UPDATE mobility_location_sessions SET expires_at=0'],
  ['archived vehicle', "UPDATE mobility_vehicles SET status='archived'"],
  [
    'removed fleet membership',
    "DELETE FROM mobility_employees WHERE user_id='driver'",
  ],
])
  void test(
    'native upload rechecks ' +
      name +
      ' after preliminary capability lookup without GPS or dispatch changes',
    async () => {
      const f = await fixture();
      try {
        await f.client.execute('UPDATE mobility_offers SET expires_at=0');
        let expected;
        f.race(async () => {
          await f.client.executeMultiple(sql);
          expected = await f.snapshot();
        });
        assert.equal((await send()).status, 401);
        assert.deepEqual(await f.snapshot(), expected);
      } finally {
        f.close();
      }
    },
  );
void test('revocation while rate-limit work is pending is checked at the real write boundary', async () => {
  const f = await fixture();
  try {
    let expected;
    globalThis.uploadTest.limit = async (...args) => {
      assert.deepEqual(args, ['driver', 'native-location', 90]);
      await f.client.execute(
        "UPDATE mobility_accounts SET status='blocked' WHERE id='driver'",
      );
      expected = await f.snapshot();
    };
    assert.equal((await send()).status, 401);
    assert.deepEqual(await f.snapshot(), expected);
  } finally {
    f.close();
  }
});
void test('duplicate and older valid points remain no-op acknowledgments and skip dispatch', async () => {
  const f = await fixture();
  try {
    await f.client.execute('UPDATE mobility_offers SET expires_at=0');
    const before = await f.snapshot();
    for (const timestamp of [
      before.mobility_drivers[0].location_at,
      before.mobility_drivers[0].location_at - 1,
    ]) {
      const r = await send({ timestamp });
      assert.equal(r.status, 200);
      const b = await r.json();
      assert.equal(b.updated, false);
      assert.equal(b.offer, null);
      assert.deepEqual(await f.snapshot(), before);
    }
  } finally {
    f.close();
  }
});
void test('legacy driver with no account row remains authorized and actual rate rejection never writes GPS', async () => {
  const f = await fixture();
  try {
    await f.client.execute('DELETE FROM mobility_accounts');
    let calls = 0;
    globalThis.uploadTest.limit = async (...args) => {
      calls++;
      assert.deepEqual(args, ['driver', 'native-location', 90]);
      const e = new Error('synthetic rate limit');
      e.status = 429;
      throw e;
    };
    const before = await f.snapshot();
    assert.equal((await send()).status, 429);
    assert.equal(calls, 1);
    assert.deepEqual(await f.snapshot(), before);
    globalThis.uploadTest.limit = async () => {};
    assert.equal((await send()).status, 200);
  } finally {
    f.close();
  }
});
void test('existing token shape, raw coordinate, accuracy and required timestamp guards reject invalid input', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    assert.equal((await send({}, 'invalid')).status, 401);
    for (const values of [
      { timestamp: undefined },
      { timestamp: Date.now() - 31000 },
      { timestamp: Date.now() + 60000 },
      { timestamp: 'now' },
      { accuracy: 101 },
      { accuracy: -1 },
      { lat: 91 },
      { lng: 181 },
    ]) {
      assert.equal((await send(values)).status, 400);
      assert.deepEqual(await f.snapshot(), before);
    }
  } finally {
    f.close();
  }
});
void test('real GPS storage failure leaves GPS, capability and offers unchanged and later explicit upload works', async () => {
  const f = await fixture();
  try {
    await f.client.executeMultiple(
      "UPDATE mobility_offers SET expires_at=0;CREATE TRIGGER fail_gps BEFORE UPDATE ON mobility_drivers BEGIN SELECT RAISE(ABORT,'synthetic GPS save failure');END",
    );
    const before = await f.snapshot();
    assert.equal((await send()).status, 500);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute('DROP TRIGGER fail_gps');
    assert.equal((await send()).status, 200);
    assert.equal((await f.snapshot()).mobility_offers[0].status, 'expired');
  } finally {
    f.close();
  }
});
for (const stage of ['queue cleanup', 'offer insertion'])
  void test(
    'committed native GPS remains acknowledged after actual dispatch ' +
      stage +
      ' failure',
    async () => {
      const f = await fixture(),
        errors = [],
        oldError = console.error;
      try {
        console.error = (...args) => errors.push(args);
        if (stage === 'queue cleanup')
          await f.client.executeMultiple(
            "INSERT INTO mobility_limits VALUES('0:synthetic',1);CREATE TRIGGER fail_dispatch BEFORE DELETE ON mobility_limits BEGIN SELECT RAISE(ABORT,'synthetic dispatch cleanup failure');END",
          );
        else
          await f.client.executeMultiple(
            "DELETE FROM mobility_offers;CREATE TRIGGER fail_dispatch BEFORE INSERT ON mobility_offers BEGIN SELECT RAISE(ABORT,'synthetic dispatch insertion failure');END",
          );
        const r = await send();
        assert.equal(r.status, 200);
        const b = await r.json(),
          after = await f.snapshot();
        assert.equal(b.ok, true);
        assert.equal(b.updated, true);
        assert.equal(after.mobility_drivers[0].lat, 50.112);
        assert.equal(errors.length, 1);
        assert.equal(errors[0][0], 'Native location dispatch refresh failed:');
        if (stage === 'queue cleanup') assert.equal(b.offer.id, 'offer');
        else assert.equal(b.offer, null);
        await f.client.execute('DROP TRIGGER fail_dispatch');
        assert.equal((await send()).status, 200);
      } finally {
        console.error = oldError;
        f.close();
      }
    },
  );
void test('account block after GPS commit suppresses offer metadata from the later actual read', async () => {
  const f = await fixture();
  try {
    const batch = f.db.batch.bind(f.db);
    f.db.batch = async (statements) => {
      const r = await batch(statements);
      await f.client.execute(
        "UPDATE mobility_accounts SET status='blocked' WHERE id='driver'",
      );
      return r;
    };
    const r = await send();
    assert.equal(r.status, 200);
    const b = await r.json();
    assert.equal(b.updated, true);
    assert.equal(b.offer, null);
  } finally {
    f.close();
  }
});
void test('actual offer-read SQL failure acknowledges committed GPS without fabricating an offer withdrawal for existing native parser', async () => {
  const f = await fixture(),
    errors = [],
    oldError = console.error;
  try {
    console.error = (...args) => errors.push(args);
    const prepare = f.db.prepare.bind(f.db);
    f.db.prepare = (sql) => {
      const statement = prepare(sql);
      if (!sql.startsWith('SELECT o.id,o.expires_at AS expiresAt'))
        return statement;
      const bind = statement.bind.bind(statement);
      statement.bind = (...args) => {
        const bound = bind(...args),
          first = bound.first.bind(bound);
        bound.first = async (...params) => {
          await f.client.execute(
            'ALTER TABLE mobility_offers RENAME TO test_unavailable_offers',
          );
          return first(...params);
        };
        return bound;
      };
      return statement;
    };
    const r = await send();
    assert.equal(r.status, 200);
    const b = await r.json();
    assert.equal(b.ok, true);
    assert.equal(b.updated, true);
    assert.equal(Object.hasOwn(b, 'offer'), false);
    assert.equal(
      (
        await f.db
          .prepare("SELECT lat FROM mobility_drivers WHERE id='driver'")
          .first()
      ).lat,
      50.112,
    );
    assert.equal(errors.length, 1);
    assert.equal(errors[0][0], 'Native location offer read failed:');
    const { parseAlertReply } =
      await import('../mobile/src/offer-alert-policy.ts');
    assert.equal(parseAlertReply(b), null);
  } finally {
    console.error = oldError;
    f.close();
  }
});
