import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  cartPrice,
  emptyOrder,
  parseCart,
  updateOrder,
  combined,
} from '../lib/mobility/refreshments.ts';
import { completedSwipe } from '../app/mobility/swipe-confirmation.ts';
test('per-ride allowances and cent prices cover every class', () => {
  assert.equal(cartPrice({ water: 2 }, 'premium'), 0);
  assert.equal(cartPrice({ water: 2, energy: 1, pretzels: 1 }, 'premium'), 400);
  assert.equal(
    cartPrice({ water: 2, energy: 2, pretzels: 1, cookies: 1 }, 'first'),
    0,
  );
  assert.equal(cartPrice({ water: 4, pretzels: 2 }, 'van'), 150);
});
test('partial deliveries, second orders and unavailable items do not reset free allowances', () => {
  let order = updateOrder(emptyOrder(), 'request', {
    cart: { water: 2, energy: 1, pretzels: 1 },
  });
  order = updateOrder(order, 'deliver', { itemId: 'water', quantity: 2 });
  assert.equal(cartPrice(order.delivered, 'premium'), 0);
  order = updateOrder(order, 'unavailable', {
    itemId: 'pretzels',
    quantity: 1,
  });
  order = updateOrder(order, 'deliver', { itemId: 'energy', quantity: 1 });
  assert.equal(cartPrice(order.delivered, 'premium'), 250);
  order = updateOrder(order, 'request', { cart: { cola: 1 } });
  assert.equal(
    cartPrice(combined(order.delivered, order.requested), 'premium'),
    500,
  );
  assert.equal(cartPrice(order.delivered, 'premium'), 250);
  assert.equal(order.revision, 5);
});
test('malformed and excessive orders, nonexistent and duplicate handovers are rejected', () => {
  for (const v of [
    { water: -1 },
    { energy: 1.1 },
    { water: 13 },
    { water: 12, energy: 12, cola: 1 },
    { champagne: 1 },
    [],
    null,
  ])
    assert.throws(() => parseCart(v));
  const order = updateOrder(emptyOrder(), 'request', { cart: { water: 1 } });
  for (const itemId of ['__proto__', 'cola'])
    assert.throws(() => updateOrder(order, 'deliver', { itemId, quantity: 1 }));
  const served = updateOrder(order, 'deliver', {
    itemId: 'water',
    quantity: 1,
  });
  assert.throws(() =>
    updateOrder(served, 'deliver', { itemId: 'water', quantity: 1 }),
  );
});
test('only a completed drag confirms; tapping the end, short swipes and disabled controls do not', () => {
  assert.equal(completedSwipe(false, 200, 100, false), false);
  assert.equal(completedSwipe(true, 0, 100, false), false);
  assert.equal(completedSwipe(true, 40, 100, false), false);
  assert.equal(completedSwipe(true, 200, 50, false), false);
  assert.equal(completedSwipe(true, 200, 100, true), false);
  assert.equal(completedSwipe(true, 200, 100, false), true);
});
