import { test } from 'node:test';
import assert from 'node:assert/strict';
import { startShiftBackground } from '../app/mobility/background-start.ts';
import type { NativeReply } from '../app/mobility/native-location.ts';

function deferred() {
  let resolve!: (reply: NativeReply) => void;
  let reject!: (error: Error) => void;
  const promise = new Promise<NativeReply>((yes, no) => {
    resolve = yes;
    reject = no;
  });
  return { promise, resolve, reject };
}

function fixture() {
  const work = deferred();
  let current: string | null = 'shift-a';
  let allowed = true;
  const ready: NativeReply[] = [];
  const errors: string[] = [];
  let stopped = 0;
  const pending = startShiftBackground({
    sessionId: 'shift-a',
    currentSession: () => current,
    isCurrent: () => allowed && current === 'shift-a',
    start: () => work.promise,
    stop: async () => {
      stopped++;
    },
    ready: (reply) => {
      ready.push(reply);
    },
    unavailable: (message) => {
      errors.push(message);
    },
  });
  return {
    work,
    pending,
    ready,
    errors,
    stopped: () => stopped,
    session: () => current,
    pause: () => {
      allowed = false;
      current = null;
    },
    replace: () => {
      current = 'shift-b';
    },
    unmount: () => {
      allowed = false;
    },
  };
}
const active = () => ({
  status: { active: true, sessionId: 'shift-a', expiresAt: Date.now() + 60000 },
});

test('a pending permission request does not prevent Pause; late startup is cleaned up', async () => {
  const f = fixture();
  assert.equal(f.session(), 'shift-a');
  f.pause();
  assert.equal(f.session(), null, 'Pause does not wait for native permission');
  f.work.resolve(active());
  await f.pending;
  assert.equal(f.ready.length, 0);
  assert.equal(f.stopped(), 1);
});

test('permission denial or timeout keeps the existing foreground session', async () => {
  for (const message of [
    'Berechtigung abgelehnt. Du bleibst offline.',
    'Standortfreigabe dauert zu lange.',
  ]) {
    const f = fixture();
    f.work.reject(new Error(message));
    await f.pending;
    assert.equal(f.session(), 'shift-a');
    assert.equal(f.ready.length, 0);
    assert.equal(f.stopped(), 0);
    assert.equal(f.errors.length, 1);
    assert.doesNotMatch(f.errors[0], /Du bleibst offline/);
  }
});

test('a replaced shift or unmounted view ignores late native replies without stopping the new service', async () => {
  for (const outcome of ['resolve', 'reject'] as const) {
    for (const action of ['replace', 'unmount'] as const) {
      const f = fixture();
      f[action]();
      if (outcome === 'resolve') f.work.resolve(active());
      else f.work.reject(new Error('Old failure'));
      await f.pending;
      assert.equal(f.ready.length, 0);
      assert.equal(f.errors.length, 0);
      assert.equal(f.stopped(), 0);
    }
  }
});

test('only a confirmed matching unexpired native session enables background mode', async () => {
  const f = fixture();
  f.work.resolve(active());
  await f.pending;
  assert.equal(f.ready.length, 1);
  for (const reply of [
    {},
    { status: { active: false } },
    { status: { active: true, sessionId: 'other' } },
    { status: { active: true, sessionId: 'shift-a', expiresAt: 0 } },
  ]) {
    const failed = fixture();
    failed.work.resolve(reply);
    await failed.pending;
    assert.equal(failed.ready.length, 0);
    assert.equal(failed.errors.length, 1);
    assert.equal(failed.session(), 'shift-a');
  }
});
