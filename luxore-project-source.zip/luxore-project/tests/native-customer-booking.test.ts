import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CustomerBookingController,
  type BookingStore,
  type PendingBooking,
} from '../mobile/src/customer-booking.ts';
import type { Booking, Quote } from '../lib/mobility/domain.ts';
const now = 1800000000000;
const p = { id: 'pickup', label: 'Alte Oper', lat: 50.115, lng: 8.671 },
  d = {
    id: 'destination',
    label: 'Frankfurt Flughafen',
    lat: 50.05,
    lng: 8.57,
  };
const quote: Quote = {
  id: 'quote-a',
  pickup: p,
  destination: d,
  distanceMeters: 15000,
  durationSeconds: 1000,
  geometry: {
    type: 'LineString',
    coordinates: [
      [p.lng, p.lat],
      [d.lng, d.lat],
    ],
  },
  calculatedAt: now,
  expiresAt: now + 300000,
  prices: { premium: 3750, first: 5250, van: 4500 },
  mode: 'now',
  scheduledAt: null,
};
const booking = {
  id: 'booking-a',
  quote_id: 'quote-a',
  service: 'premium',
  route: quote,
  status: 'requesting',
} as unknown as Booking;
const deferred = <T>() => {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((r) => {
    resolve = r;
  });
  return { promise, resolve };
};
function fixture() {
  let persisted: PendingBooking | null = null;
  const writes: unknown[] = [],
    reads: unknown[] = [];
  const store: BookingStore = {
    load: async () => persisted,
    save: async (v) => {
      persisted = structuredClone(v);
    },
    clear: async () => {
      persisted = null;
    },
  };
  const api = {
    quote: async (body: unknown, signal: AbortSignal) => {
      reads.push({ body, signal });
      return structuredClone(quote);
    },
    book: async (body: unknown) => {
      writes.push(body);
      return booking;
    },
  };
  const c = new CustomerBookingController(
    api,
    store,
    { name: 'Kunde Test', phone: '+490000000' },
    () => now,
  );
  return { c, store, api, reads, writes, persisted: () => persisted };
}
async function draft(f: ReturnType<typeof fixture>) {
  await f.c.restore();
  f.c.setActive(true);
  f.c.selectPlace('pickup', p);
  f.c.selectPlace('destination', d);
}

void test('native quote uses only confirmed address IDs and server kilometre prices; time changes invalidate it', async () => {
  const f = fixture();
  await draft(f);
  await f.c.calculate();
  assert.deepEqual((f.reads[0] as { body: unknown }).body, {
    pickupId: p.id,
    destinationId: d.id,
    mode: 'now',
    scheduledAt: null,
  });
  assert.deepEqual(f.c.getSnapshot().quote?.prices, quote.prices);
  const time = now + 3600123;
  f.c.setDeparture('reservation', time);
  assert.equal(f.c.getSnapshot().quote, null);
  f.api.quote = async (body) => ({
    ...quote,
    mode: 'reservation',
    scheduledAt: (body as { scheduledAt: number }).scheduledAt,
  });
  await f.c.calculate();
  assert.equal(f.c.getSnapshot().quote?.scheduledAt, time);
});
void test('missing, close and invalid reservation inputs never call routing', async () => {
  const f = fixture();
  await f.c.restore();
  f.c.setActive(true);
  await f.c.calculate();
  assert.match(f.c.getSnapshot().error, /Abholort/);
  await draft(f);
  f.c.selectPlace('destination', { ...p, id: 'near' });
  await f.c.calculate();
  assert.match(f.c.getSnapshot().error, /nah/);
  f.c.selectPlace('destination', d);
  f.c.setDeparture('reservation', now + 60000);
  await f.c.calculate();
  assert.match(f.c.getSnapshot().error, /30 Minuten/);
  assert.equal(f.reads.length, 0);
});
void test('address edits and background return release old quote reads without stale replacement', async () => {
  const f = fixture(),
    a = deferred<Quote>(),
    b = deferred<Quote>();
  let count = 0;
  f.api.quote = async (body, signal) => {
    f.reads.push({ body, signal });
    return ++count === 1 ? a.promise : b.promise;
  };
  await draft(f);
  const old = f.c.calculate();
  f.c.setActive(false);
  assert.equal((f.reads[0] as { signal: AbortSignal }).signal.aborted, true);
  f.c.setActive(true);
  const fresh = f.c.calculate();
  a.resolve(quote);
  await old;
  assert.equal(f.c.getSnapshot().loading, true);
  assert.equal(f.c.getSnapshot().quote, null);
  b.resolve(quote);
  await fresh;
  assert.equal(f.c.getSnapshot().quote?.id, 'quote-a');
  f.c.selectPlace('pickup', { ...p, id: 'new-pickup' });
  assert.equal(f.c.getSnapshot().quote, null);
});
void test('wrong-address and malformed server quotes are rejected before booking', async () => {
  const f = fixture();
  await draft(f);
  f.api.quote = async () => ({ ...quote, pickup: { ...p, id: 'wrong' } });
  await f.c.calculate();
  assert.equal(f.c.getSnapshot().quote, null);
  f.api.quote = async () => ({
    ...quote,
    prices: { ...quote.prices, first: NaN },
  });
  await f.c.calculate();
  assert.equal(f.c.getSnapshot().quote, null);
  await f.c.submit();
  assert.equal(f.writes.length, 0);
});
void test('a full booking preserves preferences, board cart and server service; duplicate submission is locked until confirmation', async () => {
  const f = fixture(),
    reply = deferred<Booking>();
  await draft(f);
  await f.c.calculate();
  f.c.setDetails({
    service: 'first',
    preferences: { temperature: 'cool', conversation: 'quiet', music: 'off' },
    refreshments: { water: 3, pretzels: 1 },
  });
  f.api.book = async (body) => {
    f.writes.push(body);
    return reply.promise;
  };
  const task = f.c.submit();
  await Promise.resolve();
  await f.c.submit();
  assert.equal(f.writes.length, 1);
  assert.ok(f.persisted());
  assert.equal(f.c.getSnapshot().booking, null);
  f.c.setActive(false);
  reply.resolve({ ...booking, service: 'first' });
  await task;
  assert.equal(f.c.getSnapshot().booking?.id, 'booking-a');
  assert.equal(f.persisted(), null);
  assert.deepEqual(f.writes[0], {
    quoteId: 'quote-a',
    service: 'first',
    riderName: 'Kunde Test',
    riderPhone: '+490000000',
    preferences: { temperature: 'cool', conversation: 'quiet', music: 'off' },
    refreshments: { water: 3, pretzels: 1 },
  });
});
void test('lost booking response and restart retain exact quote/class/body; retry confirms existing reservation', async () => {
  const f = fixture();
  await draft(f);
  await f.c.calculate();
  f.api.book = async (body) => {
    f.writes.push(body);
    throw new Error('Verbindung verloren');
  };
  await f.c.submit();
  const persisted = f.persisted()!;
  assert.ok(persisted);
  f.c.setDetails({ service: 'van' });
  f.c.setDeparture('reservation', now + 9000000);
  assert.equal(f.c.getSnapshot().service, 'premium');
  const recovered = new CustomerBookingController(
    {
      quote: async () => {
        throw new Error('must not requote');
      },
      book: async (body) => {
        assert.deepEqual(body, persisted.body);
        return { ...booking, status: 'reserved' };
      },
    },
    f.store,
    { name: 'Anderer Profilstand', phone: '+4912345678' },
    () => now + 99999999,
  );
  await recovered.restore();
  recovered.setActive(true);
  await recovered.submit();
  assert.equal(recovered.getSnapshot().booking?.status, 'reserved');
  assert.equal(f.persisted(), null);
});
void test('protected storage failure prevents transmission; definite rejection unlocks draft, server failure retains it', async () => {
  const f = fixture();
  await draft(f);
  await f.c.calculate();
  const save = f.store.save.bind(f.store);
  f.store.save = async () => {
    throw new Error('locked');
  };
  await f.c.submit();
  assert.equal(f.writes.length, 0);
  assert.equal(f.c.getSnapshot().pending, null);
  f.store.save = save;
  f.api.book = async () => {
    throw Object.assign(new Error('Preis abgelaufen'), { status: 409 });
  };
  await f.c.submit();
  assert.equal(f.c.getSnapshot().pending, null);
  assert.equal(f.persisted(), null);
  f.api.book = async () => {
    throw Object.assign(new Error('Serverantwort fehlt'), { status: 500 });
  };
  await f.c.submit();
  assert.ok(f.c.getSnapshot().pending);
  assert.ok(f.persisted());
});
void test('expired price/contact/cart are checked before transport; confirmed booking permits a fresh draft', async () => {
  let clock = now;
  const f = fixture(),
    c = new CustomerBookingController(
      f.api,
      f.store,
      { name: '', phone: 'x' },
      () => clock,
    );
  await c.restore();
  c.setActive(true);
  c.selectPlace('pickup', p);
  c.selectPlace('destination', d);
  await c.calculate();
  await c.submit();
  assert.match(c.getSnapshot().error, /Namen/);
  assert.equal(f.writes.length, 0);
  c.setDetails({ riderName: 'Test', riderPhone: '+4912345678' });
  c.setDetails({ refreshments: { water: 13 } });
  assert.deepEqual(c.getSnapshot().refreshments, {});
  clock = now + 300001;
  await c.submit();
  assert.match(c.getSnapshot().error, /abgelaufen/);
  assert.equal(f.writes.length, 0);
  clock = now;
  await c.submit();
  assert.ok(c.getSnapshot().booking);
  c.newDraft();
  assert.equal(c.getSnapshot().booking, null);
  assert.equal(c.getSnapshot().quote, null);
});
