import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  resolve(s, c, n) {
    if (s === 'cloudflare:workers' || s === 'next/headers')
      return { url: 'test:' + s, shortCircuit: true };
    return n(s, c);
  },
  load(u, c, n) {
    if (u === 'test:cloudflare:workers')
      return {
        format: 'module',
        shortCircuit: true,
        source:
          'export const env = new Proxy({}, {get:(_t,p)=>globalThis.accountTest.env[p]});',
      };
    if (u === 'test:next/headers')
      return {
        format: 'module',
        shortCircuit: true,
        source: 'export const headers=async()=>globalThis.accountTest.headers;',
      };
    if (u.endsWith('/app/chatgpt-auth.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source:
          'export const getChatGPTUser=async()=>globalThis.accountTest.platformUser;',
      };
    return n(u, c);
  },
});
const { POST, GET } = await import('../app/api/mobility/account/route.ts');
const { POST: manage, GET: overview } =
  await import('../app/api/mobility/operator/route.ts');
const { identity, tokenHash } = await import('../lib/mobility/server.ts');
const { POST: fleetWrite } =
  await import('../app/api/mobility/fleets/route.ts');
const oldFetch = globalThis.fetch;
function fixture(ready = true) {
  const sqlite = new DatabaseSync(':memory:');
  for (const f of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((f) => f.endsWith('.sql'))
    .sort())
    sqlite.exec(
      readFileSync(new URL('../drizzle/' + f, import.meta.url), 'utf8'),
    );
  const db = {
    prepare(sql) {
      let values = [];
      return {
        bind(...v) {
          values = v;
          return this;
        },
        async first() {
          return sqlite.prepare(sql).get(...values) || null;
        },
        async all() {
          return { results: sqlite.prepare(sql).all(...values) };
        },
        async run() {
          const r = sqlite.prepare(sql).run(...values);
          return { meta: { changes: Number(r.changes) } };
        },
      };
    },
    async batch(statements) {
      sqlite.exec('BEGIN');
      try {
        const r = [];
        for (const s of statements) r.push(await s.run());
        sqlite.exec('COMMIT');
        return r;
      } catch (e) {
        sqlite.exec('ROLLBACK');
        throw e;
      }
    },
  };
  globalThis.accountTest = {
    headers: new Headers(),
    platformUser: null,
    env: {
      DB: db,
      LUXORE_ADMIN_EMAIL: 'owner@example.test',
      ...(ready
        ? {
            RESEND_API_KEY: 'synthetic-no-network',
            LUXORE_MAIL_FROM: 'Luxore <test@example.test>',
          }
        : {}),
    },
  };
  const sent = [];
  globalThis.fetch = async (input, options) => {
    assert.equal(input, 'https://api.resend.com/emails');
    const b = JSON.parse(options.body);
    sent.push({
      email: b.to[0],
      code: b.text.match(/Anmeldecode: ([0-9]{6})/)[1],
    });
    return Response.json({ id: 'synthetic-mail' });
  };
  return {
    sqlite,
    sent,
    close() {
      sqlite.close();
      globalThis.fetch = oldFetch;
    },
  };
}
function request(value, origin = 'https://test.invalid') {
  return new Request('https://test.invalid/api/mobility/account', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Origin: origin },
    body: JSON.stringify(value),
  });
}
async function call(value) {
  const r = await POST(request(value));
  return { r, value: await r.json() };
}
function cookies(response) {
  return response.headers
    .getSetCookie()
    .map((s) => s.split(';')[0])
    .join('; ');
}
async function signup(f, email = 'rider@example.test', kind = 'customer') {
  const r = await call({
    action: 'code',
    mode: 'register',
    email,
    name: 'Synthetic Test',
    phone: '+4900000000',
    kind,
    privacy: true,
  });
  assert.equal(r.r.status, 200, JSON.stringify(r.value));
  const confirmed = await call({
    action: 'verify',
    challengeId: r.value.challengeId,
    code: f.sent.at(-1).code,
  });
  assert.equal(confirmed.r.status, 200, JSON.stringify(confirmed.value));
  globalThis.accountTest.headers = new Headers({
    cookie: cookies(confirmed.r),
  });
  return confirmed;
}
test('mail is required: unavailable registration stores no personal data and never pretends to send', async () => {
  const f = fixture(false);
  try {
    assert.equal((await GET().then((r) => r.json())).registrationReady, false);
    assert.equal(
      (
        await call({
          action: 'code',
          mode: 'register',
          email: 'x@example.test',
        })
      ).r.status,
      503,
    );
    assert.equal(
      f.sqlite
        .prepare('SELECT COUNT(*) n FROM mobility_account_challenges')
        .get().n,
      0,
    );
    assert.equal(f.sent.length, 0);
  } finally {
    f.close();
  }
});
test('verified registration adopts only its proven idle device profile, revokes guest keys and stays driver-unapproved', async () => {
  const f = fixture();
  try {
    const token = 'a'.repeat(64);
    f.sqlite
      .prepare('INSERT INTO mobility_sessions VALUES(?,?,?)')
      .run(await tokenHash(token), 'device:existing', Date.now() + 600000);
    globalThis.accountTest.headers = new Headers({
      cookie: 'luxore_device=' + token,
    });
    const verified = await signup(f, 'driver@example.test', 'driver');
    assert.equal(verified.value.account.id, 'device:existing');
    assert.equal(verified.value.isAdmin, false);
    assert.equal((await identity()).userId, 'device:existing');
    assert.equal(
      f.sqlite.prepare('SELECT approved FROM mobility_drivers').get().approved,
      0,
    );
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) n FROM mobility_sessions').get().n,
      0,
    );
    assert.match(
      verified.r.headers.getSetCookie()[0],
      /HttpOnly; SameSite=Strict; Secure/,
    );
    assert.equal(
      f.sqlite
        .prepare('SELECT code_hash FROM mobility_account_challenges')
        .get().code_hash.length,
      64,
    );
    assert.notEqual(
      f.sqlite
        .prepare('SELECT code_hash FROM mobility_account_challenges')
        .get().code_hash,
      f.sent[0].code,
    );
  } finally {
    f.close();
  }
});
test('codes expire, allow at most five attempts and can never be replayed', async () => {
  const f = fixture();
  try {
    const begun = await call({
      action: 'code',
      mode: 'register',
      email: 'attempt@example.test',
      name: 'Test',
      phone: '+49000000',
      kind: 'customer',
      privacy: true,
    });
    const challengeId = begun.value.challengeId;
    const correct = f.sent[0].code;
    for (let i = 0; i < 5; i++)
      assert.equal(
        (
          await call({
            action: 'verify',
            challengeId,
            code: correct === '000000' ? '111111' : '000000',
          })
        ).r.status,
        400,
      );
    assert.equal(
      (await call({ action: 'verify', challengeId, code: correct })).r.status,
      400,
    );
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) n FROM mobility_accounts').get().n,
      0,
    );
    const valid = await signup(f, 'valid@example.test');
    const used = f.sqlite
      .prepare('SELECT id FROM mobility_account_challenges WHERE email=?')
      .get('valid@example.test').id;
    assert.equal(
      (
        await call({
          action: 'verify',
          challengeId: used,
          code: f.sent.at(-1).code,
        })
      ).r.status,
      400,
    );
    globalThis.accountTest.headers = new Headers();
    const expired = await call({
      action: 'code',
      mode: 'register',
      email: 'expired@example.test',
      name: 'Test',
      phone: '+49000000',
      kind: 'customer',
      privacy: true,
    });
    f.sqlite
      .prepare('UPDATE mobility_account_challenges SET expires_at=0 WHERE id=?')
      .run(expired.value.challengeId);
    assert.equal(
      (
        await call({
          action: 'verify',
          challengeId: expired.value.challengeId,
          code: f.sent.at(-1).code,
        })
      ).r.status,
      400,
    );
    assert.ok(valid.value.account.id);
  } finally {
    f.close();
  }
});
test('login restores the same identity on another device; verification beats unrelated platform identity', async () => {
  const f = fixture();
  try {
    const first = await signup(f);
    const userId = first.value.account.id;
    globalThis.accountTest.headers = new Headers();
    f.sqlite
      .prepare('UPDATE mobility_account_challenges SET created_at=0')
      .run();
    const login = await call({
      action: 'code',
      mode: 'login',
      email: 'rider@example.test',
    });
    const second = await call({
      action: 'verify',
      challengeId: login.value.challengeId,
      code: f.sent.at(-1).code,
    });
    assert.equal(second.r.status, 200);
    assert.equal(second.value.account.id, userId);
    globalThis.accountTest.headers = new Headers({ cookie: cookies(second.r) });
    globalThis.accountTest.platformUser = {
      userId: 'unrelated',
      email: 'unrelated@example.test',
    };
    assert.equal((await identity()).userId, userId);
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) n FROM mobility_accounts').get().n,
      1,
    );
  } finally {
    f.close();
  }
});
test('operator overview denies customers and guests, exposes no secrets, and blocking revokes account access', async () => {
  const f = fixture();
  try {
    const first = await signup(f);
    const id = first.value.account.id;
    const customerCookies = cookies(first.r);
    assert.equal(
      (
        await overview(
          new Request('https://test.invalid/api/mobility/operator'),
        )
      ).status,
      403,
    );
    globalThis.accountTest.headers = new Headers();
    globalThis.accountTest.platformUser = {
      userId: 'operator',
      email: 'owner@example.test',
      displayName: 'Owner',
    };
    const r = await overview(
      new Request('https://test.invalid/api/mobility/operator'),
    );
    assert.equal(r.status, 200);
    const data = await r.json();
    assert.equal(data.summary.accounts, 1);
    assert.equal(data.profiles[0].email, 'rider@example.test');
    assert.ok(!JSON.stringify(data).includes('token_hash'));
    assert.ok(!JSON.stringify(data).includes('synthetic-no-network'));
    assert.equal(
      (await manage(request({ action: 'block', accountId: id }))).status,
      200,
    );
    globalThis.accountTest.platformUser = null;
    globalThis.accountTest.headers = new Headers({ cookie: customerCookies });
    assert.equal((await GET().then((r) => r.json())).account, null);
    await assert.rejects(identity(), (e) => e.status === 401);
    globalThis.accountTest.headers = new Headers();
    globalThis.accountTest.platformUser = {
      userId: 'operator',
      email: 'owner@example.test',
      displayName: 'Owner',
    };
    assert.equal(
      (await manage(request({ action: 'restore', accountId: id }))).status,
      200,
    );
  } finally {
    f.close();
  }
});
test('logout cannot abandon a shift, and deletion goes to operator queue before personal data is erased', async () => {
  const f = fixture();
  try {
    const first = await signup(f, 'delete@example.test', 'driver');
    const id = first.value.account.id;
    f.sqlite
      .prepare('UPDATE mobility_drivers SET online=1,session_id=? WHERE id=?')
      .run('shift', id);
    assert.equal((await call({ action: 'logout' })).r.status, 409);
    assert.equal(
      (await call({ action: 'delete', confirmation: 'LÖSCHEN' })).r.status,
      409,
    );
    f.sqlite
      .prepare(
        'UPDATE mobility_drivers SET online=0,session_id=NULL WHERE id=?',
      )
      .run(id);
    assert.equal(
      (await call({ action: 'delete', confirmation: 'LÖSCHEN' })).r.status,
      200,
    );
    assert.equal(
      f.sqlite
        .prepare('SELECT status FROM mobility_accounts WHERE id=?')
        .get(id).status,
      'deletion_pending',
    );
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) n FROM mobility_account_sessions').get()
        .n,
      0,
    );
    globalThis.accountTest.headers = new Headers();
    globalThis.accountTest.platformUser = {
      userId: 'operator',
      email: 'owner@example.test',
      displayName: 'Owner',
    };
    assert.equal(
      (
        await manage(
          request({ action: 'erase', accountId: id, confirmation: 'LÖSCHEN' }),
        )
      ).status,
      200,
    );
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) n FROM mobility_accounts').get().n,
      0,
    );
    assert.equal(
      f.sqlite.prepare('SELECT name,phone FROM mobility_drivers').get().name,
      'Gelöschtes Profil',
    );
    assert.equal(
      f.sqlite
        .prepare('SELECT COUNT(*) n FROM mobility_account_challenges')
        .get().n,
      0,
    );
  } finally {
    f.close();
  }
});
test('origin checks and profile kinds prevent public privilege grants', async () => {
  const f = fixture();
  try {
    assert.equal(
      (
        await POST(
          request(
            { action: 'code', mode: 'register', email: 'x@example.test' },
            'https://attacker.invalid',
          ),
        )
      ).status,
      403,
    );
    assert.equal(
      (
        await call({
          action: 'code',
          mode: 'register',
          email: 'x@example.test',
          name: 'Test',
          phone: '+49000000',
          kind: 'admin',
          privacy: true,
        })
      ).r.status,
      400,
    );
    assert.equal(f.sent.length, 0);
    assert.equal(
      (
        await overview(
          new Request('https://test.invalid/api/mobility/operator'),
        )
      ).status,
      401,
    );
  } finally {
    f.close();
  }
});

test('fleet ownership transfer is operator-only, scoped to approved idle employees, and rejects stale owners', async () => {
  const f = fixture();
  try {
    f.sqlite
      .exec(`INSERT INTO mobility_fleets(id,name,owner_id,deputy_id,created_at) VALUES('f','Test Fleet','old','next',0);
   INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online) VALUES('old','Old','000000','','','premium',1,0),('next','Next','000000','','','premium',1,0),('outsider','Other','000000','','','premium',1,0);
   INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('old','Old','000000','f','driver',0),('next','Next','000000','f','driver',0);`);
    const payload = {
      action: 'transfer_owner',
      fleetId: 'f',
      previousOwnerId: 'old',
      ownerId: 'next',
      confirmed: true,
    };
    assert.equal((await fleetWrite(request(payload))).status, 401);
    globalThis.accountTest.platformUser = {
      userId: 'old',
      email: 'driver@example.test',
      displayName: 'Old',
    };
    assert.equal((await fleetWrite(request(payload))).status, 403);
    globalThis.accountTest.platformUser = {
      userId: 'operator',
      email: 'owner@example.test',
      displayName: 'Owner',
    };
    assert.equal(
      (await fleetWrite(request({ ...payload, ownerId: 'outsider' }))).status,
      409,
    );
    f.sqlite
      .prepare('UPDATE mobility_drivers SET online=1 WHERE id=?')
      .run('next');
    assert.equal((await fleetWrite(request(payload))).status, 409);
    f.sqlite
      .prepare('UPDATE mobility_drivers SET online=0 WHERE id=?')
      .run('next');
    assert.equal(
      (await fleetWrite(request({ ...payload, confirmed: false }))).status,
      400,
    );
    assert.equal((await fleetWrite(request(payload))).status, 200);
    const fleet = f.sqlite
      .prepare('SELECT owner_id,deputy_id FROM mobility_fleets')
      .get();
    assert.equal(fleet.owner_id, 'next');
    assert.equal(fleet.deputy_id, null);
    assert.equal((await fleetWrite(request(payload))).status, 409);
    assert.equal(
      f.sqlite
        .prepare(
          'SELECT COUNT(*) n FROM mobility_operator_audit WHERE action=?',
        )
        .get('fleet.owner_transferred').n,
      1,
    );
  } finally {
    f.close();
  }
});
