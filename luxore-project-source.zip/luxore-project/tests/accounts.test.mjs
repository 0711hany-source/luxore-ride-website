import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import test from 'node:test';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
registerHooks({
  resolve(s, c, n) {
    if (s === 'next/headers')
      return { url: 'test:headers', shortCircuit: true };
    return n(s, c);
  },
  load(u, c, n) {
    if (u === 'test:headers')
      return {
        format: 'module',
        shortCircuit: true,
        source: 'export const headers=async()=>globalThis.accountTest.headers;',
      };
    if (u.endsWith('/db/sqlite.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source:
          'export const accountsConfigured=()=>true; export const runtimeDatabase=()=>globalThis.accountTest.env.DB; export class DatabaseUnavailable extends Error {}',
      };
    return n(u, c);
  },
});
const { POST, GET } = await import('../app/api/mobility/account/route.ts');
const { POST: openNativeScreen, GET: openAndroidScreen } =
  await import('../app/api/mobility/app-session/route.ts');
const { POST: manage, GET: overview } =
  await import('../app/api/mobility/operator/route.ts');
const { identity, tokenHash } = await import('../lib/mobility/server.ts');
const { webviewSessionSource } =
  await import('../mobile/src/webview-session.ts');
const { POST: fleetWrite } =
  await import('../app/api/mobility/fleets/route.ts');
const oldFetch = globalThis.fetch;
function fixture(ready = true) {
  const sqlite = new DatabaseSync(':memory:');
  for (const f of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((f) => f.endsWith('.sql'))
    .sort())
    sqlite.exec(
      readFileSync(new URL('../drizzle/' + f, import.meta.url), 'utf8'),
    );
  const db = {
    prepare(sql) {
      let values = [];
      return {
        bind(...v) {
          values = v;
          return this;
        },
        async first() {
          return sqlite.prepare(sql).get(...values) || null;
        },
        async all() {
          return { results: sqlite.prepare(sql).all(...values) };
        },
        async run() {
          const r = sqlite.prepare(sql).run(...values);
          return { meta: { changes: Number(r.changes) } };
        },
      };
    },
    async batch(statements) {
      sqlite.exec('BEGIN');
      try {
        const r = [];
        for (const s of statements) r.push(await s.run());
        sqlite.exec('COMMIT');
        return r;
      } catch (e) {
        sqlite.exec('ROLLBACK');
        throw e;
      }
    },
  };
  globalThis.accountTest = {
    headers: new Headers(),
    env: {
      DB: db,
      LUXORE_ADMIN_EMAIL: 'owner@example.test',
      ...(ready
        ? {
            RESEND_API_KEY: 'synthetic-no-network',
            LUXORE_MAIL_FROM: 'Luxore <test@example.test>',
          }
        : {}),
    },
  };
  const oldEnv = {};
  for (const key of [
    'LUXORE_ADMIN_EMAIL',
    'RESEND_API_KEY',
    'LUXORE_MAIL_FROM',
  ]) {
    oldEnv[key] = process.env[key];
    const v = globalThis.accountTest.env[key];
    if (v) process.env[key] = v;
    else delete process.env[key];
  }
  const sent = [];
  globalThis.fetch = async (input, options) => {
    assert.equal(input, 'https://api.resend.com/emails');
    const b = JSON.parse(options.body);
    sent.push({
      email: b.to[0],
      code: b.text.match(/Anmeldecode: ([0-9]{6})/)[1],
    });
    return Response.json({ id: 'synthetic-mail' });
  };
  return {
    sqlite,
    sent,
    close() {
      sqlite.close();
      for (const [k, v] of Object.entries(oldEnv)) {
        if (v === undefined) delete process.env[k];
        else process.env[k] = v;
      }
      globalThis.fetch = oldFetch;
    },
  };
}
function session(f, id, email) {
  const now = Date.now(),
    token = 'f'.repeat(64);
  f.sqlite
    .prepare(
      "INSERT OR IGNORE INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES(?,?,?,'000000','customer','active',?,?)",
    )
    .run(id, email, id, now, now);
  const hash = createHash('sha256').update(token).digest('hex');
  f.sqlite
    .prepare(
      'INSERT INTO mobility_account_sessions(token_hash,account_id,verified_at,expires_at) VALUES(?,?,?,?) ON CONFLICT(token_hash) DO UPDATE SET account_id=excluded.account_id,expires_at=excluded.expires_at',
    )
    .run(hash, id, now, now + 3600000);
  globalThis.accountTest.headers = new Headers({
    cookie: 'luxore_account=' + token,
  });
}
function operator(f) {
  session(f, 'operator', 'owner@example.test');
}
function request(value, origin = 'https://test.invalid') {
  return new Request('https://test.invalid/api/mobility/account', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Origin: origin },
    body: JSON.stringify(value),
  });
}
async function call(value) {
  const r = await POST(request(value));
  return { r, value: await r.json() };
}
function cookies(response) {
  return response.headers
    .getSetCookie()
    .map((s) => s.split(';')[0])
    .join('; ');
}
async function signup(f, email = 'rider@example.test', kind = 'customer') {
  const r = await call({
    action: 'code',
    mode: 'register',
    email,
    name: 'Synthetic Test',
    phone: '+4900000000',
    kind,
    privacy: true,
  });
  assert.equal(r.r.status, 200, JSON.stringify(r.value));
  const confirmed = await call({
    action: 'verify',
    challengeId: r.value.challengeId,
    code: f.sent.at(-1).code,
  });
  assert.equal(confirmed.r.status, 200, JSON.stringify(confirmed.value));
  globalThis.accountTest.headers = new Headers({
    cookie: cookies(confirmed.r),
  });
  return confirmed;
}
test('mail is required: unavailable registration stores no personal data and never pretends to send', async () => {
  const f = fixture(false);
  try {
    assert.equal((await GET().then((r) => r.json())).registrationReady, false);
    assert.equal(
      (
        await call({
          action: 'code',
          mode: 'register',
          email: 'x@example.test',
        })
      ).r.status,
      503,
    );
    assert.equal(
      f.sqlite
        .prepare('SELECT COUNT(*) n FROM mobility_account_challenges')
        .get().n,
      0,
    );
    assert.equal(f.sent.length, 0);
  } finally {
    f.close();
  }
});
test('native sessions require email verification, transfer through HttpOnly cookie and cannot redirect off-site', async () => {
  const f = fixture();
  try {
    globalThis.accountTest.headers = new Headers({
      'x-luxore-client': 'native-v1',
    });
    const verified = await signup(f, 'native@example.test');
    const token = verified.value.sessionToken;
    assert.match(token, /^[a-f0-9]{64}$/);
    assert.ok(verified.value.sessionExpiresAt > Date.now());
    globalThis.accountTest.headers = new Headers({
      authorization: 'Bearer ' + token,
    });
    const read = await GET().then((r) => r.json());
    assert.equal(read.account.email, 'native@example.test');
    assert.equal(read.isAdmin, false);
    const transferred = await openNativeScreen(
      request({ target: '/mobile/customer' }),
    );
    assert.equal(transferred.status, 303);
    assert.equal(
      transferred.headers.get('location'),
      'https://test.invalid/mobile/customer',
    );
    assert.match(
      transferred.headers.get('set-cookie'),
      /HttpOnly; SameSite=Strict; Secure/,
    );
    assert.equal(await transferred.text(), '');
    assert.equal(
      (await openNativeScreen(request({ target: 'https://attacker.invalid' })))
        .status,
      400,
    );
    globalThis.accountTest.headers = new Headers({
      authorization: 'Bearer invalid',
      cookie: cookies(verified.r),
    });
    assert.equal((await GET().then((r) => r.json())).account, null);
    assert.equal(
      (await openNativeScreen(request({ target: '/mobile/customer' }))).status,
      401,
    );
    globalThis.accountTest.headers = new Headers({
      authorization: 'Bearer ' + token,
    });
    f.sqlite.prepare('UPDATE mobility_account_sessions SET expires_at=0').run();
    assert.equal(
      (await openNativeScreen(request({ target: '/mobile/customer' }))).status,
      401,
    );
  } finally {
    f.close();
  }
});
test('Android WebView transfers verified accounts using GET headers and no URL or body credentials', async () => {
  const f = fixture();
  try {
    globalThis.accountTest.headers = new Headers({
      'x-luxore-client': 'native-v1',
    });
    const verified = await signup(f, 'android@example.test');
    const token = verified.value.sessionToken;
    for (const target of [
      '/mobile/customer',
      '/mobile/driver',
      '/disposition',
      '/betreiber',
    ]) {
      const source = webviewSessionSource(target, token);
      assert.equal(source.method, 'GET'); // Android applies custom headers only on this path.
      assert.equal('body' in source, false);
      assert.equal(source.uri.includes(token), false);
      globalThis.accountTest.headers = new Headers(source.headers);
      const response = await openAndroidScreen(
        new Request(source.uri, {
          method: source.method,
          headers: source.headers,
        }),
      );
      assert.equal(response.status, 303);
      assert.equal(
        response.headers.get('location'),
        'https://luxoreride.de' + target,
      );
      assert.equal(response.headers.get('referrer-policy'), 'no-referrer');
      assert.equal(response.headers.get('cache-control'), 'private, no-store');
      assert.match(
        response.headers.get('set-cookie'),
        /HttpOnly; SameSite=Strict; Secure/,
      );
      assert.equal(await response.text(), '');
    }
    assert.deepEqual(webviewSessionSource('/mobile/driver', null), {
      uri: 'https://luxoreride.de/mobile/driver',
    });
    assert.throws(
      () => webviewSessionSource('/mobile/driver', 'invalid'),
      /anmelden/,
    );
    assert.throws(
      () => webviewSessionSource('https://attacker.invalid', token),
      /App-Bildschirm/,
    );
  } finally {
    f.close();
  }
});

test('Android session bridge rejects browser-cookie-only, expired and blocked sessions, cross-site requests and external targets', async () => {
  const f = fixture();
  try {
    globalThis.accountTest.headers = new Headers({
      'x-luxore-client': 'native-v1',
    });
    const verified = await signup(f, 'android-guard@example.test');
    const token = verified.value.sessionToken;
    const open = async (target = '/mobile/driver', extra = {}) => {
      const source = webviewSessionSource('/mobile/driver', token);
      const h = new Headers({ ...source.headers, ...extra });
      globalThis.accountTest.headers = h;
      return openAndroidScreen(
        new Request(
          'https://luxoreride.de/api/mobility/app-session?target=' +
            encodeURIComponent(target),
          { headers: h },
        ),
      );
    };
    for (const extra of [
      { Origin: 'https://attacker.invalid' },
      { Origin: 'null' },
      { 'Sec-Fetch-Site': 'cross-site' },
    ]) {
      const r = await open('/mobile/driver', extra);
      assert.equal(r.status, 403);
      assert.equal(r.headers.get('set-cookie'), null);
    }
    for (const target of [
      'https://attacker.invalid',
      '//attacker.invalid',
      '/api/mobility/account',
      '/mobile/driver?token=' + token,
    ])
      assert.equal((await open(target)).status, 400);
    const noBearer = await open('/mobile/driver', {
      Authorization: '',
      Cookie: cookies(verified.r),
    });
    assert.equal(noBearer.status, 401);
    assert.equal(noBearer.headers.get('set-cookie'), null);
    f.sqlite.prepare("UPDATE mobility_accounts SET status='blocked'").run();
    assert.equal((await open()).status, 401);
    f.sqlite.prepare("UPDATE mobility_accounts SET status='active'").run();
    f.sqlite.prepare('UPDATE mobility_account_sessions SET expires_at=0').run();
    assert.equal((await open()).status, 401);
    // Legacy Android postUrl loses Origin and Authorization; never weaken all POST checks to accommodate it.
    assert.equal(
      (
        await openNativeScreen(
          new Request('https://luxoreride.de/api/mobility/app-session', {
            method: 'POST',
            body: JSON.stringify({ target: '/mobile/driver' }),
          }),
        )
      ).status,
      403,
    );
  } finally {
    f.close();
  }
});

test('browser verification never includes a raw native session in JSON', async () => {
  const f = fixture();
  try {
    const verified = await signup(f, 'browser@example.test');
    assert.equal(verified.value.sessionToken, undefined);
  } finally {
    f.close();
  }
});
test('first owner login provisions access only after proving the configured email; other logins require registration', async () => {
  const f = fixture();
  try {
    const begun = await call({
      action: 'code',
      mode: 'login',
      email: 'owner@example.test',
    });
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) n FROM mobility_accounts').get().n,
      0,
    );
    const verified = await call({
      action: 'verify',
      challengeId: begun.value.challengeId,
      code: f.sent.at(-1).code,
    });
    assert.equal(verified.r.status, 200);
    assert.equal(verified.value.isAdmin, true);
    assert.equal(verified.value.account.kind, 'fleet');
    assert.equal(
      f.sqlite.prepare('SELECT approved FROM mobility_drivers').get().approved,
      0,
    );
    globalThis.accountTest.headers = new Headers();
    const other = await call({
      action: 'code',
      mode: 'login',
      email: 'other@example.test',
    });
    assert.equal(
      (
        await call({
          action: 'verify',
          challengeId: other.value.challengeId,
          code: f.sent.at(-1).code,
        })
      ).r.status,
      400,
    );
  } finally {
    f.close();
  }
});
test('native marketplace mail domain supplies sender without copying integration key', async () => {
  const f = fixture();
  const old = process.env.RESEND_EMAIL_DOMAIN;
  try {
    delete process.env.LUXORE_MAIL_FROM;
    process.env.RESEND_EMAIL_DOMAIN = 'luxore.example.test';
    assert.equal((await GET().then((r) => r.json())).registrationReady, true);
    process.env.RESEND_EMAIL_DOMAIN = 'evil.example.test\nInjected: yes';
    assert.equal((await GET().then((r) => r.json())).registrationReady, false);
  } finally {
    if (old === undefined) delete process.env.RESEND_EMAIL_DOMAIN;
    else process.env.RESEND_EMAIL_DOMAIN = old;
    f.close();
  }
});
test('verified registration adopts only its proven idle device profile, revokes guest keys and stays driver-unapproved', async () => {
  const f = fixture();
  try {
    const token = 'a'.repeat(64);
    f.sqlite
      .prepare('INSERT INTO mobility_sessions VALUES(?,?,?)')
      .run(await tokenHash(token), 'device:existing', Date.now() + 600000);
    globalThis.accountTest.headers = new Headers({
      cookie: 'luxore_device=' + token,
    });
    const verified = await signup(f, 'driver@example.test', 'driver');
    assert.equal(verified.value.account.id, 'device:existing');
    assert.equal(verified.value.isAdmin, false);
    assert.equal((await identity()).userId, 'device:existing');
    assert.equal(
      f.sqlite.prepare('SELECT approved FROM mobility_drivers').get().approved,
      0,
    );
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) n FROM mobility_sessions').get().n,
      0,
    );
    assert.match(
      verified.r.headers.getSetCookie()[0],
      /HttpOnly; SameSite=Strict; Secure/,
    );
    assert.equal(
      f.sqlite
        .prepare('SELECT code_hash FROM mobility_account_challenges')
        .get().code_hash.length,
      64,
    );
    assert.notEqual(
      f.sqlite
        .prepare('SELECT code_hash FROM mobility_account_challenges')
        .get().code_hash,
      f.sent[0].code,
    );
  } finally {
    f.close();
  }
});
test('codes expire, allow at most five attempts and can never be replayed', async () => {
  const f = fixture();
  try {
    const begun = await call({
      action: 'code',
      mode: 'register',
      email: 'attempt@example.test',
      name: 'Test',
      phone: '+49000000',
      kind: 'customer',
      privacy: true,
    });
    const challengeId = begun.value.challengeId;
    const correct = f.sent[0].code;
    for (let i = 0; i < 5; i++)
      assert.equal(
        (
          await call({
            action: 'verify',
            challengeId,
            code: correct === '000000' ? '111111' : '000000',
          })
        ).r.status,
        400,
      );
    assert.equal(
      (await call({ action: 'verify', challengeId, code: correct })).r.status,
      400,
    );
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) n FROM mobility_accounts').get().n,
      0,
    );
    const valid = await signup(f, 'valid@example.test');
    const used = f.sqlite
      .prepare('SELECT id FROM mobility_account_challenges WHERE email=?')
      .get('valid@example.test').id;
    assert.equal(
      (
        await call({
          action: 'verify',
          challengeId: used,
          code: f.sent.at(-1).code,
        })
      ).r.status,
      400,
    );
    globalThis.accountTest.headers = new Headers();
    const expired = await call({
      action: 'code',
      mode: 'register',
      email: 'expired@example.test',
      name: 'Test',
      phone: '+49000000',
      kind: 'customer',
      privacy: true,
    });
    f.sqlite
      .prepare('UPDATE mobility_account_challenges SET expires_at=0 WHERE id=?')
      .run(expired.value.challengeId);
    assert.equal(
      (
        await call({
          action: 'verify',
          challengeId: expired.value.challengeId,
          code: f.sent.at(-1).code,
        })
      ).r.status,
      400,
    );
    assert.ok(valid.value.account.id);
  } finally {
    f.close();
  }
});
test('login restores the same identity on another device; untrusted request headers cannot replace a verified account', async () => {
  const f = fixture();
  try {
    const first = await signup(f);
    const userId = first.value.account.id;
    globalThis.accountTest.headers = new Headers();
    f.sqlite
      .prepare('UPDATE mobility_account_challenges SET created_at=0')
      .run();
    const login = await call({
      action: 'code',
      mode: 'login',
      email: 'rider@example.test',
    });
    const second = await call({
      action: 'verify',
      challengeId: login.value.challengeId,
      code: f.sent.at(-1).code,
    });
    assert.equal(second.r.status, 200);
    assert.equal(second.value.account.id, userId);
    globalThis.accountTest.headers = new Headers({ cookie: cookies(second.r) });
    globalThis.accountTest.headers.set(
      'untrusted-user-email',
      'owner@example.test',
    );
    assert.equal((await identity()).userId, userId);
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) n FROM mobility_accounts').get().n,
      1,
    );
  } finally {
    f.close();
  }
});
test('operator overview denies customers and guests, exposes no secrets, and blocking revokes account access', async () => {
  const f = fixture();
  try {
    const first = await signup(f);
    const id = first.value.account.id;
    const customerCookies = cookies(first.r);
    assert.equal(
      (
        await overview(
          new Request('https://test.invalid/api/mobility/operator'),
        )
      ).status,
      403,
    );
    globalThis.accountTest.headers = new Headers();
    operator(f);
    const r = await overview(
      new Request('https://test.invalid/api/mobility/operator'),
    );
    assert.equal(r.status, 200);
    const data = await r.json();
    assert.equal(data.summary.accounts, 2);
    assert.ok(data.profiles.some((p) => p.email === 'rider@example.test'));
    assert.ok(!JSON.stringify(data).includes('token_hash'));
    assert.ok(!JSON.stringify(data).includes('synthetic-no-network'));
    assert.equal(
      (await manage(request({ action: 'block', accountId: id }))).status,
      200,
    );
    globalThis.accountTest.headers = new Headers({ cookie: customerCookies });
    assert.equal((await GET().then((r) => r.json())).account, null);
    await assert.rejects(identity(), (e) => e.status === 401);
    globalThis.accountTest.headers = new Headers();
    operator(f);
    assert.equal(
      (await manage(request({ action: 'restore', accountId: id }))).status,
      200,
    );
  } finally {
    f.close();
  }
});
test('logout cannot abandon a shift, and deletion goes to operator queue before personal data is erased', async () => {
  const f = fixture();
  try {
    const first = await signup(f, 'delete@example.test', 'driver');
    const id = first.value.account.id;
    f.sqlite
      .prepare('UPDATE mobility_drivers SET online=1,session_id=? WHERE id=?')
      .run('shift', id);
    assert.equal((await call({ action: 'logout' })).r.status, 409);
    assert.equal(
      (await call({ action: 'delete', confirmation: 'LÖSCHEN' })).r.status,
      409,
    );
    f.sqlite
      .prepare(
        'UPDATE mobility_drivers SET online=0,session_id=NULL WHERE id=?',
      )
      .run(id);
    assert.equal(
      (await call({ action: 'delete', confirmation: 'LÖSCHEN' })).r.status,
      200,
    );
    assert.equal(
      f.sqlite
        .prepare('SELECT status FROM mobility_accounts WHERE id=?')
        .get(id).status,
      'deletion_pending',
    );
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) n FROM mobility_account_sessions').get()
        .n,
      0,
    );
    globalThis.accountTest.headers = new Headers();
    operator(f);
    assert.equal(
      (
        await manage(
          request({ action: 'erase', accountId: id, confirmation: 'LÖSCHEN' }),
        )
      ).status,
      200,
    );
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) n FROM mobility_accounts').get().n,
      1,
    );
    assert.equal(
      f.sqlite.prepare('SELECT name,phone FROM mobility_drivers').get().name,
      'Gelöschtes Profil',
    );
    assert.equal(
      f.sqlite
        .prepare('SELECT COUNT(*) n FROM mobility_account_challenges')
        .get().n,
      0,
    );
  } finally {
    f.close();
  }
});
test('origin checks and profile kinds prevent public privilege grants', async () => {
  const f = fixture();
  try {
    assert.equal(
      (
        await POST(
          request(
            { action: 'code', mode: 'register', email: 'x@example.test' },
            'https://attacker.invalid',
          ),
        )
      ).status,
      403,
    );
    assert.equal(
      (
        await call({
          action: 'code',
          mode: 'register',
          email: 'x@example.test',
          name: 'Test',
          phone: '+49000000',
          kind: 'admin',
          privacy: true,
        })
      ).r.status,
      400,
    );
    assert.equal(f.sent.length, 0);
    assert.equal(
      (
        await overview(
          new Request('https://test.invalid/api/mobility/operator'),
        )
      ).status,
      401,
    );
  } finally {
    f.close();
  }
});

test('fleet ownership transfer is operator-only, scoped to approved idle employees, and rejects stale owners', async () => {
  const f = fixture();
  try {
    f.sqlite
      .exec(`INSERT INTO mobility_fleets(id,name,owner_id,deputy_id,created_at) VALUES('f','Test Fleet','old','next',0);
   INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online) VALUES('old','Old','000000','','','premium',1,0),('next','Next','000000','','','premium',1,0),('outsider','Other','000000','','','premium',1,0);
   INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('old','Old','000000','f','driver',0),('next','Next','000000','f','driver',0);`);
    const payload = {
      action: 'transfer_owner',
      fleetId: 'f',
      previousOwnerId: 'old',
      ownerId: 'next',
      confirmed: true,
    };
    assert.equal((await fleetWrite(request(payload))).status, 401);
    session(f, 'old', 'driver@example.test');
    assert.equal((await fleetWrite(request(payload))).status, 403);
    operator(f);
    assert.equal(
      (await fleetWrite(request({ ...payload, ownerId: 'outsider' }))).status,
      409,
    );
    f.sqlite
      .prepare('UPDATE mobility_drivers SET online=1 WHERE id=?')
      .run('next');
    assert.equal((await fleetWrite(request(payload))).status, 409);
    f.sqlite
      .prepare('UPDATE mobility_drivers SET online=0 WHERE id=?')
      .run('next');
    assert.equal(
      (await fleetWrite(request({ ...payload, confirmed: false }))).status,
      400,
    );
    assert.equal((await fleetWrite(request(payload))).status, 200);
    const fleet = f.sqlite
      .prepare('SELECT owner_id,deputy_id FROM mobility_fleets')
      .get();
    assert.equal(fleet.owner_id, 'next');
    assert.equal(fleet.deputy_id, null);
    assert.equal((await fleetWrite(request(payload))).status, 409);
    assert.equal(
      f.sqlite
        .prepare(
          'SELECT COUNT(*) n FROM mobility_operator_audit WHERE action=?',
        )
        .get('fleet.owner_transferred').n,
      1,
    );
  } finally {
    f.close();
  }
});

test('fleet creation can be retried after a lost response without duplicating or changing membership', async () => {
  const f = fixture();
  try {
    operator(f);
    const payload = {
      action: 'create',
      name: 'Synthetic Fleet',
      requestId: crypto.randomUUID(),
    };
    const first = await fleetWrite(request(payload));
    assert.equal(first.status, 201);
    const created = await first.json();
    assert.equal(created.id, payload.requestId);
    const before = f.sqlite
      .prepare('SELECT * FROM mobility_employees WHERE user_id=?')
      .get('operator');
    const retry = await fleetWrite(request(payload));
    assert.equal(retry.status, 200);
    assert.deepEqual(await retry.json(), {
      id: created.id,
      name: payload.name,
      replayed: true,
    });
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) AS n FROM mobility_fleets').get().n,
      1,
    );
    assert.deepEqual(
      f.sqlite
        .prepare('SELECT * FROM mobility_employees WHERE user_id=?')
        .get('operator'),
      before,
    );
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) AS n FROM mobility_drivers').get().n,
      0,
    );
    assert.equal(
      (
        await fleetWrite(
          request({ ...payload, requestId: crypto.randomUUID() }),
        )
      ).status,
      409,
    );
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) AS n FROM mobility_fleets').get().n,
      1,
    );
  } finally {
    f.close();
  }
});

test('fleet retry IDs reject changed owners, changed names and stale records without overwriting data', async () => {
  const f = fixture();
  try {
    operator(f);
    const payload = {
      action: 'create',
      name: 'Synthetic Fleet',
      requestId: crypto.randomUUID(),
    };
    assert.equal((await fleetWrite(request(payload))).status, 201);
    const before = f.sqlite.prepare('SELECT * FROM mobility_fleets').get();
    assert.equal(
      (await fleetWrite(request({ ...payload, name: 'Other name' }))).status,
      409,
    );
    assert.equal(
      (await fleetWrite(request({ ...payload, ownerId: 'other-owner' })))
        .status,
      409,
    );
    assert.deepEqual(
      f.sqlite.prepare('SELECT * FROM mobility_fleets').get(),
      before,
    );
    f.sqlite
      .prepare('UPDATE mobility_fleets SET name=? WHERE id=?')
      .run('Renamed later', payload.requestId);
    assert.equal((await fleetWrite(request(payload))).status, 409);
    assert.equal(
      f.sqlite.prepare('SELECT name FROM mobility_fleets').get().name,
      'Renamed later',
    );
  } finally {
    f.close();
  }
});

test('fleet creation retry remains operator-only and validates its request ID before mutation', async () => {
  const f = fixture();
  try {
    const payload = {
      action: 'create',
      name: 'Synthetic Fleet',
      requestId: crypto.randomUUID(),
    };
    operator(f);
    assert.equal(
      (await fleetWrite(request({ ...payload, requestId: 'not-an-id' })))
        .status,
      400,
    );
    assert.equal((await fleetWrite(request(payload))).status, 201);
    session(f, 'other', 'other@example.test');
    assert.equal((await fleetWrite(request(payload))).status, 403);
    globalThis.accountTest.headers = new Headers();
    assert.equal((await fleetWrite(request(payload))).status, 401);
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) AS n FROM mobility_fleets').get().n,
      1,
    );
  } finally {
    f.close();
  }
});

test('fleet retry recognizes a competing commit between its initial read and write transaction', async () => {
  const f = fixture();
  try {
    operator(f);
    const payload = {
      action: 'create',
      name: 'Synthetic Fleet',
      requestId: crypto.randomUUID(),
    };
    const db = globalThis.accountTest.env.DB;
    const batch = db.batch.bind(db);
    db.batch = async (statements) => {
      f.sqlite
        .prepare(
          'INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES(?,?,?,?)',
        )
        .run(payload.requestId, payload.name, 'operator', 123);
      f.sqlite
        .prepare(
          "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('operator','Original name','000000',?,'staff',123)",
        )
        .run(payload.requestId);
      db.batch = batch;
      return batch(statements);
    };
    const retry = await fleetWrite(request(payload));
    assert.equal(retry.status, 200);
    assert.equal((await retry.json()).replayed, true);
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) AS n FROM mobility_fleets').get().n,
      1,
    );
    assert.equal(
      f.sqlite
        .prepare(
          'SELECT name,created_at FROM mobility_employees WHERE user_id=?',
        )
        .get('operator').name,
      'Original name',
    );
    assert.equal(
      f.sqlite.prepare('SELECT created_at FROM mobility_fleets').get()
        .created_at,
      123,
    );
  } finally {
    f.close();
  }
});

test('failed fleet membership insert rolls back the fleet and permits the same request to retry', async () => {
  const f = fixture();
  const originalError = console.error;
  try {
    operator(f);
    const payload = {
      action: 'create',
      name: 'Synthetic Fleet',
      requestId: crypto.randomUUID(),
    };
    f.sqlite.exec(
      "CREATE TRIGGER reject_test_member BEFORE INSERT ON mobility_employees BEGIN SELECT RAISE(ABORT,'synthetic failure'); END;",
    );
    console.error = () => {};
    assert.equal((await fleetWrite(request(payload))).status, 500);
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) AS n FROM mobility_fleets').get().n,
      0,
    );
    assert.equal(
      f.sqlite.prepare('SELECT COUNT(*) AS n FROM mobility_employees').get().n,
      0,
    );
    f.sqlite.exec('DROP TRIGGER reject_test_member');
    assert.equal((await fleetWrite(request(payload))).status, 201);
    assert.equal(
      f.sqlite
        .prepare('SELECT fleet_id FROM mobility_employees WHERE user_id=?')
        .get('operator').fleet_id,
      payload.requestId,
    );
  } finally {
    console.error = originalError;
    f.close();
  }
});
