"""Local HTTP regression test: invitations, owner impersonation and real GPS gating."""
import json, urllib.request, urllib.error, http.cookiejar, sqlite3, pathlib, uuid
base = 'http://localhost:3001'
def client(): return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def call(c, path, body=None):
    request = urllib.request.Request(base+'/api/mobility/'+path, data=json.dumps(body).encode() if body is not None else None, headers={'Content-Type':'application/json','Origin':base})
    try:
        with c.open(request) as r: return r.status,json.loads(r.read())
    except urllib.error.HTTPError as e: return e.code,json.loads(e.read())
def ok(c,path,body=None,status=200):
    code,result=call(c,path,body)
    assert code==status,(path,code,result)
    return result
connection=None
for file in pathlib.Path('.wrangler/state/v3/d1').rglob('*.sqlite'):
    c=sqlite3.connect(file)
    if c.execute("SELECT name FROM sqlite_master WHERE name='mobility_drivers'").fetchone(): connection=c;break
    c.close()
assert connection
if not connection.execute("SELECT name FROM sqlite_master WHERE name='mobility_fleet_invites'").fetchone():
    connection.executescript(pathlib.Path('drizzle/0013_curvy_mauler.sql').read_text())
owner,driver,stranger,other=[client() for _ in range(4)]
admin=client();admin.open(base+'/signin-with-chatgpt?return_to=%2F').close()
users=[];fleets=[];prefix='invitation-test-'+str(uuid.uuid4())
try:
    for c in [owner,driver,stranger,other]:
        ok(c,'session',{},201);users.append(ok(c,'config')['userId'])
    for i,c in [(0,owner),(3,other)]:
        ok(c,'team',{'name':prefix,'phone':'+49000000'})
        fleets.append(ok(admin,'fleets',{'action':'create','name':prefix,'ownerId':users[i]},201)['id'])
    ok(driver,'driver',{'action':'register','name':prefix,'phone':'+49000000','vehicle':'Test','plate':'GG HY 711','services':['premium']})
    assert not ok(driver,'config')['canDispatch']
    assert ok(driver,'driver')['driver']['approved']==0
    assert call(driver,'fleets',{'action':'claim_owner','code':'GG HY 711'})[0]==403
    assert call(driver,'fleets',{'action':'join','code':'LX-FRANKFURT'})[0]==400
    assert call(stranger,'fleets',{'action':'invite_driver','fleetId':fleets[0]})[0]==403
    assert call(owner,'fleets',{'action':'invite_driver','fleetId':fleets[1]})[0]==403
    invitation=ok(owner,'fleets',{'action':'invite_driver','fleetId':fleets[0]})
    assert invitation['code'].startswith('LX-') and len(invitation['code'])==35
    assert invitation['code'] not in str(connection.execute('SELECT token_hash FROM mobility_fleet_invites').fetchall())
    ok(driver,'fleets',{'action':'join','code':invitation['code']})
    assert not ok(driver,'config')['canDispatch']
    assert ok(driver,'driver')['driver']['approved']==0
    assert call(driver,'driver',{'action':'online'})[0]==403
    ok(owner,'operations',{'driverId':users[1],'approved':True})
    car=ok(owner,'vehicles',{'action':'create','fleetId':fleets[0],'model':'Test','plate':prefix[-12:],'services':['premium']},201)['id']
    assert call(driver,'driver',{'action':'online'})[0]==409
    ok(driver,'vehicles',{'action':'select','vehicleId':car})
    shift=ok(driver,'driver',{'action':'online','lat':50.11,'lng':8.68,'accuracy':999})
    assert ok(driver,'driver')['driver']['online']==0
    assert call(driver,'driver',{'action':'heartbeat','sessionId':shift['sessionId'],'lat':50.11,'lng':8.68,'accuracy':150})[0]==400
    ok(driver,'driver',{'action':'heartbeat','sessionId':shift['sessionId'],'lat':50.11,'lng':8.68,'accuracy':10})
    assert ok(driver,'driver')['driver']['online']==1
    ok(driver,'driver',{'action':'offline','sessionId':shift['sessionId']})
    second=ok(other,'fleets',{'action':'invite_driver','fleetId':fleets[1]})
    assert call(driver,'fleets',{'action':'join','code':second['code']})[0]==409
    ok(owner,'operations',{'driverId':users[1],'approved':False})
    ok(driver,'fleets',{'action':'join','code':invitation['code']})
    assert ok(driver,'driver')['driver']['approved']==0
    connection.execute('UPDATE mobility_fleet_invites SET expires_at=0 WHERE fleet_id=?',(fleets[0],));connection.commit()
    assert call(driver,'fleets',{'action':'join','code':invitation['code']})[0]==409
    assert ok(owner,'fleets')['fleets'][0]['owner_id']==users[0]
    print('PASS: no-login device flow; copied plate cannot grant ownership; random expiring invites; pending approval; cross-fleet access blocked; vehicle selection required; accurate GPS required; revoked approval stays revoked.')
finally:
    for user in users:
        for table,column in [('mobility_location_sessions','driver_id'),('mobility_employees','user_id'),('mobility_drivers','id'),('mobility_sessions','user_id')]:connection.execute(f'DELETE FROM {table} WHERE {column}=?',(user,))
    for fleet in fleets:
        for table,column in [('mobility_fleet_invites','fleet_id'),('mobility_vehicles','fleet_id'),('mobility_fleets','id')]:connection.execute(f'DELETE FROM {table} WHERE {column}=?',(fleet,))
    connection.commit();connection.close()
