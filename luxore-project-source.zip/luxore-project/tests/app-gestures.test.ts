import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  gestureAxis,
  swipeDirection,
  dismissDistance,
} from '../app/mobility/gesture-policy.ts';
import { BackLayers, BackNavigation } from '../app/mobility/back-stack.ts';

void test('vertical scrolling never changes into a page swipe after finger drift', () => {
  const vertical = gestureAxis(4, 26);
  assert.equal(vertical, 'vertical');
  assert.equal(gestureAxis(110, 30, vertical), 'vertical');
  assert.equal(swipeDirection(110, 30, 350, vertical), null);
  assert.equal(gestureAxis(7, 6), 'pending');
  assert.equal(gestureAxis(22, 20), 'pending');
});
void test('page gestures require direction, distance and an intentional short movement', () => {
  const horizontal = gestureAxis(24, 4);
  assert.equal(swipeDirection(-100, 12, 300, horizontal), 1);
  assert.equal(swipeDirection(100, 12, 300, horizontal), -1);
  assert.equal(swipeDirection(60, 8, 300, horizontal), null);
  assert.equal(swipeDirection(110, 90, 300, horizontal), null);
  assert.equal(swipeDirection(110, 5, 1500, horizontal), null);
  assert.equal(swipeDirection(110, 5, 200, 'pending'), null);
});
void test('dialog dismissal does not treat a tap, wrong direction or small slow drag as close', () => {
  assert.equal(dismissDistance(12, 30), false);
  assert.equal(dismissDistance(-140, 150), false);
  assert.equal(dismissDistance(55, 500), false);
  assert.equal(dismissDistance(55, 150), true);
  assert.equal(dismissDistance(110, 600), true);
});
function fixture(initialGuard = false) {
  const layers = new BackLayers();
  let guard = initialGuard,
    pushes = 0,
    backs = 0;
  const controller = new BackNavigation(layers, {
    hasGuard: () => guard,
    pushGuard: () => {
      guard = true;
      pushes++;
    },
    back: () => {
      guard = false;
      backs++;
    },
  });
  return {
    layers,
    controller,
    counts: () => ({ pushes, backs }),
    pop: () => {
      guard = false;
      controller.pop(false);
    },
  };
}
void test('Back closes only the top layer and does not skip checkout or underlying page', () => {
  const f = fixture(),
    closed: string[] = [];
  for (const [id, priority] of [
    ['selection', 20],
    ['checkout', 80],
    ['safety', 90],
  ] as const) {
    f.layers.set({
      id,
      priority,
      back: () => {
        closed.push(id);
        f.layers.remove(id);
      },
    });
    f.controller.sync();
  }
  assert.deepEqual(f.counts(), { pushes: 1, backs: 0 });
  f.pop();
  f.controller.sync();
  assert.deepEqual(closed, ['safety']);
  f.pop();
  f.controller.sync();
  assert.deepEqual(closed, ['safety', 'checkout']);
  f.pop();
  f.controller.sync();
  assert.deepEqual(closed, ['safety', 'checkout', 'selection']);
  f.pop();
  assert.equal(closed.length, 3);
});
void test('closing by button removes the guard without navigating another screen; rerenders do not add entries', () => {
  const f = fixture();
  let closed = 0;
  for (let i = 0; i < 8; i++) {
    f.layers.set({
      id: 'menu',
      priority: 60,
      back: () => {
        closed++;
      },
    });
    f.controller.sync();
  }
  assert.equal(f.layers.size, 1);
  assert.deepEqual(f.counts(), { pushes: 1, backs: 0 });
  f.layers.remove('menu');
  f.controller.sync();
  assert.deepEqual(f.counts(), { pushes: 1, backs: 1 });
  f.controller.pop(false);
  f.controller.sync();
  assert.equal(closed, 0);
});
void test('saving layer consumes Back and rearms; a newly opened dialog survives pending guard cleanup', () => {
  const f = fixture();
  let called = 0;
  f.layers.set({
    id: 'saving',
    priority: 80,
    back: () => {
      called++;
    },
  });
  f.controller.sync();
  f.pop();
  f.controller.sync();
  assert.equal(called, 1);
  assert.equal(f.counts().pushes, 2);
  f.layers.remove('saving');
  f.controller.sync();
  f.layers.set({
    id: 'settings',
    priority: 70,
    back: () => {
      throw Error('must stay open');
    },
  });
  f.controller.sync();
  assert.equal(f.counts().pushes, 2);
  f.controller.pop(false);
  f.controller.sync();
  assert.equal(f.counts().pushes, 3);
});
void test('reload on an existing guard does not add a second history entry', () => {
  const f = fixture(true);
  f.layers.set({ id: 'menu', priority: 60, back: () => {} });
  f.controller.sync();
  assert.deepEqual(f.counts(), { pushes: 0, backs: 0 });
});
