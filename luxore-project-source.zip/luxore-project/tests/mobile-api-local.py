"""Full local customer/driver journey; isolated identities and synthetic routes."""
import http.cookiejar
import json
import os
import pathlib
import sqlite3
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

base = os.environ.get('TEST_BASE_URL', 'http://localhost:3000').rstrip('/')
assert urllib.parse.urlparse(base).hostname in ('localhost', '127.0.0.1', '::1'), 'Local tests only'


def client():
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))


def call(c, path, body=None, origin=base):
    request = urllib.request.Request(base + '/api/mobility/' + path,
        data=json.dumps(body).encode() if body is not None else None,
        headers={'Content-Type': 'application/json', 'Origin': origin})
    try:
        with c.open(request) as response:
            return response.status, json.loads(response.read()), response.headers
    except urllib.error.HTTPError as error:
        raw = error.read()
        try:
            value = json.loads(raw)
        except ValueError:
            value = raw.decode()[:200]
        return error.code, value, error.headers


def ok(c, path, body=None, status=200):
    code, value, _ = call(c, path, body)
    assert code == status, (path, code, value)
    return value


rider, other, first, driver, owner, admin = [client() for _ in range(6)]
users, fleet_id, connection = [], None, None
prefix = 'mobile-test-' + str(uuid.uuid4())
for file in pathlib.Path('.wrangler/state/v3/d1').rglob('*.sqlite'):
    candidate = sqlite3.connect(file)
    if candidate.execute("SELECT name FROM sqlite_master WHERE name='mobility_quotes'").fetchone():
        connection = candidate
        break
    candidate.close()
assert connection, 'Start the local app with the existing local migrations applied'


def quote(who, mode='now'):
    now = int(time.time() * 1000)
    q = {'id': prefix + str(uuid.uuid4()),
         'pickup': {'id': 'p', 'label': 'TEST Opernplatz', 'lat': 50.115, 'lng': 8.67},
         'destination': {'id': 'd', 'label': 'TEST Hbf', 'lat': 50.107, 'lng': 8.663},
         'distanceMeters': 10000, 'durationSeconds': 1200,
         'geometry': {'type': 'LineString', 'coordinates': [[8.67, 50.115], [8.663, 50.107]]},
         'calculatedAt': now, 'expiresAt': now + 300000,
         'prices': {'premium': 2500, 'first': 3500, 'van': 3000},
         'mode': mode, 'scheduledAt': now + 3600000 if mode == 'reservation' else None}
    connection.execute('INSERT INTO mobility_quotes VALUES(?,?,?,?)', (q['id'], who, json.dumps(q), q['expiresAt']))
    connection.commit()
    return q


try:
    assert call(rider, 'config')[0] == 401
    assert call(rider, 'session', {}, 'https://attacker.invalid')[0] == 403
    for c in (rider, other, first, driver, owner):
        issued = call(c, 'session', {})
        if issued[0] == 429:
            time.sleep(60 - time.time() % 60 + 0.1)
            issued = call(c, 'session', {})
        assert issued[0] == 201, issued[:2]
        assert 'HttpOnly' in issued[2]['Set-Cookie'] and 'SameSite=Strict' in issued[2]['Set-Cookie']
        config = ok(c, 'config')
        assert not config['isAdmin']
        users.append(config['userId'])
        ok(c, 'session', {})
        assert call(c, 'operations')[0] == 403
    assert len(set(users)) == 5
    admin.open(base + '/signin-with-chatgpt?return_to=%2F').close()
    assert ok(admin, 'config')['isAdmin']
    ok(owner, 'team', {'name': prefix + ' Owner', 'phone': '+490000000'})
    fleet_id = ok(admin, 'fleets', {'action': 'create', 'name': prefix, 'ownerId': users[4]}, 201)['id']
    sessions = []
    for index, c in enumerate((first, driver)):
        ok(c, 'driver', {'action': 'register', 'name': 'TEST Mobile Driver ' + str(index), 'phone': '+490000000'})
        assert call(c, 'driver', {'action': 'online'})[0] == 403
        ok(admin, 'fleets', {'action': 'assign', 'userId': users[index + 2], 'fleetId': fleet_id, 'role': 'driver'})
        ok(owner, 'operations', {'driverId': users[index + 2], 'approved': True})
        assert call(c, 'driver', {'action': 'online'})[0] == 409
        car = ok(owner, 'vehicles', {'action': 'create', 'fleetId': fleet_id, 'model': 'TEST S Class',
            'plate': prefix[-8:] + ' ' + str(index), 'services': ['premium', 'first']}, 201)['id']
        ok(c, 'vehicles', {'action': 'select', 'vehicleId': car})
        sid = ok(c, 'driver', {'action': 'online'})['sessionId']
        heartbeat = {'action': 'heartbeat', 'sessionId': sid, 'lat': 50.11511 + index * 0.003, 'lng': 8.67011, 'accuracy': 10}
        ok(c, 'driver', heartbeat)
        sessions.append(heartbeat)

    q = quote(users[0])
    nearby = ok(rider, 'nearby', {'quoteId': q['id'], 'service': 'first'})['drivers']
    assert len(nearby) == 2, nearby
    assert all(set(d) == {'lat', 'lng'} for d in nearby)
    assert nearby[0]['lat'] != sessions[0]['lat']
    assert not ok(other, 'nearby', {'quoteId': q['id'], 'service': 'first'})['drivers']
    assert not ok(rider, 'nearby', {'quoteId': q['id'], 'service': 'van'})['drivers']
    preferences = {'temperature': 'cool', 'conversation': 'quiet', 'music': 'off'}
    booking_input = {'quoteId': q['id'], 'service': 'first', 'riderName': 'TEST Customer', 'riderPhone': '+490000001',
                     'preferences': preferences, 'price': 1}
    assert call(rider, 'bookings', {**booking_input, 'preferences': {'temperature': 'freezing'}})[0] == 400
    booking = ok(rider, 'bookings', booking_input, 201)
    assert booking['price'] == 3500 and booking['status'] == 'requesting'
    assert booking['rider_preferences'] == preferences
    assert ok(rider, 'bookings', {**booking_input, 'preferences': {'temperature': 'warm'}})['rider_preferences'] == preferences
    assert ok(other, 'bookings')['bookings'] == []
    assert call(other, 'bookings', {'action': 'cancel', 'id': booking['id']})[0] == 409
    offer = ok(first, 'driver')['offers'][0]
    assert offer['booking']['id'] == booking['id']
    assert offer['booking']['rider_preferences'] == preferences
    assert offer['booking']['rider_phone'] is None
    assert not ok(driver, 'driver')['offers']
    assert call(other, 'driver', {'action': 'accept', 'offerId': offer['id']})[0] == 403
    ok(first, 'driver', {'action': 'reject', 'offerId': offer['id']})
    assert call(first, 'driver', {'action': 'accept', 'offerId': offer['id']})[0] == 409
    next_offer = ok(driver, 'driver')['offers'][0]
    assert next_offer['booking']['id'] == booking['id']
    ok(driver, 'driver', {'action': 'accept', 'offerId': next_offer['id']})
    current = ok(rider, 'bookings')['bookings'][0]
    assert current['driver']['name'] == 'TEST Mobile Driver 1' and current['status'] == 'accepted'
    assert not ok(first, 'driver')['bookings']
    assert ok(driver, 'driver')['bookings'][0]['rider_phone'] == '+490000001'
    assert ok(driver, 'driver')['bookings'][0]['rider_preferences'] == preferences
    assert ok(owner, 'operations')['bookings'][0]['rider_preferences'] == preferences
    assert not ok(rider, 'nearby', {'bookingId': booking['id'], 'service': 'first'})['drivers']
    assert call(driver, 'payments', {'id': booking['id'], 'method': 'cash'})[0] == 409
    for old, new in [('accepted', 'arrived'), ('arrived', 'riding'), ('riding', 'completed')]:
        ok(driver, 'driver', {'action': 'status', 'id': booking['id'], 'from': old, 'status': new})
        assert ok(rider, 'bookings')['bookings'][0]['status'] == new
    assert ok(rider, 'bookings')['bookings'][0]['driver']['lat'] is None
    state = ok(driver, 'driver')
    assert state['payments'][0]['price'] == 3500 and state['today']['outstanding'] == 3500
    assert call(first, 'payments', {'id': booking['id'], 'method': 'cash'})[0] == 409
    for _ in range(2):
        ok(driver, 'payments', {'id': booking['id'], 'method': 'cash', 'amount': 1})
    assert not ok(driver, 'driver')['payments']
    assert ok(driver, 'driver')['today']['collected'] == 3500
    revenue = ok(owner, 'fleets?period=today')['revenue']
    assert len(revenue) == 1 and revenue[0]['collected'] == 3500 and revenue[0]['driver_id'] == users[3]
    assert ok(rider, 'bookings')['bookings'][0]['payment_status'] == 'paid'

    # A future reservation must not become an immediate ride while drivers are free.
    future = quote(users[0], 'reservation')
    reserved = ok(rider, 'bookings', {**booking_input, 'quoteId': future['id']}, 201)
    assert reserved['status'] == 'reserved'
    ok(rider, 'tick', {})
    for c in (first, driver):
        assert not ok(c, 'driver')['offers']
    ok(rider, 'bookings', {'action': 'cancel', 'id': reserved['id']})
    assert next(b for b in ok(rider, 'bookings')['bookings'] if b['id'] == reserved['id'])['status'] == 'cancelled'
    for c, heartbeat in zip((first, driver), sessions):
        ok(c, 'driver', {'action': 'offline', 'sessionId': heartbeat['sessionId']})
        assert call(c, 'driver', heartbeat)[0] == 409
    connection.execute('UPDATE mobility_sessions SET expires_at=0 WHERE user_id=?', (users[1],))
    connection.commit()
    assert call(other, 'config')[0] == 401
    print('PASS: five isolated devices; session CSRF/expiry; fleet approval and multi-class vehicles; nearby privacy; nearest offer -> rejection -> next driver -> acceptance -> arrival -> ride -> completion -> cash collection; retry cannot change fare; driver/fleet revenue; future reservation isolation/cancellation; stale GPS rejected. Local fixtures only; no Android/UI test.')
finally:
    for user in users:
        ids = [row[0] for row in connection.execute('SELECT id FROM mobility_bookings WHERE owner_id=?', (user,))]
        for bid in ids:
            connection.execute('DELETE FROM mobility_offers WHERE booking_id=?', (bid,))
            connection.execute('DELETE FROM mobility_events WHERE booking_id=?', (bid,))
        for table, column in [('mobility_bookings', 'owner_id'), ('mobility_quotes', 'owner_id'), ('mobility_drivers', 'id'), ('mobility_employees', 'user_id'), ('mobility_sessions', 'user_id')]:
            connection.execute('DELETE FROM ' + table + ' WHERE ' + column + '=?', (user,))
    if fleet_id:
        connection.execute('DELETE FROM mobility_vehicles WHERE fleet_id=?', (fleet_id,))
        connection.execute('DELETE FROM mobility_fleets WHERE id=?', (fleet_id,))
    connection.commit()
    connection.close()
