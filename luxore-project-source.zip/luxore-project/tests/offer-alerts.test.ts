import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  createAlertController,
  parseAlertReply,
  alertLifetime,
  type AlertState,
} from '../mobile/src/offer-alert-policy.ts';
import { nativeOfferSql } from '../lib/mobility/location.ts';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
const reply = (id = 'one', serverTime = 1000, expiresAt = 26000) => ({
  serverTime,
  offer: { id, expiresAt },
});
function harness() {
  let state: AlertState | null = null,
    dismissed = 0,
    enabled = true;
  const shown: string[] = [];
  const io = {
    load: async () => state,
    save: async (s: AlertState) => {
      state = s;
    },
    present: async (o: { id: string }) => {
      if (!enabled) return false;
      shown.push(o.id);
      return true;
    },
    dismiss: async () => {
      dismissed++;
    },
  };
  return {
    io,
    controller: createAlertController(io),
    shown,
    get dismissed() {
      return dismissed;
    },
    enable: (v: boolean) => {
      enabled = v;
    },
  };
}
void test('offer metadata is bounded and lifetime tolerates phone clock skew and network delay', () => {
  assert.equal(parseAlertReply({}), null);
  assert.equal(parseAlertReply({ serverTime: NaN, offer: null }), null);
  assert.equal(
    parseAlertReply({ serverTime: 1, offer: { id: 'x', expiresAt: 'soon' } }),
    null,
  );
  assert.deepEqual(parseAlertReply(reply()), reply());
  assert.equal(alertLifetime(reply(), 5000), 20000);
  assert.equal(alertLifetime(reply(), 26000), 0);
});
void test('concurrent callbacks and native restart ring only once for one offer', async () => {
  const h = harness();
  await Promise.all([
    h.controller.sync('shift', reply(), 0, async () => true),
    h.controller.sync('shift', reply(), 0, async () => true),
  ]);
  await createAlertController(h.io).sync(
    'shift',
    reply('one', 2000),
    0,
    async () => true,
  );
  assert.deepEqual(h.shown, ['one']);
  await h.controller.sync('shift', reply('two', 3000), 0, async () => true);
  assert.deepEqual(h.shown, ['one', 'two']);
});
void test('withdrawn/expired offers clear the alert; delayed responses cannot revive it', async () => {
  const h = harness();
  await h.controller.sync('shift', reply(), 0, async () => true);
  await h.controller.sync(
    'shift',
    { serverTime: 3000, offer: null },
    0,
    async () => true,
  );
  await h.controller.sync('shift', reply('one', 2000), 0, async () => true);
  await h.controller.sync(
    'shift',
    reply('expired', 27000),
    0,
    async () => true,
  );
  assert.deepEqual(h.shown, ['one']);
  assert.equal(h.dismissed, 2);
});
void test('pause before or during notification work prevents a surviving alert', async () => {
  const h = harness();
  await h.controller.sync('shift', reply(), 0, async () => false);
  assert.deepEqual(h.shown, []);
  let checks = 0;
  await h.controller.sync('shift', reply(), 0, async () => ++checks < 3);
  assert.equal(h.dismissed, 1);
});
void test('permission denial does not mark unseen offers delivered and failed notification work can retry', async () => {
  const h = harness();
  h.enable(false);
  await h.controller.sync('shift', reply(), 0, async () => true);
  assert.deepEqual(h.shown, []);
  h.enable(true);
  await h.controller.sync('shift', reply('one', 2000), 0, async () => true);
  assert.deepEqual(h.shown, ['one']);
  let failing = true;
  const c = createAlertController({
    ...h.io,
    present: async (o) => {
      if (failing) throw new Error('OS unavailable');
      return h.io.present(o);
    },
  });
  await assert.rejects(
    c.sync('shift', reply('two', 3000), 0, async () => true),
  );
  failing = false;
  await c.sync('shift', reply('two', 4000), 0, async () => true);
  assert.deepEqual(h.shown, ['one', 'two']);
});
void test('offer query exposes only current driver metadata and rechecks authorization at read time', () => {
  const db = new DatabaseSync(':memory:');
  try {
    for (const f of readdirSync(new URL('../drizzle/', import.meta.url))
      .filter((x) => x.endsWith('.sql'))
      .sort())
      db.exec(
        readFileSync(new URL('../drizzle/' + f, import.meta.url), 'utf8'),
      );
    db.exec(
      "INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,accuracy,location_at,session_id) VALUES('d','Name','Private phone','Car','F 1','premium',1,1,10,1000,'s');INSERT INTO mobility_location_sessions VALUES('hash','d','s',99999);INSERT INTO mobility_bookings(id,quote_id,owner_id,service,price,route,mode,status,created_at,updated_at) VALUES('b','q','customer','premium',2500,'{}','now','requesting',0,0);INSERT INTO mobility_offers VALUES('o','b','d','pending',26000,1000)",
    );
    db.exec(`INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES('f','Synthetic Fleet','d',0);
      INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('d','Test','Private phone','f','driver',0);
      INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('v','f','Car','F 1','["premium"]','active',0);
      UPDATE mobility_drivers SET vehicle_id='v';`);
    const read = () =>
      db.prepare(nativeOfferSql).get('d', 's', 'hash', 2000, -43000, 2000);
    assert.deepEqual({ ...read() }, { id: 'o', expiresAt: 26000 });
    for (const [mutation, restore] of [
      [
        "UPDATE mobility_drivers SET session_id='other'",
        "UPDATE mobility_drivers SET session_id='s'",
      ],
      [
        'UPDATE mobility_drivers SET approved=0',
        'UPDATE mobility_drivers SET approved=1',
      ],
      [
        'UPDATE mobility_drivers SET online=0',
        'UPDATE mobility_drivers SET online=1',
      ],
      [
        'UPDATE mobility_drivers SET location_at=-50000',
        'UPDATE mobility_drivers SET location_at=1000',
      ],
      [
        "UPDATE mobility_vehicles SET status='archived'",
        "UPDATE mobility_vehicles SET status='active'",
      ],
      [
        'UPDATE mobility_employees SET fleet_id=NULL',
        "UPDATE mobility_employees SET fleet_id='f'",
      ],
      [
        "UPDATE mobility_drivers SET service='van'",
        "UPDATE mobility_drivers SET service='premium'",
      ],
      [
        'UPDATE mobility_location_sessions SET expires_at=0',
        'UPDATE mobility_location_sessions SET expires_at=99999',
      ],
      [
        "UPDATE mobility_offers SET driver_id='someone'",
        "UPDATE mobility_offers SET driver_id='d'",
      ],
      [
        "UPDATE mobility_offers SET status='accepted'",
        "UPDATE mobility_offers SET status='pending'",
      ],
      [
        'UPDATE mobility_offers SET expires_at=1000',
        'UPDATE mobility_offers SET expires_at=26000',
      ],
      [
        "UPDATE mobility_bookings SET status='cancelled'",
        "UPDATE mobility_bookings SET status='requesting'",
      ],
    ]) {
      db.exec(mutation);
      assert.equal(read(), undefined, mutation);
      db.exec(restore);
    }
  } finally {
    db.close();
  }
});
