import test from 'node:test';
import assert from 'node:assert/strict';
import {
  FleetInvitationsController,
  validInvitationCode,
} from '../mobile/src/fleet-invitations.ts';
const code = 'LX-' + 'A'.repeat(32),
  create = { action: 'invite_driver', fleetId: 'f1' } as const,
  join = { action: 'join', code } as const;
const data = {
  userId: 'u1',
  fleets: [
    { id: 'f1', name: 'Test', owner_id: 'u1', deputy_id: null, created_at: 0 },
    {
      id: 'f2',
      name: 'Other',
      owner_id: 'other',
      deputy_id: null,
      created_at: 0,
    },
  ],
};
const deferred = <T>() => {
  let resolve!: (v: T) => void, reject!: (e: unknown) => void;
  const promise = new Promise<T>((a, b) => {
    resolve = a;
    reject = b;
  });
  return { promise, resolve, reject };
};
const tick = () => new Promise<void>((r) => setImmediate(r));
const error = (status: number) =>
  Object.assign(new Error('synthetic'), { status });
void test('invitation creation needs fresh own leadership while code join validates independently', async () => {
  const writes: unknown[] = [];
  const c = new FleetInvitationsController(
    'u1',
    async () => data,
    async (body) => {
      writes.push(body);
      return {
        ok: true,
        code,
        expiresAt: Date.now() + 86400000,
        shareText: 'Test',
      };
    },
  );
  assert.equal(c.canSubmit(join), false);
  c.setActive(true);
  await c.refresh();
  assert.equal(c.getSnapshot().fleets.length, 1);
  assert.equal(c.canSubmit(create), true);
  assert.equal(c.canSubmit({ ...create, fleetId: 'f2' }), false);
  assert.equal(c.canSubmit(create, Date.now() + 30001), false);
  assert.equal(c.canSubmit({ action: 'join', code: 'bad' }), false);
  assert.equal(validInvitationCode(code.toLowerCase()), true);
  await c.submit(create);
  assert.equal(c.getSnapshot().invitation?.code, code);
  assert.equal(writes.length, 1);
  c.dispose();
});
void test('old read and finally cannot overwrite or release foreground replacement', async () => {
  const first = deferred<typeof data>(),
    second = deferred<typeof data>();
  const signals: AbortSignal[] = [];
  const c = new FleetInvitationsController(
    'u1',
    (s) => {
      signals.push(s);
      return signals.length === 1 ? first.promise : second.promise;
    },
    async () => ({ ok: true }),
  );
  c.setActive(true);
  await tick();
  c.setActive(false);
  assert.equal(signals[0].aborted, true);
  c.setActive(true);
  await tick();
  first.resolve(data);
  await tick();
  assert.equal(c.getSnapshot().loading, true);
  assert.equal(c.getSnapshot().fleets.length, 0);
  second.resolve(data);
  await c.refresh();
  assert.equal(c.getSnapshot().loading, false);
  assert.equal(c.getSnapshot().fleets.length, 1);
  c.dispose();
});
void test('ordinary driver 403 may join, failed connection cannot create and 401 clears access', async () => {
  let failure = 403;
  const c = new FleetInvitationsController(
    'u1',
    async () => {
      throw error(failure);
    },
    async () => ({ ok: true }),
  );
  c.setActive(true);
  await c.refresh();
  assert.equal(c.canSubmit(join), true);
  assert.equal(c.canSubmit(create), false);
  failure = 502;
  await c.refresh();
  assert.equal(c.getSnapshot().error, 'synthetic');
  failure = 401;
  await c.refresh();
  assert.equal(c.canSubmit(join), false);
  assert.equal(c.getSnapshot().signedOut, true);
  c.dispose();
});
void test('join write survives background and prevents parallel or optimistic success', async () => {
  const pending = deferred<{ ok: boolean; message: string }>();
  let count = 0;
  const c = new FleetInvitationsController(
    'u1',
    async () => data,
    () => {
      count++;
      return pending.promise;
    },
  );
  c.setActive(true);
  await c.refresh();
  const task = c.submit(join);
  assert.equal(c.getSnapshot().joined, false);
  await c.submit(create);
  assert.equal(count, 1);
  c.setActive(false);
  pending.resolve({ ok: true, message: 'Confirmed' });
  await task;
  assert.equal(c.getSnapshot().joined, true);
  assert.equal(c.getSnapshot().notice, 'Confirmed');
  c.dispose();
});
void test('uncertain join permits only same normalized code and never retries automatically', async () => {
  let count = 0;
  const c = new FleetInvitationsController(
    'u1',
    async () => data,
    async () => {
      count++;
      if (count === 1) throw new Error('Lost');
      return { ok: true };
    },
  );
  c.setActive(true);
  await c.refresh();
  await c.submit({ ...join, code: code.toLowerCase() });
  assert.deepEqual(c.getSnapshot().uncertain, join);
  assert.equal(c.canSubmit(create), false);
  assert.equal(c.canSubmit({ ...join, code: 'LX-' + 'B'.repeat(32) }), false);
  c.setActive(false);
  c.setActive(true);
  await c.refresh();
  assert.equal(count, 1);
  await c.submit(join);
  assert.equal(c.getSnapshot().joined, true);
  assert.equal(c.getSnapshot().uncertain, null);
  c.dispose();
});
void test('lost creation response only permits explicit same fleet creation; malformed replies remain uncertain', async () => {
  const c = new FleetInvitationsController(
    'u1',
    async () => data,
    async () => ({
      ok: true,
      code: 'bad',
      expiresAt: Date.now() + 1,
      shareText: 'Test',
    }),
  );
  c.setActive(true);
  await c.refresh();
  await c.submit(create);
  assert.equal(c.getSnapshot().invitation, null);
  assert.deepEqual(c.getSnapshot().uncertain, create);
  assert.equal(c.canSubmit(join), false);
  assert.equal(c.canSubmit(create), true);
  c.dispose();
});
void test('known rejected writes do not claim membership and revoked leadership hides code', async () => {
  let rev = false,
    deny = false;
  const c = new FleetInvitationsController(
    'u1',
    async () => (rev ? { ...data, fleets: [] } : data),
    async (body) => {
      if (deny) throw error(409);
      return body.action === 'join'
        ? { ok: true }
        : { ok: true, code, expiresAt: Date.now() + 10000, shareText: 'Test' };
    },
  );
  c.setActive(true);
  await c.refresh();
  await c.submit(create);
  assert.ok(c.getSnapshot().invitation);
  rev = true;
  await c.refresh();
  assert.equal(c.getSnapshot().invitation, null);
  deny = true;
  await c.submit(join);
  assert.equal(c.getSnapshot().joined, false);
  assert.equal(c.getSnapshot().uncertain, null);
  c.dispose();
});
void test('account mismatch and disposed write cannot reveal previous invitation', async () => {
  const write = deferred<{
    ok: boolean;
    code: string;
    expiresAt: number;
    shareText: string;
  }>();
  const c = new FleetInvitationsController(
    'u1',
    async () => data,
    () => write.promise,
  );
  c.setActive(true);
  await c.refresh();
  const task = c.submit(create);
  c.dispose();
  write.resolve({
    ok: true,
    code,
    expiresAt: Date.now() + 10000,
    shareText: 'Test',
  });
  await task;
  assert.equal(c.getSnapshot().invitation, null);
  const other = new FleetInvitationsController(
    'wrong',
    async () => data,
    async () => ({ ok: true }),
  );
  other.setActive(true);
  await other.refresh();
  assert.equal(other.canSubmit(create), false);
  assert.equal(other.getSnapshot().fleets.length, 0);
  other.dispose();
});
