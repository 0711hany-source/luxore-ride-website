import './support/tsx-loader.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { registerHooks } from 'node:module';
registerHooks({
  resolve(specifier, context, next) {
    return next(
      specifier === 'next/image' ? 'next/image.js' : specifier,
      context,
    );
  },
});
const { vehicleArtwork } = await import('../lib/mobility/vehicle-artwork.ts');
const { default: VehicleArtwork } =
  await import('../app/mobility/vehicle-artwork.tsx');

test('existing fleet models use their own images independent of class ordering', () => {
  assert.equal(vehicleArtwork('Audi A6').image, '/vehicles/audi-a6.svg');
  assert.equal(
    vehicleArtwork('Mercedes Benz E-Klasse').image,
    '/brand/business.png',
  );
  assert.equal(
    vehicleArtwork('Mercedes Benz V-KLasse').image,
    '/brand/van.png',
  );
  assert.equal(
    vehicleArtwork('Mercedes—Benz S—Klasse').image,
    '/brand/first-class.png',
  );
  assert.equal(vehicleArtwork('  AUDI   A6  ').image, '/vehicles/audi-a6.svg');
  assert.equal(vehicleArtwork('Audi A60').image, null);
});
test('new vehicles retain a model-labelled schematic instead of a misleading service-class picture', () => {
  for (const [model, body] of [
    ['VW Multivan', 'van'],
    ['Tesla Model Y', 'suv'],
    ['BMW 5er Touring', 'wagon'],
    ['Mercedes E-Klasse Coupé', 'coupe'],
  ]) {
    const art = vehicleArtwork(model);
    assert.equal(art.body, body);
    assert.equal(art.image, null);
    const html = renderToStaticMarkup(createElement(VehicleArtwork, { model }));
    assert.match(html, /Schematische Fahrzeugdarstellung/);
    assert.ok(html.includes(model));
    assert.doesNotMatch(html, /<img/);
  }
  assert.equal(
    vehicleArtwork('VW Multivan').seed,
    vehicleArtwork('vw multivan').seed,
  );
});
test('vehicle names cannot inject markup and repeated schematic icons have unique gradient IDs', () => {
  const html = renderToStaticMarkup(
    createElement(
      'div',
      null,
      createElement(VehicleArtwork, { model: '<script>alert(1)</script>' }),
      createElement(VehicleArtwork, { model: 'BMW 5er Touring' }),
      createElement(VehicleArtwork, { model: 'BMW 5er Touring' }),
    ),
  );
  assert.doesNotMatch(html, /<script>/);
  assert.match(html, /&lt;script&gt;/);
  const ids = [...html.matchAll(/<linearGradient id="([^"]+)"/g)].map(
    (m) => m[1],
  );
  assert.equal(new Set(ids).size, ids.length);
});
