import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  FollowCamera,
  type CameraFrame,
} from '../app/mobility/follow-camera.ts';
import { NavigationMotion } from '../app/mobility/navigation-motion.ts';
import { drivingCameraInsets } from '../app/mobility/map-camera.ts';
const origin: CameraFrame = {
  center: [8.68, 50.11],
  zoom: 12,
  pitch: 0,
  bearing: 359,
  padding: { top: 0, bottom: 0, left: 0, right: 0 },
};
function target(lng = 8.69): CameraFrame {
  return {
    center: [lng, 50.12],
    zoom: 17,
    pitch: 58,
    bearing: 1,
    padding: drivingCameraInsets(760, 300).padding,
  };
}

void test('recenter blends center, zoom, tilt, heading and padding without a first-frame jump', () => {
  const camera = new FollowCamera();
  camera.begin(origin, 100);
  assert.deepEqual(camera.sample(target(), 100), origin);
  const half = camera.sample(target(), 525);
  assert.ok(
    half.center[0] > origin.center[0] && half.center[0] < target().center[0],
  );
  assert.equal(half.zoom, 14.5);
  assert.equal(half.pitch, 29);
  assert.equal(half.bearing, 360); // Short crossing through north.
  assert.equal(half.padding.bottom, target().padding.bottom / 2);
  assert.deepEqual(camera.sample(target(), 950), target());
  assert.equal(camera.active(950), false);
});
void test('GPS updates during return follow the moving target without restarting the camera deadline', () => {
  const camera = new FollowCamera();
  camera.begin(origin, 0);
  camera.sample(target(), 300);
  const moving = target(8.695);
  assert.notDeepEqual(camera.sample(moving, 500), moving);
  assert.ok(camera.active(849));
  assert.deepEqual(camera.sample(moving, 850), moving);
  assert.deepEqual(camera.sample(target(8.696), 870), target(8.696));
});
void test('stationary GPS still completes a camera transition after position animation has stopped', () => {
  const motion = new NavigationMotion();
  motion.push({ lat: 50.12, lng: 8.69, accuracy: 8, timestamp: 100000 }, 0);
  assert.equal(motion.active(2000), false);
  const camera = new FollowCamera();
  camera.begin(origin, 2000);
  assert.equal(camera.active(2300), true);
  const pose = motion.sample(2300)!;
  assert.ok(camera.sample(target(pose.lng), 2300).zoom < 17);
  assert.deepEqual(camera.sample(target(pose.lng), 2850), target(pose.lng));
  assert.equal(camera.active(2850), false);
});
void test('manual interaction cancels return; subsequent return starts from the new visible camera', () => {
  const camera = new FollowCamera();
  camera.begin(origin, 0);
  const halfway = camera.sample(target(), 300);
  camera.cancel();
  assert.equal(camera.active(400), false);
  const manual = {
    ...halfway,
    zoom: 13,
    center: [8.7, 50.115] as [number, number],
  };
  camera.begin(manual, 4000);
  assert.deepEqual(camera.sample(target(), 4000), manual);
  assert.deepEqual(camera.sample(target(), 4850), target());
});
void test('padding changes preserve the previous visible frame and reduced motion completes immediately', () => {
  const camera = new FollowCamera();
  const visible = target();
  camera.begin(visible, 100);
  const expanded = {
    ...visible,
    padding: drivingCameraInsets(760, 570).padding,
  };
  assert.deepEqual(camera.sample(expanded, 100), visible);
  const half = camera.sample(expanded, 525);
  assert.ok(
    half.padding.bottom > visible.padding.bottom &&
      half.padding.bottom < expanded.padding.bottom,
  );
  camera.begin(visible, 1000, 0);
  assert.deepEqual(camera.sample(expanded, 1000), expanded);
  assert.equal(camera.active(1000), false);
});
void test('return snapshots are immutable and longitude takes the short world-wrap path', () => {
  const camera = new FollowCamera();
  const from = {
    ...origin,
    center: [179, 50] as [number, number],
    padding: { ...origin.padding },
  };
  camera.begin(from, 0);
  from.center[0] = 0;
  from.padding.bottom = 99;
  const to = { ...target(), center: [-179, 50] as [number, number] };
  const half = camera.sample(to, 425);
  assert.equal(half.center[0], 180);
  assert.equal(half.padding.bottom, to.padding.bottom / 2);
});
