import test from 'node:test';
import assert from 'node:assert/strict';
import {
  OperationsController,
  ownerCandidates,
  type OperationsData,
  type OwnerChange,
} from '../mobile/src/operations.ts';
const body: OwnerChange = {
  action: 'transfer_owner',
  fleetId: 'f',
  previousOwnerId: 'old',
  ownerId: 'next',
  confirmed: true,
};
const snapshot = (): OperationsData =>
  ({
    userId: 'operator',
    canManage: true,
    fleets: [
      {
        id: 'f',
        name: 'Synthetic',
        owner_id: 'old',
        deputy_id: 'next',
        created_at: 0,
      },
    ],
    employees: [
      { user_id: 'old', name: 'Old', fleet_id: 'f', can_remove: 1 },
      {
        user_id: 'next',
        name: 'Next',
        fleet_id: 'f',
        driver_id: 'next',
        approved: 1,
        can_remove: 1,
      },
      { user_id: 'staff', name: 'Staff', fleet_id: 'f', can_remove: 1 },
    ],
    drivers: [],
    bookings: [],
    revenue: [],
  }) as OperationsData;
const defer = <T>() => {
  let resolve!: (v: T) => void;
  const promise = new Promise<T>((r) => {
    resolve = r;
  });
  return { promise, resolve };
};
const error = (status: number) =>
  Object.assign(new Error('Synthetic denial'), { status });
const make = (
  load: (signal: AbortSignal) => Promise<OperationsData>,
  write: (v: OwnerChange) => Promise<{ ok: boolean }>,
) =>
  new OperationsController(
    load,
    async () => ({ ok: true }),
    async () => ({ ok: true }),
    async () => ({ ok: true }),
    write,
  );
void test('owner transfer preserves operator-only scope and uses eligible uncapped employee records', async () => {
  let data = snapshot();
  const c = make(
    async () => data,
    async () => ({ ok: true }),
  );
  c.setActive(true);
  await c.refresh();
  assert.deepEqual(
    ownerCandidates(data, 'f').map((e) => e.user_id),
    ['next'],
  );
  assert.equal(c.canTransferOwner(body), true);
  assert.equal(c.canTransferOwner(body, Date.now() + 30001), false);
  data = { ...data, canManage: false, userId: 'old' };
  await c.refresh();
  assert.equal(c.canTransferOwner(body), false);
  data = { ...data, canManage: true, userId: undefined };
  await c.refresh();
  assert.equal(c.canTransferOwner(body), false);
  data = snapshot();
  data.employees!.push(
    {
      user_id: 'foreign',
      name: 'Synthetic foreign',
      fleet_id: 'other',
      driver_id: 'foreign',
      approved: 1,
      can_remove: 1,
    },
    {
      user_id: 'busy',
      name: 'Synthetic busy',
      fleet_id: 'f',
      driver_id: 'busy',
      approved: 1,
      can_remove: 0,
    },
    {
      user_id: 'unapproved',
      name: 'Synthetic unapproved',
      fleet_id: 'f',
      driver_id: 'unapproved',
      approved: 0,
      can_remove: 1,
    },
  );
  assert.deepEqual(
    ownerCandidates(data, 'f').map((e) => e.user_id),
    ['next'],
  );
  data.employees![0].can_remove = 0;
  assert.deepEqual(ownerCandidates(data, 'f'), []);
  data = snapshot();
  data.fleets.push({ ...data.fleets[0], id: 'other', owner_id: 'next' });
  assert.deepEqual(ownerCandidates(data, 'f'), []);
  c.dispose();
});
void test('owner write sends exact expected owner and shares write locks, survives background without optimistic mutation', async () => {
  const data = snapshot(),
    pending = defer<{ ok: boolean }>(),
    sent: OwnerChange[] = [];
  const c = make(
    async () => data,
    async (b) => {
      sent.push(b);
      return pending.promise;
    },
  );
  c.setActive(true);
  await c.refresh();
  const task = c.transferOwner(body);
  assert.deepEqual(sent, [body]);
  assert.equal(c.getSnapshot().data?.fleets[0].owner_id, 'old');
  assert.equal(c.canChange({ driverId: 'next', approved: false }), false);
  assert.equal(c.canSetDeputy({ fleetId: 'f', deputyId: null }), false);
  assert.equal(
    c.canChangeMember({
      action: 'remove_member',
      fleetId: 'f',
      userId: 'staff',
    }),
    false,
  );
  await c.transferOwner(body);
  assert.equal(sent.length, 1);
  c.setActive(false);
  pending.resolve({ ok: true });
  await task;
  assert.equal(c.getSnapshot().notice, 'Besitzerübergabe gespeichert.');
  assert.equal(c.getSnapshot().updatedAt, null);
  assert.equal(c.getSnapshot().data?.fleets[0].owner_id, 'old');
  assert.equal(c.getSnapshot().data?.fleets[0].deputy_id, 'next');
  c.dispose();
});
void test('lost response requires successful fresh GET before identical explicit retry and never retries automatically', async () => {
  let failRead = false,
    writes = 0;
  const data = snapshot();
  const c = make(
    async () => {
      if (failRead) throw new Error('Network');
      return data;
    },
    async () => {
      writes++;
      failRead = true;
      throw new Error('Lost');
    },
  );
  c.setActive(true);
  await c.refresh();
  await c.transferOwner(body);
  assert.deepEqual(c.getSnapshot().ownerUncertain, body);
  assert.equal(c.getSnapshot().ownerChecked, false);
  assert.equal(c.canTransferOwner(body), false);
  assert.equal(c.canEndOwnerReview(), false);
  failRead = false;
  await c.refresh();
  assert.equal(writes, 1);
  assert.equal(c.canTransferOwner(body), true);
  assert.equal(c.canTransferOwner({ ...body, ownerId: 'staff' }), false);
  assert.equal(c.canSetDeputy({ fleetId: 'f', deputyId: null }), false);
  assert.equal(
    c.canChangeMember({
      action: 'remove_member',
      fleetId: 'f',
      userId: 'staff',
    }),
    false,
  );
  c.setActive(false);
  assert.equal(c.canTransferOwner(body), false);
  c.setActive(true);
  await c.refresh();
  assert.equal(writes, 1);
  await c.transferOwner(body);
  assert.equal(writes, 2);
  c.dispose();
});
void test('current target owner reconciles uncertainty by read without second POST or optimistic deputy reset', async () => {
  let data = snapshot(),
    writes = 0;
  const c = make(
    async () => data,
    async () => {
      writes++;
      data = {
        ...data,
        fleets: data.fleets.map((f) => ({
          ...f,
          owner_id: 'next',
          deputy_id: null,
        })),
      };
      throw new Error('Lost');
    },
  );
  c.setActive(true);
  await c.refresh();
  await c.transferOwner(body);
  assert.equal(writes, 1);
  assert.equal(c.getSnapshot().ownerUncertain, null);
  assert.match(c.getSnapshot().notice, /Serverstand bestätigt/);
  assert.equal(c.canTransferOwner(body), false);
  assert.equal(c.getSnapshot().data?.fleets[0].deputy_id, null);
  c.dispose();
});
void test('third owner or missing fleet blocks original handover; ending reviewed local request sends no mutation', async () => {
  for (const missing of [false, true]) {
    let data = snapshot(),
      writes = 0;
    const c = make(
      async () => data,
      async () => {
        writes++;
        data = {
          ...data,
          fleets: missing
            ? []
            : data.fleets.map((f) => ({ ...f, owner_id: 'third' })),
        };
        throw new Error('Lost');
      },
    );
    c.setActive(true);
    await c.refresh();
    await c.transferOwner(body);
    assert.equal(c.canTransferOwner(body), false);
    assert.equal(c.canEndOwnerReview(), true);
    assert.equal(c.canEndOwnerReview(Date.now() + 30001), false);
    await c.transferOwner({ ...body, previousOwnerId: 'third' });
    assert.equal(writes, 1);
    c.endOwnerReview();
    assert.equal(c.getSnapshot().ownerUncertain, null);
    assert.equal(writes, 1);
    assert.match(c.getSnapshot().notice, /keine weitere Übergabe/);
    c.dispose();
  }
});
void test('successful write remains confirmed despite reload failure; known denial differs from unknown confirmation', async () => {
  let mode = 'success',
    readFail = false;
  const c = make(
    async () => {
      if (readFail) throw new Error('Read failed');
      return snapshot();
    },
    async () => {
      readFail = true;
      if (mode === 'denied') throw error(409);
      if (mode === 'incomplete') return { ok: false };
      return { ok: true };
    },
  );
  c.setActive(true);
  await c.refresh();
  await c.transferOwner(body);
  assert.equal(c.getSnapshot().ownerUncertain, null);
  assert.match(c.getSnapshot().notice, /gespeichert/);
  assert.match(c.getSnapshot().loadError, /Read failed/);
  readFail = false;
  await c.refresh();
  mode = 'denied';
  await c.transferOwner(body);
  assert.equal(c.getSnapshot().ownerUncertain, null);
  readFail = false;
  await c.refresh();
  mode = 'incomplete';
  await c.transferOwner(body);
  assert.deepEqual(c.getSnapshot().ownerUncertain, body);
  c.dispose();
});
void test('revoked access hides data, retains unconfirmed owner review but cannot approve or retry', async () => {
  let denied = false;
  const c = make(
    async () => {
      if (denied) throw error(403);
      return snapshot();
    },
    async () => {
      denied = true;
      throw new Error('Lost');
    },
  );
  c.setActive(true);
  await c.refresh();
  await c.transferOwner(body);
  assert.equal(c.getSnapshot().data, null);
  assert.deepEqual(c.getSnapshot().ownerUncertain, body);
  assert.equal(c.getSnapshot().ownerChecked, false);
  assert.equal(c.canEndOwnerReview(), false);
  assert.equal(c.canTransferOwner(body), false);
  c.dispose();
});
void test('old reads and disposed write completions cannot overwrite latest owner workspace', async () => {
  const old = defer<OperationsData>(),
    next = defer<OperationsData>();
  let calls = 0;
  const signals: AbortSignal[] = [];
  const c = make(
    async (s) => {
      signals.push(s);
      return ++calls === 1 ? old.promise : next.promise;
    },
    async () => ({ ok: true }),
  );
  c.setActive(true);
  await Promise.resolve();
  c.setActive(false);
  c.setActive(true);
  const task = c.refresh();
  await Promise.resolve();
  old.resolve({ ...snapshot(), userId: 'stale' });
  await new Promise((r) => setImmediate(r));
  assert.equal(c.getSnapshot().refreshing, true);
  assert.equal(signals[0].aborted, true);
  next.resolve(snapshot());
  await task;
  assert.equal(c.getSnapshot().data?.userId, 'operator');
  c.dispose();
  const p = defer<{ ok: boolean }>();
  const d = make(
    async () => snapshot(),
    () => p.promise,
  );
  d.setActive(true);
  await d.refresh();
  const write = d.transferOwner(body);
  d.dispose();
  p.resolve({ ok: true });
  await write;
  assert.equal(d.getSnapshot().notice, '');
});
