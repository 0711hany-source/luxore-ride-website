import test from 'node:test';
import assert from 'node:assert/strict';
import {
  NavigationMotion,
  projectRoad,
} from '../app/mobility/navigation-motion.ts';
import { distanceMeters } from '../app/mobility/gps-quality.ts';
const road = [
  [8, 50],
  [8.001, 50],
  [8.001, 50.001],
];
const fix = (
  lng: number,
  lat: number,
  timestamp: number,
  speed = 10,
  heading = 90,
) => ({ lng, lat, timestamp, speed, heading, accuracy: 6 });
test('navigation continues on the verified street between one-second fixes and freezes within a bounded horizon', () => {
  const m = new NavigationMotion(true);
  m.push(fix(8, 50, 100000), 0, road, road);
  m.push(fix(8.0001, 50, 101000), 1000, road, road);
  const atFix = m.sample(1280)!;
  const a = m.sample(1500)!;
  const b = m.sample(1900)!;
  assert.ok(a.lng > atFix.lng);
  assert.ok(b.lng > a.lng);
  assert.ok(projectRoad(b, road)!.distance < 0.1);
  const bounded = m.sample(2200)!;
  assert.equal(distanceMeters(m.sample(20000)!, bounded), 0);
  assert.ok(distanceMeters(fix(8.0001, 50, 101000), bounded) < 12);
});
test('prediction never shortcuts a corner and the next fix starts from the already displayed pose', () => {
  const m = new NavigationMotion(true);
  m.push(fix(8.0008, 50, 100000), 0, road, road);
  m.push(fix(8.00095, 50, 101000), 1000, road, road);
  for (let t = 1280; t <= 1950; t += 16)
    assert.ok(projectRoad(m.sample(t)!, road)!.distance < 0.1);
  const before = m.sample(2000)!;
  m.push(fix(8.001, 50.00002, 102000, 5, 0), 2000, road, road);
  const after = m.sample(2000)!;
  assert.ok(distanceMeters(before, after) < 0.01);
  for (let t = 2000; t <= 2280; t += 16)
    assert.ok(projectRoad(m.sample(t)!, road)!.distance < 0.1);
});
test('measured stop cancels prediction; missing course, stale cadence and off-route fixes never predict movement', () => {
  const m = new NavigationMotion(true);
  m.push(fix(8, 50, 100000), 0, road, road);
  m.push(fix(8.0001, 50, 101000), 1000, road, road);
  m.sample(1900);
  m.push(fix(8.0001, 50, 102000, 0, 90), 2000, road, road);
  const stopped = m.sample(2280)!;
  assert.ok(distanceMeters(stopped, fix(8.0001, 50, 102000)) < 0.1);
  assert.equal(distanceMeters(m.sample(20000)!, stopped), 0);
  for (const change of [
    { speed: 0 },
    { speed: undefined },
    { heading: undefined },
    { accuracy: 50 },
    { lat: 50.002 },
  ]) {
    const n = new NavigationMotion(true);
    n.push(fix(8, 50, 100000), 0, road, road);
    n.push({ ...fix(8.0001, 50, 101000), ...change }, 1000, road, road);
    assert.equal(n.sample(1280)!.lng, n.sample(20000)!.lng);
  }
  const slow = new NavigationMotion(true);
  slow.push(fix(8, 50, 100000), 0, road, road);
  slow.push(fix(8.0001, 50, 103000), 3000, road, road);
  assert.equal(slow.sample(3280)!.lng, slow.sample(20000)!.lng);
});
