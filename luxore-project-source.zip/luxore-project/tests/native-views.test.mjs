import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
const store = new Map([['luxore-account-v1', 'a'.repeat(64)]]);
globalThis.nativeViewStore = store;
globalThis.require = () => 1; // Metro resolves static PNG assets in real APKs.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    'expo-location',
    `export const Accuracy={High:4}; export const requestForegroundPermissionsAsync=async()=>({status:'denied'}),getCurrentPositionAsync=async()=>{throw new Error('GPS not enabled in view tests')};`,
  ],
  [
    'react-native',
    `
    export const View='View', Text='Text', Pressable='Pressable', ScrollView='ScrollView', Modal='Modal', Image='Image', TextInput='TextInput', KeyboardAvoidingView='KeyboardAvoidingView', ActivityIndicator='ActivityIndicator';
    export const Platform={OS:'android'}, StyleSheet={create:v=>v}, Keyboard={dismiss(){}}, Share={async share(){}}, Linking={async openURL(){},async openSettings(){}}, Alert={alert(){}};
    export const AppState={currentState:'active',addEventListener(){return {remove(){}}}}, BackHandler={addEventListener(){return {remove(){}}}};
    export const useWindowDimensions=()=>({width:390,height:844});
    export const PanResponder={create:handlers=>({panHandlers:handlers})};
    export const Animated={Value:class {constructor(v){this.value=v}setValue(v){this.value=v}},View:'AnimatedView',spring:(v,o)=>({start:()=>v.setValue(o.toValue)})};
  `,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaProvider='SafeAreaProvider', SafeAreaView='SafeAreaView';`,
  ],
  ['expo-status-bar', `export const StatusBar='StatusBar';`],
  ['expo-constants', `export default {expoConfig:{extra:{variant:'driver'}}};`],
  [
    'expo-secure-store',
    `export const getItemAsync=async k=>globalThis.nativeViewStore.get(k)||null,setItemAsync=async(k,v)=>{globalThis.nativeViewStore.set(k,v)},deleteItemAsync=async k=>{globalThis.nativeViewStore.delete(k)};`,
  ],
  [
    'expo-crypto',
    `export const randomUUID=()=> 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';`,
  ],
  [
    'expo-notifications',
    `export const getLastNotificationResponse=()=>null,clearLastNotificationResponse=()=>{},addNotificationResponseReceivedListener=()=>({remove(){}});`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',ArrowRight='ArrowRight', CalendarDays='CalendarDays', CarFront='CarFront', Check='Check', ChevronRight='ChevronRight', CircleHelp='CircleHelp', Home='Home', LogOut='LogOut', Mail='Mail', MapPinned='MapPinned', MapPin='MapPin', Clock3='Clock3', Settings='Settings', ShieldCheck='ShieldCheck', UserRound='UserRound', Users='Users',ChevronDown='ChevronDown',LocateFixed='LocateFixed',Navigation='Navigation',Phone='Phone',RefreshCw='RefreshCw',X='X',Plus='Plus',Minus='Minus',Search='Search';`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    let source = mocked.get(specifier);
    if (specifier.endsWith('/RideWorkspace') || specifier === './RideWorkspace')
      source = `export default function ForbiddenEmbeddedDriver(){throw new Error('Driver mounted a WebView');}`;
    if (specifier === './use-driver-gps')
      source = `export function useDriverGps(){return {position:{lat:50.11,lng:8.68,accuracy:8,timestamp:Date.now()},sessionId:null,error:'',foreground:true,restart:async()=>{},sync:async()=>({active:false})}}`;
    if (specifier === './location-service')
      source = `export const resumeLocation=async()=>({active:false}),stopLocation=async()=>{},foregroundPermission=async()=>{},startLocation=async()=>({active:true});`;
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: App } = await import('../mobile/src/App.tsx');
const { default: SwipeAction } = await import('../mobile/src/SwipeAction.tsx');
const { defaultStock } = await import('../lib/mobility/inventory.ts');
const account = {
  id: 'driver-a',
  name: 'Native Test',
  email: 'test@example.com',
  phone: '+49000000000',
  kind: 'driver',
};
const car = {
  id: 'car-a',
  fleet_id: 'fleet-a',
  model: 'Audi A6',
  plate: 'TEST',
  services: '["premium","first"]',
  status: 'active',
  driver_id: 'driver-a',
  driver_name: 'Native Test',
  online: 0,
};
const state = {
  driver: {
    ...account,
    approved: 1,
    online: 0,
    vehicle_id: 'car-a',
    vehicle: car.model,
    plate: car.plate,
    session_id: null,
  },
  offers: [],
  bookings: [],
  payments: [],
  vehicles: [car],
  fleet: { id: 'fleet-a', name: 'Native Flotte' },
  today: { gross: 2500, trips: 1, collected: 2500, outstanding: 0 },
};
async function settle() {
  for (let i = 0; i < 8; i++)
    await act(async () => {
      await new Promise((resolve) => setImmediate(resolve));
    });
}
test('signed-in driver starts in the native cockpit, switches cars and opens a native vehicle form without any embedded driver', async () => {
  const oldFetch = globalThis.fetch;
  const calls = [];
  const cars = [car];
  let inventory = {
    vehicleId: car.id,
    vehicles: [car],
    revision: 0,
    initialized: false,
    stock: defaultStock(),
    movements: [],
  };
  globalThis.fetch = async (url, options) => {
    calls.push({ url, options });
    const path = new URL(url).pathname.split('/').at(-1);
    if (options.method === 'POST' && path === 'vehicles') {
      const input = JSON.parse(options.body);
      assert.equal(input.action, 'create');
      assert.equal(input.fleetId, 'fleet-a');
      assert.equal(input.requestId, 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee');
      assert.equal(input.model, 'Test Van');
      assert.equal(input.plate, 'TEST 2');
      cars.push({
        ...car,
        id: input.requestId,
        model: input.model,
        plate: input.plate,
        driver_id: null,
      });
      return Response.json({ id: input.requestId }, { status: 201 });
    }
    if (options.method === 'POST' && path === 'inventory') {
      const input = JSON.parse(options.body);
      assert.equal(input.action, 'save');
      assert.equal(input.vehicleId, 'car-a');
      assert.equal(input.revision, 0);
      assert.equal(input.stock.items.water.count, 1);
      inventory = {
        ...inventory,
        revision: 1,
        initialized: true,
        stock: input.stock,
      };
      return Response.json(inventory);
    }
    const data =
      path === 'account'
        ? { account, registrationReady: true, isAdmin: false }
        : path === 'driver'
          ? state
          : path === 'config'
            ? { publicMapToken: '' }
            : path === 'fleets'
              ? {
                  fleets: [{ id: 'fleet-a', name: 'Native Flotte' }],
                  employees: [],
                  revenue: [],
                }
              : path === 'vehicles'
                ? { vehicles: cars }
                : path === 'inventory'
                  ? inventory
                  : {};
    return Response.json(data);
  };
  let renderer;
  try {
    await act(async () => {
      renderer = Renderer.create(React.createElement(App));
    });
    await settle();
    assert.match(JSON.stringify(renderer.toJSON()), /Online gehen/);
    assert.match(JSON.stringify(renderer.toJSON()), /Audi A6/);
    const button = renderer.root
      .findAllByType('Pressable')
      .find((node) =>
        node
          .findAllByType('Text')
          .some((text) => text.props.children === 'Fahrzeug wechseln'),
      );
    await act(async () => button.props.onPress());
    const modal = renderer.root
      .findAllByType('Modal')
      .find((node) => node.props.visible);
    assert.ok(modal);
    assert.match(
      JSON.stringify(
        modal.findAllByType('Text').map((node) => node.props.children),
      ),
      /Dein Fahrzeug/,
    );
    const manage = modal
      .findAllByType('Pressable')
      .find((node) =>
        node
          .findAllByType('Text')
          .some((text) => text.props.children === 'Flotte verwalten'),
      );
    await act(async () => manage.props.onPress());
    await settle();
    const add = renderer.root
      .findAllByType('Pressable')
      .find((node) =>
        node
          .findAllByType('Text')
          .some((text) => text.props.children === 'Hinzufügen'),
      );
    await act(async () => add.props.onPress());
    const form = renderer.root
      .findAllByType('Modal')
      .find((node) => node.props.visible);
    assert.ok(form.findByType('KeyboardAvoidingView'));
    assert.ok(
      form
        .findAllByType('TextInput')
        .find((node) => node.props.accessibilityLabel === 'Kennzeichen'),
    );
    assert.match(
      JSON.stringify(
        form.findAllByType('Text').map((node) => node.props.children),
      ),
      /Fahrzeug speichern/,
    );
    await act(async () => {
      form
        .findAllByType('TextInput')
        .find((node) => node.props.accessibilityLabel === 'Fahrzeugmodell')
        .props.onChangeText(' Test   Van ');
      form
        .findAllByType('TextInput')
        .find((node) => node.props.accessibilityLabel === 'Kennzeichen')
        .props.onChangeText(' test 2 ');
    });
    await act(async () =>
      form
        .findAllByType('Pressable')
        .find((node) =>
          node
            .findAllByType('Text')
            .some((text) => text.props.children === 'Fahrzeug speichern'),
        )
        .props.onPress(),
    );
    await settle();
    assert.match(JSON.stringify(renderer.toJSON()), /Test Van/);
    await act(async () =>
      renderer.root
        .findAllByType('Pressable')
        .find((node) => node.props.accessibilityLabel === 'Zur Startseite')
        .props.onPress(),
    );
    await act(async () =>
      renderer.root
        .findAllByType('Pressable')
        .find((node) =>
          node
            .findAllByType('Text')
            .some((text) => text.props.children === 'Bordbestand & Einkauf'),
        )
        .props.onPress(),
    );
    await settle();
    assert.match(JSON.stringify(renderer.toJSON()), /Anfangsbestand erfassen/);
    await act(async () => {
      renderer.root
        .findAllByType('TextInput')
        .find((node) => node.props.accessibilityLabel === 'Wasser still count')
        .props.onChangeText('1');
      renderer.root
        .findAllByType('TextInput')
        .find(
          (node) =>
            node.props.accessibilityLabel === 'Grund der Bestandskorrektur',
        )
        .props.onChangeText('Anfangsbestand geprüft');
    });
    assert.equal(
      calls.filter(
        (call) =>
          call.url.endsWith('/inventory') && call.options.method === 'POST',
      ).length,
      0,
    );
    await act(async () =>
      renderer.root
        .findAllByType(SwipeAction)
        .find((node) => node.props.label === 'Gezählten Bestand speichern')
        .props.onComplete(),
    );
    await settle();
    assert.equal(inventory.stock.items.water.count, 1);
    assert.equal(inventory.initialized, true);
    assert.ok(
      calls.every(({ url }) =>
        url.startsWith('https://luxoreride.de/api/mobility/'),
      ),
    );
    assert.ok(
      calls.every(
        ({ options }) =>
          options.headers.Authorization === 'Bearer ' + 'a'.repeat(64),
      ),
    );
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = oldFetch;
  }
});
test('native acceptance has no tap action, partial/cancelled gestures do nothing, and a full swipe confirms exactly once', async () => {
  let renderer,
    accepted = 0;
  try {
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(SwipeAction, {
          label: 'Fahrt annehmen',
          onComplete: () => accepted++,
        }),
      );
    });
    const track = renderer.root.findAllByType('View')[0];
    await act(async () =>
      track.props.onLayout({ nativeEvent: { layout: { width: 300 } } }),
    );
    const thumb = renderer.root.findByType('AnimatedView');
    assert.equal(thumb.props.onPress, undefined);
    assert.equal(renderer.root.findAllByType('Pressable').length, 0);
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 80 }));
    await act(async () => thumb.props.onPanResponderTerminate());
    assert.equal(accepted, 0);
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 230 }));
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 230 }));
    assert.equal(accepted, 1);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
  }
});

const { default: FleetScreen } = await import('../mobile/src/FleetScreen.tsx');
const fleetData = {
  fleets: [{ id: 'fleet-a', name: 'Native Flotte' }],
  employees: [],
  revenue: [],
};
function deferred() {
  let resolve;
  const promise = new Promise((r) => {
    resolve = r;
  });
  return { promise, resolve };
}
function fleetButton(renderer, label) {
  const button = renderer.root
    .findAllByType('Pressable')
    .find((node) =>
      node.findAllByType('Text').some((text) => text.props.children === label),
    );
  assert.ok(button, label);
  return button;
}
async function openVehicle(renderer) {
  await act(async () => fleetButton(renderer, 'Hinzufügen').props.onPress());
  const form = renderer.root
    .findAllByType('Modal')
    .find((node) => node.props.visible);
  assert.ok(form.findByType('SafeAreaView').findByType('KeyboardAvoidingView'));
  await act(async () => {
    form
      .findAllByType('TextInput')
      .find((n) => n.props.accessibilityLabel === 'Fahrzeugmodell')
      .props.onChangeText(' Test   Van ');
    form
      .findAllByType('TextInput')
      .find((n) => n.props.accessibilityLabel === 'Kennzeichen')
      .props.onChangeText(' test 2 ');
  });
  return form;
}
async function withFleet(fetcher, run) {
  const oldFetch = globalThis.fetch;
  globalThis.fetch = fetcher;
  let renderer;
  try {
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(FleetScreen, { token: 'a'.repeat(64) }),
      );
    });
    await settle();
    await run(renderer);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = oldFetch;
  }
}
const newCar = {
  ...car,
  id: 'new-car',
  model: 'Test Van',
  plate: 'TEST 2',
  driver_id: null,
};

test('native fleet ignores a late pre-save list response after the vehicle is confirmed', async () => {
  const stale = deferred();
  let reads = 0,
    writes = 0;
  await withFleet(
    async (url, options) => {
      if (options.method === 'POST') {
        writes++;
        return Response.json({ id: newCar.id }, { status: 201 });
      }
      if (url.includes('/fleets')) return Response.json(fleetData);
      reads++;
      if (reads === 2) return stale.promise;
      return Response.json({ vehicles: reads > 2 ? [car, newCar] : [car] });
    },
    async (renderer) => {
      await act(async () =>
        fleetButton(renderer, 'Liste aktualisieren').props.onPress(),
      );
      await openVehicle(renderer);
      await act(async () =>
        fleetButton(renderer, 'Fahrzeug speichern').props.onPress(),
      );
      await settle();
      assert.equal(writes, 1);
      assert.match(JSON.stringify(renderer.toJSON()), /Test Van/);
      await act(async () => stale.resolve(Response.json({ vehicles: [car] })));
      await settle();
      assert.match(JSON.stringify(renderer.toJSON()), /Test Van/);
      assert.match(JSON.stringify(renderer.toJSON()), /Fahrzeug gespeichert/);
    },
  );
});

test('native fleet distinguishes a confirmed save from a failed reload and recovers without writing again', async () => {
  let reads = 0,
    writes = 0;
  await withFleet(
    async (url, options) => {
      if (options.method === 'POST') {
        writes++;
        return Response.json({ id: newCar.id });
      }
      if (url.includes('/fleets')) return Response.json(fleetData);
      reads++;
      if (reads === 2) throw new Error('Verbindung unterbrochen');
      return Response.json({ vehicles: reads > 2 ? [car, newCar] : [car] });
    },
    async (renderer) => {
      await openVehicle(renderer);
      await act(async () =>
        fleetButton(renderer, 'Fahrzeug speichern').props.onPress(),
      );
      await settle();
      assert.equal(
        renderer.root.findAllByType('Modal').some((n) => n.props.visible),
        false,
      );
      const text = JSON.stringify(renderer.toJSON());
      assert.match(text, /Fahrzeug gespeichert/);
      assert.match(text, /Die Liste konnte nicht aktualisiert werden/);
      assert.match(text, /Audi A6/);
      await act(async () =>
        fleetButton(renderer, 'Liste aktualisieren').props.onPress(),
      );
      await settle();
      assert.match(JSON.stringify(renderer.toJSON()), /Test Van/);
      assert.doesNotMatch(
        JSON.stringify(renderer.toJSON()),
        /Verbindung unterbrochen/,
      );
      assert.equal(writes, 1);
    },
  );
});

test('native fleet retains the draft and retry ID after a failed write and blocks double submission', async () => {
  const failed = deferred(),
    inputs = [];
  await withFleet(
    async (url, options) => {
      if (options.method === 'POST') {
        inputs.push(JSON.parse(options.body));
        if (inputs.length === 1) return failed.promise;
        return Response.json({ id: newCar.id, replayed: true });
      }
      return Response.json(
        url.includes('/fleets')
          ? fleetData
          : { vehicles: inputs.length > 1 ? [car, newCar] : [car] },
      );
    },
    async (renderer) => {
      await openVehicle(renderer);
      const save = fleetButton(renderer, 'Fahrzeug speichern');
      await act(async () => {
        save.props.onPress();
        save.props.onPress();
      });
      assert.equal(inputs.length, 1);
      await act(async () =>
        failed.resolve(
          Response.json({ error: 'Speichern fehlgeschlagen' }, { status: 503 }),
        ),
      );
      await settle();
      const form = renderer.root
        .findAllByType('Modal')
        .find((n) => n.props.visible);
      assert.ok(form);
      assert.equal(
        form
          .findAllByType('TextInput')
          .find((n) => n.props.accessibilityLabel === 'Kennzeichen').props
          .value,
        ' test 2 ',
      );
      assert.match(
        JSON.stringify(renderer.toJSON()),
        /Speichern fehlgeschlagen/,
      );
      assert.doesNotMatch(
        JSON.stringify(renderer.toJSON()),
        /Fahrzeug gespeichert/,
      );
      await act(async () =>
        fleetButton(renderer, 'Fahrzeug speichern').props.onPress(),
      );
      await settle();
      assert.equal(inputs.length, 2);
      assert.deepEqual(inputs[0], inputs[1]);
      assert.equal(inputs[1].plate, 'TEST 2');
      assert.match(JSON.stringify(renderer.toJSON()), /Fahrzeug gespeichert/);
    },
  );
});

test('native fleet discards the previous account list and draft when the account changes', async () => {
  const stale = deferred();
  let oldReads = 0;
  await withFleet(
    async (url, options) => {
      const old = options.headers.Authorization === 'Bearer ' + 'a'.repeat(64);
      if (url.includes('/fleets'))
        return Response.json(
          old
            ? fleetData
            : {
                fleets: [{ id: 'fleet-b', name: 'Andere Flotte' }],
                employees: [],
                revenue: [],
              },
        );
      if (old && ++oldReads === 2) return stale.promise;
      return Response.json({ vehicles: old ? [car] : [] });
    },
    async (renderer) => {
      await act(async () =>
        fleetButton(renderer, 'Liste aktualisieren').props.onPress(),
      );
      await openVehicle(renderer);
      await act(async () =>
        renderer.update(
          React.createElement(FleetScreen, { token: 'b'.repeat(64) }),
        ),
      );
      await settle();
      await act(async () => stale.resolve(Response.json({ vehicles: [car] })));
      await settle();
      const text = JSON.stringify(renderer.toJSON());
      assert.match(text, /Andere Flotte/);
      assert.doesNotMatch(text, /Native Flotte|Test   Van/);
      assert.equal(
        renderer.root
          .findAllByType('Text')
          .some((n) => n.props.children === 'Audi A6'),
        false,
      );
      assert.equal(
        renderer.root.findAllByType('Modal').some((n) => n.props.visible),
        false,
      );
    },
  );
});
