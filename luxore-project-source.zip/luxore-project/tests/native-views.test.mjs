import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
const store = new Map([['luxore-account-v1', 'a'.repeat(64)]]);
globalThis.nativeViewStore = store;
globalThis.require = () => 1; // Metro resolves static PNG assets in real APKs.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    'react-native',
    `
    export const View='View', Text='Text', Pressable='Pressable', ScrollView='ScrollView', Modal='Modal', Image='Image', TextInput='TextInput', KeyboardAvoidingView='KeyboardAvoidingView', ActivityIndicator='ActivityIndicator';
    export const Platform={OS:'android'}, StyleSheet={create:v=>v}, Keyboard={dismiss(){}}, Share={async share(){}}, Linking={async openURL(){},async openSettings(){}}, Alert={alert(){}};
    export const AppState={currentState:'active',addEventListener(){return {remove(){}}}}, BackHandler={addEventListener(){return {remove(){}}}};
    export const useWindowDimensions=()=>({width:390,height:844});
    export const PanResponder={create:handlers=>({panHandlers:handlers})};
    export const Animated={Value:class {constructor(v){this.value=v}setValue(v){this.value=v}},View:'AnimatedView',spring:(v,o)=>({start:()=>v.setValue(o.toValue)})};
  `,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaProvider='SafeAreaProvider', SafeAreaView='SafeAreaView';`,
  ],
  ['expo-status-bar', `export const StatusBar='StatusBar';`],
  ['expo-constants', `export default {expoConfig:{extra:{variant:'driver'}}};`],
  [
    'expo-secure-store',
    `export const getItemAsync=async k=>globalThis.nativeViewStore.get(k)||null,setItemAsync=async(k,v)=>{globalThis.nativeViewStore.set(k,v)},deleteItemAsync=async k=>{globalThis.nativeViewStore.delete(k)};`,
  ],
  [
    'expo-crypto',
    `export const randomUUID=()=> 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';`,
  ],
  [
    'expo-notifications',
    `export const getLastNotificationResponse=()=>null,clearLastNotificationResponse=()=>{},addNotificationResponseReceivedListener=()=>({remove(){}});`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',ArrowRight='ArrowRight', CalendarDays='CalendarDays', CarFront='CarFront', Check='Check', ChevronRight='ChevronRight', CircleHelp='CircleHelp', Home='Home', LogOut='LogOut', Mail='Mail', MapPinned='MapPinned', Settings='Settings', ShieldCheck='ShieldCheck', UserRound='UserRound', Users='Users',ChevronDown='ChevronDown',LocateFixed='LocateFixed',Navigation='Navigation',Phone='Phone',RefreshCw='RefreshCw',X='X',Plus='Plus';`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    let source = mocked.get(specifier);
    if (specifier.endsWith('/RideWorkspace') || specifier === './RideWorkspace')
      source = `export default function ForbiddenEmbeddedDriver(){throw new Error('Driver mounted a WebView');}`;
    if (specifier === './use-driver-gps')
      source = `export function useDriverGps(){return {position:{lat:50.11,lng:8.68,accuracy:8,timestamp:Date.now()},sessionId:null,error:'',foreground:true,restart:async()=>{},sync:async()=>({active:false})}}`;
    if (specifier === './location-service')
      source = `export const resumeLocation=async()=>({active:false}),stopLocation=async()=>{},foregroundPermission=async()=>{},startLocation=async()=>({active:true});`;
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: App } = await import('../mobile/src/App.tsx');
const { default: SwipeAction } = await import('../mobile/src/SwipeAction.tsx');
const { defaultStock } = await import('../lib/mobility/inventory.ts');
const account = {
  id: 'driver-a',
  name: 'Native Test',
  email: 'test@example.com',
  phone: '+49000000000',
  kind: 'driver',
};
const car = {
  id: 'car-a',
  fleet_id: 'fleet-a',
  model: 'Audi A6',
  plate: 'TEST',
  services: '["premium","first"]',
  status: 'active',
  driver_id: 'driver-a',
  driver_name: 'Native Test',
  online: 0,
};
const state = {
  driver: {
    ...account,
    approved: 1,
    online: 0,
    vehicle_id: 'car-a',
    vehicle: car.model,
    plate: car.plate,
    session_id: null,
  },
  offers: [],
  bookings: [],
  payments: [],
  vehicles: [car],
  fleet: { id: 'fleet-a', name: 'Native Flotte' },
  today: { gross: 2500, trips: 1, collected: 2500, outstanding: 0 },
};
async function settle() {
  for (let i = 0; i < 8; i++)
    await act(async () => {
      await new Promise((resolve) => setImmediate(resolve));
    });
}
test('signed-in driver starts in the native cockpit, switches cars and opens a native vehicle form without any embedded driver', async () => {
  const oldFetch = globalThis.fetch;
  const calls = [];
  const cars = [car];
  let inventory = {
    vehicleId: car.id,
    vehicles: [car],
    revision: 0,
    initialized: false,
    stock: defaultStock(),
    movements: [],
  };
  globalThis.fetch = async (url, options) => {
    calls.push({ url, options });
    const path = new URL(url).pathname.split('/').at(-1);
    if (options.method === 'POST' && path === 'vehicles') {
      const input = JSON.parse(options.body);
      assert.equal(input.action, 'create');
      assert.equal(input.fleetId, 'fleet-a');
      assert.equal(input.requestId, 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee');
      assert.equal(input.model, 'Test Van');
      assert.equal(input.plate, 'TEST 2');
      cars.push({
        ...car,
        id: input.requestId,
        model: input.model,
        plate: input.plate,
        driver_id: null,
      });
      return Response.json({ id: input.requestId }, { status: 201 });
    }
    if (options.method === 'POST' && path === 'inventory') {
      const input = JSON.parse(options.body);
      assert.equal(input.action, 'save');
      assert.equal(input.vehicleId, 'car-a');
      assert.equal(input.revision, 0);
      assert.equal(input.stock.items.water.count, 1);
      inventory = {
        ...inventory,
        revision: 1,
        initialized: true,
        stock: input.stock,
      };
      return Response.json(inventory);
    }
    const data =
      path === 'account'
        ? { account, registrationReady: true, isAdmin: false }
        : path === 'driver'
          ? state
          : path === 'config'
            ? { publicMapToken: '' }
            : path === 'fleets'
              ? {
                  fleets: [{ id: 'fleet-a', name: 'Native Flotte' }],
                  employees: [],
                  revenue: [],
                }
              : path === 'vehicles'
                ? { vehicles: cars }
                : path === 'inventory'
                  ? inventory
                  : {};
    return Response.json(data);
  };
  let renderer;
  try {
    await act(async () => {
      renderer = Renderer.create(React.createElement(App));
    });
    await settle();
    assert.match(JSON.stringify(renderer.toJSON()), /Online gehen/);
    assert.match(JSON.stringify(renderer.toJSON()), /Audi A6/);
    const button = renderer.root
      .findAllByType('Pressable')
      .find((node) =>
        node
          .findAllByType('Text')
          .some((text) => text.props.children === 'Fahrzeug wechseln'),
      );
    await act(async () => button.props.onPress());
    const modal = renderer.root
      .findAllByType('Modal')
      .find((node) => node.props.visible);
    assert.ok(modal);
    assert.match(
      JSON.stringify(
        modal.findAllByType('Text').map((node) => node.props.children),
      ),
      /Dein Fahrzeug/,
    );
    const manage = modal
      .findAllByType('Pressable')
      .find((node) =>
        node
          .findAllByType('Text')
          .some((text) => text.props.children === 'Flotte verwalten'),
      );
    await act(async () => manage.props.onPress());
    await settle();
    const add = renderer.root
      .findAllByType('Pressable')
      .find((node) =>
        node
          .findAllByType('Text')
          .some((text) => text.props.children === 'Hinzufügen'),
      );
    await act(async () => add.props.onPress());
    const form = renderer.root
      .findAllByType('Modal')
      .find((node) => node.props.visible);
    assert.ok(form.findByType('KeyboardAvoidingView'));
    assert.ok(
      form
        .findAllByType('TextInput')
        .find((node) => node.props.accessibilityLabel === 'Kennzeichen'),
    );
    assert.match(
      JSON.stringify(
        form.findAllByType('Text').map((node) => node.props.children),
      ),
      /Fahrzeug speichern/,
    );
    await act(async () => {
      form
        .findAllByType('TextInput')
        .find((node) => node.props.accessibilityLabel === 'Fahrzeugmodell')
        .props.onChangeText(' Test   Van ');
      form
        .findAllByType('TextInput')
        .find((node) => node.props.accessibilityLabel === 'Kennzeichen')
        .props.onChangeText(' test 2 ');
    });
    await act(async () =>
      form
        .findAllByType('Pressable')
        .find((node) =>
          node
            .findAllByType('Text')
            .some((text) => text.props.children === 'Fahrzeug speichern'),
        )
        .props.onPress(),
    );
    await settle();
    assert.match(JSON.stringify(renderer.toJSON()), /Test Van/);
    await act(async () =>
      renderer.root
        .findAllByType('Pressable')
        .find((node) => node.props.accessibilityLabel === 'Zur Startseite')
        .props.onPress(),
    );
    await act(async () =>
      renderer.root
        .findAllByType('Pressable')
        .find((node) =>
          node
            .findAllByType('Text')
            .some((text) => text.props.children === 'Bordbestand & Einkauf'),
        )
        .props.onPress(),
    );
    await settle();
    assert.match(JSON.stringify(renderer.toJSON()), /Anfangsbestand erfassen/);
    await act(async () => {
      renderer.root
        .findAllByType('TextInput')
        .find((node) => node.props.accessibilityLabel === 'Wasser still count')
        .props.onChangeText('1');
      renderer.root
        .findAllByType('TextInput')
        .find(
          (node) =>
            node.props.accessibilityLabel === 'Grund der Bestandskorrektur',
        )
        .props.onChangeText('Anfangsbestand geprüft');
    });
    assert.equal(
      calls.filter(
        (call) =>
          call.url.endsWith('/inventory') && call.options.method === 'POST',
      ).length,
      0,
    );
    await act(async () =>
      renderer.root
        .findAllByType(SwipeAction)
        .find((node) => node.props.label === 'Gezählten Bestand speichern')
        .props.onComplete(),
    );
    await settle();
    assert.equal(inventory.stock.items.water.count, 1);
    assert.equal(inventory.initialized, true);
    assert.ok(
      calls.every(({ url }) =>
        url.startsWith('https://luxoreride.de/api/mobility/'),
      ),
    );
    assert.ok(
      calls.every(
        ({ options }) =>
          options.headers.Authorization === 'Bearer ' + 'a'.repeat(64),
      ),
    );
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = oldFetch;
  }
});
test('native acceptance has no tap action, partial/cancelled gestures do nothing, and a full swipe confirms exactly once', async () => {
  let renderer,
    accepted = 0;
  try {
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(SwipeAction, {
          label: 'Fahrt annehmen',
          onComplete: () => accepted++,
        }),
      );
    });
    const track = renderer.root.findAllByType('View')[0];
    await act(async () =>
      track.props.onLayout({ nativeEvent: { layout: { width: 300 } } }),
    );
    const thumb = renderer.root.findByType('AnimatedView');
    assert.equal(thumb.props.onPress, undefined);
    assert.equal(renderer.root.findAllByType('Pressable').length, 0);
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 80 }));
    await act(async () => thumb.props.onPanResponderTerminate());
    assert.equal(accepted, 0);
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 230 }));
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 230 }));
    assert.equal(accepted, 1);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
  }
});
