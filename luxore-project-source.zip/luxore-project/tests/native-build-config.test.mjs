import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';

function variant(platform, manifest, compiled) {
  const script = `
    import './tests/support/tsx-loader.mjs';
    import { registerHooks } from 'node:module';
    registerHooks({resolve(s,c,next) {
      const mock = s === 'expo-constants' ? ${JSON.stringify('export default ' + JSON.stringify({ expoConfig: { extra: { variant: manifest } } }) + ';')} : s === 'react-native' ? ${JSON.stringify('export const Platform=' + JSON.stringify({ OS: platform }) + ';')} : null;
      return mock ? {url:'data:text/javascript,'+encodeURIComponent(mock),shortCircuit:true} : next(s,c);
    }});
    const {driverVariant,designPreview}=await import('./mobile/src/build-config.ts');
    console.log(JSON.stringify({driverVariant,designPreview}));
  `;
  return JSON.parse(
    execFileSync(process.execPath, ['--input-type=module', '-e', script], {
      env: {
        ...process.env,
        EXPO_PUBLIC_APP_VARIANT: compiled,
        EXPO_PUBLIC_APP_PREVIEW: 'true',
      },
      encoding: 'utf8',
    }),
  );
}

test('signed native manifest wins over cached customer or driver public environment', () => {
  assert.deepEqual(variant('android', 'driver', 'customer'), {
    driverVariant: true,
    designPreview: false,
  });
  assert.deepEqual(variant('android', 'customer', 'driver'), {
    driverVariant: false,
    designPreview: false,
  });
});
test('web design preview uses its explicit variant and never determines a native variant', () => {
  assert.deepEqual(variant('web', 'customer', 'driver'), {
    driverVariant: true,
    designPreview: true,
  });
  assert.deepEqual(variant('web', 'driver', 'customer'), {
    driverVariant: false,
    designPreview: true,
  });
});
