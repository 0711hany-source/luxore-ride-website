"""Local-only integration tests. Provider routes are fixtures, never production data."""
import json, urllib.request, urllib.error, http.cookiejar, uuid, sqlite3, pathlib, time
base='http://localhost:3001'
jar=http.cookiejar.CookieJar();client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
def call(method,path,body=None,origin=base):
 if body and "quoteId" in body: body={"riderName":"TEST Customer","riderPhone":"+490000001",**body}
 request=urllib.request.Request(base+'/api/mobility/'+path,data=json.dumps(body).encode() if body is not None else None,method=method,headers={'Content-Type':'application/json','Origin':origin})
 try:
  with client.open(request) as r:return r.status,json.loads(r.read())
 except urllib.error.HTTPError as e:
  data=e.read()
  try:value=json.loads(data)
  except ValueError:value=data.decode()
  return e.code,value
assert call('GET','config')[0]==401
client.open(base+'/signin-with-chatgpt?return_to=%2F').close()
code,config=call('GET','config');assert code==200,config
assert config['mapsReady'] is False,'Run this fixture test only before connecting a real map provider'
assert config['isAdmin'] is True,'Local .dev.vars must set LUXORE_ADMIN_EMAIL=seedy@sites.test'
owner=config['userId']
assert call('POST','places',{'query':'Opernplatz 1, Frankfurt am Main'})[0]==503
assert call('POST','places',{'query':'ab'})[0]==400
assert call('POST','tick',{},origin='https://foreign.invalid')[0]==403
assert call('POST','quote',{'pickupId':'foreign','destinationId':'foreign','mode':'now'})[0]==400
connection=None
for file in pathlib.Path('.wrangler/state/v3/d1').rglob('*.sqlite'):
 c=sqlite3.connect(file)
 if c.execute("SELECT name FROM sqlite_master WHERE name='mobility_quotes'").fetchone():connection=c;break
 c.close()
assert connection is not None
now=int(time.time()*1000)
prefix='integration-'+str(uuid.uuid4())
def quote(mode='now',who=owner):
 q={'id':prefix+str(uuid.uuid4()),'pickup':{'id':'fixture-p','label':'TEST Opernplatz','lat':50.115,'lng':8.67},'destination':{'id':'fixture-d','label':'TEST Hauptbahnhof','lat':50.107,'lng':8.663},'distanceMeters':10000,'durationSeconds':1200,'geometry':{'type':'LineString','coordinates':[[8.67,50.115],[8.663,50.107]]},'calculatedAt':now,'expiresAt':now+300000,'prices':{'premium':2500,'first':3500,'van':3000},'mode':mode,'scheduledAt':now+3600000 if mode=='reservation' else None}
 connection.execute('INSERT INTO mobility_quotes VALUES(?,?,?,?)',(q['id'],who,json.dumps(q),q['expiresAt']));connection.commit();return q
q=quote('reservation');code,booking=call('POST','bookings',{'quoteId':q['id'],'service':'first','price':1,'distanceMeters':1});assert code==201,booking
assert booking['price']==3500 and booking['status']=='reserved'
assert call('POST','bookings',{'quoteId':q['id'],'service':'first'})[0]==200
assert call('POST','bookings',{'quoteId':q['id'],'service':'van'})[0]==409
foreign=quote('now','foreign-user');assert call('POST','bookings',{'quoteId':foreign['id'],'service':'first'})[0]==409
assert call('POST','bookings',{'action':'position','id':booking['id'],'lat':50,'lng':8,'shareId':'invalid'})[0]==409
assert call('POST','bookings',{'action':'cancel','id':booking['id']})[0]==200
q2=quote();code,b=call('POST','bookings',{'quoteId':q2['id'],'service':'premium'});assert code==201,b
q3=quote();assert call('POST','bookings',{'quoteId':q3['id'],'service':'premium'})[0]==409
assert call('POST','bookings',{'action':'cancel','id':b['id']})[0]==200
code,state=call('GET','driver');assert code==200
assert state['driver'] is None or state['driver']['name']=='Integration Driver','Do not overwrite an existing local real driver profile'
assert call('POST','driver',{'action':'register','name':'Integration Driver','phone':'+490000000','vehicle':'Test vehicle','plate':'TEST-000','service':'premium'})[0]==200
assert call('POST','driver',{'action':'online'})[0]==403
assert call('POST','operations',{'driverId':owner,'approved':True})[0]==200
code,session=call('POST','driver',{'action':'online'});assert code==200
heartbeat={'action':'heartbeat','sessionId':session['sessionId'],'lat':50.11,'lng':8.68,'accuracy':10}
assert call('POST','driver',heartbeat)[0]==200
assert call('POST','driver',{'action':'offline','sessionId':session['sessionId']})[0]==200
assert call('POST','driver',heartbeat)[0]==409,'Delayed GPS update must not undo explicit offline action'
assert call('GET','driver')[1]['driver']['online']==0
assert call('POST','driver',{'action':'status','id':'not-owned','from':'accepted','status':'arrived'})[0]==409
assert call('POST','driver',{'action':'status','id':'not-owned','from':'accepted','status':'completed'})[0]==400
# Remove only synthetic fixtures from this test; never delete arbitrary user rows.
for bid in (booking['id'],b['id']):
 connection.execute('DELETE FROM mobility_events WHERE booking_id=?',(bid,));connection.execute('DELETE FROM mobility_offers WHERE booking_id=?',(bid,));connection.execute('DELETE FROM mobility_bookings WHERE id=?',(bid,))
connection.execute('DELETE FROM mobility_quotes WHERE id LIKE ?',(prefix+'%',));connection.execute("DELETE FROM mobility_drivers WHERE id=? AND name='Integration Driver'",(owner,));connection.commit();connection.close()
print('PASS: auth, missing-map fail-closed, server fares, idempotency, ownership, reservation separation, customer concurrency, driver approval, explicit offline and stale GPS, status authorization. Local fixtures cleaned.')
