import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { createClient } from '@libsql/client';
import { readFileSync, readdirSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  resolve(s, c, next) {
    if (s === '#heartbeat-adapter')
      return {
        url: new URL('../db/sqlite.ts?heartbeat-adapter', import.meta.url).href,
        shortCircuit: true,
      };
    return next(s, c);
  },
  load(url, c, next) {
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `export class ApiError extends Error {constructor(status,message){super(message);this.status=status}};export const db=()=>globalThis.heartbeatTest.db,tokenHash=async token=>token,limit=async()=>{},settings=()=>({}),isAdmin=()=>false,identity=async()=>({userId:globalThis.heartbeatTest.user}),text=(v,max=160)=>{if(typeof v!=='string'||!v.trim()||v.length>max)throw new ApiError(400,'invalid');return v.trim()},body=r=>r.json(),json=(v,status=200)=>Response.json(v,{status}),handled=async fn=>{try{return await fn()}catch(e){return json({error:e.message},e.status||500)}};`,
      };
    if (
      url.endsWith('/app/api/mobility/driver/route.ts') &&
      process.env.TEST_ORIGINAL_DRIVER_HEARTBEAT
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_DRIVER_HEARTBEAT, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
const { sqliteDatabase } = await import('#heartbeat-adapter');
const { POST } = await import('../app/api/mobility/driver/route.ts');
const token = 'a'.repeat(64);
const point = { lat: 50.112, lng: 8.681, accuracy: 6 };
const send = (extra = {}) =>
  POST(
    new Request('https://test.invalid/api/mobility/driver', {
      method: 'POST',
      body: JSON.stringify({
        action: 'heartbeat',
        sessionId: 'old',
        ...point,
        timestamp: Date.now(),
        ...extra,
      }),
    }),
  );
async function fixture() {
  const client = createClient({ url: ':memory:' }),
    db = sqliteDatabase(client);
  for (const f of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((n) => n.endsWith('.sql'))
    .sort())
    await client.executeMultiple(
      readFileSync(new URL('../drizzle/' + f, import.meta.url), 'utf8'),
    );
  const now = Date.now();
  await client.execute(
    "INSERT INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES('driver','driver@example.test','Synthetic','000','driver','active',0,0)",
  );
  await client.executeMultiple(`INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES('fleet','Synthetic Fleet','owner',0);
 INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('driver','Synthetic Driver','000','fleet','driver',0);
 INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('car','fleet','Synthetic Audi','TEST','["premium"]','active',0);
 INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,services,approved,online,session_id,vehicle_id,lat,lng,accuracy,location_at) VALUES('driver','Synthetic Driver','000','Synthetic Audi','TEST','premium','["premium"]',1,1,'old','car',50.11,8.68,8,${now});
 INSERT INTO mobility_location_sessions(token_hash,driver_id,session_id,expires_at) VALUES('${token}','driver','old',${now + 3600000});
 INSERT INTO mobility_bookings(id,quote_id,owner_id,mode,service,status,route,price,payment_status,created_at,updated_at,dispatch_at) VALUES('booking','quote','customer','now','premium','requesting','{"pickup":{"lat":50.11,"lng":8.68}}',1000,'unpaid',${now},${now},${now});
 INSERT INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at) VALUES('offer','booking','driver','pending',${now + 25000},${now});`);
  globalThis.heartbeatTest = { db, user: 'driver' };
  const snapshot = async () =>
    Object.fromEntries(
      await Promise.all(
        [
          'mobility_accounts',
          'mobility_drivers',
          'mobility_location_sessions',
          'mobility_offers',
          'mobility_bookings',
          'mobility_employees',
          'mobility_vehicles',
        ].map(async (table) => [
          table,
          (await db.prepare('SELECT * FROM ' + table + ' ORDER BY 1').all())
            .results,
        ]),
      ),
    );
  const race = (work) => {
    const prepare = db.prepare;
    let fired = false;
    db.prepare = (sql) => {
      const stmt = prepare(sql);
      if (sql !== 'SELECT * FROM mobility_drivers WHERE id=? AND approved=1')
        return stmt;
      const bind = stmt.bind.bind(stmt);
      stmt.bind = (...args) => {
        const bound = bind(...args),
          first = bound.first.bind(bound);
        bound.first = async (...params) => {
          const row = await first(...params);
          if (!fired) {
            fired = true;
            await work();
          }
          return row;
        };
        return bound;
      };
      return stmt;
    };
  };
  return { client, db, snapshot, race, close: () => client.close() };
}
void test('valid authenticated heartbeat saves own raw position without changing profile, capability, fleet, offers or rides', async () => {
  const f = await fixture();
  try {
    await f.client.execute(
      "UPDATE mobility_drivers SET online=0 WHERE id='driver'",
    );
    const before = await f.snapshot(),
      r = await send({ driverId: 'foreign' });
    assert.equal(r.status, 200);
    const reply = await r.json(),
      after = await f.snapshot();
    assert.equal(reply.ok, true);
    assert.equal(typeof reply.at, 'number');
    assert.deepEqual(after.mobility_drivers[0], {
      ...before.mobility_drivers[0],
      ...point,
      online: 1,
      location_at: reply.at,
    });
    for (const name of [
      'mobility_accounts',
      'mobility_location_sessions',
      'mobility_offers',
      'mobility_bookings',
      'mobility_employees',
      'mobility_vehicles',
    ])
      assert.deepEqual(after[name], before[name]);
  } finally {
    f.close();
  }
});
for (const [name, sql, status] of [
  [
    'blocked account',
    "UPDATE mobility_accounts SET status='blocked' WHERE id='driver'",
    403,
  ],
  [
    'pending account deletion',
    "UPDATE mobility_accounts SET status='deletion_pending' WHERE id='driver'",
    403,
  ],
  [
    'withdrawn approval',
    "UPDATE mobility_drivers SET approved=0 WHERE id='driver'",
    403,
  ],
  [
    'new shift awaiting first GPS',
    "UPDATE mobility_drivers SET session_id='new',online=0 WHERE id='driver'",
    409,
  ],
  [
    'completed pause',
    "UPDATE mobility_drivers SET session_id=NULL,online=0 WHERE id='driver'",
    409,
  ],
  [
    'archived vehicle',
    "UPDATE mobility_vehicles SET status='archived' WHERE id='car'",
    409,
  ],
  [
    'removed fleet membership',
    "DELETE FROM mobility_employees WHERE user_id='driver'",
    409,
  ],
])
  void test(
    'heartbeat rechecks ' +
      name +
      ' after initial identity/profile lookup without dispatch or other mutations',
    async () => {
      const f = await fixture();
      try {
        // A real dispatch would expire this offer. Authorization failures must not
        // enter dispatch, even after the prior read had returned an approved driver.
        await f.client.execute('UPDATE mobility_offers SET expires_at=0');
        let expected;
        f.race(async () => {
          await f.client.execute(sql);
          expected = await f.snapshot();
        });
        assert.equal((await send()).status, status);
        assert.deepEqual(await f.snapshot(), expected);
      } finally {
        f.close();
      }
    },
  );
void test('wrong or empty session never updates GPS or dispatches', async () => {
  const f = await fixture();
  try {
    await f.client.execute('UPDATE mobility_offers SET expires_at=0');
    const before = await f.snapshot();
    assert.equal((await send({ sessionId: 'foreign' })).status, 409);
    assert.equal((await send({ sessionId: ' ' })).status, 400);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
void test('legacy identity and missing optional timestamp remain compatible', async () => {
  const f = await fixture();
  try {
    await f.client.execute('DELETE FROM mobility_accounts');
    const r = await send({ timestamp: undefined });
    assert.equal(r.status, 200);
    const reply = await r.json(),
      after = await f.snapshot();
    assert.equal(after.mobility_drivers[0].location_at, reply.at);
    assert.equal(after.mobility_drivers[0].session_id, 'old');
  } finally {
    f.close();
  }
});
void test('existing coordinate, accuracy and optional timestamp quality guards reject invalid GPS without mutations', async () => {
  const f = await fixture();
  try {
    await f.client.execute('UPDATE mobility_offers SET expires_at=0');
    const before = await f.snapshot();
    for (const input of [
      { lat: 91 },
      { lng: 181 },
      { lat: '50.1' },
      { accuracy: -1 },
      { accuracy: 101 },
      { accuracy: '6' },
      { timestamp: Date.now() - 31000 },
      { timestamp: Date.now() + 60000 },
      { timestamp: 'now' },
    ]) {
      assert.equal((await send(input)).status, 400);
      assert.deepEqual(await f.snapshot(), before);
    }
  } finally {
    f.close();
  }
});
void test('real GPS write failure preserves all data, skips dispatch and permits a later explicit heartbeat', async () => {
  const f = await fixture();
  try {
    await f.client.executeMultiple(
      "UPDATE mobility_offers SET expires_at=0;CREATE TRIGGER fail_gps BEFORE UPDATE ON mobility_drivers BEGIN SELECT RAISE(ABORT,'synthetic GPS save failure');END",
    );
    const before = await f.snapshot();
    assert.equal((await send()).status, 500);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute('DROP TRIGGER fail_gps');
    assert.equal((await send()).status, 200);
    assert.equal((await f.snapshot()).mobility_offers[0].status, 'expired');
  } finally {
    f.close();
  }
});
for (const stage of ['queue cleanup', 'offer creation'])
  void test(
    'committed GPS is acknowledged despite a real dispatch ' +
      stage +
      ' failure',
    async () => {
      const f = await fixture(),
        errors = [],
        originalError = console.error;
      try {
        console.error = (...args) => errors.push(args);
        if (stage === 'queue cleanup')
          await f.client.executeMultiple(
            "INSERT INTO mobility_limits(key,count) VALUES('0:synthetic',1);CREATE TRIGGER fail_dispatch BEFORE DELETE ON mobility_limits BEGIN SELECT RAISE(ABORT,'synthetic dispatch cleanup failure');END",
          );
        else
          await f.client.executeMultiple(
            "DELETE FROM mobility_offers;CREATE TRIGGER fail_dispatch BEFORE INSERT ON mobility_offers BEGIN SELECT RAISE(ABORT,'synthetic dispatch offer failure');END",
          );
        const r = await send();
        assert.equal(r.status, 200);
        const reply = await r.json(),
          after = await f.snapshot();
        assert.deepEqual(reply, {
          ok: true,
          at: after.mobility_drivers[0].location_at,
        });
        assert.equal(after.mobility_drivers[0].lat, point.lat);
        assert.equal(after.mobility_drivers[0].online, 1);
        assert.equal(after.mobility_drivers[0].session_id, 'old');
        assert.equal(errors.length, 1);
        assert.equal(errors[0][0], 'Driver heartbeat dispatch refresh failed:');
        await f.client.execute('DROP TRIGGER fail_dispatch');
        assert.equal((await send()).status, 200);
        assert.equal(errors.length, 1);
        if (stage === 'offer creation')
          assert.equal((await f.snapshot()).mobility_offers.length, 1);
      } finally {
        console.error = originalError;
        f.close();
      }
    },
  );
void test('a newer shift started while the old committed heartbeat awaits dispatch is never overwritten by its completion', async () => {
  const f = await fixture();
  try {
    const batch = f.db.batch.bind(f.db);
    let entered, release;
    const began = new Promise((r) => {
        entered = r;
      }),
      gate = new Promise((r) => {
        release = r;
      });
    f.db.batch = async (statements) => {
      entered();
      await gate;
      return batch(statements);
    };
    const pending = send();
    await began;
    await f.client.executeMultiple(
      "UPDATE mobility_drivers SET online=0,session_id='new',lat=NULL,lng=NULL,location_at=NULL WHERE id='driver';DELETE FROM mobility_location_sessions",
    );
    release();
    assert.equal((await pending).status, 200);
    const after = await f.snapshot();
    assert.equal(after.mobility_drivers[0].session_id, 'new');
    assert.equal(after.mobility_drivers[0].online, 0);
    assert.equal(after.mobility_drivers[0].lat, null);
    assert.equal(after.mobility_drivers[0].location_at, null);
  } finally {
    f.close();
  }
});
