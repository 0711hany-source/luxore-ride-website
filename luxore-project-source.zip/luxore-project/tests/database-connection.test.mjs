import test from 'node:test';
import assert from 'node:assert/strict';
import { databaseConnection } from '../db/connection.mjs';
import './support/tsx-loader.mjs';
import { accountsConfigured, databaseConfigured } from '../db/sqlite.ts';

test('own accounts may open while booking remains deliberately closed', () => {
  const keys = [
    'DATABASE_URL',
    'TURSO_DATABASE_URL',
    'NODE_ENV',
    'VERCEL',
    'LUXORE_BOOKING_ENABLED',
    'LUXORE_ACCOUNTS_ENABLED',
  ];
  const saved = Object.fromEntries(keys.map((k) => [k, process.env[k]]));
  try {
    delete process.env.DATABASE_URL;
    process.env.TURSO_DATABASE_URL = 'libsql://native.invalid';
    process.env.NODE_ENV = 'production';
    process.env.VERCEL = '1';
    delete process.env.LUXORE_BOOKING_ENABLED;
    delete process.env.LUXORE_ACCOUNTS_ENABLED;
    assert.equal(accountsConfigured(), false);
    process.env.LUXORE_ACCOUNTS_ENABLED = 'true';
    assert.equal(accountsConfigured(), true);
    assert.equal(databaseConfigured(), false);
    process.env.TURSO_DATABASE_URL = 'file:temporary.db';
    assert.equal(accountsConfigured(), false);
  } finally {
    for (const [k, v] of Object.entries(saved)) {
      if (v === undefined) delete process.env[k];
      else process.env[k] = v;
    }
  }
});

test('native Vercel connection uses the Turso pair without copying secrets', () => {
  assert.deepEqual(
    databaseConnection({
      TURSO_DATABASE_URL: 'libsql://native.invalid',
      TURSO_AUTH_TOKEN: 'native-token',
    }),
    { url: 'libsql://native.invalid', authToken: 'native-token' },
  );
});
test('custom database never receives a different integration token', () => {
  const env = {
    DATABASE_URL: 'file:local.db',
    TURSO_DATABASE_URL: 'libsql://native.invalid',
    TURSO_AUTH_TOKEN: 'other-database-token',
  };
  assert.deepEqual(databaseConnection(env), {
    url: 'file:local.db',
    authToken: undefined,
  });
  assert.equal(
    databaseConnection({ ...env, DATABASE_AUTH_TOKEN: 'own-token' }).authToken,
    'own-token',
  );
});
test('blank custom values allow native configuration and incomplete configuration stays absent', () => {
  assert.deepEqual(
    databaseConnection({
      DATABASE_URL: '  ',
      DATABASE_AUTH_TOKEN: 'wrong-token',
      TURSO_DATABASE_URL: ' libsql://native.invalid ',
      TURSO_AUTH_TOKEN: ' native-token ',
    }),
    { url: 'libsql://native.invalid', authToken: 'native-token' },
  );
  assert.equal(databaseConnection({}), undefined);
});
test('native connection still needs deliberate activation and cannot use ephemeral Vercel storage', () => {
  const keys = [
    'DATABASE_URL',
    'TURSO_DATABASE_URL',
    'NODE_ENV',
    'VERCEL',
    'LUXORE_BOOKING_ENABLED',
  ];
  const saved = Object.fromEntries(keys.map((k) => [k, process.env[k]]));
  try {
    delete process.env.DATABASE_URL;
    process.env.TURSO_DATABASE_URL = 'libsql://native.invalid';
    process.env.NODE_ENV = 'production';
    process.env.VERCEL = '1';
    delete process.env.LUXORE_BOOKING_ENABLED;
    assert.equal(databaseConfigured(), false);
    process.env.LUXORE_BOOKING_ENABLED = 'true';
    assert.equal(databaseConfigured(), true);
    process.env.TURSO_DATABASE_URL = ':memory:';
    assert.equal(databaseConfigured(), false);
    process.env.TURSO_DATABASE_URL = 'file:temporary.db';
    assert.equal(databaseConfigured(), false);
  } finally {
    for (const [k, v] of Object.entries(saved)) {
      if (v === undefined) delete process.env[k];
      else process.env[k] = v;
    }
  }
});
