import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  load(url, context, next) {
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `
    export class ApiError extends Error {constructor(status,message){super(message);this.status=status;}}
    export const db=()=>globalThis.geoTest.db;
    export const settings=()=>globalThis.geoTest.settings;
    export const identity=async()=>({userId:'cost-test'});
    export const limit=async()=>{};
    export const body=request=>request.json();
    export const json=(value,status=200)=>Response.json(value,{status});
    export const text=value=>{if(typeof value!=='string'||!value.trim())throw new ApiError(400,'empty');return value.trim();};
    export const tokenHash=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))),b=>b.toString(16).padStart(2,'0')).join('');
    export const handled=async work=>{try{return await work();}catch(e){return json({error:e.message},e.status||500);}};
  `,
      };
    return next(url, context);
  },
});
const { POST } = await import('../app/api/mobility/places/route.ts');
const { POST: quote } = await import('../app/api/mobility/quote/route.ts');
const { permanentGeocode } = await import('../lib/mobility/geocoding-cache.ts');
const { geocodeKey } = await import('../lib/mobility/geocoding-policy.ts');
const originalFetch = globalThis.fetch;
function fixture(maximum = '200') {
  const sqlite = new DatabaseSync(':memory:');
  for (const file of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((f) => f.endsWith('.sql'))
    .sort())
    sqlite.exec(
      readFileSync(new URL('../drizzle/' + file, import.meta.url), 'utf8'),
    );
  const db = {
    prepare(sql) {
      let values = [];
      return {
        bind(...args) {
          values = args;
          return this;
        },
        async first() {
          return sqlite.prepare(sql).get(...values) || null;
        },
        async run() {
          const result = sqlite.prepare(sql).run(...values);
          return { meta: { changes: Number(result.changes) } };
        },
      };
    },
    async batch(statements) {
      return Promise.all(statements.map((s) => s.run()));
    },
  };
  const calls = [];
  globalThis.geoTest = {
    db,
    settings: {
      MAPBOX_ACCESS_TOKEN: 'test-only',
      MAPBOX_PERMANENT_DAILY_LIMIT: maximum,
    },
  };
  globalThis.fetch = async (input) => {
    const url = new URL(input);
    calls.push({
      host: url.hostname,
      permanent: url.searchParams.get('permanent'),
      autocomplete: url.searchParams.get('autocomplete'),
      query: url.searchParams.get('q'),
    });
    if (url.hostname === 'api.geoapify.com')
      return Response.json({
        results: [
          {
            formatted: 'TEST Opernplatz, Frankfurt',
            lat: 50.11,
            lon: 8.67,
            datasource: { attribution: '© OpenStreetMap contributors' },
          },
          {
            formatted: 'TEST Andere Adresse',
            lat: 50.12,
            lon: 8.69,
            datasource: { attribution: '© OpenStreetMap contributors' },
          },
          { formatted: 'Invalid coordinates', lat: 1000, lon: 8.67 },
        ],
      });
    if (url.pathname.startsWith('/directions/'))
      return Response.json({
        code: 'Ok',
        routes: [
          {
            distance: 3000,
            duration: 600,
            geometry: {
              type: 'LineString',
              coordinates: [
                [8.67, 50.11],
                [8.69, 50.12],
              ],
            },
          },
        ],
      });
    return Response.json({
      features: [
        {
          properties: { full_address: 'TEST Opernplatz, Frankfurt' },
          geometry: { coordinates: [8.67, 50.11] },
        },
        {
          properties: { full_address: 'TEST Andere Adresse' },
          geometry: { coordinates: [8.69, 50.12] },
        },
      ],
    });
  };
  return {
    sqlite,
    calls,
    close() {
      sqlite.close();
      globalThis.fetch = originalFetch;
    },
  };
}
const request = (body) =>
  new Request('https://test.invalid/api/mobility/places', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
test('suggestions use temporary geocoding and are never written to places/cache; only selection is permanent', async () => {
  const f = fixture();
  try {
    const search = await POST(
      request({ kind: 'search', query: 'TEST Opernplatz' }),
    );
    assert.equal(search.status, 200);
    assert.equal((await search.json()).results.length, 2);
    assert.deepEqual(
      f.calls.map((c) => c.permanent),
      ['false'],
    );
    assert.equal(f.calls[0].autocomplete, 'true');
    assert.equal(
      f.sqlite.prepare('SELECT count(*) AS n FROM mobility_places').get().n,
      0,
    );
    assert.equal(
      f.sqlite.prepare('SELECT count(*) AS n FROM mobility_geocodes').get().n,
      0,
    );
    const selected = await POST(
      request({
        kind: 'selected',
        query: 'TEST Opernplatz',
        lat: 50.11,
        lng: 8.67,
      }),
    );
    assert.equal(selected.status, 200);
    assert.equal((await selected.json()).results.length, 1);
    assert.deepEqual(
      f.calls.map((c) => c.permanent),
      ['false', 'true'],
    );
    assert.equal(f.calls[1].autocomplete, 'false');
    assert.equal(
      f.sqlite.prepare('SELECT count(*) AS n FROM mobility_places').get().n,
      1,
    );
  } finally {
    f.close();
  }
});

test('configured free search saves licensed selection and attribution, reuses typeahead and never activates paid Mapbox geocoding', async () => {
  const f = fixture('0');
  globalThis.geoTest.settings.GEOAPIFY_API_KEY = 'test-only-free';
  try {
    const preview = await (
      await POST(request({ kind: 'search', query: 'TEST Opernplatz' }))
    ).json();
    assert.equal(preview.results.length, 2);
    assert.equal(
      f.sqlite.prepare('SELECT count(*) AS n FROM mobility_places').get().n,
      0,
    );
    const points = [];
    for (const p of preview.results) {
      const selected = await POST(
        request({
          kind: 'selected',
          query: 'test   opernplatz',
          lat: p.lat,
          lng: p.lng,
        }),
      );
      assert.equal(selected.status, 200);
      points.push((await selected.json()).results[0]);
    }
    assert.equal(f.calls.length, 1);
    assert.equal(f.calls[0].host, 'api.geoapify.com');
    const result = await (
      await quote(
        request({
          mode: 'now',
          pickupId: points[0].id,
          destinationId: points[1].id,
        }),
      )
    ).json();
    assert.equal(
      result.pickup.attribution,
      'Powered by Geoapify · © OpenStreetMap contributors',
    );
    assert.equal(f.calls.filter((c) => c.permanent === 'true').length, 0);
    assert.equal(
      (
        await POST(
          request({
            kind: 'selected',
            query: 'TEST Opernplatz',
            lat: 51,
            lng: 9,
          }),
        )
      ).status,
      409,
    );
    assert.equal(
      f.sqlite.prepare('SELECT count(*) AS n FROM mobility_places').get().n,
      2,
    );
  } finally {
    f.close();
  }
});

test('free provider quota and outage retain the paid blockade; failure releases the cache lease', async () => {
  const f = fixture('0');
  globalThis.geoTest.settings.GEOAPIFY_API_KEY = 'test-only-free';
  try {
    f.sqlite
      .prepare('INSERT INTO mobility_limits(key,count) VALUES(?,2500)')
      .run(`geoapify-day:${Math.floor(Date.now() / 86400000)}`);
    assert.equal(
      (
        await POST(
          request({
            kind: 'selected',
            query: 'TEST Quota',
            lat: 50.11,
            lng: 8.67,
          }),
        )
      ).status,
      429,
    );
    assert.equal(f.calls.length, 0);
    f.sqlite
      .prepare('DELETE FROM mobility_limits WHERE key LIKE ?')
      .run('geoapify-day:%');
    globalThis.fetch = async () =>
      Response.json({ error: 'rate limited' }, { status: 429 });
    assert.equal(
      (
        await POST(
          request({
            kind: 'selected',
            query: 'TEST Outage',
            lat: 50.11,
            lng: 8.67,
          }),
        )
      ).status,
      429,
    );
    assert.equal(
      f.sqlite
        .prepare(
          'SELECT count(*) AS n FROM mobility_geocodes WHERE claim IS NOT NULL',
        )
        .get().n,
      0,
    );
    assert.equal(
      f.sqlite.prepare('SELECT count(*) AS n FROM mobility_places').get().n,
      0,
    );
  } finally {
    f.close();
  }
});
test('permanent lookups are reused across devices/whitespace and the budget blocks new paid requests before fetch', async () => {
  const f = fixture('1');
  try {
    await permanentGeocode(' TEST Opernplatz ');
    await permanentGeocode('test   opernplatz');
    assert.equal(f.calls.length, 1);
    assert.equal(geocodeKey('TEST  Opernplatz'), geocodeKey('test opernplatz'));
    await assert.rejects(
      permanentGeocode('TEST Anderes Ziel'),
      /Tageskontingent/,
    );
    assert.equal(f.calls.length, 1);
    assert.equal(
      f.sqlite
        .prepare(
          'SELECT count(*) AS n FROM mobility_geocodes WHERE claim IS NOT NULL',
        )
        .get().n,
      0,
    );
  } finally {
    f.close();
  }
});
test('concurrent paid lookups acquire one lease; failed provider calls release it for a deliberate retry', async () => {
  const f = fixture();
  try {
    let release;
    let entered;
    const ready = new Promise((resolve) => {
      entered = resolve;
    });
    const fetch = globalThis.fetch;
    globalThis.fetch = async (input) => {
      entered();
      await new Promise((resolve) => {
        release = resolve;
      });
      return fetch(input);
    };
    const first = permanentGeocode('TEST Parallel');
    await ready;
    await assert.rejects(permanentGeocode('test parallel'), /gerade geprüft/);
    release();
    await first;
    assert.equal(f.calls.length, 1);
    globalThis.fetch = async () => {
      throw new Error('test connection failure');
    };
    await assert.rejects(
      permanentGeocode('TEST Ausfall'),
      /antwortet gerade nicht/,
    );
    globalThis.fetch = fetch;
    await permanentGeocode('TEST Ausfall');
    assert.equal(f.calls.length, 2);
  } finally {
    f.close();
  }
});
test('invalid/stale selection cannot persist a temporary point or trigger a paid request with invalid coordinates', async () => {
  const f = fixture();
  try {
    assert.equal(
      (
        await POST(
          request({
            kind: 'selected',
            query: 'TEST Opernplatz',
            lat: 1000,
            lng: 8,
          }),
        )
      ).status,
      400,
    );
    assert.equal(f.calls.length, 0);
    assert.equal(
      (
        await POST(
          request({
            kind: 'selected',
            query: 'TEST Opernplatz',
            lat: 51,
            lng: 9,
          }),
        )
      ).status,
      409,
    );
    assert.equal(
      f.sqlite.prepare('SELECT count(*) AS n FROM mobility_places').get().n,
      0,
    );
  } finally {
    f.close();
  }
});
test('confirmed addresses still quote normally with the paid budget exhausted; temporary ids cannot be booked', async () => {
  const f = fixture('1');
  try {
    const temporary = await (
      await POST(request({ kind: 'search', query: 'TEST Strecke' }))
    ).json();
    assert.equal(
      (
        await quote(
          request({
            mode: 'now',
            pickupId: temporary.results[0].id,
            destinationId: temporary.results[1].id,
          }),
        )
      ).status,
      400,
    );
    const pickup = (
      await (
        await POST(
          request({
            kind: 'selected',
            query: 'TEST Strecke',
            lat: 50.11,
            lng: 8.67,
          }),
        )
      ).json()
    ).results[0];
    const destination = (
      await (
        await POST(
          request({
            kind: 'selected',
            query: 'TEST Strecke',
            lat: 50.12,
            lng: 8.69,
          }),
        )
      ).json()
    ).results[0];
    const response = await quote(
      request({
        mode: 'now',
        pickupId: pickup.id,
        destinationId: destination.id,
      }),
    );
    assert.equal(response.status, 200);
    const result = await response.json();
    assert.equal(result.distanceMeters, 3000);
    assert.equal(result.prices.premium, 1500);
    assert.equal(f.calls.filter((c) => c.permanent === 'true').length, 1);
  } finally {
    f.close();
  }
});

test('free coordinate selection persists and quotes user points without geocoding; missing or invalid paid budget blocks new text selection', async () => {
  for (const budget of ['0', 'invalid', undefined]) {
    const f = fixture('0');
    if (budget === undefined)
      delete globalThis.geoTest.settings.MAPBOX_PERMANENT_DAILY_LIMIT;
    else globalThis.geoTest.settings.MAPBOX_PERMANENT_DAILY_LIMIT = budget;
    try {
      const selected = [];
      for (const [kind, lat, lng] of [
        ['location', 50.11, 8.67],
        ['pin', 50.12, 8.69],
      ]) {
        const response = await POST(request({ kind, lat, lng }));
        assert.equal(response.status, 200);
        const point = (await response.json()).results[0];
        assert.equal(point.lat, lat);
        assert.equal(point.lng, lng);
        assert.match(point.label, /Standort|Punkt/);
        selected.push(point);
      }
      assert.equal(f.calls.length, 0);
      assert.equal(
        f.sqlite.prepare('SELECT count(*) AS n FROM mobility_places').get().n,
        2,
      );
      const route = await quote(
        request({
          mode: 'now',
          pickupId: selected[0].id,
          destinationId: selected[1].id,
        }),
      );
      assert.equal(route.status, 200);
      assert.equal((await route.json()).distanceMeters, 3000);
      assert.equal(
        (
          await POST(
            request({
              kind: 'selected',
              query: 'TEST New',
              lat: 50.11,
              lng: 8.67,
            }),
          )
        ).status,
        429,
      );
      assert.equal(f.calls.length, 1); // The route API only, no geocoding request.
      assert.equal(f.calls.filter((c) => c.permanent === 'true').length, 0);
    } finally {
      f.close();
    }
  }
});

test('nullable attribution migration preserves existing text places and business data', () => {
  const sqlite = new DatabaseSync(':memory:');
  try {
    for (const file of readdirSync(new URL('../drizzle/', import.meta.url))
      .filter((f) => f.endsWith('.sql') && !f.startsWith('0018_'))
      .sort())
      sqlite.exec(
        readFileSync(new URL('../drizzle/' + file, import.meta.url), 'utf8'),
      );
    sqlite
      .prepare(
        'INSERT INTO mobility_places(id,owner_id,label,lat,lng,created_at) VALUES(?,?,?,?,?,?)',
      )
      .run('existing', 'owner', 'Straße d’Essai · €', 50.1, 8.6, 1000);
    sqlite.exec(
      readFileSync(
        new URL('../drizzle/0018_gorgeous_changeling.sql', import.meta.url),
        'utf8',
      ),
    );
    assert.deepEqual(
      {
        ...sqlite
          .prepare('SELECT * FROM mobility_places WHERE id=?')
          .get('existing'),
      },
      {
        id: 'existing',
        owner_id: 'owner',
        label: 'Straße d’Essai · €',
        lat: 50.1,
        lng: 8.6,
        created_at: 1000,
        attribution: null,
      },
    );
  } finally {
    sqlite.close();
  }
});

test('configured free provider also resolves GPS and map pins when paid geocoding remains disabled', async () => {
  const f = fixture('0');
  globalThis.geoTest.settings.GEOAPIFY_API_KEY = 'test-only-free';
  try {
    const location = await POST(
      request({ kind: 'location', lat: 50.11, lng: 8.67 }),
    );
    assert.equal(location.status, 200);
    const located = (await location.json()).results[0];
    assert.match(located.label, /Opernplatz/);
    assert.match(located.attribution, /Geoapify/);
    const pin = await POST(request({ kind: 'pin', lat: 50.12, lng: 8.69 }));
    assert.equal(pin.status, 200);
    const selected = (await pin.json()).results[0];
    assert.equal(selected.lat, 50.12);
    assert.equal(selected.lng, 8.69);
    assert.match(selected.attribution, /Geoapify/);
    assert.equal(f.calls.length, 2);
    assert.ok(f.calls.every((c) => c.host === 'api.geoapify.com'));
  } finally {
    f.close();
  }
});
