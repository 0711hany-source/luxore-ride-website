import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  load(url, context, next) {
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `
    export class ApiError extends Error {constructor(status,message){super(message);this.status=status;}}
    export const db=()=>globalThis.geoTest.db;
    export const settings=()=>globalThis.geoTest.settings;
    export const identity=async()=>({userId:'cost-test'});
    export const limit=async()=>{};
    export const body=request=>request.json();
    export const json=(value,status=200)=>Response.json(value,{status});
    export const text=value=>{if(typeof value!=='string'||!value.trim())throw new ApiError(400,'empty');return value.trim();};
    export const tokenHash=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))),b=>b.toString(16).padStart(2,'0')).join('');
    export const handled=async work=>{try{return await work();}catch(e){return json({error:e.message},e.status||500);}};
  `,
      };
    return next(url, context);
  },
});
const { POST } = await import('../app/api/mobility/places/route.ts');
const { POST: quote } = await import('../app/api/mobility/quote/route.ts');
const { permanentGeocode } = await import('../lib/mobility/geocoding-cache.ts');
const { geocodeKey } = await import('../lib/mobility/geocoding-policy.ts');
const originalFetch = globalThis.fetch;
function fixture(maximum = '200') {
  const sqlite = new DatabaseSync(':memory:');
  for (const file of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((f) => f.endsWith('.sql'))
    .sort())
    sqlite.exec(
      readFileSync(new URL('../drizzle/' + file, import.meta.url), 'utf8'),
    );
  const db = {
    prepare(sql) {
      let values = [];
      return {
        bind(...args) {
          values = args;
          return this;
        },
        async first() {
          return sqlite.prepare(sql).get(...values) || null;
        },
        async run() {
          const result = sqlite.prepare(sql).run(...values);
          return { meta: { changes: Number(result.changes) } };
        },
      };
    },
    async batch(statements) {
      return Promise.all(statements.map((s) => s.run()));
    },
  };
  const calls = [];
  globalThis.geoTest = {
    db,
    settings: {
      MAPBOX_ACCESS_TOKEN: 'test-only',
      MAPBOX_PERMANENT_DAILY_LIMIT: maximum,
    },
  };
  globalThis.fetch = async (input) => {
    const url = new URL(input);
    calls.push({
      permanent: url.searchParams.get('permanent'),
      query: url.searchParams.get('q'),
    });
    if (url.pathname.startsWith('/directions/'))
      return Response.json({
        code: 'Ok',
        routes: [
          {
            distance: 3000,
            duration: 600,
            geometry: {
              type: 'LineString',
              coordinates: [
                [8.67, 50.11],
                [8.69, 50.12],
              ],
            },
          },
        ],
      });
    return Response.json({
      features: [
        {
          properties: { full_address: 'TEST Opernplatz, Frankfurt' },
          geometry: { coordinates: [8.67, 50.11] },
        },
        {
          properties: { full_address: 'TEST Andere Adresse' },
          geometry: { coordinates: [8.69, 50.12] },
        },
      ],
    });
  };
  return {
    sqlite,
    calls,
    close() {
      sqlite.close();
      globalThis.fetch = originalFetch;
    },
  };
}
const request = (body) =>
  new Request('https://test.invalid/api/mobility/places', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
test('suggestions use temporary geocoding and are never written to places/cache; only selection is permanent', async () => {
  const f = fixture();
  try {
    const search = await POST(
      request({ kind: 'search', query: 'TEST Opernplatz' }),
    );
    assert.equal(search.status, 200);
    assert.equal((await search.json()).results.length, 2);
    assert.deepEqual(
      f.calls.map((c) => c.permanent),
      ['false'],
    );
    assert.equal(
      f.sqlite.prepare('SELECT count(*) AS n FROM mobility_places').get().n,
      0,
    );
    assert.equal(
      f.sqlite.prepare('SELECT count(*) AS n FROM mobility_geocodes').get().n,
      0,
    );
    const selected = await POST(
      request({
        kind: 'selected',
        query: 'TEST Opernplatz',
        lat: 50.11,
        lng: 8.67,
      }),
    );
    assert.equal(selected.status, 200);
    assert.equal((await selected.json()).results.length, 1);
    assert.deepEqual(
      f.calls.map((c) => c.permanent),
      ['false', 'true'],
    );
    assert.equal(
      f.sqlite.prepare('SELECT count(*) AS n FROM mobility_places').get().n,
      1,
    );
  } finally {
    f.close();
  }
});
test('permanent lookups are reused across devices/whitespace and the budget blocks new paid requests before fetch', async () => {
  const f = fixture('1');
  try {
    await permanentGeocode(' TEST Opernplatz ');
    await permanentGeocode('test   opernplatz');
    assert.equal(f.calls.length, 1);
    assert.equal(geocodeKey('TEST  Opernplatz'), geocodeKey('test opernplatz'));
    await assert.rejects(
      permanentGeocode('TEST Anderes Ziel'),
      /Tageskontingent/,
    );
    assert.equal(f.calls.length, 1);
    assert.equal(
      f.sqlite
        .prepare(
          'SELECT count(*) AS n FROM mobility_geocodes WHERE claim IS NOT NULL',
        )
        .get().n,
      0,
    );
  } finally {
    f.close();
  }
});
test('concurrent paid lookups acquire one lease; failed provider calls release it for a deliberate retry', async () => {
  const f = fixture();
  try {
    let release;
    let entered;
    const ready = new Promise((resolve) => {
      entered = resolve;
    });
    const fetch = globalThis.fetch;
    globalThis.fetch = async (input) => {
      entered();
      await new Promise((resolve) => {
        release = resolve;
      });
      return fetch(input);
    };
    const first = permanentGeocode('TEST Parallel');
    await ready;
    await assert.rejects(permanentGeocode('test parallel'), /gerade geprüft/);
    release();
    await first;
    assert.equal(f.calls.length, 1);
    globalThis.fetch = async () => {
      throw new Error('test connection failure');
    };
    await assert.rejects(
      permanentGeocode('TEST Ausfall'),
      /antwortet gerade nicht/,
    );
    globalThis.fetch = fetch;
    await permanentGeocode('TEST Ausfall');
    assert.equal(f.calls.length, 2);
  } finally {
    f.close();
  }
});
test('invalid/stale selection cannot persist a temporary point or trigger a paid request with invalid coordinates', async () => {
  const f = fixture();
  try {
    assert.equal(
      (
        await POST(
          request({
            kind: 'selected',
            query: 'TEST Opernplatz',
            lat: 1000,
            lng: 8,
          }),
        )
      ).status,
      400,
    );
    assert.equal(f.calls.length, 0);
    assert.equal(
      (
        await POST(
          request({
            kind: 'selected',
            query: 'TEST Opernplatz',
            lat: 51,
            lng: 9,
          }),
        )
      ).status,
      409,
    );
    assert.equal(
      f.sqlite.prepare('SELECT count(*) AS n FROM mobility_places').get().n,
      0,
    );
  } finally {
    f.close();
  }
});
test('confirmed addresses still quote normally with the paid budget exhausted; temporary ids cannot be booked', async () => {
  const f = fixture('1');
  try {
    const temporary = await (
      await POST(request({ kind: 'search', query: 'TEST Strecke' }))
    ).json();
    assert.equal(
      (
        await quote(
          request({
            mode: 'now',
            pickupId: temporary.results[0].id,
            destinationId: temporary.results[1].id,
          }),
        )
      ).status,
      400,
    );
    const pickup = (
      await (
        await POST(
          request({
            kind: 'selected',
            query: 'TEST Strecke',
            lat: 50.11,
            lng: 8.67,
          }),
        )
      ).json()
    ).results[0];
    const destination = (
      await (
        await POST(
          request({
            kind: 'selected',
            query: 'TEST Strecke',
            lat: 50.12,
            lng: 8.69,
          }),
        )
      ).json()
    ).results[0];
    const response = await quote(
      request({
        mode: 'now',
        pickupId: pickup.id,
        destinationId: destination.id,
      }),
    );
    assert.equal(response.status, 200);
    const result = await response.json();
    assert.equal(result.distanceMeters, 3000);
    assert.equal(result.prices.premium, 1500);
    assert.equal(f.calls.filter((c) => c.permanent === 'true').length, 1);
  } finally {
    f.close();
  }
});
