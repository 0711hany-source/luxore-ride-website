"""Local-only DB fixtures; route coordinates are public Frankfurt landmarks."""
import os,json,urllib.request,urllib.error,http.cookiejar,sqlite3,pathlib,time,uuid
base=os.environ.get('TEST_BASE_URL','http://localhost:3000')
assert urllib.parse.urlparse(base).hostname in ('localhost','127.0.0.1')
def client():return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def call(c,p,b,origin=base):
 req=urllib.request.Request(base+'/api/mobility/'+p,data=json.dumps(b).encode(),headers={'Content-Type':'application/json','Origin':origin})
 try:
  with c.open(req,timeout=25) as r:return r.status,json.loads(r.read())
 except urllib.error.HTTPError as e:
  raw=e.read()
  try:reply=json.loads(raw)
  except ValueError:reply={'error':raw.decode()[:160]}
  return e.code,reply
c=client(); assert call(c,'guidance',{})[0]==401
assert call(c,'session',{})[0]==201
with c.open(base+'/api/mobility/config') as r:uid=json.loads(r.read())['userId']
other=client(); assert call(other,'session',{})[0]==201
with other.open(base+'/api/mobility/config') as r:otherid=json.loads(r.read())['userId']
connection=None
for file in pathlib.Path('.wrangler/state/v3/d1').rglob('*.sqlite'):
 db=sqlite3.connect(file)
 if db.execute("SELECT name FROM sqlite_master WHERE name='mobility_drivers'").fetchone():connection=db;break
 db.close()
assert connection
bid='test-guidance-'+uuid.uuid4().hex
pickup=dict(id='hauptbahnhof',label='Frankfurt Hauptbahnhof',lng=8.6638,lat=50.1071)
destination=dict(id='alte-oper',label='Alte Oper Frankfurt',lng=8.6723,lat=50.1155)
route=dict(pickup=pickup,destination=destination,distanceMeters=2000,durationSeconds=400,geometry=dict(type='LineString',coordinates=[[8.6638,50.1071],[8.6723,50.1155]]),calculatedAt=1)
def payload():return dict(bookingId=bid,position=dict(lng=8.6691,lat=50.1097,accuracy=8,timestamp=int(time.time()*1000),speed=0))
try:
 for id in (uid,otherid):connection.execute("INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved) VALUES(?,'TEST traffic','0','TEST','TEST ROUTE','premium',1)",(id,))
 t=int(time.time()*1000)
 connection.execute("INSERT INTO mobility_bookings(id,quote_id,owner_id,service,price,route,mode,status,driver_id,created_at,updated_at) VALUES(?,?,?,'premium',4321,?,'now','accepted',?,?,?)",(bid,bid,bid,json.dumps(route),uid,t,t));connection.commit()
 assert call(other,'guidance',payload())[0]==403
 assert call(c,'guidance',payload(),'https://attacker.invalid')[0]==403
 bad=payload();bad['position']['timestamp']=1;assert call(c,'guidance',bad)[0]==400
 bad=payload();bad['position']['accuracy']=80;assert call(c,'guidance',bad)[0]==400
 for phase,target in [('accepted',pickup),('riding',destination)]:
  connection.execute('UPDATE mobility_bookings SET status=? WHERE id=?',(phase,bid));connection.commit()
  b=payload();b['destination']=dict(lng=0,lat=0) # Caller cannot replace server-owned target.
  status,reply=call(c,'guidance',b)
  if status==200:
   assert reply['bookingId']==bid and reply['phase']==phase and reply['route']['destination']==target
   assert len(reply['route']['geometry']['coordinates'])>2
   assert reply['route']['traffic']['unpaved'] is False
   steps=reply['route']['navigation'];assert len(steps)>=2 and steps[0]['type']=='depart' and steps[-1]['type']=='arrive'
   assert all(s['instruction'] and len(s['coordinates'])>=2 for s in steps)
   print('PASS:', len(steps), 'validated turn instructions for',phase)
   print('PASS: Mapbox traffic route to',phase,'with full geometry:',len(reply['route']['geometry']['coordinates']),'points')
  else:
   assert status in (502,503),(status,reply)
   print('Provider unavailable locally:',status,'— explicit failure response verified.')
  row=connection.execute('SELECT price,route FROM mobility_bookings WHERE id=?',(bid,)).fetchone()
  assert row==(4321,json.dumps(route)),row
 key=f'{int(time.time()*1000)//60000}:{uid}:traffic-guidance'
 connection.execute('INSERT INTO mobility_limits(key,count) VALUES(?,4) ON CONFLICT(key) DO UPDATE SET count=4',(key,));connection.commit()
 assert call(c,'guidance',payload())[0]==429
 connection.execute("UPDATE mobility_bookings SET status='completed' WHERE id=?",(bid,));connection.commit()
 assert call(c,'guidance',payload())[0]==403
 connection.execute("UPDATE mobility_bookings SET status='riding' WHERE id=?",(bid,));connection.execute('UPDATE mobility_drivers SET approved=0 WHERE id=?',(uid,));connection.commit()
 assert call(c,'guidance',payload())[0]==403
 print('PASS: identity/origin/assignment/approval/status/GPS guards; target is server-owned; original price and route unchanged.')
finally:
 connection.execute('DELETE FROM mobility_bookings WHERE id=?',(bid,))
 for id in (uid,otherid):
  connection.execute('DELETE FROM mobility_drivers WHERE id=?',(id,));connection.execute('DELETE FROM mobility_sessions WHERE user_id=?',(id,));connection.execute('DELETE FROM mobility_limits WHERE key LIKE ?',('%:'+id+':%',))
 connection.commit();connection.close()
