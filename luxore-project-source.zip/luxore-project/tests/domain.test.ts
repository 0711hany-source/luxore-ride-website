import { test } from 'node:test';
import assert from 'node:assert/strict';
import { quote, locations, transitions } from '../lib/ride-domain.ts';
test('Quotes reject same/unknown locations and invalid classes', () => {
  assert.throws(() => quote(locations[0], locations[0], 'premium'));
  assert.throws(() => quote('Berlin', locations[0], 'premium'));
  assert.throws(() => quote(locations[0], locations[1], 'admin'));
});
test('Premium and First Class use server-side integer cent values', () => {
  assert.equal(quote(locations[0], locations[1], 'premium'), 7500);
  assert.equal(quote(locations[0], locations[1], 'first'), 9500);
  assert.equal(quote(locations[1], locations[2], 'premium'), 7500);
});
test('A completed or cancelled ride cannot be restarted', () => {
  assert.deepEqual(transitions.completed, []);
  assert.deepEqual(transitions.cancelled, []);
  assert.deepEqual(transitions.riding, ['completed']);
  assert.equal(transitions.requested.includes('completed'), false);
});

test('Van requests use the published transfer reference and remain distinct from Business', () => {
  assert.equal(quote(locations[0], locations[1], 'van'), 8500);
  assert.equal(quote(locations[1], locations[2], 'van'), 8500);
});
