import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  classes,
  className,
  isOnRequest,
  locations,
  ON_REQUEST_LABEL,
  quote,
  transitions,
} from '../lib/ride-domain.ts';
test('Quotes reject same/unknown locations and invalid classes', () => {
  assert.throws(() => quote(locations[0], locations[0], 'premium'));
  assert.throws(() => quote('Berlin', locations[0], 'premium'));
  assert.throws(() => quote(locations[0], locations[1], 'admin'));
});
test('Premium and First Class use server-side integer cent values', () => {
  assert.equal(quote(locations[0], locations[1], 'premium'), 7500);
  assert.equal(quote(locations[0], locations[1], 'first'), 9500);
  assert.equal(quote(locations[1], locations[2], 'premium'), 7500);
});
test('Electric Class sits between Business and Van; original IDs stay valid', () => {
  assert.deepEqual(
    classes.map((c) => c.id),
    ['premium', 'electric', 'van', 'first'],
  );
  const electric = classes.find((c) => c.id === 'electric')!;
  assert.equal(electric.name, 'Electric Class');
  assert.equal(electric.detail, 'Mercedes EQE 300');
  assert.equal(electric.capacity, '4 Gäste · 2 Koffer');
  assert.equal(electric.perKm, 280);
  // Legacy reference of the unused location list, in proportion to 2,80 €/km.
  assert.equal(quote(locations[0], locations[1], 'electric'), 8400);
  assert.equal(className('electric'), 'Electric Class');
  assert.deepEqual(
    classes.filter((c) => c.onRequest).map((c) => c.id),
    ['first'],
  );
  assert.equal(isOnRequest('first'), true);
  assert.equal(isOnRequest('electric'), false);
  assert.equal(ON_REQUEST_LABEL, 'nur auf Anfrage');
});
test('A completed or cancelled ride cannot be restarted', () => {
  assert.deepEqual(transitions.completed, []);
  assert.deepEqual(transitions.cancelled, []);
  assert.deepEqual(transitions.riding, ['completed']);
  assert.equal(transitions.requested.includes('completed'), false);
});

test('Van requests use the published transfer reference and remain distinct from Business', () => {
  assert.equal(quote(locations[0], locations[1], 'van'), 8500);
  assert.equal(quote(locations[1], locations[2], 'van'), 8500);
});
