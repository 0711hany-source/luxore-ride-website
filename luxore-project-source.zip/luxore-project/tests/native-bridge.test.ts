import { test, type TestContext } from 'node:test';
import assert from 'node:assert/strict';
import {
  nativeLocation,
  type NativeReply,
} from '../app/mobility/native-location.ts';

function bridge(t: TestContext) {
  const previous = Object.getOwnPropertyDescriptor(globalThis, 'window');
  const messages: { action: string; requestId: string }[] = [];
  const target = Object.assign(new EventTarget(), {
    LuxoreNativeLocation: true,
    ReactNativeWebView: {
      postMessage: (message: string) => {
        messages.push(JSON.parse(message));
      },
    },
  });
  Object.defineProperty(globalThis, 'window', {
    value: target,
    configurable: true,
  });
  t.after(() => {
    if (previous) Object.defineProperty(globalThis, 'window', previous);
    else Reflect.deleteProperty(globalThis, 'window');
  });
  return {
    target,
    messages,
    reply: (index: number, reply: NativeReply) => {
      target.dispatchEvent(
        new CustomEvent('luxore-location', {
          detail: { ...reply, requestId: messages[index].requestId },
        }),
      );
    },
  };
}

test('status polling is suspended during native initialization; Pause still reaches the bridge', async (t) => {
  const b = bridge(t);
  const start = nativeLocation('start');
  await assert.rejects(nativeLocation('status'), /noch eingerichtet/);
  assert.deepEqual(
    b.messages.map((m) => m.action),
    ['start'],
  );
  const stop = nativeLocation('stop');
  b.reply(1, { status: { active: false } });
  await stop;
  b.reply(0, { status: { active: true, sessionId: 'test' } });
  await start;
  const status = nativeLocation('status');
  b.reply(2, { status: { active: false } });
  await status;
});

test('unanswered background setup has a bounded wait and releases later status checks', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const b = bridge(t);
  const pending = assert.rejects(nativeLocation('start'), /dauert zu lange/);
  t.mock.timers.tick(30000);
  await pending;
  const status = nativeLocation('status');
  b.reply(1, { status: { active: false } });
  await status;
});

test('a broken bridge cleans up the start lock and allows a later request', async (t) => {
  const b = bridge(t);
  const send = b.target.ReactNativeWebView.postMessage;
  b.target.ReactNativeWebView.postMessage = () => {
    throw new Error('Bridge unavailable');
  };
  await assert.rejects(nativeLocation('start'), /Bridge unavailable/);
  b.target.ReactNativeWebView.postMessage = send;
  const status = nativeLocation('status');
  b.reply(0, { status: { active: false } });
  await status;
});
