import './support/tsx-loader.mjs';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
const { default: AppHeader } = await import('../app/mobility/app-header.tsx');
const { default: Payment } = await import('../app/mobility/payment.tsx');
test('Ride and Driver retain their brand on subpages without a second page heading', () => {
  for (const variant of ['customer', 'driver']) {
    const html = renderToStaticMarkup(
      createElement(AppHeader, {
        variant,
        title: 'Meine Fahrten',
        showBack: true,
        onMenu: () => {},
        onBack: () => {},
      }),
    );
    assert.match(html, variant === 'driver' ? /LUXORÉ DRIVER/ : /LUXORÉ RIDE/);
    assert.match(html, /aria-label="Zurück"/);
    assert.doesNotMatch(html, /<h1/);
  }
});
test('collection displays the stored payable amount, including delivered refreshments, without an unsaved surcharge', () => {
  const html = renderToStaticMarkup(
    createElement(Payment, {
      preview: true,
      refresh: async () => {},
      booking: {
        id: 'test',
        price: 3500,
        fare_price: 3000,
        route: {
          pickup: { label: 'TEST Abholung' },
          destination: { label: 'TEST Ziel' },
        },
      },
    }),
  );
  assert.match(html, /Fahrpreis/);
  assert.match(html, /30,00/);
  assert.match(html, /Snacks &amp; Getränke/);
  assert.match(html, /5,00/);
  assert.match(html, /Zu kassieren/);
  assert.match(html, /Zahlung von 35,00/);
  assert.doesNotMatch(html, /Trinkgeld hinzufügen|tip-pill/);
});
