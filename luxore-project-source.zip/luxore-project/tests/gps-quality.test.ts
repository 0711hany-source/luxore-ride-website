import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  acceptFix,
  usableFix,
  displayMoved,
} from '../app/mobility/gps-quality.ts';
const now = 100000;
const point = { lat: 50.11, lng: 8.68, accuracy: 8, timestamp: now };
test('cached, inaccurate, future and duplicate GPS fixes cannot replace a fresh position', () => {
  for (const change of [
    { timestamp: now - 30001 },
    { timestamp: now + 5001 },
    { accuracy: 101 },
    { accuracy: NaN },
    { lat: 91 },
  ]) {
    assert.equal(usableFix({ ...point, ...change }, now), false);
  }
  assert.equal(acceptFix(point, point, now), false);
  assert.equal(acceptFix(null, point, now), true);
});
test('reject sudden kilometres of drift but accept road travel and reacquisition', () => {
  const driving = { ...point, lat: point.lat + 0.001, timestamp: now + 5000 };
  assert.ok(acceptFix(point, driving, now + 5000));
  assert.equal(
    acceptFix(point, { ...driving, lat: point.lat + 0.1 }, now + 5000),
    false,
  );
  assert.ok(
    acceptFix(
      point,
      { ...driving, lat: point.lat + 0.1, timestamp: now + 60000 },
      now + 60000,
    ),
  );
});
test('stationary jitter does not move the displayed car; real movement does', () => {
  assert.equal(
    displayMoved(point, { ...point, lat: point.lat + 0.00001 }, 10),
    false,
  );
  assert.ok(displayMoved(point, { ...point, lat: point.lat + 0.0002 }, 10));
  assert.ok(displayMoved(null, point));
});
