import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
const virtual = (source) => ({
  url: 'data:text/javascript,' + encodeURIComponent(source),
  shortCircuit: true,
});
registerHooks({
  resolve(s, c, next) {
    if (s === 'expo-location')
      return virtual(
        `export const Accuracy={High:4,BestForNavigation:6};export const requestForegroundPermissionsAsync=async()=>globalThis.delivery.permission?globalThis.delivery.permission():({granted:true}),getBackgroundPermissionsAsync=async()=>({granted:true}),requestBackgroundPermissionsAsync=async()=>({granted:true}),hasStartedLocationUpdatesAsync=async()=>globalThis.delivery.started,startLocationUpdatesAsync=async()=>{globalThis.delivery.started=true},stopLocationUpdatesAsync=async()=>{globalThis.delivery.started=false},getCurrentPositionAsync=()=>globalThis.delivery.first();`,
      );
    if (s === 'expo-task-manager')
      return virtual(
        `export const defineTask=(name,callback)=>{globalThis.deliveryTask=callback};`,
      );
    if (s === 'expo-secure-store')
      return virtual(
        `export const getItemAsync=async k=>globalThis.delivery.store.get(k)||null,setItemAsync=async(k,v)=>{globalThis.delivery.store.set(k,v)},deleteItemAsync=async k=>{globalThis.delivery.store.delete(k)};`,
      );
    if (s === 'react-native')
      return virtual(
        `export const Alert={alert(){throw new Error('Unexpected permission request')}};`,
      );
    if (s === './offer-alerts')
      return virtual(
        `export const offerAlerts={clear:async()=>{},sync:async(...args)=>{globalThis.delivery.alerts.push(args)}},alertStatus=async()=>({enabled:true,sound:true}),requestAlerts=async()=>({enabled:true,sound:true});`,
      );
    return next(s, c);
  },
  load(url, c, next) {
    if (
      url.endsWith('/mobile/src/location-service.ts') &&
      process.env.TEST_ORIGINAL_LOCATION_SERVICE
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_LOCATION_SERVICE, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
const service = await import('../mobile/src/location-service.ts');
const defer = () => {
  let resolve, reject;
  const promise = new Promise((a, b) => {
    resolve = a;
    reject = b;
  });
  return { promise, resolve, reject };
};
const cred = (id = 'old') => ({
  sessionId: id,
  nativeToken: (id === 'old' ? 'a' : 'b').repeat(64),
  expiresAt: Date.now() + 3600000,
});
const fix = (timestamp = Date.now(), lat = 50.11) => ({
  coords: { latitude: lat, longitude: 8.68, accuracy: 8, speed: 0, heading: 0 },
  timestamp,
});
const flush = async () => {
  for (let i = 0; i < 8; i++) await new Promise((r) => setImmediate(r));
};
function fixture() {
  const f = {
    store: new Map(),
    started: false,
    alerts: [],
    first: () => new Promise(() => {}),
    writes: [],
  };
  globalThis.delivery = f;
  return f;
}
const originalFetch = globalThis.fetch;
function mockFetch(f) {
  globalThis.fetch = async (_url, options) => {
    f.writes.push({
      token: options.headers.Authorization,
      body: JSON.parse(options.body),
      signal: options.signal,
    });
    return Response.json({
      ok: true,
      updated: true,
      offer: null,
      serverTime: Date.now(),
    });
  };
}
void test('actual service must not upload an old initial GPS result into a later shift', async () => {
  const f = fixture(),
    p = defer();
  mockFetch(f);
  f.first = () => p.promise;
  try {
    await service.startLocation(cred());
    f.first = () => new Promise(() => {});
    await service.startLocation(cred('new'));
    p.resolve(fix());
    await flush();
    assert.equal(f.writes.length, 0);
    assert.equal((await service.locationStatus()).sessionId, 'new');
    assert.equal((await service.locationStatus()).position, null);
  } finally {
    await service.stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
void test('same-session credential restart also rejects its older initial GPS callback', async () => {
  const f = fixture(),
    p = defer();
  mockFetch(f);
  f.first = () => p.promise;
  try {
    await service.startLocation(cred());
    f.first = () => new Promise(() => {});
    await service.startLocation({ ...cred(), nativeToken: 'c'.repeat(64) });
    p.resolve(fix());
    await flush();
    assert.equal(f.writes.length, 0);
    assert.equal((await service.locationStatus()).position, null);
  } finally {
    await service.stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
void test('late initial query after pause and resume cannot repopulate the new shift cache', async () => {
  const f = fixture(),
    p = defer();
  mockFetch(f);
  f.first = () => p.promise;
  try {
    await service.startLocation(cred());
    await service.stopLocation(false);
    f.first = () => new Promise(() => {});
    await service.startLocation(cred('new'));
    p.resolve(fix());
    await flush();
    assert.equal(f.writes.length, 0);
    assert.equal((await service.locationStatus()).position, null);
    assert.equal(f.started, true);
  } finally {
    await service.stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
void test('current initial query persists its raw fix and uploads with only the current capability', async () => {
  const f = fixture(),
    p = defer();
  mockFetch(f);
  f.first = () => p.promise;
  try {
    const c = cred();
    await service.startLocation(c);
    const point = fix();
    p.resolve(point);
    await flush();
    assert.equal(f.writes.length, 1);
    assert.equal(f.writes[0].token, 'Bearer ' + c.nativeToken);
    assert.equal(f.writes[0].body.timestamp, point.timestamp);
    assert.equal(
      (await service.locationStatus()).position.lat,
      point.coords.latitude,
    );
  } finally {
    await service.stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
void test('network loss retains current native cache and the next fresh background fix recovers upload', async () => {
  const f = fixture();
  mockFetch(f);
  let fail = true;
  globalThis.fetch = async (_url, options) => {
    f.writes.push(JSON.parse(options.body));
    if (fail) throw new Error('Synthetic offline');
    return Response.json({ ok: true, offer: null, serverTime: Date.now() });
  };
  try {
    await service.startLocation(cred());
    const a = fix(Date.now() - 1000);
    await globalThis.deliveryTask({ data: { locations: [a] } });
    assert.equal(f.started, true);
    assert.equal(
      (await service.locationStatus()).position.timestamp,
      a.timestamp,
    );
    fail = false;
    const b = fix(Date.now());
    await globalThis.deliveryTask({ data: { locations: [b] } });
    assert.equal(f.writes.length, 2);
    assert.equal(
      (await service.locationStatus()).position.timestamp,
      b.timestamp,
    );
  } finally {
    await service.stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
void test('late upload denial from a previous shift cannot stop the new native shift', async () => {
  const f = fixture(),
    response = defer();
  globalThis.fetch = async () => response.promise;
  try {
    await service.startLocation(cred());
    const upload = service.deliverForeground(fix());
    await flush();
    await service.startLocation(cred('new'));
    response.resolve(new Response('', { status: 401 }));
    await upload;
    assert.equal(f.started, true);
    assert.equal((await service.locationStatus()).sessionId, 'new');
  } finally {
    await service.stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
void test('actual upload alert predicate rejects renewed capability of the same session', async () => {
  const f = fixture();
  mockFetch(f);
  try {
    await service.startLocation(cred());
    await service.deliverForeground(fix());
    assert.equal(f.alerts.length, 1);
    const current = f.alerts[0][3];
    assert.equal(await current(), true);
    await service.startLocation({ ...cred(), nativeToken: 'c'.repeat(64) });
    assert.equal(await current(), false);
  } finally {
    await service.stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
void test('new start invalidates old upload alert before pending permission updates stored credential', async () => {
  const f = fixture(),
    gate = defer();
  mockFetch(f);
  let transition;
  try {
    await service.startLocation(cred());
    await service.deliverForeground(fix());
    const current = f.alerts[0][3];
    f.permission = () => gate.promise;
    transition = service.startLocation(cred('new'));
    assert.equal(await current(), false);
    gate.resolve({ granted: true });
    await transition;
    assert.equal((await service.locationStatus()).sessionId, 'new');
  } finally {
    gate.resolve({ granted: true });
    if (transition) await transition;
    await service.stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
