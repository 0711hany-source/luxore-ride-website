import test from 'node:test';
import assert from 'node:assert/strict';
import { TrafficGuidanceSession } from '../app/mobility/traffic-guidance-session.ts';
import {
  currentGuidance,
  type Guidance,
} from '../app/mobility/guidance-policy.ts';
import type { GpsFix } from '../app/mobility/gps-quality.ts';

const start = 1800000000000;
const route = (now: number) => ({
  pickup: { id: 'a', label: 'A', lat: 50, lng: 8 },
  destination: { id: 'b', label: 'B', lat: 50, lng: 8.004 },
  distanceMeters: 285,
  durationSeconds: 50,
  geometry: {
    type: 'LineString' as const,
    coordinates: [
      [8, 50],
      [8.004, 50],
    ],
  },
  calculatedAt: now,
});
const settle = () => new Promise<void>((resolve) => setImmediate(resolve));
function setup(phase = 'riding') {
  let now = start;
  const requests: {
    id: string;
    fix: GpsFix;
    signal: AbortSignal;
    resolve: (value: Guidance) => void;
    reject: (error: Error) => void;
  }[] = [];
  const session = new TrafficGuidanceSession(
    'trip',
    phase,
    (id, fix, signal) =>
      new Promise((resolve, reject) => {
        requests.push({ id, fix, signal, resolve, reject });
      }),
    () => now,
  );
  const fix = (): GpsFix => ({
    lat: 50,
    lng: 8.001,
    heading: 90,
    speed: 6,
    accuracy: 6,
    timestamp: now,
  });
  return {
    session,
    requests,
    fix,
    time: (elapsed: number) => {
      now = start + elapsed;
    },
    tick: (online = true, visible = true) =>
      session.update(fix(), online, visible),
    reply: (index: number, overrides: Partial<Guidance> = {}) =>
      requests[index].resolve({
        bookingId: 'trip',
        phase,
        route: route(now),
        ...overrides,
      }),
  };
}

void test('opening and closing the menu preserves the route and normal refresh cadence', async () => {
  const h = setup();
  h.session.resume();
  h.tick();
  h.reply(0);
  await settle();
  const saved = h.session.getSnapshot().value;
  for (let i = 1; i <= 10; i++) {
    h.time(i * 1000);
    h.session.pause();
    h.session.resume();
    h.tick();
    assert.equal(h.session.getSnapshot().value, saved);
  }
  h.time(44000);
  h.tick();
  assert.equal(h.requests.length, 1);
  h.time(45000);
  h.tick();
  assert.equal(h.requests.length, 2);
  assert.equal(h.session.getSnapshot().value, saved);
  h.session.pause();
});

void test('a cancelled response cannot overwrite or finish the newer request after resuming', async () => {
  const h = setup();
  h.session.resume();
  h.tick();
  h.time(1000);
  h.session.pause();
  assert.equal(h.requests[0].signal.aborted, true);
  assert.equal(h.session.getSnapshot().pendingSince, null);
  for (let i = 2; i < 15; i++) {
    h.time(i * 1000);
    h.session.resume();
    h.tick();
    h.session.pause();
  }
  assert.equal(h.requests.length, 1);
  h.time(15000);
  h.session.resume();
  h.tick();
  assert.equal(h.requests.length, 2);
  h.reply(0);
  await settle();
  assert.equal(h.session.getSnapshot().value, null);
  assert.equal(h.session.getSnapshot().pendingSince, start + 15000);
  assert.equal(h.session.getSnapshot().failed, false);
  h.reply(1);
  await settle();
  assert.equal(
    h.session.getSnapshot().value?.route.calculatedAt,
    start + 15000,
  );
  assert.equal(h.session.getSnapshot().pendingSince, null);
});

void test('network loss cancels only the refresh, retains fresh guidance, and retries without a burst', async () => {
  const h = setup();
  h.session.resume();
  h.tick();
  h.reply(0);
  await settle();
  const saved = h.session.getSnapshot().value;
  h.time(45000);
  h.tick();
  h.time(46000);
  h.tick(false);
  assert.equal(h.requests[1].signal.aborted, true);
  assert.equal(h.session.getSnapshot().value, saved);
  h.time(50000);
  h.tick();
  h.tick(false);
  h.tick();
  assert.equal(h.requests.length, 2);
  h.time(60000);
  h.tick();
  assert.equal(h.requests.length, 3);
  h.requests[1].reject(new Error('old cancelled request'));
  await settle();
  assert.equal(h.session.getSnapshot().failed, false);
  assert.equal(h.session.getSnapshot().pendingSince, start + 60000);
  h.reply(2);
  await settle();
});

void test('backgrounding rejects a late reply and waits for fresh GPS on return', async () => {
  const h = setup();
  h.session.resume();
  h.tick();
  const oldFix = h.fix();
  h.time(1000);
  h.tick(true, false);
  h.time(120000);
  h.tick(true, false);
  assert.equal(h.requests.length, 1);
  h.reply(0);
  await settle();
  assert.equal(h.session.getSnapshot().value, null);
  h.session.update(oldFix, true, true);
  assert.equal(h.requests.length, 1);
  h.tick();
  assert.equal(h.requests.length, 2);
  assert.equal(h.requests[1].fix.timestamp, start + 120000);
  h.reply(1);
  await settle();
});

void test('a hung request cannot keep loading after wake or clear a later request', async () => {
  const h = setup();
  h.session.resume();
  h.tick();
  h.time(20000);
  h.tick();
  assert.equal(h.requests[0].signal.aborted, true);
  assert.equal(h.requests.length, 2);
  assert.equal(h.session.getSnapshot().pendingSince, start + 20000);
  h.reply(0);
  await settle();
  assert.equal(h.session.getSnapshot().pendingSince, start + 20000);
  assert.equal(h.session.getSnapshot().value, null);
  h.reply(1);
  await settle();
});

void test('provider failure retries after 15 seconds and successful guidance returns to the 45 second cadence', async () => {
  const h = setup();
  h.session.resume();
  h.tick();
  h.requests[0].reject(new Error('network'));
  await settle();
  assert.equal(h.session.getSnapshot().failed, true);
  h.time(14999);
  h.tick();
  assert.equal(h.requests.length, 1);
  h.time(15000);
  h.tick();
  assert.equal(h.requests.length, 2);
  h.reply(1);
  await settle();
  assert.equal(h.session.getSnapshot().failed, false);
  h.time(30000);
  h.tick();
  assert.equal(h.requests.length, 2);
  h.time(60000);
  h.tick();
  assert.equal(h.requests.length, 3);
  h.session.pause();
});

void test('late, stale and foreign-trip replies never become active directions', async () => {
  for (const kind of ['late', 'stale', 'phase', 'trip']) {
    const h = setup();
    h.session.resume();
    h.tick();
    if (kind === 'late') h.time(15000);
    h.reply(
      0,
      kind === 'stale'
        ? { route: route(start - 91000) }
        : kind === 'phase'
          ? { phase: 'accepted' }
          : kind === 'trip'
            ? { bookingId: 'other' }
            : {},
    );
    await settle();
    assert.equal(h.session.getSnapshot().value, null, kind);
    assert.equal(h.session.getSnapshot().failed, true, kind);
    assert.equal(h.session.getSnapshot().pendingSince, null, kind);
  }
});

void test('new trip phases own independent directions and expired offline routes remain unusable', async () => {
  const old = setup('accepted');
  old.session.resume();
  old.tick();
  old.reply(0);
  await settle();
  old.session.pause();
  const next = setup('riding');
  next.session.resume();
  next.tick();
  assert.equal(next.session.getSnapshot().value, null);
  next.reply(0);
  await settle();
  assert.equal(next.session.getSnapshot().value?.phase, 'riding');
  old.time(91000);
  old.session.resume();
  old.tick(false);
  assert.equal(
    currentGuidance(
      old.session.getSnapshot().value,
      'trip',
      'accepted',
      start + 91000,
    ),
    null,
  );
});

void test('subscribers see request state and stop receiving changes after cleanup', async () => {
  const h = setup();
  let notifications = 0;
  const unsubscribe = h.session.subscribe(() => {
    notifications++;
  });
  const before = h.session.getSnapshot();
  h.session.resume();
  h.tick();
  assert.notEqual(h.session.getSnapshot(), before);
  h.reply(0);
  await settle();
  assert.equal(notifications, 3);
  unsubscribe();
  h.time(45000);
  h.tick();
  h.session.pause();
  assert.equal(notifications, 3);
});
