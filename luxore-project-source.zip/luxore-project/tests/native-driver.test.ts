import test from 'node:test';
import assert from 'node:assert/strict';
import {
  canSelectVehicle,
  shiftLocked,
  shiftState,
  liveOffer,
  type DriverState,
} from '../mobile/src/driver-model.ts';
import { ForegroundUpload } from '../mobile/src/foreground-upload.ts';
import type { FleetVehicle } from '../lib/mobility/domain.ts';
const now = 100000;
const fix = { lat: 50.11, lng: 8.68, accuracy: 8, timestamp: now };
function driver(): DriverState {
  return {
    driver: {
      id: 'driver-a',
      name: 'Test',
      phone: '+4900000000',
      vehicle: 'Audi A6',
      plate: 'TEST',
      vehicle_id: 'vehicle-a',
      service: 'premium',
      approved: 1,
      online: 1,
      session_id: 'shift-a',
      lat: 50.11,
      lng: 8.68,
      location_at: now,
      accuracy: 8,
    },
    offers: [],
    bookings: [],
    payments: [],
    fleet: { id: 'fleet-a', name: 'Flotte A' },
  };
}
function vehicle(): FleetVehicle {
  return {
    id: 'vehicle-a',
    fleet_id: 'fleet-a',
    model: 'Audi A6',
    plate: 'TEST',
    services: '["premium"]',
    status: 'active',
    archived_reason: null,
    driver_id: null,
    driver_name: null,
    online: 0,
  };
}
test('native shift requires approval, matching device capability, fresh GPS and server presence', () => {
  const state = driver();
  assert.equal(shiftState(state, 'shift-a', fix, now), 'online');
  assert.equal(shiftState(state, null, fix, now), 'offline');
  assert.equal(shiftState(state, 'different-device', fix, now), 'offline');
  assert.equal(
    shiftState(state, 'shift-a', { ...fix, timestamp: now - 16000 }, now),
    'gps',
  );
  state.driver!.online = 0;
  assert.equal(shiftState(state, 'shift-a', fix, now), 'connecting');
  state.driver!.online = 1;
  state.driver!.location_at = now - 46000;
  assert.equal(shiftState(state, 'shift-a', fix, now), 'connecting');
  state.driver!.approved = 0;
  assert.equal(shiftState(state, 'shift-a', fix, now), 'pending');
  state.driver = null;
  assert.equal(shiftState(state, 'shift-a', fix, now), 'unregistered');
});
test('native vehicle chooser blocks other fleets, occupied/archive cars, shifts and unsettled payments', () => {
  const state = driver(),
    car = vehicle();
  state.driver!.online = 0;
  state.driver!.session_id = null;
  assert.equal(canSelectVehicle(state, car, null), true);
  assert.equal(
    canSelectVehicle(state, { ...car, fleet_id: 'fleet-b' }, null),
    false,
  );
  assert.equal(
    canSelectVehicle(state, { ...car, driver_id: 'driver-b' }, null),
    false,
  );
  assert.equal(
    canSelectVehicle(state, { ...car, status: 'archived' }, null),
    false,
  );
  assert.equal(canSelectVehicle(state, car, 'shift-a'), false);
  state.driver!.session_id = 'shift-other';
  assert.equal(canSelectVehicle(state, car, null), false);
  state.driver!.session_id = null;
  state.payments = [{ id: 'payment' } as never];
  assert.equal(shiftLocked(state), true);
  assert.equal(canSelectVehicle(state, car, null), false);
  state.payments = [];
  state.bookings = [{ id: 'ride' } as never];
  assert.equal(shiftLocked(state), true);
  assert.equal(canSelectVehicle(state, car, null), false);
});
test('native offers respect the server clock and never surface an expired offer', () => {
  const state = driver();
  state.offers = [
    { id: 'old', expires_at: now - 1, booking: {} as never },
    { id: 'live', expires_at: now + 1, booking: {} as never },
  ];
  assert.equal(liveOffer(state, now)?.id, 'live');
  assert.equal(liveOffer(state, now + 1), null);
});
test('foreground uploads are rate bounded, non-overlapping and ignore duplicate GPS timestamps', async () => {
  const upload = new ForegroundUpload();
  let finish!: () => void;
  let calls = 0;
  const first = upload.send(1000, 1000, async () => {
    calls++;
    await new Promise<void>((resolve) => {
      finish = resolve;
    });
  });
  await upload.send(2000, 5000, async () => {
    calls++;
  });
  assert.equal(calls, 1);
  finish();
  await first;
  await upload.send(1000, 6000, async () => {
    calls++;
  });
  await upload.send(2000, 3000, async () => {
    calls++;
  });
  assert.equal(calls, 1);
  await upload.send(4000, 4000, async () => {
    calls++;
  });
  assert.equal(calls, 2);
});
test('failed foreground upload releases its lease; next fresh fix retries without a stale queue', async () => {
  const upload = new ForegroundUpload();
  await assert.rejects(
    upload.send(1000, 1000, async () => {
      throw new Error('offline');
    }),
    /offline/,
  );
  let calls = 0;
  await upload.send(2000, 2000, async () => {
    calls++;
  });
  assert.equal(calls, 0);
  await upload.send(5000, 5000, async () => {
    calls++;
  });
  assert.equal(calls, 1);
});
