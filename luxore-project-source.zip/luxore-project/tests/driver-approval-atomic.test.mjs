import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { createClient } from '@libsql/client';
import { readFileSync, readdirSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  resolve(s, c, next) {
    if (s === '#approval-adapter')
      return {
        url: new URL('../db/sqlite.ts?approval-adapter', import.meta.url).href,
        shortCircuit: true,
      };
    return next(s, c);
  },
  load(url, c, next) {
    if (url.endsWith('/db/sqlite.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `export const accountsConfigured=()=>true,runtimeDatabase=()=>globalThis.approvalTest.db; export class DatabaseUnavailable extends Error {}`,
      };
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `
      export class ApiError extends Error {constructor(status,message){super(message);this.status=status}}
      export const db=()=>globalThis.approvalTest.db,settings=()=>({}),tokenHash=async()=>'',isAdmin=u=>u.userId==='operator';
      export const identity=async()=>({userId:globalThis.approvalTest.user}),body=r=>r.json(),json=(v,status=200)=>Response.json(v,{status});
      export const text=v=>{if(typeof v!=='string'||!v.trim())throw new ApiError(400,'empty');return v.trim()};
      export const handled=async fn=>{try{return await fn()}catch(e){return json({error:e.message},e.status||500)}};
    `,
      };
    return next(url, c);
  },
});
const { sqliteDatabase } = await import('#approval-adapter');
const { POST } = await import('../app/api/mobility/operations/route.ts');
const send = (approved, driverId = 'driver-a') =>
  POST(
    new Request('https://test.invalid/api/mobility/operations', {
      method: 'POST',
      body: JSON.stringify({ approved, driverId }),
    }),
  );
async function fixture(approved = 0) {
  const client = createClient({ url: ':memory:' }),
    db = sqliteDatabase(client);
  const dir = new URL('../drizzle/', import.meta.url);
  for (const name of readdirSync(dir)
    .filter((n) => n.endsWith('.sql'))
    .sort())
    await client.executeMultiple(readFileSync(new URL(name, dir), 'utf8'));
  globalThis.approvalTest = { db, user: 'owner-a' };
  for (const id of ['a', 'b']) {
    await client.execute({
      sql: 'INSERT INTO mobility_fleets(id,name,owner_id,deputy_id,created_at) VALUES(?,?,?,?,0)',
      args: ['fleet-' + id, 'Test ' + id, 'owner-' + id, 'deputy-' + id],
    });
    for (const user of ['owner-', 'deputy-', 'driver-'])
      await client.execute({
        sql: "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,'Test','000000',?,'driver',0)",
        args: [user + id, 'fleet-' + id],
      });
    await client.execute({
      sql: "INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,session_id) VALUES(?,'Test','000000','Test','TEST','premium',?,0,NULL)",
      args: ['driver-' + id, approved],
    });
  }
  await client.execute(
    "INSERT INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at) VALUES('offer','trip','driver-a','pending',9999999999999,0)",
  );
  const snapshot = async () => ({
    drivers: (
      await db.prepare('SELECT * FROM mobility_drivers ORDER BY id').all()
    ).results,
    offers: (
      await db.prepare('SELECT * FROM mobility_offers ORDER BY id').all()
    ).results,
    audit: (
      await db
        .prepare('SELECT * FROM mobility_operator_audit ORDER BY id')
        .all()
    ).results,
  });
  return { client, db, snapshot, close: () => client.close() };
}
test('failed real audit insert rolls back approval; identical retry commits once', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    await f.client.executeMultiple(
      "CREATE TRIGGER fail_approval_audit BEFORE INSERT ON mobility_operator_audit BEGIN SELECT RAISE(ABORT,'synthetic audit failure'); END;",
    );
    assert.equal((await send(true)).status, 500);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute('DROP TRIGGER fail_approval_audit');
    assert.equal((await send(true)).status, 200);
    const saved = await f.snapshot();
    assert.equal(saved.drivers[0].approved, 1);
    assert.equal(saved.audit.length, 1);
    assert.equal((await send(true)).status, 200);
    assert.deepEqual(await f.snapshot(), saved);
  } finally {
    f.close();
  }
});
test('audit failure rolls back unapproval and pending offer withdrawal together', async () => {
  const f = await fixture(1);
  try {
    const before = await f.snapshot();
    await f.client.executeMultiple(
      "CREATE TRIGGER fail_approval_audit BEFORE INSERT ON mobility_operator_audit BEGIN SELECT RAISE(ABORT,'synthetic audit failure'); END;",
    );
    assert.equal((await send(false)).status, 500);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute('DROP TRIGGER fail_approval_audit');
    assert.equal((await send(false)).status, 200);
    const saved = await f.snapshot();
    assert.equal(saved.offers[0].status, 'withdrawn');
    assert.equal(saved.audit.length, 1);
    assert.equal((await send(false)).status, 200);
    assert.deepEqual(await f.snapshot(), saved);
  } finally {
    f.close();
  }
});
test('owner/deputy remain fleet-scoped, ordinary staff are denied, operator keeps existing scope', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    assert.equal((await send(true, 'driver-b')).status, 403);
    globalThis.approvalTest.user = 'driver-a';
    assert.equal((await send(true)).status, 403);
    assert.deepEqual(await f.snapshot(), before);
    globalThis.approvalTest.user = 'deputy-a';
    assert.equal((await send(true)).status, 200);
    globalThis.approvalTest.user = 'operator';
    assert.equal((await send(true, 'driver-b')).status, 200);
    assert.equal((await f.snapshot()).audit.length, 2);
  } finally {
    f.close();
  }
});
test('repeated approval preserves an approved online GPS session and creates no new audit', async () => {
  const f = await fixture(1);
  try {
    await f.client.execute(
      "UPDATE mobility_drivers SET online=1,session_id='active-shift',lat=50,lng=8,accuracy=5,location_at=100 WHERE id='driver-a'",
    );
    const before = await f.snapshot();
    assert.equal((await send(true)).status, 200);
    assert.deepEqual(await f.snapshot(), before);
    assert.equal((await send(false)).status, 409);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
test('active/unpaid rides block revocation without changing offers or creating audit', async () => {
  for (const status of ['accepted', 'arrived', 'riding', 'completed']) {
    const f = await fixture(1);
    try {
      await f.client.execute({
        sql: "INSERT INTO mobility_bookings(id,quote_id,owner_id,driver_id,service,price,route,mode,status,created_at,updated_at,completed_at,payment_status) VALUES('trip','q','customer','driver-a','premium',1500,'{}','now',?,0,0,1,'unpaid')",
        args: [status],
      });
      const before = await f.snapshot();
      assert.equal((await send(false)).status, 409);
      assert.deepEqual(await f.snapshot(), before);
    } finally {
      f.close();
    }
  }
});
test('target and actor blocked accounts, missing profiles and malformed flags do not mutate business data', async () => {
  for (const blocked of ['driver-a', 'owner-a']) {
    const f = await fixture();
    try {
      await f.client.execute({
        sql: "INSERT INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES(?,'synthetic@example.test','Test','000000','driver','blocked',0,0)",
        args: [blocked],
      });
      const before = await f.snapshot();
      assert.equal(
        (await send(true)).status,
        blocked === 'driver-a' ? 409 : 403,
      );
      assert.deepEqual(await f.snapshot(), before);
    } finally {
      f.close();
    }
  }
  const f = await fixture();
  try {
    globalThis.approvalTest.user = 'operator';
    const before = await f.snapshot();
    assert.equal((await send(true, 'missing')).status, 404);
    assert.equal((await send('yes')).status, 400);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
test('authority removed before write transaction is reevaluated using the transaction connection', async () => {
  const f = await fixture();
  try {
    globalThis.approvalTest.user = 'deputy-a';
    const tx = f.db.writeTransaction;
    f.db.writeTransaction = async (work) => {
      await f.client.execute(
        "UPDATE mobility_fleets SET deputy_id=NULL WHERE id='fleet-a'",
      );
      return tx(work);
    };
    const before = await f.snapshot();
    assert.equal((await send(true)).status, 403);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
