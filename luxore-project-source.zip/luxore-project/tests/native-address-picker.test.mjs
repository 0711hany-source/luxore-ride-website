import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
globalThis.addressListeners = new Set();
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    'react-native',
    `export const View='View',Text='Text',Pressable='Pressable',ScrollView='ScrollView',Modal='Modal',TextInput='TextInput',KeyboardAvoidingView='KeyboardAvoidingView',ActivityIndicator='ActivityIndicator'; export const Platform={OS:'android'},StyleSheet={create:v=>v}; export const AppState={currentState:'active',addEventListener(event,listener){globalThis.addressListeners.add(listener);return {remove(){globalThis.addressListeners.delete(listener)}}}};`,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaView='SafeAreaView';`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',MapPin='MapPin',Search='Search';`,
  ],
  [
    'expo-secure-store',
    `export const getItemAsync=async()=>null,setItemAsync=async()=>{},deleteItemAsync=async()=>{};`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    const source = mocked.get(specifier);
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: Picker } =
  await import('../mobile/src/NativeAddressPicker.tsx');
const point = {
  id: 'temporary',
  label: 'Alte Oper, Opernplatz 1, Frankfurt am Main',
  lat: 50.115,
  lng: 8.671,
  attribution: '© OpenStreetMap contributors. Powered by Geoapify',
};
const confirmed = { ...point, id: 'owner-bound-address' };
const deferred = () => {
  let resolve;
  const promise = new Promise((r) => {
    resolve = r;
  });
  return { promise, resolve };
};
async function settle() {
  for (let i = 0; i < 4; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
const props = () => ({
  visible: true,
  token: 'a'.repeat(64),
  title: 'Abholort',
  onClose() {},
  onSelected() {},
});
async function search(renderer) {
  await act(async () => {
    const input = renderer.root.findByType('TextInput');
    input.props.onChangeText('Alte Oper');
  });
  await act(async () =>
    renderer.root.findByType('TextInput').props.onSubmitEditing(),
  );
  await settle();
}
const result = (renderer) =>
  renderer.root
    .findAllByType('Pressable')
    .find((n) => n.props.accessibilityLabel === point.label);
async function lifecycle(value) {
  await act(async () => {
    for (const listener of globalThis.addressListeners) listener(value);
  });
  await settle();
}

void test('native full-screen picker shows wrapped licensed suggestions and returns only the confirmed server address', async () => {
  const old = globalThis.fetch;
  let renderer,
    writes = 0,
    closes = 0;
  const selected = [];
  globalThis.fetch = async (url, options) => {
    assert.equal(url, 'https://luxoreride.de/api/mobility/places');
    assert.equal(options.headers.Authorization, 'Bearer ' + 'a'.repeat(64));
    const body = JSON.parse(options.body);
    if (body.kind === 'search') return Response.json({ results: [point] });
    assert.deepEqual(body, {
      kind: 'selected',
      query: 'Alte Oper',
      lat: point.lat,
      lng: point.lng,
    });
    writes++;
    return Response.json({ results: [confirmed] });
  };
  try {
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(Picker, {
          ...props(),
          onClose() {
            closes++;
          },
          onSelected: (p) => selected.push(p),
        }),
      );
    });
    assert.equal(
      renderer.root.findByType('Modal').props.presentationStyle,
      'fullScreen',
    );
    assert.deepEqual(renderer.root.findByType('SafeAreaView').props.edges, [
      'top',
      'bottom',
    ]);
    assert.equal(renderer.root.findByType('TextInput').props.maxLength, 256);
    await search(renderer);
    assert.deepEqual(selected, []);
    assert.equal(writes, 0);
    assert.match(JSON.stringify(renderer.toJSON()), /Powered by Geoapify/);
    assert.equal(result(renderer).props.style.minHeight, 76);
    await act(async () => result(renderer).props.onPress());
    await settle();
    assert.deepEqual(selected, [confirmed]);
    assert.equal(writes, 1);
    await act(async () =>
      renderer.root
        .findAllByType('Pressable')
        .find((n) => n.props.accessibilityLabel === 'Adresssuche schließen')
        .props.onPress(),
    );
    assert.equal(closes, 1);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});

void test('closing the picker aborts its pending search and drops ignored-abort results', async () => {
  const old = globalThis.fetch,
    read = deferred();
  let renderer, signal;
  const selected = [];
  globalThis.fetch = async (url, options) => {
    signal = options.signal;
    return read.promise;
  };
  try {
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(Picker, {
          ...props(),
          onSelected: (p) => selected.push(p),
        }),
      );
    });
    await search(renderer);
    assert.equal(signal.aborted, false);
    await act(async () =>
      renderer.update(
        React.createElement(Picker, { ...props(), visible: false }),
      ),
    );
    assert.equal(signal.aborted, true);
    assert.equal(renderer.toJSON(), null);
    read.resolve(Response.json({ results: [point] }));
    await settle();
    assert.deepEqual(selected, []);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});

void test('background confirmation keeps its write and delivers once after foreground return', async () => {
  const old = globalThis.fetch,
    write = deferred();
  let renderer, writeSignal;
  const selected = [];
  globalThis.fetch = async (url, options) => {
    if (JSON.parse(options.body).kind === 'search')
      return Response.json({ results: [point] });
    writeSignal = options.signal;
    return write.promise;
  };
  try {
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(Picker, {
          ...props(),
          onSelected: (p) => selected.push(p),
        }),
      );
    });
    await search(renderer);
    await act(async () => result(renderer).props.onPress());
    await lifecycle('background');
    assert.equal(writeSignal.aborted, false);
    write.resolve(Response.json({ results: [confirmed] }));
    await settle();
    assert.deepEqual(selected, []);
    await lifecycle('active');
    assert.deepEqual(selected, [confirmed]);
    await lifecycle('background');
    await lifecycle('active');
    assert.deepEqual(selected, [confirmed]);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});

void test('account change cannot deliver the old account confirmation into the new picker', async () => {
  const old = globalThis.fetch,
    write = deferred();
  let renderer;
  const selected = [];
  globalThis.fetch = async (url, options) =>
    JSON.parse(options.body).kind === 'search'
      ? Response.json({ results: [point] })
      : write.promise;
  try {
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(Picker, {
          ...props(),
          onSelected: (p) => selected.push(p),
        }),
      );
    });
    await search(renderer);
    await act(async () => result(renderer).props.onPress());
    await act(async () =>
      renderer.update(
        React.createElement(Picker, {
          ...props(),
          token: 'b'.repeat(64),
          onSelected: (p) => selected.push(p),
        }),
      ),
    );
    assert.equal(renderer.root.findByType('TextInput').props.value, '');
    write.resolve(Response.json({ results: [confirmed] }));
    await settle();
    assert.deepEqual(selected, []);
    assert.equal(globalThis.addressListeners.size, 1);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});
