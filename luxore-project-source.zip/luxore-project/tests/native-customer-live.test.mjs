import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
const store = new Map([['luxore-account-v1', 'a'.repeat(64)]]);
globalThis.nativeViewStore = store;
globalThis.customerAppListeners = new Set();
globalThis.require = () => 1; // Metro resolves static PNG assets in real APKs.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    './CustomerMap',
    `import React from 'react'; export default props=>React.createElement('NativeCustomerMap',props);`,
  ],
  [
    'expo-location',
    `export const Accuracy={High:4}; export const requestForegroundPermissionsAsync=async()=>({status:'denied'}),getCurrentPositionAsync=async()=>{throw new Error('GPS not enabled in view tests')};`,
  ],
  [
    'react-native',
    `
    export const View='View', Text='Text', Pressable='Pressable', ScrollView='ScrollView', Modal='Modal', Image='Image', TextInput='TextInput', KeyboardAvoidingView='KeyboardAvoidingView', ActivityIndicator='ActivityIndicator';
    export const Platform={OS:'android'}, StyleSheet={create:v=>v}, Keyboard={dismiss(){}}, Share={async share(){}}, Linking={async openURL(){},async openSettings(){}}, Alert={alert(){}};
    export const AppState={currentState:'active',addEventListener(event,listener){globalThis.customerAppListeners.add(listener);return {remove(){globalThis.customerAppListeners.delete(listener)}}}}, BackHandler={addEventListener(){return {remove(){}}}};
    export const useWindowDimensions=()=>({width:390,height:844});
    export const PanResponder={create:handlers=>({panHandlers:handlers})};
    export const Animated={Value:class {constructor(v){this.value=v}setValue(v){this.value=v}},View:'AnimatedView',spring:(v,o)=>({start:()=>v.setValue(o.toValue)})};
  `,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaProvider='SafeAreaProvider', SafeAreaView='SafeAreaView';`,
  ],
  ['expo-status-bar', `export const StatusBar='StatusBar';`],
  [
    'expo-constants',
    `export default {expoConfig:{extra:{variant:'customer'}}};`,
  ],
  [
    'expo-secure-store',
    `export const getItemAsync=async k=>globalThis.nativeViewStore.get(k)||null,setItemAsync=async(k,v)=>{globalThis.nativeViewStore.set(k,v)},deleteItemAsync=async k=>{globalThis.nativeViewStore.delete(k)};`,
  ],
  [
    'expo-crypto',
    `export const randomUUID=()=> 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';`,
  ],
  [
    'expo-notifications',
    `export const getLastNotificationResponse=()=>null,clearLastNotificationResponse=()=>{},addNotificationResponseReceivedListener=()=>({remove(){}});`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',ArrowRight='ArrowRight', CalendarDays='CalendarDays', CarFront='CarFront', Check='Check', ChevronRight='ChevronRight', CircleHelp='CircleHelp', Home='Home', LogOut='LogOut', Mail='Mail', MapPinned='MapPinned', MapPin='MapPin', Clock3='Clock3', Settings='Settings', ShieldCheck='ShieldCheck', UserRound='UserRound', Users='Users',ChevronDown='ChevronDown',LocateFixed='LocateFixed',Navigation='Navigation',Phone='Phone',RefreshCw='RefreshCw',X='X',Plus='Plus',Minus='Minus',Search='Search';`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    let source = mocked.get(specifier);
    if (specifier.endsWith('/RideWorkspace') || specifier === './RideWorkspace')
      source = `export default function ForbiddenEmbeddedDriver(){throw new Error('Driver mounted a WebView');}`;
    if (specifier === './use-driver-gps')
      source = `export function useDriverGps(){return {position:{lat:50.11,lng:8.68,accuracy:8,timestamp:Date.now()},sessionId:null,error:'',foreground:true,restart:async()=>{},sync:async()=>({active:false})}}`;
    if (specifier === './location-service')
      source = `export const resumeLocation=async()=>({active:false}),stopLocation=async()=>{},foregroundPermission=async()=>{},startLocation=async()=>({active:true});`;
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: App } = await import('../mobile/src/App.tsx');

const { default: Live } = await import('../mobile/src/CustomerLiveScreen.tsx');
const now = Date.now();
const account = {
  id: 'customer-a',
  name: 'Test Kunde',
  email: 'test@example.test',
  phone: '+490000',
  kind: 'customer',
};
const route = {
  pickup: { id: 'p', label: 'Opernplatz', lat: 50.11, lng: 8.68 },
  destination: { id: 'd', label: 'Flughafen', lat: 50.04, lng: 8.56 },
  geometry: {
    type: 'LineString',
    coordinates: [
      [8.68, 50.11],
      [8.56, 50.04],
    ],
  },
  distanceMeters: 21000,
  durationSeconds: 1500,
};
const booking = {
  id: 'ride-a',
  owner_id: account.id,
  created_at: now,
  updated_at: now,
  status: 'accepted',
  service: 'premium',
  price: 5250,
  route,
  driver_id: 'driver-a',
  driver: {
    id: 'driver-a',
    name: 'Test Chauffeur',
    vehicle: 'Audi A6',
    plate: 'TEST',
    phone: '+490000',
    lat: 50.1,
    lng: 8.67,
    accuracy: 8,
    location_at: now,
  },
};
const props = {
  token: 'a'.repeat(64),
  ownerId: account.id,
  active: true,
  bookingId: booking.id,
  onTrips() {},
};
async function settle() {
  for (let i = 0; i < 8; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
function api(rows = [booking]) {
  const calls = [];
  globalThis.fetch = async (url, options) => {
    calls.push({ url, options });
    assert.match(url, /^https:\/\/luxoreride.de\/api\/mobility\//);
    assert.equal(options.headers.Authorization, 'Bearer ' + props.token);
    if (url.endsWith('/account'))
      return Response.json({
        account,
        registrationReady: true,
        isAdmin: false,
      });
    if (url.endsWith('/config'))
      return Response.json({ publicMapToken: 'pk.' + 'a'.repeat(30) });
    if (url.endsWith('/nearby'))
      return Response.json({
        drivers: [
          { lat: 50.1, lng: 8.6 },
          { lat: 50.11, lng: 8.61 },
          { lat: 50.12, lng: 8.62 },
        ],
      });
    assert.ok(url.endsWith('/bookings'));
    assert.equal(options.method, 'GET');
    return Response.json({ bookings: rows, serverTime: Date.now() });
  };
  return calls;
}
test('actual native live screen renders confirmed ride and protected driver marker; swipe collapses details', async () => {
  const old = globalThis.fetch;
  let root;
  try {
    api();
    await act(async () => {
      root = Renderer.create(React.createElement(Live, props));
    });
    await settle();
    const map = root.root.findByType('NativeCustomerMap');
    assert.equal(map.props.token, 'pk.' + 'a'.repeat(30));
    assert.equal(map.props.bookingId, booking.id);
    assert.deepEqual(map.props.driver, { lat: 50.1, lng: 8.67 });
    assert.match(JSON.stringify(root.toJSON()), /Test Chauffeur|Audi A6|52,50/);
    assert.ok(
      root.root.findByProps({ accessibilityLabel: 'Chauffeur anrufen' }),
    );
    const handle = root.root
      .findAllByType('View')
      .find((n) => n.props.onPanResponderRelease);
    await act(async () => handle.props.onPanResponderRelease(null, { dy: 80 }));
    assert.equal(root.root.findAllByType('ScrollView').length, 0);
    assert.equal(root.root.findAllByType('NativeCustomerMap').length, 1);
    await act(async () =>
      root.root
        .findByProps({ accessibilityLabel: 'Sicherheit öffnen' })
        .props.onPress(),
    );
    assert.equal(
      root.root.findByType('Modal').props.presentationStyle,
      'fullScreen',
    );
    assert.equal(root.root.findByType('Modal').props.visible, true);
  } finally {
    if (root) await act(async () => root.unmount());
    globalThis.fetch = old;
  }
});
test('search points are requested for the explicitly selected ride and expire when backgrounded; reads resume immediately', async (t) => {
  t.mock.timers.enable({ apis: ['setInterval'] });
  const old = globalThis.fetch;
  let root;
  const { AppState } = await import('react-native');
  try {
    const calls = api([
      { ...booking, status: 'requesting', driver: null, driver_id: null },
    ]);
    await act(async () => {
      root = Renderer.create(React.createElement(Live, props));
    });
    await settle();
    assert.equal(
      root.root.findByType('NativeCustomerMap').props.nearby.length,
      3,
    );
    const nearby = calls.find((c) => c.url.endsWith('/nearby'));
    assert.equal(nearby.options.method, 'POST');
    assert.deepEqual(JSON.parse(nearby.options.body), {
      bookingId: booking.id,
      service: 'premium',
    });
    await act(async () => {
      AppState.currentState = 'background';
      for (const f of globalThis.customerAppListeners) f('background');
    });
    assert.equal(root.root.findByType('NativeCustomerMap').props.active, false);
    assert.equal(
      root.root.findByType('NativeCustomerMap').props.nearby.length,
      0,
    );
    const count = calls.length;
    await act(async () => t.mock.timers.tick(30000));
    await settle();
    assert.equal(calls.length, count);
    await act(async () => {
      AppState.currentState = 'active';
      for (const f of globalThis.customerAppListeners) f('active');
    });
    await settle();
    assert.ok(calls.length > count);
  } finally {
    AppState.currentState = 'active';
    if (root) await act(async () => root.unmount());
    globalThis.fetch = old;
  }
});
test('actual API requests are aborted on unmount; old config cannot mount a map after leaving', async () => {
  const old = globalThis.fetch;
  let root;
  const signals = [];
  globalThis.fetch = async (url, options) => {
    signals.push(options.signal);
    return new Promise((resolve, reject) =>
      options.signal.addEventListener('abort', () =>
        reject(new Error('abort')),
      ),
    );
  };
  try {
    await act(async () => {
      root = Renderer.create(React.createElement(Live, props));
    });
    await settle();
    assert.equal(signals.length, 2);
    await act(async () => root.unmount());
    root = null;
    assert.ok(signals.every((s) => s.aborted));
  } finally {
    if (root) await act(async () => root.unmount());
    globalThis.fetch = old;
  }
});
test('401 clears driver, route and contact; map configuration error preserves confirmed ride details', async () => {
  const old = globalThis.fetch;
  let root;
  api();
  const original = globalThis.fetch;
  try {
    globalThis.fetch = async (url, options) =>
      url.endsWith('/config')
        ? Response.json(
            { error: 'Konfiguration nicht erreichbar' },
            { status: 503 },
          )
        : original(url, options);
    await act(async () => {
      root = Renderer.create(React.createElement(Live, props));
    });
    await settle();
    assert.match(
      JSON.stringify(root.toJSON()),
      /Test Chauffeur|Konfiguration nicht erreichbar/,
    );
    assert.equal(root.root.findAllByType('NativeCustomerMap').length, 0);
    globalThis.fetch = async () =>
      Response.json({ error: 'Bitte erneut anmelden.' }, { status: 401 });
    await act(async () =>
      root.update(React.createElement(Live, { ...props, active: false })),
    );
    await act(async () => root.update(React.createElement(Live, props)));
    await settle();
    assert.doesNotMatch(
      JSON.stringify(root.toJSON()),
      /Test Chauffeur|Audi A6/,
    );
    assert.equal(
      root.root.findAllByProps({ accessibilityLabel: 'Chauffeur anrufen' })
        .length,
      0,
    );
  } finally {
    if (root) await act(async () => root.unmount());
    globalThis.fetch = old;
  }
});
test('actual App opens exact selected trip in native live screen rather than embedded workspace', async () => {
  const old = globalThis.fetch;
  let root;
  try {
    api([
      booking,
      {
        ...booking,
        id: 'newer-trip',
        created_at: now + 1,
        route: {
          ...route,
          destination: { ...route.destination, label: 'Andere Fahrt' },
        },
      },
    ]);
    await act(async () => {
      root = Renderer.create(React.createElement(App));
    });
    await settle();
    const tab = root.root
      .findAllByType('Pressable')
      .find(
        (n) =>
          n.props.accessibilityRole === 'tab' &&
          n.findAllByType('Text').some((t) => t.props.children === 'Fahrten'),
      );
    await act(async () => tab.props.onPress());
    await settle();
    const trip = root.root
      .findAllByType('Pressable')
      .find(
        (n) => n.props.accessibilityLabel === 'Fahrer auf dem Weg · Flughafen',
      );
    await act(async () => trip.props.onPress());
    const modal = root.root.findAllByType('Modal').find((n) => n.props.visible);
    const live = modal
      .findAllByType('Pressable')
      .find((n) =>
        n
          .findAllByType('Text')
          .some((t) => t.props.children === 'Live-Karte öffnen'),
      );
    await act(async () => live.props.onPress());
    await settle();
    assert.equal(
      root.root.findByType('NativeCustomerMap').props.bookingId,
      booking.id,
    );
    assert.equal(
      root.root.findAllByProps({ accessibilityRole: 'tab' }).length,
      0,
    );
  } finally {
    if (root) await act(async () => root.unmount());
    globalThis.fetch = old;
  }
});
test('clock tick expires assigned GPS and contact while a new read is stuck, without inventing a position', async (t) => {
  t.mock.timers.enable({ apis: ['Date', 'setInterval'], now });
  const old = globalThis.fetch;
  let root;
  try {
    api();
    await act(async () => {
      root = Renderer.create(React.createElement(Live, props));
    });
    await settle();
    assert.ok(root.root.findByType('NativeCustomerMap').props.driver);
    globalThis.fetch = async (_url, options) =>
      new Promise((_resolve, reject) =>
        options.signal.addEventListener('abort', () =>
          reject(new Error('aborted')),
        ),
      );
    await act(async () => t.mock.timers.tick(21000));
    await settle();
    assert.equal(root.root.findByType('NativeCustomerMap').props.driver, null);
    assert.equal(
      root.root.findAllByProps({ accessibilityLabel: 'Chauffeur anrufen' })
        .length,
      0,
    );
    assert.match(JSON.stringify(root.toJSON()), /Test Chauffeur/);
  } finally {
    if (root) await act(async () => root.unmount());
    globalThis.fetch = old;
  }
});

test('actual native live screen opens fixed product-image board; only full swipe confirms and refreshes', async () => {
  const old = globalThis.fetch;
  let root;
  const own = {
    ...booking,
    payment_status: 'unpaid',
    refreshments: {
      version: 1,
      revision: 0,
      requested: {},
      delivered: { water: 2 },
      unavailable: {},
    },
  };
  store.clear();
  const calls = api([own]),
    read = globalThis.fetch,
    writes = [];
  globalThis.fetch = async (url, options) => {
    if (!url.endsWith('/refreshments')) return read(url, options);
    const body = JSON.parse(options.body);
    writes.push(body);
    assert.ok(
      store.has('luxore-board-pending-v1-' + account.id + '-' + own.id),
    );
    own.refreshments = {
      ...own.refreshments,
      revision: 1,
      requested: body.cart,
      lastRequest: { id: body.requestId, fingerprint: 'a'.repeat(64) },
    };
    own.updated_at = Date.now();
    return Response.json(own);
  };
  try {
    await act(async () => {
      root = Renderer.create(React.createElement(Live, props));
    });
    await settle();
    await act(async () =>
      root.root
        .findByProps({ accessibilityLabel: 'Bordkarte öffnen' })
        .props.onPress(),
    );
    await settle();
    assert.equal(
      root.root.findAllByType('Modal').find((n) => n.props.visible).props
        .presentationStyle,
      'fullScreen',
    );
    assert.equal(root.root.findAllByType('Image').length, 10);
    assert.match(JSON.stringify(root.toJSON()), /"2"," bereits ausgegeben"/);
    await act(async () =>
      root.root
        .findByProps({ accessibilityLabel: 'Cola hinzufügen' })
        .props.onPress(),
    );
    assert.equal(writes.length, 0);
    const { default: SwipeAction } =
      await import('../mobile/src/SwipeAction.tsx');
    const swipe = root.root.findByType(SwipeAction),
      track = swipe.findAllByType('View').find((n) => n.props.onLayout);
    await act(async () =>
      track.props.onLayout({ nativeEvent: { layout: { width: 360 } } }),
    );
    const thumb = swipe.findByType('AnimatedView');
    assert.equal(thumb.props.onPress, undefined);
    await act(async () =>
      thumb.props.onPanResponderRelease({}, { dx: 30, dy: 0 }),
    );
    await settle();
    assert.equal(writes.length, 0);
    await act(async () =>
      thumb.props.onPanResponderRelease({}, { dx: 310, dy: 0 }),
    );
    await settle();
    assert.equal(writes.length, 1);
    assert.deepEqual(writes[0].cart, { cola: 1 });
    assert.equal(writes[0].revision, 0);
    assert.match(JSON.stringify(root.toJSON()), /Bestellung bestätigt/);
    assert.ok(calls.filter((c) => c.url.endsWith('/bookings')).length >= 2);
    assert.equal(
      store.has('luxore-board-pending-v1-' + account.id + '-' + own.id),
      false,
    );
  } finally {
    if (root) await act(async () => root.unmount());
    globalThis.fetch = old;
  }
});

test('secure board store isolates owners/trips and stale completion cannot erase a newer pending request', async () => {
  const { boardStore } = await import('../mobile/src/board-store.ts');
  store.clear();
  const a = boardStore('owner-a', 'ride-a'),
    again = boardStore('owner-a', 'ride-a'),
    other = boardStore('owner-b', 'ride-a');
  const first = {
    id: 'ride-a',
    action: 'request',
    revision: 0,
    cart: { water: 1 },
    requestId: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
  };
  const second = {
    ...first,
    revision: 1,
    requestId: 'bbbbbbbb-bbbb-cccc-dddd-eeeeeeeeeeee',
  };
  await a.save(first);
  assert.equal(await other.load(), null);
  await assert.rejects(again.save(second));
  assert.deepEqual(await a.load(), first);
  await a.clear(first.requestId);
  await again.save(second);
  await a.clear(first.requestId);
  assert.deepEqual(await again.load(), second);
});
