import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
const virtual = (source) => ({
  url: 'data:text/javascript,' + encodeURIComponent(source),
  shortCircuit: true,
});
registerHooks({
  resolve(s, c, next) {
    if (s === 'expo-location')
      return virtual(
        `export const Accuracy={High:4,BestForNavigation:6};export const requestForegroundPermissionsAsync=async()=>({granted:true}),getBackgroundPermissionsAsync=async()=>({granted:globalThis.notificationRecovery.background}),requestBackgroundPermissionsAsync=async()=>({granted:false}),hasStartedLocationUpdatesAsync=async()=>globalThis.notificationRecovery.started,startLocationUpdatesAsync=async()=>{if(globalThis.notificationRecovery.gpsError)throw Error('GPS start failed');globalThis.notificationRecovery.started=true},stopLocationUpdatesAsync=async()=>{globalThis.notificationRecovery.started=false},getCurrentPositionAsync=()=>new Promise(()=>{});`,
      );
    if (s === 'expo-task-manager')
      return virtual(`export const defineTask=()=>{};`);
    if (s === 'expo-secure-store')
      return virtual(
        `export const getItemAsync=async k=>globalThis.notificationRecovery.store.get(k)||null,setItemAsync=async(k,v)=>globalThis.notificationRecovery.store.set(k,v),deleteItemAsync=async k=>globalThis.notificationRecovery.store.delete(k);`,
      );
    if (s === 'react-native')
      return virtual(
        `export const Alert={alert(){throw Error('Unexpected permission dialog')}};`,
      );
    if (s === 'expo-notifications')
      return virtual(
        `export const AndroidNotificationPriority={HIGH:2},AndroidImportance={HIGH:4,DEFAULT:3,NONE:0},AndroidNotificationVisibility={PRIVATE:0};export const setNotificationHandler=()=>{};async function op(name,value){const f=globalThis.notificationRecovery;f.calls.push(name);if(f.fail===name)throw Error('Synthetic notification '+name);return value}export const setNotificationChannelAsync=()=>op('channel'),getPermissionsAsync=()=>op('permissions',{granted:globalThis.notificationRecovery.granted,canAskAgain:true}),getNotificationChannelAsync=()=>op('readChannel',{importance:4,sound:'default'}),requestPermissionsAsync=()=>op('request',{granted:false}),dismissNotificationAsync=()=>op('dismiss'),scheduleNotificationAsync=()=>op('schedule');`,
      );
    return next(s, c);
  },
  load(url, c, next) {
    if (
      url.endsWith('/mobile/src/location-service.ts') &&
      process.env.TEST_ORIGINAL_LOCATION_SERVICE
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_LOCATION_SERVICE, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
const service = await import('../mobile/src/location-service.ts');
const { testAlert } = await import('../mobile/src/offer-alerts.ts');
const key = 'luxore-driver-location-session',
  positionKey = 'luxore-driver-background-position';
const c = () => ({
  sessionId: 'shift',
  nativeToken: 'a'.repeat(64),
  expiresAt: Date.now() + 3600000,
});
const originalFetch = globalThis.fetch;
function fixture() {
  const f = {
    store: new Map(),
    started: false,
    background: true,
    granted: true,
    fail: null,
    calls: [],
    writes: [],
  };
  globalThis.notificationRecovery = f;
  globalThis.fetch = async (_url, options) => {
    f.writes.push({
      token: options.headers.Authorization,
      body: JSON.parse(options.body),
    });
    return Response.json({ ok: true });
  };
  return f;
}
async function cleanup(f) {
  f.fail = null;
  f.gpsError = false;
  await service.stopLocation(false);
  globalThis.fetch = originalFetch;
}
for (const fail of ['channel', 'permissions', 'readChannel'])
  void test(
    'actual location status remains truthful when notification ' +
      fail +
      ' fails',
    async () => {
      const f = fixture();
      try {
        await service.startLocation(c());
        f.fail = fail;
        const status = await service.locationStatus();
        assert.equal(status.active, true);
        assert.equal(status.sessionId, 'shift');
        assert.deepEqual(status.alerts, {
          enabled: false,
          sound: false,
          unavailable: true,
        });
        assert.equal(f.started, true);
        assert.equal(f.writes.length, 0);
      } finally {
        await cleanup(f);
      }
    },
  );
void test('actual resume restores tracking and cache despite notification permission API failure without requesting permissions', async () => {
  const f = fixture();
  try {
    await service.startLocation(c());
    const p = { lat: 50.11, lng: 8.68, accuracy: 8, timestamp: Date.now() };
    f.store.set(
      positionKey,
      JSON.stringify({ sessionId: 'shift', position: p }),
    );
    f.started = false;
    f.calls = [];
    f.fail = 'permissions';
    const status = await service.resumeLocation();
    assert.equal(status.active, true);
    assert.equal(status.position.timestamp, p.timestamp);
    assert.equal(f.started, true);
    assert.equal(status.alerts.unavailable, true);
    assert.equal(f.calls.includes('request'), false);
    assert.equal(f.writes.length, 0);
  } finally {
    await cleanup(f);
  }
});
void test('optional notification permission request failure cannot reject an otherwise valid native shift start', async () => {
  const f = fixture();
  f.granted = false;
  f.fail = 'request';
  try {
    const status = await service.startLocation(c());
    assert.equal(status.active, true);
    assert.equal(status.alerts.enabled, false);
    assert.equal(status.alerts.sound, false);
    assert.equal(f.started, true);
    assert.ok(f.calls.includes('request'));
    assert.equal(f.writes.length, 0);
  } finally {
    await cleanup(f);
  }
});
void test('pause still deletes capability and cache, stops native GPS and notifies server when actual notification dismissal rejects', async () => {
  const f = fixture();
  try {
    await service.startLocation(c());
    f.store.set(positionKey, 'cached');
    f.fail = 'dismiss';
    await service.stopLocation();
    assert.equal(f.started, false);
    assert.equal(f.store.has(key), false);
    assert.equal(f.store.has(positionKey), false);
    assert.deepEqual(f.writes, [
      { token: 'Bearer ' + 'a'.repeat(64), body: { action: 'stop' } },
    ]);
  } finally {
    await cleanup(f);
  }
});
void test('notification failures never bypass actual background location permission on resume', async () => {
  const f = fixture();
  try {
    await service.startLocation(c());
    f.started = false;
    f.background = false;
    f.fail = 'channel';
    const status = await service.resumeLocation();
    assert.equal(status.active, false);
    assert.equal(f.started, false);
    assert.equal(status.alerts.unavailable, true);
  } finally {
    await cleanup(f);
  }
});
void test('real GPS startup error still rolls back credentials and reports failure despite notification errors', async () => {
  const f = fixture();
  f.gpsError = true;
  f.fail = 'channel';
  try {
    await assert.rejects(service.startLocation(c()), /GPS start failed/);
    assert.equal(f.store.has(key), false);
    assert.equal(f.started, false);
    assert.equal(f.writes.length, 1);
    assert.equal(f.writes[0].body.action, 'stop');
  } finally {
    await cleanup(f);
  }
});
void test('explicit test alarm still reports notification API failure without scheduling', async () => {
  const f = fixture();
  f.fail = 'channel';
  try {
    await assert.rejects(testAlert(), /Synthetic notification channel/);
    assert.equal(f.calls.includes('schedule'), false);
  } finally {
    await cleanup(f);
  }
});
