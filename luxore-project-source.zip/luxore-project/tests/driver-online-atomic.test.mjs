import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { createClient } from '@libsql/client';
import { readFileSync, readdirSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  resolve(s, c, next) {
    if (s === '#online-adapter')
      return {
        url: new URL('../db/sqlite.ts?online-adapter', import.meta.url).href,
        shortCircuit: true,
      };
    return next(s, c);
  },
  load(url, c, next) {
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `export class ApiError extends Error {constructor(status,message){super(message);this.status=status}};export const db=()=>globalThis.onlineTest.db,tokenHash=async token=>globalThis.onlineTest.hash(token),limit=async()=>{},settings=()=>({}),isAdmin=()=>false,identity=async()=>({userId:globalThis.onlineTest.user}),text=(v,max=160)=>{if(typeof v!=='string'||!v.trim()||v.length>max)throw new ApiError(400,'invalid');return v.trim()},body=r=>r.json(),json=(v,status=200)=>Response.json(v,{status}),handled=async fn=>{try{return await fn()}catch(e){return json({error:e.message},e.status||500)}};`,
      };
    if (
      url.endsWith('/app/api/mobility/driver/route.ts') &&
      process.env.TEST_ORIGINAL_DRIVER_ONLINE
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_DRIVER_ONLINE, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
const { sqliteDatabase } = await import('#online-adapter');
const { POST } = await import('../app/api/mobility/driver/route.ts');
const token = 'a'.repeat(64);
const send = (native = true, extra = {}) =>
  POST(
    new Request('https://test.invalid/api/mobility/driver', {
      method: 'POST',
      body: JSON.stringify({ action: 'online', native, ...extra }),
    }),
  );
async function fixture() {
  const client = createClient({ url: ':memory:' }),
    db = sqliteDatabase(client);
  for (const f of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((n) => n.endsWith('.sql'))
    .sort())
    await client.executeMultiple(
      readFileSync(new URL('../drizzle/' + f, import.meta.url), 'utf8'),
    );
  const now = Date.now();
  await client.execute(
    "INSERT INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES('driver','driver@example.test','Synthetic','000','driver','active',0,0)",
  );
  await client.executeMultiple(`INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES('fleet','Synthetic Fleet','owner',0);
 INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('driver','Synthetic Driver','000','fleet','driver',0);
 INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('car','fleet','Synthetic Audi','TEST','["premium"]','active',0);
 INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,services,approved,online,session_id,vehicle_id,lat,lng,accuracy,location_at) VALUES('driver','Synthetic Driver','000','Synthetic Audi','TEST','premium','["premium"]',1,1,'old','car',50.11,8.68,8,${now});
 INSERT INTO mobility_location_sessions(token_hash,driver_id,session_id,expires_at) VALUES('${token}','driver','old',${now + 3600000});
 INSERT INTO mobility_bookings(id,quote_id,owner_id,mode,service,status,route,price,payment_status,created_at,updated_at,dispatch_at) VALUES('booking','quote','customer','now','premium','requesting','{"pickup":{"lat":50.11,"lng":8.68}}',1000,'unpaid',${now},${now},${now});
 INSERT INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at) VALUES('offer','booking','driver','pending',${now + 25000},${now});`);
  globalThis.onlineTest = { db, user: 'driver', hash: async (token) => token };
  const snapshot = async () =>
    Object.fromEntries(
      await Promise.all(
        [
          'mobility_accounts',
          'mobility_drivers',
          'mobility_location_sessions',
          'mobility_offers',
          'mobility_bookings',
          'mobility_employees',
          'mobility_vehicles',
        ].map(async (table) => [
          table,
          (await db.prepare('SELECT * FROM ' + table + ' ORDER BY 1').all())
            .results,
        ]),
      ),
    );
  const race = (work) => {
    const prepare = db.prepare;
    let fired = false;
    db.prepare = (sql) => {
      const stmt = prepare(sql);
      if (sql !== 'SELECT * FROM mobility_drivers WHERE id=? AND approved=1')
        return stmt;
      const bind = stmt.bind.bind(stmt);
      stmt.bind = (...args) => {
        const bound = bind(...args),
          first = bound.first.bind(bound);
        bound.first = async (...params) => {
          const row = await first(...params);
          if (!fired) {
            fired = true;
            await work();
          }
          return row;
        };
        return bound;
      };
      return stmt;
    };
  };
  return { client, db, snapshot, race, close: () => client.close() };
}
void test('native start atomically rotates only its own credentials and preserves profile, rights, vehicles, offers and trips', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    const r = await send(true, { driverId: 'foreign' });
    assert.equal(r.status, 200);
    const reply = await r.json(),
      after = await f.snapshot();
    assert.match(reply.nativeToken, /^[a-f0-9]{64}$/);
    assert.ok(reply.expiresAt > Date.now());
    assert.equal(after.mobility_drivers[0].session_id, reply.sessionId);
    assert.deepEqual(after.mobility_location_sessions, [
      {
        token_hash: reply.nativeToken,
        driver_id: 'driver',
        session_id: reply.sessionId,
        expires_at: reply.expiresAt,
      },
    ]);
    assert.deepEqual(after.mobility_drivers[0], {
      ...before.mobility_drivers[0],
      online: 0,
      lat: null,
      lng: null,
      location_at: null,
      session_id: reply.sessionId,
    });
    for (const table of [
      'mobility_accounts',
      'mobility_offers',
      'mobility_bookings',
      'mobility_employees',
      'mobility_vehicles',
    ])
      assert.deepEqual(after[table], before[table]);
  } finally {
    f.close();
  }
});
for (const [name, sql, status] of [
  [
    'blocked account',
    "UPDATE mobility_accounts SET status='blocked' WHERE id='driver'",
    403,
  ],
  [
    'pending account deletion',
    "UPDATE mobility_accounts SET status='deletion_pending' WHERE id='driver'",
    403,
  ],
  [
    'withdrawn approval',
    "UPDATE mobility_drivers SET approved=0 WHERE id='driver'",
    403,
  ],
  [
    'replacement shift before GPS',
    "UPDATE mobility_drivers SET session_id='new',online=0 WHERE id='driver'",
    409,
  ],
  [
    'completed pause',
    "UPDATE mobility_drivers SET session_id=NULL,online=0 WHERE id='driver';DELETE FROM mobility_location_sessions",
    409,
  ],
  [
    'archived vehicle',
    "UPDATE mobility_vehicles SET status='archived' WHERE id='car'",
    409,
  ],
  [
    'removed fleet membership',
    "DELETE FROM mobility_employees WHERE user_id='driver'",
    409,
  ],
])
  void test(
    'start rechecks ' + name + ' after its initial authenticated profile read',
    async () => {
      for (const native of [true, false]) {
        const f = await fixture();
        try {
          let expected;
          f.race(async () => {
            await f.client.executeMultiple(sql);
            expected = await f.snapshot();
          });
          const r = await send(native);
          assert.equal(r.status, status);
          assert.deepEqual(await f.snapshot(), expected);
        } finally {
          f.close();
        }
      }
    },
  );
for (const initialSession of ['old', null])
  void test(
    'overlapping actual starts cannot replace the newer committed ' +
      (initialSession ? 'renewal' : 'first shift'),
    async () => {
      const f = await fixture();
      let release;
      try {
        if (initialSession === null)
          await f.client.executeMultiple(
            'UPDATE mobility_drivers SET session_id=NULL,online=0;DELETE FROM mobility_location_sessions',
          );
        let entered;
        const started = new Promise((r) => {
            entered = r;
          }),
          gate = new Promise((r) => {
            release = r;
          });
        let first = true;
        globalThis.onlineTest.hash = async (value) => {
          if (first) {
            first = false;
            entered();
            await gate;
          }
          return value;
        };
        const slow = send();
        await started;
        const current = await send();
        assert.equal(current.status, 200);
        const reply = await current.json(),
          expected = await f.snapshot();
        release();
        assert.equal((await slow).status, 409);
        assert.deepEqual(await f.snapshot(), expected);
        assert.equal(
          expected.mobility_location_sessions[0].token_hash,
          reply.nativeToken,
        );
        assert.equal(expected.mobility_drivers[0].session_id, reply.sessionId);
      } finally {
        release?.();
        f.close();
      }
    },
  );
for (const [name, sql] of [
  [
    'driver update',
    "CREATE TRIGGER fail_start BEFORE UPDATE ON mobility_drivers BEGIN SELECT RAISE(ABORT,'synthetic update failure'); END",
  ],
  [
    'credential deletion',
    "CREATE TRIGGER fail_start BEFORE DELETE ON mobility_location_sessions BEGIN SELECT RAISE(ABORT,'synthetic delete failure'); END",
  ],
  [
    'credential insertion',
    "CREATE TRIGGER fail_start BEFORE INSERT ON mobility_location_sessions BEGIN SELECT RAISE(ABORT,'synthetic insert failure'); END",
  ],
])
  void test(
    name +
      ' failure rolls back the entire shift and permits a later explicit start',
    async () => {
      const f = await fixture();
      try {
        await f.client.executeMultiple(sql);
        const before = await f.snapshot();
        assert.equal((await send()).status, 500);
        assert.deepEqual(await f.snapshot(), before);
        await f.client.execute('DROP TRIGGER fail_start');
        assert.equal((await send()).status, 200);
      } finally {
        f.close();
      }
    },
  );
void test('credential hash failure never mutates an existing shift', async () => {
  const f = await fixture();
  try {
    globalThis.onlineTest.hash = async () => {
      throw new Error('synthetic hash failure');
    };
    const before = await f.snapshot();
    assert.equal((await send()).status, 500);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
void test('explicit later renewal remains possible with legacy identity and existing assigned ride', async () => {
  const f = await fixture();
  try {
    await f.client.executeMultiple(
      "DELETE FROM mobility_accounts;UPDATE mobility_bookings SET status='riding',driver_id='driver' WHERE id='booking'",
    );
    assert.equal((await send()).status, 200);
    const first = await f.snapshot();
    const r = await send();
    assert.equal(r.status, 200);
    const reply = await r.json(),
      after = await f.snapshot();
    assert.notEqual(reply.sessionId, first.mobility_drivers[0].session_id);
    assert.deepEqual(after.mobility_bookings, first.mobility_bookings);
    assert.equal(after.mobility_location_sessions.length, 1);
    assert.equal(
      after.mobility_location_sessions[0].session_id,
      reply.sessionId,
    );
  } finally {
    f.close();
  }
});
void test('web start issues no native token and preserves another driver capability', async () => {
  const f = await fixture();
  try {
    await f.client.executeMultiple(
      `INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,session_id) VALUES('other','Other','000','','','premium',1,1,'old');INSERT INTO mobility_location_sessions(token_hash,driver_id,session_id,expires_at) VALUES('other-token','other','old',${Date.now() + 3600000})`,
    );
    const before = await f.snapshot(),
      r = await send(false);
    assert.equal(r.status, 200);
    const reply = await r.json(),
      after = await f.snapshot();
    assert.deepEqual(Object.keys(reply), ['sessionId']);
    assert.deepEqual(
      after.mobility_location_sessions,
      before.mobility_location_sessions.filter((c) => c.driver_id === 'other'),
    );
    assert.deepEqual(
      after.mobility_drivers.find((d) => d.id === 'other'),
      before.mobility_drivers.find((d) => d.id === 'other'),
    );
  } finally {
    f.close();
  }
});
