import test from 'node:test';
import assert from 'node:assert/strict';
import {
  readNavigationSteps,
  type NavigationStep,
} from '../lib/mobility/navigation-steps.ts';
import { routingParameters } from '../lib/mobility/routing-policy.ts';
import {
  compileNavigation,
  advanceNavigation,
  navigationDistance,
  navigationFixUsable,
} from '../app/mobility/navigation-progress.ts';
import { drivingCameraInsets } from '../app/mobility/map-camera.ts';
import type { RouteData } from '../lib/mobility/domain';
const now = 100000;
const steps: NavigationStep[] = [
  {
    type: 'depart',
    instruction: 'Richtung Osten fahren',
    street: 'A',
    distanceMeters: 72,
    durationSeconds: 20,
    coordinates: [
      [8, 50],
      [8.001, 50],
    ],
  },
  {
    type: 'turn',
    modifier: 'left',
    instruction: 'Links abbiegen',
    street: 'B',
    distanceMeters: 111,
    durationSeconds: 40,
    coordinates: [
      [8.001, 50],
      [8.001, 50.001],
    ],
  },
  {
    type: 'turn',
    modifier: 'right',
    instruction: 'Rechts abbiegen',
    street: 'C',
    distanceMeters: 72,
    durationSeconds: 30,
    coordinates: [
      [8.001, 50.001],
      [8.002, 50.001],
    ],
  },
  {
    type: 'arrive',
    instruction: 'Ziel erreicht',
    street: '',
    distanceMeters: 0,
    durationSeconds: 0,
    coordinates: [
      [8.002, 50.001],
      [8.002, 50.001],
    ],
  },
];
const route: RouteData = {
  pickup: { id: 'p', label: 'P', lat: 50, lng: 8 },
  destination: { id: 'd', label: 'D', lat: 50.001, lng: 8.002 },
  geometry: {
    type: 'LineString',
    coordinates: [
      [8, 50],
      [8.001, 50],
      [8.001, 50.001],
      [8.002, 50.001],
    ],
  },
  calculatedAt: now,
  distanceMeters: 255,
  durationSeconds: 90,
  navigation: steps,
};
const point = (lng: number, lat: number, t = now, heading = 90) => ({
  lng,
  lat,
  timestamp: t,
  accuracy: 5,
  speed: 8,
  heading,
});
function providerSteps() {
  return steps.map((s) => ({
    distance: s.distanceMeters,
    duration: s.durationSeconds,
    name: s.street,
    geometry: { type: 'LineString', coordinates: s.coordinates },
    maneuver: {
      type: s.type,
      instruction: s.instruction,
      modifier: s.modifier,
      location: s.coordinates[0],
    },
  }));
}
void test('guidance alone requests German turn steps and separate roundabout exits', () => {
  assert.equal(routingParameters(null, null, true).steps, 'true');
  assert.equal(routingParameters(null, null, true).roundabout_exits, 'true');
  assert.equal(routingParameters(null).steps, 'false');
  assert.equal(routingParameters(null, null, true).language, 'de');
});
void test('parser retains all maneuvers, rejects incomplete, malformed or oversized instructions', () => {
  assert.equal(readNavigationSteps([{ steps: providerSteps() }])!.length, 4);
  assert.equal(
    readNavigationSteps([{ steps: providerSteps().slice(1) }]),
    undefined,
  );
  assert.equal(
    readNavigationSteps([{ steps: providerSteps().slice(0, -1) }]),
    undefined,
  );
  const malformed = providerSteps();
  malformed[1].geometry.coordinates = [
    [NaN, 50],
    [8, 50],
  ];
  assert.equal(readNavigationSteps([{ steps: malformed }]), undefined);
  const invalid = providerSteps();
  invalid[1].maneuver.instruction = 'x'.repeat(601);
  assert.equal(readNavigationSteps([{ steps: invalid }]), undefined);
});
void test('next turn distance follows route, decreases with GPS, and remaining time is weighted per step', () => {
  const track = compileNavigation(route)!;
  const first = advanceNavigation(track, point(8, 50), now, null)!;
  assert.equal(first.next.modifier, 'left');
  assert.ok(first.distanceToTurn > 70 && first.distanceToTurn < 73);
  assert.equal(first.remainingSeconds, 90);
  const second = advanceNavigation(
    track,
    point(8.0005, 50, now + 5000),
    now + 5000,
    first,
  )!;
  assert.ok(second.distanceToTurn > 35 && second.distanceToTurn < 37);
  assert.ok(Math.abs(second.remainingSeconds - 80) < 0.05);
  assert.ok(Math.abs(second.remainingMeters - 219) < 0.05);
});
void test('turn remains current at the junction, advances once passed, and does not bounce backwards', () => {
  const track = compileNavigation(route)!;
  const first = advanceNavigation(track, point(8.0009, 50), now, null)!;
  const junction = advanceNavigation(
    track,
    point(8.001, 50, now + 1000),
    now + 1000,
    first,
  )!;
  assert.equal(junction.next.modifier, 'left');
  assert.equal(navigationDistance(junction.distanceToTurn), 'Jetzt');
  const after = advanceNavigation(
    track,
    point(8.001, 50.0001, now + 3000, 0),
    now + 3000,
    junction,
  )!;
  assert.equal(after.next.modifier, 'right');
  const jitter = advanceNavigation(
    track,
    point(8.001, 50.00005, now + 4000, 0),
    now + 4000,
    after,
  )!;
  assert.equal(jitter.next.modifier, 'right');
  assert.ok(jitter.along >= after.along);
});
void test('GPS loss, poor accuracy, wrong road and expired route suppress maneuvers', () => {
  const track = compileNavigation(route)!;
  assert.equal(
    advanceNavigation(track, { ...point(8, 50), accuracy: 50 }, now, null),
    null,
  );
  assert.equal(advanceNavigation(track, point(8, 50), now + 11000, null), null);
  assert.equal(advanceNavigation(track, point(8, 50.01), now, null), null);
  assert.equal(
    advanceNavigation(track, point(8, 50, now + 91000), now + 91000, null),
    null,
  );
  assert.equal(navigationFixUsable(null, now), false);
});
void test('implausible jump cannot skip maneuvers and an old fix cannot reverse progress', () => {
  const track = compileNavigation(route)!;
  const first = advanceNavigation(track, point(8, 50), now, null)!;
  assert.equal(
    advanceNavigation(
      track,
      point(8.002, 50.001, now + 1000),
      now + 1000,
      first,
    ),
    null,
  );
  assert.equal(
    advanceNavigation(track, point(8.002, 50.001, now - 1), now, first),
    first,
  );
});
void test('overlapping distant route legs are treated as ambiguous without a reliable anchor', () => {
  const loop = {
    ...route,
    navigation: [
      steps[0],
      {
        ...steps[1],
        coordinates: [
          [8.001, 50],
          [8.001, 50.001],
          [8, 50.001],
          [8, 50],
          [8.001, 50],
        ] as [number, number][],
      },
      steps[3],
    ],
  };
  assert.equal(
    advanceNavigation(compileNavigation(loop)!, point(8.0005, 50), now, null),
    null,
  );
});
void test('rerouting resets progress, arrival stays a proximity signal with no booking transition', () => {
  const track = compileNavigation(route)!;
  const old = advanceNavigation(track, point(8.0015, 50.001), now, null)!;
  const nextTrack = compileNavigation({ ...route, calculatedAt: now + 1000 })!;
  const restarted = advanceNavigation(
    nextTrack,
    point(8, 50, now + 1000),
    now + 1000,
    old,
  )!;
  assert.equal(restarted.nextIndex, 1);
  const end = advanceNavigation(
    nextTrack,
    point(8.00195, 50.001, now + 2000),
    now + 2000,
    null,
  )!;
  assert.equal(end.next.type, 'arrive');
  assert.equal(end.nearDestination, true);
  assert.ok(end.remainingMeters < 5);
  assert.equal('bookingStatus' in end, false);
});
void test('stationary GPS does not count down route duration; each fresh estimate uses actual progress', () => {
  const track = compileNavigation(route)!;
  const p = point(8.0005, 50);
  const first = advanceNavigation(track, p, now, null)!;
  const second = advanceNavigation(
    track,
    { ...p, timestamp: now + 5000, speed: 0 },
    now + 5000,
    first,
  )!;
  assert.equal(first.remainingSeconds, second.remainingSeconds);
});
void test('camera reserves visible space below the maneuver panel on compact and tall screens', () => {
  for (const height of [550, 700, 900]) {
    const padding = drivingCameraInsets(height, 80, 230).padding;
    const anchor = (height + padding.top - padding.bottom) / 2;
    assert.ok(padding.top >= 230);
    assert.ok(anchor > 230 && anchor < height - 80);
  }
});

void test('GPS reacquisition after a longer blackout can relocalize earlier on the route without a stale progress lock', () => {
  const track = compileNavigation(route)!;
  const before = advanceNavigation(track, point(8.0015, 50.001), now, null)!;
  const reacquired = advanceNavigation(
    track,
    point(8.0004, 50, now + 16000),
    now + 16000,
    before,
  )!;
  assert.equal(reacquired.nextIndex, 1);
  assert.ok(reacquired.along < before.along);
  assert.equal(reacquired.next.modifier, 'left');
});
