import test from 'node:test';
import assert from 'node:assert/strict';
import {
  routeDeviation,
  observeRouteRecovery,
  confirmedRecovery,
} from '../app/mobility/route-recovery.ts';
import { guidanceDue } from '../app/mobility/guidance-policy.ts';
import type { RouteData } from '../lib/mobility/domain';
const route: RouteData = {
  pickup: { id: 'a', label: 'A', lat: 50, lng: 8 },
  destination: { id: 'b', label: 'B', lat: 50, lng: 8.004 },
  distanceMeters: 285,
  durationSeconds: 50,
  geometry: {
    type: 'LineString',
    coordinates: [
      [8, 50],
      [8.004, 50],
    ],
  },
  calculatedAt: 100000,
};
const fix = (lng: number, timestamp: number, lat = 50) => ({
  lat,
  lng,
  timestamp,
  accuracy: 6,
  speed: 6,
  heading: 270,
});
void test('reversing on the same street becomes a reroute after two moving fixes, without waiting 45 seconds', () => {
  const first = observeRouteRecovery(null, route, fix(8.002, 114000), 114000)!;
  assert.equal(first.reason, 'wrong-direction');
  assert.equal(first.confirmed, false);
  const second = observeRouteRecovery(
    first,
    route,
    fix(8.0017, 117000),
    117000,
  )!;
  assert.equal(confirmedRecovery(second, route, 117000), 'wrong-direction');
  assert.equal(guidanceDue(second.latest, route, 100000, 117000, second), true);
  assert.equal(
    guidanceDue(second.latest, route, 105000, 117000, second),
    false,
  );
});
void test('one lateral GPS spike does not request an early reroute; repeated deviation does', () => {
  const first = observeRouteRecovery(
    null,
    route,
    fix(8.002, 114000, 50.001),
    114000,
  )!;
  assert.equal(first.reason, 'off-route');
  assert.equal(guidanceDue(first.latest, route, 100000, 114000, first), false);
  const recovered = observeRouteRecovery(
    first,
    route,
    { ...fix(8.002, 117000), heading: 90 },
    117000,
  );
  assert.equal(recovered, null);
  const second = observeRouteRecovery(
    first,
    route,
    fix(8.002, 117000, 50.001),
    117000,
  )!;
  assert.equal(guidanceDue(second.latest, route, 100000, 117000, second), true);
});
void test('cached polls, stale samples and inaccurate GPS cannot confirm a deviation', () => {
  const first = observeRouteRecovery(
    null,
    route,
    fix(8.002, 114000, 50.001),
    114000,
  )!;
  const duplicate = observeRouteRecovery(first, route, first.latest, 117000)!;
  assert.equal(duplicate, first);
  assert.equal(duplicate.confirmed, false);
  assert.equal(observeRouteRecovery(first, route, first.latest, 125000), null);
  assert.equal(
    observeRouteRecovery(
      first,
      route,
      { ...fix(8.002, 117000, 50.001), accuracy: 60 },
      117000,
    ),
    null,
  );
});
void test('phone rotation or a reversing bearing without actual movement does not reroute', () => {
  assert.equal(
    routeDeviation(route, { ...fix(8.002, 114000), speed: 0 }),
    null,
  );
  assert.equal(
    routeDeviation(route, { ...fix(8.002, 114000), heading: undefined }),
    null,
  );
  const first = observeRouteRecovery(null, route, fix(8.002, 114000), 114000)!;
  const second = observeRouteRecovery(
    first,
    route,
    fix(8.00201, 117000),
    117000,
  )!;
  assert.equal(second.confirmed, false);
});
void test('nearby legal bends and parking near destination do not trigger direction recovery', () => {
  const corner = {
    ...route,
    geometry: {
      type: 'LineString' as const,
      coordinates: [
        [8, 50],
        [8.002, 50],
        [8.002, 50.001],
      ],
    },
  };
  assert.equal(
    routeDeviation(corner, { ...fix(8.002, 114000, 50.00002), heading: 90 }),
    null,
  );
  assert.equal(routeDeviation(route, fix(8.00395, 114000)), null);
});
void test('new route and GPS blackout reset confirmation; old phase evidence cannot apply', () => {
  const first = observeRouteRecovery(null, route, fix(8.002, 114000), 114000)!;
  const second = observeRouteRecovery(
    first,
    route,
    fix(8.0017, 117000),
    117000,
  )!;
  const changed = { ...route, calculatedAt: 118000 };
  assert.equal(confirmedRecovery(second, changed, 118000), null);
  assert.equal(
    observeRouteRecovery(second, changed, fix(8.0016, 119000), 119000)!
      .confirmed,
    false,
  );
  assert.equal(
    observeRouteRecovery(second, route, fix(8.0015, 130000), 130000)!.confirmed,
    false,
  );
});
void test('confirmed detours retain the request rate limit during provider failures', () => {
  let evidence = observeRouteRecovery(
    null,
    route,
    fix(8.002, 114000, 50.001),
    114000,
  )!;
  evidence = observeRouteRecovery(
    evidence,
    route,
    fix(8.002, 117000, 50.001),
    117000,
  )!;
  let last = 100000,
    requests = 0;
  for (let t = 117000; t < 160000; t += 3000) {
    const point = fix(8.002, t, 50.001);
    evidence = observeRouteRecovery(evidence, route, point, t)!;
    if (guidanceDue(point, route, last, t, evidence)) {
      last = t;
      requests++;
    }
  }
  assert.equal(requests, 3);
});
