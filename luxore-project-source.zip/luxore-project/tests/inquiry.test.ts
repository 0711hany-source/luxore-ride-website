import test from 'node:test';
import assert from 'node:assert/strict';
import { berlinMinute, prepareInquiry, type Inquiry } from '../lib/inquiry.ts';
const now = new Date('2026-09-21T12:00:00Z');
const valid: Inquiry = {
  pickup: 'Alte Oper, Frankfurt',
  destination: 'Flughafen Terminal 1',
  date: '2026-09-22',
  time: '10:30',
  guests: 3,
  service: 'first',
  name: 'Testgast',
  phone: '',
  notes: '',
};
test('Inquiry cannot exceed vehicle capacity or request past and invalid dates', () => {
  assert.throws(
    () => prepareInquiry({ ...valid, guests: 4 }, now),
    /maximal 3/,
  );
  assert.throws(
    () => prepareInquiry({ ...valid, date: '2026-09-21', time: '13:59' }, now),
    /zukünftigen/,
  );
  assert.throws(
    () => prepareInquiry({ ...valid, date: '2027-02-30' }, now),
    /gültiges/,
  );
  assert.throws(
    () =>
      prepareInquiry({ ...valid, destination: ' alte oper, frankfurt ' }, now),
    /unterschiedlich/,
  );
  assert.ok(prepareInquiry({ ...valid, service: 'van', guests: 6 }, now));
});
test('Frankfurt timezone handles summer, winter and date boundaries independently of device timezone', () => {
  assert.equal(berlinMinute(now), '2026-09-21T14:00');
  assert.equal(
    berlinMinute(new Date('2026-12-01T23:30:00Z')),
    '2026-12-02T00:30',
  );
});
test('Email parameters preserve unicode and cannot inject additional recipient headers', () => {
  const result = prepareInquiry(
    { ...valid, notes: 'Gepäck &bcc=other@example.com\nDanke!' },
    now,
  );
  const url = new URL(result.mailto);
  assert.equal(url.pathname, 'booking@luxoreride.de');
  assert.deepEqual([...url.searchParams.keys()], ['subject', 'body']);
  assert.equal(url.searchParams.get('body'), result.body);
  assert.match(result.body, /noch keine bestätigte Buchung/);
});
