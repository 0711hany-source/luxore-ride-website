"""Location capability tests against local HTTP server; isolated test drivers only."""
import os, json, urllib.request, urllib.error, http.cookiejar, sqlite3, pathlib, time
base=os.environ.get('TEST_BASE_URL','http://localhost:3000')
def client():return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def call(c,path,b=None,token=None):
 headers={'Content-Type':'application/json'}
 if token is None:headers['Origin']=base
 else:headers['Authorization']='Bearer '+token
 req=urllib.request.Request(base+'/api/mobility/'+path,data=json.dumps(b).encode() if b is not None else None,headers=headers)
 try:
  with c.open(req) as r:return r.status,json.loads(r.read())
 except urllib.error.HTTPError as e:return e.code,json.loads(e.read())
connection=None
for file in pathlib.Path('.wrangler/state/v3/d1').rglob('*.sqlite'):
 c=sqlite3.connect(file)
 if c.execute("SELECT name FROM sqlite_master WHERE name='mobility_drivers'").fetchone():connection=c;break
 c.close()
assert connection
# Only the local fixture database is migrated here.
connection.execute('CREATE TABLE IF NOT EXISTS mobility_location_sessions(token_hash TEXT PRIMARY KEY NOT NULL,driver_id TEXT NOT NULL,session_id TEXT NOT NULL,expires_at INTEGER NOT NULL)');connection.commit()
driver,other,native,admin=client(),client(),client(),client();users=[]
for c in (driver,other):
 assert call(c,'session',{})[0]==201
 users.append(call(c,'config')[1]['userId'])
admin.open(base+'/signin-with-chatgpt?return_to=%2F').close()
def fix(**fields):return dict({'lat':50.115,'lng':8.67,'accuracy':10,'timestamp':int(time.time()*1000)},**fields)
fleet_id=None
try:
 assert call(native,'driver',{'action':'online','native':True})[0]==401
 assert call(driver,'driver',{'action':'register','name':'TEST Background Driver','phone':'+49000000','vehicle':'Test Car','plate':'TEST BG','services':['premium']})[0]==200
 assert call(driver,'driver',{'action':'online','native':True})[0]==403
 fleet_id=call(admin,'fleets',{'action':'create','name':'TEST Location fleet','ownerId':users[0]})[1]['id']
 car_id=call(admin,'vehicles',{'action':'create','fleetId':fleet_id,'model':'Test car','plate':'BG '+users[0][-8:],'services':['premium']})[1]['id']
 assert call(admin,'operations',{'driverId':users[0],'approved':True})[0]==200
 assert call(driver,'vehicles',{'action':'select','vehicleId':car_id})[0]==200
 code,session=call(driver,'driver',{'action':'online','native':True});assert code==200,session
 t=session['nativeToken'];assert len(t)==64 and t not in str(call(driver,'driver')[1])
 initial=call(driver,'driver')[1]['driver'];assert initial['online']==0 and initial['lat'] is None and initial['location_at'] is None
 assert call(driver,'driver',{'action':'heartbeat','sessionId':session['sessionId'],'lat':50.11,'lng':8.68,'accuracy':250})[0]==400
 # The open app may send real GPS for a native session before its background callback arrives.
 assert call(driver,'driver',dict(fix(timestamp=0),action='heartbeat',sessionId=session['sessionId']))[0]==400
 assert call(driver,'driver',dict(fix(),action='heartbeat',sessionId=session['sessionId']))[0]==200
 assert call(driver,'driver')[1]['driver']['online']==1
 assert call(native,'location',fix(),token='0'*64)[0]==401
 code,location=call(native,'location',fix(),token=t);assert code==200 and location['offer'] is None
 bid='alert-test-'+users[0];now=int(time.time()*1000)
 connection.execute("INSERT INTO mobility_bookings(id,quote_id,owner_id,service,price,route,mode,status,created_at,updated_at,dispatch_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(bid,bid,users[1],'premium',2500,json.dumps({'pickup':{'lat':50.115,'lng':8.67}}),'now','requesting',now,now,now))
 connection.execute('INSERT INTO mobility_offers VALUES(?,?,?,?,?,?)',(bid,bid,users[0],'pending',now+25000,now));connection.commit()
 code,location=call(native,'location',fix(),token=t);assert code==200 and set(location['offer'])=={'id','expiresAt'} and location['offer']['id']==bid,location
 connection.execute("UPDATE mobility_bookings SET status='cancelled' WHERE id=?",(bid,));connection.commit()
 assert call(native,'location',fix(),token=t)[1]['offer'] is None
 connection.execute('DELETE FROM mobility_offers WHERE id=?',(bid,));connection.execute('DELETE FROM mobility_bookings WHERE id=?',(bid,));connection.commit()
 assert call(native,'driver',{'action':'offline','sessionId':session['sessionId']},token=t)[0]==403
 assert call(native,'location',fix(timestamp=0),token=t)[0]==400
 assert call(native,'location',fix(accuracy=101),token=t)[0]==400
 assert call(other,'driver',{'action':'online','native':True})[0]==403
 assert call(driver,'driver',{'action':'offline','sessionId':session['sessionId']})[0]==200
 assert call(native,'location',fix(),token=t)[0]==401
 assert call(driver,'driver')[1]['driver']['online']==0
 # Foreground fallback remains usable without sign-in and invalidates a partial native start.
 code,partial=call(driver,'driver',{'action':'online','native':True});assert code==200
 assert call(native,'location',{'action':'stop'},token=partial['nativeToken'])[0]==200
 code,foreground=call(driver,'driver',{'action':'online'});assert code==200
 assert call(driver,'driver',{'action':'heartbeat','sessionId':foreground['sessionId'],'lat':50.115,'lng':8.67,'accuracy':10})[0]==200
 assert call(driver,'driver')[1]['driver']['online']==1
 assert call(native,'location',fix(),token=partial['nativeToken'])[0]==401
 assert call(driver,'driver',{'action':'offline','sessionId':foreground['sessionId']})[0]==200
 for mutation in ['expire','rotate','unapprove','stop']:
  code,session=call(driver,'driver',{'action':'online','native':True});assert code==200
  t=session['nativeToken']
  if mutation=='expire':connection.execute('UPDATE mobility_location_sessions SET expires_at=0 WHERE driver_id=?',(users[0],));connection.commit()
  elif mutation=='rotate':assert call(driver,'driver',{'action':'online','native':True})[0]==200
  elif mutation=='unapprove':
   assert call(admin,'operations',{'driverId':users[0],'approved':False})[0]==409
   assert call(driver,'driver',{'action':'offline','sessionId':session['sessionId']})[0]==200
   assert call(admin,'operations',{'driverId':users[0],'approved':False})[0]==200
  else:assert call(native,'location',{'action':'stop'},token=t)[0]==200
  assert call(native,'location',fix(),token=t)[0]==401,mutation
  if mutation=='unapprove':
   assert call(driver,'driver',{'action':'online','native':True})[0]==403
   assert call(admin,'operations',{'driverId':users[0],'approved':True})[0]==200
 print('PASS: native location requires approved authenticated minting; bearer has location-only scope; bad/stale fixes rejected; pause, rotation, expiry and revoked approval block further fixes; native stop ends shift; offer hints expose only opaque IDs/expiry and disappear on cancellation.')
finally:
 for u in users:
  connection.execute('DELETE FROM mobility_offers WHERE driver_id=?',(u,));connection.execute('DELETE FROM mobility_bookings WHERE owner_id=?',(u,))
  connection.execute('DELETE FROM mobility_location_sessions WHERE driver_id=?',(u,));connection.execute('DELETE FROM mobility_drivers WHERE id=?',(u,));connection.execute('DELETE FROM mobility_sessions WHERE user_id=?',(u,));connection.execute('DELETE FROM mobility_limits WHERE key LIKE ?',('%:'+u+':%',))
 if fleet_id:
  connection.execute('DELETE FROM mobility_employees WHERE fleet_id=?',(fleet_id,));connection.execute('DELETE FROM mobility_vehicles WHERE fleet_id=?',(fleet_id,));connection.execute('DELETE FROM mobility_fleets WHERE id=?',(fleet_id,))
 connection.commit();connection.close()
