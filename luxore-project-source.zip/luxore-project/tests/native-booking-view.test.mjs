import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
const store = new Map([['luxore-account-v1', 'a'.repeat(64)]]);
globalThis.nativeViewStore = store;
globalThis.customerAppListeners = new Set();
globalThis.require = () => 1; // Metro resolves static PNG assets in real APKs.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    'expo-location',
    `export const Accuracy={High:4}; export const requestForegroundPermissionsAsync=async()=>({status:'denied'}),getCurrentPositionAsync=async()=>{throw new Error('GPS not enabled in view tests')};`,
  ],
  [
    'react-native',
    `
    export const View='View', Text='Text', Pressable='Pressable', ScrollView='ScrollView', Modal='Modal', Image='Image', TextInput='TextInput', KeyboardAvoidingView='KeyboardAvoidingView', ActivityIndicator='ActivityIndicator';
    export const Platform={OS:'android'}, StyleSheet={create:v=>v}, Keyboard={dismiss(){}}, Share={async share(){}}, Linking={async openURL(){},async openSettings(){}}, Alert={alert(){}};
    export const AppState={currentState:'active',addEventListener(event,listener){globalThis.customerAppListeners.add(listener);return {remove(){globalThis.customerAppListeners.delete(listener)}}}}, BackHandler={addEventListener(){return {remove(){}}}};
    export const useWindowDimensions=()=>({width:390,height:844});
    export const PanResponder={create:handlers=>({panHandlers:handlers})};
    export const Animated={Value:class {constructor(v){this.value=v}setValue(v){this.value=v}},View:'AnimatedView',spring:(v,o)=>({start:()=>v.setValue(o.toValue)})};
  `,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaProvider='SafeAreaProvider', SafeAreaView='SafeAreaView';`,
  ],
  ['expo-status-bar', `export const StatusBar='StatusBar';`],
  [
    'expo-constants',
    `export default {expoConfig:{extra:{variant:'customer'}}};`,
  ],
  [
    'expo-secure-store',
    `export const getItemAsync=async k=>globalThis.nativeViewStore.get(k)||null,setItemAsync=async(k,v)=>{globalThis.nativeViewStore.set(k,v)},deleteItemAsync=async k=>{globalThis.nativeViewStore.delete(k)};`,
  ],
  [
    'expo-crypto',
    `export const randomUUID=()=> 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';`,
  ],
  [
    'expo-notifications',
    `export const getLastNotificationResponse=()=>null,clearLastNotificationResponse=()=>{},addNotificationResponseReceivedListener=()=>({remove(){}});`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',ArrowRight='ArrowRight', CalendarDays='CalendarDays', CarFront='CarFront', Check='Check', ChevronRight='ChevronRight', CircleHelp='CircleHelp', Home='Home', LogOut='LogOut', Mail='Mail', MapPinned='MapPinned', MapPin='MapPin', Clock3='Clock3', Settings='Settings', ShieldCheck='ShieldCheck', UserRound='UserRound', Users='Users',ChevronDown='ChevronDown',LocateFixed='LocateFixed',Navigation='Navigation',Phone='Phone',RefreshCw='RefreshCw',X='X',Plus='Plus',Minus='Minus',Search='Search';`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    let source = mocked.get(specifier);
    if (specifier.endsWith('/RideWorkspace') || specifier === './RideWorkspace')
      source = `export default function ForbiddenEmbeddedDriver(){throw new Error('Driver mounted a WebView');}`;
    if (specifier === './use-driver-gps')
      source = `export function useDriverGps(){return {position:{lat:50.11,lng:8.68,accuracy:8,timestamp:Date.now()},sessionId:null,error:'',foreground:true,restart:async()=>{},sync:async()=>({active:false})}}`;
    if (specifier === './location-service')
      source = `export const resumeLocation=async()=>({active:false}),stopLocation=async()=>{},foregroundPermission=async()=>{},startLocation=async()=>({active:true});`;
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: App } = await import('../mobile/src/App.tsx');
const { default: SwipeAction } = await import('../mobile/src/SwipeAction.tsx');
const { default: BookingScreen } =
  await import('../mobile/src/CustomerBookingScreen.tsx');
const account = {
  id: 'customer-test',
  name: 'Test Kunde',
  email: 'test@example.test',
  phone: '+4912345678',
  kind: 'customer',
};
const p = {
    id: 'confirmed-pickup',
    label: 'Alte Oper',
    lat: 50.115,
    lng: 8.671,
  },
  d = {
    id: 'confirmed-destination',
    label: 'Frankfurt Flughafen',
    lat: 50.05,
    lng: 8.57,
  };
const quote = {
  id: 'server-quote',
  pickup: p,
  destination: d,
  distanceMeters: 15000,
  durationSeconds: 1000,
  geometry: {
    type: 'LineString',
    coordinates: [
      [p.lng, p.lat],
      [d.lng, d.lat],
    ],
  },
  calculatedAt: Date.now(),
  expiresAt: Date.now() + 300000,
  prices: { premium: 3750, first: 5250, van: 4500 },
  mode: 'now',
  scheduledAt: null,
};
const booking = {
  id: 'server-booking',
  quote_id: quote.id,
  service: 'premium',
  route: quote,
  status: 'requesting',
  price: 3750,
};
async function settle() {
  for (let i = 0; i < 6; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
const button = (r, label) =>
  r.root
    .findAllByType('Pressable')
    .find(
      (n) =>
        n.props.accessibilityLabel === label ||
        n.findAllByType('Text').some((t) => t.props.children === label),
    );
async function place(r, key, value) {
  await act(async () =>
    button(
      r,
      key === 'pickup' ? 'Abholort auswählen' : 'Ziel auswählen',
    ).props.onPress(),
  );
  await settle();
  const label = key === 'pickup' ? 'Abholort' : 'Ziel';
  await act(async () =>
    r.root
      .findAllByType('TextInput')
      .find((n) => n.props.accessibilityLabel === label)
      .props.onChangeText(value),
  );
  await act(async () =>
    r.root
      .findAllByType('TextInput')
      .find((n) => n.props.accessibilityLabel === label)
      .props.onSubmitEditing(),
  );
  await settle();
  await act(async () => button(r, value).props.onPress());
  await settle();
}
async function swipe(r, label) {
  const swipe = r.root
    .findAllByType(SwipeAction)
    .find((n) => n.props.label === label);
  assert.ok(swipe);
  const track = swipe.findAllByType('View').find((n) => n.props.onLayout);
  await act(async () =>
    track.props.onLayout({ nativeEvent: { layout: { width: 360 } } }),
  );
  const thumb = swipe.findByType('AnimatedView');
  assert.equal(thumb.props.onPress, undefined);
  await act(async () =>
    thumb.props.onPanResponderRelease({}, { dx: 310, dy: 0 }),
  );
  await settle();
}
function fixture() {
  const writes = [],
    quotes = [];
  return {
    writes,
    quotes,
    fetch: async (url, options) => {
      assert.match(url, /^https:\/\/luxoreride.de\/api\/mobility\//);
      assert.equal(options.headers.Authorization, 'Bearer ' + 'a'.repeat(64));
      if (url.endsWith('/account'))
        return Response.json({
          account,
          registrationReady: true,
          isAdmin: false,
        });
      const body = options.body ? JSON.parse(options.body) : null;
      if (url.endsWith('/places')) {
        if (body.kind === 'search')
          return Response.json({
            results: [
              body.query === 'Alte Oper'
                ? { ...p, id: 'suggestion' }
                : { ...d, id: 'suggestion' },
            ],
          });
        return Response.json({ results: [body.lat === p.lat ? p : d] });
      }
      if (url.endsWith('/quote')) {
        quotes.push(body);
        return Response.json({
          ...quote,
          mode: body.mode,
          scheduledAt: body.scheduledAt,
          expiresAt: Date.now() + 300000,
        });
      }
      if (url.endsWith('/bookings') && !body)
        return Response.json({ bookings: [] });
      if (url.endsWith('/bookings')) {
        writes.push(body);
        return Response.json({
          ...booking,
          service: body.service,
          status:
            quotes.at(-1)?.mode === 'reservation' ? 'reserved' : 'requesting',
          price: quote.prices[body.service],
        });
      }
      throw new Error('Unexpected request');
    },
  };
}
void test('actual customer home opens native booking, selects addresses, quotes and books only through full swipe', async () => {
  const old = globalThis.fetch,
    f = fixture();
  let r;
  store.clear();
  store.set('luxore-account-v1', 'a'.repeat(64));
  globalThis.fetch = f.fetch;
  try {
    await act(async () => {
      r = Renderer.create(React.createElement(App));
    });
    await settle();
    await act(async () => button(r, 'Wohin möchtest du?').props.onPress());
    await settle();
    await place(r, 'pickup', 'Alte Oper');
    await place(r, 'destination', 'Frankfurt Flughafen');
    await act(async () => button(r, 'Route & Preise ansehen').props.onPress());
    await settle();
    assert.deepEqual(f.quotes[0], {
      pickupId: p.id,
      destinationId: d.id,
      mode: 'now',
      scheduledAt: null,
    });
    await act(async () => button(r, 'First Class').props.onPress());
    await settle();
    await act(async () =>
      button(r, 'Lieber Ruhe · conversation').props.onPress(),
    );
    await act(async () => button(r, 'Wasser still hinzufügen').props.onPress());
    assert.equal(f.writes.length, 0);
    await swipe(r, 'Fahrt anfragen');
    assert.equal(f.writes.length, 1);
    assert.equal(f.writes[0].quoteId, quote.id);
    assert.equal(f.writes[0].service, 'first');
    assert.equal(f.writes[0].preferences.conversation, 'quiet');
    assert.deepEqual(f.writes[0].refreshments, { water: 1 });
    assert.match(JSON.stringify(r.toJSON()), /Deine Anfrage ist angekommen/);
    assert.match(JSON.stringify(r.toJSON()), /Fahrer wird gesucht/);
    assert.equal(store.has('luxore-booking-pending-v1-' + account.id), false);
  } finally {
    if (r) await act(async () => r.unmount());
    globalThis.fetch = old;
  }
});
void test('native reservation parses local date/time and stores exact instant, with honest pending driver confirmation', async () => {
  const old = globalThis.fetch,
    f = fixture();
  let r;
  store.clear();
  globalThis.fetch = f.fetch;
  try {
    await act(async () => {
      r = Renderer.create(
        React.createElement(BookingScreen, {
          token: 'a'.repeat(64),
          profile: account,
          active: true,
          planned: true,
          onTrips() {},
          onLive() {},
        }),
      );
    });
    await settle();
    const future = new Date();
    future.setDate(future.getDate() + 2);
    future.setHours(14, 30, 0, 0);
    const day = [future.getDate(), future.getMonth() + 1, future.getFullYear()]
      .map((n, i) => (i < 2 ? String(n).padStart(2, '0') : n))
      .join('.');
    await act(async () =>
      r.root
        .findAllByType('TextInput')
        .find((n) => n.props.accessibilityLabel === 'Abholdatum')
        .props.onChangeText(day),
    );
    await act(async () =>
      r.root
        .findAllByType('TextInput')
        .find((n) => n.props.accessibilityLabel === 'Abholzeit')
        .props.onChangeText('14:30'),
    );
    await place(r, 'pickup', 'Alte Oper');
    await place(r, 'destination', 'Frankfurt Flughafen');
    await act(async () => button(r, 'Route & Preise ansehen').props.onPress());
    await settle();
    assert.equal(f.quotes[0].scheduledAt, future.getTime());
    assert.equal(f.quotes[0].mode, 'reservation');
    await swipe(r, 'Reservierung anfragen');
    assert.match(JSON.stringify(r.toJSON()), /Erst mit Fahrerzusage bestätigt/);
  } finally {
    if (r) await act(async () => r.unmount());
    globalThis.fetch = old;
  }
});
void test('pending booking survives native screen replacement and retry uses exact persisted body despite profile changes', async () => {
  const old = globalThis.fetch;
  let r,
    calls = 0;
  store.clear();
  const pending = {
    body: {
      quoteId: quote.id,
      service: 'van',
      riderName: 'Ursprünglicher Gast',
      riderPhone: '+4912345678',
      preferences: { temperature: 'cool', conversation: 'quiet', music: 'off' },
      refreshments: { water: 2 },
    },
    destination: d.label,
  };
  store.set('luxore-booking-pending-v1-' + account.id, JSON.stringify(pending));
  globalThis.fetch = async (url, options) => {
    calls++;
    assert.deepEqual(JSON.parse(options.body), pending.body);
    return Response.json({ ...booking, service: 'van', price: 4500 });
  };
  try {
    await act(async () => {
      r = Renderer.create(
        React.createElement(BookingScreen, {
          token: 'a'.repeat(64),
          profile: account,
          active: true,
          onTrips() {},
          onLive() {},
        }),
      );
    });
    await settle();
    assert.equal(calls, 0);
    assert.equal(button(r, 'Abholort auswählen'), undefined);
    assert.match(JSON.stringify(r.toJSON()), /Anfrage noch nicht bestätigt/);
    await swipe(r, 'Dieselbe Anfrage bestätigen');
    assert.equal(calls, 1);
    assert.match(JSON.stringify(r.toJSON()), /Deine Anfrage ist angekommen/);
  } finally {
    if (r) await act(async () => r.unmount());
    globalThis.fetch = old;
  }
});
void test('native picker works after StrictMode effect replay and denied GPS leaves manual booking usable', async () => {
  const old = globalThis.fetch,
    f = fixture();
  let r;
  store.clear();
  globalThis.fetch = f.fetch;
  try {
    await act(async () => {
      r = Renderer.create(
        React.createElement(
          React.StrictMode,
          null,
          React.createElement(BookingScreen, {
            token: 'a'.repeat(64),
            profile: account,
            active: true,
            onTrips() {},
            onLive() {},
          }),
        ),
      );
    });
    await settle();
    await act(async () =>
      button(r, 'Meinen Standort als Abholort verwenden').props.onPress(),
    );
    await settle();
    assert.match(JSON.stringify(r.toJSON()), /Standortfreigabe fehlt/);
    await place(r, 'pickup', 'Alte Oper');
    assert.match(JSON.stringify(r.toJSON()), /Alte Oper/);
    assert.equal(f.quotes.length, 0);
    assert.equal(f.writes.length, 0);
  } finally {
    if (r) await act(async () => r.unmount());
    globalThis.fetch = old;
  }
});
