import test from 'node:test';
import assert from 'node:assert/strict';
import {
  OperationsController,
  type OperationsData,
  type MembershipChange,
} from '../mobile/src/operations.ts';
const snapshot = (): OperationsData =>
  ({
    userId: 'owner',
    canManage: false,
    fleets: [
      {
        id: 'f',
        name: 'A',
        owner_id: 'owner',
        deputy_id: 'deputy',
        created_at: 0,
      },
      {
        id: 'other',
        name: 'B',
        owner_id: 'other-owner',
        deputy_id: null,
        created_at: 0,
      },
    ],
    employees: [
      {
        user_id: 'owner',
        name: 'Owner',
        fleet_id: 'f',
        role: 'staff',
        can_remove: 1,
      },
      {
        user_id: 'deputy',
        name: 'Deputy',
        fleet_id: 'f',
        role: 'staff',
        can_remove: 1,
      },
      {
        user_id: 'staff',
        name: 'Team',
        fleet_id: 'f',
        role: 'staff',
        can_remove: 1,
      },
      {
        user_id: 'foreign',
        name: 'Other',
        fleet_id: 'other',
        role: 'driver',
        can_remove: 1,
      },
      { user_id: 'unassigned', name: 'New', fleet_id: null, role: 'driver' },
    ],
    drivers: [
      {
        id: 'foreign',
        name: 'Other',
        fleet_id: 'other',
        online: 0,
        session_id: null,
        approved: 1,
      },
    ],
    bookings: [],
    revenue: [],
  }) as unknown as OperationsData;
const remove: MembershipChange = {
  action: 'remove_member',
  userId: 'staff',
  fleetId: 'f',
};
const assign: MembershipChange = {
  action: 'assign',
  userId: 'foreign',
  fleetId: 'f',
  role: 'driver',
};
const defer = <T>() => {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((r) => (resolve = r));
  return { promise, resolve };
};
const error = (status: number) =>
  Object.assign(new Error('Synthetic'), { status });
function create(
  load: () => Promise<OperationsData>,
  write: (body: MembershipChange) => Promise<{ ok: boolean }>,
) {
  return new OperationsController(
    load,
    async () => ({ ok: true }),
    async () => ({ ok: true }),
    write,
  );
}
void test('team removal uses concrete owner/deputy scope; assignment is existing operator only', async () => {
  let data = snapshot();
  const c = create(
    async () => data,
    async () => ({ ok: true }),
  );
  c.setActive(true);
  await c.refresh();
  assert.equal(c.canChangeMember(remove), true);
  assert.equal(c.canChangeMember(assign), false);
  assert.equal(c.canChangeMember({ ...remove, userId: 'foreign' }), false);
  assert.equal(c.canChangeMember({ ...remove, userId: 'owner' }), false);
  assert.equal(c.canChangeMember({ ...remove, userId: 'deputy' }), false);
  data = { ...data, userId: 'deputy' };
  await c.refresh();
  assert.equal(c.canChangeMember(remove), true);
  data = { ...data, userId: 'ordinary' };
  await c.refresh();
  assert.equal(c.canChangeMember(remove), false);
  data = { ...data, canManage: true };
  await c.refresh();
  assert.equal(c.canChangeMember(assign), true);
  assert.equal(c.canChangeMember({ ...assign, role: 'staff' }), false);
  assert.equal(c.canChangeMember({ ...assign, userId: 'unassigned' }), true);
  assert.equal(c.canChangeMember({ ...assign, fleetId: 'missing' }), false);
  assert.equal(c.canChangeMember({ ...assign, userId: 'missing' }), false);
  c.dispose();
});
void test('team writes require current foreground and preserve deployment/shift/payment guards', async () => {
  let data = { ...snapshot(), canManage: true };
  const c = create(
    async () => data,
    async () => ({ ok: true }),
  );
  c.setActive(true);
  await c.refresh();
  assert.equal(c.canChangeMember(assign, Date.now() + 30001), false);
  c.setActive(false);
  assert.equal(c.canChangeMember(assign), false);
  c.setActive(true);
  await c.refresh();
  data = {
    ...data,
    employees: data.employees!.map((e) =>
      e.user_id === 'staff' ? { ...e, can_remove: 0 } : e,
    ),
  };
  await c.refresh();
  assert.equal(c.canChangeMember(remove), false);
  data.drivers[0].session_id = 'gps';
  await c.refresh();
  assert.equal(c.canChangeMember(assign), false);
  data.drivers[0].session_id = null;
  data.drivers[0].online = 1;
  await c.refresh();
  assert.equal(c.canChangeMember(assign), false);
  data.drivers[0].online = 0;
  data.bookings = [
    { driver_id: 'foreign', status: 'completed', payment_status: 'unpaid' },
  ] as OperationsData['bookings'];
  await c.refresh();
  assert.equal(c.canChangeMember(assign), false);
  c.dispose();
});
void test('actual server confirmation survives background; no optimistic membership or concurrent deputy/approval', async () => {
  const data = snapshot(),
    pending = defer<{ ok: boolean }>();
  let writes = 0;
  const c = create(
    async () => data,
    async () => {
      writes++;
      return pending.promise;
    },
  );
  c.setActive(true);
  await c.refresh();
  const task = c.changeMember(remove);
  assert.equal(
    c.getSnapshot().data?.employees?.find((e) => e.user_id === 'staff')
      ?.fleet_id,
    'f',
  );
  assert.equal(c.canSetDeputy({ fleetId: 'f', deputyId: 'staff' }), false);
  assert.equal(c.canChange({ driverId: 'foreign', approved: true }), false);
  await c.changeMember(remove);
  assert.equal(writes, 1);
  c.setActive(false);
  pending.resolve({ ok: true });
  await task;
  assert.equal(c.getSnapshot().memberChanging, null);
  assert.equal(c.getSnapshot().updatedAt, null);
  assert.match(c.getSnapshot().notice, /entfernt/);
  assert.deepEqual(c.getSnapshot().data?.drivers, data.drivers);
  c.dispose();
});
void test('unknown removal holds exact action, explicit retry only; fresh scoped absence confirms without POST', async () => {
  let data = snapshot(),
    writes = 0;
  const c = create(
    async () => data,
    async () => {
      writes++;
      throw new Error('Lost');
    },
  );
  c.setActive(true);
  await c.refresh();
  await c.changeMember(remove);
  assert.deepEqual(c.getSnapshot().memberUncertain, remove);
  assert.equal(c.canChangeMember(remove), true);
  assert.equal(c.canChangeMember({ ...remove, userId: 'owner' }), false);
  assert.equal(c.canChange({ driverId: 'foreign', approved: true }), false);
  assert.equal(c.canSetDeputy({ fleetId: 'f', deputyId: 'staff' }), false);
  c.setActive(false);
  c.setActive(true);
  await c.refresh();
  assert.equal(writes, 1);
  data = {
    ...data,
    employees: data.employees!.filter((e) => e.user_id !== 'staff'),
  };
  await c.refresh();
  assert.equal(c.getSnapshot().memberUncertain, null);
  assert.match(c.getSnapshot().notice, /Serverstand/);
  assert.equal(writes, 1);
  c.dispose();
});
void test('unknown assignment locks destination/role and confirms exact membership from fresh server', async () => {
  let data = { ...snapshot(), canManage: true },
    writes = 0;
  const c = create(
    async () => data,
    async () => {
      writes++;
      throw error(503);
    },
  );
  c.setActive(true);
  await c.refresh();
  await c.changeMember(assign);
  assert.equal(c.canChangeMember(assign), true);
  assert.equal(c.canChangeMember({ ...assign, fleetId: 'other' }), false);
  assert.equal(c.canChangeMember({ ...assign, role: 'staff' }), false);
  data = {
    ...data,
    employees: data.employees!.map((e) =>
      e.user_id === 'foreign' ? { ...e, fleet_id: 'f' } : e,
    ),
  };
  await c.refresh();
  assert.equal(c.getSnapshot().memberUncertain, null);
  assert.equal(c.canChangeMember(assign), false);
  assert.equal(writes, 1);
  c.dispose();
});
void test('confirmed membership with failed reload is success but old driver/employee lists cannot write', async () => {
  let fails = false;
  const c = create(
    async () => {
      if (fails) throw error(503);
      return { ...snapshot(), canManage: true };
    },
    async () => {
      fails = true;
      return { ok: true };
    },
  );
  c.setActive(true);
  await c.refresh();
  await c.changeMember(assign);
  assert.match(c.getSnapshot().notice, /zugeordnet/);
  assert.equal(c.getSnapshot().memberUncertain, null);
  assert.equal(c.getSnapshot().updatedAt, null);
  assert.equal(c.canChangeMember(assign), false);
  assert.equal(c.canChange({ driverId: 'foreign', approved: true }), false);
  c.dispose();
});
void test('known conflict is not success; incomplete confirmation uncertain; revoked authority clears access', async () => {
  let code = 409;
  const c = create(
    async () => {
      if (code === 403) throw error(403);
      return snapshot();
    },
    async () => {
      if (code) throw error(code);
      return { ok: false };
    },
  );
  c.setActive(true);
  await c.refresh();
  await c.changeMember(remove);
  assert.equal(c.getSnapshot().memberUncertain, null);
  assert.equal(c.getSnapshot().notice, '');
  code = 0;
  await c.changeMember(remove);
  assert.deepEqual(c.getSnapshot().memberUncertain, remove);
  code = 403;
  await c.changeMember(remove);
  assert.equal(c.getSnapshot().data, null);
  assert.equal(c.getSnapshot().memberUncertain, null);
  c.dispose();
});
void test('other mutations block team changes; disposal cannot publish a delayed cross-account write', async () => {
  const data = { ...snapshot(), canManage: true },
    pending = defer<{ ok: boolean }>();
  const c = new OperationsController(
    async () => data,
    async () => {
      throw new Error('Lost');
    },
    async () => ({ ok: true }),
    () => pending.promise,
  );
  c.setActive(true);
  await c.refresh();
  await c.approve({ driverId: 'foreign', approved: false });
  assert.equal(c.canChangeMember(remove), false);
  c.dispose();
  const next = create(
    async () => data,
    () => pending.promise,
  );
  next.setActive(true);
  await next.refresh();
  const task = next.changeMember(remove);
  next.dispose();
  pending.resolve({ ok: true });
  await task;
  assert.equal(next.getSnapshot().notice, '');
  assert.equal(
    next.getSnapshot().data?.employees?.find((e) => e.user_id === 'staff')
      ?.fleet_id,
    'f',
  );
});
