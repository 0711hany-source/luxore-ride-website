import test from 'node:test';
import assert from 'node:assert/strict';
import {
  OperationsController,
  approvalBlocked,
  type OperationsData,
} from '../mobile/src/operations.ts';
const driver = {
  id: 'd1',
  fleet_id: 'f1',
  name: 'Test',
  approved: 0,
  online: 0,
  session_id: null,
};
const snapshot = (): OperationsData =>
  ({
    drivers: [{ ...driver }],
    bookings: [],
    fleets: [{ id: 'f1', name: 'Testflotte' }],
    revenue: [],
  }) as unknown as OperationsData;
const defer = <T>() => {
  let resolve!: (v: T) => void, reject!: (e: Error) => void;
  const promise = new Promise<T>((a, b) => {
    resolve = a;
    reject = b;
  });
  return { promise, resolve, reject };
};
const settle = async () => {
  for (let i = 0; i < 6; i++) await new Promise((r) => setImmediate(r));
};
const body = { driverId: 'd1', approved: true };
void test('approval dispatch is disabled before initial read, for missing profiles, stale data and background', async () => {
  let writes = 0;
  const c = new OperationsController(
    async () => snapshot(),
    async () => {
      writes++;
      return { ok: true };
    },
  );
  await c.approve(body);
  assert.equal(writes, 0);
  c.setActive(true);
  await settle();
  assert.equal(c.canChange(body), true);
  assert.equal(c.canChange({ driverId: 'foreign', approved: true }), false);
  assert.equal(c.canChange(body, c.getSnapshot().updatedAt! + 30000), false);
  c.setActive(false);
  await c.approve(body);
  assert.equal(writes, 0);
  c.dispose();
});
void test('background read abort and old finally never clear the replacement foreground request', async () => {
  const reads = [defer<OperationsData>(), defer<OperationsData>()];
  let i = 0;
  const signals: AbortSignal[] = [];
  const c = new OperationsController(
    (signal) => {
      signals.push(signal);
      return reads[i++].promise;
    },
    async () => ({ ok: true }),
  );
  c.setActive(true);
  await settle();
  c.setActive(false);
  assert.equal(signals[0].aborted, true);
  c.setActive(true);
  await settle();
  reads[0].resolve(snapshot());
  await settle();
  assert.equal(c.getSnapshot().refreshing, true);
  assert.equal(c.getSnapshot().data, null);
  void c.refresh();
  assert.equal(i, 2);
  const next = snapshot();
  next.drivers[0].name = 'New';
  reads[1].resolve(next);
  await settle();
  assert.equal(c.getSnapshot().data?.drivers[0].name, 'New');
  c.dispose();
});
void test('network read errors retain known data but block writes; revoked authority clears data', async () => {
  let error: Error | undefined;
  const c = new OperationsController(
    async () => {
      if (error) throw error;
      return snapshot();
    },
    async () => ({ ok: true }),
  );
  c.setActive(true);
  await settle();
  error = new Error('offline');
  await c.refresh();
  assert.ok(c.getSnapshot().data);
  assert.equal(c.canChange(body), false);
  error = Object.assign(new Error('denied'), { status: 403 });
  await c.refresh();
  assert.equal(c.getSnapshot().data, null);
  assert.equal(c.getSnapshot().updatedAt, null);
  c.dispose();
});
void test('write survives background and blocks duplicates, stale reads and optimistic approval', async () => {
  const write = defer<{ ok: boolean }>();
  let calls = 0,
    approved = 0;
  const c = new OperationsController(
    async () => {
      const data = snapshot();
      data.drivers[0].approved = approved;
      return data;
    },
    async (input) => {
      assert.deepEqual(input, body);
      calls++;
      return write.promise;
    },
  );
  c.setActive(true);
  await settle();
  const change = c.approve(body);
  assert.equal(c.getSnapshot().data?.drivers[0].approved, 0);
  await c.approve(body);
  assert.equal(calls, 1);
  c.setActive(false);
  approved = 1;
  write.resolve({ ok: true });
  await change;
  assert.equal(c.getSnapshot().data?.drivers[0].approved, 1);
  assert.equal(c.getSnapshot().notice, 'Fahrer freigegeben.');
  c.setActive(true);
  await settle();
  assert.equal(c.getSnapshot().data?.drivers[0].approved, 1);
  c.dispose();
});
void test('lost answer allows only identical retry until a fresh read confirms intended state', async () => {
  let approved = 0,
    fail = true,
    writes = 0;
  const c = new OperationsController(
    async () => {
      const data = snapshot();
      data.drivers[0].approved = approved;
      return data;
    },
    async () => {
      writes++;
      if (fail) throw new Error('timeout');
      approved = 1;
      return { ok: true };
    },
  );
  c.setActive(true);
  await settle();
  await c.approve(body);
  assert.deepEqual(c.getSnapshot().uncertain, body);
  assert.equal(c.canChange({ driverId: 'd1', approved: false }), false);
  assert.equal(c.canChange(body), true);
  fail = false;
  await c.approve(body);
  assert.equal(writes, 2);
  assert.equal(c.getSnapshot().uncertain, null);
  assert.equal(c.getSnapshot().data?.drivers[0].approved, 1);
  c.dispose();
});
void test('read reconciliation resolves lost successful response without another write', async () => {
  let approved = 0,
    writes = 0;
  const c = new OperationsController(
    async () => {
      const data = snapshot();
      data.drivers[0].approved = approved;
      return data;
    },
    async () => {
      writes++;
      approved = 1;
      throw new Error('lost');
    },
  );
  c.setActive(true);
  await settle();
  await c.approve(body);
  assert.equal(writes, 1);
  assert.equal(c.getSnapshot().uncertain, null);
  assert.equal(c.getSnapshot().actionError, '');
  assert.match(c.getSnapshot().notice, /Serverstand/);
  c.dispose();
});
void test('known rejection and invalid write response never claim success', async () => {
  let code = 409;
  const c = new OperationsController(
    async () => snapshot(),
    async () => {
      if (code) throw Object.assign(new Error('locked'), { status: code });
      return { ok: false };
    },
  );
  c.setActive(true);
  await settle();
  await c.approve(body);
  assert.equal(c.getSnapshot().uncertain, null);
  assert.equal(c.getSnapshot().notice, '');
  assert.equal(c.getSnapshot().data?.drivers[0].approved, 0);
  code = 0;
  await c.approve(body);
  assert.deepEqual(c.getSnapshot().uncertain, body);
  assert.equal(c.getSnapshot().notice, '');
  c.dispose();
});
void test('revocation is blocked during shift, active ride and uncollected completion', () => {
  for (const d of [
    { ...driver, online: 1 },
    { ...driver, session_id: 'session' },
  ])
    assert.equal(approvalBlocked(d as never, []), true);
  for (const status of ['accepted', 'arrived', 'riding', 'completed'])
    assert.equal(
      approvalBlocked(
        driver as never,
        [{ driver_id: 'd1', status, payment_status: 'unpaid' }] as never,
      ),
      true,
    );
  assert.equal(
    approvalBlocked(
      driver as never,
      [
        { driver_id: 'd1', status: 'completed', payment_status: 'paid' },
      ] as never,
    ),
    false,
  );
  assert.equal(
    approvalBlocked(
      driver as never,
      [{ driver_id: 'another', status: 'riding' }] as never,
    ),
    false,
  );
});
void test('disposed account never publishes old write results or rereads', async () => {
  const pending = defer<{ ok: boolean }>();
  let reads = 0;
  const c = new OperationsController(
    async () => {
      reads++;
      return snapshot();
    },
    () => pending.promise,
  );
  c.setActive(true);
  await settle();
  const change = c.approve(body);
  c.dispose();
  pending.resolve({ ok: true });
  await change;
  assert.equal(reads, 1);
  assert.equal(c.getSnapshot().data?.drivers[0].approved, 0);
});
