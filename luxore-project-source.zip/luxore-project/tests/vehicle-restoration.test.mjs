import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  load(url, context, next) {
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `
        export class ApiError extends Error {constructor(status,message){super(message);this.status=status;}}
        export const db=()=>globalThis.vehicleTest.db;
        export const identity=async()=>({userId:globalThis.vehicleTest.user});
        export const isAdmin=()=>false;
        export const limit=async()=>{};
        export const body=request=>request.json();
        export const json=(value,status=200)=>Response.json(value,{status});
        export const text=value=>{if(typeof value!=='string'||!value.trim())throw new ApiError(400,'empty');return value.trim();};
        export const handled=async work=>{try{return await work();}catch(e){return json({error:e.message},e.status||500);}};
      `,
      };
    return next(url, context);
  },
});
const { POST, GET } = await import('../app/api/mobility/vehicles/route.ts');
function fixture() {
  const sqlite = new DatabaseSync(':memory:');
  const directory = new URL('../drizzle/', import.meta.url);
  for (const file of readdirSync(directory)
    .filter((f) => f.endsWith('.sql'))
    .sort())
    sqlite.exec(readFileSync(new URL(file, directory), 'utf8'));
  const db = {
    prepare(sql) {
      let values = [];
      return {
        bind(...args) {
          values = args;
          return this;
        },
        async first() {
          return sqlite.prepare(sql).get(...values) || null;
        },
        async all() {
          return { results: sqlite.prepare(sql).all(...values) };
        },
        async run() {
          const result = sqlite.prepare(sql).run(...values);
          return { meta: { changes: Number(result.changes) } };
        },
      };
    },
    async batch(statements) {
      sqlite.exec('BEGIN');
      try {
        const results = [];
        for (const statement of statements) results.push(await statement.run());
        sqlite.exec('COMMIT');
        return results;
      } catch (e) {
        sqlite.exec('ROLLBACK');
        throw e;
      }
    },
  };
  globalThis.vehicleTest = { db, user: 'owner-a' };
  for (const id of ['a', 'b']) {
    sqlite
      .prepare(
        'INSERT INTO mobility_fleets(id,name,created_at,owner_id) VALUES(?,?,0,?)',
      )
      .run('fleet-' + id, 'TEST ' + id, 'owner-' + id);
    sqlite
      .prepare(
        'INSERT INTO mobility_employees(user_id,name,phone,fleet_id,created_at) VALUES(?,?,?,?,0)',
      )
      .run('owner-' + id, 'TEST', '000000', 'fleet-' + id);
  }
  sqlite
    .prepare(
      "INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at,archived_reason,archived_at) VALUES('car-a','fleet-a','Audi A6','TEST A 1','[\"premium\"]','archived',0,'TEST',1)",
    )
    .run();
  sqlite
    .prepare(
      "INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('car-b','fleet-b','Mercedes','TEST B 2','[\"van\"]','active',0)",
    )
    .run();
  const read = () =>
    sqlite.prepare("SELECT * FROM mobility_vehicles WHERE id='car-a'").get();
  return { sqlite, read, close: () => sqlite.close() };
}
const expected = {
  model: 'Audi A6',
  plate: 'TEST A 1',
  services: '["premium"]',
};
const draft = {
  action: 'restore',
  id: 'car-a',
  model: 'Audi A8',
  plate: 'test a 8',
  services: ['premium', 'first'],
  expected,
};
const request = (data) =>
  new Request('https://test.invalid/api/mobility/vehicles', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

test('native restore saves edited model, normalized plate and multiple classes; retry is idempotent', async () => {
  const f = fixture();
  try {
    const response = await POST(request(draft));
    assert.equal(response.status, 200);
    const saved = f.read();
    assert.equal(saved.model, 'Audi A8');
    assert.equal(saved.plate, 'TEST A 8');
    assert.equal(saved.services, '["premium","first"]');
    assert.equal(saved.status, 'active');
    assert.equal(saved.archived_at, null);
    assert.equal(saved.archived_reason, null);
    const retry = await POST(request(draft));
    assert.equal(retry.status, 200);
    assert.equal((await retry.json()).replayed, true);
    assert.deepEqual(f.read(), saved);
  } finally {
    f.close();
  }
});

test('bare web restoration retains original details and can recover a lost success response', async () => {
  const f = fixture();
  try {
    const before = f.read();
    assert.equal(
      (await POST(request({ action: 'restore', id: 'car-a' }))).status,
      200,
    );
    assert.equal(f.read().model, before.model);
    assert.equal(f.read().plate, before.plate);
    assert.equal(f.read().services, before.services);
    const retry = await POST(request({ action: 'restore', id: 'car-a' }));
    assert.equal(retry.status, 200);
    assert.equal((await retry.json()).replayed, true);
  } finally {
    f.close();
  }
});

test('stale restoration draft cannot overwrite intervening archived changes', async () => {
  const f = fixture();
  try {
    f.sqlite
      .prepare("UPDATE mobility_vehicles SET model='Audi A7' WHERE id='car-a'")
      .run();
    const before = f.read(),
      response = await POST(request(draft));
    assert.equal(response.status, 409);
    assert.match((await response.json()).error, /zwischenzeitlich/);
    assert.deepEqual(f.read(), before);
  } finally {
    f.close();
  }
});

test('partial drafts, invalid classes and drafts without prior values stay archived with visible errors', async () => {
  for (const data of [
    { action: 'restore', id: 'car-a', model: 'Audi A8' },
    { ...draft, services: [] },
    { ...draft, expected: undefined },
  ]) {
    const f = fixture();
    try {
      const before = f.read(),
        response = await POST(request(data));
      assert.equal(
        response.status,
        data.expected === undefined && data.plate ? 409 : 400,
      );
      assert.ok((await response.json()).error);
      assert.deepEqual(f.read(), before);
    } finally {
      f.close();
    }
  }
});

test('restoration cannot reuse another active plate, including whitespace and dash variants', async () => {
  const f = fixture();
  try {
    const before = f.read();
    assert.equal(
      (await POST(request({ ...draft, plate: 'test-b 2' }))).status,
      409,
    );
    assert.deepEqual(f.read(), before);
  } finally {
    f.close();
  }
});

test('fleet owner can neither see nor restore cars of another fleet; admin rights are not granted', async () => {
  const f = fixture();
  try {
    globalThis.vehicleTest.user = 'owner-b';
    const before = f.read(),
      response = await POST(request(draft));
    assert.equal(response.status, 404);
    assert.deepEqual(f.read(), before);
    const listed = await GET(
      new Request('https://test.invalid/api/mobility/vehicles'),
    );
    assert.deepEqual(
      (await listed.json()).vehicles.map((v) => v.id),
      ['car-b'],
    );
    assert.equal(
      (
        await GET(
          new Request(
            'https://test.invalid/api/mobility/vehicles?fleetId=fleet-a',
          ),
        )
      ).status,
      403,
    );
  } finally {
    f.close();
  }
});

test('a vehicle assigned to an online driver cannot be restored or have driver details changed', async () => {
  const f = fixture();
  try {
    f.sqlite
      .prepare(
        "INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,vehicle_id) VALUES('driver-a','TEST','000000','Audi A6','TEST A 1','premium',1,1,'car-a')",
      )
      .run();
    const before = f.read();
    assert.equal((await POST(request(draft))).status, 409);
    assert.deepEqual(f.read(), before);
    assert.equal(
      f.sqlite
        .prepare("SELECT vehicle FROM mobility_drivers WHERE id='driver-a'")
        .get().vehicle,
      'Audi A6',
    );
  } finally {
    f.close();
  }
});

test('idle assigned driver receives restored details and pending offers are withdrawn atomically', async () => {
  const f = fixture();
  try {
    f.sqlite
      .prepare(
        "INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,vehicle_id) VALUES('driver-a','TEST','000000','Audi A6','TEST A 1','premium',1,0,'car-a')",
      )
      .run();
    f.sqlite
      .prepare(
        "INSERT INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at) VALUES('offer-a','booking-a','driver-a','pending',100,0)",
      )
      .run();
    assert.equal((await POST(request(draft))).status, 200);
    const driver = f.sqlite
      .prepare("SELECT * FROM mobility_drivers WHERE id='driver-a'")
      .get();
    assert.equal(driver.vehicle, 'Audi A8');
    assert.equal(driver.plate, 'TEST A 8');
    assert.equal(driver.services, '["premium","first"]');
    assert.equal(
      f.sqlite
        .prepare("SELECT status FROM mobility_offers WHERE id='offer-a'")
        .get().status,
      'withdrawn',
    );
  } finally {
    f.close();
  }
});

test('restoration remains blocked during an active trip and until a completed trip is paid', async () => {
  for (const status of ['accepted', 'arrived', 'riding', 'completed']) {
    const f = fixture();
    try {
      f.sqlite
        .prepare(
          "INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,vehicle_id) VALUES('driver-a','TEST','000000','Audi A6','TEST A 1','premium',1,0,'car-a')",
        )
        .run();
      f.sqlite
        .prepare(
          "INSERT INTO mobility_bookings(id,quote_id,owner_id,service,price,route,mode,status,driver_id,created_at,updated_at,completed_at,payment_status) VALUES('booking-a','quote-a','customer-a','premium',1500,'{}','now',?,'driver-a',0,0,?,'unpaid')",
        )
        .run(status, status === 'completed' ? 1 : null);
      const before = f.read();
      assert.equal((await POST(request(draft))).status, 409);
      assert.deepEqual(f.read(), before);
      if (status === 'completed') {
        f.sqlite
          .prepare(
            "UPDATE mobility_bookings SET payment_status='paid' WHERE id='booking-a'",
          )
          .run();
        assert.equal((await POST(request(draft))).status, 200);
      }
    } finally {
      f.close();
    }
  }
});

test('lost archive response can be retried without changing its timestamp, trip history or stock', async () => {
  const f = fixture();
  try {
    f.sqlite.exec(
      "UPDATE mobility_vehicles SET status='active',archived_reason=NULL,archived_at=NULL WHERE id='car-a'",
    );
    f.sqlite.exec(
      "INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,vehicle_id) VALUES('driver-a','TEST','000000','Audi A6','TEST A 1','premium',1,0,'car-a')",
    );
    f.sqlite.exec(
      "INSERT INTO mobility_bookings(id,quote_id,owner_id,service,price,route,mode,status,driver_id,fleet_id,created_at,updated_at,completed_at,payment_status) VALUES('history-a','quote-a','customer-a','premium',2500,'{}','now','completed','driver-a','fleet-a',0,0,1,'paid')",
    );
    f.sqlite.exec(
      "INSERT INTO mobility_stock(vehicle_id,data,revision,operation_id,updated_at) VALUES('car-a','{\"water\":12}',1,'stock-a',0)",
    );
    const history = f.sqlite.prepare('SELECT * FROM mobility_bookings').all();
    const stock = f.sqlite.prepare('SELECT * FROM mobility_stock').all();
    const data = { action: 'archive', id: 'car-a', reason: 'Verkauft' };
    assert.equal((await POST(request(data))).status, 200);
    const archived = f.read();
    assert.equal(archived.status, 'archived');
    assert.equal(archived.archived_reason, 'Verkauft');
    assert.ok(archived.archived_at > 0);
    const driver = f.sqlite
      .prepare("SELECT * FROM mobility_drivers WHERE id='driver-a'")
      .get();
    assert.equal(driver.vehicle_id, null);
    assert.equal(driver.approved, 1);
    const retry = await POST(request(data));
    assert.equal(retry.status, 200);
    assert.equal((await retry.json()).replayed, true);
    assert.deepEqual(f.read(), archived);
    assert.deepEqual(
      f.sqlite
        .prepare("SELECT * FROM mobility_drivers WHERE id='driver-a'")
        .get(),
      driver,
    );
    assert.deepEqual(
      f.sqlite.prepare('SELECT * FROM mobility_bookings').all(),
      history,
    );
    assert.deepEqual(
      f.sqlite.prepare('SELECT * FROM mobility_stock').all(),
      stock,
    );
  } finally {
    f.close();
  }
});

test('archive retry cannot change the reason, expose another fleet or confirm a missing vehicle', async () => {
  const f = fixture();
  try {
    const before = f.read();
    assert.equal(
      (
        await POST(
          request({ action: 'archive', id: 'car-a', reason: 'Anderer Grund' }),
        )
      ).status,
      409,
    );
    assert.deepEqual(f.read(), before);
    globalThis.vehicleTest.user = 'owner-b';
    assert.equal(
      (await POST(request({ action: 'archive', id: 'car-a', reason: 'TEST' })))
        .status,
      409,
    );
    assert.equal(
      (
        await POST(
          request({ action: 'archive', id: 'missing', reason: 'TEST' }),
        )
      ).status,
      409,
    );
    assert.deepEqual(f.read(), before);
  } finally {
    f.close();
  }
});

test('archive never releases a car in a shift, active trip or unsettled completed trip', async () => {
  for (const state of [
    'online',
    'session',
    'accepted',
    'arrived',
    'riding',
    'completed',
  ]) {
    const f = fixture();
    try {
      f.sqlite.exec(
        "UPDATE mobility_vehicles SET status='active',archived_reason=NULL,archived_at=NULL WHERE id='car-a'",
      );
      f.sqlite
        .prepare(
          "INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,session_id,vehicle_id) VALUES('driver-a','TEST','000000','Audi A6','TEST A 1','premium',1,?,?,'car-a')",
        )
        .run(
          state === 'online' ? 1 : 0,
          state === 'session' ? 'shift-a' : null,
        );
      if (!['online', 'session'].includes(state))
        f.sqlite
          .prepare(
            "INSERT INTO mobility_bookings(id,quote_id,owner_id,service,price,route,mode,status,driver_id,created_at,updated_at,completed_at,payment_status) VALUES('booking-a','quote-a','customer-a','premium',1500,'{}','now',?,'driver-a',0,0,?,'unpaid')",
          )
          .run(state, state === 'completed' ? 1 : null);
      const before = f.read();
      assert.equal(
        (
          await POST(
            request({ action: 'archive', id: 'car-a', reason: 'Verkauft' }),
          )
        ).status,
        409,
      );
      assert.deepEqual(f.read(), before);
      assert.equal(
        f.sqlite
          .prepare(
            "SELECT vehicle_id FROM mobility_drivers WHERE id='driver-a'",
          )
          .get().vehicle_id,
        'car-a',
      );
    } finally {
      f.close();
    }
  }
});

test('failed driver release rolls back archiving and a subsequent archive succeeds', async () => {
  const f = fixture();
  try {
    f.sqlite.exec(
      "UPDATE mobility_vehicles SET status='active',archived_reason=NULL,archived_at=NULL WHERE id='car-a'",
    );
    f.sqlite.exec(
      "INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,vehicle_id) VALUES('driver-a','TEST','000000','Audi A6','TEST A 1','premium',1,0,'car-a')",
    );
    f.sqlite.exec(
      "CREATE TRIGGER fail_release BEFORE UPDATE OF vehicle_id ON mobility_drivers BEGIN SELECT RAISE(ABORT,'TEST release failed'); END",
    );
    const before = f.read();
    const data = { action: 'archive', id: 'car-a', reason: 'Verkauft' };
    assert.equal((await POST(request(data))).status, 500);
    assert.deepEqual(f.read(), before);
    assert.equal(
      f.sqlite
        .prepare("SELECT vehicle_id FROM mobility_drivers WHERE id='driver-a'")
        .get().vehicle_id,
      'car-a',
    );
    f.sqlite.exec('DROP TRIGGER fail_release');
    assert.equal((await POST(request(data))).status, 200);
  } finally {
    f.close();
  }
});
