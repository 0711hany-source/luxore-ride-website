import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const require = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const modules = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((n) => [
    n,
    pathToFileURL(require.resolve(n)).href,
  ]),
);
registerHooks({
  resolve(name, context, next) {
    if (modules.has(name))
      return { url: modules.get(name), shortCircuit: true };
    if (name === 'react-native')
      return {
        url:
          'data:text/javascript,' +
          encodeURIComponent(
            "export const View='View',Text='Text',Pressable='Pressable',ActivityIndicator='ActivityIndicator',StyleSheet={create:v=>v};",
          ),
        shortCircuit: true,
      };
    if (name === '@rnmapbox/maps')
      throw Error('Native SDK was imported before the app mounted');
    return next(name, context);
  },
});
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { NativeMapGate } = await import('../mobile/src/DriverMap.native.tsx');
const props = {
  token: 'pk.' + 'a'.repeat(30),
  position: null,
  route: null,
  active: true,
};
async function settle() {
  for (let i = 0; i < 5; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
test('native SDK import waits for an active view with a token, inside the mounted boundary', async () => {
  let loads = 0;
  const loader = async () => {
    loads++;
    return { default: () => React.createElement('NativeMap') };
  };
  let root;
  await act(async () => {
    root = Renderer.create(
      React.createElement(NativeMapGate, { ...props, token: '', loader }),
    );
  });
  assert.equal(loads, 0);
  await act(async () =>
    root.update(
      React.createElement(NativeMapGate, { ...props, active: false, loader }),
    ),
  );
  assert.equal(loads, 0);
  await act(async () =>
    root.update(React.createElement(NativeMapGate, { ...props, loader })),
  );
  await settle();
  assert.equal(loads, 1);
  assert.equal(root.root.findAllByType('NativeMap').length, 1);
  await act(async () => root.unmount());
});
test('module import failure shows recoverable native UI and retry loads a fresh module attempt', async () => {
  let loads = 0;
  const loader = async () => {
    if (++loads === 1) throw Error('missing module');
    return { default: () => React.createElement('NativeMap') };
  };
  const oldError = console.error;
  console.error = () => {};
  let root;
  try {
    await act(async () => {
      root = Renderer.create(
        React.createElement(NativeMapGate, { ...props, loader }),
      );
    });
    await settle();
    assert.match(
      JSON.stringify(root.toJSON()),
      /Fahrerbereich bleibt geöffnet/,
    );
    assert.equal(root.root.findAllByType('NativeMap').length, 0);
    await act(async () => root.root.findByType('Pressable').props.onPress());
    await settle();
    assert.equal(loads, 2);
    assert.equal(root.root.findAllByType('NativeMap').length, 1);
  } finally {
    if (root) await act(async () => root.unmount());
    console.error = oldError;
  }
});
