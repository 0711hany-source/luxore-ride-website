import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  load(url, context, next) {
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `
        export class ApiError extends Error { constructor(status,message){ super(message);this.status=status; } }
        export const db=()=>globalThis.nearbyTestDb;
        export const identity=async()=>({userId:'customer-test'});
        export const limit=async()=>{};
        export const body=request=>request.json();
        export const json=(value,status=200)=>Response.json(value,{status});
        export const text=value=>{if(typeof value!=='string'||!value.trim())throw new ApiError(400,'invalid');return value.trim();};
        export const handled=async work=>{try{return await work();}catch(e){return json({error:e.message},e.status||500);}};
      `,
      };
    return next(url, context);
  },
});
const { POST } = await import('../app/api/mobility/nearby/route.ts');
function fixture(pickup) {
  const sqlite = new DatabaseSync(':memory:');
  for (const file of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((f) => f.endsWith('.sql'))
    .sort())
    sqlite.exec(
      readFileSync(new URL('../drizzle/' + file, import.meta.url), 'utf8'),
    );
  globalThis.nearbyTestDb = {
    prepare(sql) {
      let values = [];
      return {
        bind(...args) {
          values = args;
          return this;
        },
        async first() {
          return sqlite.prepare(sql).get(...values) || null;
        },
        async all() {
          return { results: sqlite.prepare(sql).all(...values) };
        },
      };
    },
  };
  const now = Date.now();
  sqlite
    .prepare(
      'INSERT INTO mobility_quotes(id,owner_id,payload,expires_at) VALUES(?,?,?,?)',
    )
    .run('quote', 'customer-test', JSON.stringify({ pickup }), now + 60000);
  sqlite
    .prepare(
      'INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES(?,?,?,?)',
    )
    .run('fleet', 'Test fleet', 'test-owner', now);
  function driver(id, lat, lng) {
    sqlite
      .prepare(
        'INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,?,?,?,?,?)',
      )
      .run(id, 'Private name', 'Private phone', 'fleet', 'driver', now);
    sqlite
      .prepare(
        'INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES(?,?,?,?,?,?,?)',
      )
      .run(
        'car-' + id,
        'fleet',
        'Private car',
        id,
        '["premium"]',
        'active',
        now,
      );
    sqlite
      .prepare(
        'INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,vehicle_id,service,services,approved,online,lat,lng,accuracy,location_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
      )
      .run(
        id,
        'Private name',
        'Private phone',
        'Private car',
        id,
        'car-' + id,
        'premium',
        '["premium"]',
        1,
        1,
        lat,
        lng,
        10,
        now,
      );
  }
  const request = () =>
    POST(
      new Request('https://luxore.test/api/mobility/nearby', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ quoteId: 'quote', service: 'premium' }),
      }),
    );
  return { sqlite, driver, request };
}

test('Nearby API shows three local German drivers despite more than 200 eligible drivers elsewhere', async () => {
  const f = fixture({ lat: 52.52, lng: 13.405 });
  try {
    for (let i = 0; i < 205; i++) f.driver('frankfurt-' + i, 50.11, 8.68);
    f.driver('berlin-a', 52.5201, 13.406);
    f.driver('berlin-b', 52.5201, 13.412);
    f.driver('berlin-c', 52.5201, 13.418);
    const response = await f.request();
    assert.equal(response.status, 200);
    const { drivers } = await response.json();
    assert.equal(drivers.length, 3);
    assert.deepEqual(
      drivers.map((point) => Number(point.lng.toFixed(3))),
      [13.407, 13.413, 13.419],
    );
    for (const point of drivers)
      assert.deepEqual(Object.keys(point).sort(), ['lat', 'lng']);
    assert.equal(JSON.stringify(drivers).includes('Private'), false);
  } finally {
    f.sqlite.close();
  }
});

test('Nearby API ranks the actual closest drivers in a dense region and retains eligibility checks', async () => {
  const f = fixture({ lat: 50.11, lng: 8.68 });
  try {
    for (let i = 0; i < 205; i++) f.driver('farther-' + i, 50.11, 8.95);
    f.driver('closest', 50.11, 8.681);
    f.driver('second', 50.11, 8.685);
    f.driver('third', 50.11, 8.689);
    for (const id of [
      'offline',
      'unapproved',
      'stale',
      'archived',
      'foreign-car',
      'wrong-class',
    ])
      f.driver(id, 50.11, 8.68);
    f.sqlite.exec(
      "UPDATE mobility_drivers SET online=0 WHERE id='offline'; UPDATE mobility_drivers SET approved=0 WHERE id='unapproved'; UPDATE mobility_drivers SET location_at=1 WHERE id='stale'; UPDATE mobility_vehicles SET status='archived' WHERE id='car-archived'; UPDATE mobility_employees SET fleet_id='foreign' WHERE user_id='foreign-car'; UPDATE mobility_drivers SET services='[\"van\"]' WHERE id='wrong-class';",
    );
    const response = await f.request();
    assert.equal(response.status, 200);
    const { drivers } = await response.json();
    assert.deepEqual(
      drivers.map((point) => Number(point.lng.toFixed(3))),
      [8.682, 8.685, 8.688],
    );
  } finally {
    f.sqlite.close();
  }
});
