import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { createClient } from '@libsql/client';
import { readFileSync, readdirSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  resolve(s, c, next) {
    if (s === '#membership-adapter')
      return {
        url: new URL('../db/sqlite.ts?membership-adapter', import.meta.url)
          .href,
        shortCircuit: true,
      };
    return next(s, c);
  },
  load(url, c, next) {
    if (url.endsWith('/db/sqlite.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `export const accountsConfigured=()=>true,runtimeDatabase=()=>globalThis.membershipTest.db; export class DatabaseUnavailable extends Error {}`,
      };
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `
      export class ApiError extends Error {constructor(status,message){super(message);this.status=status}}
      export const limit=async()=>{}; export const db=()=>globalThis.membershipTest.db,settings=()=>({}),tokenHash=async()=>'',isAdmin=u=>u.userId==='operator';
      export const identity=async()=>({userId:globalThis.membershipTest.user}),body=r=>r.json(),json=(v,status=200)=>Response.json(v,{status});
      export const text=v=>{if(typeof v!=='string'||!v.trim())throw new ApiError(400,'empty');return v.trim()};
      export const handled=async fn=>{try{return await fn()}catch(e){return json({error:e.message},e.status||500)}};
    `,
      };
    return next(url, c);
  },
});
const { sqliteDatabase } = await import('#membership-adapter');
const { POST } = await import('../app/api/mobility/fleets/route.ts');

const send = (input) =>
  POST(
    new Request('https://test.invalid/api/mobility/fleets', {
      method: 'POST',
      body: JSON.stringify(input),
    }),
  );
const assign = (extra = {}) =>
  send({
    action: 'assign',
    userId: 'driver-a',
    fleetId: 'fleet-b',
    role: 'driver',
    ...extra,
  });
const remove = (extra = {}) =>
  send({
    action: 'remove_member',
    userId: 'driver-a',
    fleetId: 'fleet-a',
    ...extra,
  });
async function fixture() {
  const client = createClient({ url: ':memory:' }),
    db = sqliteDatabase(client);
  for (const name of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((n) => n.endsWith('.sql'))
    .sort())
    await client.executeMultiple(
      readFileSync(new URL('../drizzle/' + name, import.meta.url), 'utf8'),
    );
  globalThis.membershipTest = { db, user: 'operator' };
  for (const suffix of ['a', 'b']) {
    await client.execute({
      sql: 'INSERT INTO mobility_fleets(id,name,owner_id,deputy_id,created_at) VALUES(?,?,?,?,0)',
      args: [
        'fleet-' + suffix,
        'Synthetic ' + suffix,
        'owner-' + suffix,
        'deputy-' + suffix,
      ],
    });
    for (const prefix of ['owner-', 'deputy-', 'driver-']) {
      const id = prefix + suffix;
      await client.execute({
        sql: "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,'Test','000',?,'driver',0)",
        args: [id, 'fleet-' + suffix],
      });
      await client.execute({
        sql: "INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,session_id) VALUES(?,'Test','000','Test','TEST','premium',1,0,NULL)",
        args: [id],
      });
      await client.execute({
        sql: "INSERT INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES(?,?,'Test','000','driver','active',0,0)",
        args: [id, id + '@example.test'],
      });
    }
  }
  await client.execute(
    "INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('car','fleet-a','Test Audi','TEST A','[\"premium\"]','active',0)",
  );
  await client.execute(
    "UPDATE mobility_drivers SET vehicle_id='car',vehicle='Test Audi',plate='TEST A',services='[\"premium\"]' WHERE id='driver-a'",
  );
  await client.execute(
    "INSERT INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at) VALUES('offer','trip','driver-a','pending',9999999999999,0)",
  );
  const snapshot = async () =>
    Object.fromEntries(
      await Promise.all(
        [
          'mobility_fleets',
          'mobility_employees',
          'mobility_drivers',
          'mobility_vehicles',
          'mobility_bookings',
          'mobility_offers',
          'mobility_operator_audit',
        ].map(async (table) => [
          table,
          (await db.prepare('SELECT * FROM ' + table + ' ORDER BY 1').all())
            .results,
        ]),
      ),
    );
  return { client, db, snapshot, close: () => client.close() };
}
const failAudit = (f) =>
  f.client.executeMultiple(
    "CREATE TRIGGER fail_membership_audit BEFORE INSERT ON mobility_operator_audit BEGIN SELECT RAISE(ABORT,'synthetic audit failure'); END;",
  );
void test('assignment rolls back membership, vehicle, approval and offers when audit or reset fails', async () => {
  for (const failure of ['audit', 'reset']) {
    const f = await fixture();
    try {
      const before = await f.snapshot();
      if (failure === 'audit') await failAudit(f);
      else
        await f.client.executeMultiple(
          "CREATE TRIGGER fail_membership_reset BEFORE UPDATE ON mobility_drivers BEGIN SELECT RAISE(ABORT,'synthetic reset failure'); END;",
        );
      assert.equal((await assign()).status, 500);
      assert.deepEqual(await f.snapshot(), before);
      await f.client.execute('DROP TRIGGER fail_membership_' + failure);
      assert.equal((await assign()).status, 200);
      const saved = await f.snapshot();
      assert.equal(
        saved.mobility_employees.find((e) => e.user_id === 'driver-a').fleet_id,
        'fleet-b',
      );
      assert.equal(
        saved.mobility_drivers.find((d) => d.id === 'driver-a').approved,
        0,
      );
      assert.equal(
        saved.mobility_drivers.find((d) => d.id === 'driver-a').vehicle_id,
        null,
      );
      assert.equal(saved.mobility_offers[0].status, 'withdrawn');
      assert.equal(saved.mobility_operator_audit.length, 1);
      assert.deepEqual(saved.mobility_vehicles, before.mobility_vehicles);
    } finally {
      f.close();
    }
  }
});
void test('removal rolls back all state on audit or driver reset failure', async () => {
  for (const failure of ['audit', 'reset']) {
    const f = await fixture();
    try {
      const before = await f.snapshot();
      if (failure === 'audit') await failAudit(f);
      else
        await f.client.executeMultiple(
          "CREATE TRIGGER fail_membership_reset BEFORE UPDATE ON mobility_drivers BEGIN SELECT RAISE(ABORT,'synthetic reset failure'); END;",
        );
      assert.equal((await remove()).status, 500);
      assert.deepEqual(await f.snapshot(), before);
      await f.client.execute('DROP TRIGGER fail_membership_' + failure);
      assert.equal((await remove()).status, 200);
      const saved = await f.snapshot();
      assert.equal(
        saved.mobility_employees.find((e) => e.user_id === 'driver-a').fleet_id,
        null,
      );
      assert.equal(saved.mobility_offers[0].status, 'withdrawn');
      assert.equal(saved.mobility_operator_audit.length, 1);
      assert.deepEqual(saved.mobility_vehicles, before.mobility_vehicles);
    } finally {
      f.close();
    }
  }
});
void test('identical assignment confirms current state without stopping later GPS or duplicating audit', async () => {
  const f = await fixture();
  try {
    assert.equal((await assign()).status, 200);
    await f.client.execute(
      "UPDATE mobility_drivers SET approved=1,online=1,session_id='shift',vehicle_id='car',lat=50,lng=8,accuracy=5,location_at=100 WHERE id='driver-a'",
    );
    const before = await f.snapshot();
    assert.equal(before.mobility_operator_audit.length, 1);
    assert.equal((await assign()).status, 200);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
void test('owner, deputy and operator removal scopes preserve foreign and ordinary staff boundaries', async () => {
  for (const [actor, status] of [
    ['owner-a', 200],
    ['deputy-a', 200],
    ['operator', 200],
    ['owner-b', 403],
    ['driver-a', 403],
  ]) {
    const f = await fixture();
    try {
      globalThis.membershipTest.user = actor;
      const before = await f.snapshot();
      assert.equal((await remove()).status, status);
      if (status !== 200) assert.deepEqual(await f.snapshot(), before);
      assert.equal((await assign()).status, actor === 'operator' ? 200 : 403);
    } finally {
      f.close();
    }
  }
});
void test('revoked deputy authority at the write boundary cannot remove a fleet member', async () => {
  const f = await fixture();
  try {
    globalThis.membershipTest.user = 'deputy-a';
    const before = await f.snapshot();
    const write = f.db.writeTransaction,
      batch = f.db.batch;
    const revoke = () =>
      f.client.execute(
        "UPDATE mobility_fleets SET deputy_id=NULL WHERE id='fleet-a'",
      );
    f.db.writeTransaction = async (work) => {
      await revoke();
      return write(work);
    };
    f.db.batch = async (statements) => {
      await revoke();
      return batch(statements);
    };
    assert.equal((await remove()).status, 403);
    const after = await f.snapshot();
    assert.equal(after.mobility_fleets[0].deputy_id, null);
    assert.deepEqual(after.mobility_employees, before.mobility_employees);
    assert.deepEqual(after.mobility_drivers, before.mobility_drivers);
    assert.deepEqual(after.mobility_offers, before.mobility_offers);
    assert.equal(after.mobility_operator_audit.length, 0);
  } finally {
    f.close();
  }
});
void test('fleet deleted at the write boundary cannot leave an orphan member assignment', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot(),
      write = f.db.writeTransaction,
      batch = f.db.batch;
    const drop = () =>
      f.client.execute("DELETE FROM mobility_fleets WHERE id='fleet-b'");
    f.db.writeTransaction = async (work) => {
      await drop();
      return write(work);
    };
    f.db.batch = async (statements) => {
      await drop();
      return batch(statements);
    };
    assert.equal((await assign()).status, 404);
    const after = await f.snapshot();
    assert.deepEqual(after.mobility_employees, before.mobility_employees);
    assert.deepEqual(after.mobility_drivers, before.mobility_drivers);
    assert.deepEqual(after.mobility_offers, before.mobility_offers);
    assert.equal(after.mobility_operator_audit.length, 0);
  } finally {
    f.close();
  }
});
void test('inactive actors cannot change membership; inactive targets can detach but cannot gain fleet access', async () => {
  for (const status of ['blocked', 'deletion_pending']) {
    const f = await fixture();
    try {
      await f.client.execute({
        sql: "INSERT INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES('operator','operator@example.test','Test','000','fleet',?,0,0)",
        args: [status],
      });
      const before = await f.snapshot();
      assert.equal((await assign()).status, 403);
      assert.equal((await remove()).status, 403);
      assert.deepEqual(await f.snapshot(), before);
      await f.client.execute(
        "UPDATE mobility_accounts SET status='active' WHERE id='operator'",
      );
      await f.client.execute({
        sql: "UPDATE mobility_accounts SET status=? WHERE id='driver-a'",
        args: [status],
      });
      const blocked = await f.snapshot();
      assert.equal((await assign()).status, 409);
      assert.equal((await assign({ fleetId: 'fleet-a' })).status, 409);
      assert.deepEqual(await f.snapshot(), blocked);
      assert.equal((await assign({ fleetId: null })).status, 200);
      assert.equal(
        (await f.snapshot()).mobility_employees.find(
          (e) => e.user_id === 'driver-a',
        ).fleet_id,
        null,
      );
    } finally {
      f.close();
    }
  }
});
void test('assignment and removal retain online, GPS, active trip and unpaid completion locks', async () => {
  for (const condition of [
    'online',
    'session',
    'accepted',
    'arrived',
    'riding',
    'completed',
  ]) {
    const f = await fixture();
    try {
      if (condition === 'online')
        await f.client.execute(
          "UPDATE mobility_drivers SET online=1 WHERE id='driver-a'",
        );
      else if (condition === 'session')
        await f.client.execute(
          "UPDATE mobility_drivers SET session_id='shift' WHERE id='driver-a'",
        );
      else
        await f.client.execute({
          sql: "INSERT INTO mobility_bookings(id,quote_id,owner_id,driver_id,service,price,route,mode,status,created_at,updated_at,completed_at,payment_status) VALUES('trip','q','customer','driver-a','premium',1500,'{}','now',?,0,0,1,'unpaid')",
          args: [condition],
        });
      const before = await f.snapshot();
      assert.equal((await assign()).status, 409);
      assert.equal((await remove()).status, 409);
      assert.deepEqual(await f.snapshot(), before);
    } finally {
      f.close();
    }
  }
});
void test('owner and deputy cannot be reassigned or removed even by operator', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    for (const id of ['owner-a', 'deputy-a']) {
      assert.equal((await assign({ userId: id })).status, 409);
      assert.equal((await remove({ userId: id })).status, 409);
    }
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
void test('actual profiles, roles and fleet existence are required; staff without driver can be detached', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    assert.equal((await assign({ userId: 'missing' })).status, 404);
    assert.equal((await assign({ fleetId: 'missing' })).status, 404);
    assert.equal((await assign({ role: 'owner' })).status, 400);
    assert.equal((await remove({ fleetId: 'fleet-b' })).status, 409);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute(
      "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('staff','Test','000','fleet-a','staff',0)",
    );
    assert.equal((await remove({ userId: 'staff' })).status, 200);
    await f.client.execute(
      "DELETE FROM mobility_employees WHERE user_id='driver-b'",
    );
    assert.equal((await assign({ userId: 'driver-b' })).status, 200);
    assert.equal(
      (await f.snapshot()).mobility_employees.find(
        (e) => e.user_id === 'driver-b',
      ).fleet_id,
      'fleet-b',
    );
  } finally {
    f.close();
  }
});
