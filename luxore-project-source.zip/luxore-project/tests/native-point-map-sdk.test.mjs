import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const require = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const modules = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(require.resolve(name)).href,
  ]),
);
const mocks = new Map([
  [
    'react-native',
    `export const View='View',Text='Text',Pressable='Pressable',ActivityIndicator='ActivityIndicator',StyleSheet={create:v=>v};`,
  ],
  [
    'lucide-react-native',
    `export const MapPin='MapPin',Plus='Plus',Minus='Minus';`,
  ],
  [
    '@rnmapbox/maps',
    `export default {MapView:'MapView',Camera:'Camera',setAccessToken:token=>new Promise(resolve=>{globalThis.mapTokenResolve=resolve}),setTelemetryEnabled:()=>{globalThis.pointMapTelemetry++}};`,
  ],
]);
registerHooks({
  resolve(name, context, next) {
    if (modules.has(name))
      return { url: modules.get(name), shortCircuit: true };
    if (mocks.has(name))
      return {
        url: 'data:text/javascript,' + encodeURIComponent(mocks.get(name)),
        shortCircuit: true,
      };
    return next(name, context);
  },
});
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
globalThis.pointMapTelemetry = 0;
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: Gate } = await import('../mobile/src/PointMap.native.tsx');
const { default: NativeMap } =
  await import('../mobile/src/NativePointMapView.tsx');
const props = {
  active: true,
  token: 'pk.' + 'a'.repeat(30),
  center: { lat: 50.11, lng: 8.68, zoom: 16 },
  locked: false,
  onReady() {},
  onMoving() {},
  onIdle() {},
  onError() {},
};
async function settle() {
  for (let i = 0; i < 4; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
test('point map SDK loads only inside its mounted boundary with active token', async () => {
  let loads = 0,
    root;
  const loader = async () => {
    loads++;
    return { default: () => React.createElement('LoadedMap') };
  };
  try {
    await act(async () => {
      root = Renderer.create(
        React.createElement(Gate, { ...props, token: '', loader }),
      );
    });
    assert.equal(loads, 0);
    await act(async () =>
      root.update(
        React.createElement(Gate, { ...props, active: false, loader }),
      ),
    );
    assert.equal(loads, 0);
    await act(async () =>
      root.update(React.createElement(Gate, { ...props, loader })),
    );
    await settle();
    assert.equal(loads, 1);
    assert.equal(root.root.findAllByType('LoadedMap').length, 1);
  } finally {
    if (root) await act(async () => root.unmount());
  }
});
test('point map import failure stays recoverable and does not crash the booking screen', async () => {
  let attempts = 0,
    root,
    errors = 0;
  const loader = async () => {
    if (++attempts === 1) throw Error('SDK failed');
    return { default: () => React.createElement('LoadedMap') };
  };
  const old = console.error;
  console.error = () => {};
  try {
    await act(async () => {
      root = Renderer.create(
        React.createElement(Gate, {
          ...props,
          loader,
          onError: () => errors++,
        }),
      );
    });
    await settle();
    assert.equal(errors, 1);
    assert.equal(root.root.findAllByType('LoadedMap').length, 0);
    await act(async () => root.root.findByType('Pressable').props.onPress());
    await settle();
    assert.equal(root.root.findAllByType('LoadedMap').length, 1);
  } finally {
    if (root) await act(async () => root.unmount());
    console.error = old;
  }
});
test('native point map never constructs MapView or telemetry before token initialization completes', async () => {
  let root, idle;
  try {
    await act(async () => {
      root = Renderer.create(
        React.createElement(NativeMap, {
          ...props,
          onIdle: (value) => (idle = value),
        }),
      );
    });
    await settle();
    assert.equal(root.root.findAllByType('MapView').length, 0);
    assert.equal(globalThis.pointMapTelemetry, 0);
    await act(async () => globalThis.mapTokenResolve());
    await settle();
    assert.equal(globalThis.pointMapTelemetry, 1);
    const map = root.root.findByType('MapView');
    assert.equal(map.props.styleURL, 'mapbox://styles/mapbox/streets-v12');
    assert.equal(map.props.onRegionDidChange, undefined);
    await act(async () =>
      map.props.onMapIdle({ properties: { center: [8.68, 50.11], zoom: 16 } }),
    );
    assert.deepEqual(idle, props.center);
  } finally {
    if (root) await act(async () => root.unmount());
  }
});
