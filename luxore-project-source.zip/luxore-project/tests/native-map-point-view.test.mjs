import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const require = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const modules = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(require.resolve(name)).href,
  ]),
);
globalThis.mapPickerListeners = new Set();
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocks = new Map([
  [
    'react-native',
    `export const Modal='Modal',View='View',Text='Text',Pressable='Pressable',ActivityIndicator='ActivityIndicator',StyleSheet={create:v=>v};export const AppState={currentState:'active',addEventListener(e,fn){globalThis.mapPickerListeners.add(fn);return{remove(){globalThis.mapPickerListeners.delete(fn)}}}};`,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaView='SafeAreaView';`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',MapPin='MapPin';`,
  ],
  [
    './PointMap',
    `import React from 'react';export default props=>React.createElement('NativePointMap',props);`,
  ],
  [
    './account-client',
    `export const nativeApi=(...args)=>globalThis.mapPickerApi(...args);`,
  ],
]);
registerHooks({
  resolve(name, context, next) {
    if (modules.has(name))
      return { url: modules.get(name), shortCircuit: true };
    if (mocks.has(name))
      return {
        url: 'data:text/javascript,' + encodeURIComponent(mocks.get(name)),
        shortCircuit: true,
      };
    if (name === '@rnmapbox/maps') throw Error('SDK must be lazy');
    return next(name, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: Picker } =
  await import('../mobile/src/NativeMapPointPicker.tsx');
const point = {
  id: 'server-pin',
  label: 'Gewählter Punkt · Frankfurt',
  lat: 50.11,
  lng: 8.68,
};
const props = {
  visible: true,
  token: 'a'.repeat(64),
  title: 'Abholort',
  onClose() {},
  onSelected() {},
};
async function settle() {
  for (let i = 0; i < 4; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
function confirm(root) {
  return root.root
    .findAllByType('Pressable')
    .find(
      (n) => n.props.accessibilityLabel === 'Abholort auf Karte bestätigen',
    );
}
async function chosen(root) {
  await act(async () => {
    const map = root.root.findByType('NativePointMap');
    map.props.onReady();
    map.props.onIdle({ ...point, zoom: 16 });
  });
}
function api() {
  const calls = [];
  globalThis.mapPickerApi = async (...args) => {
    calls.push(args);
    return args[0] === 'config'
      ? { publicMapToken: 'pk.' + 'a'.repeat(30) }
      : { results: [point] };
  };
  return calls;
}
test('fixed native modal confirms the exact idle map point through own API, never a WebView', async () => {
  const calls = api(),
    selected = [];
  let root;
  try {
    await act(async () => {
      root = Renderer.create(
        React.createElement(Picker, {
          ...props,
          onSelected: (p) => selected.push(p),
        }),
      );
    });
    await settle();
    assert.equal(
      root.root.findByType('Modal').props.presentationStyle,
      'fullScreen',
    );
    assert.equal(confirm(root).props.disabled, true);
    await chosen(root);
    assert.equal(confirm(root).props.disabled, false);
    await act(async () => confirm(root).props.onPress());
    await settle();
    assert.deepEqual(calls[1].slice(0, 3), [
      'places',
      props.token,
      { kind: 'pin', lat: 50.11, lng: 8.68 },
    ]);
    assert.deepEqual(selected, [point]);
    assert.equal(root.root.findAllByType('WebView').length, 0);
  } finally {
    if (root) await act(async () => root.unmount());
  }
});
test('background confirmation is delivered once only after foreground return', async () => {
  api();
  let resolve, root;
  const selected = [];
  globalThis.mapPickerApi = async (path) =>
    path === 'config'
      ? { publicMapToken: 'pk.' + 'a'.repeat(30) }
      : new Promise((r) => (resolve = r));
  try {
    await act(async () => {
      root = Renderer.create(
        React.createElement(Picker, {
          ...props,
          onSelected: (p) => selected.push(p),
        }),
      );
    });
    await settle();
    await chosen(root);
    await act(async () => confirm(root).props.onPress());
    await act(async () => {
      for (const fn of globalThis.mapPickerListeners) fn('background');
    });
    await act(async () => resolve({ results: [point] }));
    assert.equal(selected.length, 0);
    await act(async () => {
      for (const fn of globalThis.mapPickerListeners) fn('active');
    });
    await settle();
    assert.equal(selected.length, 1);
  } finally {
    if (root) await act(async () => root.unmount());
  }
});
test('account change does not apply an old persisted point to the new account', async () => {
  api();
  let resolve, root;
  const selected = [];
  globalThis.mapPickerApi = async (path) =>
    path === 'config'
      ? { publicMapToken: 'pk.' + 'a'.repeat(30) }
      : new Promise((r) => (resolve = r));
  try {
    await act(async () => {
      root = Renderer.create(
        React.createElement(Picker, {
          ...props,
          onSelected: (p) => selected.push(p),
        }),
      );
    });
    await settle();
    await chosen(root);
    await act(async () => confirm(root).props.onPress());
    await act(async () =>
      root.update(
        React.createElement(Picker, {
          ...props,
          token: 'b'.repeat(64),
          onSelected: (p) => selected.push(p),
        }),
      ),
    );
    await settle();
    await act(async () => resolve({ results: [point] }));
    await settle();
    assert.equal(selected.length, 0);
    assert.equal(confirm(root).props.disabled, true);
  } finally {
    if (root) await act(async () => root.unmount());
  }
});
test('StrictMode effect restart still prepares a usable point picker', async () => {
  api();
  let root;
  try {
    await act(async () => {
      root = Renderer.create(
        React.createElement(
          React.StrictMode,
          null,
          React.createElement(Picker, props),
        ),
      );
    });
    await settle();
    await chosen(root);
    assert.equal(confirm(root).props.disabled, false);
  } finally {
    if (root) await act(async () => root.unmount());
  }
});
