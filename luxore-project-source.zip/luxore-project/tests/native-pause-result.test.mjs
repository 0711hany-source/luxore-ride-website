import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
const virtual = (source) => ({
  url: 'data:text/javascript,' + encodeURIComponent(source),
  shortCircuit: true,
});
registerHooks({
  resolve(s, c, next) {
    if (s === 'expo-location')
      return virtual(
        `export const Accuracy={High:4,BestForNavigation:6};export const requestForegroundPermissionsAsync=async()=>({granted:true}),getBackgroundPermissionsAsync=async()=>({granted:true}),requestBackgroundPermissionsAsync=async()=>({granted:true}),hasStartedLocationUpdatesAsync=async()=>{globalThis.pauseCleanup.probes++;globalThis.pauseCleanup.check('probe');return globalThis.pauseCleanup.started},startLocationUpdatesAsync=async()=>{globalThis.pauseCleanup.started=true},stopLocationUpdatesAsync=async()=>{globalThis.pauseCleanup.stops++;globalThis.pauseCleanup.check('stop');globalThis.pauseCleanup.started=false},getCurrentPositionAsync=()=>new Promise(()=>{});`,
      );
    if (s === 'expo-task-manager')
      return virtual(`export const defineTask=()=>{};`);
    if (s === 'expo-secure-store')
      return virtual(
        `export const getItemAsync=async k=>{if(k==='luxore-driver-location-session')globalThis.pauseCleanup.check('read');return globalThis.pauseCleanup.store.get(k)||null},setItemAsync=async(k,v)=>globalThis.pauseCleanup.store.set(k,v),deleteItemAsync=async k=>{globalThis.pauseCleanup.removes.push(k);globalThis.pauseCleanup.check(k==='luxore-driver-location-session'?'deleteCapability':'deleteCache');globalThis.pauseCleanup.store.delete(k)};`,
      );
    if (s === 'react-native')
      return virtual(
        `export const Alert={alert(){throw Error('Unexpected permission dialog')}};`,
      );
    if (s === './offer-alerts')
      return virtual(
        `export const offerAlerts={clear:async()=>{globalThis.pauseCleanup.clears++;globalThis.pauseCleanup.check('alarm')},sync:async()=>{}},alertStatus=async()=>({enabled:true,sound:true}),requestAlerts=async()=>({enabled:true,sound:true});`,
      );
    return next(s, c);
  },
  load(url, c, next) {
    if (
      url.endsWith('/mobile/src/location-service.ts') &&
      process.env.TEST_ORIGINAL_LOCATION_SERVICE
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_LOCATION_SERVICE, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
const service = await import('../mobile/src/location-service.ts');
const key = 'luxore-driver-location-session',
  positionKey = 'luxore-driver-background-position';
const cred = (id = 'old') => ({
  sessionId: id,
  nativeToken: (id === 'old' ? 'a' : 'b').repeat(64),
  expiresAt: Date.now() + 3600000,
});
const fix = () => ({
  coords: {
    latitude: 50.11,
    longitude: 8.68,
    accuracy: 8,
    speed: 0,
    heading: 0,
  },
  timestamp: Date.now(),
});
const originalFetch = globalThis.fetch;
function fixture() {
  const f = {
    store: new Map(),
    fail: new Set(),
    started: false,
    stops: 0,
    probes: 0,
    clears: 0,
    removes: [],
    writes: [],
  };
  f.check = (name) => {
    if (f.fail.has(name)) throw Error('Synthetic ' + name);
  };
  globalThis.pauseCleanup = f;
  globalThis.fetch = async (_url, o) => {
    f.writes.push({ token: o.headers.Authorization, body: JSON.parse(o.body) });
    return Response.json({ ok: true });
  };
  return f;
}
async function start(f) {
  await service.startLocation(cred());
  f.store.set(positionKey, 'cached');
  f.stops = 0;
  f.probes = 0;
  f.clears = 0;
  f.removes = [];
}
async function clean(f) {
  f.fail.clear();
  await service.stopLocation(false);
  globalThis.fetch = originalFetch;
}
for (const [name, reply] of [
  ['network failure', () => Promise.reject(Error('Synthetic network failure'))],
  ['HTTP 403', () => Response.json({ error: 'denied' }, { status: 403 })],
  ['HTTP 401', () => Response.json({ error: 'expired' }, { status: 401 })],
  ['HTTP 500', () => Response.json({ error: 'storage' }, { status: 500 })],
  ['negative acknowledgment', () => Response.json({ ok: false })],
  ['malformed acknowledgment', () => new Response('invalid JSON')],
])
  void test(
    'actual pause separates local shutdown from unconfirmed server stop after ' +
      name,
    async () => {
      const f = fixture();
      try {
        await start(f);
        globalThis.fetch = async (_url, o) => {
          f.writes.push({
            token: o.headers.Authorization,
            body: JSON.parse(o.body),
          });
          return reply();
        };
        const result = await service.stopLocation();
        assert.deepEqual(result, { active: false, serverStopped: false });
        assert.equal(f.started, false);
        assert.equal(f.store.has(key), false);
        assert.equal(f.store.has(positionKey), false);
        assert.equal(f.writes.length, 1);
        assert.equal(f.writes[0].token, 'Bearer ' + 'a'.repeat(64));
        await service.deliverForeground(fix());
        assert.equal(f.writes.length, 1);
      } finally {
        await clean(f);
      }
    },
  );
void test('actual successful stop requires the server JSON acknowledgment', async () => {
  const f = fixture();
  try {
    await start(f);
    assert.deepEqual(await service.stopLocation(), {
      active: false,
      serverStopped: true,
    });
    assert.equal(f.writes.length, 1);
  } finally {
    await clean(f);
  }
});
void test('local-only stop does not claim server confirmation or perform HTTP', async () => {
  const f = fixture();
  try {
    await start(f);
    assert.deepEqual(await service.stopLocation(false), {
      active: false,
      serverStopped: null,
    });
    assert.equal(f.writes.length, 0);
  } finally {
    await clean(f);
  }
});
void test('a second pause without credentials cannot invent confirmation or retry the deleted token', async () => {
  const f = fixture();
  try {
    await start(f);
    globalThis.fetch = async () => {
      f.writes.push({});
      throw Error('network');
    };
    await service.stopLocation();
    assert.deepEqual(await service.stopLocation(), {
      active: false,
      serverStopped: false,
    });
    assert.equal(f.writes.length, 1);
  } finally {
    await clean(f);
  }
});
void test('late rejected old server pause leaves a newly started shift intact', async () => {
  const f = fixture();
  let release;
  let stopped;
  const wait = new Promise((r) => (release = r));
  try {
    await start(f);
    globalThis.fetch = async () => wait;
    stopped = service.stopLocation();
    for (let i = 0; i < 8; i++) await new Promise((r) => setImmediate(r));
    await service.startLocation(cred('new'));
    release(Response.json({ error: 'denied' }, { status: 403 }));
    assert.deepEqual(await stopped, { active: false, serverStopped: false });
    assert.equal((await service.locationStatus()).sessionId, 'new');
    assert.equal(f.started, true);
  } finally {
    release(Response.json({ ok: true }));
    await stopped;
    await clean(f);
  }
});
