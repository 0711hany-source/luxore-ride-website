import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  NavigationMotion,
  pathPose,
  roadPath,
  turnTowards,
  type RoadLine,
} from '../app/mobility/navigation-motion.ts';
import {
  parseRoadTrace,
  readRoadMatch,
} from '../lib/mobility/road-matching.ts';
const line: RoadLine = [
  [8, 50],
  [8.001, 50],
  [8.001, 50.001],
];
const p = (lat: number, lng: number, timestamp: number, accuracy = 6) => ({
  lat,
  lng,
  timestamp,
  accuracy,
});
test('road interpolation walks the corner instead of cutting across the block', () => {
  const path = roadPath(
    { lng: 8, lat: 50 },
    { lng: 8.001, lat: 50.001 },
    line,
    8,
  )!;
  assert.ok(path.length >= 3);
  for (let t = 0; t <= 1; t += 0.05) {
    const pose = pathPose(path, t, 0);
    assert.ok(
      Math.abs(pose.lat - 50) < 1e-10 || Math.abs(pose.lng - 8.001) < 1e-10,
    );
  }
});
test('do not force an off-road point, reversed travel or a far endpoint onto the booked route', () => {
  assert.equal(
    roadPath({ lng: 8, lat: 50 }, { lng: 8.002, lat: 50.001 }, line, 8),
    null,
  );
  assert.equal(
    roadPath({ lng: 8.001, lat: 50.001 }, { lng: 8, lat: 50 }, line, 8),
    null,
  );
  assert.equal(
    roadPath(
      { lng: 8.001, lat: 50.0009 },
      { lng: 8.001, lat: 50.0012 },
      line,
      25,
    ),
    null,
  );
});
test('four-second GPS cadence remains moving after 900ms and stops at latest fix', () => {
  const m = new NavigationMotion();
  m.push(p(50, 8, 100000), 0);
  m.push(p(50, 8.001, 104000), 4000);
  const early = m.sample(4900)!,
    late = m.sample(7000)!;
  assert.ok(early.lng > 8 && early.lng < late.lng);
  assert.ok(late.lng < 8.001);
  assert.equal(m.sample(9000)!.lng, 8.001);
  assert.equal(m.sample(20000)!.lng, 8.001);
});
test('retarget during animation starts from rendered position with no teleport', () => {
  const m = new NavigationMotion();
  m.push(p(50, 8, 100000), 0);
  m.push(p(50, 8.001, 104000), 4000);
  const before = m.sample(6000)!;
  m.push(p(50, 8.0015, 106000), 6000);
  const after = m.sample(6000)!;
  assert.equal(before.lng, after.lng);
  assert.equal(before.lat, after.lat);
  assert.ok(m.sample(7000)!.lng > before.lng);
});
test('parked jitter holds direction; slow movement accumulates beyond deadband', () => {
  const m = new NavigationMotion();
  m.push(p(50, 8, 100000, 20), 0);
  assert.equal(m.push(p(50.00001, 8, 104000, 20), 4000), false);
  assert.equal(m.push(p(50.00002, 8, 108000, 20), 8000), false);
  assert.equal(m.push(p(50.00006, 8, 112000, 20), 12000), true);
});
test('old and implausible fixes are rejected; long gaps resync without driving through gaps', () => {
  const m = new NavigationMotion();
  m.push(p(50, 8, 100000), 0);
  assert.equal(m.push(p(50.5, 8, 99000), 500), false);
  assert.equal(m.push(p(50.5, 8, 101000), 1000), false);
  assert.equal(m.push(p(50.5, 8, 130000), 30000), true);
  assert.equal(m.sample(30000)!.lat, 50.5);
  m.reset();
  assert.equal(m.position, null);
});
test('north crossing turns by two degrees, never the long way around', () => {
  assert.equal(turnTowards(359, 1, 0.5), 0);
  assert.equal(turnTowards(1, 359, 0.5), 0);
});
const now = 200000;
const trace = [
  p(50, 8, now - 10000),
  p(50, 8.0005, now - 5000),
  p(50, 8.001, now),
];
const result = () => ({
  code: 'Ok',
  tracepoints: trace.map((p) => ({
    location: [p.lng, p.lat],
    alternatives_count: 0,
    matchings_index: 0,
  })),
  matchings: [
    { confidence: 0.98, geometry: { type: 'LineString', coordinates: line } },
  ],
});
test('road matching requires fresh, ordered, bounded traces', () => {
  assert.equal(parseRoadTrace(trace, now).length, 3);
  assert.throws(() => parseRoadTrace([trace[0], trace[0], trace[2]], now));
  assert.throws(() => parseRoadTrace(trace, now + 100000));
  assert.throws(() =>
    parseRoadTrace([trace[0], { ...trace[1], accuracy: 51 }, trace[2]], now),
  );
  assert.throws(() => parseRoadTrace([trace[0], null, trace[2]], now));
});
test('ambiguous, low-confidence and split matches are discarded', () => {
  assert.ok(readRoadMatch(result(), trace));
  const low = result();
  low.matchings[0].confidence = 0.3;
  assert.equal(readRoadMatch(low, trace), null);
  const ambiguous = result();
  ambiguous.tracepoints[2].alternatives_count = 1;
  assert.equal(readRoadMatch(ambiguous, trace), null);
  const split = result();
  split.tracepoints[2].matchings_index = 1;
  assert.equal(readRoadMatch(split, trace), null);
  assert.equal(readRoadMatch({ code: 'NoMatch' }, trace), null);
});
