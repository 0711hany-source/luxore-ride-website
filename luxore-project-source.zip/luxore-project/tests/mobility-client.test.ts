import { test } from 'node:test';
import assert from 'node:assert/strict';
import { api } from '../app/mobility/api.ts';

void test('a stalled online request times out and a subsequent attempt can succeed', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  let requestSignal: AbortSignal | undefined;
  t.mock.method(globalThis, 'fetch', (_url: unknown, options: RequestInit) => {
    requestSignal = options.signal!;
    return new Promise((_resolve, reject) => {
      requestSignal!.addEventListener('abort', () =>
        reject(new DOMException('Aborted', 'AbortError')),
      );
    });
  });
  const stalled = api('driver', { action: 'online' });
  const rejected = assert.rejects(stalled, /Verbindung dauert zu lange/);
  t.mock.timers.tick(15000);
  await rejected;
  assert.equal(requestSignal?.aborted, true);
  t.mock.method(globalThis, 'fetch', async () =>
    Response.json({ sessionId: 'new-shift' }),
  );
  assert.deepEqual(await api('driver', { action: 'online' }), {
    sessionId: 'new-shift',
  });
});

void test('driver rejection remains actionable and an HTML outage does not expose a JSON parser error', async (t) => {
  t.mock.method(globalThis, 'fetch', async () =>
    Response.json(
      { error: 'Bitte zuerst ein Fahrzeug wählen.' },
      { status: 409 },
    ),
  );
  await assert.rejects(
    api('driver', { action: 'online' }),
    /Bitte zuerst ein Fahrzeug wählen/,
  );
  t.mock.method(
    globalThis,
    'fetch',
    async () => new Response('<html>Unavailable</html>', { status: 503 }),
  );
  await assert.rejects(
    api('driver', { action: 'online' }),
    /Server ist gerade nicht erreichbar/,
  );
});

void test('caller cancellation still reaches fetch', async (t) => {
  const controller = new AbortController();
  t.mock.method(
    globalThis,
    'fetch',
    (_url: unknown, options: RequestInit) =>
      new Promise((_resolve, reject) => {
        options.signal!.addEventListener('abort', () =>
          reject(options.signal!.reason),
        );
      }),
  );
  const pending = api('driver', undefined, controller.signal);
  const rejected = assert.rejects(pending, { name: 'AbortError' });
  controller.abort();
  await rejected;
});

void test('a dispatch tick limited by another tab does not block reads; other failures remain visible', async (t) => {
  const { advanceDispatch, MobilityApiError } =
    await import('../app/mobility/api.ts');
  const paths: string[] = [];
  t.mock.method(globalThis, 'fetch', async (url: string) => {
    paths.push(url);
    return url.endsWith('/tick')
      ? Response.json({ error: 'Zu viele Anfragen' }, { status: 429 })
      : Response.json({ bookings: [] });
  });
  await advanceDispatch();
  assert.deepEqual(await api('bookings'), { bookings: [] });
  assert.equal(paths.length, 2);
  t.mock.method(globalThis, 'fetch', async () =>
    Response.json({ error: 'Nicht angemeldet' }, { status: 401 }),
  );
  await assert.rejects(
    advanceDispatch(),
    (error) => error instanceof MobilityApiError && error.status === 401,
  );
});
