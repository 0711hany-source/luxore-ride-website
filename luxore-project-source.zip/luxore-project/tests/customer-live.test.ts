import test from 'node:test';
import assert from 'node:assert/strict';
import type { Booking, BookingStatus } from '../lib/mobility/domain.ts';
import {
  CustomerLiveController,
  customerMapSnapshot,
  type CustomerCoordinate,
  type CustomerLiveState,
} from '../mobile/src/customer-live.ts';
const now = 100000;
function trip(id = 'ride-a', status: BookingStatus = 'requesting') {
  return {
    id,
    status,
    owner_id: 'owner-a',
    created_at: 10,
    updated_at: 10,
    service: 'premium',
    driver_id: 'driver-a',
    driver: {
      id: 'driver-a',
      lat: 50.11,
      lng: 8.68,
      accuracy: 8,
      location_at: now,
    },
  } as Booking;
}
function deferred<T>() {
  let resolve!: (value: T) => void, reject!: (error: Error) => void;
  const promise = new Promise<T>((a, b) => {
    resolve = a;
    reject = b;
  });
  return { promise, resolve, reject };
}
async function settle() {
  for (let i = 0; i < 5; i++) await new Promise((r) => setImmediate(r));
}
function view(booking: Booking): CustomerLiveState {
  return {
    booking,
    active: true,
    loaded: true,
    refreshing: false,
    updatedAt: now,
    serverTime: null,
    nearbyAt: now,
    nearby: [{ lat: 50.112, lng: 8.682 }],
    error: '',
    nearbyError: '',
  };
}

void test('selected ride belongs to the account; an absent explicit selection never falls through to another ride', async () => {
  const foreign = {
    ...trip('foreign'),
    owner_id: 'someone-else',
    created_at: 100,
  };
  const store = new CustomerLiveController(
    'owner-a',
    async () => ({ bookings: [trip(), foreign] }),
    async () => ({ drivers: [] }),
    () => now,
  );
  try {
    store.setActive(true);
    await settle();
    assert.equal(store.getSnapshot().booking?.id, 'ride-a');
    store.select('foreign');
    await settle();
    assert.equal(store.getSnapshot().booking, null);
    store.select('missing');
    await settle();
    assert.equal(store.getSnapshot().booking, null);
  } finally {
    store.dispose();
  }
});

void test('nearest vehicles use the selected booking/class, strip identities and never exceed three', async () => {
  let body: unknown;
  const store = new CustomerLiveController(
    'owner-a',
    async () => ({ bookings: [trip()] }),
    async (b) => {
      body = b;
      return {
        drivers: [
          { lat: 1000, lng: 8 },
          { lat: 50.112, lng: 8.682, id: 'hidden', phone: 'hidden' },
          { lat: 50.113, lng: 8.683 },
          { lat: 50.114, lng: 8.684 },
          { lat: 50.115, lng: 8.685 },
        ],
      };
    },
    () => now,
  );
  try {
    store.setActive(true);
    await settle();
    assert.deepEqual(body, { bookingId: 'ride-a', service: 'premium' });
    assert.deepEqual(store.getSnapshot().nearby, [
      { lat: 50.112, lng: 8.682 },
      { lat: 50.113, lng: 8.683 },
      { lat: 50.114, lng: 8.684 },
    ]);
    const result = customerMapSnapshot(store.getSnapshot(), now);
    assert.equal(result.nearby.length, 3);
    assert.equal(result.driverPosition, null);
    assert.equal(result.canContactDriver, false);
  } finally {
    store.dispose();
  }
});

void test('background aborts old reads and foreground loads immediately without stale finally releasing a newer request', async () => {
  const old = deferred<{ bookings: Booking[] }>(),
    fresh = deferred<{ bookings: Booking[] }>();
  const signals: AbortSignal[] = [];
  const store = new CustomerLiveController(
    'owner-a',
    (signal) => {
      signals.push(signal);
      return signals.length === 1 ? old.promise : fresh.promise;
    },
    async () => ({ drivers: [] }),
    () => now,
  );
  try {
    store.setActive(true);
    await settle();
    store.setActive(false);
    assert.equal(signals[0].aborted, true);
    store.setActive(true);
    await settle();
    assert.equal(signals.length, 2);
    old.resolve({ bookings: [trip('old')] });
    await settle();
    assert.equal(store.getSnapshot().refreshing, true);
    assert.equal(store.getSnapshot().booking, null);
    void store.refresh();
    await settle();
    assert.equal(signals.length, 2);
    fresh.resolve({ bookings: [trip('fresh', 'accepted')] });
    await settle();
    assert.equal(store.getSnapshot().booking?.id, 'fresh');
  } finally {
    old.resolve({ bookings: [] });
    fresh.resolve({ bookings: [] });
    store.dispose();
  }
});

void test('changing selected ride rejects an outstanding nearby answer for the former ride', async () => {
  const old = deferred<{ drivers: CustomerCoordinate[] }>();
  const a = trip(),
    b = trip('ride-b', 'accepted');
  const store = new CustomerLiveController(
    'owner-a',
    async () => ({ bookings: [a, b] }),
    () => old.promise,
    () => now,
  );
  try {
    store.select(a.id);
    store.setActive(true);
    await settle();
    store.select(b.id);
    await settle();
    assert.equal(store.getSnapshot().booking?.id, b.id);
    old.resolve({ drivers: [{ lat: 50.11, lng: 8.68 }] });
    await settle();
    assert.deepEqual(store.getSnapshot().nearby, []);
    assert.deepEqual(
      customerMapSnapshot(store.getSnapshot(), now).driverPosition,
      { lat: 50.11, lng: 8.68 },
    );
  } finally {
    old.resolve({ drivers: [] });
    store.dispose();
  }
});

void test('nearby failure keeps confirmed ride status but never stale anonymous cars', async () => {
  let fail = false;
  const store = new CustomerLiveController(
    'owner-a',
    async () => ({ bookings: [trip()] }),
    async () => {
      if (fail) throw new Error('offline');
      return { drivers: [{ lat: 50.11, lng: 8.68 }] };
    },
    () => now,
  );
  try {
    store.setActive(true);
    await settle();
    fail = true;
    await store.refresh();
    assert.equal(store.getSnapshot().booking?.status, 'requesting');
    assert.equal(store.getSnapshot().error, '');
    assert.equal(store.getSnapshot().nearbyError, 'offline');
    assert.deepEqual(customerMapSnapshot(store.getSnapshot(), now).nearby, []);
  } finally {
    store.dispose();
  }
});

void test('network loss preserves read-only details but stops live/contact claims until recovery', async () => {
  let fail = false;
  const store = new CustomerLiveController(
    'owner-a',
    async () => {
      if (fail) throw new Error('offline');
      return { bookings: [trip('ride-a', 'accepted')] };
    },
    async () => ({ drivers: [] }),
    () => now,
  );
  try {
    store.setActive(true);
    await settle();
    fail = true;
    await store.refresh();
    const snapshot = customerMapSnapshot(store.getSnapshot(), now);
    assert.equal(snapshot.booking?.id, 'ride-a');
    assert.equal(snapshot.connected, false);
    assert.equal(snapshot.driverPosition, null);
    assert.equal(snapshot.canContactDriver, false);
    fail = false;
    await store.refresh();
    assert.equal(customerMapSnapshot(store.getSnapshot(), now).connected, true);
  } finally {
    store.dispose();
  }
});

void test('authorization failure clears previous ride and driver details rather than showing another account cache', async () => {
  let fail = false;
  const store = new CustomerLiveController(
    'owner-a',
    async () => {
      if (fail) throw Object.assign(new Error('denied'), { status: 401 });
      return { bookings: [trip('ride-a', 'accepted')] };
    },
    async () => ({ drivers: [] }),
    () => now,
  );
  try {
    store.setActive(true);
    await settle();
    fail = true;
    await store.refresh();
    assert.equal(store.getSnapshot().booking, null);
    assert.equal(store.getSnapshot().updatedAt, null);
    assert.equal(store.getSnapshot().error, 'Bitte erneut anmelden.');
  } finally {
    store.dispose();
  }
});

void test('completed/cancelled/reserved/unavailable rides expose no driver GPS/contact or anonymous vehicles', () => {
  for (const status of [
    'completed',
    'cancelled',
    'reserved',
    'unavailable',
  ] as const) {
    const result = customerMapSnapshot(view(trip('ride-a', status)), now);
    assert.equal(result.driverPosition, null);
    assert.equal(result.canContactDriver, false);
    assert.deepEqual(result.nearby, []);
  }
});

void test('authorization loss during nearby loading clears already fetched booking details', async () => {
  const store = new CustomerLiveController(
    'owner-a',
    async () => ({ bookings: [trip()] }),
    async () => {
      throw Object.assign(new Error('denied'), { status: 403 });
    },
    () => now,
  );
  try {
    store.setActive(true);
    await settle();
    assert.equal(store.getSnapshot().booking, null);
    assert.equal(store.getSnapshot().error, 'Bitte erneut anmelden.');
  } finally {
    store.dispose();
  }
});

void test('stale/future/inaccurate/invalid/mismatched driver fixes cannot appear as live telemetry', () => {
  const b = trip('ride-a', 'accepted');
  assert.deepEqual(customerMapSnapshot(view(b), now).driverPosition, {
    lat: 50.11,
    lng: 8.68,
  });
  for (const patch of [
    { location_at: now - 45001 },
    { location_at: now + 5001 },
    { location_at: NaN },
    { accuracy: 101 },
    { accuracy: -1 },
    { accuracy: NaN },
    { lat: 1000 },
    { lng: null },
    { id: 'other-driver' },
  ]) {
    assert.equal(
      customerMapSnapshot(
        view({ ...b, driver: { ...b.driver!, ...patch } }),
        now,
      ).driverPosition,
      null,
    );
  }
  assert.equal(customerMapSnapshot(view(b), now + 20001).connected, false);
  assert.equal(
    customerMapSnapshot({ ...view(b), active: false }, now).driverPosition,
    null,
  );
  assert.deepEqual(customerMapSnapshot(view(trip()), now + 20001).nearby, []);
});

void test('older server ride status cannot roll the view back after a confirmed completion', async () => {
  let value = { ...trip('ride-a', 'completed'), updated_at: 20 };
  const store = new CustomerLiveController(
    'owner-a',
    async () => ({ bookings: [value] }),
    async () => ({ drivers: [] }),
    () => now,
  );
  try {
    store.select('ride-a');
    store.setActive(true);
    await settle();
    value = { ...trip('ride-a', 'accepted'), updated_at: 19 };
    await store.refresh();
    assert.equal(store.getSnapshot().booking?.status, 'completed');
    assert.match(store.getSnapshot().error, /veralteter/);
    assert.equal(
      customerMapSnapshot(store.getSnapshot(), now).driverPosition,
      null,
    );
  } finally {
    store.dispose();
  }
});

void test('older telemetry does not move the marker backwards while price/status fields still refresh', async () => {
  let value = trip('ride-a', 'accepted');
  const store = new CustomerLiveController(
    'owner-a',
    async () => ({ bookings: [value] }),
    async () => ({ drivers: [] }),
    () => now,
  );
  try {
    store.setActive(true);
    await settle();
    value = {
      ...value,
      status: 'riding',
      price: 2300,
      updated_at: 20,
      driver: { ...value.driver!, lat: 49, location_at: now - 1000 },
    };
    await store.refresh();
    assert.equal(store.getSnapshot().booking?.status, 'riding');
    assert.equal(store.getSnapshot().booking?.price, 2300);
    assert.deepEqual(
      customerMapSnapshot(store.getSnapshot(), now).driverPosition,
      { lat: 50.11, lng: 8.68 },
    );
  } finally {
    store.dispose();
  }
});

void test('disposal erases state and ignores an already delivered but late transport response', async () => {
  const pending = deferred<{ bookings: Booking[] }>();
  const store = new CustomerLiveController(
    'owner-a',
    () => pending.promise,
    async () => ({ drivers: [] }),
    () => now,
  );
  store.setActive(true);
  await settle();
  store.dispose();
  pending.resolve({ bookings: [trip()] });
  await settle();
  assert.equal(store.getSnapshot().booking, null);
  assert.equal(store.getSnapshot().active, false);
  assert.deepEqual(store.getSnapshot().nearby, []);
});

void test('malformed booking lists report a read failure instead of manufacturing an empty success', async () => {
  const store = new CustomerLiveController(
    'owner-a',
    async () => ({ bookings: null as unknown as Booking[] }),
    async () => ({ drivers: [] }),
    () => now,
  );
  try {
    store.setActive(true);
    await settle();
    assert.match(store.getSnapshot().error, /Ungültiger/);
    assert.equal(store.getSnapshot().updatedAt, null);
  } finally {
    store.dispose();
  }
});

void test('server time keeps fresh driver telemetry usable when the phone clock differs by hours', async () => {
  const serverTime = now + 6 * 3600000;
  const b = {
    ...trip('ride-a', 'accepted'),
    driver: { ...trip().driver!, location_at: serverTime - 1000 },
  };
  const store = new CustomerLiveController(
    'owner-a',
    async () => ({ bookings: [b], serverTime }),
    async () => ({ drivers: [] }),
    () => now,
  );
  try {
    store.setActive(true);
    await settle();
    assert.deepEqual(
      customerMapSnapshot(store.getSnapshot(), now).driverPosition,
      { lat: 50.11, lng: 8.68 },
    );
    assert.equal(
      customerMapSnapshot(store.getSnapshot(), now + 20001).driverPosition,
      null,
    );
    assert.equal(
      customerMapSnapshot(store.getSnapshot(), now - 1).connected,
      false,
    );
  } finally {
    store.dispose();
  }
});

void test('invalid server time cannot certify fresh telemetry', async () => {
  for (const serverTime of [NaN, Infinity, -1]) {
    const store = new CustomerLiveController(
      'owner-a',
      async () => ({ bookings: [trip('ride-a', 'accepted')], serverTime }),
      async () => ({ drivers: [] }),
      () => now,
    );
    try {
      store.setActive(true);
      await settle();
      assert.match(store.getSnapshot().error, /Serverzeit/);
      assert.equal(
        customerMapSnapshot(store.getSnapshot(), now).driverPosition,
        null,
      );
    } finally {
      store.dispose();
    }
  }
});
