import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { createClient } from '@libsql/client';
import { readFileSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import test from 'node:test';
import assert from 'node:assert/strict';
import { sqliteDatabase } from '../db/sqlite.ts';
import { defaultStock } from '../lib/mobility/inventory.ts';
globalThis.boardHash = (v) => createHash('sha256').update(v).digest('hex');
registerHooks({
  load(url, context, next) {
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `
    export class ApiError extends Error {constructor(status,message){super(message);this.status=status;}}
    export const isAdmin=()=>false; export const db=()=>globalThis.boardTest.db, identity=async()=>({userId:globalThis.boardTest.user}), limit=async()=>{};
    export const body=r=>r.json(), json=(v,status=200)=>Response.json(v,{status}), tokenHash=v=>globalThis.boardHash(v);
    export const text=v=>{if(typeof v!=='string'||!v.trim())throw new ApiError(400,'empty');return v.trim()};
    export const handled=async fn=>{try{return await fn()}catch(e){return json({error:e.message},e.status||500)}};
  `,
      };
    return next(url, context);
  },
});
const { POST } = await import('../app/api/mobility/refreshments/route.ts');
const requestId = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const base = {
  id: 'trip',
  action: 'request',
  revision: 0,
  cart: { water: 3 },
  requestId,
};
const send = (body = base) =>
  POST(
    new Request('https://test.invalid/api/mobility/refreshments', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  );
async function fixture() {
  const client = createClient({ url: ':memory:' }),
    db = sqliteDatabase(client);
  const dir = new URL('../drizzle/', import.meta.url);
  for (const n of readdirSync(dir)
    .filter((n) => n.endsWith('.sql'))
    .sort())
    await client.executeMultiple(readFileSync(new URL(n, dir), 'utf8'));
  globalThis.boardTest = { db, user: 'owner' };
  await client.execute(
    "INSERT INTO mobility_bookings(id,quote_id,owner_id,driver_id,vehicle_id,service,price,route,mode,status,created_at,updated_at) VALUES('trip','q','owner','driver','car','premium',1500,'{}','now','riding',0,1)",
  );
  const stock = defaultStock();
  stock.items.water.count = 4;
  await client.execute({
    sql: "INSERT INTO mobility_stock(vehicle_id,data,revision,operation_id,updated_at) VALUES('car',?,0,'initial',0)",
    args: [JSON.stringify(stock)],
  });
  const snapshot = async () => ({
    booking: await db.prepare('SELECT * FROM mobility_bookings').first(),
    stock: await db.prepare('SELECT * FROM mobility_stock').first(),
    moves: (await db.prepare('SELECT * FROM mobility_stock_movements').all())
      .results,
  });
  return { client, db, snapshot, close: () => client.close() };
}
test('lost order response is acknowledged without changing fare, revision, time or stock', async () => {
  const f = await fixture();
  try {
    assert.equal((await send()).status, 200);
    const saved = await f.snapshot();
    assert.equal(JSON.parse(saved.booking.refreshments).revision, 1);
    assert.equal(saved.booking.price, 1500);
    assert.equal(
      (await send({ ...base, cart: { water: 3, cola: 0 } })).status,
      200,
    );
    assert.deepEqual(await f.snapshot(), saved);
  } finally {
    f.close();
  }
});
test('acknowledged order remains acknowledged after actual driver delivery and payment closure', async () => {
  const f = await fixture();
  try {
    assert.equal((await send()).status, 200);
    globalThis.boardTest.user = 'driver';
    assert.equal(
      (
        await send({
          id: 'trip',
          action: 'deliver',
          revision: 1,
          itemId: 'water',
          quantity: 3,
        })
      ).status,
      200,
    );
    let saved = await f.snapshot();
    assert.equal(saved.booking.price, 1750);
    assert.equal(JSON.parse(saved.stock.data).items.water.count, 1);
    assert.equal(saved.moves.length, 1);
    globalThis.boardTest.user = 'owner';
    assert.equal((await send()).status, 200);
    assert.deepEqual(await f.snapshot(), saved);
    await f.client.execute(
      "UPDATE mobility_bookings SET status='completed',payment_status='paid' WHERE id='trip'",
    );
    saved = await f.snapshot();
    assert.equal((await send()).status, 200);
    assert.deepEqual(await f.snapshot(), saved);
  } finally {
    f.close();
  }
});
test('different payload, revision, owner, malformed ID and newer orders cannot be overwritten by retry', async () => {
  const f = await fixture();
  try {
    assert.equal((await send()).status, 200);
    const saved = await f.snapshot();
    for (const patch of [{ cart: { water: 4 } }, { revision: 1 }])
      assert.equal((await send({ ...base, ...patch })).status, 409);
    assert.equal((await send({ ...base, requestId: 'invalid' })).status, 400);
    globalThis.boardTest.user = 'driver';
    assert.equal((await send()).status, 403);
    globalThis.boardTest.user = 'stranger';
    assert.equal((await send()).status, 404);
    assert.deepEqual(await f.snapshot(), saved);
    globalThis.boardTest.user = 'owner';
    assert.equal(
      (
        await send({
          ...base,
          revision: 1,
          requestId: 'bbbbbbbb-bbbb-cccc-dddd-eeeeeeeeeeee',
          cart: { cola: 1 },
        })
      ).status,
      200,
    );
    const newer = await f.snapshot();
    assert.equal((await send()).status, 409);
    assert.deepEqual(await f.snapshot(), newer);
  } finally {
    f.close();
  }
});
test('legacy request clears receipt; legacy driver actions and current free allowances remain compatible', async () => {
  const f = await fixture();
  try {
    assert.equal((await send()).status, 200);
    assert.equal(
      (
        await send({
          id: 'trip',
          action: 'request',
          revision: 1,
          cart: { energy: 2 },
        })
      ).status,
      200,
    );
    const saved = await f.snapshot();
    assert.equal(JSON.parse(saved.booking.refreshments).lastRequest, undefined);
    assert.equal((await send()).status, 409);
    assert.deepEqual(await f.snapshot(), saved);
  } finally {
    f.close();
  }
});
test('receipt and cart roll back together if SQLite rejects the update', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    await f.client.executeMultiple(
      "CREATE TRIGGER board_fail BEFORE UPDATE ON mobility_bookings BEGIN SELECT RAISE(ABORT,'synthetic save error'); END;",
    );
    assert.equal((await send()).status, 500);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute('DROP TRIGGER board_fail');
    assert.equal((await send()).status, 200);
    assert.equal((await send()).status, 200);
  } finally {
    f.close();
  }
});
test('simultaneous identical requests acknowledge one saved revision and never replace it twice', async () => {
  const f = await fixture();
  try {
    const responses = await Promise.all([send(), send()]);
    assert.deepEqual(
      responses.map((r) => r.status),
      [200, 200],
    );
    const saved = await f.snapshot();
    assert.equal(JSON.parse(saved.booking.refreshments).revision, 1);
    assert.equal(saved.moves.length, 0);
  } finally {
    f.close();
  }
});
