import test from 'node:test';
import assert from 'node:assert/strict';
import {
  FleetCreationController,
  availableFleetOwners,
  type FleetCreateData,
  type FleetCreateRequest,
  type FleetCreateStore,
} from '../mobile/src/fleet-creation.ts';
import {
  fleetCreateStore,
  type SecureFleetStorage,
} from '../mobile/src/fleet-creation-store.ts';
const id = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const request: FleetCreateRequest = {
  action: 'create',
  requestId: id,
  name: 'Neue Flotte',
  ownerId: 'staff',
};
const snapshot = (): FleetCreateData => ({
  userId: 'operator',
  canManage: true,
  fleets: [
    {
      id: 'old',
      name: 'Alt',
      owner_id: 'owner',
      deputy_id: 'deputy',
      created_at: 0,
    },
  ],
  employees: [
    {
      user_id: 'owner',
      name: 'Owner',
      fleet_id: 'old',
      role: 'staff',
      can_remove: 1,
    },
    {
      user_id: 'deputy',
      name: 'Deputy',
      fleet_id: null,
      role: 'staff',
      can_remove: 1,
    },
    {
      user_id: 'staff',
      name: 'Team',
      fleet_id: null,
      role: 'staff',
      can_remove: 1,
    },
    {
      user_id: 'busy',
      name: 'Busy',
      fleet_id: null,
      role: 'driver',
      can_remove: 0,
    },
  ],
});
const defer = <T>() => {
  let resolve!: (v: T) => void;
  const promise = new Promise<T>((r) => (resolve = r));
  return { resolve, promise };
};
const error = (status: number) =>
  Object.assign(new Error('Synthetic'), { status });
function store(value: FleetCreateRequest | null = null) {
  let pending = value;
  return {
    load: async () => pending,
    save: async (v: FleetCreateRequest) => {
      pending = { ...v };
    },
    clear: async (expected: string) => {
      if (pending?.requestId === expected) pending = null;
    },
    value: () => pending,
  };
}
async function ready(c: FleetCreationController) {
  await c.restore();
  c.setActive(true);
  await c.refresh();
  c.edit('  Neue Flotte  ', 'staff');
}
void test('fleet creation requires exact current operator, fresh active data and an eligible unassigned owner', async () => {
  let data = snapshot();
  const c = new FleetCreationController(
    'operator',
    store(),
    async () => data,
    async () => ({ id, name: request.name }),
    () => id,
  );
  await ready(c);
  assert.equal(c.canSubmit(), true);
  assert.deepEqual(
    availableFleetOwners(data).map((e) => e.user_id),
    ['operator', 'staff'],
  );
  for (const owner of ['owner', 'deputy', 'busy', 'missing']) {
    c.edit('Test', owner);
    assert.equal(c.canSubmit(), false);
  }
  c.edit('Test', 'staff');
  assert.equal(c.canSubmit(Date.now() + 30001), false);
  c.setActive(false);
  assert.equal(c.canSubmit(), false);
  c.setActive(true);
  await c.refresh();
  data = { ...data, canManage: false };
  await c.refresh();
  assert.equal(c.getSnapshot().data, null);
  assert.equal(c.canSubmit(), false);
  data = { ...snapshot(), userId: 'other-account' };
  await c.refresh();
  assert.equal(c.getSnapshot().data, null);
  c.dispose();
});
void test('persist exact UUID and body before HTTP; lost response and process restart never auto-submit or change draft', async () => {
  const disk = store();
  let sent = 0,
    uuids = 0;
  const writes: FleetCreateRequest[] = [];
  const make = () =>
    new FleetCreationController(
      'operator',
      disk,
      async () => snapshot(),
      async (body) => {
        assert.deepEqual(disk.value(), body);
        sent++;
        writes.push({ ...body });
        throw new Error('Lost');
      },
      () => {
        uuids++;
        return id;
      },
    );
  const c = make();
  await ready(c);
  await c.submit();
  c.edit('Andere Flotte', 'operator');
  assert.deepEqual(c.getSnapshot().pending, request);
  assert.equal(c.getSnapshot().discardable, false);
  assert.equal(sent, 1);
  c.dispose();
  const next = make();
  await next.restore();
  next.setActive(true);
  await next.refresh();
  assert.equal(sent, 1);
  assert.equal(next.canSubmit(), true);
  await next.submit();
  assert.deepEqual(writes, [request, request]);
  assert.equal(uuids, 1);
  next.dispose();
});
void test('failed disk save prevents HTTP and locks same ID until explicit local completion', async () => {
  let sent = 0,
    fail = true;
  const disk = store(),
    storage: FleetCreateStore = {
      ...disk,
      save: async (body) => {
        if (fail) throw new Error('Disk');
        await disk.save(body);
      },
    };
  const c = new FleetCreationController(
    'operator',
    storage,
    async () => snapshot(),
    async () => {
      sent++;
      return { id, name: request.name };
    },
    () => id,
  );
  await ready(c);
  await c.submit();
  assert.equal(sent, 0);
  assert.equal(c.getSnapshot().pending?.requestId, id);
  assert.equal(c.getSnapshot().discardable, true);
  fail = false;
  await c.submit();
  assert.equal(sent, 1);
  assert.equal(c.getSnapshot().confirmed?.id, id);
  assert.equal(disk.value(), null);
  c.dispose();
});
void test('writing survives background, prevents parallel submission and publishes actual confirmation only', async () => {
  const wait = defer<{ id: string; name: string }>();
  let writes = 0;
  const c = new FleetCreationController(
    'operator',
    store(),
    async () => snapshot(),
    async () => {
      writes++;
      return wait.promise;
    },
    () => id,
  );
  await ready(c);
  const task = c.submit();
  await Promise.resolve();
  await Promise.resolve();
  assert.equal(c.getSnapshot().confirmed, null);
  await c.submit();
  assert.equal(writes, 1);
  c.setActive(false);
  wait.resolve({ id, name: request.name });
  await task;
  assert.equal(c.getSnapshot().confirmed?.name, request.name);
  assert.equal(c.getSnapshot().pending, null);
  c.dispose();
});
void test('fresh matching server record restores success without POST; renamed or transferred record does not', async () => {
  for (const mismatch of [false, true]) {
    const disk = store(request);
    let writes = 0;
    const data = snapshot();
    data.fleets.push({
      id,
      name: mismatch ? 'Renamed' : request.name,
      owner_id: mismatch ? 'other' : request.ownerId,
      deputy_id: null,
      created_at: 0,
    });
    const c = new FleetCreationController(
      'operator',
      disk,
      async () => data,
      async () => {
        writes++;
        return { id, name: request.name };
      },
      () => id,
    );
    await c.restore();
    c.setActive(true);
    await c.refresh();
    assert.equal(writes, 0);
    assert.equal(!!c.getSnapshot().confirmed, !mismatch);
    assert.equal(!!disk.value(), mismatch);
    assert.equal(c.getSnapshot().discardable, false);
    c.dispose();
  }
});
void test('confirmed server write stays successful when refresh or local cleanup fails, without another HTTP write', async () => {
  let failLoad = false,
    failClear = true,
    writes = 0;
  const disk = store();
  const c = new FleetCreationController(
    'operator',
    {
      ...disk,
      clear: async (x) => {
        if (failClear) throw new Error('Disk');
        await disk.clear(x);
      },
    },
    async () => {
      if (failLoad) throw error(503);
      return snapshot();
    },
    async () => {
      writes++;
      failLoad = true;
      return { id, name: request.name };
    },
    () => id,
  );
  await ready(c);
  await c.submit();
  assert.equal(c.getSnapshot().confirmed?.id, id);
  assert.equal(c.getSnapshot().pending?.requestId, id);
  assert.equal(c.canSubmit(), false);
  assert.match(c.getSnapshot().error, /Flotte ist bestätigt/);
  failClear = false;
  await c.finishConfirmed();
  assert.equal(c.getSnapshot().pending, null);
  assert.equal(writes, 1);
  c.dispose();
});
void test('known rejection allows explicit local discard but uncertain or incomplete response never does', async () => {
  for (const code of [409, 503, 0]) {
    const disk = store();
    const c = new FleetCreationController(
      'operator',
      disk,
      async () => snapshot(),
      async () => {
        if (code) throw error(code);
        return { id: 'wrong', name: request.name };
      },
      () => id,
    );
    await ready(c);
    await c.submit();
    assert.equal(c.canDiscard(), code === 409);
    await c.discard();
    assert.equal(!!disk.value(), code !== 409);
    assert.equal(c.getSnapshot().confirmed, null);
    c.dispose();
  }
});
void test('late reads/finally and disposal cannot overwrite a newer foreground snapshot or send after pending save', async () => {
  const old = defer<FleetCreateData>(),
    fresh = defer<FleetCreateData>();
  let reads = 0;
  const disk = store();
  const c = new FleetCreationController(
    'operator',
    disk,
    async () => (++reads === 1 ? old.promise : fresh.promise),
    async () => ({ id, name: request.name }),
    () => id,
  );
  await c.restore();
  c.setActive(true);
  await Promise.resolve();
  c.setActive(false);
  c.setActive(true);
  await Promise.resolve();
  old.resolve(snapshot());
  await Promise.resolve();
  assert.equal(c.getSnapshot().loading, true);
  const data = snapshot();
  data.employees = [];
  fresh.resolve(data);
  await c.refresh();
  assert.deepEqual(c.getSnapshot().data?.employees, []);
  c.dispose();
  const saved = defer<void>();
  let writes = 0;
  const next = new FleetCreationController(
    'operator',
    { ...disk, save: () => saved.promise },
    async () => snapshot(),
    async () => {
      writes++;
      return { id, name: request.name };
    },
    () => id,
  );
  await ready(next);
  const task = next.submit();
  next.dispose();
  saved.resolve();
  await task;
  assert.equal(writes, 0);
  assert.equal(next.getSnapshot().confirmed, null);
});
void test('restore failure keeps mutations locked and can be explicitly retried without any POST', async () => {
  let fail = true;
  const disk = store(request);
  const c = new FleetCreationController(
    'operator',
    {
      ...disk,
      load: async () => {
        if (fail) throw new Error('Disk');
        return disk.load();
      },
    },
    async () => snapshot(),
    async () => ({ id, name: request.name }),
    () => id,
  );
  await c.restore();
  c.setActive(true);
  await c.refresh();
  assert.equal(c.canSubmit(), false);
  fail = false;
  await c.restore();
  assert.deepEqual(c.getSnapshot().pending, request);
  assert.equal(c.canSubmit(), true);
  c.dispose();
});
function storage() {
  const values = new Map<string, string>();
  const api: SecureFleetStorage = {
    getItemAsync: async (key) => values.get(key) || null,
    setItemAsync: async (key, value) => {
      values.set(key, value);
    },
    deleteItemAsync: async (key) => {
      values.delete(key);
    },
  };
  return { api, values };
}
void test('protected store is account-bound, rejects other open bodies and malformed persisted records', async () => {
  const disk = storage(),
    a = fleetCreateStore(disk.api, 'a'),
    b = fleetCreateStore(disk.api, 'b');
  await a.save(request);
  assert.equal(await b.load(), null);
  await assert.rejects(a.save({ ...request, name: 'Changed' }));
  assert.deepEqual(await a.load(), request);
  const key = [...disk.values.keys()][0];
  disk.values.set(
    key,
    JSON.stringify({ version: 1, accountId: 'wrong', request }),
  );
  await assert.rejects(a.load());
  await assert.rejects(a.save(request));
});
void test('serialized store keeps new request safe from old cleanup and concurrent saves', async () => {
  const disk = storage(),
    a = fleetCreateStore(disk.api, 'a'),
    next = { ...request, requestId: '11111111-2222-3333-4444-555555555555' };
  await a.save(request);
  await Promise.all([a.clear(id), a.save(next), a.clear(id)]);
  assert.deepEqual(await a.load(), next);
  const results = await Promise.allSettled([a.save(next), a.save(request)]);
  assert.equal(results[0].status, 'fulfilled');
  assert.equal(results[1].status, 'rejected');
  assert.deepEqual(await a.load(), next);
});
void test('store write errors remain errors and do not release existing request after failed delete', async () => {
  const disk = storage(),
    a = fleetCreateStore(disk.api, 'a');
  await a.save(request);
  disk.api.deleteItemAsync = async () => {
    throw new Error('Locked');
  };
  await assert.rejects(a.clear(id));
  assert.deepEqual(await a.load(), request);
});
