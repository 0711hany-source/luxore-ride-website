import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
const store = new Map([['luxore-account-v1', 'a'.repeat(64)]]);
globalThis.nativeViewStore = store;
globalThis.require = () => 1; // Metro resolves static PNG assets in real APKs.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    'expo-location',
    `export const Accuracy={High:4}; export const requestForegroundPermissionsAsync=async()=>({status:'denied'}),getCurrentPositionAsync=async()=>{throw new Error('GPS not enabled in view tests')};`,
  ],
  [
    'react-native',
    `
    export const View='View', Text='Text', Pressable='Pressable', ScrollView='ScrollView', Modal='Modal', Image='Image', TextInput='TextInput', KeyboardAvoidingView='KeyboardAvoidingView', ActivityIndicator='ActivityIndicator';
    export const Platform={OS:'android'}, StyleSheet={create:v=>v}, Keyboard={dismiss(){}}, Share={async share(){}}, Linking={async openURL(){},async openSettings(){}}, Alert={alert(){}};
    export const AppState={currentState:'active',addEventListener(){return {remove(){}}}}, BackHandler={addEventListener(){return {remove(){}}}};
    export const useWindowDimensions=()=>({width:390,height:844});
    export const PanResponder={create:handlers=>({panHandlers:handlers})};
    export const Animated={Value:class {constructor(v){this.value=v}setValue(v){this.value=v}},View:'AnimatedView',spring:(v,o)=>({start:()=>v.setValue(o.toValue)})};
  `,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaProvider='SafeAreaProvider', SafeAreaView='SafeAreaView';`,
  ],
  ['expo-status-bar', `export const StatusBar='StatusBar';`],
  ['expo-constants', `export default {expoConfig:{extra:{variant:'driver'}}};`],
  [
    'expo-secure-store',
    `export const getItemAsync=async k=>globalThis.nativeViewStore.get(k)||null,setItemAsync=async(k,v)=>{globalThis.nativeViewStore.set(k,v)},deleteItemAsync=async k=>{globalThis.nativeViewStore.delete(k)};`,
  ],
  [
    'expo-crypto',
    `export const randomUUID=()=> 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';`,
  ],
  [
    'expo-notifications',
    `export const getLastNotificationResponse=()=>null,clearLastNotificationResponse=()=>{},addNotificationResponseReceivedListener=()=>({remove(){}});`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',ArrowRight='ArrowRight', CalendarDays='CalendarDays', CarFront='CarFront', Check='Check', ChevronRight='ChevronRight', CircleHelp='CircleHelp', Home='Home', LogOut='LogOut', Mail='Mail', MapPinned='MapPinned', MapPin='MapPin', Clock3='Clock3', Settings='Settings', ShieldCheck='ShieldCheck', UserRound='UserRound', Users='Users',ChevronDown='ChevronDown',LocateFixed='LocateFixed',Navigation='Navigation',Phone='Phone',RefreshCw='RefreshCw',X='X',Plus='Plus',Minus='Minus',Search='Search';`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    let source = mocked.get(specifier);
    if (specifier === 'react-native-webview')
      source = `import React,{forwardRef,useImperativeHandle} from 'react';export const WebView=forwardRef((props,ref)=>{useImperativeHandle(ref,()=>({injectJavaScript:s=>globalThis.pauseView.messages.push(s)}));return React.createElement('WebProbe',props)});`;
    if (specifier === './location-service')
      source = `export const foregroundPermission=async()=>{throw Error('No synthetic GPS')},locationStatus=async()=>({active:false}),resumeLocation=locationStatus,point=x=>x,startLocation=async()=>{},stopLocation=async()=>{globalThis.pauseView.stops++;return globalThis.pauseView.result}`;
    if (specifier === './offer-alerts')
      source = `export const testAlert=async()=>{};`;
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
  load(url, c, next) {
    if (
      url.endsWith('/mobile/src/RideWorkspace.tsx') &&
      process.env.TEST_ORIGINAL_PAUSE_VIEW
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_PAUSE_VIEW, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
              jsx: ts.JsxEmit.ReactJSX,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: RideWorkspace } =
  await import('../mobile/src/RideWorkspace.tsx');
const settle = async () => {
  for (let i = 0; i < 3; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
};
async function render(result) {
  globalThis.pauseView = { result, stops: 0, messages: [] };
  let view;
  await act(async () => {
    view = Renderer.create(
      React.createElement(RideWorkspace, {
        path: '/mobile/driver',
        sessionToken: 'a'.repeat(64),
        onAccount() {},
        active: true,
      }),
    );
  });
  await settle();
  return view;
}
for (const confirmed of [false, true])
  void test(
    'actual failed-renderer recovery reports ' +
      (confirmed
        ? 'confirmed server pause'
        : 'unconfirmed server pause separately from stopped local GPS'),
    async () => {
      const view = await render({ active: false, serverStopped: confirmed });
      try {
        await act(async () => view.root.findByType('WebProbe').props.onError());
        const button = view.root
          .findAllByType('Pressable')
          .find((n) =>
            JSON.stringify(
              n.toJSON?.() ??
                n.findAllByType('Text').map((t) => t.props.children),
            ).includes('Standortübertragung beenden'),
          );
        assert.ok(button);
        await act(async () => button.props.onPress());
        await settle();
        const text = JSON.stringify(view.toJSON());
        assert.equal(globalThis.pauseView.stops, 1);
        if (confirmed)
          assert.match(text, /Pausenmeldung wurde vom Server bestätigt/);
        else {
          assert.match(text, /Server-Offlinezustand ist nicht bestätigt/);
          assert.match(text, /auf diesem Gerät beendet/);
          assert.doesNotMatch(text, /Pausenmeldung wurde vom Server bestätigt/);
        }
      } finally {
        await act(async () => view.unmount());
      }
    },
  );
void test('actual native bridge preserves local stop and unconfirmed server result without inventing offline success', async () => {
  const view = await render({ active: false, serverStopped: false });
  try {
    await act(async () =>
      view.root
        .findByType('WebProbe')
        .props.onMessage({
          nativeEvent: {
            url: 'https://luxoreride.de/mobile/driver',
            data: JSON.stringify({
              type: 'luxore-location',
              action: 'stop',
              requestId: 'pause-a',
            }),
          },
        }),
    );
    const reply = globalThis.pauseView.messages.find((s) =>
      s.includes('pause-a'),
    );
    assert.ok(reply);
    assert.match(reply, /"serverStopped":false/);
    assert.match(reply, /"active":false/);
    assert.equal(globalThis.pauseView.stops, 1);
  } finally {
    await act(async () => view.unmount());
  }
});
