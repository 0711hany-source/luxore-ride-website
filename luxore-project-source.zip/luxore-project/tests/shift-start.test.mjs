import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  load(url, context, next) {
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `
        export class ApiError extends Error {constructor(status,message){super(message);this.status=status;}}
        export const db=()=>globalThis.shiftTest.db;
        export const identity=async()=>({userId:globalThis.shiftTest.user});
        export const isAdmin=()=>false;
        export const limit=async()=>{};
        export const body=request=>request.json();
        export const json=(value,status=200)=>Response.json(value,{status});
        export const text=value=>{if(typeof value!=='string'||!value.trim())throw new ApiError(400,'empty');return value.trim();};
        export const tokenHash=value=>globalThis.shiftTest.hash(value);
        export const handled=async work=>{try{return await work();}catch(e){return json({error:e.message},e.status||500);}};
      `,
      };
    return next(url, context);
  },
});
const { POST: start } = await import('../app/api/mobility/driver/route.ts');
const { POST: locate } = await import('../app/api/mobility/location/route.ts');
const digest = async (value) =>
  Array.from(
    new Uint8Array(
      await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value)),
    ),
    (b) => b.toString(16).padStart(2, '0'),
  ).join('');
const oldToken = 'a'.repeat(64);
function fixture() {
  const sqlite = new DatabaseSync(':memory:');
  const dir = new URL('../drizzle/', import.meta.url);
  for (const file of readdirSync(dir)
    .filter((f) => f.endsWith('.sql'))
    .sort())
    sqlite.exec(readFileSync(new URL(file, dir), 'utf8'));
  const db = {
    prepare(sql) {
      return {
        sql,
        values: [],
        bind(...args) {
          this.values = args;
          return this;
        },
        async first() {
          return sqlite.prepare(sql).get(...this.values) || null;
        },
        async all() {
          return { results: sqlite.prepare(sql).all(...this.values) };
        },
        async run() {
          const r = sqlite.prepare(sql).run(...this.values);
          return { meta: { changes: Number(r.changes) } };
        },
      };
    },
    async batch(statements) {
      // Match the application's libSQL write transaction: no statement may
      // interleave with another batch, and an insert failure rolls back all.
      sqlite.exec('BEGIN');
      try {
        const results = statements.map((s) => ({
          meta: {
            changes: Number(sqlite.prepare(s.sql).run(...s.values).changes),
          },
        }));
        sqlite.exec('COMMIT');
        return results;
      } catch (e) {
        sqlite.exec('ROLLBACK');
        throw e;
      }
    },
  };
  globalThis.shiftTest = { db, user: 'driver-a', hash: digest };
  for (const id of ['a', 'b']) {
    sqlite
      .prepare('INSERT INTO mobility_fleets(id,name,created_at) VALUES(?,?,0)')
      .run('fleet-' + id, 'TEST ' + id);
    sqlite
      .prepare(
        'INSERT INTO mobility_employees(user_id,name,phone,fleet_id,created_at) VALUES(?,?,?,?,0)',
      )
      .run('driver-' + id, 'TEST', '000000', 'fleet-' + id);
    sqlite
      .prepare(
        "INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES(?,?,?,?,'[\"premium\"]','active',0)",
      )
      .run('car-' + id, 'fleet-' + id, 'TEST', 'TEST ' + id);
    sqlite
      .prepare(
        "INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,services,approved,online,vehicle_id,session_id,lat,lng,accuracy,location_at) VALUES(?,'TEST','000000','TEST',?,'premium','[\"premium\"]',1,1,?,'old-shift',50.11,8.68,6,?)",
      )
      .run('driver-' + id, 'TEST ' + id, 'car-' + id, Date.now());
  }
  const read = () =>
    sqlite.prepare("SELECT * FROM mobility_drivers WHERE id='driver-a'").get();
  const sessions = () =>
    sqlite
      .prepare(
        "SELECT * FROM mobility_location_sessions WHERE driver_id='driver-a' ORDER BY token_hash",
      )
      .all();
  return { sqlite, read, sessions, close: () => sqlite.close() };
}
async function seed(f) {
  f.sqlite
    .prepare(
      "INSERT INTO mobility_location_sessions(token_hash,driver_id,session_id,expires_at) VALUES(?,'driver-a','old-shift',?)",
    )
    .run(await digest(oldToken), Date.now() + 3600000);
}
const request = (data) =>
  new Request('https://test.invalid/api/mobility/driver', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
const online = () => start(request({ action: 'online', native: true }));
const fix = (token) =>
  locate(
    new Request('https://test.invalid/api/mobility/location', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        authorization: 'Bearer ' + token,
      },
      body: JSON.stringify({
        lat: 50.112,
        lng: 8.681,
        accuracy: 6,
        timestamp: Date.now(),
      }),
    }),
  );
function pausedHash() {
  let enter, release;
  const entered = new Promise((r) => {
    enter = r;
  });
  const gate = new Promise((r) => {
    release = r;
  });
  let first = true;
  globalThis.shiftTest.hash = async (value) => {
    if (first) {
      first = false;
      enter();
      await gate;
    }
    return digest(value);
  };
  return { entered, release };
}

test('overlapping native starts retain a credential for the winning shift and accept its background GPS', async () => {
  const f = fixture();
  let pause;
  try {
    await seed(f);
    pause = pausedHash();
    const first = online();
    await pause.entered;
    const secondResponse = await online();
    assert.equal(secondResponse.status, 200);
    const second = await secondResponse.json();
    pause.release();
    const firstResponse = await first;
    assert.equal(firstResponse.status, 200);
    const credentials = [await firstResponse.json(), second];
    const current = credentials.find(
      (c) => c.sessionId === f.read().session_id,
    );
    assert.ok(current);
    assert.equal(f.sessions().length, 1);
    assert.equal(f.sessions()[0].session_id, current.sessionId);
    assert.equal(f.sessions()[0].token_hash, await digest(current.nativeToken));
    assert.equal((await fix(current.nativeToken)).status, 200);
    assert.equal(f.read().online, 1);
    assert.equal(f.read().lat, 50.112);
    const superseded = credentials.find((c) => c !== current);
    const before = f.read();
    assert.equal((await fix(superseded.nativeToken)).status, 401);
    assert.deepEqual(f.read(), before);
  } finally {
    pause?.release();
    f.close();
  }
});

test('native credential insert failure rolls back rotation and preserves the working GPS session', async () => {
  const f = fixture();
  try {
    await seed(f);
    f.sqlite.exec(
      "CREATE TRIGGER reject_test_credentials BEFORE INSERT ON mobility_location_sessions BEGIN SELECT RAISE(ABORT,'synthetic insert failure'); END;",
    );
    const before = f.read(),
      credentials = f.sessions();
    assert.equal((await online()).status, 500);
    assert.deepEqual(f.read(), before);
    assert.deepEqual(f.sessions(), credentials);
    assert.equal((await fix(oldToken)).status, 200);
  } finally {
    f.close();
  }
});

test('pending credential hashing keeps the existing shift usable until rotation commits', async () => {
  const f = fixture();
  let pause;
  try {
    await seed(f);
    pause = pausedHash();
    const before = f.read(),
      credentials = f.sessions();
    const pending = online();
    await pause.entered;
    assert.deepEqual(f.read(), before);
    assert.deepEqual(f.sessions(), credentials);
    assert.equal((await fix(oldToken)).status, 200);
    pause.release();
    assert.equal((await pending).status, 200);
  } finally {
    pause?.release();
    f.close();
  }
});

test('vehicle archived during credential preparation rejects start without destroying the previous session', async () => {
  const f = fixture();
  let pause;
  try {
    await seed(f);
    pause = pausedHash();
    const before = f.read(),
      credentials = f.sessions();
    const pending = online();
    await pause.entered;
    f.sqlite
      .prepare(
        "UPDATE mobility_vehicles SET status='archived' WHERE id='car-a'",
      )
      .run();
    pause.release();
    assert.equal((await pending).status, 409);
    assert.deepEqual(f.read(), before);
    assert.deepEqual(f.sessions(), credentials);
  } finally {
    pause?.release();
    f.close();
  }
});

test('driver approval revoked during preparation cannot create a new native credential', async () => {
  const f = fixture();
  let pause;
  try {
    await seed(f);
    pause = pausedHash();
    const credentials = f.sessions();
    const pending = online();
    await pause.entered;
    f.sqlite
      .prepare("UPDATE mobility_drivers SET approved=0 WHERE id='driver-a'")
      .run();
    const before = f.read();
    pause.release();
    assert.equal((await pending).status, 409);
    assert.deepEqual(f.read(), before);
    assert.deepEqual(f.sessions(), credentials);
  } finally {
    pause?.release();
    f.close();
  }
});

test('foreign-fleet vehicle and unapproved driver cannot start; no tokens are issued', async () => {
  for (const mode of ['foreign', 'unapproved']) {
    const f = fixture();
    try {
      f.sqlite
        .prepare(
          "UPDATE mobility_drivers SET vehicle_id=NULL WHERE id='driver-b'",
        )
        .run();
      if (mode === 'foreign')
        f.sqlite
          .prepare(
            "UPDATE mobility_drivers SET vehicle_id='car-b' WHERE id='driver-a'",
          )
          .run();
      else
        f.sqlite
          .prepare("UPDATE mobility_drivers SET approved=0 WHERE id='driver-a'")
          .run();
      const before = f.read();
      assert.equal((await online()).status, mode === 'foreign' ? 409 : 403);
      assert.deepEqual(f.read(), before);
      assert.equal(f.sessions().length, 0);
    } finally {
      f.close();
    }
  }
});

test('web shift rotation revokes only superseded credentials and preserves another driver live session', async () => {
  const f = fixture();
  try {
    await seed(f);
    const otherToken = 'b'.repeat(64);
    f.sqlite
      .prepare(
        "INSERT INTO mobility_location_sessions(token_hash,driver_id,session_id,expires_at) VALUES(?,'driver-b','old-shift',?)",
      )
      .run(await digest(otherToken), Date.now() + 3600000);
    const response = await start(request({ action: 'online' }));
    assert.equal(response.status, 200);
    const body = await response.json();
    assert.equal(body.sessionId, f.read().session_id);
    assert.equal(body.nativeToken, undefined);
    assert.equal(f.sessions().length, 0);
    assert.equal((await fix(oldToken)).status, 401);
    assert.equal((await fix(otherToken)).status, 200);
  } finally {
    f.close();
  }
});
