import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  defaultStock,
  validateStock,
  shoppingList,
  stockUsage,
  moveStock,
} from '../lib/mobility/inventory.ts';
test('vehicle starts uncounted; targets fit 24 cooling slots and eight small snacks', () => {
  const stock = validateStock(defaultStock());
  assert.deepEqual(stockUsage(stock, 'count'), { drink: 0, snack: 0 });
  assert.deepEqual(stockUsage(stock, 'target'), { drink: 24, snack: 8 });
  assert.equal(
    shoppingList(stock).reduce((n, i) => n + i.quantity, 0),
    26,
  );
});
test('low-stock reminder triggers at the threshold and shopping list tops up each item', () => {
  const stock = defaultStock();
  for (const s of Object.values(stock.items)) s.count = s.target;
  assert.deepEqual(shoppingList(stock), []);
  const next = moveStock(stock, { water: 2, cola: 1 }, -1),
    list = shoppingList(next);
  assert.deepEqual(
    list.map((i) => [i.id, i.quantity, i.urgent]),
    [
      ['water', 2, true],
      ['cola', 1, false],
    ],
  );
  assert.equal(stock.items.water.count, 3);
  assert.deepEqual(shoppingList(moveStock(next, { water: 2, cola: 1 }, 1)), []);
});
test('reject invalid counts, overfilled storage and wrong reorder thresholds', () => {
  for (const v of [-1, 1.5, NaN, 101]) {
    const s = defaultStock();
    s.items.water.count = v;
    assert.throws(() => validateStock(s));
  }
  const s = defaultStock();
  s.items.cola.target = 5;
  assert.throws(() => validateStock(s), /Stauraum/);
  s.items.cola.target = 4;
  s.items.cookies.count = 9;
  assert.throws(() => validateStock(s), /Stauraum/);
  s.items.cookies.count = 0;
  s.items.cola.minimum = 4;
  assert.throws(() => validateStock(s), /Meldeschwelle/);
});
test('personal consumption and handover cannot make negative stock; unknown items rejected', () => {
  const s = defaultStock();
  assert.throws(() => moveStock(s, { water: 1 }, -1), /Nicht genug/);
  for (const q of [
    { water: 0 },
    { water: 1.2 },
    { water: -1 },
    { unknown: 1 },
    {},
  ])
    assert.throws(() => moveStock(s, q, 1));
  s.items.cola.target = 0;
  s.items.cola.minimum = 0;
  assert.equal(
    shoppingList(validateStock(s)).some((i) => i.id === 'cola'),
    false,
  );
});
