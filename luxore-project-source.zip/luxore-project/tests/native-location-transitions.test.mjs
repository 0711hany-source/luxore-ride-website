import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
const virtual = (source) => ({
  url: 'data:text/javascript,' + encodeURIComponent(source),
  shortCircuit: true,
});
registerHooks({
  resolve(s, c, next) {
    if (s === 'expo-location')
      return virtual(
        `export const Accuracy={High:4,BestForNavigation:6};export const requestForegroundPermissionsAsync=async()=>({granted:true}),getBackgroundPermissionsAsync=()=>globalThis.transitionFixture.permission(),requestBackgroundPermissionsAsync=async()=>({granted:true}),hasStartedLocationUpdatesAsync=async()=>globalThis.transitionFixture.started,startLocationUpdatesAsync=()=>globalThis.transitionFixture.start(),stopLocationUpdatesAsync=async()=>{globalThis.transitionFixture.stops++;globalThis.transitionFixture.started=false},getCurrentPositionAsync=()=>{globalThis.transitionFixture.initial++;return new Promise(()=>{})};`,
      );
    if (s === 'expo-task-manager')
      return virtual(`export const defineTask=()=>{};`);
    if (s === 'expo-secure-store')
      return virtual(
        `export const getItemAsync=async k=>globalThis.transitionFixture.store.get(k)||null,setItemAsync=(k,v)=>globalThis.transitionFixture.set(k,v),deleteItemAsync=k=>globalThis.transitionFixture.remove(k);`,
      );
    if (s === 'react-native')
      return virtual(
        `export const Alert={alert(){throw Error('Unexpected permission request')}};`,
      );
    if (s === './offer-alerts')
      return virtual(
        `export const offerAlerts={clear:()=>globalThis.transitionFixture.clear(),sync:async()=>{}},alertStatus=async()=>({enabled:true,sound:true}),requestAlerts=async()=>({enabled:true,sound:true});`,
      );
    return next(s, c);
  },
  load(url, c, next) {
    if (
      url.endsWith('/mobile/src/location-service.ts') &&
      process.env.TEST_ORIGINAL_LOCATION_SERVICE
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_LOCATION_SERVICE, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
const service = await import('../mobile/src/location-service.ts');
const key = 'luxore-driver-location-session',
  positionKey = 'luxore-driver-background-position';
const credential = (id = 'old', token = 'a') => ({
  sessionId: id,
  nativeToken: token.repeat(64),
  expiresAt: Date.now() + 3600000,
});
const defer = () => {
  let resolve;
  const promise = new Promise((r) => {
    resolve = r;
  });
  return { promise, resolve };
};
const flush = async () => {
  for (let i = 0; i < 8; i++) await new Promise((r) => setImmediate(r));
};
const outcome = (p) =>
  p.then(
    (value) => ({ value }),
    (error) => ({ error }),
  );
const originalFetch = globalThis.fetch;
function fixture() {
  const f = {
    store: new Map(),
    started: false,
    starts: [],
    stops: 0,
    initial: 0,
    writes: [],
    capWrites: [],
    permission: async () => ({ granted: true }),
    clear: async () => {},
  };
  f.set = async (k, v) => {
    if (k === key) f.capWrites.push(JSON.parse(v));
    f.store.set(k, v);
  };
  f.remove = async (k) => {
    f.store.delete(k);
  };
  f.start = async () => {
    f.starts.push(JSON.parse(f.store.get(key)));
    f.started = true;
  };
  globalThis.transitionFixture = f;
  globalThis.fetch = async (_url, o) => {
    f.writes.push({ token: o.headers.Authorization, body: JSON.parse(o.body) });
    return Response.json({ ok: true });
  };
  return f;
}
async function clean(f) {
  f.clear = async () => {};
  f.permission = async () => ({ granted: true });
  await service.stopLocation(false);
  globalThis.fetch = originalFetch;
}
void test('pause while old start awaits alert cleanup prevents any old capability write or native GPS start', async () => {
  const f = fixture(),
    gate = defer();
  let calls = 0;
  f.clear = () => (++calls === 1 ? gate.promise : Promise.resolve());
  const old = outcome(service.startLocation(credential()));
  let pause;
  try {
    await flush();
    assert.equal(calls, 1);
    pause = service.stopLocation();
    gate.resolve();
    const result = await old;
    await pause;
    assert.deepEqual(f.starts, []);
    assert.deepEqual(f.capWrites, []);
    assert.match(result.error?.message || '', /inzwischen beendet/);
    assert.equal(f.store.has(key), false);
  } finally {
    gate.resolve();
    await old;
    await pause;
    await clean(f);
  }
});
void test('renewed same-session start during old alert cleanup starts only the newest capability', async () => {
  const f = fixture(),
    gate = defer();
  let calls = 0;
  f.clear = () => (++calls === 1 ? gate.promise : Promise.resolve());
  const old = outcome(service.startLocation(credential()));
  let next;
  try {
    await flush();
    next = service.startLocation(credential('old', 'b'));
    gate.resolve();
    const result = await old;
    await next;
    assert.deepEqual(
      f.starts.map((c) => c.nativeToken),
      ['b'.repeat(64)],
    );
    assert.deepEqual(
      f.capWrites.map((c) => c.nativeToken),
      ['b'.repeat(64)],
    );
    assert.match(result.error?.message || '', /inzwischen beendet/);
    assert.equal((await service.locationStatus()).active, true);
  } finally {
    gate.resolve();
    await old;
    await next;
    await clean(f);
  }
});
void test('pause during old cache deletion prevents subsequent credential persistence and native start', async () => {
  const f = fixture(),
    gate = defer();
  let removes = 0;
  f.remove = async (k) => {
    if (k === positionKey && ++removes === 1) await gate.promise;
    f.store.delete(k);
  };
  const old = outcome(service.startLocation(credential()));
  let pause;
  try {
    await flush();
    assert.equal(removes, 1);
    pause = service.stopLocation();
    gate.resolve();
    const result = await old;
    await pause;
    assert.deepEqual(f.capWrites, []);
    assert.deepEqual(f.starts, []);
    assert.match(result.error?.message || '', /inzwischen beendet/);
  } finally {
    gate.resolve();
    await old;
    await pause;
    await clean(f);
  }
});
void test('new shift during already-started credential persistence prevents old native start and preserves new credential', async () => {
  const f = fixture(),
    gate = defer();
  let sets = 0;
  const set = f.set;
  f.set = async (k, v) => {
    if (k === key && ++sets === 1) await gate.promise;
    await set(k, v);
  };
  const old = outcome(service.startLocation(credential()));
  let next;
  try {
    await flush();
    assert.equal(sets, 1);
    next = service.startLocation(credential('new', 'b'));
    gate.resolve();
    const result = await old;
    await next;
    assert.deepEqual(
      f.starts.map((c) => c.sessionId),
      ['new'],
    );
    assert.match(result.error?.message || '', /inzwischen beendet/);
    assert.equal(JSON.parse(f.store.get(key)).sessionId, 'new');
    assert.equal(f.started, true);
    assert.equal(f.writes.length, 0);
  } finally {
    gate.resolve();
    await old;
    await next;
    await clean(f);
  }
});
void test('pause during native GPS start rejects old completion and skips initial query while serialized pause stops actual service', async () => {
  const f = fixture(),
    gate = defer();
  const start = f.start;
  let entered = false;
  f.start = async () => {
    entered = true;
    await gate.promise;
    await start();
  };
  const old = outcome(service.startLocation(credential()));
  let pause;
  try {
    await flush();
    assert.equal(entered, true);
    pause = service.stopLocation();
    gate.resolve();
    const result = await old;
    await pause;
    assert.match(result.error?.message || '', /inzwischen beendet/);
    assert.equal(f.initial, 0);
    assert.equal(f.started, false);
    assert.equal(f.store.has(key), false);
    assert.equal(f.stops, 1);
    assert.deepEqual(f.writes, [
      { token: 'Bearer ' + 'a'.repeat(64), body: { action: 'stop' } },
    ]);
  } finally {
    gate.resolve();
    await old;
    await pause;
    await clean(f);
  }
});
void test('resume waiting for background permission cannot restart GPS after pause begins', async () => {
  const f = fixture(),
    gate = defer();
  f.store.set(key, JSON.stringify(credential()));
  f.permission = () => gate.promise;
  const resume = service.resumeLocation();
  let pause;
  try {
    await flush();
    pause = service.stopLocation();
    gate.resolve({ granted: true });
    await Promise.all([resume, pause]);
    assert.equal(f.starts.length, 0);
    assert.equal(f.started, false);
    assert.equal(f.store.has(key), false);
  } finally {
    gate.resolve({ granted: true });
    await resume;
    await pause;
    await clean(f);
  }
});
void test('current uninterrupted native start still stores exact capability, starts once and requests one initial fix', async () => {
  const f = fixture();
  try {
    const c = credential();
    const status = await service.startLocation(c);
    assert.equal(status.active, true);
    assert.equal(status.sessionId, c.sessionId);
    assert.deepEqual(f.starts, [c]);
    assert.equal(f.initial, 1);
    assert.equal(f.writes.length, 0);
  } finally {
    await clean(f);
  }
});
