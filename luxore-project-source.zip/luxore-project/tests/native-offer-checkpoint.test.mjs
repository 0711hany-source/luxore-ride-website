import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
const virtual = (source) => ({
  url: 'data:text/javascript,' + encodeURIComponent(source),
  shortCircuit: true,
});
registerHooks({
  resolve(s, c, next) {
    if (s === 'expo-location')
      return virtual(
        `export const Accuracy={High:4,BestForNavigation:6};export const requestForegroundPermissionsAsync=async()=>globalThis.delivery.permission?globalThis.delivery.permission():({granted:true}),getBackgroundPermissionsAsync=async()=>({granted:true}),requestBackgroundPermissionsAsync=async()=>({granted:true}),hasStartedLocationUpdatesAsync=async()=>globalThis.delivery.started,startLocationUpdatesAsync=async()=>{globalThis.delivery.started=true},stopLocationUpdatesAsync=async()=>{globalThis.delivery.started=false},getCurrentPositionAsync=()=>globalThis.delivery.first();`,
      );
    if (s === 'expo-task-manager')
      return virtual(
        `export const defineTask=(name,callback)=>{globalThis.deliveryTask=callback};`,
      );
    if (s === 'expo-secure-store')
      return virtual(
        `export const getItemAsync=async k=>globalThis.delivery.store.get(k)||null,setItemAsync=async(k,v)=>{globalThis.delivery.store.set(k,v)},deleteItemAsync=async k=>{globalThis.delivery.store.delete(k)};`,
      );
    if (s === 'react-native')
      return virtual(
        `export const Alert={alert(){throw new Error('Unexpected permission request')}};`,
      );
    if (s === 'expo-notifications')
      return virtual(
        `export const AndroidNotificationPriority={HIGH:2},AndroidImportance={HIGH:4,DEFAULT:3,NONE:0},AndroidNotificationVisibility={PRIVATE:0};export const setNotificationHandler=()=>{},setNotificationChannelAsync=async()=>{},getPermissionsAsync=async()=>({granted:true}),getNotificationChannelAsync=async()=>({importance:4,sound:'default'}),requestPermissionsAsync=async()=>({granted:true}),dismissNotificationAsync=async()=>{globalThis.delivery.dismissed++},scheduleNotificationAsync=async n=>{globalThis.delivery.shown.push(n.content.data.offerId)};`,
      );
    return next(s, c);
  },
  load(url, c, next) {
    const original = url.endsWith('/mobile/src/location-service.ts')
      ? process.env.TEST_ORIGINAL_LOCATION_SERVICE
      : url.endsWith('/mobile/src/offer-alert-policy.ts')
        ? process.env.TEST_ORIGINAL_OFFER_POLICY
        : null;
    if (original)
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(readFileSync(original, 'utf8'), {
          compilerOptions: {
            module: ts.ModuleKind.ESNext,
            target: ts.ScriptTarget.ES2022,
          },
        }).outputText,
      };
    return next(url, c);
  },
});
const service = await import('../mobile/src/location-service.ts');
const stateKey = 'luxore-offer-alert-state';
const originalFetch = globalThis.fetch;
const flush = async () => {
  for (let i = 0; i < 8; i++) await new Promise((r) => setImmediate(r));
};
const fix = (timestamp) => ({
  timestamp,
  coords: {
    latitude: 50.11,
    longitude: 8.68,
    accuracy: 8,
    speed: 0,
    heading: 0,
  },
});
function fixture(t) {
  let now = 2000000;
  t.mock.method(Date, 'now', () => now);
  const f = {
    store: new Map(),
    shown: [],
    dismissed: 0,
    started: false,
    first: () => new Promise(() => {}),
    requests: [],
  };
  globalThis.delivery = f;
  globalThis.fetch = async (url, options) => {
    assert.equal(url, 'https://luxoreride.de/api/mobility/location');
    let resolve;
    const pending = new Promise((r) => {
      resolve = r;
    });
    f.requests.push({ resolve, body: JSON.parse(options.body) });
    return pending;
  };
  return {
    ...f,
    clock: () => now,
    upload: (background = false) => {
      now += 1000;
      return background
        ? globalThis.deliveryTask({ data: { locations: [fix(now)] } })
        : service.deliverForeground(fix(now));
    },
    state: () => JSON.parse(f.store.get(stateKey) || 'null'),
    credential: () => ({
      sessionId: 'shift',
      nativeToken: 'a'.repeat(64),
      expiresAt: now + 3600000,
    }),
  };
}
const known = (time, id = 'offer') => ({
  ok: true,
  updated: true,
  serverTime: time,
  offer: { id, expiresAt: time + 25000 },
});
async function finish(f, index, body, promise) {
  f.requests[index].resolve(Response.json(body));
  await promise;
}
for (const updated of [true, false])
  void test(
    'newer GPS-only acknowledgment blocks an older overlapping foreground offer (updated=' +
      updated +
      ')',
    async (t) => {
      const f = fixture(t);
      try {
        await service.startLocation(f.credential());
        const old = f.upload();
        await flush();
        const oldTime = f.clock();
        const newer = f.upload(true);
        await flush();
        const newTime = f.clock();
        await finish(f, 1, { ok: true, updated, serverTime: newTime }, newer);
        await finish(f, 0, known(oldTime, 'old'), old);
        assert.deepEqual(f.shown, []);
        assert.equal(f.state().checkedAt, newTime);
        assert.equal(f.state().seenId, null);
      } finally {
        await service.stopLocation(false);
        globalThis.fetch = originalFetch;
      }
    },
  );
void test('GPS-only checkpoint preserves the existing actual native alert and seen ID while blocking a delayed different offer', async (t) => {
  const f = fixture(t);
  try {
    await service.startLocation(f.credential());
    const p = f.upload();
    await flush();
    await finish(f, 0, known(f.clock(), 'existing'), p);
    const before = f.state(),
      dismissed = globalThis.delivery.dismissed;
    const old = f.upload();
    await flush();
    const oldTime = f.clock();
    const newer = f.upload(true);
    await flush();
    const newTime = f.clock();
    await finish(f, 2, { ok: true, updated: true, serverTime: newTime }, newer);
    assert.deepEqual(f.state(), { ...before, checkedAt: newTime });
    assert.equal(globalThis.delivery.dismissed, dismissed);
    await finish(f, 1, known(oldTime, 'delayed'), old);
    assert.deepEqual(f.shown, ['existing']);
  } finally {
    await service.stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
void test('a later complete response remains usable after unknown metadata and an actual withdrawal still dismisses', async (t) => {
  const f = fixture(t);
  try {
    await service.startLocation(f.credential());
    let p = f.upload();
    await flush();
    await finish(f, 0, { ok: true, updated: true, serverTime: f.clock() }, p);
    assert.equal(f.state()?.checkedAt, f.clock());
    p = f.upload(true);
    await flush();
    await finish(f, 1, known(f.clock(), 'fresh'), p);
    assert.deepEqual(f.shown, ['fresh']);
    const before = globalThis.delivery.dismissed;
    p = f.upload();
    await flush();
    await finish(
      f,
      2,
      { ok: true, updated: false, serverTime: f.clock(), offer: null },
      p,
    );
    assert.equal(globalThis.delivery.dismissed, before + 1);
  } finally {
    await service.stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
void test('unacknowledged or malformed payloads cannot advance an alarm checkpoint', async (t) => {
  const f = fixture(t);
  try {
    await service.startLocation(f.credential());
    let index = 0;
    for (const values of [
      { ok: false, updated: true },
      { ok: true },
      { ok: true, updated: 'yes' },
      { ok: true, updated: true, offer: {} },
      { ok: true, updated: true, offer: false },
      { ok: true, updated: true, serverTime: 'invalid' },
    ]) {
      const p = f.upload();
      await flush();
      await finish(f, index++, { serverTime: f.clock(), ...values }, p);
      assert.equal(f.state(), null);
    }
  } finally {
    await service.stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
void test('late GPS-only acknowledgment from an old capability cannot change a replacement shift alert state', async (t) => {
  const f = fixture(t);
  try {
    await service.startLocation(f.credential());
    const old = f.upload();
    await flush();
    const oldTime = f.clock();
    await service.startLocation({
      ...f.credential(),
      sessionId: 'new',
      nativeToken: 'b'.repeat(64),
    });
    const p = f.upload();
    await flush();
    await finish(f, 1, known(f.clock(), 'new-offer'), p);
    const expected = f.state();
    await finish(
      f,
      0,
      { ok: true, updated: true, serverTime: oldTime + 100000 },
      old,
    );
    assert.deepEqual(f.state(), expected);
    assert.equal(expected.sessionId, 'new');
  } finally {
    await service.stopLocation(false);
    globalThis.fetch = originalFetch;
  }
});
