import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
const store = new Map([['luxore-account-v1', 'a'.repeat(64)]]);
globalThis.nativeViewStore = store;
globalThis.customerAppListeners = new Set();
globalThis.require = () => 1; // Metro resolves static PNG assets in real APKs.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    'expo-location',
    `export const Accuracy={High:4}; export const requestForegroundPermissionsAsync=async()=>({status:'denied'}),getCurrentPositionAsync=async()=>{throw new Error('GPS not enabled in view tests')};`,
  ],
  [
    'react-native',
    `
    export const View='View', Text='Text', Pressable='Pressable', ScrollView='ScrollView', Modal='Modal', Image='Image', TextInput='TextInput', KeyboardAvoidingView='KeyboardAvoidingView', ActivityIndicator='ActivityIndicator';
    export const Platform={OS:'android'}, StyleSheet={create:v=>v}, Keyboard={dismiss(){}}, Share={async share(){}}, Linking={async openURL(){},async openSettings(){}}, Alert={alert(){}};
    export const AppState={currentState:'active',addEventListener(event,listener){globalThis.customerAppListeners.add(listener);return {remove(){globalThis.customerAppListeners.delete(listener)}}}}, BackHandler={addEventListener(){return {remove(){}}}};
    export const useWindowDimensions=()=>({width:390,height:844});
    export const PanResponder={create:handlers=>({panHandlers:handlers})};
    export const Animated={Value:class {constructor(v){this.value=v}setValue(v){this.value=v}},View:'AnimatedView',spring:(v,o)=>({start:()=>v.setValue(o.toValue)})};
  `,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaProvider='SafeAreaProvider', SafeAreaView='SafeAreaView';`,
  ],
  ['expo-status-bar', `export const StatusBar='StatusBar';`],
  ['expo-constants', `export default {expoConfig:{extra:{variant:'driver'}}};`],
  [
    'expo-secure-store',
    `export const getItemAsync=async k=>globalThis.nativeViewStore.get(k)||null,setItemAsync=async(k,v)=>{globalThis.nativeViewStore.set(k,v)},deleteItemAsync=async k=>{globalThis.nativeViewStore.delete(k)};`,
  ],
  [
    'expo-crypto',
    `export const randomUUID=()=> 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';`,
  ],
  [
    'expo-notifications',
    `export const getLastNotificationResponse=()=>null,clearLastNotificationResponse=()=>{},addNotificationResponseReceivedListener=()=>({remove(){}});`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',ArrowRight='ArrowRight', CalendarDays='CalendarDays', CarFront='CarFront', Check='Check', ChevronRight='ChevronRight', CircleHelp='CircleHelp', Home='Home', LogOut='LogOut', Mail='Mail', MapPinned='MapPinned', MapPin='MapPin', Clock3='Clock3', Settings='Settings', ShieldCheck='ShieldCheck', UserRound='UserRound', Users='Users',ChevronDown='ChevronDown',LocateFixed='LocateFixed',Navigation='Navigation',Phone='Phone',RefreshCw='RefreshCw',X='X',Plus='Plus',Minus='Minus',Search='Search';`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    let source = mocked.get(specifier);
    if (specifier.endsWith('/RideWorkspace') || specifier === './RideWorkspace')
      source = `export default function ForbiddenEmbeddedDriver(){throw new Error('Driver mounted a WebView');}`;
    if (specifier === './use-driver-gps')
      source = `export function useDriverGps(){return {position:{lat:50.11,lng:8.68,accuracy:8,timestamp:Date.now()},sessionId:null,error:'',foreground:true,restart:async()=>{},sync:async()=>({active:false})}}`;
    if (specifier === './location-service')
      source = `export const resumeLocation=async()=>({active:false}),stopLocation=async()=>{},foregroundPermission=async()=>{},startLocation=async()=>({active:true});`;
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: OperationsScreen } =
  await import('../mobile/src/OperationsScreen.tsx');

const fleets = [
  { id: 'f1', name: 'Flotte A', owner_id: 'owner', deputy_id: null },
  { id: 'f2', name: 'Flotte B', owner_id: 'other', deputy_id: null },
];
const employees = [
  { user_id: 'owner', name: 'Besitzer', fleet_id: 'f1' },
  { user_id: 'team', name: 'Mitarbeiter ohne Fahrerprofil', fleet_id: 'f1' },
  { user_id: 'foreign', name: 'Fremde Person', fleet_id: 'f2' },
];
const drivers = [
  {
    id: 'owner',
    name: 'Besitzer',
    fleet_id: 'f1',
    approved: 1,
    online: 1,
    session_id: 'shift',
  },
];
async function settle() {
  for (let i = 0; i < 7; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
const text = (r) =>
  r.root
    .findAllByType('Text')
    .map((n) => n.children.filter((c) => typeof c === 'string').join(''))
    .join(' ');
const radio = (r, name) =>
  r.root
    .findAllByType('Pressable')
    .find(
      (n) =>
        n.props.accessibilityRole === 'radio' &&
        n.findAllByType('Text').some((t) => t.children.includes(name)),
    );
async function measure(r) {
  await act(async () =>
    r.root
      .findAllByType('Modal')
      .find((n) => n.props.visible)
      .findAllByType('View')
      .filter((n) => n.props.onLayout)
      .at(-1)
      .props.onLayout({ nativeEvent: { layout: { width: 330 } } }),
  );
}
void test('native deputy dialog filters actual team and confirms selection/removal only by full swipe', async () => {
  const old = globalThis.fetch;
  let renderer;
  const writes = [];
  fleets[0].deputy_id = null;
  globalThis.fetch = async (url, opts) => {
    if (url.endsWith('/operations'))
      return Response.json({ drivers, bookings: [] });
    if (opts.method === 'POST') {
      const body = JSON.parse(opts.body);
      writes.push(body);
      fleets[0].deputy_id = body.deputyId;
      return Response.json({ ok: true });
    }
    return Response.json({
      fleets,
      employees,
      revenue: [],
      userId: 'owner',
      canManage: false,
    });
  };
  try {
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(OperationsScreen, {
          token: 'a'.repeat(64),
          active: true,
          onFleet() {},
        }),
      );
    });
    await settle();
    await act(async () =>
      renderer.root
        .findByProps({ accessibilityLabel: 'Stellvertretung verwalten' })
        .props.onPress(),
    );
    const dialog = renderer.root
      .findAllByType('Modal')
      .find((n) => n.props.visible);
    assert.equal(dialog.props.presentationStyle, 'fullScreen');
    assert.equal(
      dialog
        .findAllByType('Pressable')
        .filter((n) => n.props.accessibilityRole === 'radio').length,
      2,
    );
    assert.ok(radio(renderer, 'Mitarbeiter ohne Fahrerprofil'));
    assert.equal(radio(renderer, 'Fremde Person'), undefined);
    assert.equal(radio(renderer, 'Besitzer'), undefined);
    await act(async () =>
      radio(renderer, 'Mitarbeiter ohne Fahrerprofil').props.onPress(),
    );
    await measure(renderer);
    let thumb = dialog.findByType('AnimatedView');
    assert.equal(thumb.props.onPress, undefined);
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 30 }));
    assert.equal(writes.length, 0);
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 260 }));
    await settle();
    assert.deepEqual(writes, [
      { action: 'deputy', fleetId: 'f1', deputyId: 'team' },
    ]);
    assert.match(text(renderer), /Stellvertretung gespeichert/);
    assert.equal(drivers[0].session_id, 'shift');
    await act(async () =>
      radio(renderer, 'Keine Stellvertretung').props.onPress(),
    );
    await measure(renderer);
    thumb = renderer.root
      .findAllByType('Modal')
      .find((n) => n.props.visible)
      .findByType('AnimatedView');
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 260 }));
    await settle();
    assert.equal(writes[1].deputyId, null);
    assert.match(text(renderer), /Stellvertretung aufgehoben/);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});
void test('deputy-only actor has no owner control and lost response locks other choices until identical retry', async () => {
  const old = globalThis.fetch;
  let renderer,
    actor = 'deputy',
    writes = 0;
  fleets[0].deputy_id = null;
  globalThis.fetch = async (url, opts) => {
    if (url.endsWith('/operations'))
      return Response.json({ drivers, bookings: [] });
    if (opts.method === 'POST') {
      writes++;
      assert.deepEqual(JSON.parse(opts.body), {
        action: 'deputy',
        fleetId: 'f1',
        deputyId: 'team',
      });
      if (writes === 1)
        return Response.json({ error: 'Lost reply' }, { status: 503 });
      fleets[0].deputy_id = 'team';
      return Response.json({ ok: true });
    }
    return Response.json({
      fleets,
      employees,
      revenue: [],
      userId: actor,
      canManage: false,
    });
  };
  try {
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(OperationsScreen, {
          token: 'a'.repeat(64),
          active: true,
          onFleet() {},
        }),
      );
    });
    await settle();
    assert.equal(
      renderer.root.findAllByProps({
        accessibilityLabel: 'Stellvertretung verwalten',
      }).length,
      0,
    );
    actor = 'owner';
    await act(async () =>
      renderer.root
        .findByProps({ accessibilityLabel: 'Disposition aktualisieren' })
        .props.onPress(),
    );
    await settle();
    await act(async () =>
      renderer.root
        .findByProps({ accessibilityLabel: 'Stellvertretung verwalten' })
        .props.onPress(),
    );
    await act(async () =>
      radio(renderer, 'Mitarbeiter ohne Fahrerprofil').props.onPress(),
    );
    await measure(renderer);
    await act(async () =>
      renderer.root
        .findAllByType('Modal')
        .find((n) => n.props.visible)
        .findByType('AnimatedView')
        .props.onPanResponderRelease(null, { dx: 260 }),
    );
    await settle();
    assert.equal(radio(renderer, 'Keine Stellvertretung').props.disabled, true);
    assert.match(text(renderer), /Antwort fehlt/);
    assert.equal(writes, 1);
    await measure(renderer);
    await act(async () =>
      renderer.root
        .findAllByType('Modal')
        .find((n) => n.props.visible)
        .findByType('AnimatedView')
        .props.onPanResponderRelease(null, { dx: 260 }),
    );
    await settle();
    assert.equal(writes, 2);
    assert.match(text(renderer), /Stellvertretung gespeichert/);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});

void test('legacy vehicle fallback opens the native invitations instead of joining by tap', async () => {
  const old = globalThis.fetch;
  let renderer,
    opens = 0,
    writes = 0;
  globalThis.fetch = async (url, opts) => {
    if (opts.method === 'POST') writes++;
    return Response.json({ error: 'No dispatch rights' }, { status: 403 });
  };
  try {
    const { default: FleetScreen } =
      await import('../mobile/src/FleetScreen.tsx');
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(FleetScreen, {
          token: 'a'.repeat(64),
          onInvitations() {
            opens++;
          },
        }),
      );
    });
    await settle();
    assert.equal(
      renderer.root.findAllByProps({ placeholder: 'Einladungscode' }).length,
      0,
    );
    await act(async () =>
      renderer.root
        .findByProps({ accessibilityLabel: 'Native Flotteneinladungen öffnen' })
        .props.onPress(),
    );
    assert.equal(opens, 1);
    assert.equal(writes, 0);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});
