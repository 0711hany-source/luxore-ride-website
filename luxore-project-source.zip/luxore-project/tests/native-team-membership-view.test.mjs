import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
const store = new Map([['luxore-account-v1', 'a'.repeat(64)]]);
globalThis.nativeViewStore = store;
globalThis.customerAppListeners = new Set();
globalThis.require = () => 1; // Metro resolves static PNG assets in real APKs.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    'expo-location',
    `export const Accuracy={High:4}; export const requestForegroundPermissionsAsync=async()=>({status:'denied'}),getCurrentPositionAsync=async()=>{throw new Error('GPS not enabled in view tests')};`,
  ],
  [
    'react-native',
    `
    export const View='View', Text='Text', Pressable='Pressable', ScrollView='ScrollView', Modal='Modal', Image='Image', TextInput='TextInput', KeyboardAvoidingView='KeyboardAvoidingView', ActivityIndicator='ActivityIndicator';
    export const Platform={OS:'android'}, StyleSheet={create:v=>v}, Keyboard={dismiss(){}}, Share={async share(){}}, Linking={async openURL(){},async openSettings(){}}, Alert={alert(){}};
    export const AppState={currentState:'active',addEventListener(event,listener){globalThis.customerAppListeners.add(listener);return {remove(){globalThis.customerAppListeners.delete(listener)}}}}, BackHandler={addEventListener(){return {remove(){}}}};
    export const useWindowDimensions=()=>({width:390,height:844});
    export const PanResponder={create:handlers=>({panHandlers:handlers})};
    export const Animated={Value:class {constructor(v){this.value=v}setValue(v){this.value=v}},View:'AnimatedView',spring:(v,o)=>({start:()=>v.setValue(o.toValue)})};
  `,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaProvider='SafeAreaProvider', SafeAreaView='SafeAreaView';`,
  ],
  ['expo-status-bar', `export const StatusBar='StatusBar';`],
  ['expo-constants', `export default {expoConfig:{extra:{variant:'driver'}}};`],
  [
    'expo-secure-store',
    `export const getItemAsync=async k=>globalThis.nativeViewStore.get(k)||null,setItemAsync=async(k,v)=>{globalThis.nativeViewStore.set(k,v)},deleteItemAsync=async k=>{globalThis.nativeViewStore.delete(k)};`,
  ],
  [
    'expo-crypto',
    `export const randomUUID=()=> 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';`,
  ],
  [
    'expo-notifications',
    `export const getLastNotificationResponse=()=>null,clearLastNotificationResponse=()=>{},addNotificationResponseReceivedListener=()=>({remove(){}});`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',ArrowRight='ArrowRight', CalendarDays='CalendarDays', CarFront='CarFront', Check='Check', ChevronRight='ChevronRight', CircleHelp='CircleHelp', Home='Home', LogOut='LogOut', Mail='Mail', MapPinned='MapPinned', MapPin='MapPin', Clock3='Clock3', Settings='Settings', ShieldCheck='ShieldCheck', UserRound='UserRound', Users='Users',ChevronDown='ChevronDown',LocateFixed='LocateFixed',Navigation='Navigation',Phone='Phone',RefreshCw='RefreshCw',X='X',Plus='Plus',Minus='Minus',Search='Search';`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    let source = mocked.get(specifier);
    if (specifier.endsWith('/RideWorkspace') || specifier === './RideWorkspace')
      source = `export default function ForbiddenEmbeddedDriver(){throw new Error('Driver mounted a WebView');}`;
    if (specifier === './use-driver-gps')
      source = `export function useDriverGps(){return {position:{lat:50.11,lng:8.68,accuracy:8,timestamp:Date.now()},sessionId:null,error:'',foreground:true,restart:async()=>{},sync:async()=>({active:false})}}`;
    if (specifier === './location-service')
      source = `export const resumeLocation=async()=>({active:false}),stopLocation=async()=>{},foregroundPermission=async()=>{},startLocation=async()=>({active:true});`;
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: OperationsScreen } =
  await import('../mobile/src/OperationsScreen.tsx');

const base = () => ({
  userId: 'owner',
  canManage: false,
  fleets: [
    { id: 'f', name: 'Flotte A', owner_id: 'owner', deputy_id: 'deputy' },
    { id: 'other', name: 'Flotte B', owner_id: 'other-owner', deputy_id: null },
  ],
  employees: [
    {
      user_id: 'owner',
      name: 'Besitzer',
      fleet_id: 'f',
      role: 'staff',
      can_remove: 1,
    },
    {
      user_id: 'deputy',
      name: 'Stellvertretung',
      fleet_id: 'f',
      role: 'staff',
      can_remove: 1,
    },
    {
      user_id: 'staff',
      name: 'Mitarbeiter ohne Fahrerprofil',
      fleet_id: 'f',
      role: 'staff',
      can_remove: 1,
    },
    {
      user_id: 'foreign',
      name: 'Fremde Person',
      fleet_id: 'other',
      role: 'driver',
      can_remove: 1,
    },
    { user_id: 'new', name: 'Ohne Flotte', fleet_id: null, role: 'driver' },
  ],
  revenue: [],
});
async function settle() {
  for (let i = 0; i < 7; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
const dialog = (r) =>
  r.root.findAllByType('Modal').find((n) => n.props.visible);
const text = (r) =>
  r.root
    .findAllByType('Text')
    .map((n) => n.children.filter((c) => typeof c === 'string').join(''))
    .join(' ');
async function open(r) {
  await act(async () =>
    r.root
      .findByProps({ accessibilityLabel: 'Team verwalten' })
      .props.onPress(),
  );
}
async function choose(r, name) {
  await act(async () =>
    r.root
      .findByProps({ accessibilityLabel: `Mitarbeiter ${name} auswählen` })
      .props.onPress(),
  );
}
async function swipe(r, dx) {
  await act(async () =>
    dialog(r)
      .findAllByType('View')
      .filter((n) => n.props.onLayout)
      .at(-1)
      .props.onLayout({ nativeEvent: { layout: { width: 330 } } }),
  );
  await act(async () =>
    dialog(r)
      .findByType('AnimatedView')
      .props.onPanResponderRelease(null, { dx }),
  );
  await settle();
}
void test('native team is scoped to owner/deputy employees and removes only after full swipe', async () => {
  const old = globalThis.fetch;
  let r;
  const data = base();
  data.userId = 'deputy';
  const writes = [];
  globalThis.fetch = async (url, opts) => {
    if (url.endsWith('/operations'))
      return Response.json({ drivers: [], bookings: [] });
    if (opts.method === 'POST') {
      const body = JSON.parse(opts.body);
      writes.push(body);
      data.employees = data.employees.filter((e) => e.user_id !== body.userId);
      return Response.json({ ok: true });
    }
    return Response.json(data);
  };
  try {
    await act(async () => {
      r = Renderer.create(
        React.createElement(OperationsScreen, {
          token: 'a'.repeat(64),
          active: true,
          onFleet() {},
        }),
      );
    });
    await settle();
    await open(r);
    assert.equal(dialog(r).props.presentationStyle, 'fullScreen');
    assert.equal(
      dialog(r).findAllByProps({
        accessibilityLabel: 'Mitarbeiter Fremde Person auswählen',
      }).length,
      0,
    );
    assert.equal(
      dialog(r).findByProps({
        accessibilityLabel: 'Mitarbeiter Besitzer auswählen',
      }).props.disabled,
      true,
    );
    assert.equal(
      dialog(r).findByProps({
        accessibilityLabel: 'Mitarbeiter Stellvertretung auswählen',
      }).props.disabled,
      true,
    );
    await choose(r, 'Mitarbeiter ohne Fahrerprofil');
    assert.match(text(r), /Profil bleibt erhalten/);
    assert.match(text(r), /Fahrzeugauswahl und Fahrerfreigabe/);
    assert.equal(dialog(r).findByType('AnimatedView').props.onPress, undefined);
    await swipe(r, 30);
    assert.equal(writes.length, 0);
    await swipe(r, 260);
    assert.deepEqual(writes, [
      { action: 'remove_member', userId: 'staff', fleetId: 'f' },
    ]);
    assert.match(text(r), /aus der Flotte entfernt/);
  } finally {
    if (r) await act(async () => r.unmount());
    globalThis.fetch = old;
  }
});
void test('operator can move existing staff preserving role; lost reply permits only identical explicit swipe', async () => {
  const old = globalThis.fetch;
  let r;
  const data = { ...base(), userId: 'admin', canManage: true };
  const writes = [];
  globalThis.fetch = async (url, opts) => {
    if (url.endsWith('/operations'))
      return Response.json({ drivers: [], bookings: [] });
    if (opts.method === 'POST') {
      const body = JSON.parse(opts.body);
      writes.push(body);
      if (writes.length === 1)
        return Response.json({ error: 'Lost reply' }, { status: 503 });
      data.employees = data.employees.map((e) =>
        e.user_id === body.userId ? { ...e, fleet_id: body.fleetId } : e,
      );
      return Response.json({ ok: true });
    }
    return Response.json(data);
  };
  try {
    await act(async () => {
      r = Renderer.create(
        React.createElement(OperationsScreen, {
          token: 'a'.repeat(64),
          active: true,
          onFleet() {},
        }),
      );
    });
    await settle();
    await open(r);
    await choose(r, 'Fremde Person');
    assert.match(text(r), /bisherige Flottenzuordnung wird ersetzt/);
    await swipe(r, 260);
    assert.equal(writes.length, 1);
    assert.match(text(r), /Antwort fehlt/);
    assert.equal(
      dialog(r).findByProps({
        accessibilityLabel: 'Mitarbeiter Ohne Flotte auswählen',
      }).props.disabled,
      true,
    );
    await swipe(r, 260);
    assert.equal(writes.length, 2);
    assert.deepEqual(writes[0], {
      action: 'assign',
      userId: 'foreign',
      fleetId: 'f',
      role: 'driver',
    });
    assert.deepEqual(writes[1], writes[0]);
    assert.match(text(r), /Mitarbeiter zugeordnet/);
  } finally {
    if (r) await act(async () => r.unmount());
    globalThis.fetch = old;
  }
});
void test('revoked fleet authority removes native team controls and open modal without POST', async () => {
  const old = globalThis.fetch;
  let r,
    data = base(),
    writes = 0;
  globalThis.fetch = async (url, opts) => {
    if (opts.method === 'POST') writes++;
    if (url.endsWith('/operations'))
      return Response.json({ drivers: [], bookings: [] });
    return Response.json(data);
  };
  try {
    await act(async () => {
      r = Renderer.create(
        React.createElement(OperationsScreen, {
          token: 'a'.repeat(64),
          active: true,
          onFleet() {},
        }),
      );
    });
    await settle();
    await open(r);
    await choose(r, 'Mitarbeiter ohne Fahrerprofil');
    data = { ...data, userId: 'ordinary' };
    await act(async () =>
      r.root
        .findByProps({ accessibilityLabel: 'Teamstand aktualisieren' })
        .props.onPress(),
    );
    await settle();
    assert.equal(
      r.root.findAllByProps({ accessibilityLabel: 'Team verwalten' }).length,
      0,
    );
    assert.equal(
      r.root.findAllByType('Modal').filter((n) => n.props.visible).length,
      0,
    );
    assert.equal(writes, 0);
  } finally {
    if (r) await act(async () => r.unmount());
    globalThis.fetch = old;
  }
});
