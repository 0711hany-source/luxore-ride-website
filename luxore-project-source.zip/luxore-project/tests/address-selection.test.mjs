import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const require = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const modules = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((n) => [
    n,
    pathToFileURL(require.resolve(n)).href,
  ]),
);
registerHooks({
  resolve(name, context, next) {
    if (modules.has(name))
      return { url: modules.get(name), shortCircuit: true };
    if (name === '@/components/ui/button')
      return {
        url:
          'data:text/javascript,' +
          encodeURIComponent("export const Button='button';"),
        shortCircuit: true,
      };
    return next(name, context);
  },
});
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: Address } = await import('../app/mobility/address.tsx');
const points = [
  { id: 'preview-1', label: 'Opernplatz 1, Frankfurt', lat: 50.11, lng: 8.67 },
  { id: 'preview-2', label: 'Opernplatz 2, Frankfurt', lat: 50.12, lng: 8.69 },
];
async function settle() {
  await act(async () => {
    await new Promise((r) => setImmediate(r));
  });
}
function Harness() {
  const [value, setValue] = React.useState(null);
  return React.createElement(Address, {
    label: 'Abholort',
    value,
    onChange: setValue,
    mapsReady: true,
  });
}
test('typeahead presents inline choices; keyboard selection confirms before accepting an address', async () => {
  const old = globalThis.fetch,
    calls = [];
  let root;
  globalThis.fetch = async (_url, options) => {
    const b = JSON.parse(options.body);
    calls.push(b);
    return Response.json({
      results:
        b.kind === 'search' ? points : [{ ...points[1], id: 'confirmed' }],
    });
  };
  try {
    await act(async () => {
      root = Renderer.create(React.createElement(Harness));
    });
    await act(async () => {
      root.root.findByType('input').props.onFocus();
      root.root
        .findByType('input')
        .props.onChange({ target: { value: 'Opernplatz' } });
    });
    await act(async () => {
      await new Promise((r) => setTimeout(r, 650));
    });
    await settle();
    assert.equal(calls.length, 1);
    assert.equal(calls[0].kind, 'search');
    assert.equal(root.root.findAll((n) => n.props.role === 'option').length, 2);
    const event = (key) => ({ key, preventDefault() {} });
    await act(async () =>
      root.root.findByType('input').props.onKeyDown(event('ArrowDown')),
    );
    await act(async () =>
      root.root.findByType('input').props.onKeyDown(event('ArrowDown')),
    );
    await act(async () =>
      root.root.findByType('input').props.onKeyDown(event('Enter')),
    );
    await settle();
    assert.equal(calls[1].kind, 'selected');
    assert.equal(calls[1].lat, points[1].lat);
    assert.equal(root.root.findByType('input').props.value, points[1].label);
    assert.equal(root.root.findAll((n) => n.props.role === 'option').length, 0);
    assert.match(JSON.stringify(root.toJSON()), /Ausgewählt/);
  } finally {
    if (root) await act(async () => root.unmount());
    globalThis.fetch = old;
  }
});
test('failed confirmation is not accepted; editing and successful retry clear previous errors', async () => {
  const old = globalThis.fetch;
  let fail = true,
    root;
  globalThis.fetch = async (_url, options) => {
    const b = JSON.parse(options.body);
    if (b.kind === 'selected' && fail)
      return Response.json({ error: 'Adressanbieter fehlt' }, { status: 429 });
    return Response.json({
      results:
        b.kind === 'search' ? points : [{ ...points[0], id: 'confirmed' }],
    });
  };
  try {
    await act(async () => {
      root = Renderer.create(React.createElement(Harness));
    });
    async function type() {
      await act(async () => {
        root.root.findByType('input').props.onFocus();
        root.root
          .findByType('input')
          .props.onChange({ target: { value: 'Opernplatz' } });
      });
      await act(async () => {
        await new Promise((r) => setTimeout(r, 650));
      });
      await settle();
    }
    await type();
    await act(async () =>
      root.root.findAll((n) => n.props.role === 'option')[0].props.onClick(),
    );
    await settle();
    assert.equal(root.root.findAll((n) => n.props.role === 'alert').length, 1);
    assert.doesNotMatch(
      JSON.stringify(root.toJSON()),
      /Ausgewählt|Treffer gefunden/,
    );
    fail = false;
    await type();
    assert.equal(root.root.findAll((n) => n.props.role === 'alert').length, 0);
    await act(async () =>
      root.root.findAll((n) => n.props.role === 'option')[0].props.onClick(),
    );
    await settle();
    assert.equal(root.root.findByType('input').props.value, points[0].label);
    assert.equal(root.root.findAll((n) => n.props.role === 'alert').length, 0);
  } finally {
    if (root) await act(async () => root.unmount());
    globalThis.fetch = old;
  }
});
