import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  NativeStatusRequests,
  matchesNativeShift,
} from '../app/mobility/native-status.ts';

function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((done) => {
    resolve = done;
  });
  return { promise, resolve };
}

test('an inactive response begun before Online cannot cancel the new shift', async () => {
  const requests = new NativeStatusRequests();
  const old = deferred<boolean>();
  let active = false;
  const pending = requests.read(
    () => old.promise,
    (value) => {
      active = value;
    },
  );
  requests.invalidate(); // Online pressed.
  active = true; // Current native start succeeded.
  requests.invalidate(); // Transition finished.
  old.resolve(false);
  await pending;
  assert.equal(active, true);
  await requests.read(
    async () => false,
    (value) => {
      active = value;
    },
  );
  assert.equal(active, false, 'a fresh confirmed stop still takes effect');
});

test('Pause and unmount reject pending active status; a new observer can restore current status', async () => {
  for (const transition of ['pause', 'unmount']) {
    const requests = new NativeStatusRequests();
    const old = deferred<boolean>();
    let writes = 0;
    const pending = requests.read(
      () => old.promise,
      () => {
        writes++;
      },
    );
    requests.invalidate();
    old.resolve(true);
    await pending;
    assert.equal(writes, 0, transition);
    await requests.read(
      async () => true,
      () => {
        writes++;
      },
    );
    assert.equal(writes, 1);
  }
});

test('responses out of order keep the newest result, and a network error does not report offline', async () => {
  const requests = new NativeStatusRequests();
  const old = deferred<string>();
  let applied = '';
  const pending = requests.read(
    () => old.promise,
    (value) => {
      applied = value;
    },
  );
  await requests.read(
    async () => 'new',
    (value) => {
      applied = value;
    },
  );
  old.resolve('old');
  await pending;
  assert.equal(applied, 'new');
  await assert.rejects(
    requests.read(
      async () => {
        throw new Error('Disconnected');
      },
      () => {
        applied = 'offline';
      },
    ),
    /Disconnected/,
  );
  assert.equal(applied, 'new');
});

test('current shift wins over an older server snapshot; only matching live sessions restore', () => {
  const live = { active: true, sessionId: 'new', expiresAt: 200 };
  assert.equal(matchesNativeShift(live, 'new', 'old', 100), true);
  assert.equal(
    matchesNativeShift({ ...live, sessionId: 'old' }, 'new', 'old', 100),
    false,
  );
  assert.equal(matchesNativeShift(live, null, 'new', 100), true);
  assert.equal(matchesNativeShift(live, null, null, 100), false);
  assert.equal(
    matchesNativeShift({ ...live, active: false }, 'new', 'new', 100),
    false,
  );
  assert.equal(matchesNativeShift(live, 'new', 'new', 200), false);
  assert.equal(
    matchesNativeShift({ ...live, expiresAt: NaN }, 'new', 'new', 100),
    false,
  );
});
