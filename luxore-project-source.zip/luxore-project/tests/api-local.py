"""Local Sites development server only; uses its documented local sign-in route."""
import json, urllib.request, urllib.error, http.cookiejar, uuid
base='http://localhost:3001'
jar=http.cookiejar.CookieJar()
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
def call(method,path='/api/rides',body=None,origin=base):
    request=urllib.request.Request(base+path,data=json.dumps(body).encode() if body is not None else None,method=method,headers={'Content-Type':'application/json','Origin':origin})
    try:
        with client.open(request) as r: return r.status,json.loads(r.read())
    except urllib.error.HTTPError as e:
        data=e.read()
        try: parsed=json.loads(data)
        except ValueError: parsed=data.decode()
        return e.code,parsed
assert call('GET')[0]==401
client.open(base+'/signin-with-chatgpt?return_to=%2F').close()
assert call('GET')[0]==200
ride={'id':str(uuid.uuid4()),'pickup':'Frankfurt Flughafen · Terminal 1','destination':'Alte Oper · Opernplatz','service':'first','scheduledAt':None}
assert call('POST',body=ride,origin='https://other.invalid')[0]==403
assert call('POST',body={**ride,'destination':ride['pickup']})[0]==400
assert call('POST',body=ride)[0]==201
assert call('POST',body=ride)[0]==200
assert call('POST',body={**ride,'service':'premium'})[0]==409
status,rows=call('GET')
found=[r for r in rows if r['id']==ride['id']]
assert len(found)==1 and found[0]['price']==9500
assert call('PATCH',body={'id':ride['id'],'from':'requested','status':'completed'})[0]==400
assert call('PATCH',body={'id':str(uuid.uuid4()),'from':'requested','status':'accepted'})[0]==409
for old,new in [('requested','accepted'),('accepted','arrived'),('arrived','riding'),('riding','completed')]:
    assert call('PATCH',body={'id':ride['id'],'from':old,'status':new})[0]==200
    assert call('PATCH',body={'id':ride['id'],'from':old,'status':new})[0]==409
assert call('PATCH',body={'id':ride['id'],'from':'completed','status':'requested'})[0]==400
van={**ride,'id':str(uuid.uuid4()),'service':'van'}
assert call('POST',body=van)[0]==201
assert [r for r in call('GET')[1] if r['id']==van['id']][0]['price']==8500
assert call('PATCH',body={'id':van['id'],'from':'requested','status':'cancelled'})[0]==200
print('PASS: Van persistence and cancellation, anonymous denial, origin check, validation, idempotency, quote, lifecycle, stale-write rejection. Synthetic completed ride retained locally.')
