import test from 'node:test';
import assert from 'node:assert/strict';
import {
  LocationRequest,
  locationDeadline,
} from '../mobile/src/location-request.ts';
test('Manual edit/cancel rejects stale GPS and cannot end a newer request', () => {
  const owner = new LocationRequest();
  const first = owner.begin();
  owner.cancel();
  assert.equal(owner.isCurrent(first), false);
  const second = owner.begin();
  owner.finish(first);
  assert.equal(owner.isCurrent(second), true);
  owner.finish(second);
  assert.equal(owner.isCurrent(second), false);
});
test('GPS timeout rejects and late native completion does not apply', async () => {
  const controller = new AbortController();
  let complete!: (value: string) => void;
  const native = new Promise<string>((resolve) => {
    complete = resolve;
  });
  let applied = false;
  const result = locationDeadline(native, controller.signal, 5).then(() => {
    applied = true;
  });
  await assert.rejects(result, /dauert zu lange/);
  complete('late position');
  await Promise.resolve();
  assert.equal(applied, false);
});
test('Cancellation settles promptly; later native rejection remains handled', async () => {
  const owner = new LocationRequest();
  const request = owner.begin();
  let fail!: (e: Error) => void;
  const pending = new Promise<never>((_, reject) => {
    fail = reject;
  });
  const result = locationDeadline(pending, request.signal);
  owner.cancel();
  await assert.rejects(result, /abgebrochen/);
  fail(new Error('late native failure'));
  await Promise.resolve();
});
test('Successful GPS completes normally', async () => {
  assert.equal(
    await locationDeadline(
      Promise.resolve('position'),
      new AbortController().signal,
    ),
    'position',
  );
});
