import test from 'node:test';
import assert from 'node:assert/strict';
import {
  LocationRequest,
  PermissionMissingError,
  abortable,
  locationDeadline,
} from '../mobile/src/location-request.ts';
test('Manual edit/cancel rejects stale GPS and cannot end a newer request', () => {
  const owner = new LocationRequest();
  const first = owner.begin();
  owner.cancel();
  assert.equal(owner.isCurrent(first), false);
  const second = owner.begin();
  owner.finish(first);
  assert.equal(owner.isCurrent(second), true);
  owner.finish(second);
  assert.equal(owner.isCurrent(second), false);
});
test('GPS timeout rejects and late native completion does not apply', async () => {
  const controller = new AbortController();
  let complete!: (value: string) => void;
  const native = new Promise<string>((resolve) => {
    complete = resolve;
  });
  let applied = false;
  const result = locationDeadline(native, controller.signal, 5).then(() => {
    applied = true;
  });
  await assert.rejects(result, /dauert zu lange/);
  complete('late position');
  await Promise.resolve();
  assert.equal(applied, false);
});
test('Cancellation settles promptly; later native rejection remains handled', async () => {
  const owner = new LocationRequest();
  const request = owner.begin();
  let fail!: (e: Error) => void;
  const pending = new Promise<never>((_, reject) => {
    fail = reject;
  });
  const result = locationDeadline(pending, request.signal);
  owner.cancel();
  await assert.rejects(result, /abgebrochen/);
  fail(new Error('late native failure'));
  await Promise.resolve();
});
test('Successful GPS completes normally', async () => {
  assert.equal(
    await locationDeadline(
      Promise.resolve('position'),
      new AbortController().signal,
    ),
    'position',
  );
});

test('Cancelling the shift start stops waiting on a native call that never answers', async () => {
  const controller = new AbortController();
  const waiting = abortable(new Promise<string>(() => {}), controller.signal);
  controller.abort();
  await assert.rejects(waiting, /abgebrochen/);
  // An already cancelled attempt never waits, and a late rejection stays observed.
  let fail!: (error: Error) => void;
  const late = new Promise<string>((_, reject) => {
    fail = reject;
  });
  await assert.rejects(abortable(late, controller.signal), /abgebrochen/);
  fail(new Error('late native failure'));
  await Promise.resolve();
  const open = new AbortController();
  assert.equal(await abortable(Promise.resolve('ok'), open.signal), 'ok');
  await assert.rejects(
    abortable(Promise.reject(new Error('native')), open.signal),
    /native/,
  );
});
test('A missing Android permission is marked so the screen can offer the settings', () => {
  const error = new PermissionMissingError('Bitte erlauben.');
  assert.equal(error.settings, true);
  assert.equal(error.message, 'Bitte erlauben.');
  assert.ok(error instanceof Error);
});
