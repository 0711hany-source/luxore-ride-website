import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import test from 'node:test';
import assert from 'node:assert/strict';
globalThis.nativeAccountStore = new Map();
registerHooks({
  resolve(s, c, n) {
    if (s === 'expo-secure-store')
      return {
        url:
          'data:text/javascript,' +
          encodeURIComponent(
            'export const getItemAsync=async k=>globalThis.nativeAccountStore.get(k)||null; export const setItemAsync=async(k,v)=>{globalThis.nativeAccountStore.set(k,v)}; export const deleteItemAsync=async k=>{globalThis.nativeAccountStore.delete(k)};',
          ),
        shortCircuit: true,
      };
    return n(s, c);
  },
});
const {
  storedSession,
  saveSession,
  forgetSession,
  nativeApi,
  NativeApiError,
  NativeRequestAborted,
  cacheProfile,
  cachedProfile,
} = await import('../mobile/src/account-client.ts');

test('a cancelled native read never starts transport or clears the account session', async () => {
  const original = globalThis.fetch;
  let calls = 0;
  const controller = new AbortController();
  const token = 'f'.repeat(64);
  await saveSession(token);
  controller.abort();
  globalThis.fetch = async () => {
    calls++;
    return Response.json({});
  };
  try {
    await assert.rejects(
      nativeApi('bookings', token, undefined, undefined, controller.signal),
      (error) =>
        error instanceof NativeRequestAborted && error.name === 'AbortError',
    );
    assert.equal(calls, 0);
    assert.equal(await storedSession(), token);
  } finally {
    globalThis.fetch = original;
  }
});

test('native screen cancellation aborts an in-flight read rather than reporting an offline error', async () => {
  const original = globalThis.fetch;
  const controller = new AbortController();
  let release;
  let transportSignal;
  globalThis.fetch = (_url, options) => {
    transportSignal = options.signal;
    return new Promise((resolve, reject) => {
      release = () => resolve(Response.json({ bookings: [] }));
      options.signal.addEventListener(
        'abort',
        () => reject(new Error('synthetic abort')),
        { once: true },
      );
    });
  };
  try {
    const read = nativeApi(
      'bookings',
      'a'.repeat(64),
      undefined,
      undefined,
      controller.signal,
    );
    const rejected = assert.rejects(
      read,
      (error) =>
        error instanceof NativeRequestAborted && error.name === 'AbortError',
    );
    controller.abort();
    release();
    await rejected;
    assert.equal(transportSignal.aborted, true);
  } finally {
    release?.();
    globalThis.fetch = original;
  }
});

test('cancellation during response decoding cannot deliver old native data', async () => {
  const original = globalThis.fetch,
    controller = new AbortController();
  let release;
  const body = new Promise((resolve) => {
    release = resolve;
  });
  globalThis.fetch = async () => ({ ok: true, json: () => body });
  try {
    const read = nativeApi(
      'bookings',
      'a'.repeat(64),
      undefined,
      undefined,
      controller.signal,
    );
    const rejected = assert.rejects(
      read,
      (error) => error instanceof NativeRequestAborted,
    );
    await new Promise((resolve) => setImmediate(resolve));
    controller.abort();
    release({ bookings: [{ id: 'stale' }] });
    await rejected;
  } finally {
    release?.({});
    globalThis.fetch = original;
  }
});

test('successful native reads remove their caller abort listener and preserve API errors', async () => {
  const original = globalThis.fetch,
    controller = new AbortController();
  let transportSignal;
  globalThis.fetch = async (_url, options) => {
    transportSignal = options.signal;
    return Response.json({ bookings: [] });
  };
  try {
    await nativeApi(
      'bookings',
      'a'.repeat(64),
      undefined,
      undefined,
      controller.signal,
    );
    controller.abort();
    assert.equal(transportSignal.aborted, false);
    globalThis.fetch = async () =>
      Response.json({ error: 'Keine Fahrerfreigabe' }, { status: 403 });
    await assert.rejects(
      nativeApi('driver', 'a'.repeat(64)),
      (error) =>
        error instanceof NativeApiError &&
        error.status === 403 &&
        error.message === 'Keine Fahrerfreigabe',
    );
  } finally {
    globalThis.fetch = original;
  }
});
test('native account survives restart in protected storage, rejects malformed credentials and is explicitly cleared', async () => {
  globalThis.nativeAccountStore.clear();
  const token = 'a'.repeat(64);
  await saveSession(token);
  assert.equal(await storedSession(), token);
  await assert.rejects(saveSession('invalid'), /Anmeldeantwort/);
  assert.equal(await storedSession(), token);
  await forgetSession();
  assert.equal(await storedSession(), null);
});
test('cached native profile survives an offline restart but is isolated from different sessions and logout', async () => {
  globalThis.nativeAccountStore.clear();
  const token = 'c'.repeat(64),
    account = {
      id: 'local-test',
      name: 'Test',
      email: 'test@example.com',
      phone: '+490000000',
      kind: 'driver',
    };
  await saveSession(token);
  await cacheProfile(token, account);
  assert.deepEqual(await cachedProfile(token), account);
  assert.equal(await cachedProfile('d'.repeat(64)), null);
  await cacheProfile('d'.repeat(64), { ...account, name: 'Old response' });
  assert.deepEqual(await cachedProfile(token), account);
  await forgetSession();
  assert.equal(await cachedProfile(token), null);
});
test('native requests use own HTTPS origin and bearer header; transport errors do not erase the session', async () => {
  const oldFetch = globalThis.fetch;
  const token = 'b'.repeat(64);
  await saveSession(token);
  try {
    globalThis.fetch = async (url, options) => {
      assert.equal(url, 'https://luxoreride.de/api/mobility/account');
      assert.equal(options.headers.Authorization, 'Bearer ' + token);
      assert.equal(options.headers.Origin, 'https://luxoreride.de');
      assert.equal(options.redirect, 'error');
      assert.equal(options.credentials, 'omit');
      return Response.json({ account: { id: 'native-synthetic' } });
    };
    assert.equal(
      (await nativeApi('account', token)).account.id,
      'native-synthetic',
    );
    await assert.rejects(nativeApi('../outside', token), /Ungültige/);
    globalThis.fetch = async () => {
      throw new TypeError('offline');
    };
    await assert.rejects(nativeApi('account', token), /Keine Verbindung/);
    assert.equal(await storedSession(), token);
    globalThis.fetch = async () =>
      Response.json({ error: 'Bitte neu anmelden.' }, { status: 401 });
    await assert.rejects(
      nativeApi('account', token),
      (e) => e instanceof NativeApiError && e.status === 401,
    );
    assert.equal(await storedSession(), token);
  } finally {
    globalThis.fetch = oldFetch;
    await forgetSession();
  }
});
test('native fleet query parameters stay encoded inside the own API path', async () => {
  const oldFetch = globalThis.fetch;
  try {
    globalThis.fetch = async (url) => {
      assert.equal(
        url,
        'https://luxoreride.de/api/mobility/vehicles?fleetId=a%26other%3D1',
      );
      return Response.json({ vehicles: [] });
    };
    await nativeApi('vehicles', 'a'.repeat(64), undefined, {
      fleetId: 'a&other=1',
    });
    await assert.rejects(nativeApi('vehicles?fleetId=evil', null), /Ungültige/);
    await assert.rejects(nativeApi('https://other.example', null), /Ungültige/);
  } finally {
    globalThis.fetch = oldFetch;
  }
});
