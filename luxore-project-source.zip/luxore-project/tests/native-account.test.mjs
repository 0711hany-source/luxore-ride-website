import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import test from 'node:test';
import assert from 'node:assert/strict';
globalThis.nativeAccountStore = new Map();
registerHooks({
  resolve(s, c, n) {
    if (s === 'expo-secure-store')
      return {
        url:
          'data:text/javascript,' +
          encodeURIComponent(
            'export const getItemAsync=async k=>globalThis.nativeAccountStore.get(k)||null; export const setItemAsync=async(k,v)=>{globalThis.nativeAccountStore.set(k,v)}; export const deleteItemAsync=async k=>{globalThis.nativeAccountStore.delete(k)};',
          ),
        shortCircuit: true,
      };
    return n(s, c);
  },
});
const { storedSession, saveSession, forgetSession, nativeApi, NativeApiError } =
  await import('../mobile/src/account-client.ts');
test('native account survives restart in protected storage, rejects malformed credentials and is explicitly cleared', async () => {
  globalThis.nativeAccountStore.clear();
  const token = 'a'.repeat(64);
  await saveSession(token);
  assert.equal(await storedSession(), token);
  await assert.rejects(saveSession('invalid'), /Anmeldeantwort/);
  assert.equal(await storedSession(), token);
  await forgetSession();
  assert.equal(await storedSession(), null);
});
test('native requests use own HTTPS origin and bearer header; transport errors do not erase the session', async () => {
  const oldFetch = globalThis.fetch;
  const token = 'b'.repeat(64);
  await saveSession(token);
  try {
    globalThis.fetch = async (url, options) => {
      assert.equal(url, 'https://luxoreride.de/api/mobility/account');
      assert.equal(options.headers.Authorization, 'Bearer ' + token);
      assert.equal(options.headers.Origin, 'https://luxoreride.de');
      assert.equal(options.redirect, 'error');
      assert.equal(options.credentials, 'omit');
      return Response.json({ account: { id: 'native-synthetic' } });
    };
    assert.equal(
      (await nativeApi('account', token)).account.id,
      'native-synthetic',
    );
    await assert.rejects(nativeApi('../outside', token), /Ungültige/);
    globalThis.fetch = async () => {
      throw new TypeError('offline');
    };
    await assert.rejects(nativeApi('account', token), /Keine Verbindung/);
    assert.equal(await storedSession(), token);
    globalThis.fetch = async () =>
      Response.json({ error: 'Bitte neu anmelden.' }, { status: 401 });
    await assert.rejects(
      nativeApi('account', token),
      (e) => e instanceof NativeApiError && e.status === 401,
    );
    assert.equal(await storedSession(), token);
  } finally {
    globalThis.fetch = oldFetch;
    await forgetSession();
  }
});
