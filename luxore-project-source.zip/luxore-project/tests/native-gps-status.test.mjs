import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
const requireMobile = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const reactModules = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((n) => [
    n,
    pathToFileURL(requireMobile.resolve(n)).href,
  ]),
);
const virtual = (source) => ({
  url: 'data:text/javascript,' + encodeURIComponent(source),
  shortCircuit: true,
});
registerHooks({
  resolve(s, c, next) {
    if (reactModules.has(s))
      return { url: reactModules.get(s), shortCircuit: true };
    if (s === 'react-native')
      return virtual(
        `export const Platform={OS:'android'}; export const AppState={get currentState(){return globalThis.gpsHook.state},addEventListener(_,f){globalThis.gpsHook.listeners.add(f);return {remove(){globalThis.gpsHook.listeners.delete(f)}}}};`,
      );
    if (s === 'expo-location')
      return virtual(
        `export const Accuracy={BestForNavigation:6};export const watchPositionAsync=async(o,f)=>{const x={f,removed:false,remove(){this.removed=true}};globalThis.gpsHook.watchers.push(x);return x};export const getLastKnownPositionAsync=async()=>null;export const getCurrentPositionAsync=async()=>({coords:{latitude:50.11,longitude:8.68,accuracy:8},timestamp:Date.now()-2000});`,
      );
    if (s === './location-service')
      return virtual(
        `export const foregroundPermission=async()=>{},deliverForeground=async()=>{};export const resumeLocation=()=>globalThis.gpsHook.resume();export const point=p=>({lat:p.coords.latitude,lng:p.coords.longitude,accuracy:p.coords.accuracy,timestamp:p.timestamp});`,
      );
    return next(s, c);
  },
  load(url, c, next) {
    if (
      url.endsWith('/mobile/src/use-driver-gps.ts') &&
      process.env.TEST_ORIGINAL_GPS_HOOK
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_GPS_HOOK, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { useDriverGps } = await import('../mobile/src/use-driver-gps.ts');
function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => {
    resolve = yes;
    reject = no;
  });
  return { promise, resolve, reject };
}
const position = (lng = 8.68) => ({
  lat: 50.11,
  lng,
  accuracy: 8,
  timestamp: Date.now() - 500,
});
const active = (sessionId, p) => ({ active: true, sessionId, position: p });
async function fixture() {
  const f = {
    state: 'active',
    listeners: new Set(),
    watchers: [],
    resume: async () => ({ active: false }),
    value: null,
    r: null,
  };
  globalThis.gpsHook = f;
  function Harness() {
    const value = useDriverGps();
    React.useLayoutEffect(() => {
      f.value = value;
    }, [value]);
    return React.createElement('Probe', { session: value.sessionId });
  }
  await act(async () => {
    f.r = Renderer.create(React.createElement(Harness));
    await new Promise((r) => setImmediate(r));
  });
  f.change = async (state) => {
    await act(async () => {
      f.state = state;
      f.listeners.forEach((fn) => fn(state));
      await new Promise((r) => setImmediate(r));
    });
  };
  f.close = async () => {
    await act(async () => f.r.unmount());
  };
  return f;
}
void test('late active GPS status cannot restore a shift after a newer confirmed pause', async () => {
  const f = await fixture(),
    old = deferred();
  try {
    f.resume = () => old.promise;
    let reading;
    await act(async () => {
      reading = f.value.sync();
    });
    f.resume = async () => ({ active: false });
    await act(async () => f.value.sync());
    assert.equal(f.value.sessionId, null);
    await act(async () => {
      old.resolve(active('ended-shift', position(8.68008)));
      await reading;
    });
    assert.equal(f.value.sessionId, null);
    assert.notEqual(f.value.position?.lng, 8.68008);
  } finally {
    old.resolve({ active: false });
    await f.close();
  }
});
void test('late inactive GPS status cannot erase a newly confirmed active session', async () => {
  const f = await fixture(),
    old = deferred();
  try {
    f.resume = () => old.promise;
    let reading;
    await act(async () => {
      reading = f.value.sync();
    });
    f.resume = async () => active('new-shift', position(8.68001));
    await act(async () => f.value.sync());
    await act(async () => {
      old.resolve({ active: false });
      await reading;
    });
    assert.equal(f.value.sessionId, 'new-shift');
    assert.equal(f.value.position.lng, 8.68001);
  } finally {
    old.resolve({ active: false });
    await f.close();
  }
});
void test('background and foreground recovery invalidate an earlier native status response', async () => {
  const f = await fixture(),
    old = deferred();
  try {
    f.resume = () => old.promise;
    let reading;
    await act(async () => {
      reading = f.value.sync();
    });
    await f.change('background');
    assert.equal(f.value.foreground, false);
    assert.ok(f.watchers.every((w) => w.removed));
    f.resume = async () => active('returned-shift', position(8.68002));
    await f.change('active');
    assert.equal(f.value.sessionId, 'returned-shift');
    await act(async () => {
      old.resolve(active('old-background', position(8.68003)));
      await reading;
    });
    assert.equal(f.value.sessionId, 'returned-shift');
    assert.equal(f.value.position.lng, 8.68002);
  } finally {
    old.resolve({ active: false });
    await f.close();
  }
});
void test('native status finishing in background cannot update visible session or position', async () => {
  const f = await fixture(),
    old = deferred();
  try {
    f.resume = () => old.promise;
    let reading;
    await act(async () => {
      reading = f.value.sync();
    });
    await f.change('background');
    await act(async () => {
      old.resolve(active('hidden-session', position(8.68004)));
      await reading;
    });
    assert.equal(f.value.sessionId, null);
    assert.notEqual(f.value.position?.lng, 8.68004);
  } finally {
    old.resolve({ active: false });
    await f.close();
  }
});
void test('old completion/failure does not release a newer pending GPS sync', async () => {
  const f = await fixture(),
    old = deferred(),
    fresh = deferred();
  try {
    f.resume = () => old.promise;
    let a, b;
    await act(async () => {
      a = f.value.sync();
    });
    f.resume = () => fresh.promise;
    await act(async () => {
      b = f.value.sync();
    });
    await act(async () => {
      old.reject(new Error('old native error'));
      await assert.rejects(a, /old native/);
    });
    await act(async () => {
      fresh.resolve(active('latest-session', position(8.68005)));
      await b;
    });
    assert.equal(f.value.sessionId, 'latest-session');
  } finally {
    old.resolve({ active: false });
    fresh.resolve({ active: false });
    await f.close();
  }
});
void test('restart cancels the preceding native status and preserves the replacement session', async () => {
  const f = await fixture(),
    old = deferred();
  try {
    f.resume = () => old.promise;
    let reading;
    await act(async () => {
      reading = f.value.sync();
    });
    f.resume = async () => active('restart-session', position(8.68006));
    await act(async () => f.value.restart());
    await act(async () => {
      old.resolve(active('superseded-session', position(8.68007)));
      await reading;
    });
    assert.equal(f.value.sessionId, 'restart-session');
    assert.equal(f.value.position.lng, 8.68006);
  } finally {
    old.resolve({ active: false });
    await f.close();
  }
});
