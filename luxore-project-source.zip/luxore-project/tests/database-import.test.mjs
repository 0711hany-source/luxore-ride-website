import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, readFileSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { createHash } from 'node:crypto';

const root=resolve(import.meta.dirname,'..');
function schema(path) {
  const db=new DatabaseSync(path);
  for(const name of readdirSync(join(root,'drizzle')).filter(n=>n.endsWith('.sql')).sort())db.exec(readFileSync(join(root,'drizzle',name),'utf8'));
  return db;
}
function rows(path,sql) {
  const db=new DatabaseSync(path,{readOnly:true});
  try {const stmt=db.prepare(sql);stmt.setReadBigInts(true);return stmt.all().map(row=>Object.fromEntries(Object.entries(row)));} finally {db.close();}
}
function fixture(t) {
  const dir=mkdtempSync(join(tmpdir(),'luxore-private-import-'));
  t.after(()=>rmSync(dir,{recursive:true,force:true}));
  const source=join(dir,'source.sqlite'),target=join(dir,'target.sqlite');
  const s=schema(source),d=schema(target);
  const payload=JSON.stringify({address:"Frankfurt · Straße d'Essai",preferences:['Ruhe','Kühle Temperatur'],notes:'prüfen € '.repeat(4000)});
  s.prepare('INSERT INTO mobility_accounts(id,email,name,phone,kind,verified_at,created_at) VALUES(?,?,?,?,?,?,?)').run('owner','owner@example.test','Test Fahrer','+490000000','fleet',1000,1000);
  s.prepare('INSERT INTO mobility_fleets(id,name,created_at) VALUES(?,?,?)').run('fleet','Luxóre Testflotte',1000);
  s.prepare('INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,?,?,?,?,?)').run('account:owner','Test Fahrer','+490000000','fleet','owner',1000);
  s.prepare('INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,created_at) VALUES(?,?,?,?,?,?)').run('vehicle','fleet','Mercedes Test','GG TEST 711','["business","first"]',1000);
  s.prepare('INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,lat,lng,accuracy,session_id,vehicle_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)').run('account:owner','Test Fahrer','+490000000','Mercedes Test','GG TEST 711','first',1,1,50.1,8.6,5,'old-session','vehicle');
  s.prepare('INSERT INTO mobility_quotes(id,owner_id,payload,expires_at) VALUES(?,?,?,?)').run('quote','account:customer',payload,9999999);
  s.prepare('INSERT INTO mobility_bookings(id,quote_id,owner_id,service,price,route,mode,status,driver_id,created_at,updated_at,fleet_id,vehicle_id,payment_status,payment_method,paid_at,completed_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run('booking','quote','account:customer','first',3580,payload,'now','completed','account:owner',1000,2000,'fleet','vehicle','paid','cash',2000,2000);
  s.prepare('INSERT INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at) VALUES(?,?,?,?,?,?)').run('pending-offer','booking','account:owner','pending',9999999,1000);
  s.close();d.close();
  const run=(native=false,destination=target)=>spawnSync(process.execPath,[join(root,'scripts/import-database.mjs'),source],{
    cwd:root,encoding:'utf8',timeout:15000,
    env:{...process.env,DATABASE_URL:native?'':`file:${destination}`,DATABASE_AUTH_TOKEN:'',TURSO_DATABASE_URL:native?`file:${destination}`:'',TURSO_AUTH_TOKEN:'',LUXORE_BOOKING_ENABLED:'false'},
  });
  return {source,target,run};
}
function assertEmpty(path) {
  const db=new DatabaseSync(path,{readOnly:true});
  try {for(const {name} of db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '\\_%' ESCAPE '\\'").all())assert.equal(db.prepare('SELECT COUNT(*) n FROM "'+name+'"').get().n,0,name);}finally{db.close();}
}
function change(path,sql) {const db=new DatabaseSync(path);try{db.exec(sql);}finally{db.close();}}
const fingerprint=path=>createHash('sha256').update(readFileSync(path)).digest('hex');

test('complete import preserves full route text, fleet rights, classes and collected fare; only stale availability resets',t=>{
  const f=fixture(t),before=fingerprint(f.source),r=f.run();
  assert.equal(r.status,0,r.stderr);
  const report=JSON.parse(r.stdout);
  assert.equal(report.imported.length,21);
  assert.ok(report.imported.every(r=>/^[a-f0-9]{64}$/.test(r.sha256)));
  for(const table of ['mobility_accounts','mobility_fleets','mobility_employees','mobility_vehicles','mobility_quotes','mobility_bookings'])assert.deepEqual(rows(f.target,'SELECT * FROM '+table),rows(f.source,'SELECT * FROM '+table));
  assert.deepEqual(rows(f.target,'SELECT approved,online,lat,lng,accuracy,session_id,vehicle_id FROM mobility_drivers')[0],{approved:1n,online:0n,lat:null,lng:null,accuracy:null,session_id:null,vehicle_id:'vehicle'});
  assert.equal(rows(f.target,'SELECT status FROM mobility_offers')[0].status,'expired');
  assert.equal(fingerprint(f.source),before);
});
test('native Turso environment pair works for the migration command and the import command',t=>{
  const f=fixture(t);
  const destination=f.target+'.migrated';
  const env={...process.env,DATABASE_URL:'',DATABASE_AUTH_TOKEN:'',TURSO_DATABASE_URL:`file:${destination}`,TURSO_AUTH_TOKEN:''};
  const r=spawnSync(process.execPath,[join(root,'scripts/migrate-database.mjs')],{cwd:root,encoding:'utf8',timeout:15000,env});
  assert.equal(r.status,0,r.stderr);
  assert.equal(rows(destination,'SELECT COUNT(*) n FROM _luxore_migrations')[0].n,18n);
  const repeated=spawnSync(process.execPath,[join(root,'scripts/migrate-database.mjs')],{cwd:root,encoding:'utf8',timeout:15000,env});
  assert.equal(repeated.status,0,repeated.stderr);assert.equal(repeated.stdout,'');
  const imported=f.run(true,destination);assert.equal(imported.status,0,imported.stderr);
});
test('unknown table or extra field is rejected instead of silently discarding source data',t=>{
  for(const sql of ['CREATE TABLE new_business_records(id TEXT PRIMARY KEY); INSERT INTO new_business_records VALUES(\'preserve\')',"ALTER TABLE mobility_fleets ADD extra_owner_note TEXT; UPDATE mobility_fleets SET extra_owner_note='preserve'"]){
    const f=fixture(t);change(f.source,sql);const before=fingerprint(f.source),r=f.run();
    assert.notEqual(r.status,0);assert.match(r.stderr,/Unsupported snapshot table|Snapshot column mismatch/);assertEmpty(f.target);assert.equal(fingerprint(f.source),before);
  }
});
test('a missing business table prevents any partial import',t=>{
  const f=fixture(t);change(f.source,'DROP TABLE mobility_stock_movements');const r=f.run();
  assert.notEqual(r.status,0);assert.match(r.stderr,/Incomplete snapshot/);assertEmpty(f.target);
});
test('an existing target record is never overwritten or merged',t=>{
  const f=fixture(t);change(f.target,"INSERT INTO mobility_fleets(id,name,created_at) VALUES('existing','Existing fleet',123)");const r=f.run();
  assert.notEqual(r.status,0);assert.match(r.stderr,/Target is not empty/);
  assert.deepEqual(rows(f.target,'SELECT id,name,created_at FROM mobility_fleets'),[{id:'existing',name:'Existing fleet',created_at:123n}]);
  assert.equal(rows(f.target,'SELECT COUNT(*) n FROM mobility_accounts')[0].n,0n);
});
test('same row counts cannot hide a target trigger changing contents; the whole transaction rolls back',t=>{
  const f=fixture(t);change(f.target,"CREATE TRIGGER alter_import AFTER INSERT ON mobility_fleets BEGIN UPDATE mobility_fleets SET name=lower(name) WHERE id=NEW.id; END");const r=f.run();
  assert.notEqual(r.status,0);assert.match(r.stderr,/Snapshot content mismatch/);assertEmpty(f.target);
});
test('unique vehicle constraints failing mid-import roll back all earlier records',t=>{
  const f=fixture(t);change(f.source,"DROP INDEX idx_vehicle_active_plate; INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,created_at) VALUES('duplicate','fleet','Other','GG TEST 711','[\"first\"]',1000)");const r=f.run();
  assert.notEqual(r.status,0);assert.match(r.stderr,/UNIQUE constraint failed/);assertEmpty(f.target);
});
test('64-bit integers, blobs, nulls and embedded zero characters survive without rounding or truncation',t=>{
  const f=fixture(t);
  for(const path of [f.source,f.target])change(path,'CREATE TABLE legacy_binary(id TEXT PRIMARY KEY, bytes BLOB, amount INTEGER, text_value TEXT, real_value REAL, missing TEXT)');
  const db=new DatabaseSync(f.source);
  db.prepare('INSERT INTO legacy_binary VALUES(?,?,?,?,?,?)').run('large',new Uint8Array([0,255,128,1]),9223372036854775807n,'Grüße\0€',1.25,null);
  db.prepare('INSERT INTO legacy_binary VALUES(?,?,?,?,?,?)').run('negative',new Uint8Array([]),-9223372036854775808n,'',0,null);db.close();
  const r=f.run();assert.equal(r.status,0,r.stderr);
  assert.deepEqual(rows(f.target,'SELECT * FROM legacy_binary ORDER BY id'),rows(f.source,'SELECT * FROM legacy_binary ORDER BY id'));
});
