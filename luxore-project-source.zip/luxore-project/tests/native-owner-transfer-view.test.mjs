import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
const store = new Map([['luxore-account-v1', 'a'.repeat(64)]]);
globalThis.nativeViewStore = store;
globalThis.customerAppListeners = new Set();
globalThis.require = () => 1; // Metro resolves static PNG assets in real APKs.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    'expo-location',
    `export const Accuracy={High:4}; export const requestForegroundPermissionsAsync=async()=>({status:'denied'}),getCurrentPositionAsync=async()=>{throw new Error('GPS not enabled in view tests')};`,
  ],
  [
    'react-native',
    `
    export const View='View', Text='Text', Pressable='Pressable', ScrollView='ScrollView', Modal='Modal', Image='Image', TextInput='TextInput', KeyboardAvoidingView='KeyboardAvoidingView', ActivityIndicator='ActivityIndicator';
    export const Platform={OS:'android'}, StyleSheet={create:v=>v}, Keyboard={dismiss(){}}, Share={async share(){}}, Linking={async openURL(){},async openSettings(){}}, Alert={alert(){}};
    export const AppState={currentState:'active',addEventListener(event,listener){globalThis.customerAppListeners.add(listener);return {remove(){globalThis.customerAppListeners.delete(listener)}}}}, BackHandler={addEventListener(){return {remove(){}}}};
    export const useWindowDimensions=()=>({width:390,height:844});
    export const PanResponder={create:handlers=>({panHandlers:handlers})};
    export const Animated={Value:class {constructor(v){this.value=v}setValue(v){this.value=v}},View:'AnimatedView',spring:(v,o)=>({start:()=>v.setValue(o.toValue)})};
  `,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaProvider='SafeAreaProvider', SafeAreaView='SafeAreaView';`,
  ],
  ['expo-status-bar', `export const StatusBar='StatusBar';`],
  ['expo-constants', `export default {expoConfig:{extra:{variant:'driver'}}};`],
  [
    'expo-secure-store',
    `export const getItemAsync=async k=>globalThis.nativeViewStore.get(k)||null,setItemAsync=async(k,v)=>{globalThis.nativeViewStore.set(k,v)},deleteItemAsync=async k=>{globalThis.nativeViewStore.delete(k)};`,
  ],
  [
    'expo-crypto',
    `export const randomUUID=()=> 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';`,
  ],
  [
    'expo-notifications',
    `export const getLastNotificationResponse=()=>null,clearLastNotificationResponse=()=>{},addNotificationResponseReceivedListener=()=>({remove(){}});`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',ArrowRight='ArrowRight', CalendarDays='CalendarDays', CarFront='CarFront', Check='Check', ChevronRight='ChevronRight', CircleHelp='CircleHelp', Home='Home', LogOut='LogOut', Mail='Mail', MapPinned='MapPinned', MapPin='MapPin', Clock3='Clock3', Settings='Settings', ShieldCheck='ShieldCheck', UserRound='UserRound', Users='Users',ChevronDown='ChevronDown',LocateFixed='LocateFixed',Navigation='Navigation',Phone='Phone',RefreshCw='RefreshCw',X='X',Plus='Plus',Minus='Minus',Search='Search';`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    let source = mocked.get(specifier);
    if (specifier.endsWith('/RideWorkspace') || specifier === './RideWorkspace')
      source = `export default function ForbiddenEmbeddedDriver(){throw new Error('Driver mounted a WebView');}`;
    if (specifier === './use-driver-gps')
      source = `export function useDriverGps(){return {position:{lat:50.11,lng:8.68,accuracy:8,timestamp:Date.now()},sessionId:null,error:'',foreground:true,restart:async()=>{},sync:async()=>({active:false})}}`;
    if (specifier === './location-service')
      source = `export const resumeLocation=async()=>({active:false}),stopLocation=async()=>{},foregroundPermission=async()=>{},startLocation=async()=>({active:true});`;
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: OperationsScreen } =
  await import('../mobile/src/OperationsScreen.tsx');

const base = () => ({
  userId: 'operator',
  canManage: true,
  fleets: [{ id: 'f', name: 'Flotte A', owner_id: 'old', deputy_id: 'next' }],
  employees: [
    {
      user_id: 'old',
      name: 'Bisheriger Besitzer',
      fleet_id: 'f',
      can_remove: 1,
    },
    {
      user_id: 'next',
      name: 'Neue Besitzerin',
      fleet_id: 'f',
      driver_id: 'next',
      approved: 1,
      can_remove: 1,
    },
    {
      user_id: 'staff',
      name: 'Personal ohne Fahrerprofil',
      fleet_id: 'f',
      can_remove: 1,
    },
    {
      user_id: 'busy',
      name: 'Aktive Schicht',
      fleet_id: 'f',
      driver_id: 'busy',
      approved: 1,
      can_remove: 0,
    },
  ],
  revenue: [],
});
async function settle() {
  for (let i = 0; i < 7; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
const modal = (r) => r.root.findAllByType('Modal').find((n) => n.props.visible);
const text = (r) =>
  r.root
    .findAllByType('Text')
    .map((n) => n.children.filter((c) => typeof c === 'string').join(''))
    .join(' ');
async function press(r, label) {
  await act(async () =>
    r.root.findByProps({ accessibilityLabel: label }).props.onPress(),
  );
  await settle();
}
async function swipe(r, label, dx) {
  const gesture = modal(r).findByProps({
    accessibilityLabel: label + ' · vollständig nach rechts wischen',
  });
  await act(async () => {
    modal(r)
      .findAllByType('View')
      .filter((n) => n.props.onLayout)
      .forEach((n) =>
        n.props.onLayout({ nativeEvent: { layout: { width: 330 } } }),
      );
  });
  await act(async () => gesture.props.onPanResponderRelease(null, { dx }));
  await settle();
}
const mount = async () => {
  let r;
  await act(async () => {
    r = Renderer.create(
      React.createElement(OperationsScreen, {
        token: 'a'.repeat(64),
        active: true,
        onFleet() {},
      }),
    );
  });
  await settle();
  return r;
};
void test('actual native owner dialog filters eligible people and only a complete swipe sends expected old owner', async () => {
  const old = globalThis.fetch,
    data = base(),
    writes = [];
  let r;
  globalThis.fetch = async (url, opts) => {
    if (url.endsWith('/operations'))
      return Response.json({ drivers: [], bookings: [] });
    if (opts.method === 'POST') {
      const b = JSON.parse(opts.body);
      writes.push(b);
      data.fleets[0].owner_id = b.ownerId;
      data.fleets[0].deputy_id = null;
      return Response.json({ ok: true });
    }
    return Response.json(data);
  };
  try {
    r = await mount();
    await press(r, 'Besitz übergeben');
    assert.equal(modal(r).props.presentationStyle, 'fullScreen');
    assert.equal(
      modal(r).findAllByProps({
        accessibilityLabel: 'Besitzer Personal ohne Fahrerprofil auswählen',
      }).length,
      0,
    );
    assert.equal(
      modal(r).findAllByProps({
        accessibilityLabel: 'Besitzer Aktive Schicht auswählen',
      }).length,
      0,
    );
    await press(r, 'Besitzer Neue Besitzerin auswählen');
    assert.match(text(r), /Fahrerfreigaben bleiben/);
    const gesture = modal(r).findByProps({
      accessibilityLabel: 'Besitz übergeben · vollständig nach rechts wischen',
    });
    assert.equal(gesture.props.onPress, undefined);
    await swipe(r, 'Besitz übergeben', 30);
    assert.equal(writes.length, 0);
    await swipe(r, 'Besitz übergeben', 260);
    assert.deepEqual(writes, [
      {
        action: 'transfer_owner',
        fleetId: 'f',
        previousOwnerId: 'old',
        ownerId: 'next',
        confirmed: true,
      },
    ]);
    assert.match(text(r), /Besitzerübergabe gespeichert/);
  } finally {
    if (r) await act(async () => r.unmount());
    globalThis.fetch = old;
  }
});
void test('actual dialog pins uncertain selection, checks server before retry and ends conflicting local review only by swipe', async () => {
  const old = globalThis.fetch,
    data = base(),
    writes = [];
  let r,
    failRead = false;
  globalThis.fetch = async (url, opts) => {
    if (url.endsWith('/operations'))
      return Response.json({ drivers: [], bookings: [] });
    if (opts.method === 'POST') {
      writes.push(JSON.parse(opts.body));
      failRead = true;
      throw new Error('Synthetic lost response');
    }
    if (failRead) throw new Error('Synthetic network');
    return Response.json(data);
  };
  try {
    r = await mount();
    await press(r, 'Besitz übergeben');
    await press(r, 'Besitzer Neue Besitzerin auswählen');
    await swipe(r, 'Besitz übergeben', 260);
    assert.match(text(r), /Zuerst den aktuellen Serverstand/);
    assert.equal(
      modal(r).findAll(
        (n) =>
          typeof n.type === 'function' &&
          n.type.name === 'SwipeAction' &&
          n.props.label === 'Gleiche Übergabe bestätigen',
      )[0].props.disabled,
      true,
    );
    assert.equal(
      modal(r).findAllByProps({ accessibilityRole: 'radio' }).length,
      0,
    );
    assert.equal(
      r.root.findByProps({ accessibilityLabel: 'Stellvertretung verwalten' })
        .props.disabled,
      true,
    );
    failRead = false;
    data.fleets[0].owner_id = 'third';
    await press(r, 'Übergabestand laden');
    assert.equal(writes.length, 1);
    assert.match(text(r), /inzwischen geändert/);
    assert.equal(
      modal(r).findAll(
        (n) =>
          typeof n.type === 'function' &&
          n.type.name === 'SwipeAction' &&
          n.props.label === 'Gleiche Übergabe bestätigen',
      )[0].props.disabled,
      true,
    );
    await swipe(r, 'Geprüfte Anfrage beenden', 30);
    assert.match(text(r), /inzwischen geändert/);
    await swipe(r, 'Geprüfte Anfrage beenden', 260);
    assert.equal(writes.length, 1);
    assert.match(text(r), /keine weitere Übergabe/);
  } finally {
    if (r) await act(async () => r.unmount());
    globalThis.fetch = old;
  }
});
void test('ordinary owner or deputy receives no native owner transfer entry or new platform rights', async () => {
  const old = globalThis.fetch;
  let r;
  const data = base();
  data.canManage = false;
  data.userId = 'old';
  globalThis.fetch = async (url) =>
    Response.json(
      url.endsWith('/operations') ? { drivers: [], bookings: [] } : data,
    );
  try {
    r = await mount();
    assert.equal(
      r.root.findAllByProps({ accessibilityLabel: 'Besitz übergeben' }).length,
      0,
    );
    assert.equal(
      r.root.findAllByType('Modal').filter((n) => n.props.visible).length,
      0,
    );
  } finally {
    if (r) await act(async () => r.unmount());
    globalThis.fetch = old;
  }
});
