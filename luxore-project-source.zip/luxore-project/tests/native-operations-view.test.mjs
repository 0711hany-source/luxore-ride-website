import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
const store = new Map([['luxore-account-v1', 'a'.repeat(64)]]);
globalThis.nativeViewStore = store;
globalThis.customerAppListeners = new Set();
globalThis.require = () => 1; // Metro resolves static PNG assets in real APKs.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    'expo-location',
    `export const Accuracy={High:4}; export const requestForegroundPermissionsAsync=async()=>({status:'denied'}),getCurrentPositionAsync=async()=>{throw new Error('GPS not enabled in view tests')};`,
  ],
  [
    'react-native',
    `
    export const View='View', Text='Text', Pressable='Pressable', ScrollView='ScrollView', Modal='Modal', Image='Image', TextInput='TextInput', KeyboardAvoidingView='KeyboardAvoidingView', ActivityIndicator='ActivityIndicator';
    export const Platform={OS:'android'}, StyleSheet={create:v=>v}, Keyboard={dismiss(){}}, Share={async share(){}}, Linking={async openURL(){},async openSettings(){}}, Alert={alert(){}};
    export const AppState={currentState:'active',addEventListener(event,listener){globalThis.customerAppListeners.add(listener);return {remove(){globalThis.customerAppListeners.delete(listener)}}}}, BackHandler={addEventListener(){return {remove(){}}}};
    export const useWindowDimensions=()=>({width:390,height:844});
    export const PanResponder={create:handlers=>({panHandlers:handlers})};
    export const Animated={Value:class {constructor(v){this.value=v}setValue(v){this.value=v}},View:'AnimatedView',spring:(v,o)=>({start:()=>v.setValue(o.toValue)})};
  `,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaProvider='SafeAreaProvider', SafeAreaView='SafeAreaView';`,
  ],
  ['expo-status-bar', `export const StatusBar='StatusBar';`],
  ['expo-constants', `export default {expoConfig:{extra:{variant:'driver'}}};`],
  [
    'expo-secure-store',
    `export const getItemAsync=async k=>globalThis.nativeViewStore.get(k)||null,setItemAsync=async(k,v)=>{globalThis.nativeViewStore.set(k,v)},deleteItemAsync=async k=>{globalThis.nativeViewStore.delete(k)};`,
  ],
  [
    'expo-crypto',
    `export const randomUUID=()=> 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';`,
  ],
  [
    'expo-notifications',
    `export const getLastNotificationResponse=()=>null,clearLastNotificationResponse=()=>{},addNotificationResponseReceivedListener=()=>({remove(){}});`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',ArrowRight='ArrowRight', CalendarDays='CalendarDays', CarFront='CarFront', Check='Check', ChevronRight='ChevronRight', CircleHelp='CircleHelp', Home='Home', LogOut='LogOut', Mail='Mail', MapPinned='MapPinned', MapPin='MapPin', Clock3='Clock3', Settings='Settings', ShieldCheck='ShieldCheck', UserRound='UserRound', Users='Users',ChevronDown='ChevronDown',LocateFixed='LocateFixed',Navigation='Navigation',Phone='Phone',RefreshCw='RefreshCw',X='X',Plus='Plus',Minus='Minus',Search='Search';`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    let source = mocked.get(specifier);
    if (specifier.endsWith('/RideWorkspace') || specifier === './RideWorkspace')
      source = `export default function ForbiddenEmbeddedDriver(){throw new Error('Driver mounted a WebView');}`;
    if (specifier === './use-driver-gps')
      source = `export function useDriverGps(){return {position:{lat:50.11,lng:8.68,accuracy:8,timestamp:Date.now()},sessionId:null,error:'',foreground:true,restart:async()=>{},sync:async()=>({active:false})}}`;
    if (specifier === './location-service')
      source = `export const resumeLocation=async()=>({active:false}),stopLocation=async()=>{},foregroundPermission=async()=>{},startLocation=async()=>({active:true});`;
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: OperationsScreen } =
  await import('../mobile/src/OperationsScreen.tsx');
const { default: SwipeAction } = await import('../mobile/src/SwipeAction.tsx');

const fleets = [
  { id: 'f1', name: 'Testflotte A', owner_id: 'd1', deputy_id: null },
  { id: 'f2', name: 'Testflotte B', owner_id: 'd2', deputy_id: null },
];
const drivers = [
  {
    id: 'd1',
    name: 'Fahrer Alpha',
    fleet_id: 'f1',
    approved: 0,
    online: 0,
    session_id: null,
    vehicle: 'Audi A6',
    plate: 'TEST A',
    phone: '000',
  },
  {
    id: 'd2',
    name: 'Fahrer Beta',
    fleet_id: 'f2',
    approved: 1,
    online: 0,
    session_id: null,
    vehicle: 'Van',
    plate: 'TEST B',
    phone: '000',
  },
];
const revenue = [
  {
    fleet_id: 'f1',
    gross: 10000,
    outstanding: 1000,
    collected: 9000,
    trips: 3,
  },
  { fleet_id: 'f2', gross: 2500, outstanding: 0, collected: 2500, trips: 1 },
];
async function settle() {
  for (let i = 0; i < 7; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
const allText = (renderer) =>
  renderer.root
    .findAllByType('Text')
    .map((n) => n.children.filter((c) => typeof c === 'string').join(''))
    .join(' ');
test('native dispatch isolates fleet cards and uses only complete swipe for driver approval', async () => {
  const old = globalThis.fetch;
  let renderer,
    writes = 0,
    carOpens = 0;
  globalThis.fetch = async (url, options) => {
    assert.match(url, /^https:\/\/luxoreride.de\/api\/mobility\//);
    if (url.endsWith('/operations')) {
      if (options.method === 'POST') {
        writes++;
        assert.deepEqual(JSON.parse(options.body), {
          driverId: 'd1',
          approved: true,
        });
        drivers[0].approved = 1;
        return Response.json({ ok: true });
      }
      return Response.json({ drivers: structuredClone(drivers), bookings: [] });
    }
    assert.ok(url.includes('/fleets?period=today'));
    return Response.json({ fleets, revenue });
  };
  try {
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(OperationsScreen, {
          token: 'a'.repeat(64),
          active: true,
          onFleet: () => carOpens++,
        }),
      );
    });
    await settle();
    assert.match(allText(renderer), /Fahrer Alpha/);
    assert.doesNotMatch(allText(renderer), /Fahrer Beta/);
    assert.match(allText(renderer), /100,00/);
    const choose = (name) =>
      renderer.root
        .findAllByType('Pressable')
        .find((n) =>
          n.findAllByType('Text').some((t) => t.children.includes(name)),
        );
    await act(async () => choose('Testflotte B').props.onPress());
    assert.match(allText(renderer), /Fahrer Beta/);
    assert.doesNotMatch(allText(renderer), /Fahrer Alpha/);
    assert.match(allText(renderer), /25,00/);
    await act(async () => choose('Testflotte A').props.onPress());
    await act(async () =>
      renderer.root
        .findByProps({ accessibilityLabel: 'Fahrer Fahrer Alpha öffnen' })
        .props.onPress(),
    );
    assert.equal(
      renderer.root.findByType('Modal').props.presentationStyle,
      'fullScreen',
    );
    const swipe = renderer.root.findByType(SwipeAction);
    assert.equal(swipe.props.label, 'Fahrer freigeben');
    assert.equal(swipe.props.disabled, false);
    await act(async () =>
      renderer.root
        .findAllByType('View')
        .find((n) => n.props.onLayout)
        .props.onLayout({ nativeEvent: { layout: { width: 330 } } }),
    );
    const thumb = renderer.root.findByType('AnimatedView');
    assert.equal(thumb.props.onPress, undefined);
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 0 }));
    assert.equal(writes, 0);
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 260 }));
    await settle();
    assert.equal(writes, 1);
    assert.match(allText(renderer), /Fahrer freigegeben/);
    await act(async () =>
      renderer.root
        .findByProps({ accessibilityLabel: 'Fahrerprofil schließen' })
        .props.onPress(),
    );
    await act(async () => choose('Fahrzeuge & Flotte').props.onPress());
    assert.equal(carOpens, 1);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});
test('native dispatch hides revoked fleet data and aborts background reads on its actual API path', async () => {
  const old = globalThis.fetch;
  let renderer,
    denied = false,
    aborted = 0;
  globalThis.fetch = async (url, options) => {
    options.signal.addEventListener('abort', () => aborted++);
    if (denied)
      return Response.json({ error: 'Nur Disposition' }, { status: 403 });
    return url.endsWith('/operations')
      ? Response.json({ drivers, bookings: [] })
      : Response.json({ fleets, revenue });
  };
  try {
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(OperationsScreen, {
          token: 'a'.repeat(64),
          active: true,
          onFleet: () => {},
        }),
      );
    });
    await settle();
    assert.match(allText(renderer), /Fahrer Alpha/);
    denied = true;
    await act(async () =>
      renderer.root
        .findByProps({ accessibilityLabel: 'Disposition aktualisieren' })
        .props.onPress(),
    );
    await settle();
    assert.doesNotMatch(allText(renderer), /Fahrer Alpha/);
    assert.match(allText(renderer), /Nur Disposition/);
    aborted = 0;
    // Start real unresolved transports, then background them; no POST is sent.
    globalThis.fetch = async (url, options) =>
      new Promise((resolve, reject) => {
        options.signal.addEventListener('abort', () => {
          aborted++;
          reject(new Error('aborted'));
        });
      });
    await act(async () =>
      renderer.root
        .findByProps({ accessibilityLabel: 'Disposition aktualisieren' })
        .props.onPress(),
    );
    await act(async () => {
      for (const listener of globalThis.customerAppListeners)
        listener('background');
    });
    await settle();
    assert.equal(aborted, 2);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});

void test('driver app menu opens native dispatch and keeps the separate vehicle workspace', async () => {
  const old = globalThis.fetch;
  let renderer;
  globalThis.fetch = async (url) => {
    if (url.endsWith('/account'))
      return Response.json({
        account: {
          id: 'd1',
          name: 'Test',
          email: 'test@example.test',
          phone: '000',
          kind: 'driver',
        },
        registrationReady: true,
        isAdmin: false,
      });
    if (url.endsWith('/driver'))
      return Response.json({
        driver: { ...drivers[0], vehicle_id: null, approved: 1 },
        offers: [],
        bookings: [],
        payments: [],
        vehicles: [],
        fleet: fleets[0],
      });
    if (url.endsWith('/operations'))
      return Response.json({ drivers, bookings: [] });
    if (url.includes('/fleets'))
      return Response.json({ fleets, revenue, employees: [] });
    if (url.endsWith('/vehicles')) return Response.json({ vehicles: [] });
    throw new Error('Unexpected API request');
  };
  try {
    const { default: App } = await import('../mobile/src/App.tsx');
    await act(async () => {
      renderer = Renderer.create(React.createElement(App));
    });
    await settle();
    await act(async () =>
      renderer.root
        .findByProps({ accessibilityLabel: 'App-Menü öffnen' })
        .props.onPress(),
    );
    const card = renderer.root
      .findAllByType('Pressable')
      .find((n) =>
        n
          .findAllByType('Text')
          .some((t) => t.children.includes('Flotte & Disposition')),
      );
    await act(async () => card.props.onPress());
    await settle();
    assert.match(allText(renderer), /Disposition\./);
    assert.match(allText(renderer), /Fahrer Alpha/);
    const cars = renderer.root
      .findAllByType('Pressable')
      .find((n) =>
        n
          .findAllByType('Text')
          .some((t) => t.children.includes('Fahrzeuge & Flotte')),
      );
    await act(async () => cars.props.onPress());
    await settle();
    assert.match(allText(renderer), /Alles an einem Ort/);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});
