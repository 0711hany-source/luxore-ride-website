import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
const virtual = (s) => ({
  url: 'data:text/javascript,' + encodeURIComponent(s),
  shortCircuit: true,
});
registerHooks({
  resolve(s, c, next) {
    if (s === 'expo-notifications')
      return virtual(
        `export const AndroidNotificationPriority={HIGH:2},AndroidImportance={HIGH:4,DEFAULT:3,NONE:0},AndroidNotificationVisibility={PRIVATE:0};export const setNotificationHandler=()=>{},setNotificationChannelAsync=async()=>{},getPermissionsAsync=async()=>globalThis.alertDeadline.permission?globalThis.alertDeadline.permission():({granted:true}),getNotificationChannelAsync=async()=>({importance:4,sound:'default'}),requestPermissionsAsync=async()=>({granted:true}),dismissNotificationAsync=()=>globalThis.alertDeadline.dismiss(),scheduleNotificationAsync=async n=>{globalThis.alertDeadline.shown.push(n);};`,
      );
    if (s === 'expo-secure-store')
      return virtual(
        `export const getItemAsync=async k=>globalThis.alertDeadline.store.get(k)||null,setItemAsync=async(k,v)=>{globalThis.alertDeadline.store.set(k,v)};`,
      );
    return next(s, c);
  },
  load(url, c, next) {
    let path;
    if (url.endsWith('/mobile/src/offer-alerts.ts'))
      path = process.env.TEST_ORIGINAL_OFFER_ALERTS;
    if (url.endsWith('/mobile/src/offer-alert-policy.ts'))
      path = process.env.TEST_ORIGINAL_OFFER_POLICY;
    if (path)
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(readFileSync(path, 'utf8'), {
          compilerOptions: {
            module: ts.ModuleKind.ESNext,
            target: ts.ScriptTarget.ES2022,
          },
        }).outputText,
      };
    return next(url, c);
  },
});
const { createAlertController } =
  await import('../mobile/src/offer-alert-policy.ts');
const { offerAlerts } = await import('../mobile/src/offer-alerts.ts');
const reply = (time = 1000, id = 'offer', end = 11000) => ({
  serverTime: time,
  offer: { id, expiresAt: end },
});
const defer = () => {
  let resolve;
  const promise = new Promise((r) => {
    resolve = r;
  });
  return { promise, resolve };
};
const flush = async () => {
  for (let i = 0; i < 8; i++) await new Promise((r) => setImmediate(r));
};
void test('credential lookup delay cannot revive an expired offer before presentation', async (t) => {
  let now = 1000,
    checks = 0,
    saved = null,
    shown = 0;
  t.mock.method(Date, 'now', () => now);
  const c = createAlertController({
    load: async () => saved,
    save: async (s) => {
      saved = s;
    },
    present: async () => {
      shown++;
      return true;
    },
    dismiss: async () => {},
  });
  await c.sync('shift', reply(), 0, async () => {
    if (++checks === 2) now = 12000;
    return true;
  });
  assert.equal(shown, 0);
  assert.equal(saved.seenId, null);
  assert.equal(saved.checkedAt, 1000);
});
void test('time spent awaiting current credential is subtracted from a still-valid lifetime', async (t) => {
  let now = 1000,
    checks = 0,
    lifetime;
  t.mock.method(Date, 'now', () => now);
  const c = createAlertController({
    load: async () => null,
    save: async () => {},
    present: async (_o, ms) => {
      lifetime = ms;
      return true;
    },
    dismiss: async () => {},
  });
  await c.sync('shift', reply(), 0, async () => {
    if (++checks === 2) now = 4000;
    return true;
  });
  assert.equal(lifetime, 7000);
});
async function nativeFixture(t) {
  const f = { now: 1000, store: new Map(), shown: [], dismiss: async () => {} };
  globalThis.alertDeadline = f;
  t.mock.method(Date, 'now', () => f.now);
  await offerAlerts.clear();
  return f;
}
void test('actual native alert cannot be scheduled after it expires while dismissing previous notification', async (t) => {
  const f = await nativeFixture(t),
    pending = defer();
  let calls = 0;
  f.dismiss = () => (++calls === 1 ? pending.promise : Promise.resolve());
  const task = offerAlerts.sync('shift', reply(), 0, async () => true);
  try {
    await flush();
    assert.equal(calls, 1);
    f.now = 12000;
    pending.resolve();
    await task;
    assert.equal(f.shown.length, 0);
    const s = JSON.parse([...f.store.values()][0]);
    assert.equal(s.seenId, null);
  } finally {
    pending.resolve();
    await task;
    f.dismiss = async () => {};
    await offerAlerts.clear();
  }
});
void test('actual native alert needs more than two seconds remaining after dismiss completes', async (t) => {
  const f = await nativeFixture(t),
    pending = defer();
  let calls = 0;
  f.dismiss = () => (++calls === 1 ? pending.promise : Promise.resolve());
  const task = offerAlerts.sync('shift', reply(), 0, async () => true);
  try {
    await flush();
    f.now = 9000;
    pending.resolve();
    await task;
    assert.equal(f.shown.length, 0);
  } finally {
    pending.resolve();
    await task;
    f.dismiss = async () => {};
    await offerAlerts.clear();
  }
});
void test('valid current offer still produces only one actual native alarm for concurrent replies', async (t) => {
  const f = await nativeFixture(t);
  try {
    await Promise.all([
      offerAlerts.sync('shift', reply(), 0, async () => true),
      offerAlerts.sync('shift', reply(1001), 0, async () => true),
    ]);
    assert.equal(f.shown.length, 1);
    assert.equal(f.shown[0].content.data.offerId, 'offer');
    assert.equal(f.shown[0].trigger.channelId, 'luxore-ride-offers-v1');
  } finally {
    await offerAlerts.clear();
  }
});
void test('newer withdrawn-offer reply prevents a delayed older actual native alarm', async (t) => {
  const f = await nativeFixture(t);
  try {
    await offerAlerts.sync(
      'shift',
      { serverTime: 3000, offer: null },
      0,
      async () => true,
    );
    await offerAlerts.sync('shift', reply(2000), 0, async () => true);
    assert.equal(f.shown.length, 0);
  } finally {
    await offerAlerts.clear();
  }
});
void test('pause during native permission lookup prevents old offer scheduling', async (t) => {
  const f = await nativeFixture(t),
    gate = defer();
  let current = true;
  f.permission = () => gate.promise;
  const task = offerAlerts.sync('shift', reply(), 0, async () => current);
  try {
    await flush();
    current = false;
    gate.resolve({ granted: true });
    await task;
    assert.equal(f.shown.length, 0);
    assert.equal(f.store.size, 0);
  } finally {
    gate.resolve({ granted: true });
    await task;
    f.permission = undefined;
    await offerAlerts.clear();
  }
});
void test('shift change during native dismissal prevents old offer scheduling', async (t) => {
  const f = await nativeFixture(t),
    gate = defer();
  let current = true,
    calls = 0;
  f.dismiss = () => (++calls === 1 ? gate.promise : Promise.resolve());
  const task = offerAlerts.sync('old', reply(), 0, async () => current);
  try {
    await flush();
    current = false;
    gate.resolve();
    await task;
    assert.equal(f.shown.length, 0);
    assert.equal(f.store.size, 0);
  } finally {
    gate.resolve();
    await task;
    f.dismiss = async () => {};
    await offerAlerts.clear();
  }
});
void test('fresh new shift can notify after old native work is invalidated', async (t) => {
  const f = await nativeFixture(t),
    gate = defer();
  let current = true,
    calls = 0;
  f.dismiss = () => (++calls === 1 ? gate.promise : Promise.resolve());
  const old = offerAlerts.sync('old', reply(), 0, async () => current);
  try {
    await flush();
    current = false;
    const next = offerAlerts.sync(
      'new',
      reply(1001, 'new-offer'),
      0,
      async () => true,
    );
    gate.resolve();
    await Promise.all([old, next]);
    assert.deepEqual(
      f.shown.map((n) => n.content.data.offerId),
      ['new-offer'],
    );
    assert.equal(JSON.parse([...f.store.values()][0]).sessionId, 'new');
  } finally {
    gate.resolve();
    await old;
    f.dismiss = async () => {};
    await offerAlerts.clear();
  }
});
void test('native scheduling already started is dismissed after a pause without marking offer seen', async (t) => {
  const f = await nativeFixture(t);
  let current = true,
    dismissed = 0;
  f.dismiss = async () => {
    dismissed++;
  };
  const status = async () => {
    if (f.shown.length) current = false;
    return current;
  };
  try {
    await offerAlerts.sync('shift', reply(), 0, status);
    assert.equal(f.shown.length, 1);
    assert.equal(f.store.size, 0);
    assert.equal(dismissed, 2);
  } finally {
    await offerAlerts.clear();
  }
});
