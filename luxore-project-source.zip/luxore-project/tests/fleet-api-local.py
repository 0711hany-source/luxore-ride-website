"""Real HTTP tests, isolated device cookie jars and local SQL route fixtures only."""
import os, concurrent.futures, json, urllib.request, urllib.error, http.cookiejar, uuid, sqlite3, pathlib, time
base=os.environ.get('TEST_BASE_URL','http://localhost:3000')
def client(): return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def call(c,path,b=None,origin=base):
 req=urllib.request.Request(base+'/api/mobility/'+path,data=json.dumps(b).encode() if b is not None else None,headers={'Content-Type':'application/json','Origin':origin})
 try:
  with c.open(req) as r:return r.status,json.loads(r.read()),r.headers
 except urllib.error.HTTPError as e:
  raw=e.read()
  try: value=json.loads(raw)
  except ValueError: value=raw.decode()[:200]
  return e.code,value,e.headers
clients=[client() for _ in range(6)]
owner,otherowner,deputy,driver,rider,stranger=clients
admin=client();admin.open(base+'/signin-with-chatgpt?return_to=%2F').close()
users=[]
for c in clients:
 issued=call(c,'session',{})
 if issued[0]==429:
  time.sleep(60-time.time()%60+0.1)
  issued=call(c,'session',{})
 assert issued[0]==201,(issued[0],issued[1])
 users.append(call(c,'config')[1]['userId'])
connection=None
for file in pathlib.Path('.wrangler/state/v3/d1').rglob('*.sqlite'):
 c=sqlite3.connect(file)
 if c.execute("SELECT name FROM sqlite_master WHERE name='mobility_quotes'").fetchone():connection=c;break
 c.close()
assert connection
now=int(time.time()*1000);prefix='fleet-test-'+str(uuid.uuid4())
def quote(who):
 q={'id':prefix+str(uuid.uuid4()),'pickup':{'id':'p','label':'TEST Opernplatz','lat':50.115,'lng':8.67},'destination':{'id':'d','label':'TEST Hbf','lat':50.107,'lng':8.663},'distanceMeters':10000,'durationSeconds':1200,'geometry':{'type':'LineString','coordinates':[[8.67,50.115],[8.663,50.107]]},'calculatedAt':now,'expiresAt':now+300000,'prices':{'premium':2500,'first':3500,'van':3000},'mode':'now','scheduledAt':None}
 connection.execute('INSERT INTO mobility_quotes VALUES(?,?,?,?)',(q['id'],who,json.dumps(q),q['expiresAt']));connection.commit();return q
fleetids=[]
def ok(c,path,data=None,status=200):
 code,b,_=call(c,path,data);assert code==status,(path,code,b);return b
def snapshot(c,vehicle_id):
 v=next(v for v in ok(c,'vehicles')['vehicles'] if v['id']==vehicle_id)
 return {key:v[key] for key in ('model','plate','services')}
try:
 for i,c in enumerate((owner,otherowner,deputy)):
  ok(c,'team',{'name':prefix+str(i),'phone':'+490000000','role':'admin'})
  assert ok(c,'team')['employee']['role']=='staff'
  assert call(c,'fleets')[0]==403
 for i in range(2):
  f=ok(admin,'fleets',{'action':'create','name':prefix+str(i),'ownerId':users[i]},201);fleetids.append(f['id'])
 assert ok(owner,'config')['canDispatch']
 ok(owner,'fleets',{'action':'rename','fleetId':fleetids[0],'name':'Test renamed fleet'})
 assert ok(owner,'fleets')['fleets'][0]['name']=='Test renamed fleet'
 assert call(otherowner,'fleets',{'action':'rename','fleetId':fleetids[0],'name':'Forbidden'})[0]==403
 ok(driver,'driver',{'action':'register','name':prefix+'Driver','phone':'+490000000','vehicle':'Test S','plate':'TEST 42','services':['premium','first']})
 for i,role in [(2,'staff'),(3,'driver')]:ok(admin,'fleets',{'action':'assign','userId':users[i],'fleetId':fleetids[0],'role':role})
 assert len(ok(owner,'fleets')['fleets'])==1
 assert ok(owner,'fleets')['fleets'][0]['owner_id']==users[0]
 assert users[3] in [d['id'] for d in ok(owner,'operations')['drivers']]
 assert users[3] not in [d['id'] for d in ok(otherowner,'operations')['drivers']]
 assert call(otherowner,'operations',{'driverId':users[3],'approved':True})[0]==403
 assert call(owner,'fleets',{'action':'deputy','fleetId':fleetids[1],'deputyId':users[2]})[0]==403
 ok(owner,'fleets',{'action':'deputy','fleetId':fleetids[0],'deputyId':users[2]})
 assert ok(deputy,'config')['canDispatch']
 assert call(deputy,'fleets',{'action':'rename','fleetId':fleetids[0],'name':'Forbidden'})[0]==403
 for protected in (users[0],users[2]):
  assert call(owner,'fleets',{'action':'remove_member','fleetId':fleetids[0],'userId':protected})[0]==409
 assert call(deputy,'fleets',{'action':'deputy','fleetId':fleetids[0],'deputyId':None})[0]==403
 assert call(deputy,'fleets',{'action':'create','name':'Forbidden'})[0]==403
 assert call(admin,'fleets',{'action':'assign','userId':users[2],'fleetId':fleetids[1],'role':'staff'})[0]==409
 ok(deputy,'operations',{'driverId':users[3],'approved':True})
 cars=[]
 for i,services in [(0,['premium','first']),(1,['premium'])]:
  cars.append(ok(owner,'vehicles',{'action':'create','fleetId':fleetids[0],'model':'Test Car '+str(i),'plate':prefix[-8:]+' '+str(i),'services':services},201)['id'])
 assert call(otherowner,'vehicles',{'action':'create','fleetId':fleetids[0],'model':'X','plate':'INVALID','services':['premium']})[0]==403
 # Repeating a create after a lost response must return the same vehicle.
 requestId=str(uuid.uuid4())
 payload={'action':'create','fleetId':fleetids[0],'model':' Retry Car ', 'plate':prefix[-8:]+' R', 'services':['premium','premium'], 'requestId':requestId}
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  saves=list(pool.map(lambda c:call(c,'vehicles',payload),[deputy,owner]))
 assert sorted(r[0] for r in saves)==[200,201],saves
 assert saves[0][1]['id']==saves[1][1]['id']
 replay=saves[0][1]['id']
 assert ok(deputy,'vehicles',payload)['id']==replay
 assert len([v for v in ok(owner,'vehicles')['vehicles'] if v['id']==replay])==1
 assert call(deputy,'vehicles',{**payload,'model':'Changed'})[0]==409
 ok(deputy,'vehicles',{'action':'archive','id':replay,'reason':'Temporary test'})
 for invalid in ({'model':'   '},{'plate':'   '},{'services':[]},{'services':['invalid']},{'services':[['premium']]}):
  status,problem,_=call(deputy,'vehicles',{**payload, 'requestId':str(uuid.uuid4()), **invalid})
  assert status==400 and problem.get('error'),problem
 assert call(driver,'driver',{'action':'online'})[0]==409
 foreign=ok(otherowner,'vehicles',{'action':'create','fleetId':fleetids[1],'model':'Foreign Car','plate':prefix[-8:]+' B','services':['premium']},201)['id']
 assert {v['id'] for v in ok(driver,'driver')['vehicles']}==set(cars)
 assert {v['id'] for v in ok(owner,'vehicles')['vehicles']}==set(cars+[replay])
 assert call(owner,'vehicles?fleetId='+fleetids[1])[0]==403
 assert call(driver,'vehicles',{'action':'select','vehicleId':foreign})[0]==409
 assert call(otherowner,'vehicles',{'action':'create','fleetId':fleetids[1],'model':'Duplicate','plate':(prefix[-8:]+'-0').lower(),'services':['premium']})[0]==409
 ok(driver,'vehicles',{'action':'select','vehicleId':cars[0]})
 assert ok(driver,'driver')['driver']['vehicle_id']==cars[0]
 assert call(otherowner,'vehicles',{'action':'update','id':cars[0],'expected':snapshot(owner,cars[0]),'model':'X','plate':'X','services':['premium']})[0]==404
 # Two editors start from the same original data; only one distinct change may win.
 original=snapshot(owner,cars[0])
 changes=[{'action':'update','id':cars[0],'expected':original,'model':'Concurrent '+str(i),'plate':original['plate'],'services':services} for i,services in enumerate((['first'],['van']))]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  edits=list(pool.map(lambda args:call(args[0],'vehicles',args[1]),zip((owner,deputy),changes)))
 assert sorted(r[0] for r in edits)==[200,409],edits
 winner=next(i for i,r in enumerate(edits) if r[0]==200)
 loser=1-winner
 assert 'zwischenzeitlich' in edits[loser][1]['error'],edits
 current=snapshot(owner,cars[0])
 assert current['model']==changes[winner]['model'] and json.loads(current['services'])==changes[winner]['services']
 selected=ok(driver,'driver')['driver']
 assert selected['vehicle']==current['model'] and selected['services']==current['services']
 # Retrying the winning payload after a lost response does not change anything.
 assert ok(deputy,'vehicles',changes[winner])['replayed'] is True
 assert call(owner,'vehicles',changes[loser])[0]==409
 assert snapshot(owner,cars[0])==current
 missing={key:value for key,value in changes[loser].items() if key!='expected'}
 assert call(owner,'vehicles',missing)[0]==409
 assert snapshot(owner,cars[0])==current
 # Reloading the latest snapshot allows the next intentional edit.
 ok(deputy,'vehicles',{'action':'update','id':cars[0],'expected':snapshot(owner,cars[0]),'model':'Test Car 0 Updated','plate':prefix[-8:]+' 0','services':['premium','first','van']})
 assert ok(driver,'driver')['driver']['vehicle']=='Test Car 0 Updated'
 assert json.loads(ok(driver,'driver')['driver']['services'])==['premium','first','van']
 assert call(owner,'vehicles',{'action':'update','id':cars[0],'expected':snapshot(owner,cars[0]),'model':'X','plate':prefix[-8:]+' 1','services':['van']})[0]==409
 assert ok(driver,'driver')['driver']['vehicle']=='Test Car 0 Updated'
 ok(deputy,'driver',{'action':'register','name':'Second Test Driver','phone':'+490000000','vehicle':'Old','plate':'OLD','services':['premium']})
 ok(owner,'operations',{'driverId':users[2],'approved':True})
 assert call(deputy,'vehicles',{'action':'select','vehicleId':cars[0]})[0]==409
 assert call(stranger,'vehicles',{'action':'select','vehicleId':cars[1]})[0]==409
 ok(stranger,'driver',{'action':'register','name':'TEST invited driver','phone':'+490000000'})
 connection.execute('UPDATE mobility_drivers SET approved=1 WHERE id=?',(users[5],));connection.commit()
 assert call(stranger,'driver',{'action':'online'})[0]==409
 invite=ok(owner,'fleets',{'action':'invite_driver','fleetId':fleetids[0]})
 ok(stranger,'fleets',{'action':'join','code':invite['code']})
 assert ok(stranger,'driver')['fleet']['id']==fleetids[0]
 assert ok(stranger,'driver')['driver']['approved']==0
 ok(owner,'operations',{'driverId':users[5],'approved':True})
 assert call(stranger,'fleets',{'action':'join','code':invite['code']})[0]==409
 assert ok(stranger,'driver')['driver']['approved']==1
 otherinvite=ok(otherowner,'fleets',{'action':'invite_driver','fleetId':fleetids[1]})
 assert call(stranger,'fleets',{'action':'join','code':otherinvite['code']})[0]==409
 assert ok(stranger,'driver')['fleet']['id']==fleetids[0]

 assert call(otherowner,'fleets',{'action':'remove_member','fleetId':fleetids[0],'userId':users[5]})[0]==403
 ok(deputy,'fleets',{'action':'remove_member','fleetId':fleetids[0],'userId':users[5]})
 assert ok(stranger,'driver')['fleet'] is None
 assert ok(stranger,'driver')['driver']['approved']==0
 ok(stranger,'fleets',{'action':'join','code':invite['code']})
 assert ok(stranger,'driver')['fleet']['id']==fleetids[0]
 assert ok(stranger,'driver')['driver']['approved']==0

 sid=ok(driver,'driver',{'action':'online'})['sessionId']
 ok(driver,'driver',{'action':'heartbeat','sessionId':sid,'lat':50.115,'lng':8.67,'accuracy':10})
 ok(owner,'operations',{'driverId':users[3],'approved':True})
 assert ok(driver,'driver')['driver']['session_id']==sid and ok(driver,'driver')['driver']['online']==1
 assert call(owner,'operations',{'driverId':users[3],'approved':False})[0]==409
 assert call(owner,'fleets',{'action':'remove_member','fleetId':fleetids[0],'userId':users[3]})[0]==409
 assert call(deputy,'vehicles',{'action':'update','id':cars[0],'expected':snapshot(owner,cars[0]),'model':'Forbidden change','plate':prefix[-8:]+' 0','services':['van']})[0]==409
 assert next(v for v in ok(owner,'vehicles')['vehicles'] if v['id']==cars[0])['blocking_reason']
 assert call(owner,'vehicles',{'action':'release','id':cars[0],'expectedDriverId':users[3]})[0]==409
 assert call(driver,'vehicles',{'action':'select','vehicleId':cars[1]})[0]==409
 assert call(owner,'vehicles',{'action':'archive','id':cars[0],'reason':'Sold'})[0]==409
 q=quote(users[4]);b=ok(rider,'bookings',{'quoteId':q['id'],'service':'first','riderName':'Test','riderPhone':'+490000001'},201)
 offer=ok(driver,'driver')['offers'][0]
 ok(driver,'driver',{'action':'accept','offerId':offer['id']})
 assert ok(rider,'bookings')['bookings'][0]['fleet_id']==fleetids[0]
 assert ok(rider,'bookings')['bookings'][0]['vehicle_id']==cars[0]
 assert call(driver,'payments',{'id':b['id'],'method':'cash'})[0]==409
 assert call(admin,'fleets',{'action':'assign','userId':users[3],'fleetId':fleetids[1],'role':'driver'})[0]==409
 for old,new in [('accepted','arrived'),('arrived','riding'),('riding','completed')]:ok(driver,'driver',{'action':'status','id':b['id'],'from':old,'status':new})
 assert call(admin,'fleets',{'action':'assign','userId':users[3],'fleetId':fleetids[1],'role':'driver'})[0]==409
 assert call(driver,'vehicles',{'action':'select','vehicleId':cars[1]})[0]==409
 assert call(owner,'vehicles',{'action':'release','id':cars[0],'expectedDriverId':users[3]})[0]==409
 assert call(deputy,'fleets',{'action':'remove_member','fleetId':fleetids[0],'userId':users[3]})[0]==409
 assert next(v for v in ok(owner,'vehicles')['vehicles'] if v['id']==cars[0])['blocking_reason']=='Zahlung noch offen'
 state=ok(driver,'driver');assert state['payments'][0]['price']==3500
 assert state['revenue']['outstanding']==3500
 assert state['today']['gross']==3500 and state['today']['trips']==1
 assert ok(owner,'fleets?period=today')['revenue'][0]['gross']==3500
 assert call(stranger,'payments',{'id':b['id'],'method':'cash'})[0]==409
 rev=ok(owner,'fleets')['revenue'][0];assert rev['gross']==3500 and rev['outstanding']==3500 and rev['collected']==0
 assert ok(otherowner,'fleets')['revenue']==[]
 for _ in range(2):ok(driver,'payments',{'id':b['id'],'method':'terminal','amount':1})
 assert call(driver,'payments',{'id':b['id'],'method':'cash'})[0]==409
 assert ok(driver,'driver')['payments']==[]
 paid=ok(rider,'bookings')['bookings'][0];assert paid['payment_status']=='paid' and paid['price']==3500
 rev=ok(owner,'fleets')['revenue'][0];assert rev['collected']==3500 and rev['outstanding']==0
 ok(driver,'driver',{'action':'offline','sessionId':sid})
 assert call(otherowner,'vehicles',{'action':'release','id':cars[0],'expectedDriverId':users[3]})[0]==409
 ok(owner,'vehicles',{'action':'release','id':cars[0],'expectedDriverId':users[3]})
 assert ok(driver,'driver')['driver']['vehicle_id'] is None
 assert ok(driver,'driver')['driver']['plate']==''
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  claims=list(pool.map(lambda c:call(c,'vehicles',{'action':'select','vehicleId':cars[1]})[0], [driver,deputy]))
 assert sorted(claims)==[200,409],claims
 old_index=claims.index(200)
 old_driver=(driver,deputy)[old_index]
 new_driver=(driver,deputy)[1-old_index]
 old_id=(users[3],users[2])[old_index]
 new_id=(users[3],users[2])[1-old_index]
 stale_release={'action':'release','id':cars[1],'expectedDriverId':old_id}
 ok(old_driver,'vehicles',{'action':'select','vehicleId':None})
 ok(new_driver,'vehicles',{'action':'select','vehicleId':cars[1]})
 stale_result=call(owner,'vehicles',stale_release)
 assert stale_result[0]==409,('stale release removed the next driver',stale_result)
 assert ok(new_driver,'driver')['driver']['vehicle_id']==cars[1]
 assert call(owner,'vehicles',{'action':'release','id':cars[1]})[0]==409
 assert ok(new_driver,'driver')['driver']['vehicle_id']==cars[1]
 current_release={'action':'release','id':cars[1],'expectedDriverId':new_id}
 ok(owner,'vehicles',current_release)
 assert ok(owner,'vehicles',current_release)['replayed'] is True
 # A delayed retry must not release a driver who has since taken the vehicle.
 ok(old_driver,'vehicles',{'action':'select','vehicleId':cars[1]})
 assert call(owner,'vehicles',current_release)[0]==409
 assert ok(old_driver,'driver')['driver']['vehicle_id']==cars[1]
 ok(owner,'vehicles',stale_release)
 ok(driver,'vehicles',{'action':'select','vehicleId':cars[1]})
 assert ok(driver,'driver')['driver']['services']=='["premium"]'
 ok(owner,'vehicles',{'action':'archive','id':cars[0],'reason':'Verkauft'})
 assert call(driver,'vehicles',{'action':'select','vehicleId':cars[0]})[0]==409
 history=ok(rider,'bookings')['bookings'][0];assert history['driver']['vehicle']=='Test Car 0 Updated' and history['vehicle_id']==cars[0]
 assert call(otherowner,'vehicles',{'action':'archive','id':cars[1],'reason':'Forbidden'})[0]==409
 assert call(otherowner,'vehicles',{'action':'restore','id':cars[0]})[0]==404
 # Archival and restoration preserve identity; an active replacement plate blocks restoration.
 replacement=ok(deputy,'vehicles',{'action':'create','fleetId':fleetids[0],'model':'Replacement','plate':prefix[-8:]+' 0','services':['premium']},201)['id']
 assert call(deputy,'vehicles',{'action':'restore','id':cars[0]})[0]==409
 ok(deputy,'vehicles',{'action':'archive','id':replacement,'reason':'Replacement retired'})
 ok(deputy,'vehicles',{'action':'restore','id':cars[0]})
 assert cars[0] in [v['id'] for v in ok(driver,'driver')['vehicles']]
 ok(deputy,'vehicles',{'action':'update','id':cars[0],'expected':snapshot(owner,cars[0]),'model':'Changed after ride','plate':prefix[-8:]+' 0','services':['van']})
 assert ok(rider,'bookings')['bookings'][0]['driver']['vehicle']=='Test Car 0 Updated'
 ok(deputy,'vehicles',{'action':'archive','id':cars[0],'reason':'Test finished'})
 ok(admin,'fleets',{'action':'assign','userId':users[3],'fleetId':fleetids[1],'role':'driver'})
 assert ok(driver,'driver')['driver']['vehicle_id'] is None
 assert ok(driver,'driver')['driver']['approved']==0
 assert {v['id'] for v in ok(driver,'driver')['vehicles']}=={foreign}
 assert call(driver,'vehicles',{'action':'select','vehicleId':cars[1]})[0]==409
 ok(otherowner,'operations',{'driverId':users[3],'approved':True})
 ok(driver,'vehicles',{'action':'select','vehicleId':foreign})
 assert ok(owner,'fleets')['revenue'][0]['gross']==3500
 assert ok(otherowner,'fleets')['revenue']==[]
 ok(owner,'fleets',{'action':'deputy','fleetId':fleetids[0],'deputyId':None})
 assert not ok(deputy,'config')['canDispatch']
 ok(owner,'fleets',{'action':'remove_member','fleetId':fleetids[0],'userId':users[2]})
 assert ok(deputy,'driver')['fleet'] is None
 assert ok(owner,'fleets')['revenue'][0]['gross']==3500
 assert call(deputy,'operations')[0]==403 and call(deputy,'fleets')[0]==403
 print('PASS: vehicle input errors; idempotent creation; simultaneous edit conflict, retained driver data, safe retry and fresh-snapshot edit; scoped edit, driver class sync, safe restore, duplicate restore blocked; fleet rename ownership, member departure/rejoin, active and unpaid departure blocked;  foreign-fleet choices blocked; duplicate plate spelling blocked; reapproval preserves live shift; active/unpaid handover blocked; assignment-bound release and concurrent exclusive claims, stale and delayed releases preserve the next driver; transfer resets approval and vehicle;  fleet owner dispatch, deputy assignment/revocation, cross-fleet isolation, role injection blocked, ride snapshot, collection ownership/idempotency, per-driver fleet revenue and preserved historical revenue after transfer; vehicle creation, selection, exclusive occupancy, class changes, archival and historical vehicle snapshots; daily revenue.')
finally:
 for u in users:
  ids=[r[0] for r in connection.execute('SELECT id FROM mobility_bookings WHERE owner_id=?',(u,))]
  for bid in ids:
   connection.execute('DELETE FROM mobility_offers WHERE booking_id=?',(bid,));connection.execute('DELETE FROM mobility_events WHERE booking_id=?',(bid,))
  for table,col in [('mobility_bookings','owner_id'),('mobility_quotes','owner_id'),('mobility_drivers','id'),('mobility_employees','user_id'),('mobility_sessions','user_id')]:connection.execute('DELETE FROM '+table+' WHERE '+col+'=?',(u,))
 for fid in fleetids:
  connection.execute('DELETE FROM mobility_fleet_invites WHERE fleet_id=?',(fid,))
  connection.execute('DELETE FROM mobility_vehicles WHERE fleet_id=?',(fid,))
  connection.execute('DELETE FROM mobility_fleets WHERE id=?',(fid,))
 connection.commit();connection.close()
