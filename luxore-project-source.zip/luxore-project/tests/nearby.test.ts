import {test} from 'node:test';
import assert from 'node:assert/strict';
import {nearestDrivers} from '../lib/mobility/nearby.ts';
import type {Driver} from '../lib/mobility/domain.ts';
test('Nearby drivers are three nearest within range, approximate and anonymous', () => {
  const ds = [8.72,8.682,8.7,8.69,12].map((lng,i) => ({id:String(i),lat:50.11012,lng,name:'private',phone:'secret',plate:'secret'}) as Driver);
  const points=nearestDrivers(ds,{lat:50.11,lng:8.68});
  assert.equal(points.length,3);
  assert.deepEqual(points.map(p=>p.lng),[8.682,8.691,8.700000000000001]);
  assert.deepEqual(Object.keys(points[0]).sort(),['lat','lng']);
  assert.notEqual(points[0].lat,ds[0].lat);
  assert.deepEqual(nearestDrivers([],{lat:50,lng:8}),[]);
});
