import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  navigationUrl,
  navigationTarget,
  parseNavigation,
} from '../app/mobility/navigation-preferences.ts';
const route = {
  pickup: { lat: 50.11, lng: 8.68 },
  destination: { lat: 50.03, lng: 8.57 },
};
test('Unknown or damaged device preferences fall back to the internal map', () => {
  assert.deepEqual(parseNavigation(null), {
    provider: 'standard',
    autoStart: true,
  });
  assert.deepEqual(parseNavigation({ provider: 'evil', autoStart: 0 }), {
    provider: 'standard',
    autoStart: true,
  });
  assert.deepEqual(parseNavigation({ provider: 'waze', autoStart: false }), {
    provider: 'waze',
    autoStart: false,
  });
});
test('Official navigation URLs carry the exact coordinate and driving parameters', () => {
  const g = new URL(navigationUrl('google', route.destination)!);
  assert.equal(g.origin, 'https://www.google.com');
  assert.equal(g.searchParams.get('destination'), '50.03,8.57');
  assert.equal(g.searchParams.get('dir_action'), 'navigate');
  assert.equal(g.searchParams.get('api'), '1');
  const w = new URL(navigationUrl('waze', route.pickup)!);
  assert.equal(w.searchParams.get('ll'), '50.11,8.68');
  assert.equal(w.searchParams.get('navigate'), 'yes');
  const a = new URL(navigationUrl('apple', route.pickup)!);
  assert.equal(a.origin, 'https://maps.apple.com');
  assert.equal(a.searchParams.get('daddr'), '50.11,8.68');
  assert.equal(a.searchParams.get('dirflg'), 'd');
  assert.equal(navigationUrl('standard', route.pickup), null);
  assert.equal(navigationUrl('google', { lat: NaN, lng: 8 }), null);
  assert.equal(navigationUrl('waze', { lat: 91, lng: 8 }), null);
});
test('Only accepting and starting a trip can automatically launch navigation', () => {
  assert.equal(navigationTarget({ action: 'accept' }, route), route.pickup);
  assert.equal(
    navigationTarget({ action: 'status', status: 'riding' }, route),
    route.destination,
  );
  for (const action of [
    { action: 'status', status: 'arrived' },
    { action: 'status', status: 'completed' },
    { action: 'heartbeat' },
    { action: 'reject' },
    { action: 'online' },
  ])
    assert.equal(navigationTarget(action, route), null);
  assert.equal(navigationTarget({ action: 'accept' }), null);
});
