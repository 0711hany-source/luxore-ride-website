import test from 'node:test';
import assert from 'node:assert/strict';
import type { Booking, BookingStatus } from '../lib/mobility/domain.ts';
import {
  CustomerTripsController,
  canCancelTrip,
  tripGroups,
} from '../mobile/src/customer-trips.ts';
function trip(id = 'trip-a', status: BookingStatus = 'requesting') {
  return { id, status, created_at: 10, scheduled_at: null } as Booking;
}
function deferred<T>() {
  let resolve!: (value: T) => void, reject!: (error: Error) => void;
  const promise = new Promise<T>((a, b) => {
    resolve = a;
    reject = b;
  });
  return { promise, resolve, reject };
}
async function settle() {
  for (let i = 0; i < 5; i++) await new Promise((r) => setImmediate(r));
}

void test('foreground immediately starts a fresh read while an abandoned background request is still unresolved', async () => {
  const old = deferred<{ bookings: Booking[] }>();
  let calls = 0;
  const store = new CustomerTripsController(async () => {
    calls++;
    return calls === 1 ? old.promise : { bookings: [trip('fresh')] };
  });
  try {
    store.setActive(true);
    await settle();
    store.setActive(false);
    store.setActive(true);
    await settle();
    assert.equal(calls, 2);
    assert.equal(store.getSnapshot().bookings[0]?.id, 'fresh');
    old.resolve({ bookings: [trip('old')] });
    await settle();
    assert.equal(store.getSnapshot().bookings[0]?.id, 'fresh');
  } finally {
    old.resolve({ bookings: [] });
    store.dispose();
  }
});

void test('an abandoned read cannot free the slot of a newer still-pending read', async () => {
  const old = deferred<{ bookings: Booking[] }>(),
    current = deferred<{ bookings: Booking[] }>();
  let calls = 0;
  const store = new CustomerTripsController(async () => {
    calls++;
    return calls === 1 ? old.promise : current.promise;
  });
  try {
    store.setActive(true);
    await settle();
    store.setActive(false);
    store.setActive(true);
    await settle();
    assert.equal(calls, 2);
    old.resolve({ bookings: [trip('old')] });
    await settle();
    assert.equal(store.getSnapshot().refreshing, true);
    void store.refresh();
    await settle();
    assert.equal(calls, 2);
    current.resolve({ bookings: [trip('new')] });
    await settle();
    assert.equal(store.getSnapshot().bookings[0].id, 'new');
  } finally {
    old.resolve({ bookings: [] });
    current.resolve({ bookings: [] });
    store.dispose();
  }
});

void test('background and disposal abort only reads; a confirmed cancellation survives backgrounding', async () => {
  const pending = deferred<{ bookings: Booking[] }>(),
    change = deferred<{ bookings?: Booking[] }>();
  const signals: AbortSignal[] = [];
  let reads = 0,
    writes = 0;
  const store = new CustomerTripsController(async (body, signal) => {
    if (body) {
      writes++;
      assert.equal(signal, undefined);
      return change.promise;
    }
    assert.ok(signal);
    signals.push(signal);
    reads++;
    return reads === 1 ? { bookings: [trip()] } : pending.promise;
  });
  try {
    store.setActive(true);
    await settle();
    void store.refresh();
    await settle();
    const cancelling = store.cancel('trip-a');
    assert.equal(signals[1].aborted, true);
    store.setActive(false);
    change.resolve({});
    await cancelling;
    assert.equal(writes, 1);
    assert.equal(store.getSnapshot().bookings[0].status, 'cancelled');
    store.setActive(true);
    await settle();
    store.dispose();
    assert.equal(signals[2].aborted, true);
  } finally {
    pending.resolve({ bookings: [] });
    change.resolve({});
    store.dispose();
  }
});
void test('native trip grouping keeps active rides, chronological reservations and history distinct', () => {
  const rows = [
    trip('old', 'completed'),
    { ...trip('later', 'reserved'), scheduled_at: 30 },
    trip('now', 'riding'),
    { ...trip('soon', 'reserved'), scheduled_at: 20 },
    trip('cancelled', 'cancelled'),
  ];
  const groups = tripGroups(rows);
  assert.deepEqual(
    groups.map((g) => g.items.map((b) => b.id)),
    [['now'], ['soon', 'later'], ['old', 'cancelled']],
  );
  assert.equal(canCancelTrip(trip('a', 'arrived')), true);
  assert.equal(canCancelTrip(trip('a', 'riding')), false);
  assert.equal(canCancelTrip(trip('a', 'completed')), false);
});
void test('hidden native trips do not fetch; visible reads are serialized and disposed stores never publish', async () => {
  const read = deferred<{ bookings: Booking[] }>();
  let calls = 0,
    updates = 0;
  const store = new CustomerTripsController(async () => {
    calls++;
    return read.promise;
  });
  store.subscribe(() => updates++);
  await store.refresh();
  assert.equal(calls, 0);
  store.setActive(true);
  await settle();
  assert.equal(calls, 1);
  void store.refresh();
  assert.equal(calls, 1);
  store.dispose();
  const before = updates;
  read.resolve({ bookings: [trip()] });
  await settle();
  assert.equal(updates, before);
  assert.equal(calls, 1);
});
void test('background response is ignored and foreground waits for one fresh read without overlapping requests', async () => {
  const first = deferred<{ bookings: Booking[] }>(),
    second = deferred<{ bookings: Booking[] }>();
  let calls = 0;
  const store = new CustomerTripsController(async () => {
    calls++;
    return calls === 1 ? first.promise : second.promise;
  });
  store.setActive(true);
  await settle();
  store.setActive(false);
  first.resolve({ bookings: [trip('old')] });
  await settle();
  assert.equal(store.getSnapshot().bookings.length, 0);
  assert.equal(calls, 1);
  store.setActive(true);
  await settle();
  assert.equal(calls, 2);
  second.resolve({ bookings: [trip('fresh')] });
  await settle();
  assert.equal(store.getSnapshot().bookings[0].id, 'fresh');
  store.dispose();
});
void test('a foreground return abandons a pending background read and fetches a fresh response', async () => {
  const first = deferred<{ bookings: Booking[] }>();
  let calls = 0;
  const store = new CustomerTripsController(async () => {
    calls++;
    return calls === 1 ? first.promise : { bookings: [trip('new')] };
  });
  store.setActive(true);
  await settle();
  store.setActive(false);
  store.setActive(true);
  await settle();
  assert.equal(calls, 2);
  first.resolve({ bookings: [trip('old')] });
  await settle();
  assert.equal(calls, 2);
  assert.equal(store.getSnapshot().bookings[0].id, 'new');
  store.dispose();
});
void test('cancellation waits for server confirmation, rejects duplicate gestures and ignores older status reads', async () => {
  const read = deferred<{ bookings: Booking[] }>(),
    change = deferred<{ bookings?: Booking[] }>();
  let reads = 0,
    writes = 0;
  const store = new CustomerTripsController(async (body) => {
    if (body) {
      writes++;
      assert.equal(body.id, 'trip-a');
      return change.promise;
    }
    reads++;
    return reads === 2
      ? read.promise
      : { bookings: [trip('trip-a', reads > 2 ? 'cancelled' : 'requesting')] };
  });
  store.setActive(true);
  await settle();
  void store.refresh();
  await settle();
  const cancelling = store.cancel('trip-a');
  void store.cancel('trip-a');
  assert.equal(writes, 1);
  assert.equal(store.getSnapshot().bookings[0].status, 'requesting');
  change.resolve({});
  await settle();
  assert.equal(store.getSnapshot().bookings[0].status, 'cancelled');
  read.resolve({ bookings: [trip()] });
  await cancelling;
  await settle();
  assert.equal(store.getSnapshot().bookings[0].status, 'cancelled');
  assert.equal(writes, 1);
  store.dispose();
});
void test('network loss preserves known trips, disables changes and fresh reconnect clears only the load error', async () => {
  let offline = false,
    writes = 0;
  const store = new CustomerTripsController(async (body) => {
    if (body) {
      writes++;
      return {};
    }
    if (offline) throw new Error('offline');
    return { bookings: [trip()] };
  });
  store.setActive(true);
  await settle();
  offline = true;
  await store.refresh();
  assert.equal(store.getSnapshot().bookings.length, 1);
  assert.equal(store.getSnapshot().loadError, 'offline');
  await store.cancel('trip-a');
  assert.equal(writes, 0);
  offline = false;
  await store.refresh();
  assert.equal(store.getSnapshot().loadError, '');
  assert.equal(store.getSnapshot().bookings[0].id, 'trip-a');
  store.dispose();
});
void test('server rejects cancellation after the ride starts; refresh shows the new status without pretending success', async () => {
  let reads = 0;
  const store = new CustomerTripsController(async (body) => {
    if (body) throw new Error('Fahrt läuft bereits');
    reads++;
    return { bookings: [trip('trip-a', reads > 1 ? 'riding' : 'accepted')] };
  });
  store.setActive(true);
  await settle();
  await store.cancel('trip-a');
  assert.equal(store.getSnapshot().bookings[0].status, 'riding');
  assert.equal(store.getSnapshot().notice, '');
  assert.equal(store.getSnapshot().actionError, 'Fahrt läuft bereits');
  await store.cancel('trip-a');
  assert.equal(reads, 2);
  store.dispose();
});
