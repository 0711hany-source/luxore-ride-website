import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { createClient } from '@libsql/client';
import { readFileSync, readdirSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  resolve(s, c, next) {
    if (s === '#creation-adapter')
      return {
        url: new URL('../db/sqlite.ts?creation-adapter', import.meta.url).href,
        shortCircuit: true,
      };
    return next(s, c);
  },
  load(url, c, next) {
    if (url.endsWith('/db/sqlite.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source:
          'export const accountsConfigured=()=>true,runtimeDatabase=()=>globalThis.creationTest.db; export class DatabaseUnavailable extends Error {}',
      };
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `export class ApiError extends Error {constructor(status,message){super(message);this.status=status}}
      export const limit=async()=>{},db=()=>globalThis.creationTest.db,settings=()=>({}),tokenHash=async()=>'',isAdmin=u=>u.userId==='operator';
      export const identity=async()=>({userId:globalThis.creationTest.user,displayName:'Synthetic operator'}),body=r=>r.json(),json=(v,status=200)=>Response.json(v,{status});
      export const text=(v,max=100)=>{if(typeof v!=='string'||!v.trim()||v.trim().length>max)throw new ApiError(400,'invalid');return v.trim()};
      export const handled=async fn=>{try{return await fn()}catch(e){return json({error:e.message},e.status||500)}};`,
      };
    if (
      url.endsWith('/app/api/mobility/fleets/route.ts') &&
      process.env.TEST_ORIGINAL_FLEET_CREATE
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_FLEET_CREATE, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
const { sqliteDatabase } = await import('#creation-adapter');
const { POST } = await import('../app/api/mobility/fleets/route.ts');
const id = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const send = (extra = {}) =>
  POST(
    new Request('https://test.invalid/api/mobility/fleets', {
      method: 'POST',
      body: JSON.stringify({
        action: 'create',
        name: 'Synthetic Fleet',
        requestId: id,
        ownerId: 'driver',
        ...extra,
      }),
    }),
  );
async function fixture() {
  const client = createClient({ url: ':memory:' }),
    db = sqliteDatabase(client);
  for (const f of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((f) => f.endsWith('.sql'))
    .sort())
    await client.executeMultiple(
      readFileSync(new URL('../drizzle/' + f, import.meta.url), 'utf8'),
    );
  globalThis.creationTest = { db, user: 'operator' };
  for (const user of ['operator', 'driver', 'staff', 'other-owner'])
    await client.execute({
      sql: "INSERT INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES(?,?,'Test','000','fleet','active',0,0)",
      args: [user, user + '@example.test'],
    });
  await client.executeMultiple(`INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES('old-fleet','Old Fleet','other-owner',1);
 INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('driver','Original Driver','000',NULL,'driver',25),('staff','Original Staff','001',NULL,'staff',26),('other-owner','Other Owner','002','old-fleet','staff',1);
 INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,services,approved,online,session_id) VALUES('driver','Original Driver','000','','','premium','["premium"]',1,0,NULL);
 INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('old-car','old-fleet','Test Audi','TEST A','["premium"]','active',0);`);
  const snapshot = async () =>
    Object.fromEntries(
      await Promise.all(
        [
          'mobility_fleets',
          'mobility_employees',
          'mobility_drivers',
          'mobility_vehicles',
          'mobility_bookings',
          'mobility_offers',
          'mobility_operator_audit',
        ].map(async (table) => [
          table,
          (await db.prepare('SELECT * FROM ' + table + ' ORDER BY 1').all())
            .results,
        ]),
      ),
    );
  return { client, db, snapshot, close: () => client.close() };
}
void test('fleet creation and owner membership roll back together on audit failure; same ID can retry', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    await f.client.executeMultiple(
      "CREATE TRIGGER fail_create_audit BEFORE INSERT ON mobility_operator_audit BEGIN SELECT RAISE(ABORT,'synthetic audit failure'); END;",
    );
    assert.equal((await send()).status, 500);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute('DROP TRIGGER fail_create_audit');
    const r = await send();
    assert.equal(r.status, 201);
    assert.deepEqual(await r.json(), { id, name: 'Synthetic Fleet' });
    const saved = await f.snapshot();
    assert.equal(
      saved.mobility_employees.find((e) => e.user_id === 'driver').fleet_id,
      id,
    );
    assert.equal(saved.mobility_operator_audit.length, 1);
    assert.equal(saved.mobility_operator_audit[0].action, 'fleet.created');
    assert.deepEqual(saved.mobility_vehicles, before.mobility_vehicles);
    assert.deepEqual(saved.mobility_drivers, before.mobility_drivers);
  } finally {
    f.close();
  }
});
void test('failed existing owner membership preserves profile and rolls back the new fleet before retry', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    await f.client.executeMultiple(
      "CREATE TRIGGER fail_create_member BEFORE UPDATE ON mobility_employees BEGIN SELECT RAISE(ABORT,'synthetic member failure'); END;",
    );
    assert.equal((await send()).status, 500);
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute('DROP TRIGGER fail_create_member');
    assert.equal((await send()).status, 201);
    const e = (await f.snapshot()).mobility_employees.find(
      (e) => e.user_id === 'driver',
    );
    assert.equal(e.name, 'Original Driver');
    assert.equal(e.role, 'driver');
    assert.equal(e.created_at, 25);
  } finally {
    f.close();
  }
});
void test('blocked/deleting actor and intended owner cannot create a fleet or change a profile', async () => {
  for (const subject of ['operator', 'driver'])
    for (const status of ['blocked', 'deletion_pending']) {
      const f = await fixture();
      try {
        await f.client.execute({
          sql: 'UPDATE mobility_accounts SET status=? WHERE id=?',
          args: [status, subject],
        });
        const before = await f.snapshot();
        assert.equal((await send()).status, subject === 'operator' ? 403 : 409);
        assert.deepEqual(await f.snapshot(), before);
      } finally {
        f.close();
      }
    }
});
void test('owner or operator blocked at write boundary is checked inside actual libSQL transaction', async () => {
  for (const subject of ['operator', 'driver']) {
    const f = await fixture();
    try {
      const before = await f.snapshot(),
        write = f.db.writeTransaction,
        batch = f.db.batch;
      const block = () =>
        f.client.execute({
          sql: "UPDATE mobility_accounts SET status='blocked' WHERE id=?",
          args: [subject],
        });
      f.db.writeTransaction = async (work) => {
        await block();
        return write(work);
      };
      f.db.batch = async (statements) => {
        await block();
        return batch(statements);
      };
      assert.equal((await send()).status, subject === 'operator' ? 403 : 409);
      assert.deepEqual(await f.snapshot(), before);
    } finally {
      f.close();
    }
  }
});
void test('identical lost-response retry confirms current record without resetting later GPS or duplicating audit', async () => {
  const f = await fixture();
  try {
    assert.equal((await send()).status, 201);
    await f.client.executeMultiple(
      `INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('new-car','${id}','Test Car','TEST B','["premium"]','active',0);UPDATE mobility_drivers SET approved=1,online=1,session_id='gps',vehicle_id='new-car',vehicle='Test Car',plate='TEST B',lat=50,lng=8,accuracy=5,location_at=100 WHERE id='driver';`,
    );
    const before = await f.snapshot();
    const retry = await send();
    assert.equal(retry.status, 200);
    assert.deepEqual(await retry.json(), {
      id,
      name: 'Synthetic Fleet',
      replayed: true,
    });
    assert.deepEqual(await f.snapshot(), before);
    assert.equal(before.mobility_operator_audit.length, 1);
    assert.equal((await send({ name: 'Changed' })).status, 409);
    assert.equal((await send({ ownerId: 'staff' })).status, 409);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
void test('new creation cannot take existing membership, owner or deputy even with inconsistent legacy membership', async () => {
  for (const role of ['member', 'owner', 'deputy']) {
    const f = await fixture();
    try {
      if (role === 'member')
        await f.client.execute(
          "UPDATE mobility_employees SET fleet_id='old-fleet' WHERE user_id='driver'",
        );
      if (role === 'owner') {
        await f.client.execute(
          "UPDATE mobility_fleets SET owner_id='driver' WHERE id='old-fleet'",
        );
      }
      if (role === 'deputy')
        await f.client.execute(
          "UPDATE mobility_fleets SET deputy_id='driver' WHERE id='old-fleet'",
        );
      const before = await f.snapshot();
      assert.equal((await send()).status, 409);
      assert.deepEqual(await f.snapshot(), before);
    } finally {
      f.close();
    }
  }
});
void test('online GPS active trip and unpaid completion guards protect new owner assignment', async () => {
  for (const guard of ['online', 'gps', 'trip', 'unpaid']) {
    const f = await fixture();
    try {
      if (guard === 'online')
        await f.client.execute(
          "UPDATE mobility_drivers SET online=1 WHERE id='driver'",
        );
      if (guard === 'gps')
        await f.client.execute(
          "UPDATE mobility_drivers SET session_id='gps' WHERE id='driver'",
        );
      if (guard === 'trip' || guard === 'unpaid')
        await f.client.execute({
          sql: "INSERT INTO mobility_bookings(id,quote_id,owner_id,service,price,route,mode,status,driver_id,created_at,updated_at,payment_status,completed_at) VALUES('trip','quote','customer','premium',2500,'{}','now',?,'driver',0,0,?,?)",
          args: [
            guard === 'trip' ? 'accepted' : 'completed',
            guard === 'unpaid' ? 'unpaid' : 'paid',
            guard === 'unpaid' ? 100 : null,
          ],
        });
      const before = await f.snapshot();
      assert.equal((await send()).status, 409);
      assert.deepEqual(await f.snapshot(), before);
    } finally {
      f.close();
    }
  }
});
void test('current competing commit is confirmed unchanged and renamed/transferred record is a conflict', async () => {
  const f = await fixture();
  try {
    const write = f.db.writeTransaction,
      batch = f.db.batch;
    let injected = false;
    const compete = async () => {
      if (injected) return;
      injected = true;
      await f.client.execute({
        sql: 'INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES(?,?,?,123)',
        args: [id, 'Synthetic Fleet', 'driver'],
      });
      await f.client.execute({
        sql: 'UPDATE mobility_employees SET fleet_id=? WHERE user_id=?',
        args: [id, 'driver'],
      });
    };
    f.db.writeTransaction = async (work) => {
      await compete();
      return write(work);
    };
    f.db.batch = async (statements) => {
      await compete();
      return batch(statements);
    };
    const retry = await send();
    assert.equal(retry.status, 200);
    assert.equal((await retry.json()).replayed, true);
    const saved = await f.snapshot();
    assert.equal(
      saved.mobility_fleets.find((e) => e.id === id).created_at,
      123,
    );
    assert.equal(saved.mobility_operator_audit.length, 0);
    await f.client.execute({
      sql: 'UPDATE mobility_fleets SET name=? WHERE id=?',
      args: ['Renamed', id],
    });
    assert.equal((await send()).status, 409);
    await f.client.execute({
      sql: 'UPDATE mobility_fleets SET name=?,owner_id=? WHERE id=?',
      args: ['Synthetic Fleet', 'staff', id],
    });
    assert.equal((await send()).status, 409);
  } finally {
    f.close();
  }
});
void test('creation remains operator-only with valid UUID and known owner; self and staff legacy profiles remain supported', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    assert.equal((await send({ requestId: 'invalid' })).status, 400);
    assert.equal((await send({ ownerId: 'missing' })).status, 404);
    globalThis.creationTest.user = 'other-owner';
    assert.equal((await send()).status, 403);
    globalThis.creationTest.user = 'operator';
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute("DELETE FROM mobility_accounts WHERE id='staff'");
    assert.equal((await send({ ownerId: 'staff' })).status, 201);
    const saved = await f.snapshot();
    assert.equal(
      saved.mobility_employees.find((e) => e.user_id === 'staff').role,
      'staff',
    );
    assert.deepEqual(saved.mobility_drivers, before.mobility_drivers);
    const self = await send({
      ownerId: 'operator',
      requestId: '11111111-2222-3333-4444-555555555555',
    });
    assert.equal(self.status, 201);
    assert.equal(
      (await f.snapshot()).mobility_employees.find(
        (e) => e.user_id === 'operator',
      ).name,
      'Synthetic operator',
    );
  } finally {
    f.close();
  }
});
void test('blocked operator cannot replay an existing creation and another request ID cannot duplicate its owner', async () => {
  const f = await fixture();
  try {
    assert.equal((await send()).status, 201);
    const before = await f.snapshot();
    assert.equal(
      (await send({ requestId: '11111111-2222-3333-4444-555555555555' }))
        .status,
      409,
    );
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute(
      "UPDATE mobility_accounts SET status='blocked' WHERE id='operator'",
    );
    assert.equal((await send()).status, 403);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
