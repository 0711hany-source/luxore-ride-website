import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
const store = new Map([['luxore-account-v1', 'a'.repeat(64)]]);
globalThis.nativeViewStore = store;
globalThis.customerAppListeners = new Set();
globalThis.require = () => 1; // Metro resolves static PNG assets in real APKs.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    'react-native',
    `
    export const View='View', Text='Text', Pressable='Pressable', ScrollView='ScrollView', Modal='Modal', Image='Image', TextInput='TextInput', KeyboardAvoidingView='KeyboardAvoidingView', ActivityIndicator='ActivityIndicator';
    export const Platform={OS:'android'}, StyleSheet={create:v=>v}, Keyboard={dismiss(){}}, Share={async share(){}}, Linking={async openURL(){},async openSettings(){}}, Alert={alert(){}};
    export const AppState={currentState:'active',addEventListener(event,listener){globalThis.customerAppListeners.add(listener);return {remove(){globalThis.customerAppListeners.delete(listener)}}}}, BackHandler={addEventListener(){return {remove(){}}}};
    export const useWindowDimensions=()=>({width:390,height:844});
    export const PanResponder={create:handlers=>({panHandlers:handlers})};
    export const Animated={Value:class {constructor(v){this.value=v}setValue(v){this.value=v}},View:'AnimatedView',spring:(v,o)=>({start:()=>v.setValue(o.toValue)})};
  `,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaProvider='SafeAreaProvider', SafeAreaView='SafeAreaView';`,
  ],
  ['expo-status-bar', `export const StatusBar='StatusBar';`],
  [
    'expo-constants',
    `export default {expoConfig:{extra:{variant:'customer'}}};`,
  ],
  [
    'expo-secure-store',
    `export const getItemAsync=async k=>globalThis.nativeViewStore.get(k)||null,setItemAsync=async(k,v)=>{globalThis.nativeViewStore.set(k,v)},deleteItemAsync=async k=>{globalThis.nativeViewStore.delete(k)};`,
  ],
  [
    'expo-crypto',
    `export const randomUUID=()=> 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';`,
  ],
  [
    'expo-notifications',
    `export const getLastNotificationResponse=()=>null,clearLastNotificationResponse=()=>{},addNotificationResponseReceivedListener=()=>({remove(){}});`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',ArrowRight='ArrowRight', CalendarDays='CalendarDays', CarFront='CarFront', Check='Check', ChevronRight='ChevronRight', CircleHelp='CircleHelp', Home='Home', LogOut='LogOut', Mail='Mail', MapPinned='MapPinned', MapPin='MapPin', Clock3='Clock3', Settings='Settings', ShieldCheck='ShieldCheck', UserRound='UserRound', Users='Users',ChevronDown='ChevronDown',LocateFixed='LocateFixed',Navigation='Navigation',Phone='Phone',RefreshCw='RefreshCw',X='X',Plus='Plus';`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    let source = mocked.get(specifier);
    if (specifier.endsWith('/RideWorkspace') || specifier === './RideWorkspace')
      source = `export default function ForbiddenEmbeddedDriver(){throw new Error('Driver mounted a WebView');}`;
    if (specifier === './use-driver-gps')
      source = `export function useDriverGps(){return {position:{lat:50.11,lng:8.68,accuracy:8,timestamp:Date.now()},sessionId:null,error:'',foreground:true,restart:async()=>{},sync:async()=>({active:false})}}`;
    if (specifier === './location-service')
      source = `export const resumeLocation=async()=>({active:false}),stopLocation=async()=>{},foregroundPermission=async()=>{},startLocation=async()=>({active:true});`;
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: App } = await import('../mobile/src/App.tsx');
const { default: SwipeAction } = await import('../mobile/src/SwipeAction.tsx');

const account = {
  id: 'customer-a',
  name: 'Customer Test',
  email: 'test@example.test',
  phone: '+490000000',
  kind: 'customer',
};
const point = (label) => ({ id: label, label, lat: 50.11, lng: 8.68 });
const route = {
  pickup: point('Opernplatz Frankfurt'),
  destination: point('Frankfurt Flughafen'),
  distanceMeters: 21000,
  durationSeconds: 1500,
};
const rows = [
  {
    id: 'trip-a',
    route,
    status: 'accepted',
    service: 'premium',
    price: 5250,
    created_at: Date.now(),
    scheduled_at: null,
    payment_status: 'unpaid',
    driver: {
      name: 'TEST Fahrer',
      vehicle: 'Audi A6',
      plate: 'TEST',
      phone: '+490000000',
    },
  },
  {
    id: 'reserved-a',
    route,
    status: 'reserved',
    service: 'first',
    price: 7350,
    created_at: Date.now(),
    scheduled_at: Date.now() + 86400000,
    payment_status: 'unpaid',
    driver: null,
  },
];
async function settle() {
  for (let i = 0; i < 8; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
void test('customer trip tab and native details never mount an embedded view; only a full swipe cancels', async () => {
  const old = globalThis.fetch;
  let renderer,
    writes = 0,
    reads = 0;
  globalThis.fetch = async (url, options) => {
    assert.match(url, /^https:\/\/luxoreride.de\/api\/mobility\//);
    assert.equal(options.headers.Authorization, 'Bearer ' + 'a'.repeat(64));
    if (url.endsWith('/account'))
      return Response.json({
        account,
        registrationReady: true,
        isAdmin: false,
      });
    assert.ok(url.endsWith('/bookings'));
    if (options.method === 'POST') {
      writes++;
      assert.deepEqual(JSON.parse(options.body), {
        action: 'cancel',
        id: 'trip-a',
      });
      rows[0] = { ...rows[0], status: 'cancelled' };
      return Response.json({ ok: true });
    }
    reads++;
    return Response.json({ bookings: rows });
  };
  try {
    await act(async () => {
      renderer = Renderer.create(React.createElement(App));
    });
    await settle();
    assert.equal(reads, 0);
    const tab = renderer.root
      .findAllByType('Pressable')
      .find(
        (n) =>
          n.props.accessibilityRole === 'tab' &&
          n.findAllByType('Text').some((t) => t.props.children === 'Fahrten'),
      );
    assert.ok(tab);
    await act(async () => tab.props.onPress());
    await settle();
    assert.equal(reads, 1);
    assert.match(JSON.stringify(renderer.toJSON()), /Reservierungen/);
    assert.match(JSON.stringify(renderer.toJSON()), /Fahrerzusage ausstehend/);
    const trip = renderer.root
      .findAllByType('Pressable')
      .find(
        (n) =>
          n.props.accessibilityLabel ===
          'Fahrer auf dem Weg · Frankfurt Flughafen',
      );
    await act(async () => trip.props.onPress());
    const modal = renderer.root
      .findAllByType('Modal')
      .find((n) => n.props.visible);
    assert.ok(modal.findByType('SafeAreaView'));
    assert.match(
      JSON.stringify(modal.findAllByType('Text').map((n) => n.props.children)),
      /Fahrtdetails|TEST Fahrer|Audi A6/,
    );
    assert.equal(
      modal
        .findAllByType('Pressable')
        .filter((n) =>
          n
            .findAllByType('Text')
            .some((t) => t.props.children === 'Fahrt stornieren'),
        ).length,
      0,
    );
    const swipe = modal.findByType(SwipeAction),
      track = swipe.findAllByType('View')[0];
    await act(async () =>
      track.props.onLayout({ nativeEvent: { layout: { width: 300 } } }),
    );
    const thumb = swipe.findByType('AnimatedView');
    assert.equal(thumb.props.onPress, undefined);
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 80 }));
    assert.equal(writes, 0);
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 230 }));
    await settle();
    assert.equal(writes, 1);
    assert.match(JSON.stringify(renderer.toJSON()), /Storniert/);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});
void test('native trip polling pauses in the background and reloads on foreground return', async (t) => {
  t.mock.timers.enable({ apis: ['setInterval'] });
  const old = globalThis.fetch;
  let renderer,
    reads = 0;
  const { AppState } = await import('react-native');
  globalThis.fetch = async (url) => {
    if (url.endsWith('/account'))
      return Response.json({
        account,
        registrationReady: true,
        isAdmin: false,
      });
    assert.ok(url.endsWith('/bookings'));
    reads++;
    return Response.json({ bookings: rows });
  };
  try {
    await act(async () => {
      renderer = Renderer.create(React.createElement(App));
    });
    await settle();
    const tab = renderer.root
      .findAllByType('Pressable')
      .find(
        (n) =>
          n.props.accessibilityRole === 'tab' &&
          n.findAllByType('Text').some((n) => n.props.children === 'Fahrten'),
      );
    await act(async () => tab.props.onPress());
    await settle();
    assert.equal(reads, 1);
    await act(async () => {
      AppState.currentState = 'background';
      for (const listener of globalThis.customerAppListeners)
        listener('background');
      t.mock.timers.tick(30000);
    });
    await settle();
    assert.equal(reads, 1);
    await act(async () => {
      AppState.currentState = 'active';
      for (const listener of globalThis.customerAppListeners)
        listener('active');
    });
    await settle();
    assert.equal(reads, 2);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
    AppState.currentState = 'active';
  }
});
