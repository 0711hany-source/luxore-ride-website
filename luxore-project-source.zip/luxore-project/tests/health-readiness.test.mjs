import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';

registerHooks({
  load(url, context, next) {
    if (url.endsWith('/db/sqlite.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `export const accountsConfigured=()=>globalThis.healthFixture.accounts;
          export const databaseConfigured=()=>globalThis.healthFixture.booking;
          export const runtimeDatabase=()=>globalThis.healthFixture.db;`,
      };
    if (url.endsWith('/lib/mobility/accounts.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: 'export const mailReady=()=>globalThis.healthFixture.mail;',
      };
    return next(url, context);
  },
});
const { GET } = await import('../app/api/health/route.ts');
const migration = (file) =>
  readFileSync(new URL('../drizzle/' + file, import.meta.url), 'utf8');

function fixture({ current = true } = {}) {
  const sqlite = new DatabaseSync(':memory:');
  for (const file of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((f) => f.endsWith('.sql'))
    .sort()) {
    if (current || !file.startsWith('0018_')) sqlite.exec(migration(file));
  }
  const queries = [];
  globalThis.healthFixture = {
    accounts: true,
    booking: true,
    mail: true,
    db: {
      prepare(sql) {
        queries.push(sql);
        return {
          async all() {
            return { results: sqlite.prepare(sql).all() };
          },
        };
      },
    },
  };
  return {
    sqlite,
    queries,
    close() {
      sqlite.close();
      delete globalThis.healthFixture;
    },
  };
}

test('health rejects the previous schema while keeping working accounts ready; the additive migration restores booking readiness', async () => {
  const f = fixture({ current: false });
  try {
    let response = await GET();
    assert.equal(response.status, 503);
    assert.equal(response.headers.get('cache-control'), 'no-store');
    assert.deepEqual(await response.json(), {
      service: 'luxore-ride',
      bookingConfigured: false,
      databaseConnected: true,
      accountsReady: true,
    });
    f.sqlite.exec(migration('0018_gorgeous_changeling.sql'));
    response = await GET();
    assert.equal(response.status, 200);
    assert.deepEqual(await response.json(), {
      service: 'luxore-ride',
      bookingConfigured: true,
      databaseConnected: true,
      accountsReady: true,
    });
    assert.ok(
      f.queries.every(
        (sql) => /^\s*SELECT\b/i.test(sql) && /LIMIT 0\s*$/.test(sql),
      ),
    );
  } finally {
    f.close();
  }
});

test('missing core booking tables cannot report a healthy booking service', async () => {
  for (const table of [
    'mobility_quotes',
    'mobility_bookings',
    'mobility_offers',
  ]) {
    const f = fixture();
    try {
      f.sqlite.exec('DROP TABLE ' + table);
      const response = await GET();
      assert.equal(response.status, 503, table);
      const result = await response.json();
      assert.equal(result.bookingConfigured, false);
      assert.equal(result.accountsReady, true);
    } finally {
      f.close();
    }
  }
});

test('readiness preserves deliberate activation switches and checks the mail dependency separately', async () => {
  const f = fixture();
  try {
    globalThis.healthFixture.booking = false;
    assert.equal((await GET()).status, 503);
    assert.equal(f.queries.length, 2); // No booking query when explicitly closed.
    globalThis.healthFixture.accounts = false;
    f.queries.length = 0;
    assert.deepEqual(await (await GET()).json(), {
      service: 'luxore-ride',
      bookingConfigured: false,
      databaseConnected: false,
      accountsReady: false,
    });
    assert.equal(f.queries.length, 0);
    globalThis.healthFixture.accounts = true;
    globalThis.healthFixture.booking = true;
    globalThis.healthFixture.mail = false;
    const response = await GET();
    assert.equal(response.status, 200);
    assert.equal((await response.json()).accountsReady, false);
  } finally {
    f.close();
  }
});

test('database failures are unhealthy and do not expose private diagnostics', async () => {
  const f = fixture();
  try {
    globalThis.healthFixture.db = {
      prepare() {
        throw new Error('libsql://private-host.invalid token=secret');
      },
    };
    const response = await GET();
    assert.equal(response.status, 503);
    assert.deepEqual(await response.json(), {
      service: 'luxore-ride',
      bookingConfigured: false,
      databaseConnected: false,
      accountsReady: false,
    });
  } finally {
    f.close();
  }
});
