"""Real HTTP tests, isolated device cookie jars and local SQL route fixtures only."""
import os, copy, concurrent.futures, json, urllib.request, urllib.error, http.cookiejar, uuid, sqlite3, pathlib, time
base=os.environ.get('TEST_BASE_URL','http://localhost:3000')
def client(): return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def call(c,path,b=None,origin=base):
 req=urllib.request.Request(base+'/api/mobility/'+path,data=json.dumps(b).encode() if b is not None else None,headers={'Content-Type':'application/json','Origin':origin})
 try:
  with c.open(req) as r:return r.status,json.loads(r.read()),r.headers
 except urllib.error.HTTPError as e:
  raw=e.read()
  try: value=json.loads(raw)
  except ValueError: value=raw.decode()[:200]
  return e.code,value,e.headers
rider,other,driver,admin=client(),client(),client(),client()
assert call(rider,'config')[0]==401
assert call(rider,'session',{},'https://attacker.invalid')[0]==403
users=[]
for c in (rider,other,driver):
 code,b,h=call(c,'session',{});assert code==201,(code,b)
 assert 'HttpOnly' in h['Set-Cookie'] and 'SameSite=Strict' in h['Set-Cookie']
 code,config,_=call(c,'config');assert code==200 and not config['isAdmin'];users.append(config['userId'])
 assert call(c,'session',{})[0]==200
 assert call(c,'operations')[0]==403
assert len(set(users))==3
admin.open(base+'/signin-with-chatgpt?return_to=%2F').close()
assert call(admin,'config')[1]['isAdmin']
connection=None
for file in pathlib.Path('.wrangler/state/v3/d1').rglob('*.sqlite'):
 c=sqlite3.connect(file)
 if c.execute("SELECT name FROM sqlite_master WHERE name='mobility_quotes'").fetchone():connection=c;break
 c.close()
assert connection
now=int(time.time()*1000);prefix='mobile-test-'+str(uuid.uuid4())
def quote(who):
 q={'id':prefix+str(uuid.uuid4()),'pickup':{'id':'p','label':'TEST Opernplatz','lat':50.115,'lng':8.67},'destination':{'id':'d','label':'TEST Hbf','lat':50.107,'lng':8.663},'distanceMeters':10000,'durationSeconds':1200,'geometry':{'type':'LineString','coordinates':[[8.67,50.115],[8.663,50.107]]},'calculatedAt':now,'expiresAt':now+300000,'prices':{'premium':2500,'first':3500,'van':3000},'mode':'now','scheduledAt':None}
 connection.execute('INSERT INTO mobility_quotes VALUES(?,?,?,?)',(q['id'],who,json.dumps(q),q['expiresAt']));connection.commit();return q
try:
 for column,kind in [('refreshments','TEXT'),('fare_price','INTEGER')]:
  if column not in [r[1] for r in connection.execute('PRAGMA table_info(mobility_bookings)')]:connection.execute(f'ALTER TABLE mobility_bookings ADD COLUMN {column} {kind}')
 connection.commit()
 def ok(c,path,b=None,status=200):
  code,data,_=call(c,path,b);assert code==status,(path,code,data);return data
 q=quote(users[0])
 ok(driver,'driver',{'action':'register','name':'TEST Board Driver','phone':'+490000000','vehicle':'TEST S','plate':'TEST BOARD','services':['premium']})
 ok(admin,'operations',{'driverId':users[2],'approved':True})
 fleet=prefix+'-fleet'; vehicle=prefix+'-car'
 connection.execute('INSERT INTO mobility_fleets(id,owner_id,name,created_at) VALUES(?,?,?,?)',(fleet,users[2],'TEST pantry',now))
 connection.execute("INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,?,?,?,?,?)",(users[2],'TEST Driver','0',fleet,'driver',now))
 connection.execute("INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES(?,?,?,?,?,'active',?)",(vehicle,fleet,'TEST S',prefix,'["premium"]',now))
 connection.execute('UPDATE mobility_drivers SET vehicle_id=? WHERE id=?',(vehicle,users[2]));connection.commit()
 inventory=ok(driver,'inventory?vehicleId='+vehicle)
 assert not inventory['initialized']
 for item in inventory['stock']['items'].values():item['count']=item['target']
 inventory=ok(driver,'inventory',{'action':'save','vehicleId':vehicle,'revision':0,'stock':inventory['stock'],'note':'Test first count'})
 assert call(other,'inventory?vehicleId='+vehicle)[0]==403
 assert call(rider,'inventory',{'action':'personal','vehicleId':vehicle,'revision':1,'quantities':{'cola':1}})[0]==403
 too_full=copy.deepcopy(inventory['stock']);too_full['items']['cola']['target']=5
 assert call(driver,'inventory',{'action':'save','vehicleId':vehicle,'revision':1,'stock':too_full,'note':'overflow'})[0]==400
 assert call(driver,'inventory',{'action':'personal','vehicleId':vehicle,'revision':1,'quantities':{'water':4}})[0]==400
 def consume():return call(driver,'inventory',{'action':'personal','vehicleId':vehicle,'revision':1,'quantities':{'cola':1},'note':'TEST driver drink'})
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: results=list(pool.map(lambda _:consume(),range(2)))
 assert sorted(r[0] for r in results)==[200,409],results
 inventory=ok(driver,'inventory?vehicleId='+vehicle);assert inventory['stock']['items']['cola']['count']==3 and inventory['revision']==2
 assert len([m for m in inventory['movements'] if m['kind']=='personal'])==1
 assert call(driver,'inventory',{'action':'restock','vehicleId':vehicle,'revision':1,'quantities':{'cola':1}})[0]==409
 inventory=ok(driver,'inventory',{'action':'restock','vehicleId':vehicle,'revision':2,'quantities':{'cola':1}})
 assert inventory['stock']['items']['cola']['count']==4
 # Ordinary approved driver in the same fleet cannot read a colleague's car.
 employee=client();ok(employee,'session',{},201); employee_id=ok(employee,'config')['userId'];users.append(employee_id)
 connection.execute("INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,?,?,?,?,?)",(employee_id,'TEST coworker','0',fleet,'driver',now))
 connection.execute("INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved) VALUES(?,?,?,?,?,?,1)",(employee_id,'TEST coworker','0','TEST','TEST','premium'));connection.commit()
 assert call(employee,'inventory?vehicleId='+vehicle)[0]==403
 sid=ok(driver,'driver',{'action':'online'})['sessionId']
 ok(driver,'driver',{'action':'heartbeat','sessionId':sid,'lat':50.115,'lng':8.67,'accuracy':10})
 booking=ok(rider,'bookings',{'quoteId':q['id'],'service':'premium','riderName':'TEST Board Customer','riderPhone':'+490000001','refreshments':{'water':2,'energy':1,'pretzels':1}},201)
 bid=booking['id'];assert booking['price']==2500 and booking['fare_price']==2500
 assert booking['refreshments']['requested']['water']==2
 offer=ok(driver,'driver')['offers'][0]
 assert offer['booking']['refreshments']['requested']['energy']==1
 ok(driver,'driver',{'action':'accept','offerId':offer['id']})
 inventory=ok(driver,'inventory?vehicleId='+vehicle)
 ok(driver,'inventory',{'action':'personal','vehicleId':vehicle,'revision':inventory['revision'],'quantities':{'cookies':1}})
 assert ok(driver,'driver')['bookings'][0]['price']==2500

 def order(c,action,rev,**fields):return call(c,'refreshments',dict(id=bid,action=action,revision=rev,**fields))
 assert order(other,'request',0,cart={})[0]==404
 assert order(rider,'deliver',0,itemId='water',quantity=1)[0]==403
 assert order(driver,'request',0,cart={})[0]==403
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  delivered=list(pool.map(lambda _:order(driver,'deliver',0,itemId='water',quantity=2),range(2)))
 assert sorted(r[0] for r in delivered)==[200,409],delivered
 b=next(r[1] for r in delivered if r[0]==200);assert b['price']==2500
 inventory=ok(driver,'inventory?vehicleId='+vehicle)
 assert inventory['stock']['items']['water']['count']==1
 assert len([m for m in inventory['movements'] if m['kind']=='delivery'])==1
 assert ok(driver,'driver')['inventory']['urgent']==1
 assert order(driver,'deliver',0,itemId='water',quantity=2)[0]==409
 code,b,_=order(driver,'unavailable',1,itemId='pretzels',quantity=1);assert code==200 and b['price']==2500
 code,b,_=order(driver,'deliver',2,itemId='energy',quantity=1);assert code==200 and b['price']==2750
 code,b,_=order(rider,'request',3,cart={'cola':1});assert code==200 and b['price']==2750
 ok(driver,'driver',{'action':'status','id':bid,'from':'accepted','status':'arrived'})
 ok(driver,'driver',{'action':'status','id':bid,'from':'arrived','status':'riding'})
 code,b,_=order(driver,'deliver',4,itemId='cola',quantity=1);assert code==200 and b['price']==3000
 ok(driver,'driver',{'action':'status','id':bid,'from':'riding','status':'completed'})
 assert order(rider,'request',5,cart={'cola':1})[0]==409
 assert order(driver,'deliver',5,itemId='cola',quantity=1)[0]==409
 payment=ok(driver,'driver')['payments'][0];assert payment['price']==3000 and payment['fare_price']==2500
 ok(driver,'payments',{'id':bid,'method':'cash'})
 assert ok(driver,'driver')['today']['gross']==3000
 inventory=ok(driver,'inventory?vehicleId='+vehicle)
 assert inventory['stock']['items']['energy']['count']==1 and inventory['stock']['items']['cola']['count']==3
 print('PASS: stock setup, capacity, negative stock, fleet isolation, concurrent consumption, stale restock and atomic duplicate handover protection.')
 print('PASS: prebooking order reaches driver offer; live revisions; rider/driver isolation; partial fulfillment; free allowances persist; unavailable items not charged; final receipt/revenue includes delivered extras; completed rides closed.')
finally:
 for table,col in [('mobility_stock_movements','vehicle_id'),('mobility_stock','vehicle_id'),('mobility_vehicles','id')]:connection.execute(f'DELETE FROM {table} WHERE {col}=?',(prefix+'-car',))
 connection.execute('DELETE FROM mobility_fleets WHERE id=?',(prefix+'-fleet',))
 for u in users:
  connection.execute('DELETE FROM mobility_employees WHERE user_id=?',(u,))
  for table,column in [('mobility_events','actor_id'),('mobility_offers','driver_id'),('mobility_bookings','owner_id'),('mobility_quotes','owner_id'),('mobility_drivers','id'),('mobility_sessions','user_id')]:connection.execute(f'DELETE FROM {table} WHERE {column}=?',(u,))
 connection.commit();connection.close()
