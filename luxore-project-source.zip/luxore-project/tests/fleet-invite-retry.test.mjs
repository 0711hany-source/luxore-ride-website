import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { createClient } from '@libsql/client';
import { readFileSync, readdirSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  resolve(s, c, next) {
    if (s === '#invite-adapter')
      return {
        url: new URL('../db/sqlite.ts?invite-adapter', import.meta.url).href,
        shortCircuit: true,
      };
    return next(s, c);
  },
  load(url, c, next) {
    if (url.endsWith('/db/sqlite.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `export const accountsConfigured=()=>true,runtimeDatabase=()=>globalThis.inviteTest.db; export class DatabaseUnavailable extends Error {}`,
      };
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `
      export class ApiError extends Error {constructor(status,message){super(message);this.status=status}}
      export const limit=async()=>{}; export const db=()=>globalThis.inviteTest.db,settings=()=>({}),tokenHash=async token=>{const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token));return Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('')},isAdmin=u=>u.userId==='operator';
      export const identity=async()=>({userId:globalThis.inviteTest.user}),body=r=>r.json(),json=(v,status=200)=>Response.json(v,{status});
      export const text=v=>{if(typeof v!=='string'||!v.trim())throw new ApiError(400,'empty');return v.trim()};
      export const handled=async fn=>{try{return await fn()}catch(e){return json({error:e.message},e.status||500)}};
    `,
      };
    return next(url, c);
  },
});
const { sqliteDatabase } = await import('#invite-adapter');
const { POST } = await import('../app/api/mobility/fleets/route.ts');

const send = (input) =>
  POST(
    new Request('https://test.invalid/api/mobility/fleets', {
      method: 'POST',
      body: JSON.stringify(input),
    }),
  );
const join = (code) => send({ action: 'join', code });
const hash = async (code) =>
  Array.from(
    new Uint8Array(
      await crypto.subtle.digest('SHA-256', new TextEncoder().encode(code)),
    ),
    (b) => b.toString(16).padStart(2, '0'),
  ).join('');
const code = 'LX-' + 'A'.repeat(32);
async function fixture() {
  const client = createClient({ url: ':memory:' }),
    db = sqliteDatabase(client);
  for (const name of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((n) => n.endsWith('.sql'))
    .sort())
    await client.executeMultiple(
      readFileSync(new URL('../drizzle/' + name, import.meta.url), 'utf8'),
    );
  globalThis.inviteTest = { db, user: 'joiner' };
  for (const suffix of ['a', 'b']) {
    await client.execute({
      sql: 'INSERT INTO mobility_fleets(id,name,owner_id,deputy_id,created_at) VALUES(?,?,?,?,0)',
      args: [
        'fleet-' + suffix,
        'Synthetic ' + suffix,
        'owner-' + suffix,
        'deputy-' + suffix,
      ],
    });
    for (const prefix of ['owner-', 'deputy-'])
      await client.execute({
        sql: "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,'Test','000',?,'staff',0)",
        args: [prefix + suffix, 'fleet-' + suffix],
      });
  }
  for (const id of [
    'joiner',
    'owner-a',
    'deputy-a',
    'owner-b',
    'deputy-b',
    'ordinary',
  ])
    await client.execute({
      sql: "INSERT INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES(?,?,'Test','000','driver','active',0,0)",
      args: [id, id + '@example.test'],
    });
  await client.execute(
    "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('ordinary','Test','000','fleet-a','driver',0)",
  );
  await client.execute(
    "INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,vehicle_id,services) VALUES('joiner','Test','000','Test car','TEST A','premium',1,0,'car','[\"premium\",\"first\"]')",
  );
  await client.execute(
    "INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('car','fleet-b','Test car','TEST A','[\"premium\",\"first\"]','active',0)",
  );
  await client.execute({
    sql: 'INSERT INTO mobility_fleet_invites(token_hash,fleet_id,inviter_id,expires_at) VALUES(?,?,?,?)',
    args: [await hash(code), 'fleet-a', 'owner-a', Date.now() + 86400000],
  });
  await client.execute(
    "INSERT INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at) VALUES('offer','trip','joiner','pending',9999999999999,0)",
  );
  const snapshot = async () =>
    Object.fromEntries(
      await Promise.all(
        [
          'mobility_fleets',
          'mobility_employees',
          'mobility_drivers',
          'mobility_vehicles',
          'mobility_bookings',
          'mobility_offers',
          'mobility_fleet_invites',
          'mobility_operator_audit',
        ].map(async (table) => [
          table,
          (await db.prepare('SELECT * FROM ' + table + ' ORDER BY 1').all())
            .results,
        ]),
      ),
    );
  return { client, db, snapshot, close: () => client.close() };
}
const failAudit = (f) =>
  f.client.executeMultiple(
    "CREATE TRIGGER fail_invite_audit BEFORE INSERT ON mobility_operator_audit BEGIN SELECT RAISE(ABORT,'synthetic audit failure'); END;",
  );
void test('lost join response repeats current same-fleet membership without resetting approval, car, GPS or audit', async () => {
  const f = await fixture();
  try {
    assert.equal((await join(code.toLowerCase())).status, 200);
    const first = await f.snapshot();
    assert.equal(first.mobility_drivers[0].approved, 0);
    assert.equal(first.mobility_drivers[0].vehicle_id, null);
    assert.equal(first.mobility_offers[0].status, 'withdrawn');
    assert.equal(first.mobility_operator_audit.length, 1);
    await f.client.execute(
      "UPDATE mobility_drivers SET approved=1,vehicle_id='car',vehicle='Test car',plate='TEST A',services='[\"premium\",\"first\"]',online=1,session_id='shift',lat=50,lng=8,location_at=100,accuracy=5 WHERE id='joiner'",
    );
    const active = await f.snapshot();
    const replay = await join(code);
    assert.equal(replay.status, 200);
    assert.equal((await replay.json()).replayed, true);
    assert.deepEqual(await f.snapshot(), active);
  } finally {
    f.close();
  }
});
void test('join audit or driver reset failure rolls back membership, approval and pending offers', async () => {
  for (const failure of ['audit', 'driver']) {
    const f = await fixture();
    try {
      const before = await f.snapshot();
      if (failure === 'audit') await failAudit(f);
      else
        await f.client.executeMultiple(
          "CREATE TRIGGER fail_invite_driver BEFORE UPDATE ON mobility_drivers BEGIN SELECT RAISE(ABORT,'synthetic reset failure'); END;",
        );
      assert.equal((await join(code)).status, 500);
      assert.deepEqual(await f.snapshot(), before);
      await f.client.execute(
        'DROP TRIGGER ' +
          (failure === 'audit' ? 'fail_invite_audit' : 'fail_invite_driver'),
      );
      assert.equal((await join(code)).status, 200);
      assert.equal((await f.snapshot()).mobility_operator_audit.length, 1);
    } finally {
      f.close();
    }
  }
});
void test('invalid codes, missing profiles and existing foreign fleet or leadership remain blocked', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    assert.equal((await join('bad')).status, 400);
    assert.equal((await join('LX-' + 'B'.repeat(32))).status, 409);
    assert.deepEqual(await f.snapshot(), before);
    globalThis.inviteTest.user = 'ordinary';
    assert.equal((await join(code)).status, 409);
    globalThis.inviteTest.user = 'joiner';
    await f.client.execute(
      "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('joiner','Test','000','fleet-b','driver',0)",
    );
    let saved = await f.snapshot();
    assert.equal((await join(code)).status, 409);
    assert.deepEqual(await f.snapshot(), saved);
    await f.client.execute(
      "UPDATE mobility_employees SET fleet_id='fleet-a' WHERE user_id='joiner'",
    );
    await f.client.execute(
      "UPDATE mobility_fleets SET deputy_id='joiner' WHERE id='fleet-a'",
    );
    saved = await f.snapshot();
    assert.equal((await join(code)).status, 409);
    assert.deepEqual(await f.snapshot(), saved);
  } finally {
    f.close();
  }
});
void test('expired invitations and revoked or cross-fleet inviter authority cannot join or confirm replay', async () => {
  for (const change of [
    'UPDATE mobility_fleet_invites SET expires_at=0',
    "UPDATE mobility_fleets SET owner_id='replacement' WHERE id='fleet-a'",
    "UPDATE mobility_employees SET fleet_id='fleet-b' WHERE user_id='owner-a'",
  ]) {
    const f = await fixture();
    try {
      await f.client.execute(change);
      const before = await f.snapshot();
      assert.equal((await join(code)).status, 409);
      assert.deepEqual(await f.snapshot(), before);
      await f.client.execute(
        "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('joiner','Test','000','fleet-a','driver',0)",
      );
      const member = await f.snapshot();
      assert.equal((await join(code)).status, 409);
      assert.deepEqual(await f.snapshot(), member);
    } finally {
      f.close();
    }
  }
});
void test('inactive joining or inviting accounts cannot grant membership, including identical repeats', async () => {
  for (const id of ['joiner', 'owner-a'])
    for (const status of ['blocked', 'deletion_pending']) {
      const f = await fixture();
      try {
        await f.client.execute({
          sql: 'UPDATE mobility_accounts SET status=? WHERE id=?',
          args: [status, id],
        });
        const before = await f.snapshot();
        assert.equal((await join(code)).status, id === 'joiner' ? 403 : 409);
        assert.deepEqual(await f.snapshot(), before);
        await f.client.execute(
          "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('joiner','Test','000','fleet-a','driver',0)",
        );
        const member = await f.snapshot();
        assert.equal((await join(code)).status, id === 'joiner' ? 403 : 409);
        assert.deepEqual(await f.snapshot(), member);
      } finally {
        f.close();
      }
    }
});
void test('new join remains blocked for online, GPS, active rides and uncollected completion', async () => {
  for (const condition of [
    'online',
    'session',
    'accepted',
    'arrived',
    'riding',
    'completed',
  ]) {
    const f = await fixture();
    try {
      if (condition === 'online')
        await f.client.execute(
          "UPDATE mobility_drivers SET online=1 WHERE id='joiner'",
        );
      else if (condition === 'session')
        await f.client.execute(
          "UPDATE mobility_drivers SET session_id='shift' WHERE id='joiner'",
        );
      else
        await f.client.execute({
          sql: "INSERT INTO mobility_bookings(id,quote_id,owner_id,driver_id,service,price,route,mode,status,created_at,updated_at,completed_at,payment_status) VALUES('trip','q','customer','joiner','premium',1500,'{}','now',?,0,0,1,'unpaid')",
          args: [condition],
        });
      const before = await f.snapshot();
      assert.equal((await join(code)).status, 409);
      assert.deepEqual(await f.snapshot(), before);
    } finally {
      f.close();
    }
  }
});
void test('expiry at the actual write boundary is checked after delayed hashing or transport', async (t) => {
  t.mock.timers.enable({ apis: ['Date'], now: 2000000 });
  const f = await fixture();
  try {
    await f.client.execute(
      'UPDATE mobility_fleet_invites SET expires_at=2001000',
    );
    const before = await f.snapshot();
    const write = f.db.writeTransaction;
    f.db.writeTransaction = async (work) => {
      t.mock.timers.setTime(2002000);
      return write(work);
    };
    const batch = f.db.batch;
    f.db.batch = async (statements) => {
      t.mock.timers.setTime(2002000);
      return batch(statements);
    };
    assert.equal((await join(code)).status, 409);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
void test('same-fleet staff state and detached existing employee are preserved or joined as appropriate', async () => {
  const f = await fixture();
  try {
    await f.client.execute(
      "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('joiner','Test','000','fleet-a','staff',0)",
    );
    const member = await f.snapshot();
    assert.equal((await join(code)).status, 200);
    assert.deepEqual(await f.snapshot(), member);
    await f.client.execute(
      "UPDATE mobility_employees SET fleet_id=NULL WHERE user_id='joiner'",
    );
    assert.equal((await join(code)).status, 200);
    const joined = await f.snapshot();
    assert.equal(
      joined.mobility_employees.find((e) => e.user_id === 'joiner').role,
      'driver',
    );
    assert.equal(joined.mobility_operator_audit.length, 1);
  } finally {
    f.close();
  }
});
void test('owner/deputy invitation creation returns only committed code; audit failure preserves old invitations', async () => {
  const f = await fixture();
  try {
    globalThis.inviteTest.user = 'owner-a';
    await f.client.execute(
      "INSERT INTO mobility_fleet_invites(token_hash,fleet_id,inviter_id,expires_at) VALUES('old','fleet-a','owner-a',0)",
    );
    const before = await f.snapshot();
    await failAudit(f);
    assert.equal(
      (await send({ action: 'invite_driver', fleetId: 'fleet-a' })).status,
      500,
    );
    assert.deepEqual(await f.snapshot(), before);
    await f.client.execute('DROP TRIGGER fail_invite_audit');
    const reply = await send({ action: 'invite_driver', fleetId: 'fleet-a' });
    assert.equal(reply.status, 200);
    const value = await reply.json();
    assert.match(value.code, /^LX-[A-F0-9]{32}$/);
    assert.ok(value.expiresAt > Date.now());
    const saved = await f.snapshot();
    assert.ok(
      saved.mobility_fleet_invites.some((i) =>
        i.token_hash === undefined ? false : i.token_hash.length === 64,
      ),
    );
    const storedHash = await hash(value.code);
    assert.ok(
      saved.mobility_fleet_invites.some((i) => i.token_hash === storedHash),
    );
    assert.equal(saved.mobility_operator_audit.length, 1);
    assert.equal(JSON.stringify(saved).includes(value.code), false);
    assert.equal(
      saved.mobility_fleet_invites.some((i) => i.token_hash === 'old'),
      false,
    );
    globalThis.inviteTest.user = 'deputy-a';
    assert.equal(
      (await send({ action: 'invite_driver', fleetId: 'fleet-a' })).status,
      200,
    );
  } finally {
    f.close();
  }
});

void test('ordinary staff, foreign or inactive leaders and removed membership cannot create invitations', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    for (const actor of ['ordinary', 'owner-b', 'joiner', 'operator']) {
      globalThis.inviteTest.user = actor;
      assert.equal(
        (await send({ action: 'invite_driver', fleetId: 'fleet-a' })).status,
        403,
      );
    }
    assert.deepEqual(await f.snapshot(), before);
    globalThis.inviteTest.user = 'owner-a';
    await f.client.execute(
      "UPDATE mobility_accounts SET status='blocked' WHERE id='owner-a'",
    );
    let state = await f.snapshot();
    assert.equal(
      (await send({ action: 'invite_driver', fleetId: 'fleet-a' })).status,
      403,
    );
    assert.deepEqual(await f.snapshot(), state);
    await f.client.execute(
      "UPDATE mobility_accounts SET status='active' WHERE id='owner-a'",
    );
    await f.client.execute(
      "UPDATE mobility_employees SET fleet_id=NULL WHERE user_id='owner-a'",
    );
    state = await f.snapshot();
    assert.equal(
      (await send({ action: 'invite_driver', fleetId: 'fleet-a' })).status,
      403,
    );
    assert.deepEqual(await f.snapshot(), state);
  } finally {
    f.close();
  }
});
