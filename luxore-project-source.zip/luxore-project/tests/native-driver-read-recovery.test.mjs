import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import assert from 'node:assert/strict';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
const store = new Map([['luxore-account-v1', 'a'.repeat(64)]]);
globalThis.nativeViewStore = store;
globalThis.require = () => 1; // Metro resolves static PNG assets in real APKs.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    'expo-location',
    `export const Accuracy={High:4}; export const requestForegroundPermissionsAsync=async()=>({status:'denied'}),getCurrentPositionAsync=async()=>{throw new Error('GPS not enabled in view tests')};`,
  ],
  [
    'react-native',
    `
    export const View='View', Text='Text', Pressable='Pressable', ScrollView='ScrollView', Modal='Modal', Image='Image', TextInput='TextInput', KeyboardAvoidingView='KeyboardAvoidingView', ActivityIndicator='ActivityIndicator';
    export const Platform={OS:'android'}, StyleSheet={create:v=>v}, Keyboard={dismiss(){}}, Share={async share(){}}, Linking={async openURL(){},async openSettings(){}}, Alert={alert(){}};
    export const AppState={currentState:'active',addEventListener(){return {remove(){}}}}, BackHandler={addEventListener(){return {remove(){}}}};
    export const useWindowDimensions=()=>({width:390,height:844});
    export const PanResponder={create:handlers=>({panHandlers:handlers})};
    export const Animated={Value:class {constructor(v){this.value=v}setValue(v){this.value=v}},View:'AnimatedView',spring:(v,o)=>({start:()=>v.setValue(o.toValue)})};
  `,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaProvider='SafeAreaProvider', SafeAreaView='SafeAreaView';`,
  ],
  ['expo-status-bar', `export const StatusBar='StatusBar';`],
  ['expo-constants', `export default {expoConfig:{extra:{variant:'driver'}}};`],
  [
    'expo-secure-store',
    `export const getItemAsync=async k=>globalThis.nativeViewStore.get(k)||null,setItemAsync=async(k,v)=>{globalThis.nativeViewStore.set(k,v)},deleteItemAsync=async k=>{globalThis.nativeViewStore.delete(k)};`,
  ],
  [
    'expo-crypto',
    `export const randomUUID=()=> 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';`,
  ],
  [
    'expo-notifications',
    `export const getLastNotificationResponse=()=>null,clearLastNotificationResponse=()=>{},addNotificationResponseReceivedListener=()=>({remove(){}});`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',ArrowRight='ArrowRight', CalendarDays='CalendarDays', CarFront='CarFront', Check='Check', ChevronRight='ChevronRight', CircleHelp='CircleHelp', Home='Home', LogOut='LogOut', Mail='Mail', MapPinned='MapPinned', MapPin='MapPin', Clock3='Clock3', Settings='Settings', ShieldCheck='ShieldCheck', UserRound='UserRound', Users='Users',ChevronDown='ChevronDown',LocateFixed='LocateFixed',Navigation='Navigation',Phone='Phone',RefreshCw='RefreshCw',X='X',Plus='Plus',Minus='Minus',Search='Search';`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    let source = mocked.get(specifier);
    if (specifier.endsWith('/RideWorkspace') || specifier === './RideWorkspace')
      source = `export default function ForbiddenEmbeddedDriver(){throw new Error('Driver mounted a WebView');}`;
    if (specifier === './use-driver-gps')
      source = `import {useSyncExternalStore} from 'react';export function useDriverGps(){return useSyncExternalStore(f=>{globalThis.driverReads.listeners.add(f);return ()=>globalThis.driverReads.listeners.delete(f)},()=>globalThis.driverReads.gps)}`;
    if (specifier === './location-service')
      source = `export const resumeLocation=async()=>({active:false}),stopLocation=async()=>{globalThis.driverReads.stops++},foregroundPermission=async()=>{},startLocation=async()=>({active:true});`;
    if (specifier === './DriverMap')
      source = `import React from 'react';export default props=>React.createElement('MapProbe',props);`;
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
  load(url, context, next) {
    if (
      url.endsWith('/mobile/src/DriverScreen.tsx') &&
      process.env.TEST_ORIGINAL_DRIVER_READS
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_DRIVER_READS, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
              jsx: ts.JsxEmit.ReactJSX,
            },
          },
        ).outputText,
      };
    return next(url, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: DriverScreen } =
  await import('../mobile/src/DriverScreen.tsx');
const account = {
  id: 'driver-a',
  name: 'Synthetic Driver',
  email: 'driver@example.test',
  phone: '000',
  kind: 'driver',
};
const route = {
  pickup: { id: 'p', label: 'Abholung', lat: 50.11, lng: 8.68 },
  destination: { id: 'd', label: 'Ziel', lat: 50.12, lng: 8.69 },
  distanceMeters: 1500,
  durationSeconds: 300,
  geometry: {
    type: 'LineString',
    coordinates: [
      [8.68, 50.11],
      [8.69, 50.12],
    ],
  },
};
const snapshot = (name = 'Synthetic Audi', status) => ({
  driver: {
    id: 'driver-a',
    name: 'Synthetic',
    approved: 1,
    online: 0,
    session_id: null,
    vehicle: name,
    plate: 'TEST',
    vehicle_id: 'car',
  },
  offers: [],
  bookings: status
    ? [
        {
          id: 'ride-a',
          status,
          route,
          price: 1500,
          preferences: {},
          refreshments: null,
        },
      ]
    : [],
  payments: [],
  vehicles: [],
  today: { gross: 0, trips: 0, collected: 0, outstanding: 0 },
});
const text = (r) => JSON.stringify(r.toJSON());
async function settle() {
  for (let i = 0; i < 3; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
async function fixture(setup = () => {}) {
  const old = globalThis.fetch;
  const f = {
    data: snapshot(),
    calls: [],
    pending: [],
    listeners: new Set(),
    stops: 0,
    props: {
      token: 'a'.repeat(64),
      profile: account,
      active: true,
      settings: false,
      onFleet() {},
      onInventory() {},
    },
    r: null,
  };
  f.gps = {
    position: { lat: 50.11, lng: 8.68, accuracy: 8, timestamp: Date.now() },
    sessionId: null,
    error: '',
    foreground: true,
    restart: async () => {},
    sync: async () => ({ active: false }),
  };
  globalThis.driverReads = f;
  f.reply = (req) =>
    Response.json(
      req.path === 'driver'
        ? f.data
        : req.path === 'config'
          ? { publicMapToken: 'pk.synthetic-current' }
          : req.path === 'guidance'
            ? { bookingId: 'ride-a', phase: f.data.bookings[0]?.status, route }
            : { ok: true },
    );
  f.handle = (req) => f.reply(req);
  f.defer = (req) => {
    let resolve;
    const promise = new Promise((r) => {
      resolve = r;
    });
    const d = {
      req,
      promise,
      resolve: (value) =>
        resolve(value instanceof Response ? value : Response.json(value)),
    };
    f.pending.push(d);
    return d;
  };
  setup(f);
  globalThis.fetch = async (url, options) => {
    const req = {
      path: new URL(url).pathname.split('/').at(-1),
      method: options.method,
      signal: options.signal,
      token: options.headers.Authorization,
      body: options.body ? JSON.parse(options.body) : null,
    };
    f.calls.push(req);
    return f.handle(req);
  };
  await act(async () => {
    f.r = Renderer.create(React.createElement(DriverScreen, f.props));
  });
  await settle();
  f.foreground = async (value) => {
    await act(async () => {
      f.gps = { ...f.gps, foreground: value };
      f.listeners.forEach((fn) => fn());
    });
    await settle();
  };
  f.render = async (patch) => {
    f.props = { ...f.props, ...patch };
    await act(async () =>
      f.r.update(React.createElement(DriverScreen, f.props)),
    );
    await settle();
  };
  f.button = (label, scope = f.r.root) =>
    scope
      .findAllByType('Pressable')
      .find((n) =>
        n.findAllByType('Text').some((t) => t.props.children === label),
      );
  f.refresh = async () => {
    await act(async () => f.button('HEUTE').props.onPress());
    const modal = f.r.root.findAllByType('Modal').find((n) => n.props.visible);
    await act(async () => {
      f.button('Aktualisieren', modal).props.onPress();
    });
    await settle();
  };
  f.map = () => f.r.root.findByType('MapProbe').props;
  f.close = async () => {
    await act(async () => f.r.unmount());
    for (const p of f.pending) p.resolve({});
    await settle();
    globalThis.fetch = old;
  };
  return f;
}
void test('background aborts actual driver/config reads and foreground starts fresh without waiting', async () => {
  const f = await fixture((f) => {
    f.handle = (req) =>
      ['driver', 'config'].includes(req.path)
        ? f.defer(req).promise
        : f.reply(req);
  });
  try {
    const old = f.calls.slice();
    assert.equal(old.length, 2);
    await f.foreground(false);
    assert.ok(old.every((r) => r.signal.aborted));
    assert.equal(f.stops, 0);
    f.handle = (req) => f.reply(req);
    await f.foreground(true);
    assert.equal(f.calls.filter((r) => r.path === 'driver').length, 2);
    assert.match(text(f.r), /Synthetic Audi/);
    await act(async () => {
      f.pending
        .find((p) => p.req.path === 'driver')
        .resolve(snapshot('OLD CAR'));
      f.pending
        .find((p) => p.req.path === 'config')
        .resolve({ publicMapToken: 'pk.old' });
    });
    await settle();
    assert.doesNotMatch(text(f.r), /OLD CAR/);
    assert.equal(f.map().token, 'pk.synthetic-current');
  } finally {
    await f.close();
  }
});
void test('hidden driver page performs no reads until visible again and keeps native tracking separate', async () => {
  const f = await fixture((f) => {
    f.handle = (req) => f.defer(req).promise;
  });
  try {
    const old = f.calls.slice();
    await f.render({ active: false });
    assert.ok(old.every((r) => r.signal.aborted));
    const count = f.calls.length;
    await f.foreground(false);
    await f.foreground(true);
    assert.equal(f.calls.length, count);
    assert.equal(f.stops, 0);
    f.handle = (req) => f.reply(req);
    await f.render({ active: true });
    assert.equal(f.calls.filter((r) => r.path === 'driver').length, 2);
  } finally {
    await f.close();
  }
});
void test('an old driver completion cannot release the newer pending read for overlapping polls', async (t) => {
  t.mock.timers.enable({ apis: ['setInterval'] });
  const f = await fixture((f) => {
    f.handle = (req) =>
      req.path === 'driver' ? f.defer(req).promise : f.reply(req);
  });
  try {
    await f.foreground(false);
    await f.foreground(true);
    assert.equal(f.pending.length, 2);
    await act(async () => f.pending[0].resolve(snapshot('OLD CAR')));
    await settle();
    await act(async () => t.mock.timers.tick(5000));
    await settle();
    assert.equal(f.pending.length, 2);
    await act(async () => f.pending[1].resolve(snapshot('CURRENT CAR')));
    await settle();
    assert.match(text(f.r), /CURRENT CAR/);
    assert.doesNotMatch(text(f.r), /OLD CAR/);
  } finally {
    await f.close();
  }
});
void test('phase change aborts preceding guidance and immediately requests the new riding route', async () => {
  const f = await fixture((f) => {
    f.data = snapshot('Synthetic Audi', 'accepted');
    f.handle = (req) =>
      req.path === 'guidance' ? f.defer(req).promise : f.reply(req);
  });
  try {
    assert.equal(f.pending.length, 1);
    const old = f.pending[0];
    f.data = snapshot('Synthetic Audi', 'riding');
    await f.refresh();
    assert.ok(old.req.signal.aborted);
    assert.equal(f.pending.length, 2);
    const newer = {
      ...route,
      pickup: { ...route.pickup, label: 'Neue Anfahrt' },
    };
    await act(async () =>
      f.pending[1].resolve({
        bookingId: 'ride-a',
        phase: 'riding',
        route: newer,
      }),
    );
    await settle();
    assert.equal(f.map().route.pickup.label, 'Neue Anfahrt');
    await act(async () =>
      old.resolve({ bookingId: 'ride-a', phase: 'accepted', route }),
    );
    await settle();
    assert.equal(f.map().route.pickup.label, 'Neue Anfahrt');
  } finally {
    await f.close();
  }
});
void test('guidance after foreground return is not blocked by a preceding request or cooldown', async () => {
  const f = await fixture((f) => {
    f.data = snapshot('Synthetic Audi', 'accepted');
    f.handle = (req) =>
      req.path === 'guidance' ? f.defer(req).promise : f.reply(req);
  });
  try {
    const old = f.pending[0];
    await f.foreground(false);
    assert.ok(old.req.signal.aborted);
    await f.foreground(true);
    assert.equal(f.pending.length, 2);
    assert.equal(f.stops, 0);
  } finally {
    await f.close();
  }
});
void test('confirmed trip write survives background and reads wait until return', async () => {
  const f = await fixture((f) => {
    f.data = snapshot('Synthetic Audi', 'accepted');
    f.handle = (req) =>
      req.path === 'driver' && req.method === 'POST'
        ? f.defer(req).promise
        : f.reply(req);
  });
  try {
    const swipe = f.r.root
      .findAll((n) => n.type?.name === 'SwipeAction')
      .find((n) => String(n.props.label).includes('angekommen'));
    assert.ok(swipe);
    await act(async () => {
      swipe
        .findAllByType('View')
        .find((n) => n.props.onLayout)
        .props.onLayout({ nativeEvent: { layout: { width: 330 } } });
    });
    await act(async () => {
      swipe
        .findByType('AnimatedView')
        .props.onPanResponderRelease({}, { dx: 260 });
    });
    await settle();
    const write = f.pending[0];
    assert.equal(write.req.path, 'driver');
    await f.foreground(false);
    assert.equal(write.req.signal.aborted, false);
    const count = f.calls.filter(
      (r) => r.path === 'driver' && r.method === 'GET',
    ).length;
    f.data = snapshot('Synthetic Audi', 'arrived');
    await act(async () => write.resolve({ ok: true }));
    await settle();
    assert.equal(write.req.signal.aborted, false);
    assert.equal(
      f.calls.filter((r) => r.path === 'driver' && r.method === 'GET').length,
      count,
    );
    await f.foreground(true);
    assert.equal(
      f.calls.filter((r) => r.path === 'driver' && r.method === 'GET').length,
      count + 1,
    );
    assert.equal(f.stops, 0);
  } finally {
    await f.close();
  }
});
void test('account change aborts preceding reads and cannot carry the former cockpit into the new token', async () => {
  const f = await fixture((f) => {
    f.handle = (req) =>
      req.path === 'driver' ? f.defer(req).promise : f.reply(req);
  });
  try {
    const old = f.pending[0];
    f.handle = (req) => f.reply(req);
    f.data = snapshot('NEW ACCOUNT CAR');
    await f.render({
      token: 'b'.repeat(64),
      profile: { ...account, id: 'driver-b' },
    });
    assert.ok(old.req.signal.aborted);
    await act(async () => old.resolve(snapshot('PRIVATE OLD CAR')));
    await settle();
    assert.match(text(f.r), /NEW ACCOUNT CAR/);
    assert.doesNotMatch(text(f.r), /PRIVATE OLD CAR/);
    assert.equal(
      f.calls.filter((r) => r.path === 'driver').at(-1).token,
      'Bearer ' + 'b'.repeat(64),
    );
  } finally {
    await f.close();
  }
});
void test('current authorization loss removes previous trip and map data without stopping the native shift', async () => {
  for (const status of [401, 403]) {
    const f = await fixture((f) => {
      f.data = snapshot('CONFIDENTIAL CAR', 'riding');
    });
    try {
      f.handle = (req) =>
        req.path === 'driver'
          ? Response.json({ error: 'Kein Zugriff' }, { status })
          : f.reply(req);
      await f.refresh();
      assert.doesNotMatch(text(f.r), /CONFIDENTIAL CAR/);
      assert.equal(f.map().token, '');
      assert.equal(f.map().route, null);
      assert.equal(f.stops, 0);
    } finally {
      await f.close();
    }
  }
});
