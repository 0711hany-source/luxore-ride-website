import './support/tsx-loader.mjs';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
const { VehicleCreateForm } = await import('../app/mobility/vehicle-form.tsx');
const base = {
  fleetId: 'fleet-test',
  model: 'Mercedes-Benz E-Klasse',
  plate: 'F TEST 711',
  setModel: () => {},
  setPlate: () => {},
  services: ['premium'],
  setServices: () => {},
  busy: false,
  error: '',
  onSave: () => {},
};
function render(overrides = {}) {
  return renderToStaticMarkup(
    createElement(VehicleCreateForm, { ...base, ...overrides }),
  );
}
function submit(html) {
  return html.match(/<button\b[^>]*type="submit"[^>]*>/g) || [];
}
void test('vehicle form renders exactly one real submit control, enabled for a selected class', () => {
  const html = render(),
    buttons = submit(html);
  assert.equal(buttons.length, 1);
  assert.doesNotMatch(buttons[0], /\sdisabled(?:=|\s|>)/);
  assert.match(html, /Fahrzeug hinzufügen/);
  assert.match(html, /id="model-fleet-test"[^>]*required/);
  assert.match(html, /id="plate-fleet-test"[^>]*required/);
});
void test('pending save is locked while missing classes have visible feedback instead of a dead button', () => {
  const pending = render({ busy: true });
  assert.match(submit(pending)[0], /\sdisabled(?:=|\s|>)/);
  assert.match(pending, /Wird gespeichert/);
  const empty = render({ services: [] });
  assert.doesNotMatch(submit(empty)[0], /\sdisabled(?:=|\s|>)/);
  assert.match(empty, /mindestens eine Fahrzeugklasse/);
});
void test('server errors remain visible and entered vehicle details are retained', () => {
  const html = render({
    error: 'Dieses Kennzeichen ist bereits aktiv angelegt.',
  });
  assert.match(html, /role="alert"/);
  assert.match(html, /Dieses Kennzeichen ist bereits aktiv angelegt/);
  assert.match(html, /value="F TEST 711"/);
  assert.match(html, /value="Mercedes-Benz E-Klasse"/);
});

void test('mobile save uses explicit field validation and edit mode retains the same submit path', () => {
  const html = render({ editing: true, onCancel: () => {} });
  assert.match(html, /novalidate/i);
  assert.match(html, /Änderungen speichern/);
  assert.match(html, /type="button"[^>]*>Abbrechen/);
  assert.equal(submit(html).length, 1);
});

void test('conflicting changes retain the draft and offer an explicit reload without submitting', () => {
  const html = render({
    editing: true,
    error: 'Das Fahrzeug wurde zwischenzeitlich geändert.',
    onReload: () => {},
  });
  assert.match(html, /value="Mercedes-Benz E-Klasse"/);
  assert.match(html, /ungespeicherten Eingaben/);
  assert.match(html, /type="button"[^>]*>Aktuelle Daten laden/);
  assert.equal(submit(html).length, 1);
  const pending = render({
    editing: true,
    error: 'Konflikt',
    onReload: () => {},
    busy: true,
    loadingLatest: true,
  });
  assert.match(pending, /Daten werden geladen/);
  assert.match(pending, /<button[^>]*disabled[^>]*>Aktuelle Daten laden/);
});
