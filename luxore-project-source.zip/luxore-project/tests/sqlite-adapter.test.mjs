import './support/tsx-loader.mjs';
import { createClient } from '@libsql/client';
import test from 'node:test';
import assert from 'node:assert/strict';
import { sqliteDatabase, runtimeDatabase, DatabaseUnavailable, databaseConfigured } from '../db/sqlite.ts';
test('SQLite adapter keeps placeholders, return rows and change counts used by fleet saving', async () => {
  const client=createClient({url:':memory:',intMode:'number'}),db=sqliteDatabase(client);
  try {
    await client.execute('CREATE TABLE vehicles(id TEXT PRIMARY KEY,price INTEGER NOT NULL)');
    const r=await db.prepare('INSERT INTO vehicles VALUES(?,?) RETURNING id').bind("quoted'plate",1500).run();
    assert.equal(r.meta.changes,1);assert.equal(r.results[0].id,"quoted'plate");
    assert.equal(await db.prepare('SELECT price FROM vehicles').first('price'),1500);
    assert.equal(await db.prepare('SELECT id FROM vehicles WHERE id=?').bind('absent').first(),null);
  } finally {client.close();}
});
test('SQLite batch is atomic on constraint failures and bindings are immutable', async () => {
  const client=createClient({url:':memory:'}),db=sqliteDatabase(client);
  try {
    await client.execute('CREATE TABLE stock(id TEXT PRIMARY KEY,n INTEGER CHECK(n>=0))');
    const query=db.prepare('INSERT INTO stock VALUES(?,?)');
    const first=query.bind('one',1),second=query.bind('two',2);
    await db.batch([first,second]);
    await assert.rejects(db.batch([db.prepare('UPDATE stock SET n=0 WHERE id=?').bind('one'),query.bind('bad',-1)]));
    assert.equal(await db.prepare('SELECT n FROM stock WHERE id=?').bind('one').first('n'),1);
    assert.equal((await db.prepare('SELECT * FROM stock').all()).results.length,2);
    await assert.rejects(db.batch([sqliteDatabase(client).prepare('SELECT 1')]));
  } finally {client.close();}
});
test('missing persistent database fails closed instead of writing ephemeral production data',()=>{
  const url=process.env.DATABASE_URL,host=process.env.VERCEL;
  try {
    delete process.env.DATABASE_URL;assert.throws(runtimeDatabase,DatabaseUnavailable);
    process.env.DATABASE_URL='file:temporary.db';process.env.VERCEL='1';assert.throws(runtimeDatabase,DatabaseUnavailable);
  } finally {
    if(url===undefined)delete process.env.DATABASE_URL;else process.env.DATABASE_URL=url;
    if(host===undefined)delete process.env.VERCEL;else process.env.VERCEL=host;
  }
});

test('production booking activation requires a deliberate flag after data migration',()=>{
 const values={DATABASE_URL:process.env.DATABASE_URL,NODE_ENV:process.env.NODE_ENV,LUXORE_BOOKING_ENABLED:process.env.LUXORE_BOOKING_ENABLED};
 try{process.env.DATABASE_URL='libsql://synthetic.invalid';process.env.NODE_ENV='production';delete process.env.LUXORE_BOOKING_ENABLED;assert.equal(databaseConfigured(),false);process.env.LUXORE_BOOKING_ENABLED='true';assert.equal(databaseConfigured(),true);}
 finally{for(const[k,v]of Object.entries(values)){if(v===undefined)delete process.env[k];else process.env[k]=v;}}
});
