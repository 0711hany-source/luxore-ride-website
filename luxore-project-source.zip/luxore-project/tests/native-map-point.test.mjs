import './support/tsx-loader.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import { MapPointController } from '../mobile/src/map-point.ts';
const point = {
  id: 'stored-pin',
  label: 'Gewählter Punkt',
  lat: 50.11,
  lng: 8.68,
};
const token = 'pk.' + 'x'.repeat(30);
const tick = () => new Promise((r) => setImmediate(r));
function fixture(overrides = {}) {
  const calls = [];
  const api = {
    config: async () => ({ publicMapToken: token }),
    confirm: async (center) => {
      calls.push(center);
      return { results: [{ ...point, lat: center.lat, lng: center.lng }] };
    },
    ...overrides,
  };
  const controller = new MapPointController(api);
  return { controller, calls };
}
async function chosen(controller) {
  controller.setActive(true);
  await tick();
  controller.ready();
  controller.idle({ ...point, zoom: 16 });
}
test('Europe overview, unready tiles and moving camera cannot persist a point; idle street view can', async () => {
  const { controller: c, calls } = fixture();
  c.setActive(true);
  await tick();
  c.idle({ ...point, zoom: 16 });
  await c.confirm();
  assert.equal(calls.length, 0);
  c.ready();
  c.idle({ ...point, zoom: 4 });
  await c.confirm();
  assert.equal(calls.length, 0);
  c.idle({ ...point, zoom: 16 });
  c.moving();
  await c.confirm();
  assert.equal(calls.length, 0);
  c.idle({ ...point, zoom: 16 });
  await c.confirm();
  assert.equal(calls.length, 1);
  assert.equal(c.getSnapshot().confirmed.id, point.id);
});
test('panning never geocodes; confirmation writes exactly the current center once', async () => {
  let release;
  const { controller: c, calls } = fixture({
    confirm: (center) => {
      calls.push(center);
      return new Promise((r) => {
        release = r;
      });
    },
  });
  await chosen(c);
  for (let i = 0; i < 20; i++) {
    c.moving();
    c.idle({ ...point, lng: 8.68 + i / 1000, zoom: 16 });
  }
  assert.equal(calls.length, 0);
  const pending = c.confirm();
  await c.confirm();
  c.idle({ ...point, lng: 9, zoom: 16 });
  assert.equal(calls.length, 1);
  assert.equal(calls[0].lng, 8.699);
  release({ results: [{ ...point, lng: 8.699 }] });
  await pending;
  assert.equal(c.getSnapshot().confirmed.lng, 8.699);
});
test('confirmation survives background and read restart without a second write', async () => {
  let release;
  const { controller: c, calls } = fixture({
    confirm: (center) => {
      calls.push(center);
      return new Promise((r) => (release = r));
    },
  });
  await chosen(c);
  const pending = c.confirm();
  c.setActive(false);
  release({ results: [point] });
  await pending;
  assert.equal(c.getSnapshot().confirmed.id, point.id);
  c.setActive(true);
  await c.confirm();
  assert.equal(calls.length, 1);
});
test('old aborted config response cannot overwrite a newer resume or clear its loading state', async () => {
  const reads = [];
  const { controller: c } = fixture({
    config: (signal) =>
      new Promise((resolve) => reads.push({ signal, resolve })),
  });
  c.setActive(true);
  c.setActive(false);
  c.setActive(true);
  assert.equal(reads[0].signal.aborted, true);
  reads[0].resolve({ publicMapToken: token });
  await tick();
  assert.equal(c.getSnapshot().token, '');
  assert.equal(c.getSnapshot().loading, true);
  reads[1].resolve({ publicMapToken: token + 'new' });
  await tick();
  assert.equal(c.getSnapshot().token, token + 'new');
});
test('failed map config visibly recovers on retry; center survives background', async () => {
  let n = 0;
  const { controller: c } = fixture({
    config: async () => {
      if (++n === 1) throw Error('offline');
      return { publicMapToken: token };
    },
  });
  c.setActive(true);
  await tick();
  assert.equal(c.getSnapshot().loading, false);
  assert.equal(c.getSnapshot().error, 'offline');
  await c.load();
  c.ready();
  c.idle({ ...point, zoom: 17 });
  c.setActive(false);
  c.setActive(true);
  await tick();
  assert.equal(c.getSnapshot().center.zoom, 17);
  assert.equal(c.getSnapshot().ready, false);
});
test('invalid coordinates and unconfirmed or shifted server responses never become booking places', async () => {
  const { controller: c } = fixture({
    confirm: async () => ({ results: [{ ...point, lng: 9 }] }),
  });
  await chosen(c);
  c.idle({ ...point, lat: NaN, zoom: 16 });
  assert.equal(c.getSnapshot().center.lat, point.lat);
  await c.confirm();
  assert.equal(c.getSnapshot().confirmed, null);
  assert.match(c.getSnapshot().error, /nicht bestätigt/);
  assert.equal(c.getSnapshot().saving, false);
});
test('failed persistence keeps candidate and offers an explicit retry', async () => {
  let n = 0;
  const { controller: c } = fixture({
    confirm: async () => {
      if (++n === 1) throw Error('offline');
      return { results: [point] };
    },
  });
  await chosen(c);
  await c.confirm();
  assert.equal(c.canConfirm(), true);
  await c.confirm();
  assert.equal(c.getSnapshot().confirmed.id, point.id);
});
