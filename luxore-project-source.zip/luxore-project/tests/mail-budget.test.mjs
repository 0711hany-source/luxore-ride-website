import './support/tsx-loader.mjs';
import { createClient } from '@libsql/client';
import { sqliteDatabase } from '../db/sqlite.ts';
import {
  reserveMailBudget,
  mailBudgetStatus,
} from '../lib/mobility/mail-budget.ts';
import test from 'node:test';
import assert from 'node:assert/strict';
const now = Date.UTC(2026, 9, 7, 12);
const dayKey = `account-mail:${Math.floor(now / 86400000)}`;
const monthKey = 'account-mail-month:2026-10';
async function fixture(day = 0, month = 0) {
  const client = createClient({ url: 'file::memory:' });
  await client.execute(
    'CREATE TABLE mobility_limits(key TEXT PRIMARY KEY,count INTEGER NOT NULL)',
  );
  await client.batch(
    [
      { sql: 'INSERT INTO mobility_limits VALUES(?,?)', args: [dayKey, day] },
      {
        sql: 'INSERT INTO mobility_limits VALUES(?,?)',
        args: [monthKey, month],
      },
    ],
    'write',
  );
  return { client, db: sqliteDatabase(client) };
}
test('parallel last-slot requests reserve exactly one day/month allowance', async () => {
  const f = await fixture(89, 2799);
  try {
    const attempts = await Promise.all(
      Array.from({ length: 12 }, () => reserveMailBudget(f.db, now)),
    );
    assert.equal(attempts.filter(Boolean).length, 1);
    assert.deepEqual(await mailBudgetStatus(f.db, now), {
      dayLimit: 90,
      monthLimit: 2800,
      dayRemaining: 0,
      monthRemaining: 0,
      available: false,
    });
  } finally {
    f.client.close();
  }
});
test('exhausted monthly or daily allowance never consumes the other allowance', async () => {
  for (const [day, month] of [
    [15, 2800],
    [90, 37],
  ]) {
    const f = await fixture(day, month);
    try {
      assert.equal(await reserveMailBudget(f.db, now), false);
      const rows = await f.client.execute(
        'SELECT count FROM mobility_limits ORDER BY key',
      );
      assert.deepEqual(
        rows.rows.map((r) => r.count),
        [month, day],
      );
    } finally {
      f.client.close();
    }
  }
});
test('second counter failure rolls back the first reservation', async () => {
  const f = await fixture(10, 20);
  try {
    await f.client.execute(
      `CREATE TRIGGER fail_month BEFORE UPDATE ON mobility_limits WHEN NEW.key='${monthKey}' BEGIN SELECT RAISE(ABORT,'synthetic failure'); END`,
    );
    await assert.rejects(reserveMailBudget(f.db, now), /synthetic failure/);
    const state = await mailBudgetStatus(f.db, now);
    assert.equal(state.dayRemaining, 80);
    assert.equal(state.monthRemaining, 2780);
  } finally {
    f.client.close();
  }
});
test('UTC period rollover restores only the new period and leaves historical counters unchanged', async () => {
  const f = await fixture(90, 2800);
  try {
    const nextDay = now + 86400000;
    assert.equal((await mailBudgetStatus(f.db, nextDay)).dayRemaining, 90);
    assert.equal(await reserveMailBudget(f.db, nextDay), false);
    const nextMonth = Date.UTC(2026, 10, 1);
    assert.equal(await reserveMailBudget(f.db, nextMonth), true);
    assert.equal((await mailBudgetStatus(f.db, nextMonth)).dayRemaining, 89);
    assert.equal(
      (await mailBudgetStatus(f.db, nextMonth)).monthRemaining,
      2799,
    );
    assert.equal((await mailBudgetStatus(f.db, now)).monthRemaining, 0);
  } finally {
    f.client.close();
  }
});
