import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { createClient } from '@libsql/client';
import { readFileSync, readdirSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  resolve(s, c, next) {
    if (s === '#stop-adapter')
      return {
        url: new URL('../db/sqlite.ts?stop-adapter', import.meta.url).href,
        shortCircuit: true,
      };
    return next(s, c);
  },
  load(url, c, next) {
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `export class ApiError extends Error {constructor(status,message){super(message);this.status=status}};export const db=()=>globalThis.stopTest.db,tokenHash=async token=>token,limit=async()=>{},body=r=>r.json(),json=(v,status=200)=>Response.json(v,{status}),handled=async fn=>{try{return await fn()}catch(e){return json({error:e.message},e.status||500)}};`,
      };
    if (
      url.endsWith('/app/api/mobility/location/route.ts') &&
      process.env.TEST_ORIGINAL_NATIVE_STOP
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_NATIVE_STOP, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
const { sqliteDatabase } = await import('#stop-adapter');
const { POST } = await import('../app/api/mobility/location/route.ts');
const token = 'a'.repeat(64),
  nextToken = 'b'.repeat(64);
const send = (value = token) =>
  POST(
    new Request('https://test.invalid/api/mobility/location', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + value },
      body: JSON.stringify({ action: 'stop' }),
    }),
  );
async function fixture() {
  const client = createClient({ url: ':memory:' }),
    db = sqliteDatabase(client);
  for (const f of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((n) => n.endsWith('.sql'))
    .sort())
    await client.executeMultiple(
      readFileSync(new URL('../drizzle/' + f, import.meta.url), 'utf8'),
    );
  const now = Date.now();
  await client.executeMultiple(`INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES('fleet','Synthetic Fleet','owner',0);
 INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('driver','Synthetic Driver','000','fleet','driver',0);
 INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('car','fleet','Synthetic Audi','TEST','["premium"]','active',0);
 INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,services,approved,online,session_id,vehicle_id,lat,lng,accuracy,location_at) VALUES('driver','Synthetic Driver','000','Synthetic Audi','TEST','premium','["premium"]',1,1,'old','car',50.11,8.68,8,${now});
 INSERT INTO mobility_location_sessions(token_hash,driver_id,session_id,expires_at) VALUES('${token}','driver','old',${now + 3600000});
 INSERT INTO mobility_bookings(id,quote_id,owner_id,mode,service,status,route,price,payment_status,created_at,updated_at,dispatch_at) VALUES('booking','quote','customer','now','premium','requesting','{"pickup":{"lat":50.11,"lng":8.68}}',1000,'unpaid',${now},${now},${now});
 INSERT INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at) VALUES('offer','booking','driver','pending',${now + 25000},${now});`);
  globalThis.stopTest = { db };
  const snapshot = async () =>
    Object.fromEntries(
      await Promise.all(
        [
          'mobility_drivers',
          'mobility_location_sessions',
          'mobility_offers',
          'mobility_bookings',
          'mobility_employees',
          'mobility_vehicles',
        ].map(async (table) => [
          table,
          (await db.prepare('SELECT * FROM ' + table + ' ORDER BY 1').all())
            .results,
        ]),
      ),
    );
  const race = (work) => {
    const prepare = db.prepare;
    let fired = false;
    db.prepare = (sql) => {
      const stmt = prepare(sql);
      if (!sql.includes('SELECT s.driver_id,s.session_id')) return stmt;
      const bind = stmt.bind.bind(stmt);
      stmt.bind = (...args) => {
        const bound = bind(...args),
          first = bound.first.bind(bound);
        bound.first = async (...params) => {
          const row = await first(...params);
          if (!fired) {
            fired = true;
            await work();
          }
          return row;
        };
        return bound;
      };
      return stmt;
    };
  };
  return { client, db, snapshot, race, close: () => client.close() };
}
void test('actual native stop confirms committed offline/capability/offer changes and cannot replay a revoked token', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    const r = await send();
    assert.equal(r.status, 200);
    assert.deepEqual(await r.json(), { ok: true });
    const after = await f.snapshot();
    assert.equal(after.mobility_drivers[0].online, 0);
    assert.equal(after.mobility_drivers[0].session_id, null);
    assert.equal(after.mobility_drivers[0].approved, 1);
    assert.equal(after.mobility_drivers[0].vehicle_id, 'car');
    assert.equal(after.mobility_drivers[0].lat, 50.11);
    assert.equal(after.mobility_location_sessions.length, 0);
    assert.equal(after.mobility_offers[0].status, 'rejected');
    assert.deepEqual(after.mobility_employees, before.mobility_employees);
    assert.deepEqual(after.mobility_vehicles, before.mobility_vehicles);
    assert.deepEqual(after.mobility_bookings, before.mobility_bookings);
    assert.equal((await send()).status, 401);
    assert.deepEqual(await f.snapshot(), after);
  } finally {
    f.close();
  }
});
for (const [name, sql] of [
  [
    'token renewal for the same session',
    `UPDATE mobility_location_sessions SET token_hash='${nextToken}' WHERE token_hash='${token}'`,
  ],
  [
    'replacement shift before its first GPS upload',
    `UPDATE mobility_drivers SET session_id='new',online=0 WHERE id='driver';DELETE FROM mobility_location_sessions;INSERT INTO mobility_location_sessions(token_hash,driver_id,session_id,expires_at) VALUES('${nextToken}','driver','new',${Date.now() + 3600000})`,
  ],
  [
    'revoked driver approval',
    "UPDATE mobility_drivers SET approved=0 WHERE id='driver'",
  ],
  [
    'inactive vehicle',
    "UPDATE mobility_vehicles SET status='inactive' WHERE id='car'",
  ],
  ['expired capability', 'UPDATE mobility_location_sessions SET expires_at=0'],
])
  void test(
    'actual stop rechecks ' +
      name +
      ' within the write transaction without mutating the new state',
    async () => {
      const f = await fixture();
      let expected;
      try {
        f.race(async () => {
          await f.client.executeMultiple(sql);
          expected = await f.snapshot();
        });
        const r = await send();
        assert.ok(expected);
        assert.equal(r.status, 401);
        assert.deepEqual(await f.snapshot(), expected);
      } finally {
        f.close();
      }
    },
  );
for (const [name, sql] of [
  [
    'driver update',
    "CREATE TRIGGER fail_stop BEFORE UPDATE ON mobility_drivers BEGIN SELECT RAISE(ABORT,'Synthetic driver failure'); END",
  ],
  [
    'capability deletion',
    "CREATE TRIGGER fail_stop BEFORE DELETE ON mobility_location_sessions BEGIN SELECT RAISE(ABORT,'Synthetic capability failure'); END",
  ],
  [
    'offer withdrawal',
    "CREATE TRIGGER fail_stop BEFORE UPDATE ON mobility_offers BEGIN SELECT RAISE(ABORT,'Synthetic offer failure'); END",
  ],
])
  void test(
    'actual libSQL ' +
      name +
      ' failure rolls back the whole stop and permits explicit retry',
    async () => {
      const f = await fixture();
      try {
        const before = await f.snapshot();
        await f.client.executeMultiple(sql);
        assert.equal((await send()).status, 500);
        assert.deepEqual(await f.snapshot(), before);
        await f.client.execute('DROP TRIGGER fail_stop');
        assert.equal((await send()).status, 200);
        assert.equal((await f.snapshot()).mobility_drivers[0].session_id, null);
      } finally {
        f.close();
      }
    },
  );
void test('actual post-commit dispatch failure cannot turn a committed native pause into an unconfirmed HTTP failure', async () => {
  const f = await fixture();
  try {
    await f.client.executeMultiple(
      "INSERT INTO mobility_limits(key,count) VALUES('0:synthetic',1);CREATE TRIGGER fail_dispatch BEFORE DELETE ON mobility_limits BEGIN SELECT RAISE(ABORT,'Synthetic dispatch failure'); END",
    );
    const r = await send();
    assert.equal(r.status, 200);
    assert.deepEqual(await r.json(), { ok: true });
    const after = await f.snapshot();
    assert.equal(after.mobility_drivers[0].online, 0);
    assert.equal(after.mobility_drivers[0].session_id, null);
    assert.equal(after.mobility_location_sessions.length, 0);
    assert.equal(after.mobility_offers[0].status, 'rejected');
    assert.equal((await send()).status, 401);
  } finally {
    f.close();
  }
});
void test('unknown native token never changes driver, capability, offers or trip', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    assert.equal((await send('c'.repeat(64))).status, 401);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
