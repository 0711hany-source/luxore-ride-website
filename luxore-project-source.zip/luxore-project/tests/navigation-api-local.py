"""Isolated local authorization fixtures; the only provider trace is public Mapbox example data."""
import os,json,urllib.request,urllib.error,http.cookiejar,sqlite3,pathlib,time
base=os.environ.get('TEST_BASE_URL','http://localhost:3000')
def client():return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def call(c,p,b,origin=base):
 req=urllib.request.Request(base+'/api/mobility/'+p,data=json.dumps(b).encode(),headers={'Content-Type':'application/json','Origin':origin})
 try:
  with c.open(req) as r:return r.status,json.loads(r.read())
 except urllib.error.HTTPError as e:
  raw=e.read()
  try: value=json.loads(raw)
  except ValueError: value=raw.decode()[:200]
  return e.code,value
c=client();assert call(c,'navigation',{})[0]==401
assert call(c,'session',{})[0]==201
with c.open(base+'/api/mobility/config') as r:uid=json.loads(r.read())['userId']
assert call(c,'navigation',{})[0]==403
connection=None
for file in pathlib.Path('.wrangler/state/v3/d1').rglob('*.sqlite'):
 db=sqlite3.connect(file)
 if db.execute("SELECT name FROM sqlite_master WHERE name='mobility_drivers'").fetchone():connection=db;break
 db.close()
assert connection
try:
 connection.execute("INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved) VALUES(?,'TEST navigation','0','TEST','TEST NAV','premium',1)",(uid,));connection.commit()
 assert call(c,'navigation',{})[0]==400
 assert call(c,'navigation',{},'https://attacker.invalid')[0]==403
 now=int(time.time()*1000)
 coords=[[-122.397484,37.792809],[-122.39746,37.792693],[-122.39745,37.792645],[-122.397437,37.792586]]
 points=[dict(lng=p[0],lat=p[1],accuracy=8,timestamp=now-(3-i)*5000) for i,p in enumerate(coords)]
 status,reply=call(c,'navigation',{'points':points});assert status==200,(status,reply)
 match=reply['match']
 if match:
  assert match['timestamp']==points[-1]['timestamp'] and len(match['coordinates'])>=2
  print('PASS: real Mapbox road matching returned validated road geometry.')
 else: print('Provider returned no unambiguous match; safe null fallback verified.')
 assert call(c,'navigation',{'points':[dict(p,timestamp=p['timestamp']-200000) for p in points]})[0]==400
 print('PASS: anonymous/unapproved driver and wrong origin rejected; input freshness checked; provider fallback handled.')
finally:
 connection.execute('DELETE FROM mobility_drivers WHERE id=?',(uid,));connection.execute('DELETE FROM mobility_sessions WHERE user_id=?',(uid,));connection.commit();connection.close()
