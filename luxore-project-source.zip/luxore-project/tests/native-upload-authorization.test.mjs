import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
const virtual = (source) => ({
  url: 'data:text/javascript,' + encodeURIComponent(source),
  shortCircuit: true,
});
registerHooks({
  resolve(s, c, next) {
    if (s === 'expo-location')
      return virtual(
        `export const Accuracy={High:4,BestForNavigation:6};export const requestForegroundPermissionsAsync=()=>globalThis.uploadAuthorization.permission(),getBackgroundPermissionsAsync=async()=>({granted:true}),requestBackgroundPermissionsAsync=async()=>({granted:true}),hasStartedLocationUpdatesAsync=async()=>globalThis.uploadAuthorization.started,startLocationUpdatesAsync=async()=>{globalThis.uploadAuthorization.starts++;globalThis.uploadAuthorization.started=true},stopLocationUpdatesAsync=async()=>{globalThis.uploadAuthorization.started=false},getCurrentPositionAsync=()=>new Promise(()=>{});`,
      );
    if (s === 'expo-task-manager')
      return virtual(
        `export const defineTask=(_name,callback)=>{globalThis.uploadTask=callback};`,
      );
    if (s === 'expo-secure-store')
      return virtual(
        `export const getItemAsync=k=>globalThis.uploadAuthorization.get(k),setItemAsync=(k,v)=>globalThis.uploadAuthorization.set(k,v),deleteItemAsync=async k=>globalThis.uploadAuthorization.store.delete(k);`,
      );
    if (s === 'react-native')
      return virtual(
        `export const Alert={alert(){throw Error('Unexpected permission dialog')}};`,
      );
    if (s === './offer-alerts')
      return virtual(
        `export const offerAlerts={clear:async()=>{},sync:async(...a)=>globalThis.uploadAuthorization.alerts.push(a)},alertStatus=async()=>({enabled:true,sound:true}),requestAlerts=async()=>({enabled:true,sound:true});`,
      );
    return next(s, c);
  },
  load(url, c, next) {
    if (
      url.endsWith('/mobile/src/location-service.ts') &&
      process.env.TEST_ORIGINAL_LOCATION_SERVICE
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_LOCATION_SERVICE, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
const service = await import('../mobile/src/location-service.ts');
const key = 'luxore-driver-location-session',
  positionKey = 'luxore-driver-background-position';
const credential = (token = 'a') => ({
  sessionId: 'shift',
  nativeToken: token.repeat(64),
  expiresAt: Date.now() + 3600000,
});
const fix = (timestamp = Date.now()) => ({
  coords: {
    latitude: 50.11,
    longitude: 8.68,
    accuracy: 8,
    speed: 0,
    heading: 0,
  },
  timestamp,
});
const defer = () => {
  let resolve;
  const promise = new Promise((r) => {
    resolve = r;
  });
  return { promise, resolve };
};
const flush = async () => {
  for (let i = 0; i < 8; i++) await new Promise((r) => setImmediate(r));
};
const originalFetch = globalThis.fetch;
function fixture() {
  const f = {
    store: new Map(),
    started: false,
    starts: 0,
    writes: [],
    cacheWrites: [],
    alerts: [],
    permission: async () => ({ granted: true }),
  };
  f.get = async (k) => f.store.get(k) || null;
  f.set = async (k, v) => {
    if (k === positionKey) f.cacheWrites.push(JSON.parse(v));
    f.store.set(k, v);
  };
  globalThis.uploadAuthorization = f;
  globalThis.fetch = async (_url, o) => {
    f.writes.push({ token: o.headers.Authorization, body: JSON.parse(o.body) });
    return Response.json({ ok: true, offer: null, serverTime: Date.now() });
  };
  return f;
}
async function clean(f) {
  f.permission = async () => ({ granted: true });
  await service.stopLocation(false);
  globalThis.fetch = originalFetch;
}
void test('fresh runtime restores persisted background capability and uploads a fresh fix without a new online action', async () => {
  const f = fixture();
  try {
    f.store.set(key, JSON.stringify(credential()));
    const status = await service.resumeLocation();
    assert.equal(status.active, true);
    await globalThis.uploadTask({ data: { locations: [fix()] } });
    assert.equal(f.writes.length, 1);
    assert.equal(f.writes[0].token, 'Bearer ' + 'a'.repeat(64));
  } finally {
    await clean(f);
  }
});
for (const mode of ['foreground', 'background'])
  void test(
    mode +
      ' GPS cannot use old capability while a new start awaits permission; current new start recovers',
    async () => {
      const f = fixture(),
        gate = defer();
      let next;
      try {
        await service.startLocation(credential());
        f.permission = () => gate.promise;
        next = service.startLocation(credential('b'));
        const sample = fix(Date.now() - 1000);
        if (mode === 'foreground') await service.deliverForeground(sample);
        else await globalThis.uploadTask({ data: { locations: [sample] } });
        assert.equal(f.writes.length, 0);
        assert.equal(f.cacheWrites.length, 0);
        gate.resolve({ granted: true });
        await next;
        await service.deliverForeground(fix());
        assert.equal(f.writes.length, 1);
        assert.equal(f.writes[0].token, 'Bearer ' + 'b'.repeat(64));
      } finally {
        gate.resolve({ granted: true });
        await next;
        await clean(f);
      }
    },
  );
void test('old pre-upload credential read cannot authorize HTTP after completed pause', async () => {
  const f = fixture(),
    gate = defer();
  let entered = false,
    upload;
  try {
    await service.startLocation(credential());
    const get = f.get;
    f.get = async (k) => {
      const value = await get(k);
      if (k === key && f.cacheWrites.length && !entered) {
        entered = true;
        await gate.promise;
      }
      return value;
    };
    upload = service.deliverForeground(fix());
    await flush();
    assert.equal(entered, true);
    await service.stopLocation(false);
    gate.resolve();
    await upload;
    assert.equal(f.writes.length, 0);
    assert.equal(f.store.has(positionKey), false);
  } finally {
    gate.resolve();
    await upload;
    await clean(f);
  }
});
void test('renewed same-session token invalidates delayed old pre-upload read and permits only fresh new upload', async () => {
  const f = fixture(),
    gate = defer();
  let entered = false,
    upload;
  try {
    await service.startLocation(credential());
    const get = f.get;
    f.get = async (k) => {
      const value = await get(k);
      if (k === key && f.cacheWrites.length && !entered) {
        entered = true;
        await gate.promise;
      }
      return value;
    };
    upload = service.deliverForeground(fix(Date.now() - 1000));
    await flush();
    assert.equal(entered, true);
    await service.startLocation(credential('b'));
    gate.resolve();
    await upload;
    assert.equal(f.writes.length, 0);
    await service.deliverForeground(fix());
    assert.equal(f.writes.length, 1);
    assert.equal(f.writes[0].token, 'Bearer ' + 'b'.repeat(64));
  } finally {
    gate.resolve();
    await upload;
    await clean(f);
  }
});
void test('pause during serialized cache read prevents an old cache write as well as HTTP', async () => {
  const f = fixture(),
    gate = defer();
  let entered = false,
    upload,
    pause;
  try {
    await service.startLocation(credential());
    const get = f.get;
    f.get = async (k) => {
      const value = await get(k);
      if (k === positionKey && !entered) {
        entered = true;
        await gate.promise;
      }
      return value;
    };
    upload = service.deliverForeground(fix());
    await flush();
    assert.equal(entered, true);
    pause = service.stopLocation(false);
    gate.resolve();
    await Promise.all([upload, pause]);
    assert.equal(f.cacheWrites.length, 0);
    assert.equal(f.writes.length, 0);
  } finally {
    gate.resolve();
    await upload;
    await pause;
    await clean(f);
  }
});
void test('foreground resume and status cannot revive old stored shift during pending new-start permission', async () => {
  const f = fixture(),
    gate = defer();
  let next;
  try {
    await service.startLocation(credential());
    f.started = false;
    f.starts = 0;
    f.permission = () => gate.promise;
    next = service.startLocation(credential('b'));
    const status = await service.resumeLocation();
    assert.equal(f.starts, 0);
    assert.equal(status.active, false);
    gate.resolve({ granted: true });
    await next;
    assert.equal((await service.locationStatus()).active, true);
    assert.equal(f.starts, 1);
  } finally {
    gate.resolve({ granted: true });
    await next;
    await clean(f);
  }
});
void test('HTTP already sent before pause may settle but cannot authorize an old native alert', async () => {
  const f = fixture(),
    gate = defer();
  let upload;
  try {
    await service.startLocation(credential());
    globalThis.fetch = async (_url, o) => {
      f.writes.push(JSON.parse(o.body));
      return gate.promise;
    };
    upload = service.deliverForeground(fix());
    await flush();
    assert.equal(f.writes.length, 1);
    await service.stopLocation(false);
    gate.resolve(
      Response.json({ ok: true, offer: null, serverTime: Date.now() }),
    );
    await upload;
    if (f.alerts.length) assert.equal(await f.alerts[0][3](), false);
    assert.equal(f.store.has(key), false);
  } finally {
    gate.resolve(
      Response.json({ ok: true, offer: null, serverTime: Date.now() }),
    );
    await upload;
    await clean(f);
  }
});
