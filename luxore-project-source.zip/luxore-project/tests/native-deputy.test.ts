import test from 'node:test';
import assert from 'node:assert/strict';
import {
  OperationsController,
  type OperationsData,
} from '../mobile/src/operations.ts';
const snapshot = (): OperationsData =>
  ({
    userId: 'owner',
    canManage: false,
    fleets: [
      {
        id: 'f',
        owner_id: 'owner',
        deputy_id: null,
        name: 'Test',
        created_at: 0,
      },
    ],
    employees: [
      { user_id: 'staff', name: 'Team', fleet_id: 'f' },
      { user_id: 'foreign', name: 'Other', fleet_id: 'other' },
    ],
    drivers: [
      {
        id: 'staff',
        name: 'Team',
        approved: 1,
        online: 1,
        session_id: 'shift',
        fleet_id: 'f',
      },
    ],
    bookings: [],
    revenue: [],
  }) as unknown as OperationsData;
const body = { fleetId: 'f', deputyId: 'staff' };
const defer = <T>() => {
  let resolve!: (v: T) => void;
  const promise = new Promise<T>((r) => {
    resolve = r;
  });
  return { promise, resolve };
};
const error = (status: number) =>
  Object.assign(new Error('Synthetic'), { status });
void test('deputy selection requires current actor authority, same-fleet employee and fresh active data', async () => {
  let data = snapshot();
  const c = new OperationsController(
    async () => data,
    async () => ({ ok: true }),
    async () => ({ ok: true }),
  );
  assert.equal(c.canSetDeputy(body), false);
  c.setActive(true);
  await c.refresh();
  assert.equal(c.canSetDeputy(body), true);
  assert.equal(c.canSetDeputy({ ...body, deputyId: 'foreign' }), false);
  assert.equal(c.canSetDeputy({ ...body, deputyId: 'owner' }), false);
  assert.equal(c.canSetDeputy({ ...body, fleetId: 'other' }), false);
  assert.equal(c.canSetDeputy(body, Date.now() + 30001), false);
  data = { ...data, userId: 'deputy' };
  await c.refresh();
  assert.equal(c.canSetDeputy(body), false);
  data = { ...data, canManage: true };
  await c.refresh();
  assert.equal(c.canSetDeputy(body), true);
  c.setActive(false);
  assert.equal(c.canSetDeputy(body), false);
  c.dispose();
});
void test('deputy write survives background without optimistic result, parallel approval or GPS reset', async () => {
  const pending = defer<{ ok: boolean }>(),
    data = snapshot();
  let writes = 0;
  const c = new OperationsController(
    async () => data,
    async () => {
      writes++;
      return { ok: true };
    },
    () => {
      writes++;
      return pending.promise;
    },
  );
  c.setActive(true);
  await c.refresh();
  const task = c.setDeputy(body);
  assert.equal(c.getSnapshot().data?.fleets[0].deputy_id, null);
  assert.equal(c.canChange({ driverId: 'staff', approved: false }), false);
  await c.setDeputy({ ...body, deputyId: null });
  assert.equal(writes, 1);
  c.setActive(false);
  pending.resolve({ ok: true });
  await task;
  assert.equal(c.getSnapshot().data?.fleets[0].deputy_id, 'staff');
  assert.deepEqual(c.getSnapshot().data?.drivers, data.drivers);
  assert.equal(c.getSnapshot().notice, 'Stellvertretung gespeichert.');
  c.dispose();
});
void test('uncertain deputy write permits only identical retry and read reconciliation performs no extra write', async () => {
  let data = snapshot(),
    writes = 0;
  const c = new OperationsController(
    async () => data,
    async () => ({ ok: true }),
    async () => {
      writes++;
      throw new Error('Lost');
    },
  );
  c.setActive(true);
  await c.refresh();
  await c.setDeputy(body);
  assert.deepEqual(c.getSnapshot().deputyUncertain, body);
  assert.equal(c.canSetDeputy({ ...body, deputyId: null }), false);
  assert.equal(c.canChange({ driverId: 'staff', approved: true }), false);
  c.setActive(false);
  c.setActive(true);
  await c.refresh();
  assert.equal(writes, 1);
  assert.equal(c.canSetDeputy(body), true);
  data = {
    ...data,
    fleets: data.fleets.map((f) => ({ ...f, deputy_id: 'staff' })),
  };
  await c.refresh();
  assert.equal(c.getSnapshot().deputyUncertain, null);
  assert.equal(writes, 1);
  assert.equal(c.canSetDeputy(body), false);
  c.dispose();
});
void test('approval uncertainty blocks deputy changes and removal does not need the old deputy profile', async () => {
  let data = snapshot();
  data.drivers[0].approved = 0;
  const c = new OperationsController(
    async () => data,
    async () => {
      throw new Error('Lost');
    },
    async () => ({ ok: true }),
  );
  c.setActive(true);
  await c.refresh();
  await c.approve({ driverId: 'staff', approved: true });
  assert.equal(c.canSetDeputy(body), false);
  c.dispose();
  data = {
    ...data,
    fleets: data.fleets.map((f) => ({ ...f, deputy_id: 'blocked-legacy' })),
  };
  const next = new OperationsController(
    async () => data,
    async () => ({ ok: true }),
    async () => ({ ok: true }),
  );
  next.setActive(true);
  await next.refresh();
  assert.equal(next.canSetDeputy({ fleetId: 'f', deputyId: null }), true);
  next.setActive(false);
  await next.setDeputy({ fleetId: 'f', deputyId: null });
  assert.equal(next.getSnapshot().data?.fleets[0].deputy_id, 'blocked-legacy');
  next.dispose();
});
void test('known denial clears uncertainty, while incomplete confirmation is not a success', async () => {
  let code = 409;
  const c = new OperationsController(
    async () => snapshot(),
    async () => ({ ok: true }),
    async () => {
      if (code) throw error(code);
      return { ok: false };
    },
  );
  c.setActive(true);
  await c.refresh();
  await c.setDeputy(body);
  assert.equal(c.getSnapshot().deputyUncertain, null);
  assert.equal(c.getSnapshot().data?.fleets[0].deputy_id, null);
  code = 0;
  await c.setDeputy(body);
  assert.deepEqual(c.getSnapshot().deputyUncertain, body);
  c.dispose();
});
void test('revoked rights and account disposal reject or hide delayed deputy responses', async () => {
  let data = snapshot();
  const pending = defer<{ ok: boolean }>();
  const c = new OperationsController(
    async () => data,
    async () => ({ ok: true }),
    () => pending.promise,
  );
  c.setActive(true);
  await c.refresh();
  data = {
    ...data,
    fleets: data.fleets.map((f) => ({ ...f, owner_id: 'new-owner' })),
  };
  await c.refresh();
  assert.equal(c.canSetDeputy(body), false);
  data = snapshot();
  await c.refresh();
  const task = c.setDeputy(body);
  c.dispose();
  pending.resolve({ ok: true });
  await task;
  assert.equal(c.getSnapshot().data?.fleets[0].deputy_id, null);
  const denied = new OperationsController(
    async () => {
      throw error(403);
    },
    async () => ({ ok: true }),
    async () => ({ ok: true }),
  );
  denied.setActive(true);
  await denied.refresh();
  assert.equal(denied.getSnapshot().data, null);
  assert.equal(denied.canSetDeputy(body), false);
  denied.dispose();
});
