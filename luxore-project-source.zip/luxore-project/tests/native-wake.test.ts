import test from 'node:test';
import assert from 'node:assert/strict';
import { LocationLifecycle } from '../mobile/src/location-lifecycle.ts';
import {
  freshNativePosition,
  newestNativePosition,
} from '../mobile/src/position-cache.ts';
import { LocationRequest } from '../mobile/src/location-request.ts';
import { WebViewRecovery } from '../mobile/src/webview-recovery.ts';
test('fresh background fix wins over the old foreground fix on wake; delayed GPS can never move it backwards', () => {
  const now = 100000;
  const old = { lat: 50, lng: 8, accuracy: 6, timestamp: 90000 };
  const background = {
    ...old,
    lng: 8.001,
    timestamp: 99500,
    heading: 90,
    speed: 8,
  };
  const selected = newestNativePosition(old, background, now)!;
  assert.equal(selected.timestamp, 99500);
  assert.equal(newestNativePosition(selected, old, now), selected);
  for (const bad of [
    { ...background, timestamp: 89999 },
    { ...background, timestamp: 110000 },
    { ...background, accuracy: 101 },
    { ...background, lng: Infinity },
  ])
    assert.equal(freshNativePosition(bad, now), null);
});
test('background/wake cancels a stuck one-shot without disabling the new foreground watch', () => {
  const requests = new LocationRequest();
  const before = requests.begin();
  requests.cancel();
  const resumed = requests.begin();
  assert.equal(requests.isCurrent(before), false);
  assert.equal(requests.isCurrent(resumed), true);
  requests.finish(before);
  assert.equal(requests.isCurrent(resumed), true);
});
test('pause runs after an in-flight native restart and newer transitions invalidate pending permission starts', async () => {
  const life = new LocationLifecycle();
  let finish!: () => void;
  let entered!: () => void;
  const ready = new Promise<void>((resolve) => {
    entered = resolve;
  });
  let active = false;
  const restarting = life.run(async () => {
    entered();
    await new Promise<void>((resolve) => {
      finish = resolve;
    });
    active = true;
  });
  await ready;
  const pendingStart = life.begin();
  life.begin();
  const pause = life.run(async () => {
    active = false;
  });
  assert.equal(life.current(pendingStart), false);
  finish();
  await restarting;
  await pause;
  assert.equal(active, false);
  await assert.rejects(
    life.run(async () => {
      throw new Error('test native failure');
    }),
  );
  assert.equal(
    await life.run(async () => 'queue recovered'),
    'queue recovered',
  );
});
test('a killed renderer is recreated without an endless automatic reload loop; manual retry recreates the dead view', () => {
  const recovery = new WebViewRecovery();
  assert.equal(recovery.crashed(1000), true);
  assert.equal(recovery.crashed(2000), false);
  assert.equal(recovery.retry(), true);
  assert.equal(recovery.retry(), false);
  assert.equal(recovery.crashed(61000), true);
});
