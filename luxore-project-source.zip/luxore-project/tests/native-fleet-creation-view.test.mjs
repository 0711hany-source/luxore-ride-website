import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
const store = new Map([['luxore-account-v1', 'a'.repeat(64)]]);
globalThis.nativeViewStore = store;
globalThis.customerAppListeners = new Set();
globalThis.require = () => 1; // Metro resolves static PNG assets in real APKs.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    'expo-location',
    `export const Accuracy={High:4}; export const requestForegroundPermissionsAsync=async()=>({status:'denied'}),getCurrentPositionAsync=async()=>{throw new Error('GPS not enabled in view tests')};`,
  ],
  [
    'react-native',
    `
    export const View='View', Text='Text', Pressable='Pressable', ScrollView='ScrollView', Modal='Modal', Image='Image', TextInput='TextInput', KeyboardAvoidingView='KeyboardAvoidingView', ActivityIndicator='ActivityIndicator';
    export const Platform={OS:'android'}, StyleSheet={create:v=>v}, Keyboard={dismiss(){}}, Share={async share(){}}, Linking={async openURL(){},async openSettings(){}}, Alert={alert(){}};
    export const AppState={currentState:'active',addEventListener(event,listener){globalThis.customerAppListeners.add(listener);return {remove(){globalThis.customerAppListeners.delete(listener)}}}}, BackHandler={addEventListener(){return {remove(){}}}};
    export const useWindowDimensions=()=>({width:390,height:844});
    export const PanResponder={create:handlers=>({panHandlers:handlers})};
    export const Animated={Value:class {constructor(v){this.value=v}setValue(v){this.value=v}},View:'AnimatedView',spring:(v,o)=>({start:()=>v.setValue(o.toValue)})};
  `,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaProvider='SafeAreaProvider', SafeAreaView='SafeAreaView';`,
  ],
  ['expo-status-bar', `export const StatusBar='StatusBar';`],
  ['expo-constants', `export default {expoConfig:{extra:{variant:'driver'}}};`],
  [
    'expo-secure-store',
    `export const getItemAsync=async k=>globalThis.nativeViewStore.get(k)||null,setItemAsync=async(k,v)=>{globalThis.nativeViewStore.set(k,v)},deleteItemAsync=async k=>{globalThis.nativeViewStore.delete(k)};`,
  ],
  [
    'expo-crypto',
    `export const randomUUID=()=> 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';`,
  ],
  [
    'expo-notifications',
    `export const getLastNotificationResponse=()=>null,clearLastNotificationResponse=()=>{},addNotificationResponseReceivedListener=()=>({remove(){}});`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',ArrowRight='ArrowRight', CalendarDays='CalendarDays', CarFront='CarFront', Check='Check', ChevronRight='ChevronRight', CircleHelp='CircleHelp', Home='Home', LogOut='LogOut', Mail='Mail', MapPinned='MapPinned', MapPin='MapPin', Clock3='Clock3', Settings='Settings', ShieldCheck='ShieldCheck', UserRound='UserRound', Users='Users',ChevronDown='ChevronDown',LocateFixed='LocateFixed',Navigation='Navigation',Phone='Phone',RefreshCw='RefreshCw',X='X',Plus='Plus',Minus='Minus',Search='Search';`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    let source = mocked.get(specifier);
    if (specifier.endsWith('/RideWorkspace') || specifier === './RideWorkspace')
      source = `export default function ForbiddenEmbeddedDriver(){throw new Error('Driver mounted a WebView');}`;
    if (specifier === './use-driver-gps')
      source = `export function useDriverGps(){return {position:{lat:50.11,lng:8.68,accuracy:8,timestamp:Date.now()},sessionId:null,error:'',foreground:true,restart:async()=>{},sync:async()=>({active:false})}}`;
    if (specifier === './location-service')
      source = `export const resumeLocation=async()=>({active:false}),stopLocation=async()=>{},foregroundPermission=async()=>{},startLocation=async()=>({active:true});`;
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: OperationsScreen } =
  await import('../mobile/src/OperationsScreen.tsx');

const id = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const base = () => ({
  userId: 'operator',
  canManage: true,
  fleets: [{ id: 'f', name: 'Flotte A', owner_id: 'owner', deputy_id: null }],
  employees: [
    {
      user_id: 'owner',
      name: 'Besitzer',
      fleet_id: 'f',
      role: 'staff',
      can_remove: 1,
    },
    {
      user_id: 'staff',
      name: 'Freies Profil',
      fleet_id: null,
      role: 'staff',
      can_remove: 1,
    },
  ],
  revenue: [],
});
async function settle() {
  for (let i = 0; i < 9; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
const modal = (r) => r.root.findAllByType('Modal').find((n) => n.props.visible);
const text = (r) =>
  r.root
    .findAllByType('Text')
    .map((n) => n.children.filter((c) => typeof c === 'string').join(''))
    .join(' ');
async function swipe(r, dx) {
  await act(async () =>
    modal(r)
      .findAllByType('View')
      .filter((n) => n.props.onLayout)
      .at(-1)
      .props.onLayout({ nativeEvent: { layout: { width: 330 } } }),
  );
  await act(async () =>
    modal(r)
      .findByType('AnimatedView')
      .props.onPanResponderRelease(null, { dx }),
  );
  await settle();
}
void test('integrated native creation has fixed eligible owner form and exact persisted POST only after full swipe', async () => {
  const old = globalThis.fetch;
  let r;
  const data = base(),
    writes = [];
  store.clear();
  globalThis.fetch = async (url, opts) => {
    if (url.endsWith('/operations'))
      return Response.json({ drivers: [], bookings: [] });
    if (opts.method === 'POST') {
      const b = JSON.parse(opts.body);
      assert.ok(
        [...store.values()].some(
          (v) => v.includes(b.requestId) && v.includes(b.name),
        ),
      );
      writes.push(b);
      data.fleets.push({
        id: b.requestId,
        name: b.name,
        owner_id: b.ownerId,
        deputy_id: null,
      });
      return Response.json({ id: b.requestId, name: b.name });
    }
    return Response.json(data);
  };
  try {
    await act(async () => {
      r = Renderer.create(
        React.createElement(OperationsScreen, {
          token: 'a'.repeat(64),
          accountId: 'operator',
          active: true,
          onFleet() {},
        }),
      );
    });
    await settle();
    await act(async () =>
      r.root
        .findByProps({ accessibilityLabel: 'Neue Flotte gründen' })
        .props.onPress(),
    );
    await settle();
    assert.equal(modal(r).props.presentationStyle, 'fullScreen');
    assert.equal(
      modal(r).findAllByProps({
        accessibilityLabel: 'Besitzer Besitzer auswählen',
      }).length,
      0,
    );
    await act(async () =>
      modal(r)
        .findByProps({ accessibilityLabel: 'Name der neuen Flotte' })
        .props.onChangeText('Neue Flotte'),
    );
    await act(async () =>
      modal(r)
        .findByProps({ accessibilityLabel: 'Besitzer Freies Profil auswählen' })
        .props.onPress(),
    );
    assert.equal(modal(r).findByType('AnimatedView').props.onPress, undefined);
    await swipe(r, 30);
    assert.equal(writes.length, 0);
    await swipe(r, 260);
    assert.deepEqual(writes, [
      {
        action: 'create',
        requestId: id,
        name: 'Neue Flotte',
        ownerId: 'staff',
      },
    ]);
    assert.match(text(r), /Flotte gegründet/);
  } finally {
    if (r) await act(async () => r.unmount());
    globalThis.fetch = old;
    store.clear();
  }
});
void test('lost creation restores locked original fields across remount and explicitly repeats same UUID', async () => {
  const old = globalThis.fetch;
  let r;
  const writes = [];
  const data = base();
  store.clear();
  globalThis.fetch = async (url, opts) => {
    if (url.endsWith('/operations'))
      return Response.json({ drivers: [], bookings: [] });
    if (opts.method === 'POST') {
      const b = JSON.parse(opts.body);
      writes.push(b);
      if (writes.length === 1)
        return Response.json({ error: 'Lost reply' }, { status: 503 });
      data.fleets.push({
        id: b.requestId,
        name: b.name,
        owner_id: b.ownerId,
        deputy_id: null,
      });
      return Response.json({ id: b.requestId, name: b.name });
    }
    return Response.json(data);
  };
  const mount = async () => {
    await act(async () => {
      r = Renderer.create(
        React.createElement(OperationsScreen, {
          token: 'a'.repeat(64),
          accountId: 'operator',
          active: true,
          onFleet() {},
        }),
      );
    });
    await settle();
  };
  try {
    await mount();
    await act(async () =>
      r.root
        .findByProps({ accessibilityLabel: 'Neue Flotte gründen' })
        .props.onPress(),
    );
    await settle();
    await act(async () =>
      modal(r)
        .findByProps({ accessibilityLabel: 'Name der neuen Flotte' })
        .props.onChangeText('Original'),
    );
    await act(async () =>
      modal(r)
        .findByProps({ accessibilityLabel: 'Besitzer Freies Profil auswählen' })
        .props.onPress(),
    );
    await swipe(r, 260);
    assert.equal(writes.length, 1);
    await act(async () => r.unmount());
    r = null;
    await mount();
    assert.equal(writes.length, 1);
    await act(async () =>
      r.root
        .findByProps({ accessibilityLabel: 'Offene Flottengründung prüfen' })
        .props.onPress(),
    );
    await settle();
    assert.equal(
      modal(r).findByProps({ accessibilityLabel: 'Name der neuen Flotte' })
        .props.editable,
      false,
    );
    assert.equal(
      modal(r).findByProps({ accessibilityLabel: 'Name der neuen Flotte' })
        .props.value,
      'Original',
    );
    await swipe(r, 260);
    assert.equal(writes.length, 2);
    assert.deepEqual(writes[0], writes[1]);
    assert.match(text(r), /Flotte gegründet/);
  } finally {
    if (r) await act(async () => r.unmount());
    globalThis.fetch = old;
    store.clear();
  }
});
void test('ordinary fleet owner has no native creation control, and restored request is not exposed to another account', async () => {
  const old = globalThis.fetch;
  let r;
  store.clear();
  globalThis.fetch = async (url) =>
    Response.json(
      url.endsWith('/operations')
        ? { drivers: [], bookings: [] }
        : { ...base(), userId: 'owner', canManage: false },
    );
  try {
    await act(async () => {
      r = Renderer.create(
        React.createElement(OperationsScreen, {
          token: 'a'.repeat(64),
          accountId: 'owner',
          active: true,
          onFleet() {},
        }),
      );
    });
    await settle();
    assert.equal(
      r.root.findAllByProps({ accessibilityLabel: 'Neue Flotte gründen' })
        .length,
      0,
    );
    assert.equal(
      r.root.findAllByProps({
        accessibilityLabel: 'Offene Flottengründung prüfen',
      }).length,
      0,
    );
  } finally {
    if (r) await act(async () => r.unmount());
    globalThis.fetch = old;
    store.clear();
  }
});
