import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { Map as MapboxMap } from 'mapbox-gl';
import { attachMapAutoReturn } from '../app/mobility/map-auto-return.ts';

function fixture() {
  const outside = new EventTarget();
  const element = Object.assign(new EventTarget(), {
    ownerDocument: { defaultView: outside },
  });
  const listeners = new Map<
    string,
    Set<(event: { originalEvent?: unknown }) => void>
  >();
  const map = {
    getContainer: () => element,
    on(name: string, fn: (event: { originalEvent?: unknown }) => void) {
      if (!listeners.has(name)) listeners.set(name, new Set());
      listeners.get(name)!.add(fn);
    },
    off(name: string, fn: (event: { originalEvent?: unknown }) => void) {
      listeners.get(name)?.delete(fn);
    },
  };
  let returned = 0,
    paused = 0;
  const control = attachMapAutoReturn(
    map as unknown as MapboxMap,
    () => returned++,
    () => paused++,
  );
  function input(type: string, props = {}) {
    const event = Object.assign(new Event(type), props);
    (type === 'pointerup' || type === 'pointercancel'
      ? outside
      : element
    ).dispatchEvent(event);
  }
  function movement(originalEvent?: unknown) {
    listeners.get('move')?.forEach((fn) => fn({ originalEvent }));
  }
  function end() {
    listeners.get('moveend')?.forEach((fn) => fn({}));
  }
  return {
    control,
    input,
    movement,
    end,
    returned: () => returned,
    paused: () => paused,
  };
}

void test('drag returns exactly three seconds after release, never while held', (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const f = fixture();
  t.after(() => f.control.dispose());
  f.input('pointerdown', { pointerId: 1 });
  f.movement({});
  f.end();
  t.mock.timers.tick(10000);
  assert.equal(f.returned(), 0);
  f.input('pointerup', { pointerId: 1 });
  t.mock.timers.tick(2999);
  assert.equal(f.returned(), 0);
  t.mock.timers.tick(1);
  assert.equal(f.returned(), 1);
  assert.ok(f.paused() > 0);
});

void test('pinch waits for both fingers and momentum to finish', (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const f = fixture();
  t.after(() => f.control.dispose());
  f.input('pointerdown', { pointerId: 1 });
  f.input('pointerdown', { pointerId: 2 });
  f.input('pointerup', { pointerId: 1 });
  t.mock.timers.tick(4000);
  assert.equal(f.returned(), 0);
  f.input('pointerup', { pointerId: 2 });
  t.mock.timers.tick(1000);
  f.movement();
  f.end();
  t.mock.timers.tick(2999);
  assert.equal(f.returned(), 0);
  t.mock.timers.tick(1);
  assert.equal(f.returned(), 1);
});

void test('wheel and keyboard restart delay; automatic animations do not loop', (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const f = fixture();
  t.after(() => f.control.dispose());
  f.movement();
  f.end();
  t.mock.timers.tick(4000);
  assert.equal(f.returned(), 0);
  f.input('wheel');
  t.mock.timers.tick(2500);
  f.input('keydown', { key: '+' });
  t.mock.timers.tick(2999);
  assert.equal(f.returned(), 0);
  t.mock.timers.tick(1);
  assert.equal(f.returned(), 1);
  f.movement();
  f.end();
  t.mock.timers.tick(10000);
  assert.equal(f.returned(), 1);
});

void test('manual recenter clears pending return; cancelled pointer can recover', (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const f = fixture();
  t.after(() => f.control.dispose());
  f.input('pointerdown', { pointerId: 1 });
  f.input('pointercancel', { pointerId: 1 });
  t.mock.timers.tick(3000);
  assert.equal(f.returned(), 1);
  f.input('wheel');
  f.control.reset();
  assert.equal(f.returned(), 2);
  t.mock.timers.tick(4000);
  assert.equal(f.returned(), 2);
});

void test('unmount cancels the timer and removes all map listeners', (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const f = fixture();
  f.input('wheel');
  f.control.dispose();
  f.movement({});
  f.end();
  t.mock.timers.tick(5000);
  assert.equal(f.returned(), 0);
});
