import type { SqlDatabase } from '@/db/sqlite';
import { test } from 'node:test';
/* oxlint-disable typescript/no-floating-promises -- Node's test runner registers and awaits every top-level test. */
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { fare, departure, MAX_ROUTE_METERS } from '../lib/mobility/domain.ts';
import {
  dispatch,
  accept,
  OFFER_MS,
  FRESH_MS,
} from '../lib/mobility/dispatch.ts';
function fixture() {
  const sqlite = new DatabaseSync(':memory:');
  for (const name of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((n) => n.endsWith('.sql'))
    .sort())
    sqlite.exec(
      readFileSync(new URL('../drizzle/' + name, import.meta.url), 'utf8'),
    );
  class Statement {
    values: unknown[] = [];
    query: string;
    constructor(query: string) {
      this.query = query;
    }
    bind(...v: unknown[]) {
      this.values = v;
      return this;
    }
    async first<T>() {
      return (
        (sqlite.prepare(this.query).get(...(this.values as never[])) as T) ??
        null
      );
    }
    async all<T>() {
      return {
        results: sqlite
          .prepare(this.query)
          .all(...(this.values as never[])) as T[],
      };
    }
    async run() {
      const r = sqlite.prepare(this.query).run(...(this.values as never[]));
      return { meta: { changes: Number(r.changes) } };
    }
  }
  const db = {
    prepare: (q: string) => new Statement(q),
    batch: async (items: Statement[]) => {
      sqlite.exec('BEGIN');
      try {
        const result = [];
        for (const item of items) result.push(await item.run());
        sqlite.exec('COMMIT');
        return result;
      } catch (e) {
        sqlite.exec('ROLLBACK');
        throw e;
      }
    },
  } as unknown as SqlDatabase;
  const now = 1789750000000;
  function driver(id: string, lng: number, approved = 1, online = 1, at = now) {
    sqlite
      .prepare(
        'INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,lat,lng,accuracy,location_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
      )
      .run(
        id,
        id,
        '01234',
        'E Klasse',
        id,
        'premium',
        approved,
        online,
        50.11,
        lng,
        10,
        at,
      );
    sqlite
      .prepare(
        "INSERT OR IGNORE INTO mobility_fleets(id,name,owner_id,created_at) VALUES('fleet-a','Fleet A','owner-a',?)",
      )
      .run(now);
    sqlite
      .prepare(
        "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,?,?,'fleet-a','driver',?)",
      )
      .run(id, id, '01234', now);
    sqlite
      .prepare(
        "INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES(?,'fleet-a','Test car',?,'[\"premium\"]','active',?)",
      )
      .run('car-' + id, id, now);
    sqlite
      .prepare('UPDATE mobility_drivers SET vehicle_id=? WHERE id=?')
      .run('car-' + id, id);
  }
  function booking(
    id: string,
    owner = 'customer-' + id,
    status = 'requesting',
    schedule: number | null = null,
  ) {
    sqlite
      .prepare(
        'INSERT INTO mobility_bookings(id,quote_id,owner_id,service,price,route,mode,scheduled_at,status,created_at,updated_at,dispatch_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
      )
      .run(
        id,
        'q-' + id,
        owner,
        'premium',
        2500,
        JSON.stringify({ pickup: { lat: 50.11, lng: 8.68 } }),
        schedule ? 'reservation' : 'now',
        schedule,
        status,
        now,
        now,
        status === 'requesting' ? now : null,
      );
  }
  return { db, sqlite, now, driver, booking };
}
test('Fare uses route metres, rounds once to cents and applies the confirmed minimum', () => {
  assert.equal(fare(1000, 'first'), 1500);
  assert.equal(fare(10000, 'premium'), 2500);
  assert.equal(fare(12345, 'first'), 4321);
  assert.equal(fare(12345, 'van'), 3704);
  assert.equal(fare(3_500_000, 'premium'), 875000);
  assert.equal(fare(MAX_ROUTE_METERS, 'first'), 3500000);
  for (const d of [NaN, Infinity, -1, 0, MAX_ROUTE_METERS + 1])
    assert.throws(() => fare(d, 'premium'));
  assert.throws(() => fare(10000, 'toString' as never));
});
test('Reservations validate departure time independently from immediate rides', () => {
  assert.equal(departure('now', null, 1000), null);
  assert.throws(() => departure('reservation', 1000, 1000));
  assert.throws(() => departure('other', null, 1000));
  assert.equal(departure('reservation', 1801000, 1000), 1801000);
});
test('Nearest eligible driver gets the offer; rejection advances to next and prevents double assignment', async () => {
  const f = fixture();
  f.booking('one');
  f.driver('nearest', 8.681);
  f.driver('next', 8.69);
  f.driver('not-approved', 8.6801, 0);
  f.driver('stale', 8.6802, 1, 1, f.now - FRESH_MS - 1);
  await dispatch(f.db, f.now);
  const offer = f.sqlite
    .prepare("SELECT * FROM mobility_offers WHERE status='pending'")
    .get()!;
  assert.equal(offer.driver_id, 'nearest');
  assert.equal(await accept(f.db, String(offer.id), 'next', f.now), false);
  f.sqlite
    .prepare("UPDATE mobility_offers SET status='rejected' WHERE id=?")
    .run(offer.id as string);
  await dispatch(f.db, f.now + 1000);
  const next = f.sqlite
    .prepare("SELECT * FROM mobility_offers WHERE status='pending'")
    .get()!;
  assert.equal(next.driver_id, 'next');
  assert.equal(await accept(f.db, String(next.id), 'next', f.now + 2000), true);
  assert.equal(
    await accept(f.db, String(next.id), 'next', f.now + 3000),
    false,
  );
  assert.equal(
    f.sqlite
      .prepare('SELECT driver_id FROM mobility_bookings WHERE id=?')
      .get('one')?.driver_id,
    'next',
  );
  f.booking('two');
  await dispatch(f.db, f.now + 3000);
  assert.equal(
    f.sqlite
      .prepare(
        "SELECT count(*) n FROM mobility_offers WHERE status='pending' AND driver_id='next'",
      )
      .get()?.n,
    0,
  );
});
test('Expired offers cannot be accepted and move to a different driver', async () => {
  const f = fixture();
  f.booking('one');
  f.driver('a', 8.681);
  f.driver('b', 8.69);
  await dispatch(f.db, f.now);
  const first = f.sqlite
    .prepare("SELECT id FROM mobility_offers WHERE status='pending'")
    .get()!;
  assert.equal(
    await accept(f.db, String(first.id), 'a', f.now + OFFER_MS + 1),
    false,
  );
  await dispatch(f.db, f.now + OFFER_MS + 1);
  assert.equal(
    f.sqlite
      .prepare("SELECT driver_id FROM mobility_offers WHERE status='pending'")
      .get()?.driver_id,
    'b',
  );
});
test('A driver receives at most one pending offer, cannot serve their own request, and reservations wait', async () => {
  const f = fixture();
  f.driver('d', 8.681);
  f.booking('own', 'd');
  f.booking('one');
  f.booking('two');
  f.booking('later', 'later-user', 'reserved', f.now + 3600000);
  await dispatch(f.db, f.now);
  assert.equal(
    f.sqlite
      .prepare("SELECT count(*) n FROM mobility_offers WHERE status='pending'")
      .get()?.n,
    1,
  );
  assert.equal(
    f.sqlite
      .prepare("SELECT count(*) n FROM mobility_offers WHERE booking_id='own'")
      .get()?.n,
    0,
  );
  assert.equal(
    f.sqlite
      .prepare("SELECT status FROM mobility_bookings WHERE id='later'")
      .get()?.status,
    'reserved',
  );
});
test('Reservation activation and empty-fleet timeout are explicit states', async () => {
  const f = fixture();
  f.booking('soon', 'u', 'reserved', f.now + 600000);
  await dispatch(f.db, f.now);
  assert.equal(
    f.sqlite
      .prepare("SELECT status FROM mobility_bookings WHERE id='soon'")
      .get()?.status,
    'requesting',
  );
  await dispatch(f.db, f.now + 180001);
  assert.equal(
    f.sqlite
      .prepare("SELECT status FROM mobility_bookings WHERE id='soon'")
      .get()?.status,
    'unavailable',
  );
});
test('Cancelled rides cannot be accepted even if an offer was still displayed', async () => {
  const f = fixture();
  f.driver('d', 8.681);
  f.booking('one');
  await dispatch(f.db, f.now);
  const offer = f.sqlite.prepare('SELECT id FROM mobility_offers').get()!;
  f.sqlite
    .prepare("UPDATE mobility_bookings SET status='cancelled' WHERE id='one'")
    .run();
  assert.equal(await accept(f.db, String(offer.id), 'd', f.now + 1), false);
});
test('Database enforces unique active driver and customer even outside application checks', () => {
  const f = fixture();
  f.booking('one', 'customer');
  assert.throws(() => f.booking('duplicate', 'customer'));
  f.booking('two');
  f.sqlite
    .prepare(
      "UPDATE mobility_bookings SET status='accepted',driver_id='driver' WHERE id='one'",
    )
    .run();
  assert.throws(() =>
    f.sqlite
      .prepare(
        "UPDATE mobility_bookings SET status='accepted',driver_id='driver' WHERE id='two'",
      )
      .run(),
  );
});

test('Multi-class driver receives and accepts secondary class; cannot receive a third class', async () => {
  const f = fixture();
  f.driver('multi', 8.68);
  f.booking('first');
  f.sqlite
    .prepare(
      'UPDATE mobility_drivers SET services=\'["premium","first"]\' WHERE id=\'multi\'',
    )
    .run();
  f.sqlite
    .prepare("UPDATE mobility_bookings SET service='first' WHERE id='first'")
    .run();
  await dispatch(f.db, f.now);
  const offer = f.sqlite
    .prepare("SELECT id FROM mobility_offers WHERE booking_id='first'")
    .get()!;
  assert.equal(await accept(f.db, String(offer.id), 'multi', f.now + 1), true);
  f.sqlite
    .prepare("UPDATE mobility_bookings SET status='completed' WHERE id='first'")
    .run();
  f.booking('van');
  f.sqlite
    .prepare("UPDATE mobility_bookings SET service='van' WHERE id='van'")
    .run();
  await dispatch(f.db, f.now + 2);
  assert.equal(
    f.sqlite
      .prepare("SELECT count(*) n FROM mobility_offers WHERE booking_id='van'")
      .get()!.n,
    0,
  );
});

test('Changing eligibility before acceptance prevents accepting a removed class', async () => {
  const f = fixture();
  f.driver('d', 8.68);
  f.booking('b');
  await dispatch(f.db, f.now);
  const offer = f.sqlite.prepare('SELECT id FROM mobility_offers').get()!;
  f.sqlite.prepare('UPDATE mobility_drivers SET services=\'["first"]\'').run();
  assert.equal(await accept(f.db, String(offer.id), 'd', f.now + 1), false);
});

test('Collection is driver-owned, completed-only, idempotent and gates the next offer', async () => {
  const { collect } = await import('../lib/mobility/payments.ts');
  const f = fixture();
  f.driver('d', 8.68);
  f.booking('b');
  await dispatch(f.db, f.now);
  const offer = f.sqlite.prepare('SELECT id FROM mobility_offers').get()!;
  assert.equal(await accept(f.db, String(offer.id), 'd', f.now + 1), true);
  assert.equal(
    f.sqlite
      .prepare("SELECT fleet_id FROM mobility_bookings WHERE id='b'")
      .get()!.fleet_id,
    'fleet-a',
  );
  assert.equal(await collect(f.db, 'b', 'd', 'cash', f.now + 2), false);
  f.sqlite
    .prepare(
      "UPDATE mobility_bookings SET status='completed',completed_at=? WHERE id='b'",
    )
    .run(f.now + 3);
  assert.equal(
    await collect(f.db, 'b', 'other-driver', 'cash', f.now + 4),
    false,
  );
  f.booking('next');
  await dispatch(f.db, f.now + 5);
  assert.equal(
    f.sqlite
      .prepare("SELECT count(*) n FROM mobility_offers WHERE booking_id='next'")
      .get()!.n,
    0,
  );
  assert.equal(await collect(f.db, 'b', 'd', 'cash', f.now + 6), true);
  assert.equal(await collect(f.db, 'b', 'd', 'cash', f.now + 7), true);
  assert.equal(await collect(f.db, 'b', 'd', 'terminal', f.now + 8), false);
  assert.equal(
    f.sqlite
      .prepare(
        "SELECT count(*) n FROM mobility_events WHERE action='collected:cash'",
      )
      .get()!.n,
    1,
  );
  f.sqlite
    .prepare(
      "UPDATE mobility_employees SET fleet_id='fleet-b' WHERE user_id='d'",
    )
    .run();
  assert.equal(
    f.sqlite
      .prepare("SELECT fleet_id FROM mobility_bookings WHERE id='b'")
      .get()!.fleet_id,
    'fleet-a',
  );
  await dispatch(f.db, f.now + 9);
  assert.equal(
    f.sqlite
      .prepare("SELECT count(*) n FROM mobility_offers WHERE booking_id='next'")
      .get()!.n,
    0,
  );
  f.sqlite
    .prepare(
      "INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES('fleet-b','Fleet B','owner-b',?)",
    )
    .run(f.now);
  f.sqlite
    .prepare(
      "INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('car-b','fleet-b','New car','B 1','[\"premium\"]','active',?)",
    )
    .run(f.now);
  f.sqlite
    .prepare("UPDATE mobility_drivers SET vehicle_id='car-b' WHERE id='d'")
    .run();
  await dispatch(f.db, f.now + 10);
  assert.equal(
    f.sqlite
      .prepare("SELECT count(*) n FROM mobility_offers WHERE booking_id='next'")
      .get()!.n,
    1,
  );
});

test('Historical completions are never retroactively presented for collection', async () => {
  const { collect } = await import('../lib/mobility/payments.ts');
  const f = fixture();
  f.driver('d', 8.68);
  f.booking('legacy', 'rider', 'completed');
  f.sqlite
    .prepare("UPDATE mobility_bookings SET driver_id='d' WHERE id='legacy'")
    .run();
  assert.equal(await collect(f.db, 'legacy', 'd', 'cash', f.now), false);
});

test('Frankfurt daily revenue boundaries handle winter, summer and both DST transitions', async () => {
  const { berlinDayStart } = await import('../lib/mobility/time.ts');
  for (const [instant, start] of [
    ['2026-01-15T12:00:00Z', '2026-01-14T23:00:00Z'],
    ['2026-09-24T12:00:00Z', '2026-09-23T22:00:00Z'],
    ['2026-03-29T12:00:00Z', '2026-03-28T23:00:00Z'],
    ['2026-10-25T12:00:00Z', '2026-10-24T22:00:00Z'],
    ['2026-09-23T22:00:00Z', '2026-09-23T22:00:00Z'],
  ])
    assert.equal(
      new Date(berlinDayStart(Date.parse(instant))).toISOString(),
      new Date(start).toISOString(),
    );
});

test('Vehicles without a current active fleet association are excluded from offers and acceptance', async () => {
  const f = fixture();
  f.driver('d', 8.68);
  f.booking('b');
  f.sqlite
    .prepare(
      "UPDATE mobility_employees SET fleet_id='f',created_at=? WHERE user_id='d'",
    )
    .run(f.now);
  f.sqlite
    .prepare(
      "INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,created_at) VALUES('v','f','S Class','F TEST','[\"premium\"]',?)",
    )
    .run(f.now);
  await dispatch(f.db, f.now);
  assert.equal(
    f.sqlite.prepare('SELECT count(*) n FROM mobility_offers').get()!.n,
    0,
  );
  f.sqlite
    .prepare("UPDATE mobility_drivers SET vehicle_id='v' WHERE id='d'")
    .run();
  f.sqlite
    .prepare(
      "INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES('f','Fleet F','owner-f',?)",
    )
    .run(f.now);
  await dispatch(f.db, f.now + 1);
  const offer = f.sqlite.prepare('SELECT id FROM mobility_offers').get()!;
  f.sqlite
    .prepare("UPDATE mobility_vehicles SET status='archived' WHERE id='v'")
    .run();
  assert.equal(await accept(f.db, String(offer.id), 'd', f.now + 2), false);
});

test('Fleetless, foreign-fleet and archived cars never receive offers or accept old offers', async () => {
  for (const mutation of [
    "DELETE FROM mobility_employees WHERE user_id='d'",
    "UPDATE mobility_employees SET fleet_id='other' WHERE user_id='d'",
    "UPDATE mobility_vehicles SET status='archived' WHERE id='car-d'",
    "UPDATE mobility_drivers SET vehicle_id=NULL WHERE id='d'",
  ]) {
    const f = fixture();
    f.driver('d', 8.68);
    f.booking('b');
    await dispatch(f.db, f.now);
    const offer = f.sqlite.prepare('SELECT id FROM mobility_offers').get()!;
    f.sqlite.exec(mutation);
    assert.equal(await accept(f.db, String(offer.id), 'd', f.now + 1), false);
    f.sqlite.exec('DELETE FROM mobility_offers');
    await dispatch(f.db, f.now + 2);
    assert.equal(
      f.sqlite.prepare('SELECT count(*) n FROM mobility_offers').get()!.n,
      0,
    );
    f.sqlite.close();
  }
});

test('European pickup dispatches to an eligible local driver, never a distant Frankfurt driver', async () => {
  const f = fixture();
  try {
    f.booking('paris');
    f.sqlite
      .prepare('UPDATE mobility_bookings SET route=? WHERE id=?')
      .run(JSON.stringify({ pickup: { lat: 48.8566, lng: 2.3522 } }), 'paris');
    f.driver('frankfurt', 8.68);
    await dispatch(f.db, f.now);
    assert.equal(
      f.sqlite.prepare('SELECT count(*) AS n FROM mobility_offers').get()!.n,
      0,
    );
    f.driver('paris-local', 2.353);
    f.sqlite
      .prepare('UPDATE mobility_drivers SET lat=48.857 WHERE id=?')
      .run('paris-local');
    await dispatch(f.db, f.now + 1000);
    const offer = f.sqlite
      .prepare("SELECT * FROM mobility_offers WHERE status='pending'")
      .get()!;
    assert.equal(offer.driver_id, 'paris-local');
    assert.equal(
      await accept(f.db, String(offer.id), 'paris-local', f.now + 2000),
      true,
    );
  } finally {
    f.sqlite.close();
  }
});
