import './support/tsx-loader.mjs';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
const { default: Panel } = await import('../app/mobility/navigation-panel.tsx');
const now = 1800000000000;
const step = {
  type: 'turn',
  modifier: 'left',
  instruction: 'Links in die Taunusstraße abbiegen',
};
const route = {
  calculatedAt: now,
  navigation: [step],
  traffic: { unpaved: false },
};
const base = {
  phase: 'riding',
  destination: 'Opernplatz',
  route,
  progress: {
    next: step,
    following: null,
    nearDestination: false,
    distanceToTurn: 120,
    remainingMeters: 2200,
    remainingSeconds: 300,
  },
  fix: { lat: 50, lng: 8, accuracy: 6, timestamp: now },
  now,
  online: true,
  failed: false,
  pending: false,
};
const render = (props = {}) =>
  renderToStaticMarkup(createElement(Panel, { ...base, ...props }));
void test('guidance prominently shows turn, distance, Berlin ETA and remaining journey', () => {
  const html = render();
  assert.match(html, /120 m/);
  assert.match(html, /Links in die Taunusstraße abbiegen/);
  assert.match(html, /Ankunft · ca\./);
  assert.match(html, /Restzeit/);
  assert.match(html, /2,2 km/);
  assert.match(html, /Verkehr berücksichtigt/);
});
void test('GPS loss and stale route hide old turn and ETA instead of showing misleading guidance', () => {
  for (const html of [
    render({ fix: null }),
    render({ now: now + 91000, fix: { ...base.fix, timestamp: now + 91000 } }),
  ]) {
    assert.doesNotMatch(html, /Links in die Taunusstraße/);
    assert.doesNotMatch(html, /120 m/);
    assert.doesNotMatch(html, /2,2 km/);
  }
});
void test('offline can retain fresh saved directions but marks them; arrival requires manual trip flow', () => {
  assert.match(render({ online: false }), /Offline · Route gespeichert/);
  assert.match(render({ phase: 'arrived' }), /Fahrgast einsteigen lassen/);
  assert.doesNotMatch(render({ phase: 'arrived' }), /120 m/);
});
void test('provider strings are escaped and unknown guidance never becomes HTML', () => {
  const html = render({
    progress: {
      ...base.progress,
      next: { ...step, instruction: '<script>alert(1)</script>' },
    },
  });
  assert.doesNotMatch(html, /<script>/);
  assert.match(html, /&lt;script&gt;/);
});

void test('confirmed route recovery hides stale turns and ETA even while GPS itself is valid', () => {
  for (const recovery of ['off-route', 'wrong-direction']) {
    const html = render({ recovery });
    assert.doesNotMatch(html, /Links in die Taunusstraße/);
    assert.doesNotMatch(html, /120 m|2,2 km/);
    assert.match(html, /Neue Route wird gesucht/);
  }
  const offline = render({ recovery: 'off-route', online: false });
  assert.match(offline, /Neue Route benötigt/);
  assert.match(offline, /Keine Internetverbindung/);
});
