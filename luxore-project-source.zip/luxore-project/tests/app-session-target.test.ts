import test from 'node:test';
import assert from 'node:assert/strict';
import {
  appSessionTarget,
  reviewPath,
  reviewQuery,
} from '../lib/mobility/app-targets.ts';

void test('session handover accepts only fixed screens and the review page with known parameters', () => {
  for (const target of [
    '/mobile/customer',
    '/mobile/driver',
    '/disposition',
    '/betreiber',
    '/pruefung',
    '/pruefung?bereich=papiere',
    '/pruefung?bereich=kontrolle&fahrzeug=vehicle:veh_1-A',
    '/pruefung?fahrer=account:local-test-6ea5',
    '/pruefung?fahrer=3f0c1c2e-8a4b-4c1d-9e57-0a1b2c3d4e5f',
  ])
    assert.equal(appSessionTarget(target), target);
  // Parameters are rebuilt in a fixed order, never copied through.
  assert.equal(
    appSessionTarget('/pruefung?fahrzeug=v1&bereich=kontrolle'),
    '/pruefung?bereich=kontrolle&fahrzeug=v1',
  );
});

void test('session handover rejects open redirects, other paths and unknown or malformed parameters', () => {
  for (const target of [
    undefined,
    null,
    42,
    ['/pruefung'],
    '',
    'pruefung',
    'https://attacker.invalid/pruefung',
    '//attacker.invalid/pruefung',
    '/\\attacker.invalid',
    '/pruefung/',
    '/pruefung/../betreiber',
    '/pruefung2',
    '/pruefungen?bereich=papiere',
    '/Pruefung',
    '/pruefung#x',
    '/pruefung?',
    '/pruefung?bereich=papiere#//attacker.invalid',
    '/pruefung?bereich=',
    '/pruefung?bereich=alles',
    '/pruefung?bereich=papiere&bereich=kontrolle',
    '/pruefung?fahrzeug=a&fahrzeug=b',
    '/pruefung?fahrzeug=a=b',
    '/pruefung?fahrzeug=' + 'a'.repeat(81),
    '/pruefung?fahrzeug=a%2F..%2Fb',
    '/pruefung?fahrzeug=a/b',
    '/pruefung?fahrzeug=a@attacker.invalid',
    '/pruefung?fahrzeug=a?b',
    '/pruefung?fahrzeug=a b',
    '/pruefung?fahrzeug=a\r\nSet-Cookie:x',
    '/pruefung?weiter=https://attacker.invalid',
    '/pruefung?bereich=papiere&next=//attacker.invalid',
    '/pruefung?token=abc',
    '/pruefung?bereich=papiere&',
    '/pruefung&bereich=papiere',
    '/mobile/driver?bereich=papiere',
    '/disposition?fahrzeug=v1',
    '/api/mobility/account',
    '/konto',
  ])
    assert.equal(appSessionTarget(target), null, String(target));
});

void test('review query keeps only validated values', () => {
  assert.deepEqual(reviewQuery(''), {
    bereich: null,
    fahrzeug: null,
    fahrer: null,
  });
  assert.deepEqual(reviewQuery('fahrer=d1&bereich=papiere'), {
    bereich: 'papiere',
    fahrzeug: null,
    fahrer: 'd1',
  });
  assert.equal(reviewQuery('seite=2'), null);
  assert.equal(reviewPath(), '/pruefung');
  assert.equal(
    reviewPath({ bereich: 'kontrolle', fahrzeug: 'v1', fahrer: 'd1' }),
    '/pruefung?bereich=kontrolle&fahrzeug=v1&fahrer=d1',
  );
});
