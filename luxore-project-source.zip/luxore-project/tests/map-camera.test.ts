import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  drivingHeading,
  bearingBetween,
  drivingCameraInsets,
} from '../app/mobility/map-camera.ts';

void test('slow real movement accumulates until direction can be estimated', () => {
  const origin = { lat: 50.11, lng: 8.68 };
  let result = drivingHeading(null, origin, 5, null);
  result = drivingHeading(
    result.anchor,
    { ...origin, lat: origin.lat + 0.00005 },
    5,
    result.bearing,
  );
  assert.equal(result.bearing, null);
  assert.deepEqual(result.anchor, origin);
  result = drivingHeading(
    result.anchor,
    { ...origin, lat: origin.lat + 0.0001 },
    5,
    result.bearing,
  );
  assert.equal(result.bearing, null);
  result = drivingHeading(
    result.anchor,
    { ...origin, lat: origin.lat + 0.0002 },
    5,
    result.bearing,
  );
  assert.equal(result.bearing, 0);
});

void test('GPS jitter preserves heading, while crossing north turns through the short angle', () => {
  const origin = { lat: 50.11, lng: 8.68 };
  assert.equal(
    drivingHeading(origin, { ...origin, lat: origin.lat + 0.00008 }, 30, 150)
      .bearing,
    150,
  );
  const north = drivingHeading(
    origin,
    { ...origin, lat: origin.lat + 0.001 },
    5,
    359,
  );
  assert.ok(north.bearing! > 359 || north.bearing! < 1);
  assert.equal(
    bearingBetween(origin, { ...origin, lng: origin.lng + 0.001 }).toFixed(0),
    '90',
  );
});

void test('camera keeps a usable viewport above small, expanded or oversized sheets', () => {
  for (const height of [200, 420, 760]) {
    for (const sheet of [0, 80, 350, 1000]) {
      const camera = drivingCameraInsets(height, sheet);
      const free = height - camera.padding.top - camera.padding.bottom;
      assert.ok(free > 0);
      const anchor = camera.padding.top + free / 2;
      assert.ok(
        anchor > camera.padding.top && anchor < height - camera.padding.bottom,
      );
      assert.ok(anchor > (height - camera.padding.bottom) / 2);
      assert.equal('offset' in camera, false);
      assert.ok(camera.padding.bottom >= 0);
    }
  }
});
