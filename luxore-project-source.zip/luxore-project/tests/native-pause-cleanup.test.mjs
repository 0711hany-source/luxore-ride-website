import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
const virtual = (source) => ({
  url: 'data:text/javascript,' + encodeURIComponent(source),
  shortCircuit: true,
});
registerHooks({
  resolve(s, c, next) {
    if (s === 'expo-location')
      return virtual(
        `export const Accuracy={High:4,BestForNavigation:6};export const requestForegroundPermissionsAsync=async()=>({granted:true}),getBackgroundPermissionsAsync=async()=>({granted:true}),requestBackgroundPermissionsAsync=async()=>({granted:true}),hasStartedLocationUpdatesAsync=async()=>{globalThis.pauseCleanup.probes++;globalThis.pauseCleanup.check('probe');return globalThis.pauseCleanup.started},startLocationUpdatesAsync=async()=>{globalThis.pauseCleanup.started=true},stopLocationUpdatesAsync=async()=>{globalThis.pauseCleanup.stops++;globalThis.pauseCleanup.check('stop');globalThis.pauseCleanup.started=false},getCurrentPositionAsync=()=>new Promise(()=>{});`,
      );
    if (s === 'expo-task-manager')
      return virtual(`export const defineTask=()=>{};`);
    if (s === 'expo-secure-store')
      return virtual(
        `export const getItemAsync=async k=>{if(k==='luxore-driver-location-session')globalThis.pauseCleanup.check('read');return globalThis.pauseCleanup.store.get(k)||null},setItemAsync=async(k,v)=>globalThis.pauseCleanup.store.set(k,v),deleteItemAsync=async k=>{globalThis.pauseCleanup.removes.push(k);globalThis.pauseCleanup.check(k==='luxore-driver-location-session'?'deleteCapability':'deleteCache');globalThis.pauseCleanup.store.delete(k)};`,
      );
    if (s === 'react-native')
      return virtual(
        `export const Alert={alert(){throw Error('Unexpected permission dialog')}};`,
      );
    if (s === './offer-alerts')
      return virtual(
        `export const offerAlerts={clear:async()=>{globalThis.pauseCleanup.clears++;globalThis.pauseCleanup.check('alarm')},sync:async()=>{}},alertStatus=async()=>({enabled:true,sound:true}),requestAlerts=async()=>({enabled:true,sound:true});`,
      );
    return next(s, c);
  },
  load(url, c, next) {
    if (
      url.endsWith('/mobile/src/location-service.ts') &&
      process.env.TEST_ORIGINAL_LOCATION_SERVICE
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_LOCATION_SERVICE, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
const service = await import('../mobile/src/location-service.ts');
const key = 'luxore-driver-location-session',
  positionKey = 'luxore-driver-background-position';
const cred = (id = 'old') => ({
  sessionId: id,
  nativeToken: (id === 'old' ? 'a' : 'b').repeat(64),
  expiresAt: Date.now() + 3600000,
});
const fix = () => ({
  coords: {
    latitude: 50.11,
    longitude: 8.68,
    accuracy: 8,
    speed: 0,
    heading: 0,
  },
  timestamp: Date.now(),
});
const originalFetch = globalThis.fetch;
function fixture() {
  const f = {
    store: new Map(),
    fail: new Set(),
    started: false,
    stops: 0,
    probes: 0,
    clears: 0,
    removes: [],
    writes: [],
  };
  f.check = (name) => {
    if (f.fail.has(name)) throw Error('Synthetic ' + name);
  };
  globalThis.pauseCleanup = f;
  globalThis.fetch = async (_url, o) => {
    f.writes.push({ token: o.headers.Authorization, body: JSON.parse(o.body) });
    return Response.json({ ok: true });
  };
  return f;
}
async function start(f) {
  await service.startLocation(cred());
  f.store.set(positionKey, 'cached');
  f.stops = 0;
  f.probes = 0;
  f.clears = 0;
  f.removes = [];
}
async function clean(f) {
  f.fail.clear();
  await service.stopLocation(false);
  globalThis.fetch = originalFetch;
}
for (const failure of ['deleteCapability', 'deleteCache'])
  void test(
    'actual pause continues native cleanup and original-token server stop after ' +
      failure +
      ' rejects, then reports failure',
    async () => {
      const f = fixture();
      try {
        await start(f);
        f.fail.add(failure);
        await assert.rejects(service.stopLocation(), /Synthetic/);
        assert.equal(f.started, false);
        assert.equal(f.stops, 1);
        assert.equal(f.clears, 1);
        assert.ok(f.removes.includes(key));
        assert.ok(f.removes.includes(positionKey));
        assert.deepEqual(f.writes, [
          { token: 'Bearer ' + 'a'.repeat(64), body: { action: 'stop' } },
        ]);
        const count = f.writes.length;
        await service.deliverForeground(fix());
        assert.equal(f.writes.length, count);
        assert.equal(
          f.store.has(failure === 'deleteCapability' ? key : positionKey),
          true,
        );
      } finally {
        await clean(f);
      }
    },
  );
void test('unconditional pause with unreadable capability still clears storage and stops native GPS without inventing server credentials', async () => {
  const f = fixture();
  try {
    await start(f);
    f.fail.add('read');
    await assert.rejects(service.stopLocation(), /Synthetic read/);
    assert.equal(f.started, false);
    assert.equal(f.store.has(key), false);
    assert.equal(f.store.has(positionKey), false);
    assert.equal(f.clears, 1);
    assert.equal(f.writes.length, 0);
  } finally {
    await clean(f);
  }
});
void test('failed native running-status probe still attempts actual stop and original-token server stop, with explicit error', async () => {
  const f = fixture();
  try {
    await start(f);
    f.fail.add('probe');
    await assert.rejects(service.stopLocation(), /Synthetic probe/);
    assert.equal(f.stops, 1);
    assert.equal(f.started, false);
    assert.equal(f.writes.length, 1);
    assert.equal(f.writes[0].token, 'Bearer ' + 'a'.repeat(64));
  } finally {
    await clean(f);
  }
});
void test('actual native stop failure cannot suppress capability revocation or original-token server stop', async () => {
  const f = fixture();
  try {
    await start(f);
    f.fail.add('stop');
    await assert.rejects(service.stopLocation(), /Synthetic stop/);
    assert.equal(f.started, true);
    assert.equal(f.store.has(key), false);
    assert.equal(f.store.has(positionKey), false);
    assert.equal(f.writes.length, 1);
    const count = f.writes.length;
    await service.deliverForeground(fix());
    assert.equal(f.writes.length, count);
    assert.equal((await service.locationStatus()).active, false);
  } finally {
    await clean(f);
  }
});
void test('explicit retry after failed capability deletion completes device cleanup, and a later valid shift uploads normally', async () => {
  const f = fixture();
  try {
    await start(f);
    f.fail.add('deleteCapability');
    await assert.rejects(service.stopLocation(), /Synthetic/);
    assert.equal(f.started, false);
    f.fail.clear();
    await service.stopLocation();
    assert.equal(f.store.has(key), false);
    assert.equal((await service.resumeLocation()).active, false);
    assert.equal(f.writes.length, 2);
    await service.startLocation(cred('new'));
    await service.deliverForeground(fix());
    assert.equal(f.writes.at(-1).token, 'Bearer ' + 'b'.repeat(64));
    assert.ok('lat' in f.writes.at(-1).body);
  } finally {
    await clean(f);
  }
});
void test('best-effort alarm cleanup failure preserves successful native and server pause', async () => {
  const f = fixture();
  try {
    await start(f);
    f.fail.add('alarm');
    await service.stopLocation();
    assert.equal(f.started, false);
    assert.equal(f.store.has(key), false);
    assert.equal(f.writes.length, 1);
  } finally {
    await clean(f);
  }
});
void test('stale expected-session pause cannot delete or stop a newer native shift', async () => {
  const f = fixture();
  try {
    await start(f);
    await service.startLocation(cred('new'));
    f.removes = [];
    f.stops = 0;
    await service.stopLocation(true, 'old', -1);
    assert.equal(f.started, true);
    assert.equal(JSON.parse(f.store.get(key)).sessionId, 'new');
    assert.equal(f.stops, 0);
    assert.equal(f.removes.length, 0);
    assert.equal(f.writes.length, 0);
  } finally {
    await clean(f);
  }
});
void test('late server pause response cannot delete a shift started after local cleanup', async () => {
  const f = fixture();
  let release;
  const pending = new Promise((r) => {
    release = r;
  });
  let stopped;
  try {
    await start(f);
    globalThis.fetch = async (_url, o) => {
      f.writes.push({
        token: o.headers.Authorization,
        body: JSON.parse(o.body),
      });
      return pending;
    };
    stopped = service.stopLocation();
    for (let i = 0; i < 8; i++) await new Promise((r) => setImmediate(r));
    assert.equal(f.writes.length, 1);
    await service.startLocation(cred('new'));
    release(Response.json({ ok: true }));
    await stopped;
    assert.equal((await service.locationStatus()).sessionId, 'new');
    assert.equal(f.started, true);
    assert.equal(f.writes.length, 1);
  } finally {
    release(Response.json({ ok: true }));
    await stopped;
    await clean(f);
  }
});
