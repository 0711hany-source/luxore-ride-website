import { test } from 'node:test';
import assert from 'node:assert/strict';
import { sheetHeights, settleSheet } from '../app/mobility/sheet-motion.ts';
import {
  freshLocation,
  saveNativeLocationSql,
} from '../lib/mobility/location.ts';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
test('driver sheet has a small map-first stop and follows drag and flick direction', () => {
  const h = sheetHeights(600);
  assert.equal(h.peek, 80);
  assert.equal(h.full, 588);
  assert.equal(settleSheet(90, 0, h), 'peek');
  assert.equal(settleSheet(340, 0, h), 'half');
  assert.equal(settleSheet(570, 0, h), 'full');
  assert.equal(settleSheet(300, -1, h), 'peek');
  assert.equal(settleSheet(400, 1, h), 'full');
  assert.equal(settleSheet(100, 1, h), 'half');
  assert.equal(settleSheet(80, -2, h), 'peek');
  assert.equal(settleSheet(588, 2, h), 'full');
  const small = sheetHeights(220);
  assert.ok(
    small.peek <= small.half && small.half <= small.full && small.full <= 220,
  );
});
test('location accepts only fresh accurate finite samples', () => {
  const now = 100000;
  const p = { lat: 50, lng: 8, accuracy: 10, timestamp: now };
  assert.ok(freshLocation(p, now));
  for (const values of [
    { timestamp: now - 30001 },
    { timestamp: now + 5001 },
    { accuracy: 101 },
    { accuracy: -1 },
    { lat: NaN },
    { lng: 181 },
    { timestamp: NaN },
  ])
    assert.equal(freshLocation({ ...p, ...values }, now), false);
});
test('native update CAS cannot revive a paused, replaced, unapproved, expired or vehicle-ineligible driver', () => {
  const db = new DatabaseSync(':memory:');
  try {
    for (const f of readdirSync(new URL('../drizzle/', import.meta.url))
      .filter((x) => x.endsWith('.sql'))
      .sort())
      db.exec(
        readFileSync(new URL('../drizzle/' + f, import.meta.url), 'utf8'),
      );
    db.exec(
      "INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,session_id) VALUES('driver','Test','123456','Car','TEST','premium',1,0,'shift'); INSERT INTO mobility_location_sessions VALUES('hash','driver','shift',999999)",
    );
    db.exec(
      "INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES('fleet','Test fleet','owner',0);" +
        "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,created_at) VALUES('driver','Test','123456','fleet',0);INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('car','fleet','Car','TEST','[\"premium\"]','active',0)",
    );
    db.exec("UPDATE mobility_drivers SET vehicle_id='car'");
    const save = (stamp = 1000) =>
      db
        .prepare(saveNativeLocationSql)
        .run(50, 8, 10, stamp, 'driver', 'shift', stamp, 'hash', 1000).changes;
    assert.equal(save(), 1);
    assert.equal(save(), 0);
    assert.equal(save(999), 0);
    assert.equal(save(1001), 1);
    for (const sql of [
      'UPDATE mobility_drivers SET session_id=NULL,online=0',
      "UPDATE mobility_drivers SET session_id='other'",
      'UPDATE mobility_drivers SET approved=0',
      'UPDATE mobility_location_sessions SET expires_at=0',
    ]) {
      db.exec(sql);
      assert.equal(save(2000), 0);
      db.exec(
        "UPDATE mobility_drivers SET session_id='shift',approved=1;UPDATE mobility_location_sessions SET expires_at=999999",
      );
    }
    db.exec('UPDATE mobility_drivers SET vehicle_id=NULL');
    assert.equal(save(2001), 0);
    db.exec("UPDATE mobility_drivers SET vehicle_id='car'");
    assert.equal(save(2001), 1);
    db.exec("UPDATE mobility_vehicles SET status='archived'");
    assert.equal(save(2002), 0);
  } finally {
    db.close();
  }
});
