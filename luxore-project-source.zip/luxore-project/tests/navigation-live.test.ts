import test from 'node:test';
import assert from 'node:assert/strict';
import {
  NavigationMotion,
  projectRoad,
} from '../app/mobility/navigation-motion.ts';
import {
  travelTelemetry,
  reliableCourse,
} from '../lib/mobility/gps-telemetry.ts';
import {
  chooseTrafficRoute,
  includesUnpaved,
  routingParameters,
  type TrafficRoute,
} from '../lib/mobility/routing-policy.ts';
import {
  guidanceDue,
  currentGuidance,
} from '../app/mobility/guidance-policy.ts';
import { roadMatchForFix } from '../app/mobility/road-match-policy.ts';
const fix = (
  lng: number,
  lat: number,
  timestamp: number,
  speed = 10,
  heading = 90,
) => ({ lng, lat, timestamp, speed, heading, accuracy: 6 });
const geometry = {
  type: 'LineString' as const,
  coordinates: [
    [8, 50],
    [8.001, 50],
    [8.001, 50.001],
  ],
};
const route = {
  pickup: { id: 'a', label: 'A', lng: 8, lat: 50 },
  destination: { id: 'b', label: 'B', lng: 8.001, lat: 50.001 },
  geometry,
  calculatedAt: 100000,
  distanceMeters: 200,
  durationSeconds: 60,
};
const candidate = (duration: number, distance: number): TrafficRoute => ({
  duration,
  distance,
  geometry,
});
void test('navigation catches up within 280 ms even for old three-second APKs; customer smoothing remains unchanged', () => {
  const m = new NavigationMotion(true);
  m.push(fix(8, 50, 100000), 0);
  m.push(fix(8.0004, 50, 103000), 3000);
  assert.ok(m.sample(3100)!.lng > 8 && m.sample(3100)!.lng < 8.0004);
  assert.equal(m.sample(3280)!.lng, 8.0004);
  assert.equal(m.sample(8000)!.lng, 8.0004);
});
void test('course stays east during alternating lateral GPS drift and holds while parked', () => {
  const m = new NavigationMotion(true);
  m.push(fix(8, 50, 100000), 0);
  for (let i = 1; i <= 8; i++) {
    m.push(
      fix(8 + i * 0.0001, 50 + (i % 2 ? 0.00002 : -0.00002), 100000 + i * 1000),
      i * 1000,
    );
    for (let dt = 0; dt < 600; dt += 16)
      assert.equal(m.sample(i * 1000 + dt)!.bearing, 90);
  }
  m.push(fix(8.0008, 50.000001, 109000, 0, 270), 9000);
  assert.equal(m.sample(10000)!.bearing, 90);
});
void test('missing Android speed or invalid course is not treated as north; sustained straight movement supplies heading', () => {
  assert.deepEqual(travelTelemetry({ heading: -1, speed: NaN }), {
    heading: undefined,
    speed: undefined,
  });
  assert.equal(reliableCourse({ accuracy: 10, heading: 0, speed: 0 }), null);
  assert.equal(reliableCourse({ accuracy: 10, heading: 0, speed: 5 }), 0);
  assert.equal(reliableCourse({ accuracy: 60, heading: 90, speed: 10 }), null);
  const m = new NavigationMotion(true);
  m.push({ ...fix(8, 50, 100000), speed: undefined, heading: undefined }, 0);
  for (let i = 1; i <= 4; i++) {
    m.push(
      {
        ...fix(8 + i * 0.00002, 50, 100000 + i * 1000),
        speed: undefined,
        heading: undefined,
      },
      i * 1000,
    );
    for (let dt = 0; dt < 600; dt += 16) m.sample(i * 1000 + dt);
  }
  assert.equal(m.position!.bearing, 0); // Under six metres: do not rotate on noise.
  m.push(
    { ...fix(8.00012, 50, 105000), speed: undefined, heading: undefined },
    5000,
  );
  for (let t = 5000; t <= 6000; t += 16) m.sample(t);
  assert.ok(m.position!.bearing > 89);
});
void test('full roundabout path is retained and latest measured point reached promptly', () => {
  const coords = Array.from({ length: 13 }, (_, i) => [
    8 + 0.0003 * Math.cos((i * Math.PI) / 12),
    50 + 0.0002 * Math.sin((i * Math.PI) / 12),
  ]);
  const m = new NavigationMotion(true);
  m.push(fix(coords[0][0], coords[0][1], 100000), 0);
  m.push(fix(coords[6][0], coords[6][1], 103000, 10, 0), 3000, coords);
  for (let t = 3000; t <= 3280; t += 16) {
    const pose = m.sample(t)!;
    assert.ok(projectRoad(pose, coords)!.distance < 0.1);
  }
  assert.ok(Math.abs(m.sample(3280)!.lat - coords[6][1]) < 1e-9);
});
void test('traffic policy permits ordinary roads, avoids unpaved and retains full geometry', () => {
  const p = routingParameters(null, 359.8);
  assert.equal(p.exclude, 'unpaved');
  assert.equal(p.overview, 'full');
  assert.equal(p.depart_at, 'now');
  assert.equal(p.bearings, '0,60;');
  assert.equal(routingParameters(null).bearings, undefined);
  assert.equal(
    routingParameters(1800000000000).depart_at,
    new Date(1800000000000).toISOString(),
  );
  assert.equal(
    chooseTrafficRoute([candidate(600, 9000), candidate(620, 7000)])!.distance,
    7000,
  );
  assert.equal(
    chooseTrafficRoute([candidate(600, 9000), candidate(660, 7000)])!.distance,
    9000,
  );
  const dirt = {
    ...candidate(500, 5000),
    legs: [{ notifications: [{ type: 'violation', subtype: 'unpaved' }] }],
  };
  assert.equal(
    chooseTrafficRoute([dirt, candidate(600, 9000)])!.distance,
    9000,
  );
  assert.ok(includesUnpaved(chooseTrafficRoute([dirt])!));
  assert.equal(
    chooseTrafficRoute([
      candidate(NaN, 1),
      {
        ...candidate(5, 10),
        geometry: {
          type: 'LineString',
          coordinates: [
            [8, 50],
            [NaN, 50],
          ],
        },
      },
    ]),
    null,
  );
});
void test('traffic request cadence bounds GPS, detours and retries; old trip responses never become current', () => {
  const f = fix(8, 50, 110000);
  assert.equal(guidanceDue(f, null, null, 110000), true);
  assert.equal(guidanceDue({ ...f, accuracy: 70 }, null, null, 110000), false);
  assert.equal(guidanceDue({ ...f, timestamp: 1 }, null, null, 110000), false);
  assert.equal(guidanceDue(f, route, 100000, 110000), false);
  assert.equal(
    guidanceDue(
      { ...f, lat: 50.002, timestamp: 116000 },
      route,
      100000,
      116000,
    ),
    false,
  );
  assert.equal(
    guidanceDue({ ...f, timestamp: 145000 }, route, 100000, 145000),
    true,
  );
  const value = { bookingId: 'b', phase: 'accepted', route };
  assert.equal(currentGuidance(value, 'b', 'riding', 110000), null);
  assert.equal(currentGuidance(value, 'c', 'accepted', 110000), null);
  assert.equal(currentGuidance(value, 'b', 'accepted', 191000), null);
  assert.equal(currentGuidance(value, 'b', 'accepted', 110000), route);
});
void test('late road match supports newer GPS on its road but never pins beyond endpoint', () => {
  const match = {
    timestamp: 100000,
    coordinates: geometry.coordinates as [number, number][],
  };
  assert.ok(roadMatchForFix(match, fix(8.0009, 50, 101000), 101100));
  assert.equal(
    roadMatchForFix(match, fix(8.001, 50.0012, 101000), 101100),
    null,
  );
  assert.equal(roadMatchForFix(match, fix(8.0009, 50, 107000), 107100), null);
  assert.equal(roadMatchForFix(match, fix(8.0009, 50, 99000), 101100), null);
});
