import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
const directory = new URL('../drizzle/', import.meta.url);
const provisioning = readFileSync(
  new URL('0012_luxore_fleet_owner.sql', directory),
  'utf8',
);
const owner = 'device:cea0a048-70a0-4ad6-afd9-86b0246b689d';
test('fleet provisioning grants only the existing approved identity, never a plate copied on another device', () => {
  const db = new DatabaseSync(':memory:');
  try {
    for (const f of readdirSync(directory)
      .filter((f) => f.endsWith('.sql'))
      .sort())
      db.exec(readFileSync(new URL(f, directory), 'utf8'));
    const insert = db.prepare(
      'INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online) VALUES(?,?,?,?,?,?,?,0)',
    );
    insert.run('imposter', 'Test', '123456', 'Car', 'GG HY 711', 'premium', 1);
    db.exec(provisioning);
    assert.equal(
      db.prepare('SELECT COUNT(*) AS n FROM mobility_fleets').get()?.n,
      0,
    );
    insert.run(owner, 'Owner', '123456', 'E Klasse', 'GG HY 711', 'premium', 0);
    db.exec(provisioning);
    assert.equal(
      db.prepare('SELECT COUNT(*) AS n FROM mobility_fleets').get()?.n,
      0,
    );
    db.prepare('UPDATE mobility_drivers SET approved=1 WHERE id=?').run(owner);
    db.exec(provisioning);
    db.exec(provisioning);
    assert.equal(
      db.prepare('SELECT COUNT(*) AS n FROM mobility_fleets').get()?.n,
      1,
    );
    assert.equal(
      db.prepare('SELECT owner_id FROM mobility_fleets').get()?.owner_id,
      owner,
    );
    assert.equal(
      db.prepare('SELECT COUNT(*) AS n FROM mobility_employees').get()?.n,
      1,
    );
    assert.equal(
      db
        .prepare('SELECT vehicle_id FROM mobility_drivers WHERE id=?')
        .get(owner)?.vehicle_id,
      'luxore-gg-hy-711',
    );
    assert.equal(
      db
        .prepare('SELECT vehicle_id FROM mobility_drivers WHERE id=?')
        .get('imposter')?.vehicle_id,
      null,
    );
    assert.equal(
      db.prepare('SELECT online FROM mobility_drivers WHERE id=?').get(owner)
        ?.online,
      0,
    );
  } finally {
    db.close();
  }
});
