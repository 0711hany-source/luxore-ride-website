import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const mobileRequire = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const nativeReact = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((name) => [
    name,
    pathToFileURL(mobileRequire.resolve(name)).href,
  ]),
);
const store = new Map([['luxore-account-v1', 'a'.repeat(64)]]);
globalThis.nativeViewStore = store;
globalThis.customerAppListeners = new Set();
globalThis.require = () => 1; // Metro resolves static PNG assets in real APKs.
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const mocked = new Map([
  [
    'expo-location',
    `export const Accuracy={High:4}; export const requestForegroundPermissionsAsync=async()=>({status:'denied'}),getCurrentPositionAsync=async()=>{throw new Error('GPS not enabled in view tests')};`,
  ],
  [
    'react-native',
    `
    export const View='View', Text='Text', Pressable='Pressable', ScrollView='ScrollView', Modal='Modal', Image='Image', TextInput='TextInput', KeyboardAvoidingView='KeyboardAvoidingView', ActivityIndicator='ActivityIndicator';
    export const Platform={OS:'android'}, StyleSheet={create:v=>v}, Keyboard={dismiss(){}}, Share={async share(){}}, Linking={async openURL(){},async openSettings(){}}, Alert={alert(){}};
    export const AppState={currentState:'active',addEventListener(event,listener){globalThis.customerAppListeners.add(listener);return {remove(){globalThis.customerAppListeners.delete(listener)}}}}, BackHandler={addEventListener(){return {remove(){}}}};
    export const useWindowDimensions=()=>({width:390,height:844});
    export const PanResponder={create:handlers=>({panHandlers:handlers})};
    export const Animated={Value:class {constructor(v){this.value=v}setValue(v){this.value=v}},View:'AnimatedView',spring:(v,o)=>({start:()=>v.setValue(o.toValue)})};
  `,
  ],
  [
    'react-native-safe-area-context',
    `export const SafeAreaProvider='SafeAreaProvider', SafeAreaView='SafeAreaView';`,
  ],
  ['expo-status-bar', `export const StatusBar='StatusBar';`],
  ['expo-constants', `export default {expoConfig:{extra:{variant:'driver'}}};`],
  [
    'expo-secure-store',
    `export const getItemAsync=async k=>globalThis.nativeViewStore.get(k)||null,setItemAsync=async(k,v)=>{globalThis.nativeViewStore.set(k,v)},deleteItemAsync=async k=>{globalThis.nativeViewStore.delete(k)};`,
  ],
  [
    'expo-crypto',
    `export const randomUUID=()=> 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';`,
  ],
  [
    'expo-notifications',
    `export const getLastNotificationResponse=()=>null,clearLastNotificationResponse=()=>{},addNotificationResponseReceivedListener=()=>({remove(){}});`,
  ],
  [
    'lucide-react-native',
    `export const ArrowLeft='ArrowLeft',ArrowRight='ArrowRight', CalendarDays='CalendarDays', CarFront='CarFront', Check='Check', ChevronRight='ChevronRight', CircleHelp='CircleHelp', Home='Home', LogOut='LogOut', Mail='Mail', MapPinned='MapPinned', MapPin='MapPin', Clock3='Clock3', Settings='Settings', ShieldCheck='ShieldCheck', UserRound='UserRound', Users='Users',ChevronDown='ChevronDown',LocateFixed='LocateFixed',Navigation='Navigation',Phone='Phone',RefreshCw='RefreshCw',X='X',Plus='Plus',Minus='Minus',Search='Search';`,
  ],
]);
registerHooks({
  resolve(specifier, context, next) {
    if (nativeReact.has(specifier))
      return { url: nativeReact.get(specifier), shortCircuit: true };
    let source = mocked.get(specifier);
    if (specifier.endsWith('/RideWorkspace') || specifier === './RideWorkspace')
      source = `export default function ForbiddenEmbeddedDriver(){throw new Error('Driver mounted a WebView');}`;
    if (specifier === './use-driver-gps')
      source = `export function useDriverGps(){return {position:{lat:50.11,lng:8.68,accuracy:8,timestamp:Date.now()},sessionId:null,error:'',foreground:true,restart:async()=>{},sync:async()=>({active:false})}}`;
    if (specifier === './location-service')
      source = `export const resumeLocation=async()=>({active:false}),stopLocation=async()=>{},foregroundPermission=async()=>{},startLocation=async()=>({active:true});`;
    return source
      ? {
          url: 'data:text/javascript,' + encodeURIComponent(source),
          shortCircuit: true,
        }
      : next(specifier, context);
  },
});
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: FleetInvitationsScreen } =
  await import('../mobile/src/FleetInvitationsScreen.tsx');
const { default: SwipeAction } = await import('../mobile/src/SwipeAction.tsx');

const fleets = [
  { id: 'f1', name: 'Testflotte A', owner_id: 'd1', deputy_id: null },
  { id: 'f2', name: 'Testflotte B', owner_id: 'd2', deputy_id: null },
];
const drivers = [
  {
    id: 'd1',
    name: 'Fahrer Alpha',
    fleet_id: 'f1',
    approved: 0,
    online: 0,
    session_id: null,
    vehicle: 'Audi A6',
    plate: 'TEST A',
    phone: '000',
  },
  {
    id: 'd2',
    name: 'Fahrer Beta',
    fleet_id: 'f2',
    approved: 1,
    online: 0,
    session_id: null,
    vehicle: 'Van',
    plate: 'TEST B',
    phone: '000',
  },
];
const revenue = [
  {
    fleet_id: 'f1',
    gross: 10000,
    outstanding: 1000,
    collected: 9000,
    trips: 3,
  },
  { fleet_id: 'f2', gross: 2500, outstanding: 0, collected: 2500, trips: 1 },
];
async function settle() {
  for (let i = 0; i < 7; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
const allText = (renderer) =>
  renderer.root
    .findAllByType('Text')
    .map((n) => n.children.filter((c) => typeof c === 'string').join(''))
    .join(' ');
const choose = (r, name) =>
  r.root
    .findAllByType('Pressable')
    .find((n) =>
      n.findAllByType('Text').some((t) => t.children.includes(name)),
    );
const measure = async (r) =>
  act(async () =>
    r.root
      .findAllByType('View')
      .find((n) => n.props.onLayout)
      .props.onLayout({ nativeEvent: { layout: { width: 330 } } }),
  );
const code = 'LX-' + 'A'.repeat(32);
void test('native creation shows only current own fleets, requires full swipe and shares confirmed code', async () => {
  const old = globalThis.fetch;
  let renderer,
    writes = 0;
  globalThis.fetch = async (url, opts) => {
    assert.match(url, /^https:\/\/luxoreride.de\/api\/mobility\/fleets/);
    if (opts.method === 'POST') {
      writes++;
      assert.deepEqual(JSON.parse(opts.body), {
        action: 'invite_driver',
        fleetId: 'f1',
      });
      return Response.json({
        ok: true,
        code,
        expiresAt: Date.now() + 86400000,
        shareText: 'Test invitation',
      });
    }
    return Response.json({ fleets, userId: 'd1' });
  };
  try {
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(FleetInvitationsScreen, {
          token: 'a'.repeat(64),
          userId: 'd1',
          active: true,
          onDone() {},
        }),
      );
    });
    await settle();
    await act(async () => choose(renderer, 'Team einladen').props.onPress());
    assert.match(allText(renderer), /Testflotte A/);
    assert.doesNotMatch(allText(renderer), /Testflotte B/);
    assert.equal(renderer.root.findByType(SwipeAction).props.disabled, false);
    await measure(renderer);
    const thumb = renderer.root.findByType('AnimatedView');
    assert.equal(thumb.props.onPress, undefined);
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 30 }));
    assert.equal(writes, 0);
    await act(async () => thumb.props.onPanResponderRelease(null, { dx: 260 }));
    await settle();
    assert.equal(writes, 1);
    assert.match(allText(renderer), new RegExp(code));
    assert.equal(
      renderer.root.findByProps({ accessibilityLabel: 'Einladung teilen' })
        .props.disabled,
      false,
    );
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});
void test('ordinary driver joins using native code field and server confirmation across background', async () => {
  const old = globalThis.fetch;
  let renderer,
    finish,
    done = 0,
    writes = 0;
  globalThis.fetch = async (url, opts) => {
    if (opts.method === 'POST') {
      writes++;
      assert.deepEqual(JSON.parse(opts.body), { action: 'join', code });
      return new Promise((resolve) => {
        finish = () =>
          resolve(Response.json({ ok: true, message: 'Flotte bestätigt' }));
      });
    }
    return Response.json({ error: 'No leadership' }, { status: 403 });
  };
  try {
    await act(async () => {
      renderer = Renderer.create(
        React.createElement(FleetInvitationsScreen, {
          token: 'a'.repeat(64),
          userId: 'd3',
          active: true,
          onDone() {
            done++;
          },
        }),
      );
    });
    await settle();
    await act(async () =>
      renderer.root
        .findByProps({ accessibilityLabel: 'Flotteneinladungscode' })
        .props.onChangeText(code.toLowerCase()),
    );
    await measure(renderer);
    await act(async () =>
      renderer.root
        .findByType('AnimatedView')
        .props.onPanResponderRelease(null, { dx: 260 }),
    );
    await settle();
    assert.equal(writes, 1);
    assert.doesNotMatch(allText(renderer), /Flotte bestätigt/);
    await act(async () => {
      for (const fn of globalThis.customerAppListeners) fn('background');
    });
    await act(async () => finish());
    await settle();
    assert.match(allText(renderer), /Flotte bestätigt/);
    assert.equal(renderer.root.findAllByType(SwipeAction).length, 0);
    await act(async () => {
      for (const fn of globalThis.customerAppListeners) fn('active');
    });
    await settle();
    await act(async () =>
      renderer.root
        .findByProps({ accessibilityLabel: 'Zum Fahrerbereich' })
        .props.onPress(),
    );
    assert.equal(done, 1);
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});
void test('driver app menu opens actual native invitation page without embedded driver workspace', async () => {
  const old = globalThis.fetch;
  let renderer;
  globalThis.fetch = async (url) => {
    if (url.endsWith('/account'))
      return Response.json({
        account: {
          id: 'd1',
          name: 'Test',
          email: 'test@example.test',
          phone: '000',
          kind: 'driver',
        },
        registrationReady: true,
        isAdmin: false,
      });
    if (url.endsWith('/driver'))
      return Response.json({
        driver: { ...drivers[0], vehicle_id: null, approved: 1 },
        offers: [],
        bookings: [],
        payments: [],
        vehicles: [],
        fleet: fleets[0],
      });
    if (url.endsWith('/operations'))
      return Response.json({ drivers, bookings: [] });
    if (url.includes('/fleets'))
      return Response.json({ fleets, revenue, employees: [], userId: 'd1' });
    if (url.endsWith('/vehicles')) return Response.json({ vehicles: [] });
    throw new Error('Unexpected API request');
  };
  try {
    const { default: App } = await import('../mobile/src/App.tsx');
    await act(async () => {
      renderer = Renderer.create(React.createElement(App));
    });
    await settle();
    await act(async () =>
      renderer.root
        .findByProps({ accessibilityLabel: 'App-Menü öffnen' })
        .props.onPress(),
    );
    await act(async () =>
      choose(renderer, 'Flotteneinladungen').props.onPress(),
    );
    await settle();
    assert.match(allText(renderer), /Einladungen\./);
    assert.equal(
      renderer.root.findByProps({ accessibilityLabel: 'Flotteneinladungscode' })
        .props.editable,
      true,
    );
  } finally {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = old;
  }
});
