import './support/tsx-loader.mjs';
import { registerHooks } from 'node:module';
import { createClient } from '@libsql/client';
import { readFileSync, readdirSync } from 'node:fs';
import ts from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
registerHooks({
  resolve(s, c, next) {
    if (s === '#offline-adapter')
      return {
        url: new URL('../db/sqlite.ts?offline-adapter', import.meta.url).href,
        shortCircuit: true,
      };
    return next(s, c);
  },
  load(url, c, next) {
    if (url.endsWith('/lib/mobility/server.ts'))
      return {
        format: 'module',
        shortCircuit: true,
        source: `export class ApiError extends Error {constructor(status,message){super(message);this.status=status}};export const db=()=>globalThis.offlineTest.db,tokenHash=async token=>token,limit=async()=>{},settings=()=>({}),isAdmin=()=>false,identity=async()=>({userId:globalThis.offlineTest.user}),text=(v,max=160)=>{if(typeof v!=='string'||!v.trim()||v.length>max)throw new ApiError(400,'invalid');return v.trim()},body=r=>r.json(),json=(v,status=200)=>Response.json(v,{status}),handled=async fn=>{try{return await fn()}catch(e){return json({error:e.message},e.status||500)}};`,
      };
    if (
      url.endsWith('/app/api/mobility/driver/route.ts') &&
      process.env.TEST_ORIGINAL_DRIVER_OFFLINE
    )
      return {
        format: 'module',
        shortCircuit: true,
        source: ts.transpileModule(
          readFileSync(process.env.TEST_ORIGINAL_DRIVER_OFFLINE, 'utf8'),
          {
            compilerOptions: {
              module: ts.ModuleKind.ESNext,
              target: ts.ScriptTarget.ES2022,
            },
          },
        ).outputText,
      };
    return next(url, c);
  },
});
const { sqliteDatabase } = await import('#offline-adapter');
const { POST } = await import('../app/api/mobility/driver/route.ts');
const token = 'a'.repeat(64),
  nextToken = 'b'.repeat(64);
const send = (sessionId = 'old', extra = {}) =>
  POST(
    new Request('https://test.invalid/api/mobility/driver', {
      method: 'POST',
      body: JSON.stringify({ action: 'offline', sessionId, ...extra }),
    }),
  );
async function fixture() {
  const client = createClient({ url: ':memory:' }),
    db = sqliteDatabase(client);
  for (const f of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((n) => n.endsWith('.sql'))
    .sort())
    await client.executeMultiple(
      readFileSync(new URL('../drizzle/' + f, import.meta.url), 'utf8'),
    );
  const now = Date.now();
  await client.execute(
    "INSERT INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES('driver','driver@example.test','Synthetic','000','driver','active',0,0)",
  );
  await client.executeMultiple(`INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES('fleet','Synthetic Fleet','owner',0);
 INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES('driver','Synthetic Driver','000','fleet','driver',0);
 INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES('car','fleet','Synthetic Audi','TEST','["premium"]','active',0);
 INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,services,approved,online,session_id,vehicle_id,lat,lng,accuracy,location_at) VALUES('driver','Synthetic Driver','000','Synthetic Audi','TEST','premium','["premium"]',1,1,'old','car',50.11,8.68,8,${now});
 INSERT INTO mobility_location_sessions(token_hash,driver_id,session_id,expires_at) VALUES('${token}','driver','old',${now + 3600000});
 INSERT INTO mobility_bookings(id,quote_id,owner_id,mode,service,status,route,price,payment_status,created_at,updated_at,dispatch_at) VALUES('booking','quote','customer','now','premium','requesting','{"pickup":{"lat":50.11,"lng":8.68}}',1000,'unpaid',${now},${now},${now});
 INSERT INTO mobility_offers(id,booking_id,driver_id,status,expires_at,created_at) VALUES('offer','booking','driver','pending',${now + 25000},${now});`);
  globalThis.offlineTest = { db, user: 'driver' };
  const snapshot = async () =>
    Object.fromEntries(
      await Promise.all(
        [
          'mobility_accounts',
          'mobility_drivers',
          'mobility_location_sessions',
          'mobility_offers',
          'mobility_bookings',
          'mobility_employees',
          'mobility_vehicles',
        ].map(async (table) => [
          table,
          (await db.prepare('SELECT * FROM ' + table + ' ORDER BY 1').all())
            .results,
        ]),
      ),
    );
  const race = (work) => {
    const prepare = db.prepare;
    let fired = false;
    db.prepare = (sql) => {
      const stmt = prepare(sql);
      if (sql !== 'SELECT * FROM mobility_drivers WHERE id=? AND approved=1')
        return stmt;
      const bind = stmt.bind.bind(stmt);
      stmt.bind = (...args) => {
        const bound = bind(...args),
          first = bound.first.bind(bound);
        bound.first = async (...params) => {
          const row = await first(...params);
          if (!fired) {
            fired = true;
            await work();
          }
          return row;
        };
        return bound;
      };
      return stmt;
    };
  };
  return { client, db, snapshot, race, close: () => client.close() };
}
void test('matching authenticated offline atomically revokes the shift and its native tokens without resetting profile, GPS, fleet or trips', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    const r = await send('old', { driverId: 'foreign' });
    assert.equal(r.status, 200);
    assert.deepEqual(await r.json(), { ok: true });
    const after = await f.snapshot();
    assert.equal(after.mobility_drivers[0].online, 0);
    assert.equal(after.mobility_drivers[0].session_id, null);
    assert.equal(after.mobility_location_sessions.length, 0);
    assert.equal(after.mobility_offers[0].status, 'rejected');
    assert.deepEqual(
      { ...after.mobility_drivers[0], online: 1, session_id: 'old' },
      before.mobility_drivers[0],
    );
    for (const table of [
      'mobility_accounts',
      'mobility_bookings',
      'mobility_employees',
      'mobility_vehicles',
    ])
      assert.deepEqual(after[table], before[table]);
  } finally {
    f.close();
  }
});
void test('wrong session cannot confirm a stop of the current online shift', async () => {
  const f = await fixture();
  try {
    const before = await f.snapshot();
    assert.equal((await send('foreign')).status, 409);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
void test('old session cannot withdraw a replacement shift offer before its first GPS upload', async () => {
  const f = await fixture();
  try {
    await f.client.execute(
      "UPDATE mobility_drivers SET session_id='new',online=0 WHERE id='driver'",
    );
    const before = await f.snapshot();
    assert.equal((await send()).status, 409);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
for (const [name, sql, status] of [
  [
    'concurrent replacement shift',
    "UPDATE mobility_drivers SET session_id='new',online=0 WHERE id='driver'",
    409,
  ],
  [
    'withdrawn approval',
    "UPDATE mobility_drivers SET approved=0 WHERE id='driver'",
    403,
  ],
  [
    'blocked account',
    "UPDATE mobility_accounts SET status='blocked' WHERE id='driver'",
    403,
  ],
  [
    'trip accepted after the screen snapshot',
    "UPDATE mobility_bookings SET status='accepted',driver_id='driver' WHERE id='booking'",
    409,
  ],
])
  void test(
    'authenticated offline rechecks ' + name + ' at its actual write boundary',
    async () => {
      const f = await fixture();
      let expected;
      try {
        f.race(async () => {
          await f.client.execute(sql);
          expected = await f.snapshot();
        });
        assert.equal((await send()).status, status);
        assert.ok(expected);
        assert.deepEqual(await f.snapshot(), expected);
      } finally {
        f.close();
      }
    },
  );
void test('active ride phases and a completed unpaid ride block an actual shift transition without changing any data', async () => {
  for (const status of ['accepted', 'arrived', 'riding', 'completed']) {
    const f = await fixture();
    try {
      await f.client.execute({
        sql: "UPDATE mobility_bookings SET status=?,driver_id='driver',completed_at=CASE WHEN ?='completed' THEN 1 ELSE NULL END WHERE id='booking'",
        args: [status, status],
      });
      const before = await f.snapshot();
      assert.equal((await send()).status, 409);
      assert.deepEqual(await f.snapshot(), before);
    } finally {
      f.close();
    }
  }
});
void test('paid completed history does not block an own valid stop, even with an inactive selected vehicle', async () => {
  const f = await fixture();
  try {
    await f.client.executeMultiple(
      "UPDATE mobility_bookings SET status='completed',driver_id='driver',completed_at=1,payment_status='paid' WHERE id='booking';UPDATE mobility_vehicles SET status='archived' WHERE id='car'",
    );
    assert.equal((await send()).status, 200);
    assert.equal((await f.snapshot()).mobility_drivers[0].session_id, null);
  } finally {
    f.close();
  }
});
const blockDispatch = (client) =>
  client.executeMultiple(
    "INSERT INTO mobility_limits(key,count) VALUES('0:synthetic',1);CREATE TRIGGER fail_dispatch BEFORE DELETE ON mobility_limits BEGIN SELECT RAISE(ABORT,'Synthetic dispatch failure'); END",
  );
void test('native stop already completed: authenticated confirmation of current offline state is mutation-free and skips dispatch', async () => {
  const f = await fixture();
  try {
    await f.client.executeMultiple(
      "UPDATE mobility_drivers SET session_id=NULL,online=0 WHERE id='driver';DELETE FROM mobility_location_sessions;UPDATE mobility_offers SET status='rejected'",
    );
    await blockDispatch(f.client);
    const before = await f.snapshot();
    assert.equal((await send()).status, 200);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
void test('explicit lost-response retry confirms only current offline state without another dispatch or reset', async () => {
  const f = await fixture();
  try {
    assert.equal((await send()).status, 200);
    await blockDispatch(f.client);
    const before = await f.snapshot();
    assert.equal((await send()).status, 200);
    assert.deepEqual(await f.snapshot(), before);
  } finally {
    f.close();
  }
});
for (const [name, sql] of [
  [
    'driver update',
    "CREATE TRIGGER fail_stop BEFORE UPDATE ON mobility_drivers BEGIN SELECT RAISE(ABORT,'Synthetic driver failure'); END",
  ],
  [
    'capability deletion',
    "CREATE TRIGGER fail_stop BEFORE DELETE ON mobility_location_sessions BEGIN SELECT RAISE(ABORT,'Synthetic capability failure'); END",
  ],
  [
    'offer withdrawal',
    "CREATE TRIGGER fail_stop BEFORE UPDATE ON mobility_offers BEGIN SELECT RAISE(ABORT,'Synthetic offer failure'); END",
  ],
])
  void test(
    'authenticated stop rolls back all writes after actual libSQL ' +
      name +
      ' failure and allows explicit retry',
    async () => {
      const f = await fixture();
      try {
        const before = await f.snapshot();
        await f.client.executeMultiple(sql);
        assert.equal((await send()).status, 500);
        assert.deepEqual(await f.snapshot(), before);
        await f.client.execute('DROP TRIGGER fail_stop');
        assert.equal((await send()).status, 200);
      } finally {
        f.close();
      }
    },
  );
void test('dispatch storage failure after commit does not falsify a confirmed authenticated offline change', async () => {
  const f = await fixture();
  try {
    await blockDispatch(f.client);
    const r = await send();
    assert.equal(r.status, 200);
    assert.deepEqual(await r.json(), { ok: true });
    const after = await f.snapshot();
    assert.equal(after.mobility_drivers[0].online, 0);
    assert.equal(after.mobility_drivers[0].session_id, null);
    assert.equal(after.mobility_location_sessions.length, 0);
    assert.equal(after.mobility_offers[0].status, 'rejected');
  } finally {
    f.close();
  }
});
void test('legacy own driver identity without an account row can still stop; empty session is rejected without mutations', async () => {
  const f = await fixture();
  try {
    await f.client.execute('DELETE FROM mobility_accounts');
    const before = await f.snapshot();
    assert.equal((await send(' ')).status, 400);
    assert.deepEqual(await f.snapshot(), before);
    assert.equal((await send()).status, 200);
  } finally {
    f.close();
  }
});

void test('current offline confirmation still requires an active approved own identity', async () => {
  for (const sql of [
    "UPDATE mobility_accounts SET status='blocked' WHERE id='driver'",
    "UPDATE mobility_accounts SET status='deletion_pending' WHERE id='driver'",
    "UPDATE mobility_drivers SET approved=0 WHERE id='driver'",
  ]) {
    const f = await fixture();
    try {
      await f.client.executeMultiple(
        "UPDATE mobility_drivers SET online=0,session_id=NULL WHERE id='driver';" +
          sql,
      );
      const before = await f.snapshot();
      assert.equal((await send()).status, 403);
      assert.deepEqual(await f.snapshot(), before);
    } finally {
      f.close();
    }
  }
});
void test('same session text belonging to another driver is not revoked by own offline write', async () => {
  const f = await fixture();
  try {
    await f.client.executeMultiple(
      `INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,approved,online,session_id) VALUES('other','Other','000','','','premium',1,1,'old');INSERT INTO mobility_location_sessions(token_hash,driver_id,session_id,expires_at) VALUES('${nextToken}','other','old',${Date.now() + 3600000})`,
    );
    assert.equal((await send()).status, 200);
    const after = await f.snapshot();
    assert.deepEqual(
      after.mobility_location_sessions.map((s) => s.driver_id),
      ['other'],
    );
    assert.equal(
      after.mobility_drivers.find((d) => d.id === 'other').session_id,
      'old',
    );
    assert.equal(
      after.mobility_drivers.find((d) => d.id === 'other').online,
      1,
    );
  } finally {
    f.close();
  }
});
