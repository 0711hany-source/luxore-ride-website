import type { SqlDatabase } from '@/db/sqlite';
import { test } from 'node:test';
/* oxlint-disable typescript/no-floating-promises -- Node's test runner registers and awaits every top-level test. */
import assert from 'node:assert/strict';
import { generateKeyPairSync, createVerify } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { classAvailability } from '../lib/mobility/availability.ts';
import { dispatch, FRESH_MS } from '../lib/mobility/dispatch.ts';
import { validateVehicleInput } from '../lib/mobility/vehicle-input.ts';
import {
  claimWakeRecipients,
  forgetPushAccess,
  pushConfig,
  PushForbidden,
  PushInvalid,
  registerPushToken,
  removePushToken,
  serviceJwt,
  WAKE_BODY,
  WAKE_INTERVAL_MS,
  wakeMessage,
  wakeOfflineDrivers,
} from '../lib/mobility/push.ts';

const now = 1789750000000;
function fixture() {
  const sqlite = new DatabaseSync(':memory:');
  for (const name of readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((n) => n.endsWith('.sql'))
    .sort())
    sqlite.exec(
      readFileSync(new URL('../drizzle/' + name, import.meta.url), 'utf8'),
    );
  const statement = (query: string) => {
    let values: unknown[] = [];
    const s = {
      bind(...v: unknown[]) {
        values = v;
        return s;
      },
      async first() {
        return sqlite.prepare(query).get(...(values as never[])) ?? null;
      },
      async all() {
        return { results: sqlite.prepare(query).all(...(values as never[])) };
      },
      async run() {
        const r = sqlite.prepare(query).run(...(values as never[]));
        return { meta: { changes: Number(r.changes) } };
      },
    };
    return s;
  };
  const db = {
    prepare: statement,
    batch: async (items: ReturnType<typeof statement>[]) => {
      const result = [];
      for (const item of items) result.push(await item.run());
      return result;
    },
  } as unknown as SqlDatabase;
  sqlite
    .prepare(
      "INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES('fleet','Fleet','owner',?)",
    )
    .run(now);
  function driver(
    id: string,
    services: string[],
    options: {
      approved?: number;
      online?: number;
      at?: number | null;
      vehicle?: 'active' | 'archived';
    } = {},
  ) {
    const { approved = 1, online = 1, at = now, vehicle = 'active' } = options;
    sqlite
      .prepare(
        'INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,services,approved,online,lat,lng,accuracy,location_at,vehicle_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
      )
      .run(
        id,
        'Private name ' + id,
        '+49 000',
        'Mercedes EQE 300',
        'F ' + id,
        services[0],
        JSON.stringify(services),
        approved,
        online,
        at === null ? null : 50.11,
        at === null ? null : 8.68,
        at === null ? null : 10,
        at,
        'car-' + id,
      );
    sqlite
      .prepare(
        "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,?,?,'fleet','driver',?)",
      )
      .run(id, id, '0', now);
    sqlite
      .prepare(
        "INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES(?,'fleet','Mercedes EQE 300',?,?,?,?)",
      )
      .run('car-' + id, 'F ' + id, JSON.stringify(services), vehicle, now);
  }
  function booking(
    id: string,
    service: string,
    status = 'requesting',
    driverId: string | null = null,
    owner = 'customer-' + id,
  ) {
    sqlite
      .prepare(
        'INSERT INTO mobility_bookings(id,quote_id,owner_id,service,price,route,mode,status,driver_id,created_at,updated_at,dispatch_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
      )
      .run(
        id,
        'q-' + id,
        owner,
        service,
        3220,
        JSON.stringify({ pickup: { lat: 50.11, lng: 8.68 } }),
        'now',
        status,
        driverId,
        now,
        now,
        now,
      );
  }
  const tokens = () =>
    sqlite
      .prepare(
        'SELECT driver_id,token,last_wake_at FROM mobility_push_tokens ORDER BY driver_id',
      )
      .all() as { driver_id: string; token: string; last_wake_at: number }[];
  return { sqlite, db, driver, booking, tokens };
}
const token = (name: string) => 'fcm-token-' + name + '-' + 'x'.repeat(30);
const { privateKey, publicKey } = generateKeyPairSync('rsa', {
  modulusLength: 2048,
});
const pem = privateKey.export({ type: 'pkcs8', format: 'pem' }) as string;
const env = {
  FCM_PROJECT_ID: 'luxore-test',
  FCM_CLIENT_EMAIL: 'push@luxore-test.iam.gserviceaccount.com',
  // As stored in a hosting panel: one line with literal \n.
  FCM_PRIVATE_KEY: pem.replace(/\n/g, '\\n'),
};
function provider(status: (token: string) => number = () => 200) {
  const calls: { url: string; body: string; auth: string | null }[] = [];
  const request = (async (url: string | URL, init?: RequestInit) => {
    const body = String(init?.body ?? '');
    calls.push({
      url: String(url),
      body,
      auth: new Headers(init?.headers).get('authorization'),
    });
    if (String(url).includes('oauth2.googleapis.com'))
      return Response.json({ access_token: 'access', expires_in: 3600 });
    const code = status(JSON.parse(body).message.token);
    return code === 200
      ? Response.json({ name: 'projects/luxore-test/messages/1' })
      : Response.json(
          {
            error: {
              status: code === 404 ? 'NOT_FOUND' : 'UNAVAILABLE',
              details: [{ errorCode: code === 404 ? 'UNREGISTERED' : 'X' }],
            },
          },
          { status: code },
        );
  }) as typeof fetch;
  return { calls, request };
}

test('availability per class uses the dispatch yardstick and reveals only true/false', async () => {
  const f = fixture();
  const none = await classAvailability(f.db, now);
  assert.deepEqual(none, {
    premium: false,
    electric: false,
    van: false,
    first: false,
  });
  f.driver('eqe', ['electric']);
  f.driver('unapproved', ['van'], { approved: 0 });
  f.driver('offline', ['van'], { online: 0 });
  f.driver('stale', ['van'], { at: now - FRESH_MS - 1 });
  f.driver('archived', ['van'], { vehicle: 'archived' });
  f.driver('multi', ['premium', 'first']);
  const some = await classAvailability(f.db, now);
  assert.deepEqual(some, {
    premium: true,
    electric: true,
    van: false,
    first: true,
  });
  assert.deepEqual(Object.keys(some), ['premium', 'electric', 'van', 'first']);
  assert.doesNotMatch(JSON.stringify(some), /Private|50\.11|8\.68|eqe/);
  // A chauffeur on a ride is not free: the class shows „besetzt“.
  f.booking('ride', 'electric', 'riding', 'eqe');
  assert.equal((await classAvailability(f.db, now)).electric, false);
  // The location becomes stale 45 seconds after the last heartbeat.
  assert.equal(
    (await classAvailability(f.db, now + FRESH_MS + 1)).premium,
    false,
  );
});

test('an EQE vehicle released for Electric receives Electric requests only', async () => {
  const f = fixture();
  assert.deepEqual(
    validateVehicleInput({
      model: 'Mercedes EQE 300',
      plate: 'f lx 280',
      services: ['electric'],
    }).value,
    { model: 'Mercedes EQE 300', plate: 'F LX 280', services: ['electric'] },
  );
  assert.ok(
    validateVehicleInput({ model: 'X', plate: 'F 1', services: ['eco'] })
      .errors.services,
  );
  f.driver('eqe', ['electric']);
  f.driver('business', ['premium']);
  f.booking('e1', 'electric');
  f.booking('v1', 'van');
  await dispatch(f.db, now);
  const offers = f.sqlite
    .prepare('SELECT booking_id,driver_id FROM mobility_offers')
    .all();
  assert.deepEqual(
    offers.map((o) => ({ ...o })),
    [{ booking_id: 'e1', driver_id: 'eqe' }],
  );
});

test('only an approved driver stores a token, and only under the own account', async () => {
  const f = fixture();
  f.driver('approved', ['electric'], { online: 0 });
  f.driver('pending', ['electric'], { approved: 0, online: 0 });
  await assert.rejects(
    registerPushToken(f.db, 'customer', token('a'), 'android', now),
    PushForbidden,
  );
  await assert.rejects(
    registerPushToken(f.db, 'pending', token('a'), 'android', now),
    PushForbidden,
  );
  for (const bad of ['', 'short', 'has space ' + 'x'.repeat(30), 7, null])
    await assert.rejects(
      registerPushToken(f.db, 'approved', bad, 'android', now),
      PushInvalid,
    );
  await assert.rejects(
    registerPushToken(f.db, 'approved', token('a'), 'windows', now),
    PushInvalid,
  );
  assert.equal(f.tokens().length, 0);
  await registerPushToken(f.db, 'approved', token('a'), 'android', now);
  // A new token replaces the old one: one device per driver.
  await registerPushToken(f.db, 'approved', token('b'), 'android', now + 1);
  assert.deepEqual(
    f.tokens().map((t) => [t.driver_id, t.token]),
    [['approved', token('b')]],
  );
  // The same phone signed in by another approved driver moves to that driver.
  f.driver('second', ['van'], { online: 0 });
  await registerPushToken(f.db, 'second', token('b'), 'android', now + 2);
  assert.deepEqual(
    f.tokens().map((t) => [t.driver_id, t.token]),
    [['second', token('b')]],
  );
  await removePushToken(f.db, 'approved');
  assert.equal(f.tokens().length, 1);
  await removePushToken(f.db, 'second');
  assert.equal(f.tokens().length, 0);
});

test('wake recipients: offline approved drivers of the waiting class, once per ten minutes', async () => {
  const f = fixture();
  f.driver('eqe-off', ['electric'], { online: 0 });
  f.driver('eqe-stale', ['premium', 'electric'], { at: now - FRESH_MS - 1 });
  f.driver('eqe-unapproved', ['electric'], { approved: 0, online: 0 });
  f.driver('eqe-archived', ['electric'], { online: 0, vehicle: 'archived' });
  f.driver('van-off', ['van'], { online: 0 });
  f.driver('eqe-no-token', ['electric'], { online: 0 });
  for (const id of ['eqe-off', 'eqe-stale', 'eqe-archived', 'van-off'])
    await registerPushToken(f.db, id, token(id), 'android', now);
  // The unapproved driver cannot register; force a row to prove the filter.
  f.sqlite
    .prepare(
      "INSERT INTO mobility_push_tokens(driver_id,token,platform,created_at,updated_at) VALUES('eqe-unapproved',?,'android',?,?)",
    )
    .run(token('eqe-unapproved'), now, now);
  // No request waiting: nobody is disturbed.
  assert.deepEqual(await claimWakeRecipients(f.db, now), []);
  f.booking('e1', 'electric');
  const first = await claimWakeRecipients(f.db, now);
  assert.deepEqual(first.map((r) => r.driverId).sort(), [
    'eqe-off',
    'eqe-stale',
  ]);
  // Ten-minute lock per driver, also for a second waiting request.
  f.booking('e2', 'electric');
  assert.deepEqual(await claimWakeRecipients(f.db, now + 1000), []);
  assert.deepEqual(
    await claimWakeRecipients(f.db, now + WAKE_INTERVAL_MS - 1),
    [],
  );
  const later = await claimWakeRecipients(f.db, now + WAKE_INTERVAL_MS);
  assert.deepEqual(later.map((r) => r.driverId).sort(), [
    'eqe-off',
    'eqe-stale',
  ]);
  // A free online chauffeur of the class: no push at all.
  const g = fixture();
  g.driver('eqe-on', ['electric']);
  g.driver('eqe-off', ['electric'], { online: 0 });
  await registerPushToken(g.db, 'eqe-off', token('x'), 'android', now);
  g.booking('e1', 'electric');
  assert.deepEqual(await claimWakeRecipients(g.db, now), []);
  // A reservation that is not yet due does not wake anybody.
  const h = fixture();
  h.driver('eqe-off', ['electric'], { online: 0 });
  await registerPushToken(h.db, 'eqe-off', token('y'), 'android', now);
  h.booking('r1', 'electric', 'reserved');
  assert.deepEqual(await claimWakeRecipients(h.db, now), []);
  // A driver busy with a ride is not asked to go online.
  h.booking('e1', 'electric');
  h.booking('busy', 'electric', 'riding', 'eqe-off');
  assert.deepEqual(await claimWakeRecipients(h.db, now), []);
});

test('without configuration the push is a silent no-op that touches nothing', async () => {
  const f = fixture();
  f.driver('eqe-off', ['electric'], { online: 0 });
  await registerPushToken(f.db, 'eqe-off', token('a'), 'android', now);
  f.booking('e1', 'electric');
  const p = provider();
  for (const partial of [
    {},
    { FCM_PROJECT_ID: 'luxore-test' },
    { ...env, FCM_PRIVATE_KEY: '' },
    { ...env, FCM_PRIVATE_KEY: 'not a key' },
    { ...env, FCM_CLIENT_EMAIL: ' ' },
  ]) {
    assert.equal(pushConfig(partial), null);
    assert.deepEqual(
      await wakeOfflineDrivers(f.db, now, { env: partial, fetch: p.request }),
      { configured: false, sent: 0, failed: 0, removed: 0 },
    );
  }
  assert.equal(p.calls.length, 0);
  assert.equal(f.tokens()[0].last_wake_at, null);
});

test('configured push sends a signed FCM v1 request without customer data and removes dead tokens', async () => {
  forgetPushAccess();
  const f = fixture();
  f.driver('alive', ['electric'], { online: 0 });
  f.driver('gone', ['electric'], { online: 0 });
  f.driver('flaky', ['electric'], { online: 0 });
  for (const id of ['alive', 'gone', 'flaky'])
    await registerPushToken(f.db, id, token(id), 'android', now);
  f.booking('e1', 'electric');
  f.sqlite
    .prepare(
      "UPDATE mobility_bookings SET rider_name='Secret Rider',rider_phone='+49 111 222' WHERE id='e1'",
    )
    .run();
  const p = provider((t) =>
    t === token('gone') ? 404 : t === token('flaky') ? 503 : 200,
  );
  const result = await wakeOfflineDrivers(f.db, now, {
    env,
    fetch: p.request,
  });
  assert.deepEqual(result, {
    configured: true,
    sent: 1,
    failed: 2,
    removed: 1,
  });
  const [auth, ...sends] = p.calls;
  assert.equal(auth.url, 'https://oauth2.googleapis.com/token');
  const assertion = new URLSearchParams(auth.body).get('assertion')!;
  const [head, claims, signature] = assertion.split('.');
  const verify = createVerify('RSA-SHA256');
  verify.update(head + '.' + claims);
  assert.equal(verify.verify(publicKey, signature, 'base64url'), true);
  const parsed = JSON.parse(Buffer.from(claims, 'base64url').toString());
  assert.equal(parsed.iss, env.FCM_CLIENT_EMAIL);
  assert.equal(
    parsed.scope,
    'https://www.googleapis.com/auth/firebase.messaging',
  );
  assert.equal(parsed.exp - parsed.iat, 3600);
  assert.equal(sends.length, 3);
  for (const send of sends) {
    assert.equal(
      send.url,
      'https://fcm.googleapis.com/v1/projects/luxore-test/messages:send',
    );
    assert.equal(send.auth, 'Bearer access');
    assert.doesNotMatch(send.body, /Secret|111 222|50\.11|electric|3220/);
    assert.equal(JSON.parse(send.body).message.notification.body, WAKE_BODY);
  }
  assert.equal(WAKE_BODY, 'Eine Fahrtanfrage wartet. Bitte online gehen.');
  assert.equal(wakeMessage('t').message.android.priority, 'HIGH');
  // The unregistered token is gone; the others stay locked for ten minutes.
  assert.deepEqual(
    f.tokens().map((t) => [t.driver_id, t.last_wake_at]),
    [
      ['alive', now],
      ['flaky', now],
    ],
  );
  const again = await wakeOfflineDrivers(f.db, now + 60000, {
    env,
    fetch: p.request,
  });
  assert.deepEqual(again, {
    configured: true,
    sent: 0,
    failed: 0,
    removed: 0,
  });
  assert.equal(p.calls.length, 4);
  assert.equal((await serviceJwt(pushConfig(env)!, now)).split('.').length, 3);
});

test('a failing provider never throws into the booking path', async () => {
  forgetPushAccess();
  const f = fixture();
  f.driver('off', ['electric'], { online: 0 });
  await registerPushToken(f.db, 'off', token('a'), 'android', now);
  f.booking('e1', 'electric');
  const errors: unknown[] = [];
  const original = console.error;
  console.error = (...args: unknown[]) => errors.push(args);
  try {
    const result = await wakeOfflineDrivers(f.db, now, {
      env,
      fetch: (async () => {
        throw new Error('offline');
      }) as unknown as typeof fetch,
    });
    assert.deepEqual(result, {
      configured: true,
      sent: 0,
      failed: 0,
      removed: 0,
    });
  } finally {
    console.error = original;
  }
  assert.equal(errors.length, 1);
  assert.doesNotMatch(JSON.stringify(errors), /fcm-token|PRIVATE KEY/);
});
