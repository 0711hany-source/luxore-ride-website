import './support/tsx-loader.mjs';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
const require = createRequire(
  new URL('../mobile/package.json', import.meta.url),
);
const modules = new Map(
  ['react', 'react/jsx-runtime', 'react-test-renderer'].map((n) => [
    n,
    pathToFileURL(require.resolve(n)).href,
  ]),
);
const stubs = new Map([
  [
    'react-native',
    "export const ActivityIndicator='ActivityIndicator',View='View',Text='Text',Pressable='Pressable',StyleSheet={create:v=>v};",
  ],
  [
    'lucide-react-native',
    "export const CarFront='CarFront',LocateFixed='LocateFixed';",
  ],
  [
    'react-native-svg',
    "export default 'Svg';export const Defs='Defs',LinearGradient='LinearGradient',Path='Path',Stop='Stop';",
  ],
  [
    '@rnmapbox/maps',
    "export default {MapView:'NativeMap',Camera:'Camera',FillExtrusionLayer:'Extrusion',PointAnnotation:'Annotation',MarkerView:'Marker',ShapeSource:'Source',LineLayer:'Line',setAccessToken:async()=>{globalThis.mapInitAttempts++;if(globalThis.mapInitAttempts===1)throw Error('SDK unavailable');},setTelemetryEnabled:()=>{globalThis.mapTelemetryCalls++;}};",
  ],
]);
registerHooks({
  resolve(name, context, next) {
    if (modules.has(name))
      return { url: modules.get(name), shortCircuit: true };
    if (stubs.has(name))
      return {
        url: 'data:text/javascript,' + encodeURIComponent(stubs.get(name)),
        shortCircuit: true,
      };
    return next(name, context);
  },
});
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
globalThis.mapInitAttempts = 0;
globalThis.mapTelemetryCalls = 0;
const React = await import('react');
const { default: Renderer, act } = await import('react-test-renderer');
const { default: NativeCustomerMap } =
  await import('../mobile/src/NativeCustomerMapView.tsx');
async function settle() {
  for (let i = 0; i < 4; i++)
    await act(async () => {
      await new Promise((r) => setImmediate(r));
    });
}
test('native initialization failure replaces indefinite loading with a visible retry; retry can mount the map', async () => {
  let root;
  try {
    await act(async () => {
      root = Renderer.create(
        React.createElement(NativeCustomerMap, {
          token: 'pk.' + 'a'.repeat(30),
          bookingId: 'trip-test',
          route: {
            pickup: { lat: 50.11, lng: 8.68 },
            destination: { lat: 50.04, lng: 8.56 },
            geometry: {
              type: 'LineString',
              coordinates: [
                [8.68, 50.11],
                [8.56, 50.04],
              ],
            },
          },
          driver: null,
          nearby: [],
          active: true,
        }),
      );
    });
    await settle();
    assert.match(JSON.stringify(root.toJSON()), /Karte erneut starten/);
    assert.doesNotMatch(JSON.stringify(root.toJSON()), /wird vorbereitet/);
    assert.equal(globalThis.mapTelemetryCalls, 0);
    assert.equal(root.root.findAllByType('NativeMap').length, 0);
    await act(async () => root.root.findByType('Pressable').props.onPress());
    await settle();
    assert.equal(globalThis.mapInitAttempts, 2);
    assert.equal(globalThis.mapTelemetryCalls, 1);
    assert.equal(root.root.findAllByType('NativeMap').length, 1);
  } finally {
    if (root) await act(async () => root.unmount());
  }
});
