import test from 'node:test';
import assert from 'node:assert/strict';
import { MapStartup } from '../mobile/src/map-startup.ts';
const token = 'pk.' + 'a'.repeat(30);
function deferred() {
  let resolve!: () => void;
  const promise = new Promise<void>((r) => {
    resolve = r;
  });
  return { promise, resolve };
}
void test('native telemetry never constructs a map before the access token completes', async () => {
  const events: string[] = [],
    ready = deferred();
  const startup = new MapStartup({
    setAccessToken: async () => {
      events.push('token');
      await ready.promise;
      events.push('ready');
    },
    setTelemetryEnabled: (enabled) => {
      assert.equal(enabled, false);
      events.push('telemetry');
    },
  });
  const result = startup.prepare(token, () => true);
  await Promise.resolve();
  assert.deepEqual(events, ['token']);
  ready.resolve();
  assert.equal(await result, true);
  assert.deepEqual(events, ['token', 'ready', 'telemetry']);
  assert.equal(await startup.prepare(token, () => true), true);
  assert.equal(events.length, 3);
});
void test('unmounted views do not construct telemetry views and later mounts can retry', async () => {
  let mounted = true,
    count = 0;
  const ready = deferred();
  const startup = new MapStartup({
    setAccessToken: () => ready.promise,
    setTelemetryEnabled: () => {
      count++;
    },
  });
  const first = startup.prepare(token, () => mounted);
  await Promise.resolve();
  mounted = false;
  ready.resolve();
  assert.equal(await first, false);
  assert.equal(count, 0);
  assert.equal(await startup.prepare(token, () => true), true);
  assert.equal(count, 1);
});
void test('failed token initialization is recoverable without telemetry or a poisoned queue', async () => {
  let fail = true,
    count = 0;
  const startup = new MapStartup({
    setAccessToken: async () => {
      if (fail) throw Error('native init failed');
    },
    setTelemetryEnabled: () => {
      count++;
    },
  });
  await assert.rejects(
    startup.prepare(token, () => true),
    /native init failed/,
  );
  assert.equal(count, 0);
  fail = false;
  assert.equal(await startup.prepare(token, () => true), true);
  assert.equal(count, 1);
});
void test('changing tokens serializes native UI initialization; invalid or canceled attempts skip SDK', async () => {
  const events: string[] = [],
    ready = deferred(),
    second = token + 'b';
  const startup = new MapStartup({
    setAccessToken: async (t) => {
      events.push(t);
      if (t === token) await ready.promise;
    },
    setTelemetryEnabled: () => {
      events.push('telemetry');
    },
  });
  await assert.rejects(
    startup.prepare('sk.invalid', () => true),
    /Kartenzugang/,
  );
  assert.equal(await startup.prepare(token, () => false), false);
  assert.equal(events.length, 0);
  const a = startup.prepare(token, () => true),
    b = startup.prepare(second, () => true);
  await Promise.resolve();
  assert.deepEqual(events, [token]);
  ready.resolve();
  assert.equal(await a, true);
  assert.equal(await b, true);
  assert.deepEqual(events, [token, 'telemetry', second, 'telemetry']);
});

void test('canceling a different token does not reuse a stale ready flag for the previous token', async () => {
  const events: string[] = [],
    pending = deferred(),
    second = token + 'b';
  let mounted = true;
  const startup = new MapStartup({
    setAccessToken: async (t) => {
      events.push(t);
      if (t === second) await pending.promise;
    },
    setTelemetryEnabled: () => events.push('telemetry'),
  });
  await startup.prepare(token, () => true);
  const change = startup.prepare(second, () => mounted);
  await Promise.resolve();
  mounted = false;
  pending.resolve();
  assert.equal(await change, false);
  assert.equal(await startup.prepare(token, () => true), true);
  assert.deepEqual(events, [token, 'telemetry', second, token, 'telemetry']);
});
