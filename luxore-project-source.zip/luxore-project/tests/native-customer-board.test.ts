import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CustomerBoardController,
  type BoardRequest,
  type BoardStore,
} from '../mobile/src/customer-board.ts';
import {
  emptyOrder,
  cartPrice,
  combined,
} from '../lib/mobility/refreshments.ts';
import type { Booking } from '../lib/mobility/domain.ts';
const booking = {
  id: 'ride',
  owner_id: 'owner',
  updated_at: 1,
  status: 'riding',
  service: 'premium',
  payment_status: 'unpaid',
  price: 1500,
  refreshments: emptyOrder(),
} as Booking;
function fixture() {
  let saved: BoardRequest | null = null;
  const writes: BoardRequest[] = [];
  const store: BoardStore = {
    load: async () => saved,
    save: async (b) => {
      saved = structuredClone(b);
    },
    clear: async () => {
      saved = null;
    },
  };
  const send = async (body: BoardRequest): Promise<Booking> => {
    assert.deepEqual(saved, body);
    writes.push(structuredClone(body));
    return {
      ...booking,
      updated_at: 2,
      refreshments: {
        ...emptyOrder(),
        revision: 1,
        requested: body.cart,
        lastRequest: { id: body.requestId, fingerprint: 'f'.repeat(64) },
      },
    };
  };
  const controller = () =>
    new CustomerBoardController(
      'owner',
      booking,
      store,
      (b) => api.send(b),
      () => 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
    );
  const api = { send };
  return {
    c: controller(),
    controller,
    store,
    api,
    writes,
    saved: () => saved,
  };
}
async function ready(f: ReturnType<typeof fixture>) {
  await f.c.restore();
  f.c.receive(booking, true, true);
}
void test('native board persists before send and only confirmed matching trip acknowledges it', async () => {
  const f = fixture();
  await ready(f);
  f.c.edit('water', 3);
  await f.c.submit();
  assert.deepEqual(f.writes[0].cart, { water: 3 });
  assert.equal(f.c.getSnapshot().confirmed, true);
  assert.equal(f.saved(), null);
  assert.equal(cartPrice(f.c.getSnapshot().cart, 'premium'), 250);
});
void test('lost response survives restart and repeats exact revision/cart/ID without new draft', async () => {
  const f = fixture();
  await ready(f);
  f.c.edit('energy', 1);
  f.api.send = async (b) => {
    f.writes.push(structuredClone(b));
    throw new Error('lost');
  };
  await f.c.submit();
  const pending = structuredClone(f.saved()!);
  f.c.edit('water', 1);
  assert.deepEqual(f.c.getSnapshot().cart, { energy: 1 });
  const reopened = f.controller();
  await reopened.restore();
  reopened.receive(booking, true, true);
  await reopened.submit();
  assert.deepEqual(f.writes, [pending, pending]);
  assert.deepEqual(f.saved(), pending);
});
void test('storage failure prevents transport; closing/background cannot abort confirmed write', async () => {
  const f = fixture();
  await ready(f);
  f.store.save = async () => {
    throw new Error('storage');
  };
  await f.c.submit();
  assert.equal(f.writes.length, 0);
  const g = fixture();
  await ready(g);
  let resolve!: (value: Booking) => void;
  g.api.send = () =>
    new Promise((r) => {
      resolve = r;
    });
  const task = g.c.submit();
  await new Promise((r) => setImmediate(r));
  g.c.receive(booking, false, false);
  const p = g.saved()!;
  resolve({
    ...booking,
    refreshments: {
      ...emptyOrder(),
      lastRequest: { id: p.requestId, fingerprint: 'a'.repeat(64) },
    },
  });
  await task;
  assert.equal(g.c.getSnapshot().confirmed, true);
  assert.equal(g.saved(), null);
});
void test('driver revision changes block stale draft and require explicit review; delivered quantities retain allowance', async () => {
  const f = fixture();
  await ready(f);
  f.c.edit('cola', 1);
  const newer = {
    ...booking,
    updated_at: 2,
    refreshments: {
      ...emptyOrder(),
      revision: 2,
      delivered: { water: 2 },
      requested: { cola: 1 },
    },
  };
  f.c.receive(newer, true, true);
  await f.c.submit();
  assert.equal(f.writes.length, 0);
  f.c.review();
  assert.equal(f.c.getSnapshot().revision, 2);
  assert.equal(
    cartPrice(
      combined(newer.refreshments.delivered, f.c.getSnapshot().cart),
      'premium',
    ),
    250,
  );
});
void test('definite conflicts unlock review; transport errors, wrong confirmations and clear errors retain pending body', async () => {
  for (const scenario of ['conflict', 'transport', 'mismatch', 'clear']) {
    const f = fixture();
    await ready(f);
    if (scenario === 'clear')
      f.store.clear = async () => {
        throw new Error('clear');
      };
    else
      f.api.send = async () => {
        if (scenario === 'mismatch') return { ...booking, id: 'other' };
        throw Object.assign(
          new Error(scenario),
          scenario === 'conflict' ? { status: 409 } : {},
        );
      };
    await f.c.submit();
    assert.equal(!!f.c.getSnapshot().pending, scenario !== 'conflict');
    assert.equal(f.c.getSnapshot().confirmed, false);
  }
});
void test('foreign, finished, offline, excessive and malformed persisted drafts never generate a new order', async () => {
  const f = fixture();
  await ready(f);
  f.c.receive({ ...booking, status: 'completed', updated_at: 2 }, true, true);
  await f.c.submit();
  assert.equal(f.writes.length, 0);
  const g = fixture();
  await ready(g);
  g.c.receive(booking, true, false);
  await g.c.submit();
  assert.equal(g.writes.length, 0);
  for (const cart of [
    { water: 13 },
    { water: 12, cola: 12, energy: 1 },
  ] as Record<string, number>[]) {
    const h = fixture();
    h.store.load = async () => ({
      id: 'other',
      action: 'request',
      revision: 0,
      cart,
      requestId: 'wrong',
    });
    await h.c.restore();
    h.c.receive(booking, true, true);
    await h.c.submit();
    assert.equal(h.writes.length, 0);
    assert.equal(h.c.getSnapshot().restoring, true);
  }
});
void test('same-millisecond stale poll cannot overwrite a confirmed board revision', async () => {
  const f = fixture();
  await ready(f);
  await f.c.submit();
  const saved = f.c.getSnapshot().booking;
  f.c.receive({ ...booking, updated_at: saved.updated_at }, true, true);
  assert.equal(f.c.getSnapshot().booking.refreshments?.revision, 1);
});
