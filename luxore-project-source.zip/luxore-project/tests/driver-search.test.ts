import { test } from 'node:test';
/* oxlint-disable typescript/no-floating-promises -- Node's test runner registers and awaits every top-level test. */
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import {
  driverSearchArea,
  DRIVER_SEARCH_RADIUS_METERS,
} from '../lib/mobility/driver-search.ts';
import { distance } from '../lib/mobility/domain.ts';

function circlePoint(pickup: { lat: number; lng: number }, bearing: number) {
  const radians = Math.PI / 180;
  const arc = (DRIVER_SEARCH_RADIUS_METERS - 1) / 6_371_000;
  const heading = bearing * radians;
  const latitude = pickup.lat * radians;
  const lat = Math.asin(
    Math.sin(latitude) * Math.cos(arc) +
      Math.cos(latitude) * Math.sin(arc) * Math.cos(heading),
  );
  const lng =
    pickup.lng * radians +
    Math.atan2(
      Math.sin(heading) * Math.sin(arc) * Math.cos(latitude),
      Math.cos(arc) - Math.sin(latitude) * Math.sin(lat),
    );
  return { lat: lat / radians, lng: ((lng / radians + 540) % 360) - 180 };
}

test('SQL search area retains the entire 50 km circle across German cities, dateline and polar pickups', () => {
  for (const pickup of [
    { lat: 52.52, lng: 13.405 },
    { lat: 48.137, lng: 11.575 },
    { lat: 53.55, lng: 9.993 },
    { lat: 47.27, lng: 10.18 },
    { lat: 0, lng: 179.9 },
    { lat: 0, lng: -179.9 },
    { lat: 89.8, lng: 60 },
    { lat: -89.8, lng: -60 },
  ]) {
    const sqlite = new DatabaseSync(':memory:');
    try {
      sqlite.exec('CREATE TABLE drivers(lat REAL,lng REAL)');
      const insert = sqlite.prepare('INSERT INTO drivers VALUES(?,?)');
      for (let bearing = 0; bearing < 360; bearing++) {
        const point = circlePoint(pickup, bearing);
        assert.ok(distance(pickup, point) < DRIVER_SEARCH_RADIUS_METERS);
        insert.run(point.lat, point.lng);
      }
      const area = driverSearchArea(pickup);
      const row = sqlite
        .prepare(`SELECT count(*) n FROM drivers d WHERE ${area.sql}`)
        .get(...area.parameters)!;
      assert.equal(row.n, 360, JSON.stringify(pickup));
    } finally {
      sqlite.close();
    }
  }
});

test('SQL area excludes other German cities before candidates are loaded', () => {
  const sqlite = new DatabaseSync(':memory:');
  try {
    sqlite.exec('CREATE TABLE drivers(name TEXT,lat REAL,lng REAL)');
    const insert = sqlite.prepare('INSERT INTO drivers VALUES(?,?,?)');
    insert.run('Berlin', 52.52, 13.405);
    insert.run('Frankfurt', 50.11, 8.68);
    insert.run('Hamburg', 53.55, 9.993);
    insert.run('Munich', 48.137, 11.575);
    const area = driverSearchArea({ lat: 52.52, lng: 13.405 });
    assert.deepEqual(
      sqlite
        .prepare(`SELECT name FROM drivers d WHERE ${area.sql}`)
        .all(...area.parameters)
        .map((row) => row.name),
      ['Berlin'],
    );
  } finally {
    sqlite.close();
  }
});
