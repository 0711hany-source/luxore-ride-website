import { createClient } from '@libsql/client';
import { readdirSync, readFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { databaseConnection } from '../db/connection.mjs';
if (existsSync('.env.local')) process.loadEnvFile('.env.local');
const connection = databaseConnection();
if (!connection) throw new Error('Configure DATABASE_URL or TURSO_DATABASE_URL before running migrations.');
const client = createClient(connection);
try {
  await client.execute('CREATE TABLE IF NOT EXISTS _luxore_migrations(name TEXT PRIMARY KEY,hash TEXT NOT NULL,applied_at INTEGER NOT NULL)');
  for (const name of readdirSync('drizzle').filter((p) => p.endsWith('.sql')).sort()) {
    const sql = readFileSync('drizzle/' + name, 'utf8');
    const hash = createHash('sha256').update(sql).digest('hex');
    const applied = (await client.execute({sql:'SELECT hash FROM _luxore_migrations WHERE name=?',args:[name]})).rows[0];
    if (applied) {
      if (applied.hash !== hash) throw new Error('Previously applied migration changed: ' + name);
      continue;
    }
    const tx = await client.transaction('write');
    try {
      await tx.executeMultiple(sql);
      await tx.execute({sql:'INSERT INTO _luxore_migrations VALUES(?,?,?)',args:[name,hash,Date.now()]});
      await tx.commit();
    } finally { tx.close(); }
    console.log('Applied migration ' + name);
  }
} finally { client.close(); }
