// Import a complete, privately exported SQLite snapshot into an empty target.
// Never use a truncated table preview as the migration source.
import { DatabaseSync } from 'node:sqlite';
import { createClient } from '@libsql/client';
import { existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { databaseConnection } from '../db/connection.mjs';
if(existsSync('.env.local'))process.loadEnvFile('.env.local');
const path=process.argv[2];
const connection=databaseConnection();
if(!path||!existsSync(path)||!connection)throw new Error('Provide a private SQLite snapshot and target DATABASE_URL or TURSO_DATABASE_URL.');
const source=new DatabaseSync(path,{readOnly:true});
const target=createClient({...connection,intMode:'bigint'});
let tx;
const quoted=(s)=>{if(!/^[a-zA-Z0-9_]+$/.test(s))throw new Error('Unexpected SQL identifier');return '"'+s+'"';};
const tableQuery="SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '\\_%' ESCAPE '\\' ORDER BY name";
// Typed cells prevent a rounded 64-bit integer or altered text/blob from
// appearing equal. SQL hex projection avoids a local driver's NUL text
// truncation when reading back a correctly stored string.
const cell=(value)=>{
  if(value===null)return ['null'];
  if(typeof value==='bigint')return ['integer',value.toString()];
  if(typeof value==='number')return ['real',value];
  if(typeof value==='string')return ['text',value];
  if(value instanceof ArrayBuffer)return ['blob',Buffer.from(value).toString('base64')];
  if(ArrayBuffer.isView(value))return ['blob',Buffer.from(value.buffer,value.byteOffset,value.byteLength).toString('base64')];
  throw new Error('Unsupported snapshot value type');
};
const digest=(rows,columns)=>{
  const hash=createHash('sha256');
  hash.update(JSON.stringify(columns)+'\n');
  for(const row of rows)hash.update(JSON.stringify(columns.map((_,i)=>[row['_luxore_type_'+i],cell(row['_luxore_value_'+i])]))+'\n');
  return hash.digest('hex');
};
try{
  // One read transaction keeps the complete source consistent, including when
  // a mistakenly supplied live SQLite file still has another writer.
  source.exec('BEGIN');
  if(source.prepare('PRAGMA quick_check').all().some(r=>r.quick_check!=='ok'))throw new Error('Snapshot integrity check failed.');
  const sourceNames=new Set(source.prepare(tableQuery).all().map(r=>String(r.name)));
  tx=await target.transaction('write');
  const tables=(await tx.execute(tableQuery)).rows.map(r=>String(r.name));
  if(!tables.includes('mobility_accounts'))throw new Error('Apply target migrations before importing.');
  for(const table of sourceNames)if(!tables.includes(table))throw new Error('Unsupported snapshot table: '+table+'; refusing to discard data.');
  const metadata=new Map();
  for(const table of tables){
    const count=(await tx.execute('SELECT COUNT(*) n FROM '+quoted(table))).rows[0].n;
    if(Number(count)!==0)throw new Error('Target is not empty: '+table+'; refusing to overwrite or merge.');
    if(!sourceNames.has(table))throw new Error('Incomplete snapshot: '+table);
    const info=(await tx.execute('PRAGMA table_info('+quoted(table)+')')).rows;
    const columns=info.map(r=>String(r.name));
    const sourceColumns=source.prepare('PRAGMA table_info('+quoted(table)+')').all().map(r=>String(r.name));
    if(columns.length!==sourceColumns.length||columns.some(c=>!sourceColumns.includes(c)))throw new Error('Snapshot column mismatch: '+table+'; refusing to discard or invent fields.');
    const keys=info.filter(r=>Number(r.pk)>0).sort((a,b)=>Number(a.pk)-Number(b.pk)).map(r=>String(r.name));
    if(!keys.length)throw new Error('Table has no stable primary key: '+table);
    const suffix=' FROM '+quoted(table)+' ORDER BY '+keys.map(quoted).join(',');
    const verification='SELECT '+columns.flatMap((c,i)=>[
      'typeof('+quoted(c)+') AS "_luxore_type_'+i+'"',
      'CASE WHEN typeof('+quoted(c)+") IN ('text','blob') THEN hex("+quoted(c)+') ELSE '+quoted(c)+' END AS "_luxore_value_'+i+'"',
    ]).join(',')+suffix;
    metadata.set(table,{columns,select:'SELECT '+columns.map(quoted).join(',')+suffix,verification});
  }
  const totals=[];
  for(const table of tables){
    const {columns,select,verification}=metadata.get(table);
    const insert='INSERT INTO '+quoted(table)+'('+columns.map(quoted).join(',')+') VALUES(';
    const statement=source.prepare(select);
    statement.setReadBigInts(true);
    const rows=statement.all();
    for(const row of rows)await tx.execute({
      // Bind text as bytes and cast inside SQLite, keeping embedded NULs intact.
      sql:insert+columns.map(c=>typeof row[c]==='string'?'CAST(? AS TEXT)':'?').join(',')+')',
      args:columns.map(c=>typeof row[c]==='string'?Buffer.from(row[c],'utf8'):row[c]),
    });
    const sourceVerification=source.prepare(verification);sourceVerification.setReadBigInts(true);
    const copied=(await tx.execute(verification)).rows;
    const checksum=digest(sourceVerification.all(),columns);
    if(copied.length!==rows.length||digest(copied,columns)!==checksum)throw new Error('Snapshot content mismatch: '+table+'; transaction rolled back.');
    totals.push({table,rows:copied.length,sha256:checksum});
  }
  // Old online state is not a proof of a fresh location on the new server.
  await tx.execute("UPDATE mobility_drivers SET online=0,session_id=NULL,lat=NULL,lng=NULL,accuracy=NULL");
  await tx.execute("UPDATE mobility_offers SET status='expired' WHERE status='pending'");
  await tx.commit();
  console.log(JSON.stringify({imported:totals,verified:'Typed contents before deliberate online/offer reset.',booking_activation:'Still disabled until fleet, identity and booking checks pass.'}));
}finally{tx?.close();source.close();target.close();}
