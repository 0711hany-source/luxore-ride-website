// Import a complete, privately exported SQLite snapshot into an empty target.
// Never use a truncated table preview as the migration source.
import { DatabaseSync } from 'node:sqlite';
import { createClient } from '@libsql/client';
import { existsSync } from 'node:fs';
if(existsSync('.env.local'))process.loadEnvFile('.env.local');
const path=process.argv[2];
if(!path||!existsSync(path)||!process.env.DATABASE_URL)throw new Error('Provide a private SQLite snapshot and target DATABASE_URL.');
const source=new DatabaseSync(path,{readOnly:true});
const target=createClient({url:process.env.DATABASE_URL,authToken:process.env.DATABASE_AUTH_TOKEN,intMode:'number'});
let tx;
const quoted=(s)=>{if(!/^[a-zA-Z0-9_]+$/.test(s))throw new Error('Unexpected SQL identifier');return '"'+s+'"';};
try{
  const tables=(await target.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '\\_%' ESCAPE '\\'")).rows.map(r=>String(r.name));
  if(!tables.includes('mobility_accounts'))throw new Error('Apply target migrations before importing.');
  const sourceNames=new Set(source.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(r=>r.name));
  tx=await target.transaction('write');
  for(const table of tables){
    const count=(await tx.execute('SELECT COUNT(*) n FROM '+quoted(table))).rows[0].n;
    if(Number(count)!==0)throw new Error('Target is not empty: '+table+'; refusing to overwrite or merge.');
  }
  const totals=[];
  for(const table of tables){
    if(!sourceNames.has(table))throw new Error('Incomplete snapshot: '+table);
    const columns=(await tx.execute('PRAGMA table_info('+quoted(table)+')')).rows.map(r=>String(r.name));
    const sql='INSERT INTO '+quoted(table)+'('+columns.map(quoted).join(',')+') VALUES('+columns.map(()=>'?').join(',')+')';
    const rows=source.prepare('SELECT '+columns.map(quoted).join(',')+' FROM '+quoted(table)).all();
    for(const row of rows)await tx.execute({sql,args:columns.map(c=>row[c])});
    const count=Number((await tx.execute('SELECT COUNT(*) n FROM '+quoted(table))).rows[0].n);
    if(count!==rows.length)throw new Error('Count mismatch: '+table);
    totals.push({table,rows:count});
  }
  // Old online state is not a proof of a fresh location on the new server.
  await tx.execute("UPDATE mobility_drivers SET online=0,session_id=NULL,lat=NULL,lng=NULL,accuracy=NULL");
  await tx.execute("UPDATE mobility_offers SET status='expired' WHERE status='pending'");
  await tx.commit();
  console.log(JSON.stringify({imported:totals,booking_activation:'Still disabled until fleet, identity and booking checks pass.'}));
}finally{tx?.close();source.close();target.close();}
