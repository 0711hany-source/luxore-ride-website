#!/usr/bin/env node
// Lokaler Testzugang: legt Testkonten in der LOKALEN Datei-Datenbank an und
// schreibt pro Konto eine Sitzung, genau wie app/api/mobility/account (verify)
// sie nach erfolgreicher Code-Prüfung anlegt. Es wird nichts an app/ oder lib/
// geändert und keine Anmelderegel umgangen: ohne dieses Skript bleibt alles wie
// bisher. Aufruf: node scripts/seed-local-test-accounts.mjs
import { createHash, randomBytes } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createClient } from '@libsql/client';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const stop = (message) => {
  console.error('ABBRUCH: ' + message);
  process.exit(1);
};

function readEnvFile(name) {
  const file = resolve(root, name);
  if (!existsSync(file)) return {};
  const out = {};
  for (const line of readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = /^\s*(?:export\s+)?([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
    if (m) out[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
  return out;
}
const fileEnv = { ...readEnvFile('.env'), ...readEnvFile('.env.local') };
const env = (key) => process.env[key] ?? fileEnv[key];

if (process.env.NODE_ENV === 'production')
  stop('NODE_ENV=production ist gesetzt. Dieses Skript läuft nur lokal.');
if (process.env.VERCEL) stop('VERCEL ist gesetzt. Dieses Skript läuft nur lokal.');
const databaseUrl = (env('DATABASE_URL') || '').trim();
if (!databaseUrl.startsWith('file:'))
  stop(
    'DATABASE_URL fehlt oder beginnt nicht mit "file:". Es wird keine entfernte Datenbank angefasst.',
  );
const filePath = databaseUrl.replace(/^file:(\/\/)?/, '');
const absolute = resolve(root, filePath);
if (!existsSync(absolute)) stop('Die lokale Datenbankdatei existiert nicht: ' + absolute);

// Gleiche Funktion wie tokenHash in lib/mobility/server.ts (SHA-256, hex).
const tokenHash = (token) => createHash('sha256').update(token).digest('hex');
const randomToken = () => randomBytes(32).toString('hex'); // wie accounts.ts: 64 Hex-Zeichen

const adminEmail = (env('LUXORE_ADMIN_EMAIL') || '').trim().toLowerCase();
const accounts = [
  { key: 'betreiber', email: adminEmail || 'betreiber@example.test', name: 'Test Betreiber', phone: '+49 69 0000001', kind: 'fleet' },
  { key: 'flotte', email: 'flotte@example.test', name: 'Test Flottenbesitzer', phone: '+49 69 0000002', kind: 'fleet' },
  { key: 'fahrer', email: 'fahrer@example.test', name: 'Test Fahrer', phone: '+49 69 0000003', kind: 'driver' },
  { key: 'kunde', email: 'kunde@example.test', name: 'Test Kunde', phone: '+49 69 0000004', kind: 'customer' },
];
const FLEET_ID = 'fleet:local-test';
const VEHICLE_ID = 'vehicle:local-test';
const PLATE = 'F-LX 1001';

const db = createClient({ url: 'file:' + absolute });
const now = Date.now();
const expiresAt = now + 30 * 86400000;
const stable = (email) => 'account:local-test-' + createHash('sha256').update(email).digest('hex').slice(0, 16);

try {
  const tables = (await db.execute("SELECT name FROM sqlite_master WHERE type='table'")).rows.map((r) => r.name);
  for (const t of ['mobility_accounts', 'mobility_account_sessions', 'mobility_drivers', 'mobility_fleets', 'mobility_employees', 'mobility_vehicles'])
    if (!tables.includes(t)) stop('Tabelle fehlt (Migration ausführen): ' + t);

  const sessions = {};
  const ids = {};
  for (const a of accounts) {
    const existing = (await db.execute({ sql: 'SELECT id,status FROM mobility_accounts WHERE email=?', args: [a.email] })).rows[0];
    if (existing && existing.status !== 'active') stop('Konto ' + a.key + ' existiert, ist aber nicht aktiv. Nichts verändert.');
    const id = existing ? String(existing.id) : stable(a.email);
    ids[a.key] = id;
    if (!existing)
      await db.execute({
        sql: "INSERT INTO mobility_accounts(id,email,name,phone,kind,status,verified_at,created_at) VALUES(?,?,?,?,?,'active',?,?)",
        args: [id, a.email, a.name, a.phone, a.kind, now, now],
      });
    // Fahrer-/Flottenprofil wie bei der Registrierung (nicht freigegeben, offline).
    if (a.kind !== 'customer')
      await db.execute({
        sql: `INSERT INTO mobility_drivers(id,name,phone,vehicle,plate,service,services,approved,online) VALUES(?,?,?,'','','premium','["premium"]',0,0) ON CONFLICT(id) DO NOTHING`,
        args: [id, a.name, a.phone],
      });
  }

  // Flotte (wie createFleet): Besitzer bekommt Mitarbeiterzeile + Flotte.
  await db.execute({
    sql: "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,?,?,NULL,'staff',?) ON CONFLICT(user_id) DO NOTHING",
    args: [ids.flotte, 'Test Flottenbesitzer', '+49 69 0000002', now],
  });
  const fleet = (await db.execute({ sql: 'SELECT id FROM mobility_fleets WHERE owner_id=?', args: [ids.flotte] })).rows[0];
  const fleetId = fleet ? String(fleet.id) : FLEET_ID;
  if (!fleet) {
    await db.execute({ sql: 'INSERT INTO mobility_fleets(id,name,owner_id,created_at) VALUES(?,?,?,?)', args: [fleetId, 'Test-Flotte (lokal)', ids.flotte, now] });
    await db.execute({ sql: 'UPDATE mobility_employees SET fleet_id=? WHERE user_id=?', args: [fleetId, ids.flotte] });
  }
  // Fahrer gehört zur Flotte (Mitarbeiterzeile) und hat ein Business-Fahrzeug.
  await db.execute({
    sql: "INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at) VALUES(?,?,?,?,'staff',?) ON CONFLICT(user_id) DO UPDATE SET fleet_id=excluded.fleet_id",
    args: [ids.fahrer, 'Test Fahrer', '+49 69 0000003', fleetId, now],
  });
  const veh = (await db.execute({ sql: 'SELECT id FROM mobility_vehicles WHERE fleet_id=? AND plate=? AND status=?', args: [fleetId, PLATE, 'active'] })).rows[0];
  const vehicleId = veh ? String(veh.id) : VEHICLE_ID;
  if (!veh)
    await db.execute({
      sql: "INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at) VALUES(?,?,?,?,?,'active',?)",
      args: [vehicleId, fleetId, 'Mercedes E-Klasse', PLATE, '["premium"]', now],
    });
  // Freigabe + Zuordnung, nur wenn der Fahrer gerade im Ruhezustand ist.
  await db.execute({
    sql: `UPDATE mobility_drivers SET approved=1,vehicle_id=?,vehicle='Mercedes E-Klasse',plate=?,service='premium',services='["premium"]'
          WHERE id=? AND online=0 AND session_id IS NULL
          AND NOT EXISTS(SELECT 1 FROM mobility_drivers o WHERE o.vehicle_id=? AND o.id<>?)`,
    args: [vehicleId, PLATE, ids.fahrer, vehicleId, ids.fahrer],
  });

  // Sitzungen: je Lauf neues Token, alte Test-Sitzungen dieser Konten ersetzen.
  for (const a of accounts) {
    const token = randomToken();
    await db.batch(
      [
        { sql: 'DELETE FROM mobility_account_sessions WHERE account_id=?', args: [ids[a.key]] },
        { sql: 'INSERT INTO mobility_account_sessions(token_hash,account_id,expires_at,verified_at) VALUES(?,?,?,?)', args: [tokenHash(token), ids[a.key], expiresAt, now] },
      ],
      'write',
    );
    sessions[a.key] = token;
  }

  const out = resolve(root, 'work/local-test-sessions.json');
  mkdirSync(dirname(out), { recursive: true });
  const file = {
    hinweis: 'Nur lokal (http://localhost). Cookie-Name luxore_account, Pfad /. Nicht weitergeben, nicht committen.',
    gueltigBis: new Date(expiresAt).toISOString(),
    konten: Object.fromEntries(
      accounts.map((a) => [
        a.key,
        {
          // Die Betreiber-Adresse stammt aus .env.local und wird bewusst nicht gespeichert.
          email: a.key === 'betreiber' && adminEmail ? '(aus LUXORE_ADMIN_EMAIL)' : a.email,
          cookie: 'luxore_account=' + sessions[a.key],
          browserKonsole: `document.cookie='luxore_account=${sessions[a.key]}; path=/; max-age=2592000'; location.reload()`,
          curl: `curl -H 'Authorization: Bearer ${sessions[a.key]}' http://localhost:3100/api/mobility/account`,
        },
      ]),
    ),
  };
  writeFileSync(out, JSON.stringify(file, null, 2) + '\n', { mode: 0o600 });
  console.log('Fertig. Testkonten: ' + accounts.map((a) => a.key).join(', '));
  console.log('Sitzungen (30 Tage) stehen in: work/local-test-sessions.json');
  console.log('Im Browser auf http://localhost öffnen, Konsole (Cmd+Alt+J), Zeile "browserKonsole" des Kontos einfügen.');
} finally {
  db.close();
}
