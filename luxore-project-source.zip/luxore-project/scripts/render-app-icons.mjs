// Editable local vector artwork; no font, generator service or remote asset dependency.
import { createRequire } from 'node:module';
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const require = createRequire(import.meta.resolve('next/package.json'));
const sharp = require('sharp');
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = resolve(root, 'mobile/assets');
const source = resolve(output, 'source');
mkdirSync(source, { recursive: true });
// One silhouette for both variants, entirely within the adaptive icon's safe circle.
const letter =
  'M302 274H566V292H529C512 292 503 303 503 326V670H584C653 670 694 639 730 580H747L724 750H302V732H331C354 732 365 720 365 697V326C365 303 354 292 331 292H302Z';
const road =
  'M479 727C578 717 678 671 735 600L730 625C677 688 585 724 515 733Z';
function svg(variant, foreground = false, mono = false) {
  const driver = variant === 'driver';
  const background = driver ? '#e4cba0' : '#11151c';
  const fill = mono ? '#fff' : driver ? '#171c24' : 'url(#champagne)';
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="1024" height="1024">
<defs><linearGradient id="champagne" x1="0" y1="0" x2=".5" y2="1"><stop stop-color="#f2ddba"/><stop offset=".55" stop-color="#d8b57c"/><stop offset="1" stop-color="#b58a4c"/></linearGradient><linearGradient id="surface" x2=".6" y2="1"><stop stop-color="${driver ? '#ecdbbe' : '#202733'}"/><stop offset="1" stop-color="${background}"/></linearGradient><mask id="monogram"><path d="${letter}" fill="white"/><path d="${road}" fill="black"/></mask></defs>
${foreground ? '' : '<rect width="1024" height="1024" fill="url(#surface)"/>'}
<g transform="translate(30.72 30.72) scale(.94)"><path d="${letter}" fill="${fill}" mask="url(#monogram)"/></g>
</svg>`;
}
for (const variant of ['ride', 'driver']) {
  const full = svg(variant),
    adaptive = svg(variant, true);
  writeFileSync(resolve(source, `icon-${variant}.svg`), full);
  writeFileSync(resolve(source, `icon-${variant}-adaptive.svg`), adaptive);
  await sharp(Buffer.from(full))
    .flatten({ background: variant === 'ride' ? '#11151c' : '#e4cba0' })
    .png()
    .toFile(resolve(output, `icon-${variant}.png`));
  await sharp(Buffer.from(adaptive))
    .png()
    .toFile(resolve(output, `icon-${variant}-adaptive.png`));
  await sharp(Buffer.from(full))
    .flatten()
    .png()
    .toFile(resolve(root, `public/brand/icon-${variant}.png`));
}
const monochrome = svg('ride', true, true);
writeFileSync(resolve(source, 'icon-monochrome.svg'), monochrome);
await sharp(Buffer.from(monochrome))
  .png()
  .toFile(resolve(output, 'icon-monochrome.png'));
writeFileSync(
  resolve(root, 'public/favicon.svg'),
  svg('ride').replace('width="1024" height="1024"', 'width="64" height="64"'),
);
console.log(
  'Rendered opaque 1024px app icons, transparent adaptive foregrounds and monochrome layer.',
);
