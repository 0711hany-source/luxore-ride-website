"""Export the public landing page for the existing static GitHub/Vercel site.

The booking application and its database stay on their existing origin. This
export deliberately contains no hydration bundle, sessions or admin data.
"""
import argparse
import html
import json
from html.parser import HTMLParser
from pathlib import Path
import re
import shutil
from urllib.request import urlopen

APP_ORIGIN = 'https://luxore-ride-frankfurt.lucky-goose-6238.chatgpt.site'
ROOT = Path(__file__).resolve().parents[1]


class PublicDocument(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.parts = []
        self.in_script = False

    def handle_decl(self, decl):
        self.parts.append(f'<!{decl}>')

    def handle_starttag(self, tag, attrs):
        if tag == 'script':
            self.in_script = True
            return
        if self.in_script:
            return
        values = dict(attrs)
        if tag == 'link' and values.get('rel') in ('stylesheet', 'modulepreload'):
            return
        cleaned = []
        for key, value in attrs:
            if key.startswith('data-rsc') or key.startswith('on'):
                continue
            if key == 'href' and value:
                if value.startswith(('/mobile/', '/konto', '/ride', '/disposition', '/betreiber', '/app-ansichten')):
                    value = APP_ORIGIN + value
                elif value == '/impressum':
                    value = '/impressum.html'
                elif value == '/datenschutz':
                    value = '/datenschutz.html'
                elif value == '/hilfe':
                    value = '/hilfe.html'
            if key in ('src', 'href') and value and value.startswith('/brand/'):
                value = '/luxore-' + value.rsplit('/', 1)[-1]
            cleaned.append(key if value is None else f'{key}="{html.escape(value, quote=True)}"')
        self.parts.append('<' + tag + (' ' + ' '.join(cleaned) if cleaned else '') + '>')

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag):
        if tag == 'script':
            self.in_script = False
            return
        if self.in_script:
            return
        if tag == 'head':
            self.parts.append('<link rel="stylesheet" href="/luxore-premium.css">'
                              '<link rel="icon" href="/luxore-favicon.svg" type="image/svg+xml">')
        self.parts.append(f'</{tag}>')

    def handle_data(self, data):
        if not self.in_script:
            self.parts.append(data)

    def handle_entityref(self, name):
        if not self.in_script:
            self.parts.append(f'&{name};')

    def handle_charref(self, name):
        if not self.in_script:
            self.parts.append(f'&#{name};')


def export_page(base_url, route):
    with urlopen(base_url + route, timeout=30) as response:
        if response.status != 200:
            raise RuntimeError(f'Could not render {route}')
        source = response.read().decode('utf-8')
    parser = PublicDocument()
    parser.feed(source)
    result = ''.join(parser.parts)
    if '<script' in result or '/@id/' in result or 'self[' in result:
        raise RuntimeError('Development or hydration code leaked into the public export')
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--base-url', default='http://localhost:3000')
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)

    # Keep the existing original company imprint; it must not be replaced with
    # incomplete or guessed proprietor details. Its Git history remains intact.
    if not (output / 'impressum.html').is_file():
        raise RuntimeError('Export into a checkout of the original company site')
    for route, name in [('/', 'index.html'), ('/hilfe', 'hilfe.html'), ('/datenschutz', 'datenschutz.html')]:
        document = export_page(args.base_url.rstrip('/'), route)
        if name == 'datenschutz.html':
            document = re.sub(
                r'<p>Diese Hinweise beschreiben die Verarbeitung.*?</p>',
                '<p>Diese Hinweise beschreiben die neue Unternehmenswebsite und die verlinkten Online-Apps von LUXORÉ RIDE.</p>',
                document, count=1, flags=re.S,
            )
            document = document.replace(
                'Die Online-Oberfläche wird über OpenAI Sites und Cloudflare bereitgestellt.',
                'Die Unternehmenswebsite wird über Vercel bereitgestellt. Dabei können IP-Adresse und technische Verbindungsdaten verarbeitet werden. Die verlinkte Buchungsoberfläche und Online-Apps werden über OpenAI Sites und Cloudflare bereitgestellt.',
            )
        # Static metadata uses the already existing, connected company domain.
        canonical = '/' if name == 'index.html' else '/' + name
        document = document.replace('</head>', f'<link rel="canonical" href="https://luxoreride.de{canonical}"></head>')
        (output / name).write_text(document, encoding='utf-8')

    css = (ROOT / 'app/globals.css').read_text()
    css = re.sub(r"@import\s+[^;]+;", '', css)
    css = re.sub(r'@theme inline\s*\{[^}]*\}', '', css)
    css += '\n' + (ROOT / 'app/portal.css').read_text()
    (output / 'luxore-premium.css').write_text(css)
    for name in ['frankfurt.png', 'business.png', 'first-class.png', 'van.png']:
        shutil.copyfile(ROOT / 'public/brand' / name, output / ('luxore-' + name))
    shutil.copyfile(ROOT / 'public/favicon.svg', output / 'luxore-favicon.svg')

    redirects = []
    for path in ['/mobile/:path*', '/konto', '/ride', '/disposition', '/betreiber', '/app-ansichten']:
        redirects.append({'source': path, 'destination': APP_ORIGIN + path, 'permanent': False})
    for path in ['hilfe', 'impressum', 'datenschutz']:
        redirects.append({'source': '/' + path, 'destination': '/' + path + '.html', 'permanent': False})
    config = {
        '$schema': 'https://openapi.vercel.sh/vercel.json',
        'framework': None, 'buildCommand': '', 'installCommand': '',
        'outputDirectory': '.', 'redirects': redirects,
        'headers': [{'source': '/(.*)', 'headers': [
            {'key': 'X-Content-Type-Options', 'value': 'nosniff'},
            {'key': 'Referrer-Policy', 'value': 'strict-origin-when-cross-origin'},
        ]}],
    }
    (output / 'vercel.json').write_text(json.dumps(config, indent=2) + '\n')
    (output / 'robots.txt').write_text('User-agent: *\nAllow: /\nDisallow: /betreiber\nSitemap: https://luxoreride.de/sitemap.xml\n')
    urls = ['https://luxoreride.de/', 'https://luxoreride.de/hilfe.html', 'https://luxoreride.de/impressum.html', 'https://luxoreride.de/datenschutz.html']
    (output / 'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + ''.join('<url><loc>' + u + '</loc></url>' for u in urls) + '</urlset>\n')
    print(json.dumps({'output': str(output), 'pages': 3, 'booking_origin': APP_ORIGIN}))


if __name__ == '__main__':
    main()
