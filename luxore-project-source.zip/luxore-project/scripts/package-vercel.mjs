import { zipSync, strToU8 } from 'fflate';
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { createHash } from 'node:crypto';
const output=resolve(process.argv[2]||'outputs/github-website');
mkdirSync(output,{recursive:true});
// Publish reviewed source only. Untracked personal files and conflict copies
// remain local; new project files must be committed before packaging.
const names=[...new Set(execFileSync('git',['ls-files','--cached','-z']).toString().split('\0').filter(Boolean))];
const archive={};
for(const name of names){
  if(!existsSync(name)||name.startsWith('docs/design-review/')||name.endsWith('.tsbuildinfo'))continue;
  // Preserve local cloud-sync conflict copies, but publish only the canonical
  // file when it exists. A historical tracked lockfile copy also needs this.
  const canonical=name.replace(/ [2-9]\d*(\.[^/]+)$/, '$1');
  if(canonical!==name&&existsSync(canonical))continue;
  const bytes=readFileSync(name);
  // Public code does not need the proprietor's private login email.
  const sanitized=bytes.includes(Buffer.from('operator@example.com'))?
    Buffer.from(bytes.toString().replaceAll('operator@example.com','operator@example.com')):bytes;
  archive['luxore-project/'+name]=[sanitized,{mtime:new Date('2026-10-06T00:00:00Z')}];
}
const base=execFileSync('git',['rev-parse','HEAD']).toString().trim();
archive['luxore-project/SOURCE-NOTES.md']=[strToU8('Independent source snapshot. Base commit: '+base+'\nThe private operator email is an example in this public archive. Configure the real operator in the protected runtime environment.\n'),{mtime:new Date('2026-10-06T00:00:00Z')}];
const bytes=zipSync(archive,{level:9});writeFileSync(join(output,'luxore-project-source.zip'),bytes);
const hash=createHash('sha256').update(bytes).digest('hex');
const pkg=JSON.parse(readFileSync('package.json','utf8'));
pkg.scripts.build='node vercel-bootstrap.mjs && next build';
writeFileSync(join(output,'package.json'),JSON.stringify(pkg,null,2)+'\n');
writeFileSync(join(output,'pnpm-lock.yaml'),readFileSync('pnpm-lock.yaml'));
writeFileSync(join(output,'pnpm-workspace.yaml'),readFileSync('pnpm-workspace.yaml'));
writeFileSync(join(output,'vercel-bootstrap.mjs'),readFileSync('vercel-bootstrap.mjs'));
writeFileSync(join(output,'vercel.json'),JSON.stringify({
  '$schema':'https://openapi.vercel.sh/vercel.json',framework:'nextjs',
  buildCommand:'pnpm run build',outputDirectory:'.next',regions:['fra1'],
  redirects:[
    {source:'/index.html',destination:'/',permanent:true},
    {source:'/index_en.html',destination:'/',permanent:false},
    {source:'/datenschutz.html',destination:'/datenschutz',permanent:true},
    {source:'/hilfe.html',destination:'/hilfe',permanent:true},
  ],
},null,2)+'\n');
writeFileSync(join(output,'README.md'),readFileSync('README.md'));
writeFileSync(join(output,'SOURCE-VERSION.txt'),'Independent source snapshot based on '+base+'\nArchive sha256: '+hash+'\nWebsite, API and own account authentication use luxoreride.de.\n');
console.log(JSON.stringify({output,files:Object.keys(archive).length,archive_bytes:bytes.length,sha256:hash}));
