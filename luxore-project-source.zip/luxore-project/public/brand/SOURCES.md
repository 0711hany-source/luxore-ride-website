Brand imagery provided through the user's business website luxoreride.de, retrieved 2026-09-18 with authorization to adapt the app to that website.
- business.png: https://luxoreride.de/assets/transparent_gen_e_class.png
- first-class.png: https://luxoreride.de/assets/transparent_gen_s_class.png
- van.png: https://luxoreride.de/assets/transparent_gen_v_class.png
- frankfurt.png: https://luxoreride.de/assets/hero_frankfurt.png
These are website illustrations of vehicle classes, not verified photographs of assigned vehicles.
- electric.png: Mercedes EQE 300, picture supplied by the user in chat on 2026-11-16 (white background removed, scaled to 1024 px). Origin and usage rights not verified – looks like a manufacturer illustration; the user must confirm the right to use it before it goes online.
- app-concept.png: generated with built-in imagegen for the user's app design preview; reused on the website on 2026-09-21. Concept image with fictional data, not a screenshot of shipped functionality.
