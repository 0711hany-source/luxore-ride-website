// Server-only configuration. Vercel's native integration supplies TURSO_*.
// Keep each URL paired with its own token; never borrow credentials from a
// different database if an explicit custom connection is selected.
export function databaseConnection(env = process.env) {
  const customUrl = env.DATABASE_URL?.trim();
  const url = customUrl || env.TURSO_DATABASE_URL?.trim();
  if (!url) return undefined;
  const token = customUrl ? env.DATABASE_AUTH_TOKEN : env.TURSO_AUTH_TOKEN;
  return { url, authToken: token?.trim() || undefined };
}
