import { sql } from 'drizzle-orm';
import {
  sqliteTable,
  text,
  integer,
  real,
  index,
  uniqueIndex,
} from 'drizzle-orm/sqlite-core';
export const mobilityStock = sqliteTable('mobility_stock', {
  vehicleId: text('vehicle_id').primaryKey(),
  data: text('data').notNull(),
  revision: integer('revision').notNull(),
  operationId: text('operation_id').notNull(),
  updatedAt: integer('updated_at').notNull(),
});
export const mobilityStockMovements = sqliteTable(
  'mobility_stock_movements',
  {
    id: text('id').primaryKey(),
    vehicleId: text('vehicle_id').notNull(),
    actorId: text('actor_id').notNull(),
    actorName: text('actor_name').notNull(),
    kind: text('kind').notNull(),
    note: text('note').notNull(),
    details: text('details').notNull(),
    bookingId: text('booking_id'),
    createdAt: integer('created_at').notNull(),
  },
  (t) => [
    index('idx_stock_movements_vehicle_time').on(t.vehicleId, t.createdAt),
  ],
);
export const rides = sqliteTable(
  'rides',
  {
    id: text('id').primaryKey(),
    ownerId: text('owner_id').notNull(),
    operatorId: text('operator_id').notNull(),
    pickup: text('pickup').notNull(),
    destination: text('destination').notNull(),
    service: text('service').notNull(),
    price: integer('price').notNull(),
    status: text('status').notNull().default('requested'),
    createdAt: integer('created_at').notNull(),
    scheduledAt: text('scheduled_at'),
  },
  (t) => [index('idx_rides_owner_created').on(t.ownerId, t.createdAt)],
);

// Version 3 uses separate tables; historical preview rides remain read-only.
export const mobilityPlaces = sqliteTable(
  'mobility_places',
  {
    id: text('id').primaryKey(),
    ownerId: text('owner_id').notNull(),
    label: text('label').notNull(),
    lat: real('lat').notNull(),
    lng: real('lng').notNull(),
    createdAt: integer('created_at').notNull(),
  },
  (t) => [index('idx_places_owner').on(t.ownerId)],
);
export const mobilityQuotes = sqliteTable(
  'mobility_quotes',
  {
    id: text('id').primaryKey(),
    ownerId: text('owner_id').notNull(),
    payload: text('payload').notNull(),
    expiresAt: integer('expires_at').notNull(),
  },
  (t) => [index('idx_quotes_owner').on(t.ownerId)],
);
export const mobilityDrivers = sqliteTable('mobility_drivers', {
  vehicleId: text('vehicle_id').unique(),
  services: text('services'),
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  phone: text('phone').notNull(),
  vehicle: text('vehicle').notNull(),
  plate: text('plate').notNull(),
  service: text('service').notNull(),
  approved: integer('approved').notNull().default(0),
  online: integer('online').notNull().default(0),
  lat: real('lat'),
  lng: real('lng'),
  accuracy: real('accuracy'),
  locationAt: integer('location_at'),
  sessionId: text('session_id'),
});
export const mobilityBookings = sqliteTable(
  'mobility_bookings',
  {
    vehicleId: text('vehicle_id'),
    vehicleSnapshot: text('vehicle_snapshot'),
    paymentStatus: text('payment_status').notNull().default('unpaid'),
    paymentMethod: text('payment_method'),
    paidAt: integer('paid_at'),
    completedAt: integer('completed_at'),
    fleetId: text('fleet_id'),
    riderName: text('rider_name'),
    riderPhone: text('rider_phone'),
    riderPreferences: text('rider_preferences'),
    refreshments: text('refreshments'),
    farePrice: integer('fare_price'),
    id: text('id').primaryKey(),
    quoteId: text('quote_id').notNull(),
    ownerId: text('owner_id').notNull(),
    service: text('service').notNull(),
    price: integer('price').notNull(),
    route: text('route').notNull(),
    mode: text('mode').notNull(),
    scheduledAt: integer('scheduled_at'),
    status: text('status').notNull(),
    driverId: text('driver_id'),
    createdAt: integer('created_at').notNull(),
    updatedAt: integer('updated_at').notNull(),
    dispatchAt: integer('dispatch_at'),
    riderLat: real('rider_lat'),
    riderLng: real('rider_lng'),
    riderLocationAt: integer('rider_location_at'),
    riderShareId: text('rider_share_id'),
  },
  (t) => [
    uniqueIndex('idx_booking_quote_unique').on(t.quoteId),
    index('idx_booking_owner_created').on(t.ownerId, t.createdAt),
    index('idx_booking_driver_completed').on(t.driverId, t.completedAt),
    index('idx_booking_fleet_created').on(t.fleetId, t.createdAt),
    index('idx_booking_status_schedule').on(t.status, t.scheduledAt),
    uniqueIndex('idx_one_active_driver')
      .on(t.driverId)
      .where(sql`${t.status} in ('accepted','arrived','riding')`),
    uniqueIndex('idx_one_active_customer')
      .on(t.ownerId)
      .where(sql`${t.status} in ('requesting','accepted','arrived','riding')`),
  ],
);
export const mobilityOffers = sqliteTable(
  'mobility_offers',
  {
    id: text('id').primaryKey(),
    bookingId: text('booking_id').notNull(),
    driverId: text('driver_id').notNull(),
    status: text('status').notNull(),
    expiresAt: integer('expires_at').notNull(),
    createdAt: integer('created_at').notNull(),
  },
  (t) => [
    uniqueIndex('idx_offer_attempt').on(t.bookingId, t.driverId),
    uniqueIndex('idx_one_pending_offer_booking')
      .on(t.bookingId)
      .where(sql`${t.status} = 'pending'`),
    uniqueIndex('idx_one_pending_offer_driver')
      .on(t.driverId)
      .where(sql`${t.status} = 'pending'`),
  ],
);
export const mobilityEvents = sqliteTable(
  'mobility_events',
  {
    id: text('id').primaryKey(),
    bookingId: text('booking_id').notNull(),
    actorId: text('actor_id').notNull(),
    action: text('action').notNull(),
    createdAt: integer('created_at').notNull(),
  },
  (t) => [index('idx_events_booking').on(t.bookingId, t.createdAt)],
);
export const mobilityLimits = sqliteTable('mobility_limits', {
  key: text('key').primaryKey(),
  count: integer('count').notNull(),
});
// Only Mapbox results acquired with permanent storage rights belong here.
export const mobilityGeocodes = sqliteTable('mobility_geocodes', {
  key: text('key').primaryKey(),
  payload: text('payload'),
  expiresAt: integer('expires_at').notNull(),
  claim: text('claim'),
  claimedUntil: integer('claimed_until').notNull().default(0),
});

// Anonymous device credentials are hashed at rest; they never grant operator access.
export const mobilitySessions = sqliteTable(
  'mobility_sessions',
  {
    tokenHash: text('token_hash').primaryKey(),
    userId: text('user_id').notNull(),
    expiresAt: integer('expires_at').notNull(),
  },
  (t) => [index('idx_sessions_expiry').on(t.expiresAt)],
);

export const mobilityFleets = sqliteTable('mobility_fleets', {
  ownerId: text('owner_id').unique(),
  deputyId: text('deputy_id'),
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  createdAt: integer('created_at').notNull(),
});
export const mobilityEmployees = sqliteTable(
  'mobility_employees',
  {
    userId: text('user_id').primaryKey(),
    name: text('name').notNull(),
    phone: text('phone').notNull(),
    fleetId: text('fleet_id'),
    role: text('role').notNull().default('staff'),
    createdAt: integer('created_at').notNull(),
  },
  (t) => [index('idx_employee_fleet').on(t.fleetId)],
);

export const mobilityVehicles = sqliteTable(
  'mobility_vehicles',
  {
    id: text('id').primaryKey(),
    fleetId: text('fleet_id').notNull(),
    model: text('model').notNull(),
    plate: text('plate').notNull(),
    services: text('services').notNull(),
    status: text('status').notNull().default('active'),
    archivedReason: text('archived_reason'),
    createdAt: integer('created_at').notNull(),
    archivedAt: integer('archived_at'),
  },
  (t) => [
    index('idx_vehicle_fleet_status').on(t.fleetId, t.status),
    uniqueIndex('idx_vehicle_active_plate')
      .on(t.plate)
      .where(sql`${t.status} = 'active'`),
  ],
);

// A native service may only update the current driver's location; no ride access.
export const mobilityLocationSessions = sqliteTable(
  'mobility_location_sessions',
  {
    tokenHash: text('token_hash').primaryKey(),
    driverId: text('driver_id').notNull(),
    sessionId: text('session_id').notNull(),
    expiresAt: integer('expires_at').notNull(),
  },
);

export const mobilityFleetInvites = sqliteTable('mobility_fleet_invites', {
  tokenHash: text('token_hash').primaryKey(),
  fleetId: text('fleet_id').notNull(),
  inviterId: text('inviter_id').notNull(),
  expiresAt: integer('expires_at').notNull(),
});

export const mobilityAccounts = sqliteTable('mobility_accounts', {
  id: text('id').primaryKey(),
  email: text('email').notNull().unique(),
  name: text('name').notNull(),
  phone: text('phone').notNull(),
  kind: text('kind').notNull(),
  status: text('status').notNull().default('active'),
  verifiedAt: integer('verified_at').notNull(),
  createdAt: integer('created_at').notNull(),
  deletionRequestedAt: integer('deletion_requested_at'),
});
export const mobilityAccountSessions = sqliteTable(
  'mobility_account_sessions',
  {
    tokenHash: text('token_hash').primaryKey(),
    accountId: text('account_id').notNull(),
    expiresAt: integer('expires_at').notNull(),
    verifiedAt: integer('verified_at').notNull(),
  },
  (t) => [index('idx_account_session_user').on(t.accountId)],
);
export const mobilityAccountChallenges = sqliteTable(
  'mobility_account_challenges',
  {
    id: text('id').primaryKey(),
    email: text('email').notNull(),
    codeHash: text('code_hash').notNull(),
    payload: text('payload').notNull(),
    deviceId: text('device_id'),
    expiresAt: integer('expires_at').notNull(),
    createdAt: integer('created_at').notNull(),
    attempts: integer('attempts').notNull().default(0),
    claimed: integer('claimed').notNull().default(0),
  },
  (t) => [index('idx_account_challenge_email').on(t.email, t.createdAt)],
);
export const mobilityOperatorAudit = sqliteTable(
  'mobility_operator_audit',
  {
    id: text('id').primaryKey(),
    actorId: text('actor_id').notNull(),
    subjectId: text('subject_id').notNull(),
    action: text('action').notNull(),
    createdAt: integer('created_at').notNull(),
  },
  (t) => [index('idx_operator_audit_time').on(t.createdAt)],
);
