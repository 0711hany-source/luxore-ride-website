import { createClient, type Client, type InValue, type ResultSet } from '@libsql/client';

export type SqlResult<T = Record<string, unknown>> = {
  results: T[];
  success: true;
  meta: { changes: number; last_row_id: string | null };
};
export interface SqlStatement {
  bind(...values: unknown[]): SqlStatement;
  first<T = Record<string, unknown>>(column?: string): Promise<T | null>;
  all<T = Record<string, unknown>>(): Promise<SqlResult<T>>;
  run(): Promise<SqlResult>;
}
export interface SqlDatabase {
  prepare(sql: string): SqlStatement;
  batch(statements: SqlStatement[]): Promise<SqlResult[]>;
}
function result<T>(value: ResultSet, sql: string): SqlResult<T> {
  // Some SQLite drivers report zero changes while a RETURNING cursor is open.
  // Returned mutation rows are the actual affected rows, including guarded no-ops.
  const returningMutation = /^\s*(INSERT|UPDATE|DELETE|REPLACE)\b/i.test(sql) && /\bRETURNING\b/i.test(sql);
  return {
    results: value.rows.map((r) => Object.fromEntries(Object.entries(r))) as T[],
    success: true,
    meta: { changes: returningMutation ? value.rows.length : value.rowsAffected, last_row_id: value.lastInsertRowid?.toString() ?? null },
  };
}
function argument(v: unknown): InValue {
  if (v === null || v === undefined) return null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (typeof v === 'string' || typeof v === 'number' || typeof v === 'bigint' || v instanceof Uint8Array) return v;
  throw new TypeError('Unsupported SQL parameter');
}
export function sqliteDatabase(client: Client): SqlDatabase {
  class Statement implements SqlStatement {
    readonly sql: string;
    readonly args: InValue[];
    constructor(sql: string, args: InValue[] = []) { this.sql=sql; this.args=args; }
    bind(...values: unknown[]) { return new Statement(this.sql, values.map(argument)); }
    async first<T = Record<string, unknown>>(column?: string): Promise<T | null> {
      const value = await client.execute({ sql: this.sql, args: this.args });
      const row = value.rows[0];
      return row ? (column ? row[column] as T : Object.fromEntries(Object.entries(row)) as T) : null;
    }
    async all<T = Record<string, unknown>>() { return result<T>(await client.execute({ sql: this.sql, args: this.args }), this.sql); }
    async run() { return this.all(); }
  }
  return {
    prepare: (sql) => new Statement(sql),
    async batch(statements) {
      const queries = statements.map((s) => {
        if (!(s instanceof Statement)) throw new TypeError('Statements must belong to this database');
        return { sql: s.sql, args: s.args };
      });
      // One write transaction preserves fare, stock and dispatch atomicity.
      return (await client.batch(queries, 'write')).map((r,i)=>result<Record<string, unknown>>(r,queries[i].sql));
    },
  };
}
export class DatabaseUnavailable extends Error {
  status = 503;
  constructor() { super('Das Buchungssystem wird eingerichtet. Bitte kontaktiere unser Team direkt.'); }
}
export function databaseConfigured() {
  return Boolean(process.env.DATABASE_URL) &&
    (process.env.NODE_ENV !== 'production' || process.env.LUXORE_BOOKING_ENABLED === 'true');
}
let database: SqlDatabase | undefined;
export function runtimeDatabase() {
  if (!databaseConfigured()) throw new DatabaseUnavailable();
  if (process.env.VERCEL && process.env.DATABASE_URL?.startsWith('file:')) throw new DatabaseUnavailable();
  return database ??= sqliteDatabase(createClient({
    url: process.env.DATABASE_URL!, authToken: process.env.DATABASE_AUTH_TOKEN, intMode: 'number',
  }));
}
