import {
  createClient,
  type Client,
  type InValue,
  type ResultSet,
  type Transaction,
} from '@libsql/client';
import { databaseConnection } from './connection.mjs';

export type SqlResult<T = Record<string, unknown>> = {
  results: T[];
  success: true;
  meta: { changes: number; last_row_id: string | null };
};
export interface SqlStatement {
  bind(...values: unknown[]): SqlStatement;
  first<T = Record<string, unknown>>(column?: string): Promise<T | null>;
  all<T = Record<string, unknown>>(): Promise<SqlResult<T>>;
  run(): Promise<SqlResult>;
}
export interface SqlDatabase {
  prepare(sql: string): SqlStatement;
  batch(statements: SqlStatement[]): Promise<SqlResult[]>;
  writeTransaction<T>(work: (database: SqlDatabase) => Promise<T>): Promise<T>;
}
function result<T>(value: ResultSet, sql: string): SqlResult<T> {
  // Some SQLite drivers report zero changes while a RETURNING cursor is open.
  // Returned mutation rows are the actual affected rows, including guarded no-ops.
  const returningMutation =
    /^\s*(INSERT|UPDATE|DELETE|REPLACE)\b/i.test(sql) &&
    /\bRETURNING\b/i.test(sql);
  return {
    results: value.rows.map((r) =>
      Object.fromEntries(Object.entries(r)),
    ) as T[],
    success: true,
    meta: {
      changes: returningMutation ? value.rows.length : value.rowsAffected,
      last_row_id: value.lastInsertRowid?.toString() ?? null,
    },
  };
}
function argument(v: unknown): InValue {
  if (v === null || v === undefined) return null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (
    typeof v === 'string' ||
    typeof v === 'number' ||
    typeof v === 'bigint' ||
    v instanceof Uint8Array
  )
    return v;
  throw new TypeError('Unsupported SQL parameter');
}
export function sqliteDatabase(client: Client | Transaction): SqlDatabase {
  class Statement implements SqlStatement {
    readonly sql: string;
    readonly args: InValue[];
    constructor(sql: string, args: InValue[] = []) {
      this.sql = sql;
      this.args = args;
    }
    bind(...values: unknown[]) {
      return new Statement(this.sql, values.map(argument));
    }
    async first<T = Record<string, unknown>>(
      column?: string,
    ): Promise<T | null> {
      const value = await client.execute({ sql: this.sql, args: this.args });
      const row = value.rows[0];
      return row
        ? column
          ? (row[column] as T)
          : (Object.fromEntries(Object.entries(row)) as T)
        : null;
    }
    async all<T = Record<string, unknown>>() {
      return result<T>(
        await client.execute({ sql: this.sql, args: this.args }),
        this.sql,
      );
    }
    async run() {
      return this.all();
    }
  }
  return {
    prepare: (sql) => new Statement(sql),
    async batch(statements) {
      const queries = statements.map((s) => {
        if (!(s instanceof Statement))
          throw new TypeError('Statements must belong to this database');
        return { sql: s.sql, args: s.args };
      });
      // One write transaction preserves fare, stock and dispatch atomicity.
      const rows =
        'transaction' in client
          ? await client.batch(queries, 'write')
          : await client.batch(queries);
      return rows.map((r, i) =>
        result<Record<string, unknown>>(r, queries[i].sql),
      );
    },
    async writeTransaction(work) {
      if (!('transaction' in client))
        throw new TypeError('Nested write transactions are not supported');
      const transaction = await client.transaction('write');
      try {
        const value = await work(sqliteDatabase(transaction));
        await transaction.commit();
        return value;
      } catch (error) {
        // Closing also releases/rolls back an interrupted connection. Preserve
        // the original failure if the remote transaction has already expired.
        await transaction.rollback().catch(() => {});
        throw error;
      } finally {
        transaction.close();
      }
    },
  };
}
export class DatabaseUnavailable extends Error {
  status = 503;
  constructor() {
    super(
      'Das Buchungssystem wird eingerichtet. Bitte kontaktiere unser Team direkt.',
    );
  }
}
export function storageConfigured() {
  const connection = databaseConnection();
  return Boolean(
    connection &&
    (!process.env.VERCEL || !/^(file:|:memory:$)/i.test(connection.url)),
  );
}
export function databaseConfigured() {
  return (
    storageConfigured() &&
    (process.env.NODE_ENV !== 'production' ||
      process.env.LUXORE_BOOKING_ENABLED === 'true')
  );
}
export function accountsConfigured() {
  return (
    storageConfigured() &&
    (process.env.NODE_ENV !== 'production' ||
      process.env.LUXORE_ACCOUNTS_ENABLED === 'true' ||
      process.env.LUXORE_BOOKING_ENABLED === 'true')
  );
}
let database: SqlDatabase | undefined;
export function runtimeDatabase(scope: 'booking' | 'account' = 'booking') {
  const connection = databaseConnection();
  if (
    !connection ||
    !(scope === 'account' ? accountsConfigured() : databaseConfigured())
  )
    throw new DatabaseUnavailable();
  return (database ??= sqliteDatabase(
    createClient({
      ...connection,
      intMode: 'number',
    }),
  ));
}
