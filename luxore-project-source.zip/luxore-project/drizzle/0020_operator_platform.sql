CREATE TABLE `mobility_documents` (
	`id` text PRIMARY KEY NOT NULL,
	`subject_type` text NOT NULL,
	`subject_id` text NOT NULL,
	`fleet_id` text,
	`kind` text NOT NULL,
	`number` text,
	`expires_on` text,
	`status` text DEFAULT 'submitted' NOT NULL,
	`reason` text,
	`uploaded_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`reviewed_by` text,
	`reviewed_at` integer
);
--> statement-breakpoint
CREATE INDEX `idx_document_subject` ON `mobility_documents` (`subject_type`,`subject_id`,`kind`);--> statement-breakpoint
CREATE INDEX `idx_document_status` ON `mobility_documents` (`status`,`created_at`);--> statement-breakpoint
CREATE TABLE `mobility_fleet_applications` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`fleet_id` text NOT NULL,
	`company` text NOT NULL,
	`legal_form` text NOT NULL,
	`address` text NOT NULL,
	`contact` text NOT NULL,
	`phone` text NOT NULL,
	`tax_id` text,
	`terms_accepted_at` integer NOT NULL,
	`status` text DEFAULT 'submitted' NOT NULL,
	`reason` text,
	`decided_by` text,
	`decided_at` integer,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `mobility_fleet_applications_fleet_id_unique` ON `mobility_fleet_applications` (`fleet_id`);--> statement-breakpoint
CREATE INDEX `idx_fleet_application_status` ON `mobility_fleet_applications` (`status`,`created_at`);--> statement-breakpoint
CREATE UNIQUE INDEX `idx_one_open_fleet_application` ON `mobility_fleet_applications` (`account_id`) WHERE "mobility_fleet_applications"."status" = 'submitted';--> statement-breakpoint
CREATE TABLE `mobility_images` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_type` text NOT NULL,
	`owner_id` text NOT NULL,
	`slot` text NOT NULL,
	`mime` text NOT NULL,
	`bytes` integer NOT NULL,
	`data` blob NOT NULL,
	`uploaded_by` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_image_owner` ON `mobility_images` (`owner_type`,`owner_id`);--> statement-breakpoint
CREATE TABLE `mobility_inspections` (
	`id` text PRIMARY KEY NOT NULL,
	`vehicle_id` text NOT NULL,
	`fleet_id` text NOT NULL,
	`inspector_id` text NOT NULL,
	`inspector_name` text NOT NULL,
	`result` text NOT NULL,
	`items` text NOT NULL,
	`odometer` integer,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_inspection_vehicle_time` ON `mobility_inspections` (`vehicle_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_inspection_result_time` ON `mobility_inspections` (`result`,`created_at`);--> statement-breakpoint
CREATE TABLE `mobility_settings` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL,
	`updated_at` integer NOT NULL,
	`updated_by` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `mobility_settlements` (
	`fleet_id` text NOT NULL,
	`week` text NOT NULL,
	`start_at` integer NOT NULL,
	`end_at` integer NOT NULL,
	`status` text DEFAULT 'open' NOT NULL,
	`paid_at` integer,
	`paid_by` text,
	`snapshot` text,
	`updated_at` integer NOT NULL,
	PRIMARY KEY(`fleet_id`, `week`)
);
--> statement-breakpoint
CREATE TABLE `mobility_suspensions` (
	`id` text PRIMARY KEY NOT NULL,
	`subject_type` text NOT NULL,
	`subject_id` text NOT NULL,
	`fleet_id` text,
	`level` text NOT NULL,
	`reason` text NOT NULL,
	`created_by` text NOT NULL,
	`created_by_name` text NOT NULL,
	`created_at` integer NOT NULL,
	`lifted_by` text,
	`lifted_by_name` text,
	`lifted_at` integer
);
--> statement-breakpoint
CREATE INDEX `idx_suspension_subject` ON `mobility_suspensions` (`subject_type`,`subject_id`);--> statement-breakpoint
CREATE INDEX `idx_suspension_fleet_time` ON `mobility_suspensions` (`fleet_id`,`created_at`);--> statement-breakpoint
CREATE UNIQUE INDEX `idx_one_active_suspension` ON `mobility_suspensions` (`subject_type`,`subject_id`,`level`) WHERE "mobility_suspensions"."lifted_at" is null;