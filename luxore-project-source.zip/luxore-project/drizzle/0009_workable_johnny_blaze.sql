CREATE TABLE `mobility_vehicles` (
	`id` text PRIMARY KEY NOT NULL,
	`fleet_id` text NOT NULL,
	`model` text NOT NULL,
	`plate` text NOT NULL,
	`services` text NOT NULL,
	`status` text DEFAULT 'active' NOT NULL,
	`archived_reason` text,
	`created_at` integer NOT NULL,
	`archived_at` integer
);
--> statement-breakpoint
CREATE INDEX `idx_vehicle_fleet_status` ON `mobility_vehicles` (`fleet_id`,`status`);--> statement-breakpoint
CREATE UNIQUE INDEX `idx_vehicle_active_plate` ON `mobility_vehicles` (`plate`) WHERE "mobility_vehicles"."status" = 'active';--> statement-breakpoint
ALTER TABLE `mobility_bookings` ADD `vehicle_id` text;--> statement-breakpoint
ALTER TABLE `mobility_bookings` ADD `vehicle_snapshot` text;--> statement-breakpoint
ALTER TABLE `mobility_drivers` ADD `vehicle_id` text;--> statement-breakpoint
CREATE UNIQUE INDEX `mobility_drivers_vehicle_id_unique` ON `mobility_drivers` (`vehicle_id`);