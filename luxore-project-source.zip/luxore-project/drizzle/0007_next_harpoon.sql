CREATE TABLE `mobility_employees` (
	`user_id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`fleet_id` text,
	`role` text DEFAULT 'staff' NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_employee_fleet` ON `mobility_employees` (`fleet_id`);--> statement-breakpoint
CREATE TABLE `mobility_fleets` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
ALTER TABLE `mobility_bookings` ADD `payment_status` text DEFAULT 'unpaid' NOT NULL;--> statement-breakpoint
ALTER TABLE `mobility_bookings` ADD `payment_method` text;--> statement-breakpoint
ALTER TABLE `mobility_bookings` ADD `paid_at` integer;--> statement-breakpoint
ALTER TABLE `mobility_bookings` ADD `completed_at` integer;--> statement-breakpoint
ALTER TABLE `mobility_bookings` ADD `fleet_id` text;--> statement-breakpoint
CREATE INDEX `idx_booking_driver_completed` ON `mobility_bookings` (`driver_id`,`completed_at`);--> statement-breakpoint
CREATE INDEX `idx_booking_fleet_created` ON `mobility_bookings` (`fleet_id`,`created_at`);