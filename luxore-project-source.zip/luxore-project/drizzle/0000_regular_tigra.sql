CREATE TABLE `rides` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`operator_id` text NOT NULL,
	`pickup` text NOT NULL,
	`destination` text NOT NULL,
	`service` text NOT NULL,
	`price` integer NOT NULL,
	`status` text DEFAULT 'requested' NOT NULL,
	`created_at` integer NOT NULL,
	`scheduled_at` text
);
--> statement-breakpoint
CREATE INDEX `idx_rides_owner_created` ON `rides` (`owner_id`,`created_at`);