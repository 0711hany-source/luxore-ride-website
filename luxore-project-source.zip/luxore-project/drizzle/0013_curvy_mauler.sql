CREATE TABLE `mobility_fleet_invites` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`fleet_id` text NOT NULL,
	`inviter_id` text NOT NULL,
	`expires_at` integer NOT NULL
);
