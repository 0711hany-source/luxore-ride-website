CREATE TABLE `mobility_push_tokens` (
	`driver_id` text PRIMARY KEY NOT NULL,
	`token` text NOT NULL,
	`platform` text DEFAULT 'android' NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	`last_wake_at` integer
);
--> statement-breakpoint
CREATE UNIQUE INDEX `mobility_push_tokens_token_unique` ON `mobility_push_tokens` (`token`);