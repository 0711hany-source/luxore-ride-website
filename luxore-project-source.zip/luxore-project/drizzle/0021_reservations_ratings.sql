CREATE TABLE `mobility_ratings` (
	`id` text PRIMARY KEY NOT NULL,
	`booking_id` text NOT NULL,
	`rater_role` text NOT NULL,
	`rater_id` text NOT NULL,
	`subject_id` text NOT NULL,
	`stars` integer NOT NULL,
	`comment` text,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_rating_booking_role` ON `mobility_ratings` (`booking_id`,`rater_role`);--> statement-breakpoint
CREATE INDEX `idx_rating_subject` ON `mobility_ratings` (`subject_id`,`rater_role`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_rating_rater` ON `mobility_ratings` (`rater_id`);--> statement-breakpoint
ALTER TABLE `mobility_bookings` ADD `assigned_driver_id` text;--> statement-breakpoint
ALTER TABLE `mobility_bookings` ADD `assigned_fleet_id` text;--> statement-breakpoint
ALTER TABLE `mobility_bookings` ADD `assigned_vehicle_id` text;--> statement-breakpoint
ALTER TABLE `mobility_bookings` ADD `assigned_at` integer;--> statement-breakpoint
CREATE INDEX `idx_booking_assigned_driver` ON `mobility_bookings` (`assigned_driver_id`,`status`);