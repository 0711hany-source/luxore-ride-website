-- Owner-authorized provisioning for the existing approved GG HY 711 driver.
-- Match the existing device identity, never a self-entered plate on a new device.
INSERT INTO mobility_fleets(id,name,owner_id,created_at)
SELECT 'luxore-frankfurt', 'Luxóre Ride Frankfurt', d.id, unixepoch()*1000
FROM mobility_drivers d WHERE d.id='device:cea0a048-70a0-4ad6-afd9-86b0246b689d'
AND d.plate='GG HY 711' AND d.approved=1
AND NOT EXISTS(SELECT 1 FROM mobility_employees e WHERE e.user_id=d.id AND e.fleet_id IS NOT NULL)
AND NOT EXISTS(SELECT 1 FROM mobility_fleets f WHERE f.owner_id=d.id OR f.id='luxore-frankfurt');
--> statement-breakpoint
INSERT INTO mobility_employees(user_id,name,phone,fleet_id,role,created_at)
SELECT d.id,d.name,d.phone,f.id,'driver',unixepoch()*1000
FROM mobility_drivers d JOIN mobility_fleets f ON f.owner_id=d.id AND f.id='luxore-frankfurt'
WHERE d.id='device:cea0a048-70a0-4ad6-afd9-86b0246b689d'
AND NOT EXISTS(SELECT 1 FROM mobility_employees e WHERE e.user_id=d.id);
--> statement-breakpoint
INSERT INTO mobility_vehicles(id,fleet_id,model,plate,services,status,created_at)
SELECT 'luxore-gg-hy-711',e.fleet_id,d.vehicle,d.plate,COALESCE(d.services,'["premium"]'),'active',unixepoch()*1000
FROM mobility_drivers d JOIN mobility_employees e ON e.user_id=d.id AND e.fleet_id='luxore-frankfurt'
WHERE d.id='device:cea0a048-70a0-4ad6-afd9-86b0246b689d' AND d.plate='GG HY 711'
AND NOT EXISTS(SELECT 1 FROM mobility_vehicles v WHERE v.id='luxore-gg-hy-711' OR (v.plate=d.plate AND v.status='active'));
--> statement-breakpoint
UPDATE mobility_drivers SET vehicle_id='luxore-gg-hy-711'
WHERE id='device:cea0a048-70a0-4ad6-afd9-86b0246b689d' AND plate='GG HY 711' AND vehicle_id IS NULL
AND EXISTS(SELECT 1 FROM mobility_vehicles v JOIN mobility_employees e ON e.fleet_id=v.fleet_id
  WHERE v.id='luxore-gg-hy-711' AND v.status='active' AND e.user_id=mobility_drivers.id)
AND NOT EXISTS(SELECT 1 FROM mobility_drivers d WHERE d.vehicle_id='luxore-gg-hy-711')
AND NOT EXISTS(SELECT 1 FROM mobility_bookings b WHERE b.driver_id=mobility_drivers.id AND b.status IN ('accepted','arrived','riding'));
