ALTER TABLE `mobility_fleets` ADD `owner_id` text;--> statement-breakpoint
ALTER TABLE `mobility_fleets` ADD `deputy_id` text;--> statement-breakpoint
CREATE UNIQUE INDEX `mobility_fleets_owner_id_unique` ON `mobility_fleets` (`owner_id`);