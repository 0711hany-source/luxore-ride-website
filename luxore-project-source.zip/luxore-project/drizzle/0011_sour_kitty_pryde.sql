CREATE TABLE `mobility_location_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`driver_id` text NOT NULL,
	`session_id` text NOT NULL,
	`expires_at` integer NOT NULL
);
