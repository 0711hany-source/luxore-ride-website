ALTER TABLE `mobility_bookings` ADD `refreshments` text;--> statement-breakpoint
ALTER TABLE `mobility_bookings` ADD `fare_price` integer;