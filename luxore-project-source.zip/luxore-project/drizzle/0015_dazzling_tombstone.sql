CREATE TABLE `mobility_stock` (
	`vehicle_id` text PRIMARY KEY NOT NULL,
	`data` text NOT NULL,
	`revision` integer NOT NULL,
	`operation_id` text NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `mobility_stock_movements` (
	`id` text PRIMARY KEY NOT NULL,
	`vehicle_id` text NOT NULL,
	`actor_id` text NOT NULL,
	`actor_name` text NOT NULL,
	`kind` text NOT NULL,
	`note` text NOT NULL,
	`details` text NOT NULL,
	`booking_id` text,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_stock_movements_vehicle_time` ON `mobility_stock_movements` (`vehicle_id`,`created_at`);