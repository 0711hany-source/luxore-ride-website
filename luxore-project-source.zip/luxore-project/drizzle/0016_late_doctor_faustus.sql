CREATE TABLE `mobility_geocodes` (
	`key` text PRIMARY KEY NOT NULL,
	`payload` text,
	`expires_at` integer NOT NULL,
	`claim` text,
	`claimed_until` integer DEFAULT 0 NOT NULL
);
