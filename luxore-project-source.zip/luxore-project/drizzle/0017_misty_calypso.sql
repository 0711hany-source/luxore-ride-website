CREATE TABLE `mobility_account_challenges` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`code_hash` text NOT NULL,
	`payload` text NOT NULL,
	`device_id` text,
	`expires_at` integer NOT NULL,
	`created_at` integer NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`claimed` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_account_challenge_email` ON `mobility_account_challenges` (`email`,`created_at`);--> statement-breakpoint
CREATE TABLE `mobility_account_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`expires_at` integer NOT NULL,
	`verified_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_account_session_user` ON `mobility_account_sessions` (`account_id`);--> statement-breakpoint
CREATE TABLE `mobility_accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`kind` text NOT NULL,
	`status` text DEFAULT 'active' NOT NULL,
	`verified_at` integer NOT NULL,
	`created_at` integer NOT NULL,
	`deletion_requested_at` integer
);
--> statement-breakpoint
CREATE UNIQUE INDEX `mobility_accounts_email_unique` ON `mobility_accounts` (`email`);--> statement-breakpoint
CREATE TABLE `mobility_operator_audit` (
	`id` text PRIMARY KEY NOT NULL,
	`actor_id` text NOT NULL,
	`subject_id` text NOT NULL,
	`action` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_operator_audit_time` ON `mobility_operator_audit` (`created_at`);