CREATE TABLE `mobility_bookings` (
	`id` text PRIMARY KEY NOT NULL,
	`quote_id` text NOT NULL,
	`owner_id` text NOT NULL,
	`service` text NOT NULL,
	`price` integer NOT NULL,
	`route` text NOT NULL,
	`mode` text NOT NULL,
	`scheduled_at` integer,
	`status` text NOT NULL,
	`driver_id` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	`dispatch_at` integer,
	`rider_lat` real,
	`rider_lng` real,
	`rider_location_at` integer
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_booking_quote_unique` ON `mobility_bookings` (`quote_id`);--> statement-breakpoint
CREATE INDEX `idx_booking_owner_created` ON `mobility_bookings` (`owner_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_booking_status_schedule` ON `mobility_bookings` (`status`,`scheduled_at`);--> statement-breakpoint
CREATE UNIQUE INDEX `idx_one_active_driver` ON `mobility_bookings` (`driver_id`) WHERE "mobility_bookings"."status" in ('accepted','arrived','riding');--> statement-breakpoint
CREATE UNIQUE INDEX `idx_one_active_customer` ON `mobility_bookings` (`owner_id`) WHERE "mobility_bookings"."status" in ('requesting','accepted','arrived','riding');--> statement-breakpoint
CREATE TABLE `mobility_drivers` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`vehicle` text NOT NULL,
	`plate` text NOT NULL,
	`service` text NOT NULL,
	`approved` integer DEFAULT 0 NOT NULL,
	`online` integer DEFAULT 0 NOT NULL,
	`lat` real,
	`lng` real,
	`accuracy` real,
	`location_at` integer
);
--> statement-breakpoint
CREATE TABLE `mobility_events` (
	`id` text PRIMARY KEY NOT NULL,
	`booking_id` text NOT NULL,
	`actor_id` text NOT NULL,
	`action` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_events_booking` ON `mobility_events` (`booking_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `mobility_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `mobility_offers` (
	`id` text PRIMARY KEY NOT NULL,
	`booking_id` text NOT NULL,
	`driver_id` text NOT NULL,
	`status` text NOT NULL,
	`expires_at` integer NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_offer_attempt` ON `mobility_offers` (`booking_id`,`driver_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `idx_one_pending_offer_booking` ON `mobility_offers` (`booking_id`) WHERE "mobility_offers"."status" = 'pending';--> statement-breakpoint
CREATE UNIQUE INDEX `idx_one_pending_offer_driver` ON `mobility_offers` (`driver_id`) WHERE "mobility_offers"."status" = 'pending';--> statement-breakpoint
CREATE TABLE `mobility_places` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`label` text NOT NULL,
	`lat` real NOT NULL,
	`lng` real NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_places_owner` ON `mobility_places` (`owner_id`);--> statement-breakpoint
CREATE TABLE `mobility_quotes` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`payload` text NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_quotes_owner` ON `mobility_quotes` (`owner_id`);