DROP INDEX `idx_one_active_driver`;--> statement-breakpoint
CREATE UNIQUE INDEX `idx_one_waiting_driver` ON `mobility_bookings` (`driver_id`) WHERE "mobility_bookings"."status" in ('accepted','arrived');--> statement-breakpoint
CREATE UNIQUE INDEX `idx_one_riding_driver` ON `mobility_bookings` (`driver_id`) WHERE "mobility_bookings"."status" = 'riding';
