ALTER TABLE `mobility_bookings` ADD `rider_name` text;--> statement-breakpoint
ALTER TABLE `mobility_bookings` ADD `rider_phone` text;