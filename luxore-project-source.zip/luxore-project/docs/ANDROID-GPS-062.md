# Android · gemeinsame GPS-Prüfung 0.6.2

8. Oktober 2026. Interner Entwicklungsschritt; kein vollständiger physischer Navigationsnachweis.

## Befund und Korrektur

Die native Fahreransicht prüfte bereits Messalter, Genauigkeit und unplausible Sprünge. Ihr Upload und der Hintergrunddienst verwendeten diesen Filter jedoch nicht: Ein GPS-Ausreißer konnte im Hintergrund gespeichert und übertragen werden; ältere oder doppelte Punkte wurden trotz unverändertem Cache erneut versandt. Ein letzter ungültiger Punkt in einem verzögerten Messpaket verdrängte außerdem vorherige brauchbare Punkte. Ein Cache einer anderen Schicht konnte die Speicherung einer neuen Messung verhindern.

Vordergrund und Hintergrund verwenden nun dieselbe `acceptFix`-Prüfung. Auswahl und Speicherung sind gemeinsam mit dem bestehenden Schicht-Lebenszyklus serialisiert. Ein Paket wird chronologisch geprüft und nur dessen neuester plausibler Punkt gespeichert und übertragen. Alte, doppelte, zu ungenaue, ungültige oder unplausible Messungen werden verworfen. Der Vergleichspunkt muss gültig und derselben Schicht zugeordnet sein. Nach mehr als 30 Sekunden ohne brauchbaren Vergleichspunkt ist eine neue Standortaufnahme möglich. Rohkoordinaten werden nicht verschoben oder auf Straßen umgeschrieben.

Die Speicherung erfolgt weiterhin vor dem Netzabruf. Bei Netzverlust bleibt der brauchbare Punkt für die Rückkehr erhalten; die nächste frische Messung versucht erneut zu senden. Keine alte Warteschlange wird abgespielt. Ein bereits gespeicherter identischer Punkt löst keinen erneuten Upload aus. Der bestehende Server prüft weiterhin Zeitstempel und aktuelle Standortberechtigung.

## Prüfungen und Grenzen

Vier neue Tests verwenden den tatsächlichen nativen Standortdienst mit isolierten Speicher-, Standort- und Netzadaptern. Die ersten drei scheitern mit dem vorherigen Code und bestehen mit der Korrektur. Geprüft sind Sprünge, alte/doppelte Messungen, verspätete Pakete mit ungültigem Schluss, negative Genauigkeit/ungültige Koordinaten/Zukunftszeit, schichtfremder oder veralteter Cache, Netzverlust und gleichzeitige Vordergrund-/Hintergrundaufrufe. Insgesamt 269 Projekttests sowie Mobile- und Web-TypeScript bestanden. Gezielter Lint für Standortdienst, Konfiguration und Tests bestanden. Die allein an der Versionsanzeige geänderte `App.tsx` besitzt weiterhin sechs bereits im vorherigen Quellstand vorhandene Lint-Befunde; kein allgemeiner Lint-Erfolg behauptet.

Dies verbessert die Messwertverarbeitung; es beweist weder exakte Straßenführung noch GPS-Latenz, Hersteller-Akkusperren oder einen angemeldeten Hintergrundbetrieb auf dem Nutzertelefon. Die SDK-Startkorrektur aus 0.6.1 bleibt erhalten. Physischer Test: Update ohne Deinstallation, vorhandenes Konto/Schicht prüfen, Bildschirm sperren, externe Navigation öffnen, Netz kurz unterbrechen und zur App zurückkehren. Neue native Änderungen benötigen die neue APK; eine Website-Veröffentlichung aktualisiert installierte Apps nicht.

Textadressbestätigung bleibt bis zur konkreten Geoapify-Vertrags-/Konto-Zustimmung und Einrichtung gesperrt. Kein Geokodierungsbudget, Anbieterzugang, Geschäftsdatensatz oder Kontorecht geändert.

## Tatsächlich gebaute APKs

Beide internen ARM64-Apps 0.6.2 / Build 16 erfolgreich gebaut und geprüft: eigenständiger Bundle, korrekte Varianten, nicht debuggable, Kunden-App ohne Fahrer-Hintergrundrechte, Fahrer-App mit Hintergrund-/Foreground-Service-Standort. Zertifikat unverändert: `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c`.

| Datei in `mobile/artifacts` | Bytes | SHA-256 |
| --- | ---: | --- |
| Luxore-Driver-Test-0.6.2.apk | 55.496.272 | `c240fe7f2d7779eef15346b6ba93fedbd2dd3b6ee3276d52b8edb6bd04d1fd42` |
| Luxore-Ride-Test-0.6.2.apk | 55.524.260 | `adc96832bd080eb89dcac298937f881e73551971a13b29f444b08c83915d12bb` |

Im bestehenden isolierten AOSP-Android-36-Emulator ohne Deinstallation über 0.6.1 installiert. Fahrer-App drei kalte Starts und lebender Prozess, Kunden-App ebenfalls mit lebendem Prozess gestartet; keine Fatal-/ReactNativeJS-Fehlermeldung im geprüften Protokoll. Kein angemeldeter Schicht-/Karten-/GPS-Beweis. Echte SDK-Konstruktion ohne Token löst weiterhin die erwartete MapboxConfigurationException aus; nach Tokeninitialisierung ist die MapView erfolgreich erstellt und freigegeben. Die SDK-Probe verwendet einen synthetischen Token und keine bezahlte Providerabfrage.

Lokaler Build: Automatisch erzeugte Cloud-Konfliktkopien blockierten das Lesen von Mapbox-/SafeArea-Dex-Transformcaches. Betroffene generierte Transformverzeichnisse von Mapbox, WebView, SafeArea und Expo Core wurden unverändert in `work/gps-cache-backup` gesichert und neu erzeugt; danach beide Builds erfolgreich. Keine Geschäftsdaten oder Projektquellen gelöscht. APKs und Signierdaten gehören nicht ins öffentliche Quellarchiv.

## Geschützter Testdownload und E-Mail

Beide 0.6.2-APKs im bestehenden privaten GitHub-Release-Entwurf gespeichert, ohne Veröffentlichung, neuen öffentlichen Tag oder Änderung der Zugriffsrechte. GitHub zeigt für beide Dateien die oben angegebenen SHA-256-Werte; die ältere 0.6.1-Datei ist ebenfalls erhalten. Aktuelle Entwurfsadresse: https://github.com/0711hany-source/luxore-ride-website/releases/tag/untagged-46b1be77c2a5bb3f488a. Downloads benötigen das vorhandene GitHub-Betreiberkonto; kein Nachweis eines Downloads auf dem Nutzerhandy.

Beim Speichern hat GitHub die interne untagged-Adresse geändert. Deshalb wurde der ausdrücklich gewünschte APK-Mailversand mit den tatsächlich angezeigten neuen Fahrer-/Kundenlinks und der stabilen Release-Übersicht korrigiert. Resend bestätigt die einmalige Testmail „[TEST] Deine LUXORÉ Apps 0.6.2 – aktuelle Android-Downloads“ an die bestätigte Betreiberadresse als delivered. Der tatsächlich zugestellte Inhalt enthält beide aktuellen Links, GitHub-Anmeldehinweis, Installation ohne Deinstallation und offene Geräteprüfungen. Keine Kundenmail, kein Broadcast, keine neue Versandintegration und kein bezahlter Tarif.

Für spätere Versionen einen separaten privaten Entwurf verwenden: bereits versendete untagged-Downloadlinks dürfen nicht durch erneut gespeicherte Entwürfe als unverändert zugesagt werden. Stabile Rückfallebene bleibt https://github.com/0711hany-source/luxore-ride-website/releases. Nachweise: `outputs/gps-062/apk-draft-ready.png`, `outputs/gps-062/mail-delivered.png`.
