# Native Flottengründung · Fahrer 0.7.4 / Build 28

## Verhalten

Die bestehende native Disposition bietet dem vorhandenen Plattformbetreiber ein festes Vollbildformular für Name und tatsächlichen Besitzer. Ein normaler Besitzer oder Stellvertreter erhält damit keine zusätzlichen Plattformrechte. Zur Auswahl stehen unzugeordnete Mitarbeiter/Fahrer ohne gelieferte Einsatzsperre und ohne bestehende Besitzer-/Stellvertreterrolle; das eigene erste Betreiberprofil bleibt möglich. GET /api/mobility/fleets liefert den bestehenden Einsatzguard jetzt auch für Fahrer ohne Mitarbeiterdatensatz. Der atomare create-Endpunkt prüft Kontostatus, Mitgliedschaft, Leitung, Online-/GPS-/Fahrt-/Zahlungssperren erneut (ATOMIC-FLEET-CREATION.md).

Gründung erfolgt ausschließlich durch vollständiges Wischen. Name, Besitzer und UUID werden vor HTTP kontogebunden in Expo SecureStore gespeichert. Fehler beim Speichern verhindern den Versand. Nach verlorener Antwort oder Prozessneustart bleiben dieselbe UUID und derselbe Inhalt fest; keine automatische Wiederholung, keine neue UUID und kein optimistischer Erfolg. Ein frischer GET kann den identischen aktuellen Flottenrecord bestätigen. Ein inzwischen umbenannter oder übergebener Record wird nicht als ursprüngliche Bestätigung ausgegeben. Eine eindeutige Ablehnung erlaubt das ausdrückliche Beenden der lokalen Anfrage per Wischgeste; bestehende Flotten werden dabei niemals gelöscht.

Die Geräteablage serialisiert Lesen, Speichern und erwartete UUID-Bereinigung pro Konto. Eine alte Bereinigung löscht keine neuere Anfrage; ein beschädigter fremder Datensatz wird nicht überschrieben. Eine bestätigte Gründung bleibt als Erfolg sichtbar, auch wenn die lokale Bereinigung oder folgende Aktualisierung scheitert. Bereinigungswiederholung ist rein lokal und sendet keinen neuen Gründungsauftrag.

## Lifecycle und gemeinsame Sperren

FleetCreationController liest die tatsächliche fleets-API mit AbortSignal, prüft die exakte Konto-ID und bestehenden Betreiberzugriff. Lesen und 15-Sekunden-Poll laufen nur bei sichtbarer Disposition im Vordergrund, wenn Formular oder offene Anfrage vorhanden sind. Änderungen benötigen einen weniger als 30 Sekunden alten bestätigten Stand. Hintergrund, Kontowechsel, verspätete Antworten und alte finally-Blöcke dürfen keine neueren Leseanfragen überschreiben. Schreibvorgänge werden beim Hintergrundwechsel nicht als Leseanfragen abgebrochen.

Während Wiederherstellung, offener Gründung oder geöffnetem Formular sind Freigabe, Stellvertretung und Teamänderung der Disposition gesperrt. Eine dort bereits unklare Änderung verhindert wiederum den Einstieg in eine neue Gründung. Nach Schließen und tatsächlicher Klärung lädt die Disposition neu. Das geschützte Formular ist aus App.tsx mit der eigenen Konto-ID eingebunden; native Änderungen benötigen ein APK-Update.

## Prüfstand und Grenzen

Zwölf neue Controller-/Geräteablageprüfungen, drei tatsächliche integrierte React-Native-Komponententests und ein echter fleets-GET-/libSQL-Test ergänzen den Stand auf **512 bestandene Tests**. Beide TypeScript-Prüfungen und gezieltes Lint der neuen/geänderten Module bestanden. App.tsx behält die bereits vorhandenen allgemeinen Lintbefunde; die einzige Änderung dort ist die Weitergabe der Konto-ID. Lokale echte Komponenten-Vorschau mit ausdrücklich synthetischen Daten auf 390×844 und 390×640: kein äußerer horizontaler Überlauf, feste Wischfläche erreichbar und eine vollständige lokale Testgeste bestätigt den synthetischen Record.

Keine Migration oder echte Production-Gründung, Einladung, Team-/Leitungs-/Freigabeänderung ausgelöst. Kunden-APK bleibt 0.6.9 / Build 23. Physische angemeldete Gründung/Team-/SDK-/Fahrt-/Mehrgeräte- und straßennahe Hintergrund-GPS-Prüfungen bleiben offen; anonyme Emulatorstarts ersetzen sie nicht. Interne APKs sind geschützte Entwürfe, keine öffentliche Binary-/Store-Freigabe oder Installation auf Nutzerhandys.

Nächster Schritt: konkrete angemeldete Gerätefehler und Fahrer-Navigation prüfen; verbleibende native Besitzerübergabe erst mit erwartetem altem Besitzer und ausdrücklicher Serverstandklärung bei verlorener Antwort ergänzen.

## Android-Nachweis

Fahrer 0.7.4 / Build 28 wurde außerhalb des synchronisierten Quell-/Abhängigkeitsbaums mit unveränderten Paketversionen gebaut. 71 Runtime-/Asset-/Konfigurationsdateien bytegenau mit dem Buildbaum abgeglichen. Android-SDK-Prüfung bestätigt Fahrer-Paket, Standalone-Bundle, ARM64, interne Variante, deaktiviertes Backup und bestehende Berechtigungen. Signatur SHA-256 `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c` unverändert. APK 56.203.216 Bytes; SHA-256 `b8e48632f0c1f82546f19ebc6980888923dc05e048a4e40d3e6568ab96ed6688`.

Im isolierten Android-Emulator über Fahrer 0.7.3 ohne Deinstallation aktualisiert. Drei kalte Starts mit lebendem Prozess, nativer anonymer Startoberfläche und ohne Fatal-/React-Native-JS-Absturz geprüft. Keine angemeldete Production-Gründung oder physische Geräteprüfung. Kunde 0.6.9 / Build 23 unverändert.
