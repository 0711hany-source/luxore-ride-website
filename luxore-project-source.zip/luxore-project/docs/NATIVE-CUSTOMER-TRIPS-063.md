# Native Kunden-Fahrtenübersicht · 0.6.3 / Build 17

Die Kunden-App erhält einen eigenen nativen Tab „Fahrten“ für aktuelle Anfragen, Reservierungen und Rückblick. Das feste native Detailfenster zeigt Abholung, Ziel, Klasse, Preis, tatsächlich verfügbaren Fahrer/Fahrzeug und den vom Server gelieferten Zahlungsstatus. Reservierungen werden ausdrücklich ohne Fahrerzusage dargestellt, bis diese tatsächlich vorliegt. Fahrertelefon wird nur bei einer aktiven zugesagten Fahrt angezeigt. Stornieren ist ausschließlich durch vollständiges Wischen möglich; Antippen oder unvollständiges Wischen löst keine Stornierung aus.

Die Übersicht verwendet die eigene API und vorhandene geschützte Luxóre-Kontositzung. Konto-Wechsel erzeugt einen getrennten Speicher. Abfragen laufen nur bei sichtbarem Fahrtenbereich und aktiver App, alle zehn Sekunden und bei Rückkehr. Keine überlappenden Abfragen; verspätete Antworten können eine Stornierung oder den neueren Vordergrundstand nicht überschreiben. Netzfehler erhalten bekannte Fahrten und sperren Änderungen bis zur erfolgreichen erneuten Abfrage. Der angezeigte Status ändert sich erst nach bestätigter Serverantwort; ein Konflikt wird angezeigt und der tatsächliche Status nachgeladen.

## Prüfungen

289 Tests bestanden, darunter sieben Controller-Tests für Sortierung, Hintergrund, verzögerte Antworten, Wiederaufnahme, doppelte Stornierung, Netzverlust und Serverkonflikt. Zwei echte React-Native-Komponententests prüfen den Einstieg über die App, feste Details, Reservationstext, ausschließlich vollständige Wischbestätigung und Hintergrund-/Vordergrundwechsel. Die Tests verwenden isolierte synthetische Fahrten und erzeugen keine Production-Buchung.

Web- und Mobile-TypeScript bestanden. Gezieltes Lint für die neuen Module und Tests bestanden. App.tsx hat dieselben sechs bereits vorher bestehenden Lint-Meldungen (Effekt-/Compilerregeln, Metro-Asset-require, Autofokus); kein vollständiges grünes App-Lint behaupten.

Die echten React-Native-Komponenten wurden zusätzlich über React Native Web auf 390×844 Pixel geprüft. Native Details passen ohne horizontalen Überlauf: document.scrollWidth = innerWidth = 390. Lokale Bilder mit gekennzeichneten Testdaten: outputs/customer-trips-063/native-trips.png und native-trip-details.png. Diese Designprüfung ersetzt keinen Android-Gerätetest.

## Grenzen und nächster Schritt

Buchungsformular und Kunden-Live-Karte bleiben in diesem Schritt eingebettet. Der Fahrerbereich ist weiterhin nativ; seine vorhandenen GPS-/Hintergrundfunktionen bleiben erhalten. Vollständige native Kundenbuchung, erweiterte Disposition, echte angemeldete Mehrgerätefahrt und physische Hintergrund-GPS-/Akkutests bleiben offen. Neue native Oberflächen benötigen eine neue interne APK; Website-Veröffentlichung aktualisiert installierte Apps nicht.

Keine neue Migration, Betreiber-/Fahrerfreigabe, Production-Testfahrt, Providerbudget-Änderung oder Store-Einreichung. Neue Textadressbestätigung bleibt bis zur ausstehenden konkreten Geoapify-Vertrags-/Konto-Zustimmung und Einrichtung gesperrt; Mapbox-Permanent-Budget bleibt null. Konten und Buchungen sind bereits freigegeben und benötigen keine erneute allgemeine Aktivierungsbestätigung. Vor offiziellem kommerziellem Start bleibt ein geeigneter Hostingtarif notwendig.
