# Native Kunden-Fahrtenübersicht · 0.6.3 / Build 17

Die Kunden-App erhält einen eigenen nativen Tab „Fahrten“ für aktuelle Anfragen, Reservierungen und Rückblick. Das feste native Detailfenster zeigt Abholung, Ziel, Klasse, Preis, tatsächlich verfügbaren Fahrer/Fahrzeug und den vom Server gelieferten Zahlungsstatus. Reservierungen werden ausdrücklich ohne Fahrerzusage dargestellt, bis diese tatsächlich vorliegt. Fahrertelefon wird nur bei einer aktiven zugesagten Fahrt angezeigt. Stornieren ist ausschließlich durch vollständiges Wischen möglich; Antippen oder unvollständiges Wischen löst keine Stornierung aus.

Die Übersicht verwendet die eigene API und vorhandene geschützte Luxóre-Kontositzung. Konto-Wechsel erzeugt einen getrennten Speicher. Abfragen laufen nur bei sichtbarem Fahrtenbereich und aktiver App, alle zehn Sekunden und bei Rückkehr. Keine überlappenden Abfragen; verspätete Antworten können eine Stornierung oder den neueren Vordergrundstand nicht überschreiben. Netzfehler erhalten bekannte Fahrten und sperren Änderungen bis zur erfolgreichen erneuten Abfrage. Der angezeigte Status ändert sich erst nach bestätigter Serverantwort; ein Konflikt wird angezeigt und der tatsächliche Status nachgeladen.

## Prüfungen

289 Tests bestanden, darunter sieben Controller-Tests für Sortierung, Hintergrund, verzögerte Antworten, Wiederaufnahme, doppelte Stornierung, Netzverlust und Serverkonflikt. Zwei echte React-Native-Komponententests prüfen den Einstieg über die App, feste Details, Reservationstext, ausschließlich vollständige Wischbestätigung und Hintergrund-/Vordergrundwechsel. Die Tests verwenden isolierte synthetische Fahrten und erzeugen keine Production-Buchung.

Web- und Mobile-TypeScript bestanden. Gezieltes Lint für die neuen Module und Tests bestanden. App.tsx hat dieselben sechs bereits vorher bestehenden Lint-Meldungen (Effekt-/Compilerregeln, Metro-Asset-require, Autofokus); kein vollständiges grünes App-Lint behaupten.

Die echten React-Native-Komponenten wurden zusätzlich über React Native Web auf 390×844 Pixel geprüft. Native Details passen ohne horizontalen Überlauf: document.scrollWidth = innerWidth = 390. Lokale Bilder mit gekennzeichneten Testdaten: outputs/customer-trips-063/native-trips.png und native-trip-details.png. Diese Designprüfung ersetzt keinen Android-Gerätetest.

## Grenzen und nächster Schritt

Buchungsformular und Kunden-Live-Karte bleiben in diesem Schritt eingebettet. Der Fahrerbereich ist weiterhin nativ; seine vorhandenen GPS-/Hintergrundfunktionen bleiben erhalten. Vollständige native Kundenbuchung, erweiterte Disposition, echte angemeldete Mehrgerätefahrt und physische Hintergrund-GPS-/Akkutests bleiben offen. Neue native Oberflächen benötigen eine neue interne APK; Website-Veröffentlichung aktualisiert installierte Apps nicht.

Keine neue Migration, Betreiber-/Fahrerfreigabe, Production-Testfahrt, Providerbudget-Änderung oder Store-Einreichung. Neue Textadressbestätigung bleibt bis zur ausstehenden konkreten Geoapify-Vertrags-/Konto-Zustimmung und Einrichtung gesperrt; Mapbox-Permanent-Budget bleibt null. Konten und Buchungen sind bereits freigegeben und benötigen keine erneute allgemeine Aktivierungsbestätigung. Vor offiziellem kommerziellem Start bleibt ein geeigneter Hostingtarif notwendig.

## Tatsächliche interne APK- und Startprüfung

Beide APKs 0.6.3 / Build 17 sind gebaut, ARM64-Bundle, App-Variante, Berechtigungen, Backup-Sperre und Signatur geprüft. Kunden-App hat keine Fahrer-Hintergrundberechtigungen, Fahrer-App behält Hintergrundstandort/Foreground-Service/Fahrtalarme. Signatur SHA-256: fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c; entspricht 0.6.2. Updates ohne Deinstallation im isolierten Emulator installiert. Kunden-Startbildschirm mit Fahrten-Tab sichtbar; Fahrer drei kalte Starts, danach tatsächlicher initialisierter nativer Startbildschirm und lebender Prozess bestätigt. Kein Fatal-/React-Native-JS-Absturz. Mapbox-Starttest am echten installierten SDK bestätigt erwartete ConfigurationException ohne Token sowie erfolgreiche MapView-Konstruktion/-Freigabe nach Initialisierung. Keine Anbieteranfrage oder echte Standortdaten dafür erforderlich.

| Datei in mobile/artifacts | Bytes | SHA-256 |
| --- | ---: | --- |
| Luxore-Ride-Test-0.6.3.apk | 55.541.872 | dfca63c4545dd9cbacb30c56a5de3e6bc515f072e4ab1745084a0f46cf9d1ff8 |
| Luxore-Driver-Test-0.6.3.apk | 55.514.060 | 6222635d5e878a207c6ae7626311e673158411b6f82eaac866ccb54f52803739 |

Bei der lokalen Buildprüfung waren synchronisierte Konfliktkopien in generierten Android-/Kotlin-/Abhängigkeits-Buildcaches vorhanden; sie wurden unverändert in work/customer-trips-063 gesichert. Keine Quell-/Schlüssel-/Geschäftsdateien gelöscht. Fahrer-Build in einem getrennten temporären Ordner mit denselben geprüften Quellen und gemeinsamen Navigationsmodulen erstellt. Bisherige APKs bleiben erhalten. Diese SDK-/Emulatorprüfung ist weiterhin kein physischer oder angemeldeter kompletter Fahrt-/GPS-Nachweis.

## GitHub-/Vercel-Veröffentlichung

Quellbasis 25b865d, öffentlicher GitHub-Commit edf6c74b171167b7edf34f66e02a3a9fded36630. Archiv mit 424 Dateien, 7.621.194 Bytes, SHA-256 06e613906aabf578236aed1bc96db52f413ceac1843d066686ef3f7d0b7a605e. Archiv, Versionsnachweis und README bytegenau abgeglichen. Keine APKs, Signierdateien, privaten Umgebungsvariablen oder persönlichen Konfliktdateien im Archiv. Sauberer tatsächlicher Next.js-Archivbuild bestanden. Vercel BH75cAfmfonS6Uz6auYpCAVUqLAX ist Ready / Latest / Current Production unter luxoreride.de. Live-Health bestätigt Datenbank-, Konto- und Buchungsbereitschaft; Konto-API bleibt anonym ohne Betreiberrechte, Kunden-/Fahrer-/Dispositionsseiten HTTP 200. Native Änderungen werden erst durch APK-Installation auf dem Handy wirksam. Veröffentlichung dieser Nachweise ändert keinen Runtime-Code.

Interne Downloads sind als eigener geschützter GitHub-Entwurf gespeichert: https://github.com/0711hany-source/luxore-ride-website/releases/tag/untagged-c83aa997bb781f7cf48d. Er bleibt unveröffentlicht und benötigt das berechtigte bestehende GitHub-Konto; keine neuen Personenberechtigungen erteilt. Alter 0.6.2-Entwurf und dessen Downloadlinks unverändert. Die getrennte Website-Veröffentlichung ersetzt keine APK-Installation. Der Fünf-Stunden-Rhythmus bleibt aktiv; die Automation ist auf 0.6.3 und die native Kunden-Fahrtenübersicht berichtigt. Kein neuer APK-E-Mail-Versand in diesem Durchlauf.
