# Schichtgebundene GPS-Erstortung · Fahrer 0.7.8 / Build 32

Ein reproduzierter Fehler im tatsächlichen nativen Ortungsdienst konnte einen verspäteten Erstortungspunkt einer alten Freigabe unter einer inzwischen gestarteten neuen Freigabe hochladen. startLocation startet nach der Diensteinrichtung eine einmalige getCurrentPositionAsync-Abfrage. Der bisherige then-Callback rief später deliver auf, das erst dann die aktuelle Schichtfreigabe las. Bei Pause/Neustart oder neuer Freigabe konnte dadurch ein Punkt der älteren Anfrage den neuen Cache befüllen und mit dem neuen Token gesendet werden. Auch die Erneuerung derselben sessionId war betroffen.

Der Callback prüft jetzt die bereits beim Start festgehaltene LocationLifecycle-Version vor deliver. Jede spätere Pause, Freigabeerneuerung oder neuer Start invalidiert ihn. Die bestehende erneute Versions-/Freigabeprüfung innerhalb des serialisierten Cachezugriffs schützt auch einen Wechsel während der anschließenden asynchronen Verarbeitung. Alte native Abfragen dürfen weiterhin auslaufen; sie werden nicht in eine spätere Freigabe umgebunden. Keine bestätigenden Schicht-/Fahrtwrites oder unabhängige Hintergrundortung abbrechen.

GPS-Qualitätsprüfung, Rohkoordinaten, Berechtigungen, Updateintervalle, Server-Authentifizierung und Anbieter bleiben unverändert. Keine neue Positionswarteschlange oder automatische Schichtfreigabe. Bei Netzverlust bleibt ein gültiger aktueller Fix im geschützten Cache; der nächste frische Hintergrundpunkt lädt wieder hoch. Alte Upload-Ablehnungen dürfen eine neue Schicht weiterhin nicht stoppen.

## Prüfungen

Sechs neue tatsächliche location-service-Tests mit isolierten Expo-Location-/TaskManager-/SecureStore-/Benachrichtigungsadaptern und abgefangenem fetch. Drei scheitern im vorherigen Quellstand und bestehen mit der Korrektur:

- Alte Erstortung nach Wechsel zur neuen Schicht: weder Upload noch Cache-Eintrag unter neuer Freigabe.
- Erneuerung derselben sessionId mit neuem Token verwirft die ältere Erstortung ebenfalls.
- Pause mit anschließendem Neustart erhält den neuen leeren Cache trotz später alter Antwort.
- Aktuelle Erstortung wird unverändert geschützt gespeichert und mit der aktuellen Freigabe gesendet.
- Tatsächlicher Hintergrund-Task erhält den Cache bei Netzverlust und lädt den nächsten frischen Fix nach Rückkehr hoch.
- Eine verspätete 401 des alten Uploads beendet weder neue Freigabe noch neuen nativen Dienst.

Die Tests verwenden synthetische Orte und lokale Adapter; sie lösen keine Production-Fahrt, Schicht oder Position aus. Gesamtstand 543 Tests bestanden; beide TypeScript-Prüfungen, gezieltes Lint und Format bestanden. Neue Fahrer-APK 0.7.8 / Build 32 erforderlich, Kunden-APK bleibt 0.6.9 / Build 23. Kein Datenbankschritt, Providerwechsel oder neues Zugriffsrecht. Angemeldete physische SDK-/Mehrgeräte-/Schicht-/Straßen-/Hintergrund-GPS-Prüfungen bleiben offen. Keine Navigationsglättung oder Installation auf Nutzerhandys behaupten.

## Android-Nachweis · 15. Oktober

Fahrer 0.7.8 / Build 32 außerhalb synchronisierter Quell-/Abhängigkeitsordner mit unveränderten 21 direkten installierten Paketversionen, eingefrorenem Lockfile und bestehender Signatur gebaut. 85 Runtime-/Asset-/Konfigurationsdateien einschließlich sämtlicher gemeinsamer Imports stimmen bytegenau überein. Gradle erfolgreich in 3m37s. Varianten-/Standalone-/ARM64-Prüfung bestanden; Berechtigungen exakt wie 0.7.7. Zertifikat SHA-256 fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c unverändert. APK 56.217.452 Bytes, SHA-256 0afe9ff8d4cc414d8b7781d17385cff6d7781c618e5fd7dc5589337d8a756c2c.

Als Update über 0.7.7 ohne Deinstallation im isolierten Emulator installiert; drei anonyme Kaltstarts mit laufendem Prozess und ohne fatale Android-/React-Native-Fehler. Kein angemeldeter Schicht-/SDK-/GPS-Ablauf und keine physische Prüfung. Interne APK bleibt geschützter GitHub-Entwurf, keine öffentliche Binary-/Store-Freigabe. Kunden 0.6.9 / Build 23 unverändert. Keine Production-Fahrt/Schicht oder Migration.

## Veröffentlichungsnachweis

Runtime-Quellstand `8a99765a1e0f89d553161ce2cdf5d94149ff0f5a`, öffentlicher GitHub-Commit `21ca00321ca5e7e33e03c43502205bf996d4210a`. Öffentliches Archiv, SOURCE-VERSION.txt und README.md bytegleich zurückgelesen. Archiv: 518 Dateien, 7.917.825 Bytes, SHA-256 `0d7d33181fca6006ac18e3f2df475999d985bd6dbc038035b9ae56739f053a95`. Tatsächlichen GPS-Dienst, Regressionstests und bestehenden nativen Runtime-/Shared-Quellstand im Archiv exakt geprüft; private Dateien, APKs und persönliche Konfliktkopie ausgeschlossen. Produktionsbuild genau dieses Archivs erfolgreich: 7,6s Kompilierung, 4,8s TypeScript.

Vercel `HJvhRrNQQUtGqjiYX4GY86vbwyVb` ist Ready / Latest / Current Production für luxoreride.de und den genannten Quellcommit; GitHub-Status success. Fünf reine GETs für health, account, Kunden-/Fahrerbereich und Disposition liefern 200; Datenbank/Konten/Buchung bereit. Keine echte Schicht, Position oder Fahrt ausgelöst.

Geschützter interner APK-Entwurf: https://github.com/0711hany-source/luxore-ride-website/releases/tag/untagged-01827fe96d071bcccf09. GitHub bestätigt Asset-Digest `0afe9ff8d4cc414d8b7781d17385cff6d7781c618e5fd7dc5589337d8a756c2c`. Screenshotnachweise: outputs/native-gps-start-078/apk-draft.png und vercel-ready.png. Emulator nach Update/Startprüfung beendet. Dieser nachträgliche Nachweis ändert keinen veröffentlichten Runtime-Code oder das geprüfte Archiv. Nächster unabhängiger Schritt: konkurrierende Vordergrund-/Hintergrund-Uploads und zeitversetzte Angebots-/Serverantworten auf einen weiteren tatsächlich nachweisbaren Fehler prüfen. Physische angemeldete Unternehmensgeräte-/Straßen-/Hintergrund-GPS-Prüfungen bleiben offen.
