# Fahrerposition und Straßenabgleich

Stand: 29.09.2026

Die Fahrerposition wird entlang eines zeitbasierten Pfads animiert. Die Dauer richtet sich nach dem GPS-Takt (650 bis 6.000 ms), statt nach jedem Ping in 900 ms zum Ziel zu fahren und dann zu warten. Neue Messungen übernehmen die aktuell gezeichnete Position. Kamera und Pfeil folgen demselben animierten Punkt. Die Rotation nimmt den kurzen Weg über Norden. Kleine Standabweichungen werden gehalten, langsame echte Bewegungen gesammelt. Es gibt keine Weiterfahrt über den letzten bekannten Messpunkt hinaus. Nach einer längeren Messlücke wird direkt neu positioniert.

Der neue weiß eingefasste, goldene Pfeil liegt in Mapbox auf der Kartenebene: Rotation und Neigung folgen der 3D-Karte. Die bestehende Rückkehr nach manueller Kartenbedienung bleibt bei drei Sekunden. Rohmessungen für Vermittlung und Backend bleiben unverändert.

## Straßen

Freigegebene Fahrer können über `/api/mobility/navigation` kurze, aktuelle GPS-Folgen mit Mapbox abgleichen. Maximal zwölf Anfragen pro Minute und Fahrer, höchstens zehn gesammelte Punkte im Client, sechs Sekunden Mindestabstand zwischen Abfragen. GPS-Spuren werden nicht zusätzlich in der Datenbank gespeichert. Der Provider erhält die Koordinaten zur Durchführung des Abgleichs. Die Funktion nutzt den vorhandenen Mapbox-Zugang und dessen API-Kontingent.

Nur zusammenhängende Matchings mit mindestens 0,8 Konfidenz und einem eindeutigen letzten Punkt werden verwendet. Bei Ausfall, Zeitüberschreitung, veralteter Antwort oder unklarer Zuordnung bleibt der GPS-Pfad verfügbar. Während einer gestarteten Fahrt kann die gebuchte Straßengeometrie als lokale Orientierung dienen. Vor Abholung wird der Fahrer nicht auf die spätere Fahrgaststrecke gezogen. Abweichungen, Rückwärtsprojektionen, lange Umwege und ein Festklemmen jenseits des Routenziels werden verworfen.

Das ersetzt kein vollständiges Navigations-SDK: Sprachansagen, verkehrsabhängige Neuberechnung und komplexe Abbiegeanweisungen bleiben in der extern geöffneten Navigation. Eine Probefahrt auf dem tatsächlichen Fahrergerät ist noch erforderlich, besonders an Parallelstraßen, Unterführungen und bei schlechtem GPS.

## Prüfung

- 20 Tests für GPS-Qualität, Kamerageometrie, automatische Rückkehr, Kurveninterpolation, GPS-Takt, Retargeting ohne Sprung, Stillstand, Messlücken, kurze Drehung über Norden und Match-Validierung bestanden.
- Lokale HTTP-Prüfung: Zugang ohne Fahrerfreigabe und fremder Origin gesperrt; veraltete Eingaben abgewiesen; fehlender Provider-Zugang führt zum sicheren Fallback.
- Separater Provider-Test mit öffentlichen Beispielkoordinaten aus der Mapbox-Dokumentation und dem vorhandenen öffentlichen Mapbox-Token: `Ok`, Konfidenz 0,980288 und eindeutige Punkte. Keine echten Fahrerpositionen oder Buchungen als Testdaten.

Referenzen: [Map Matching API](https://docs.mapbox.com/api/navigation/map-matching/), [Marker-Animation](https://docs.mapbox.com/mapbox-gl-js/example/animate-marker/).

## Weiterarbeit

Die bestehende Codex-Aufgabe ist auf Weiterarbeit alle fünf Stunden umgestellt, mit kurzem deutschem Ergebnisbericht nach jedem Durchlauf. Nächster Praxisschritt: Straßenfahrt auf einem Fahrerhandy prüfen und bei Bedarf den nativen GPS-Takt und die Richtungsdaten weiter verbessern.

## Weiterentwicklung am 30.09.2026 · Kameranachführung

Die Rückkehr in die Fahransicht und die laufende Standortnachführung verwenden jetzt dieselbe Animation. Zuvor konnte das nächste `jumpTo` die gerade gestartete Mapbox-`easeTo`-Rückkehr abbrechen. Die neue `FollowCamera` blendet die tatsächlich sichtbare Kamera innerhalb von 850 ms zur jeweils aktuellen animierten Fahrerposition. Neue GPS-Punkte verschieben das Ziel, ohne die Übergangsfrist neu zu starten. Auch im Stillstand läuft ein begonnener Kameraübergang zu Ende. Manuelle Kartenbedienung bricht die Rückkehr ab; nach den bestehenden drei Sekunden startet sie von der dann sichtbaren Perspektive. Bei reduzierter Bewegung erfolgt die Rückkehr sofort.

Der Blick nach vorn wird durch einheitliches Karten-Padding umgesetzt. Der zuvor verwendete `offset` ist eine Mapbox-Animationsoption und wird von `jumpTo` nicht unterstützt. Dadurch konnte der Pfeil zwischen Rückkehr und laufender Fahrt vertikal versetzt erscheinen. Das einheitliche Padding gilt für kleine und große Fahrtflächen; die 2D-Streckenübersicht bleibt eigenständig.

Referenz: [Mapbox CameraOptions und AnimationOptions](https://docs.mapbox.com/mapbox-gl-js/api/properties/). GPS-Rohdaten, Straßenabgleich, Vermittlung und Buchungen werden durch diesen Schritt nicht verändert. Keine zusätzliche Provider-Abfrage, kein neues Konto und keine APK erforderlich.

Prüfung: 26 gezielte Tests für Kameraübergänge, Standortbewegung, Straßenkurven, Stillstand, Kartenrückkehr, Richtungswechsel und freien Kartenausschnitt; außerdem Typprüfung, Lint der geänderten Dateien und Produktionsbuild. Dies ist ein Hintergrunddurchlauf ohne Browser-Vorschau oder visuelle Geräteprüfung.

Nächster Schritt: echte Probefahrt auf einem Fahrergerät, besonders Rückkehr nach manuellem Verschieben, 2D/3D-Wechsel, große Fahrtfläche und Wiederaufnahme nach gesperrtem Bildschirm. Danach Antwortzeiten des Straßenabgleichs bei häufigen GPS-Punkten untersuchen. Sprachansagen und verkehrsabhängige Routenänderungen bleiben weiterhin Aufgabe der gewählten externen Navigation.

## 30.09.2026 · Android-Probefahrt: weniger Nachlauf und Verkehrsroute

Der Nutzer meldete seitliches Pendeln beim Anfahren und 1–2 Sekunden Nachlauf im Kreisverkehr mit der Android-Fahrer-APK. Deshalb ist für die eigene Fahreransicht die bisherige zusätzliche Animation über ein vollständiges GPS-Intervall ersetzt: neue Messungen werden jetzt innerhalb von höchstens 280 ms eingeholt. Die Kundenansicht behält die ruhigere Interpolation seltenerer Fernmessungen. Die eigene Pfeilrichtung nutzt bei Bewegung die gültige Android-Fahrtrichtung (ab 1,5 m/s, Genauigkeit höchstens 30 m); fehlende Richtungsdaten werden erst nach ausreichender tatsächlicher Bewegung ersetzt. Kleine seitliche Korrekturen drehen den Pfeil nicht mehr. Kein ungemessenes Weiterfahren bei ausbleibenden Messpunkten.

Android-Testversion 0.4.2 / Versionscode 7 fordert im Vordergrund `BestForNavigation` und 1.000 ms an statt 3.000 ms. Richtung und Geschwindigkeit erreichen die Webansicht. Der Hintergrunddienst erhält Navigationsgenauigkeit, bleibt aber bei fünf Sekunden und den bisherigen Schicht-/Berechtigungsregeln. Die native Änderung erfordert einmalig die neue APK. Die Datei liegt unter `mobile/artifacts/Luxore-Driver-Test-0.4.2.apk`; Signatur entspricht 0.4.1. Darüber installieren, nicht vorher deinstallieren. Signatur, ARM64-Bundle, Paketkennung, Versionscode und Berechtigungen sind geprüft. Das tatsächliche Messintervall hängt von Android und GPS-Empfang ab.

`/api/mobility/guidance` berechnet nur für den freigegebenen, zugeordneten Fahrer einer aktiven Fahrt. Ziel ist serverseitig die Abholung bei `accepted`, das Fahrtziel bei `riding`. Client-Zielangaben werden ignoriert; nach Provider-Antwort wird die Zuordnung/Phase erneut geprüft. Keine Änderung an Buchung, Preis oder gebuchter Route. Frischer GPS-Punkt mit höchstens 50 m Genauigkeit erforderlich, vier Abfragen pro Minute erlaubt. Der sichtbare Client fragt normalerweise alle 45 Sekunden ab; bei mehr als 40 m Abweichung (bzw. 1,5-facher GPS-Ungenauigkeit) frühestens nach 15 Sekunden. Keine Abfragen bei versteckter Seite, fehlendem GPS oder paralleler laufender Anfrage. Antworten einer anderen Fahrt/Phase werden verworfen. Nach Ausfall wird der Verkehrsstatus als nicht aktuell markiert, nach 90 Sekunden die alte Verkehrsroute verworfen. Gebuchte Strecke bleibt als Fallback verfügbar.

Mapbox-Profil bleibt `driving-traffic`, nun mit vollständiger Geometrie, Alternativen, `exclude=unpaved` und aktueller Abfahrtszeit. Kein Ausschluss von Nebenstraßen und keine zusätzliche Hauptstraßenpräferenz. Aus den befahrbaren Alternativen wird die schnellste gewählt; innerhalb höchstens 30 Sekunden UND 5 Prozent Zeitunterschied gewinnt die kürzere Strecke. Gemeldete unbefestigte Abschnitte werden gegenüber befestigten Alternativen nachrangig behandelt; wenn keine solche Alternative geliefert wird, erscheint ein Hinweis beim Buchen und in der Fahreransicht. Die Datenlage des Kartenanbieters bleibt maßgeblich. Bei gültiger Bewegungsrichtung wird diese auch als Start-Richtungsbereich an die Live-Routenabfrage gegeben. Keine erfundenen Sonderrechte für Taxispuren oder gesperrte Gassen.

Straßenabgleich: Antworten müssen nicht mehr exakt denselben Zeitstempel wie der allerneueste Sekunden-Punkt haben. Bis zu sechs Sekunden alte, eindeutige Geometrie kann verwendet werden, solange der aktuelle Punkt darauf liegt. Veraltete Endpunkte dürfen das Fahrzeug nicht festhalten. Das vermeidet, dass beim schnelleren GPS-Takt jede etwas langsamere Provider-Antwort verworfen wird.

Verkehrsabfragen nutzen den vorhandenen Mapbox-Zugang und dessen Kontingent. Der vorhandene öffentliche, vom Nutzer bereitgestellte Mapbox-Token wurde auch in die ignorierten lokalen Entwicklungseinstellungen übernommen, um echte Provider-Antworten zu testen. Keine neuen Konten, keine zusätzlichen Tarifbuchungen, keine Datenbankmigration.

Prüfung: 33 gezielte Tests für Bewegung, Richtung, Kreisverkehr, Stillstand, Routenauswahl, Wiederholungsintervalle, veraltete Antworten und Kamera bestanden. Lokaler HTTP-Test mit isolierten Frankfurt-Testdaten: echte Mapbox-Routen mit 51/93 Geometriepunkten für Abholung/Ziel; Geräteidentität, fremde Fahrer, Freigabe, abgeschlossene Fahrt, Origin, GPS-Frische und Rate-Limit geprüft; gebuchter Preis und Route unverändert. Ausfallantwort ohne lokalen Token ebenfalls geprüft. Android-Typprüfung und APK-Verifikation bestanden. Web-Typprüfung, Lint und Produktionsbuild ebenfalls bestanden; zusätzliche Regressionstests für Fahrpreise, native Standortanfragen und die Standortbrücke bestanden.

Nächster Praxisschritt: Version 0.4.2 auf dem Fahrerhandy installieren und dieselbe Strecke mit Anfahren, Kreisverkehr und Ampel wiederholen. Sprachansagen und detaillierte Abbiegeführung bleiben in der extern gewählten Navi-App. Es gab keine erneute echte Gerätefahrt und keine visuelle Browser-Prüfung in diesem Durchlauf.

Referenzen: [Mapbox Directions: Verkehr, vollständige Geometrie und Ausschlüsse](https://docs.mapbox.com/api/navigation/directions/), [Expo Location SDK 57: Genauigkeit, Fahrtrichtung und Zeitintervall](https://docs.expo.dev/versions/v57.0.0/sdk/location/).

## 30.09.2026 · Navigationsbildschirm während aktiver Fahrten

Der feste Navigationskopf ersetzt die bisherige Ziel-/Streckenkarte. Er zeigt den nächsten deutschen Mapbox-Abbiegeschritt mit Richtungssymbol, Entfernung zum Manöver sowie geschätzter Ankunftszeit (Europe/Berlin), Restzeit und Reststrecke. Kreisverkehre erhalten ihre Ausfahrtsnummer; getrennte Ausfahrtsschritte werden beim Provider angefordert. Bei kurz aufeinanderfolgenden Manövern erscheint zusätzlich der folgende Schritt mit Zwischenentfernung. Ankunft in Zielnähe ist ein Hinweis und bestätigt keine Abholung oder Fahrt automatisch.

Nur der bestehende Fahrer-Guidance-Endpunkt fordert `steps=true` und `roundabout_exits=true` an. Preisangebote und gespeicherte Buchungsrouten behalten ihre bisherige Datenform. Die normalisierten Routenschritte werden vollständig validiert und sind mengenbegrenzt; bei unvollständigen Schritten wird keine Teilnavigation angezeigt. Preise, Zuordnung, Fahrerfreigabe und das bestehende Rate-Limit bleiben unverändert.

Die lokale Fortschrittsberechnung projiziert frische GPS-Punkte auf die Geometrie der Routenschritte. Sie berücksichtigt Bewegungsrichtung, den letzten zuverlässigen Fortschritt und eine begrenzte Vorwärtsbewegung. Uneindeutige Überlagerungen/Schleifen und zu große Sprünge ergeben keine Anweisung. Die nächste Abbiegung wechselt erst nach dem Kreuzungspunkt mit kleiner Hysterese; rückwärtiges GPS-Rauschen setzt bereits passierte Anweisungen nicht zurück. Restzeit wird aus den verbleibenden Schrittzeiten berechnet, nicht einfach seit der letzten Anfrage heruntergezählt. Im Stillstand bleibt die Restfahrzeit erhalten und die geschätzte Ankunft verschiebt sich entsprechend.

Für Manöver gelten maximal zehn Sekunden alte GPS-Daten und höchstens 35 m gemeldete Ungenauigkeit. Bei unklarem Standort werden Pfeilhinweis und Kennzahlen ausgeblendet. Standortfehler und „Standort prüfen“ bleiben direkt erreichbar. Offline darf eine noch gültige Route weiterführen, wird aber als gespeicherte Route markiert; spätestens nach den bestehenden 90 Sekunden wird sie verworfen. Fehlgeschlagene Verkehrsabfragen erscheinen als nicht aktuell. Anweisungen und Schätzungen bleiben vom gebuchten Preis getrennt.

Bei Anfahrt und Fahrt startet das Wischmenü klein. Navigationskopf und Menü reservieren jeweils Platz für die Karte. Die tatsächliche Kopfhöhe wird beobachtet; die maximale Menüausdehnung und Kameraposition berücksichtigen diesen Platz. Die Standardgesten anderer Ansichten bleiben unverändert. Eine ausdrücklich als Beispiel bezeichnete neue Ansicht unter `/app-ansichten#navigation` nutzt dieselbe Komponente und zeigt Abbiegen, Kreisverkehr, fehlendes GPS und Offline ohne echte Fahrt oder Standortübertragung.

Validiert: 51 Tests für Manöverschritte, Fortschritt, Kreisverkehr-/Kurvenpfad, GPS-Ausfall, Rücksprünge, überlappende Straßen, veraltete Routen, Kameraplatz und Gesten sowie servergerenderte Navigationszustände. Echte lokale Mapbox-HTTP-Tests lieferten sechs Anweisungen zur Abholung und sieben zum Fahrtziel; Identität, Freigabe, Zuordnung, Origin, frisches GPS, Rate-Limit und unveränderter Buchungspreis geprüft. Web-Typprüfung, Lint und Produktionsbuild erfolgreich. Keine visuelle Browserprüfung und keine echte Gerätefahrt durchgeführt.

Diese Änderung kommt über die bestehende Weboberfläche; keine zusätzliche APK erforderlich. Die Fahrer-APK 0.4.2 bleibt für den schnelleren nativen GPS-Takt empfohlen. Keine automatische Sprachausgabe ergänzt; die gewählte externe Navigation bleibt verfügbar. Nächster Praxisschritt: Abbiegezeitpunkt, Kartenplatz, große Schrift, Ampelstand und Wiederaufnahme nach GPS-Ausfall auf dem Fahrerhandy prüfen.

Quelle: [Mapbox Directions API – Route Step / Step Maneuver](https://docs.mapbox.com/api/navigation/directions/).

## 01.10.2026 · Neue Route nach Umkehr, Abweichung und GPS-Ausfall

Eine reine Entfernungsmessung zur Route erkennt keine Umkehr auf derselben Straße. Die Wiederaufnahme berücksichtigt jetzt zusätzlich die verlässliche Fahrtrichtung bei mindestens 3 m/s und höchstens 25 m GPS-Ungenauigkeit. Nahe Routensegmente werden gemeinsam betrachtet, damit Kurven mit verzögerten Richtungsdaten keinen falschen Alarm auslösen. Rangieren innerhalb von 25 m zum Routenziel löst keine Richtungs-Neuberechnung aus.

Eine Abweichung muss durch unterschiedliche, aktuelle GPS-Punkte über mindestens drei Sekunden bestätigt werden; eine falsche Fahrtrichtung zusätzlich durch mindestens sechs Meter Bewegung. Ein einzelner Ausreißer oder wiederholtes Lesen desselben Standorts genügt nicht. Bei mehr als zehn Sekunden zwischen Messungen beginnt die Bestätigung erneut. Jede neue Route und Fahrtphase erhält eine eigene Beweislage. Die seitliche Schwelle bleibt bei mehr als 40 m beziehungsweise der 1,5-fachen gemeldeten Ungenauigkeit. Der Mindestabstand von 15 Sekunden zwischen Routenanfragen und die normale Verkehrsaktualisierung alle 45 Sekunden bleiben erhalten.

Bei bestätigter Abweichung verschwinden alte Manöver, Entfernungen und Ankunftsschätzungen. Der Navigationskopf zeigt die Suche nach einer neuen Route; ohne Internet erscheint „Neue Route benötigt“. Die Abweichung wird auch während einer laufenden Anfrage oder ohne Verbindung weiter ausgewertet. Nach einer GPS-Messlücke von mehr als 15 Sekunden wird der alte Fortschrittsanker verworfen und die Position mit den bestehenden Mehrdeutigkeitsprüfungen neu zugeordnet. Der Ladezustand ist an Fahrt und Phase gebunden und läuft nach 15 Sekunden aus; abgebrochene Anfragen können ihn nicht in die nächste Fahrt übertragen.

Validiert: 60 Tests für Umkehr, GPS-Ausreißer, wiederholte Messpunkte, Kurven, Rangieren, längere GPS-Ausfälle, neue Routen, Anfragebegrenzung, ausgeblendete Manöver sowie bisherige Kamera-, Gesten- und Navigationsfunktionen bestanden. Typprüfung, Lint der geänderten Dateien und Produktionsbuild erfolgreich. Keine API-, Datenbank-, Preis- oder native Änderung; keine neue APK erforderlich. Dieser Durchlauf enthält keine visuelle Browserprüfung und keine echte Gerätefahrt.

Nächster Praxisschritt: auf dem Android-Fahrerhandy eine Umkehr, das bewusste Verlassen der Route sowie Wiederaufnahme nach GPS- und Internet-Ausfall prüfen. Dabei besonders auf falsche Neuberechnungen in engen Kurven und die Wiederkehr der passenden Abbiegehinweise achten.

## 01.10.2026 · Navigation bei Menüwechsel und Verbindungsunterbrechung

Das Öffnen des App-Menüs oder der Navigationseinstellungen deaktiviert vorübergehend die Fahreransicht. Bisher verlor die Routenabfrage dabei ihren internen Zeitstempel und startete nach jedem Schließen erneut. Wiederholte Menüwechsel konnten dadurch das bestehende Abfragelimit erreichen. Eine Navigationssitzung je Fahrt und Phase behält jetzt ihre gültige Route, Abweichungsprüfung und Abfragefrist über solche Pausen hinweg. Die Karte behält dieselbe gültige Route, statt während des Menüs auf die ursprüngliche Buchungsstrecke umzuschalten und den Manöverfortschritt zurückzusetzen. Für eine andere Fahrt oder Phase beginnt eine getrennte Sitzung; Abhol- und Zielnavigation werden nicht vermischt.

Beim Verlassen der sichtbaren App, beim Öffnen des Menüs oder bei gemeldetem Verbindungsverlust wird eine laufende Routenanfrage abgebrochen. Eine gültige gespeicherte Route bleibt verfügbar. Zurückkehrende Antworten und Fehler abgebrochener Anfragen können weder eine neuere Route überschreiben noch deren Ladezustand beenden. Nach Rückkehr werden GPS-Frische und die bestehenden Abfragefristen erneut geprüft. Auch wenn Android Zeitgeber während einer Pause aussetzt, kann eine über 15 Sekunden alte Anfrage beim nächsten Durchlauf nicht unbegrenzt blockieren. Antworten nach dieser Frist werden nicht übernommen.

Nach einem Fehler oder einer unterbrochenen Anfrage darf der Client ab 15 Sekunden nach dem letzten Versuch erneut anfragen, statt ohne Route 45 Sekunden warten zu müssen. Erfolgreiche Aktualisierungen bleiben im normalen 45-Sekunden-Takt. Ohne frisches GPS, ohne Internet oder bei unsichtbarer App startet keine neue Anfrage. Die bestehenden serverseitigen Grenzen und die Gültigkeitsdauer gespeicherter Routen bleiben erhalten.

Prüfung: 62 gezielte Tests bestanden, darunter neun neue Tests für wiederholte Menüwechsel, verspätete Antworten, Abbruch, Internet-Ausfall, Rückkehr mit veraltetem GPS, hängende Anfragen, Fehlerwiederholung und getrennte Fahrtphasen. Typprüfung, Lint und Produktionsbuild ebenfalls erfolgreich. Keine Änderung an Buchungen, Preisen, Datenbank oder nativer Android-Version; keine neue APK nötig. Hintergrunddurchlauf ohne Browser-Vorschau, visuelle Prüfung oder echte Gerätefahrt.

Nächster Praxisschritt: Auf dem Fahrerhandy während einer Navigation Menü und Einstellungen mehrmals öffnen, kurz zu einer anderen App wechseln und nach vorübergehendem Verbindungsverlust zurückkehren. Die Route soll ohne erneutes Laden bei jedem Menüwechsel erhalten bleiben. Standort, Karte und Hinweise bei längerer Bildschirmsperre bleiben Teil der ausstehenden Geräteprüfung.
