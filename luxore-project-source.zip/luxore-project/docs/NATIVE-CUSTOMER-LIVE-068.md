# Native Kunden-Live-Ansicht · 0.6.8 / Build 22

## Abgeschlossener Entwicklungsschritt

Die Buchungsbestätigung und die native Fahrtenliste öffnen die ausdrücklich gewählte Fahrt in `CustomerLiveScreen`. Keine eingebettete Live-Webseite. Das Root-Menü bleibt nativ; auf dieser Kartenansicht entfällt die untere Tab-Leiste. Helle Streets-v12-Karte zeigt vorhandene Straßenroute, Abhol-/Zielpunkt, den frischen zugeordneten Fahrer oder während requesting maximal drei anonymisierte ungefähre Suchfahrzeuge. Es werden keine Ankunftszeiten, Straßenbewegungen oder verfügbaren Fahrer erfunden. Die Fahrerposition wird mit bestätigten Messpunkten aktualisiert; dies ist keine vollständige Navigationsglättung.

Das feste Fahrtdetailfeld lässt sich am Griff durch Wischen ein-/ausklappen. Schrift, Flächen und Goldakzente passen zu den übrigen nativen Ansichten. Karte bleibt sichtbar, lange Details scrollen innerhalb des Felds. Fahrer, tatsächliches zugeordnetes Fahrzeug/Kennzeichen aus der hydratisierten Serverantwort, Klasse, Preis, Abholort/Ziel, Reservierungs-/Zahlstatus und bestätigte Bordbestellung sind lesbar. Der Sicherheitsdialog ist ein eigener fester nativer Vollbilddialog. Notruf und Chauffeuranruf öffnen nur durch ausdrückliches Tippen die Telefonfunktion; Support öffnet die eigene Hilfe. Die Live-Ansicht verändert keine Fahrt. Stornieren erfolgt weiterhin in der nativen Fahrtenansicht ausschließlich durch vollständiges Wischen. Zusätzliche Bordbestellungen während der Fahrt bleiben nächste Integrationsarbeit; die neue Live-Ansicht zeigt bereits bestätigte Bestellungen.

## Lifecycle, Kosten und Kartenstart

Der vorhandene `CustomerLiveController` ist pro Sitzung/Eigentümer isoliert. Beide tatsächlichen API-Lesewege erhalten AbortSignal. Sichtbare Ansicht fragt höchstens alle fünf Sekunden ab; manuelle Fahrtwiederholung ist zusätzlich auf fünf Sekunden begrenzt. Die Umgebungssuche erfolgt nur für requesting. Verlassen oder Hintergrund stoppt Polls und bricht alte Leseanfragen ab; Vordergrund startet sofort neu. Ein Sekundentakt lässt veraltete Marker/Kontakt auch während einer ausstehenden Antwort verschwinden. Detaildaten bleiben bei Netzverlust lesbar, 401/403 entfernt sie. Explizite Fahrtwahl kann niemals auf eine andere Fahrt wechseln. Kein eigener Kunden-GPS-Schreibvorgang und keine neue Routen-/Geokodierungsanfrage pro Poll.

SDK wird erst nach aktivem Bildschirm und Token innerhalb einer Fehlergrenze geladen. `MapStartup` setzt den öffentlichen Token vor Telemetrie und MapView. Import-, Initialisierungs- und Kartenladefehler bieten Wiederholung. Kartenladen hat ein 20-Sekunden-Limit. Karte verwendet denselben hellen Stil wie die Fahrer-App, native Routen-/Marker-Layer und sichtbare Lizenzhinweise. Nach manueller Kamerageste wird die Fahrtausdehnung nach drei Sekunden wiederhergestellt; die freie native Kartenpunktwahl bleibt davon unberührt. Eigene Konfigurationsabfrage verwendet das tatsächliche Serverfeld publicMapToken, wird bei Verlassen abgebrochen und kann keine veraltete Antwort übernehmen.

## Prüfungen und tatsächliche Grenzen

Neun neue Prüfungen, insgesamt 391 Tests: echte React-Native-Komponenten einschließlich App-Navigation mit exakter Fahrtauswahl, Wischfeld, native Sicherheitsseite, fahrtspezifische anonymisierte Suchpunkte, Hintergrundpause/Rückkehr, echte HTTP-Abbruchsignale, 401 und Konfigurationsfehler sowie zeitlicher Verfall bei hängender Leseantwort. Zusätzlich Lazy-Import/Fehlergrenzen-Wiederholung und Karten-Initialisierung mit fehlgeschlagenem Tokenstart vor MapView. SDK-Antworten in Komponententests sind isoliert; keine Production-Testfahrt oder Kundendatenänderung.

Lokale echte Bildschirmkomponente auf 390 × 844 und 390 × 640 ohne horizontalen oder äußeren vertikalen Überlauf geprüft, einschließlich einklappbarer Ansicht. Vorschaubilder in outputs/native-customer-live verwenden ausdrücklich synthetische Karte und Testfahrt. Kein Beweis für echten angemeldeten Mapbox-Lauf oder GPS-Qualität auf Unternehmenshandys. Web-/Mobile-TypeScript und gezieltes Lint der neuen Module sind geprüft; bestehender kompletter App-Lint wird nicht als fehlerfrei behauptet.

Kunden-APK 0.6.8 / Build 22 im isolierten Android-Quellbaum mit unveränderten Abhängigkeitsversionen gebaut. Signatur und Runtime-Variante geprüft, als Update über 0.6.7 ohne Deinstallation im eigenen Emulator installiert; drei kalte Starts ohne native Fatal-/JS-Abstürze. Die Startprüfung ist anonym, kein angemeldeter echter Live-SDK-Fahrtablauf. Veröffentlichungsnachweis folgt nach tatsächlicher Prüfung. Fahrer-APK bleibt unverändert 0.6.4 / Build 18. Website-Veröffentlichung installiert keine neue APK auf Nutzergeräten. Angemeldete physische Mehrgeräte-/Fahrtprüfung, Fahrer-Hintergrund-GPS und erweiterte native Disposition bleiben offen. Keine neue Migration, Rechte-/Tarif-/Budgetänderung oder Store-Einreichung.


## APK-Nachweis

Datei `mobile/artifacts/Luxore-Ride-Test-0.6.8.apk`, 56135428 Bytes, SHA-256 `37d6e1066a1fc32e7be8773abfdb5d58cdd6d3e751358f985db80e9fcca8024d`. Interne unveränderte Signatur `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c`, Paket de.luxoreride.customer.preview. Standalone-ARM64-Bundle, nicht debuggbar, Backup/Designvorschau aus, keine Fahrer-Hintergrund-, Mikrofon-/Overlay-Berechtigung. 43 gebaute Runtime-/Konfigurationsquellen bytegenau verglichen. Screenshot: outputs/native-customer-live/customer-emulator-start.png. Keine Store-Signatur oder Installation auf Nutzerhandys behaupten.


## Quellveröffentlichung geprüft

Paketierter lokaler Quellstand e0e67f3, Runtime 9d3539f. GitHub `6664d94aa480b6fb5926e087c2899e4940dd809a` enthält drei bytegenau geprüfte Quellartefakte. Archiv: 466 Dateien, 7743722 Bytes, SHA-256 `3b05099e32f9e0028c2a3e72e262b6fc87a970f28b76eea4f2c20c6a33e6f758`. Genau dieser Quellstand besteht den frischen Next.js-Produktionsbuild. APKs, Schlüssel, private Umgebungen und untracked ROADMAP-Kopie sind ausgeschlossen.

Vercel `3dos3AFzfENew8pUp68GkNWyrxgE` bestätigt Ready / Latest / Current Production mit diesem GitHub-Commit unter luxoreride.de. Screenshot: outputs/native-customer-live/vercel-ready.png. Health, anonyme Konto-API, Kunden-/Fahreransicht und Disposition antworten mit HTTP 200; Datenbank, Konten und Buchungen bereit, anonyme Antwort ohne Konto/Betreiberrechte. Keine Production-Schreibprüfung oder echte GPS-/Fahrtabfrage.

Automation ACTIVE alle fünf Stunden mit aktuellem Stand 391 Tests und Kunden-APK 0.6.8, Fahrer unverändert 0.6.4. Weitere native Bordbestellungen und reale angemeldete Prüfungen bleiben offen. Dieser nachträgliche Prüfnachweis verändert keine bereits veröffentlichten Runtime-/Archivbytes.

## Geschützter APK-Download geprüft

Der gespeicherte GitHub-Release-Entwurf [LUXORÉ Ride 0.6.8 · Interner Kundentest](https://github.com/0711hany-source/luxore-ride-website/releases/tag/untagged-2e4dcf0eaa2648c88a82) enthält genau ein Asset `Luxore-Ride-Test-0.6.8.apk` mit 53,5 MB. Der von GitHub am Asset angezeigte SHA-256 stimmt mit der geprüften lokalen APK überein: `37d6e1066a1fc32e7be8773abfdb5d58cdd6d3e751358f985db80e9fcca8024d`. Screenshot: outputs/native-customer-live/private-apk-download.png. Der Entwurf ist nur mit bestehendem berechtigtem GitHub-Konto zugänglich; keine öffentliche Release-Veröffentlichung oder neue Zugriffsrechte. Ältere APK-Entwürfe bleiben erhalten. Kein E-Mail-Versand in diesem Durchlauf.
