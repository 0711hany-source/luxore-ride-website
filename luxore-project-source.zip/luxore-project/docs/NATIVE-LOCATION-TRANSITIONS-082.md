# Native GPS-Startübergänge · Fahrer 0.8.2 / Build 36

## Reproduzierter Ablauf

startLocation prüfte seine ursprüngliche LocationLifecycle-Version nur beim Eintritt in den serialisierten Speicher-/Dienstabschnitt. Während await offerAlerts.clear, Cachelöschung oder Credentialspeicherung konnte inzwischen eine Pause oder ein neuer Start die Version ändern. Der alte Start speicherte trotzdem weiter und startete den nativen Dienst. Selbst wenn eine Pause während eines bereits begonnenen nativen Starts eintraf, konnte dessen alter Abschluss noch einen Erstortungsabruf anfordern und seinen Start als erfolgreich beendet behandeln.

Ein lokaler requireCurrent-Guard prüft jetzt dieselbe ursprüngliche Version am Eintritt sowie nach jeder dieser Wartezeiten und nach dem nativen Dienststart. Ein inzwischen überholter Start endet mit der vorhandenen Meldung „Die Standortfreigabe wurde inzwischen beendet.“; er setzt keine weitere alte Mutation oder Erstortung in Gang. Bereits begonnene Speicher-/native Operationen werden nicht abgebrochen oder rückwirkend ungeschehen gemacht. Der bestehende serialisierte nachfolgende Stopp/Neustart bereinigt beziehungsweise ersetzt den Stand. Die bedingte Fehlerbereinigung des alten Starts bleibt an Session und ursprüngliche Version gebunden, damit sie neuere Freigaben nicht löscht. Keine Änderung am Server-Schichtauftrag, keine automatische Wiederholung bestätigender Writes.

## Verhaltenstests

Sieben neue Tests führen den tatsächlichen location-service mit isolierten Expo-Location-/TaskManager-/SecureStore-/Alarmadaptern und abgefangenem fetch aus. Fünf Regressionen scheitern im alten Dienst, alle sieben bestehen mit der Korrektur:

- Pause während ausstehender Alarmbereinigung verhindert alte Credentialspeicherung und GPS-Start.
- Erneuerung derselben sessionId während Alarmbereinigung startet ausschließlich den neuen Token.
- Pause während Cachelöschung verhindert anschließende alte Speicherung/Start.
- Neuer Start während bereits begonnener Credentialspeicherung verhindert alten GPS-Start und erhält die neue Session/Capability. Die bereits begonnene Speicherung darf auslaufen.
- Pause während bereits begonnenem nativem GPS-Start lässt dessen API auslaufen, verwirft den alten Abschluss/Erstortungsabruf und stoppt den tatsächlichen Dienst geordnet mit Server-Stopp unter ursprünglichem Token.
- Wiederaufnahme während ausstehender Hintergrundberechtigung startet nach Pause weiterhin keinen Dienst (bestehender Kontrollfall).
- Ununterbrochener gültiger Start speichert exakte Capability, startet einmal und fordert genau eine Erstortung an (bestehender Kontrollfall).

Alle Punkte sind lokale synthetische Aufrufe. Keine Production-Schicht, Position, Alarme, Fahrt oder Rechteänderung. Berechtigungen, Rohkoordinaten, Qualitäts-/Netzcachefilter, Alarm-Deadlines/-Freigabe, Intervalle und serverseitige Authentifizierung unverändert. Keine neue API, Migration oder Provider.

## Grenzen

Hängende native Promises sind damit nicht zeitlich begrenzt. Bereits laufende native Operationen können erst nach ihrem Abschluss durch den folgenden serialisierten Übergang bereinigt werden; keine sofortige rückwirkende OS-Stoppgarantie. Physische angemeldete Unternehmensgeräte-/Schicht-/Hersteller-/Straßen-/Hintergrund-GPS-Prüfungen bleiben offen. Native Startversionsprüfung ist keine Navigationsglättung.

Kunde bleibt 0.6.9 / Build 23, Fahrer benötigt 0.8.2 / Build 36. APK ausschließlich geschützter interner GitHub-Entwurf, keine öffentliche Binary-/Store-Freigabe. Website-Veröffentlichung installiert keine APK auf Nutzerhandys. 571 Tests, beide TypeScript-Prüfungen, gezieltes Lint/Format und diff-Prüfung bestanden. Build außerhalb synchronisierter Quellen mit vollständigem Importbaum in 4m 21s; 85 Runtime-/Asset-/Konfigurationsdateien bytegenau, alle 21 direkten installierten Paketversionen und Lockfile unverändert. Signaturzertifikat SHA-256 fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c und Manifest-Berechtigungen unverändert; Variantenprüfung bestanden.

APK 56218136 Bytes, SHA-256 fb6dc149d620a87773411a0dce6a5fc194cd461a8981e78d1d12e56e6ac5b257. Im isolierten Emulator Update über 0.8.1 ohne Deinstallation und drei anonyme Kaltstarts ohne Absturz. Emulator anschließend beendet. Kein angemeldeter physischer Schicht-/GPS-Nachweis. Exakter Archivbuild bestanden: 8,0 Sekunden Kompilierung, 6,1 Sekunden TypeScript. 


## Veröffentlichung und Nachweise

Veröffentlichung 0.8.2 bestätigt: Runtime 143099cc86b09189eeddad0a1399b57f2de785d6, GitHub 86e47f01fd3af1e9c886c9df5b07329aa688a8da. Drei öffentliche Paketdateien bytegenau. Archiv 525 Dateien/7940947 Bytes/SHA-256 6a73ff4b9a69fb3e74712e436480ff7e6139c38b88c2312d7f7ff765293a54e1. Exakter Archivbuild 8,0s Kompilierung/6,1s TS bestanden. Vercel 2ozB8PzttAHZDwE5NoYxKjF1p9sD Ready/Latest/Current Production luxoreride.de mit exaktem Commit bestätigt, GitHub success. Fünf reine health/account/Kunden-/Fahrer-/Dispositions-GETs 200, Datenbank/Konten/Buchung bereit. APK 0.8.2 / 36 geschützter Entwurf untagged-3cd7637f79a4bc8677eb mit genau einem tatsächlichen Anhang, 56218136 Bytes und identischem angezeigtem SHA-256 fb6dc149d620a87773411a0dce6a5fc194cd461a8981e78d1d12e56e6ac5b257. Update über 0.8.1 ohne Deinstallation und drei anonyme Emulator-Kaltstarts bestanden; Emulator beendet. Unveränderte Signatur, Berechtigungen, 21 direkte Paketversionen/Lockfile und 85 Runtime-/Asset-/Konfigurationsdateien bytegenau. Kunde 0.6.9 / 23 unverändert. Keine physische angemeldete Prüfung oder Production-Schicht/Alarme/Positionen/Fahrt/Rechteänderung. Details docs/NATIVE-LOCATION-TRANSITIONS-082.md. Nächster Schritt tatsächliche GPS-Upload-Freigabe während ausstehender Pause/Neustart prüfen; abgeschlossene Startversionsguards nicht erneut implementieren.

Geschützter Entwurf: https://github.com/0711hany-source/luxore-ride-website/releases/tag/untagged-3cd7637f79a4bc8677eb. Kein Publish release oder öffentliche Binary-/Store-Freigabe. Private lokale Prüfungen unter work/native-location-transitions-082, sichtbare Nachweise outputs/native-location-transitions-082/vercel-ready.png und apk-draft.png. Diese nachträgliche Evidenz verändert den geprüften Runtime-/Archivstand nicht.
