# Native GPS-Startübergänge · Fahrer 0.8.2 / Build 36

## Reproduzierter Ablauf

startLocation prüfte seine ursprüngliche LocationLifecycle-Version nur beim Eintritt in den serialisierten Speicher-/Dienstabschnitt. Während await offerAlerts.clear, Cachelöschung oder Credentialspeicherung konnte inzwischen eine Pause oder ein neuer Start die Version ändern. Der alte Start speicherte trotzdem weiter und startete den nativen Dienst. Selbst wenn eine Pause während eines bereits begonnenen nativen Starts eintraf, konnte dessen alter Abschluss noch einen Erstortungsabruf anfordern und seinen Start als erfolgreich beendet behandeln.

Ein lokaler requireCurrent-Guard prüft jetzt dieselbe ursprüngliche Version am Eintritt sowie nach jeder dieser Wartezeiten und nach dem nativen Dienststart. Ein inzwischen überholter Start endet mit der vorhandenen Meldung „Die Standortfreigabe wurde inzwischen beendet.“; er setzt keine weitere alte Mutation oder Erstortung in Gang. Bereits begonnene Speicher-/native Operationen werden nicht abgebrochen oder rückwirkend ungeschehen gemacht. Der bestehende serialisierte nachfolgende Stopp/Neustart bereinigt beziehungsweise ersetzt den Stand. Die bedingte Fehlerbereinigung des alten Starts bleibt an Session und ursprüngliche Version gebunden, damit sie neuere Freigaben nicht löscht. Keine Änderung am Server-Schichtauftrag, keine automatische Wiederholung bestätigender Writes.

## Verhaltenstests

Sieben neue Tests führen den tatsächlichen location-service mit isolierten Expo-Location-/TaskManager-/SecureStore-/Alarmadaptern und abgefangenem fetch aus. Fünf Regressionen scheitern im alten Dienst, alle sieben bestehen mit der Korrektur:

- Pause während ausstehender Alarmbereinigung verhindert alte Credentialspeicherung und GPS-Start.
- Erneuerung derselben sessionId während Alarmbereinigung startet ausschließlich den neuen Token.
- Pause während Cachelöschung verhindert anschließende alte Speicherung/Start.
- Neuer Start während bereits begonnener Credentialspeicherung verhindert alten GPS-Start und erhält die neue Session/Capability. Die bereits begonnene Speicherung darf auslaufen.
- Pause während bereits begonnenem nativem GPS-Start lässt dessen API auslaufen, verwirft den alten Abschluss/Erstortungsabruf und stoppt den tatsächlichen Dienst geordnet mit Server-Stopp unter ursprünglichem Token.
- Wiederaufnahme während ausstehender Hintergrundberechtigung startet nach Pause weiterhin keinen Dienst (bestehender Kontrollfall).
- Ununterbrochener gültiger Start speichert exakte Capability, startet einmal und fordert genau eine Erstortung an (bestehender Kontrollfall).

Alle Punkte sind lokale synthetische Aufrufe. Keine Production-Schicht, Position, Alarme, Fahrt oder Rechteänderung. Berechtigungen, Rohkoordinaten, Qualitäts-/Netzcachefilter, Alarm-Deadlines/-Freigabe, Intervalle und serverseitige Authentifizierung unverändert. Keine neue API, Migration oder Provider.

## Grenzen

Hängende native Promises sind damit nicht zeitlich begrenzt. Bereits laufende native Operationen können erst nach ihrem Abschluss durch den folgenden serialisierten Übergang bereinigt werden; keine sofortige rückwirkende OS-Stoppgarantie. Physische angemeldete Unternehmensgeräte-/Schicht-/Hersteller-/Straßen-/Hintergrund-GPS-Prüfungen bleiben offen. Native Startversionsprüfung ist keine Navigationsglättung.

Kunde bleibt 0.6.9 / Build 23, Fahrer benötigt 0.8.2 / Build 36. APK ausschließlich geschützter interner GitHub-Entwurf, keine öffentliche Binary-/Store-Freigabe. Website-Veröffentlichung installiert keine APK auf Nutzerhandys. 571 Tests, beide TypeScript-Prüfungen, gezieltes Lint/Format und diff-Prüfung bestanden. Build außerhalb synchronisierter Quellen mit vollständigem Importbaum in 4m 21s; 85 Runtime-/Asset-/Konfigurationsdateien bytegenau, alle 21 direkten installierten Paketversionen und Lockfile unverändert. Signaturzertifikat SHA-256 fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c und Manifest-Berechtigungen unverändert; Variantenprüfung bestanden.

APK 56218136 Bytes, SHA-256 fb6dc149d620a87773411a0dce6a5fc194cd461a8981e78d1d12e56e6ac5b257. Im isolierten Emulator Update über 0.8.1 ohne Deinstallation und drei anonyme Kaltstarts ohne Absturz. Emulator anschließend beendet. Kein angemeldeter physischer Schicht-/GPS-Nachweis. Exakter Archivbuild und Veröffentlichung werden nach Abschluss ergänzt.
