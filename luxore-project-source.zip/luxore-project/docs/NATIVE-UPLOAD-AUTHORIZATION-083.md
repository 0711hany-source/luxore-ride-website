# Native GPS-Upload-Freigabe · Fahrer 0.8.3 / Build 37

## Nachgewiesener Fehler

Ein neuer Start erhöht sofort die Lifecycle-Version, wartet aber vor seiner serialisierten Speicherung auf Berechtigungen. Neue Vordergrund-/Hintergrund-Callbacks konnten diese neue Versionsnummer zusammen mit den weiterhin gespeicherten alten Credentials erfassen und damit noch alte Punkte speichern/hochladen. Außerdem prüfte der Dienst vor HTTP seine Version vor einer asynchronen Credentialsuche. Deren verspätete alte Antwort konnte nach inzwischen abgeschlossener Pause oder Erneuerung derselben sessionId noch einen HTTP-Aufruf mit altem Token freigeben. Eine Pause während Cachelesen verhinderte zwar HTTP, ließ aber noch den alten Cache-Schreibbeginn zu.

## Korrektur

LocationLifecycle trennt aktuelle Versionsnummer von erlaubter Übertragung: begin sperrt sie synchron für den gesamten laufzeitlokalen Übergang. Erst activate derselben aktuellen Version nach erfolgreich abgeschlossenem nativem Start öffnet Übertragung wieder. Ein alter Abschluss kann keine neuere Version aktivieren. Eine frische native Laufzeit beginnt weiterhin wiederherstellbar, damit eine gültige gespeicherte Capability nach normalem JS-Neustart ohne neue Online-Aktion weiterarbeiten kann; Credentials/Ablauf und Serverauthentifizierung bleiben erforderlich.

Der tatsächliche Ortungsdienst prüft vor Verarbeitung und nach jedem relevanten Credentialslesen Version/Übertragungsfreigabe, exakte sessionId/nativeToken und Ablaufzeit. Dieselbe Prüfung steht am Cacheeintritt, nach Cachelesen vor neuem Cache-Schreibbeginn, vor HTTP sowie im nativen Alarm-Prüfcallback. Entscheidende Versions-/Absichtsprüfung erfolgt nach der asynchronen Antwort. Status und Wiederaufnahme dürfen einen im laufenden Übergang noch gespeicherten alten Dienst nicht als freigegeben melden oder neu starten. Nur frische Punkte nach erfolgreicher aktueller Freigabe werden verarbeitet; keine Warteschlange alter Punkte.

Bereits begonnene Speicher-/HTTP-/native Aufrufe werden nicht abgebrochen oder rückwirkend ungeschehen gemacht. Der folgende serialisierte Übergang bereinigt Speicher/Dienst; späte HTTP-Antworten erhalten keine alte Alarmfreigabe. Bestätigende Server-Schicht-/Fahrtwrites bleiben unabhängig, keine automatische Wiederholung. GPS-Rohkoordinaten, Qualitätsfilter, Intervalle, gültiger Netzverlustcache, Berechtigungen und Rollen unverändert. Keine neue API, Migration oder Provider.

## Tatsächliche Regressionen

Acht zusätzliche Tests führen den tatsächlichen location-service mit isolierten Expo-Location-/TaskManager-/SecureStore-/Alarmadaptern und abgefangenem fetch aus. Sechs scheitern vorher, alle bestehen korrigiert:

- Frische Laufzeit stellt gültige gespeicherte Freigabe wieder her und sendet frischen Hintergrundpunkt ohne neuen Online-Auftrag (Kontrollfall).
- Je Vordergrund und Hintergrund: alte Credentials bleiben während ausstehender neuer Startberechtigung ohne Cache/HTTP; nach Abschluss sendet nur ein frischer Punkt mit neuem Token.
- Verspätete Credentialsuche vor Upload darf nach abgeschlossener Pause keinen HTTP-Aufruf mehr auslösen.
- Erneuerung derselben sessionId sperrt späten alten Token; frischer neuer Upload funktioniert danach.
- Pause während Cachelesen verhindert auch den alten Cache-Schreibbeginn.
- Status/Wiederaufnahme starten während neuer Startberechtigung nicht den alten gespeicherten Dienst; aktueller Start funktioniert anschließend.
- Schon vor Pause gesendete HTTP-Anfrage darf auslaufen, erhält aber keine alte Alarmfreigabe (Kontrollfall).

Bestehende native Qualitätsfixtures richteten nach vorheriger expliziter Pause nur erneut gespeicherte Credentials im selben Runtime ein. Sie verwenden nun einen tatsächlich erfolgreichen neuen startLocation-Aufruf; Qualitäts-, Reihenfolge-, Duplikat-, Netzverlust- und Cache-Assertions bleiben erhalten. Kaltwiederherstellung wird weiterhin separat ohne neuen Start getestet.

## Grenzen

Die Übergangsabsicht ist laufzeitlokal, kein neuer dauerhaft gespeicherter Pauseauftrag. Prozessabbruch vor abgeschlossener geschützter Bereinigung wird dadurch nicht als dauerhaft quittierte Pause behandelt; eine neue Laufzeit liest weiter den tatsächlichen geschützten Stand und jeder Upload unterliegt dem tatsächlichen Server. Bereits begonnene HTTP-Aufrufe können serverseitig ankommen. Hängende native Promises werden nicht zeitlich begrenzt. Physische angemeldete Unternehmensgeräte-/Mehrprozess-/Schicht-/Hersteller-/Straßen-/Hintergrund-GPS-Prüfungen bleiben offen. Alle Tests lokal/synthetisch, keine Production-Position, Schicht, Alarme, Fahrt oder Rechteänderung.

Kunde bleibt 0.6.9 / Build 23, Fahrer benötigt 0.8.3 / Build 37. Interner geschützter APK-Entwurf, keine öffentliche Binary-/Store-Freigabe. Website-Update installiert keine APK auf Nutzerhandys. 579 Tests, beide TypeScript-Prüfungen, gezieltes Lint/Format und diff-Prüfung bestanden; die 16 betroffenen Dienst-/Qualitätsprüfungen nach Fixturebereinigung zusätzlich erfolgreich. Build außerhalb synchronisierter Quellen in 4m 45s, 85 Runtime-/Asset-/Konfigurationsdateien im vollständigen Importbaum bytegenau. Alle 21 direkten installierten Paketversionen und Lockfile unverändert. Bestehendes Zertifikat SHA-256 fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c, Manifest-Berechtigungen und Variantenprüfung bestätigt.

APK 56219000 Bytes, SHA-256 7583b99038a4bd5fae255cfe7caac9c3c17829fda634bbe9363e494e913d1446. Update über 0.8.2 ohne Deinstallation im isolierten Emulator, drei anonyme Kaltstarts ohne Absturz. Emulator anschließend beendet. Keine angemeldete physische Prüfung. Exakter Archivbuild und Veröffentlichung werden nach Abschluss ergänzt.
