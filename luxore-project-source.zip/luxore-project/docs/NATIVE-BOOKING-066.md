# Native Kundenbuchung · 0.6.6 / Build 20

## Umgesetzt

Der native Start öffnet jetzt `CustomerBookingScreen` statt der eingebetteten Buchungsseite. Die native Adressauswahl bestätigt Abholort und Ziel serverseitig; temporäre Vorschläge werden nicht als bestätigte Adresse gespeichert. Der GPS-Knopf fordert nur Vordergrundfreigabe an und bestätigt den tatsächlichen Punkt über die eigene HTTPS-API. Verweigerte Freigabe blockiert die manuelle Adressauswahl nicht; verzögerte GPS-Antworten nach Hintergrund/Verlassen werden verworfen und nach 20 Sekunden bleibt ein bedienbarer Wiederholungsweg.

Jetztfahrt oder Reservierung mit lokaler Datum-/Zeitprüfung, serverseitiger Straßenroute und allen drei bestätigten Kilometerpreisen. Klassenbilder, Temperatur/Gespräch/Musik, transparente Produktbilder im Bordkartenraster und bestehende Gratis-Kontingente. Name/Telefon werden geprüft. Reservierungen zeigen die tatsächliche Serverbestätigung und behaupten keine Fahrerzusage. Die Buchung wird ausschließlich nach vollständig ausgeführter Wischgeste gesendet, ohne zusätzliche Tippannahme.

## Wiederholung und Lebenszyklus

Vor dem HTTP-Schreiben wird der unveränderte Buchungskörper einschließlich Quote-ID und Klasse kontogebunden in SecureStore gesichert. Verlorene Antworten, Serverfehler und Neustart lassen dieselbe Anfrage wiederholen; die bestehende Server-Wiederholungslogik bestätigt eine bereits gespeicherte Buchung. Speicherfehler vor Versand senden nichts. Eindeutige clientseitige Ablehnung entsperrt einen neuen Entwurf; unklare Transport-/Serverfehler tun das nicht. Schreibvorgänge erhalten kein Lifecycle-Abbruchsignal. Alte Leseanfragen werden dagegen abgebrochen und können keine neueren Angebote überschreiben. Abgelaufene Angebote und unvollständige Serverantworten werden sichtbar behandelt.

Die Buchungsansicht behält beim Wechsel in Menü/Start ihren Entwurf. Kontowechsel trennt Controller und Gerätespeicher. `NativeAddressPicker` bleibt nach React-StrictMode-Effektwiederholung bedienbar; die Cleanup-Funktion deaktiviert den Controller, statt ihn dauerhaft zu zerstören.

## Prüfungen

336 Tests bestanden: acht neue Controller-Tests und vier tatsächliche React-Native-Komponententests. Der App-Test öffnet den nativen Ablauf über den Start, wählt beide bestätigten Adressen, berechnet den Preis, setzt First Class/Fahrtwunsch/Bordartikel und führt die vollständige Wischgeste bis zur Serverbestätigung aus. Die alte eingebettete Komponente darf dabei nicht montiert werden. Reservierungszeit, verlorene Antwort mit Neustart, persistierter identischer Anfragekörper, StrictMode und verweigerter GPS-Zugang sind geprüft. Serverantworten und GPS werden im Test isoliert; keine Production-Fahrt oder tatsächliche Fahrerortung erzeugt.

Web-/Mobile-TypeScript und gezieltes Lint für die neuen Module/Tests bestanden. Keine Behauptung eines vollständig grünen Gesamt-App-Lints. Echte Komponenten mit synthetischen Antworten auf 390 × 844 geprüft; kein horizontaler Überlauf, alle zehn bestehenden Produktbilder geladen. Nachweise: `outputs/native-booking/quote-preview.png` und `board-preview.png`.

## Grenzen und nächster Schritt

Die Kunden-Live-Karte und freie Kartenpunktwahl bleiben in der bestehenden eingebetteten Ansicht erreichbar. Erweiterte Disposition/Betreiberverwaltung bleibt im eigenen Webportal. GPS auf physischen Geräten, angemeldete Mehrgerätebuchung und vollständige Fahrer-Schicht einschließlich Hintergrund bleiben offen. Fahrer-APK bleibt 0.6.4 / Build 18. Kunden-Änderungen benötigen eine neue APK-Installation; Website-Updates ersetzen keine Installation. Keine neuen Konten, Store-Einreichungen, Rechte, Gebühren oder Permanent-Geokodierungsbudgets.

Nächster Schritt: native Kunden-Live-Karte/freie Kartenpunktwahl und reale angemeldete Unternehmensgeräteprüfungen.
