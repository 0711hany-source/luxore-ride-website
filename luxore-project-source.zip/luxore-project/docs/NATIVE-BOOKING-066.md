# Native Kundenbuchung · 0.6.6 / Build 20

## Umgesetzt

Der native Start öffnet jetzt `CustomerBookingScreen` statt der eingebetteten Buchungsseite. Die native Adressauswahl bestätigt Abholort und Ziel serverseitig; temporäre Vorschläge werden nicht als bestätigte Adresse gespeichert. Der GPS-Knopf fordert nur Vordergrundfreigabe an und bestätigt den tatsächlichen Punkt über die eigene HTTPS-API. Verweigerte Freigabe blockiert die manuelle Adressauswahl nicht; verzögerte GPS-Antworten nach Hintergrund/Verlassen werden verworfen und nach 20 Sekunden bleibt ein bedienbarer Wiederholungsweg.

Jetztfahrt oder Reservierung mit lokaler Datum-/Zeitprüfung, serverseitiger Straßenroute und allen drei bestätigten Kilometerpreisen. Klassenbilder, Temperatur/Gespräch/Musik, transparente Produktbilder im Bordkartenraster und bestehende Gratis-Kontingente. Name/Telefon werden geprüft. Reservierungen zeigen die tatsächliche Serverbestätigung und behaupten keine Fahrerzusage. Die Buchung wird ausschließlich nach vollständig ausgeführter Wischgeste gesendet, ohne zusätzliche Tippannahme.

## Wiederholung und Lebenszyklus

Vor dem HTTP-Schreiben wird der unveränderte Buchungskörper einschließlich Quote-ID und Klasse kontogebunden in SecureStore gesichert. Verlorene Antworten, Serverfehler und Neustart lassen dieselbe Anfrage wiederholen; die bestehende Server-Wiederholungslogik bestätigt eine bereits gespeicherte Buchung. Speicherfehler vor Versand senden nichts. Eindeutige clientseitige Ablehnung entsperrt einen neuen Entwurf; unklare Transport-/Serverfehler tun das nicht. Schreibvorgänge erhalten kein Lifecycle-Abbruchsignal. Alte Leseanfragen werden dagegen abgebrochen und können keine neueren Angebote überschreiben. Abgelaufene Angebote und unvollständige Serverantworten werden sichtbar behandelt.

Die Buchungsansicht behält beim Wechsel in Menü/Start ihren Entwurf. Kontowechsel trennt Controller und Gerätespeicher. `NativeAddressPicker` bleibt nach React-StrictMode-Effektwiederholung bedienbar; die Cleanup-Funktion deaktiviert den Controller, statt ihn dauerhaft zu zerstören.

## Prüfungen

336 Tests bestanden: acht neue Controller-Tests und vier tatsächliche React-Native-Komponententests. Der App-Test öffnet den nativen Ablauf über den Start, wählt beide bestätigten Adressen, berechnet den Preis, setzt First Class/Fahrtwunsch/Bordartikel und führt die vollständige Wischgeste bis zur Serverbestätigung aus. Die alte eingebettete Komponente darf dabei nicht montiert werden. Reservierungszeit, verlorene Antwort mit Neustart, persistierter identischer Anfragekörper, StrictMode und verweigerter GPS-Zugang sind geprüft. Serverantworten und GPS werden im Test isoliert; keine Production-Fahrt oder tatsächliche Fahrerortung erzeugt.

Web-/Mobile-TypeScript und gezieltes Lint für die neuen Module/Tests bestanden. Keine Behauptung eines vollständig grünen Gesamt-App-Lints. Echte Komponenten mit synthetischen Antworten auf 390 × 844 geprüft; kein horizontaler Überlauf, alle zehn bestehenden Produktbilder geladen. Nachweise: `outputs/native-booking/quote-preview.png` und `board-preview.png`.

## Grenzen und nächster Schritt

Die Kunden-Live-Karte und freie Kartenpunktwahl bleiben in der bestehenden eingebetteten Ansicht erreichbar. Erweiterte Disposition/Betreiberverwaltung bleibt im eigenen Webportal. GPS auf physischen Geräten, angemeldete Mehrgerätebuchung und vollständige Fahrer-Schicht einschließlich Hintergrund bleiben offen. Fahrer-APK bleibt 0.6.4 / Build 18. Kunden-Änderungen benötigen eine neue APK-Installation; Website-Updates ersetzen keine Installation. Keine neuen Konten, Store-Einreichungen, Rechte, Gebühren oder Permanent-Geokodierungsbudgets.

Nächster Schritt: native Kunden-Live-Karte/freie Kartenpunktwahl und reale angemeldete Unternehmensgeräteprüfungen.


## APK-Nachweis

Kunden-APK 0.6.6 / Build 20 gebaut: Paketkennung `de.luxoreride.customer.preview`, Runtime-Variante customer, Design-Vorschau aus, ARM64-Bibliotheken und Standalone-Bundle, nicht debuggbar, Backup aus, keine Fahrer-Hintergrundortung oder Mikrofon-/Overlay-Berechtigung. Test-Signatur unverändert SHA-256 `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c`.

Als Update von 0.6.5 ohne Deinstallation im isolierten Android-Emulator installiert. Drei kalte Starts mit jeweils lebendem Prozess und ohne Fatal-/ReactNativeJS-Absturz. Nativer Startbildschirm bestätigt, Nachweis `outputs/native-booking/customer-emulator-start.png`. Kein angemeldeter oder physischer Gerätebeweis; der Emulator wurde danach beendet. Der erfolgreiche Build nutzt einen separaten temporären Quellbaum mit unveränderten vorhandenen Abhängigkeitsversionen. Metro benötigte echte Abhängigkeitsdateien im isolierten Baum statt eines Symlinks außerhalb seiner Watch-Folders; kein Runtime-Paket oder Signierschlüssel geändert.

| Datei in mobile/artifacts | Bytes | SHA-256 |
| --- | ---: | --- |
| Luxore-Ride-Test-0.6.6.apk | 56092720 | aa1215ff8495afed6656ef366afb2b7a3779f3737eccac822cb67f642e95ee1c |

## GitHub-/Vercel-Nachweis

Quellbasis `6944fae`, GitHub `603ab0a0618b944bc1431ae73c9223c578e7db01`. Öffentliches Archiv, SOURCE-VERSION und README bytegenau geprüft. Archiv: 443 Dateien, 7684916 Bytes, SHA-256 `2ae585b9209ed165e340a502231066227c67733bd9e617f07c1e3b63188775ef`. Keine APKs, Schlüssel, Umgebungsgeheimnisse oder untracked ROADMAP-Kopie im Archiv. Der Produktionsbuild genau dieses Archivs besteht.

Vercel `6XYyRZqf2x74Ly8HajGX8QRXebLU` ist Ready / Latest / Current Production unter luxoreride.de. Screenshot `outputs/native-booking/vercel-production-ready.png`. Live-Health: Datenbank verbunden, Konten und Buchungen bereit. Anonyme Konto-API ohne Konto/Betreiberrechte; Kunden-, Fahrer- und Dispositionsseite HTTP 200. Keine Production-Testfahrt, GPS-Ortung, Konten-/Flotten-/Rechteänderung. Dieser Nachweis ergänzt die bereits veröffentlichten Quellen, ohne deren Runtime/Archivbytes zu verändern.


## Geschützter interner Download

Gespeicherter unveröffentlichter Entwurf: https://github.com/0711hany-source/luxore-ride-website/releases/tag/untagged-ae07728f9ddee79f929b. GitHub zeigt genau eine Kunden-APK und denselben tatsächlichen Asset-SHA-256 wie die geprüfte lokale Datei. Screenshot `outputs/native-booking/private-apk-download.png`. Das bestehende berechtigte GitHub-Konto ist erforderlich. Keine öffentliche Store-/APK-Freigabe, keine neuen Personenrechte und keine Löschung älterer Downloads. Kein E-Mail-Versand in diesem Durchlauf.

Automation weiterhin ACTIVE alle fünf Stunden, mit Kunden-Version 0.6.6 / Build 20, unverändertem Fahrer-Download 0.6.4 / Build 18, 336 Tests, nativer Buchung und realen Prüfgrenzen aktualisiert.
