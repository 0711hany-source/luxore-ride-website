# Native Kunden-Fahrtenansicht · 0.6.5 / Build 19

Beim Wechsel in den Hintergrund wurde bisher nur die Antwort einer laufenden Abfrage ungültig. Ihr belegter Abfrageplatz blieb bis zum Abschluss bestehen. Nach der Rückkehr konnte die Ansicht deshalb bis zum alten Timeout warten, obwohl eine neue Verbindung verfügbar war.

Der Controller beendet und löst jetzt ausschließlich laufende Leseanfragen beim Hintergrundwechsel, Verlassen oder Beginn einer Stornierung. Beim Zurückkehren startet unmittelbar eine frische Anfrage. Eine verspätet abgeschlossene, verlassene Abfrage darf weder den Platz einer neueren Abfrage freigeben noch weitere überlappende Abfragen auslösen. Bekannte Fahrten bleiben sichtbar, solange der neue Stand lädt.

Der gemeinsame native API-Client unterstützt dazu ein optionales AbortSignal. Vorab abgebrochene Anfragen senden nichts; nach Transport und JSON-Decodierung wird die Abbruchentscheidung erneut geprüft. Abbruch wird von Timeout und Netzfehler unterschieden, und der Listener wird nach Abschluss entfernt. Kontositzung, eigene HTTPS-Origin, Bearer-Authentifizierung und Rechte bleiben erhalten. Ein tatsächlicher API-Rechtefehler bleibt ein NativeApiError.

Stornierungen sind Schreibvorgänge und erhalten kein Lifecycle-Abbruchsignal. Ein Wechsel in den Hintergrund bedeutet nicht, dass eine bereits gesendete Änderung auf dem Server rückgängig wird. Erst die tatsächliche Serverantwort bestätigt die Stornierung; Wischbestätigung und vorhandene Fehler-/Wiederholungslogik bleiben erhalten.

## Prüfungen

312 Tests bestanden. Zwei neue Controller-Regressionstests scheitern nachweislich im vorherigen Stand: sofortige neue Abfrage trotz ungelöster alter Anfrage, und Schutz des neu belegten Abfrageplatzes vor deren verspätetem finally. Ein weiterer Test prüft tatsächlich abgebrochene Leseanfragen bei unverändert weiterlaufender Stornierung. Vier API-Client-Tests prüfen Vorab-Abbruch, Transportabbruch ohne falschen Offlinefehler, Abbruch während JSON-Decodierung und Listener-Aufräumen einschließlich echter API-Fehler. Die vorhandenen tatsächlichen React-Native-Komponententests bestehen ebenfalls.

Web- und Mobile-TypeScript sowie gezieltes Lint für die geänderten Module und Tests bestanden. Die bekannten übrigen App.tsx-Lintmeldungen sind kein vollständig grünes Gesamt-App-Lint. Kein Production-Konto, Fahrzeug, GPS-Punkt oder Buchungsdatensatz wurde für diese Tests geändert.

## APK und Grenzen

Nur die Kunden-App wird in diesem Schritt als interne Version 0.6.5 / Build 19 gebaut. Fahrer-App und bisherige APK-Dateien bleiben 0.6.4 / Build 18. Die native Änderung benötigt ein Kunden-APK-Update; eine Website-Veröffentlichung ersetzt keine auf Handys installierte APK.

Die vollständige native Kunden-Adressauswahl, Buchung und Live-Karte bleiben offen. Diese Korrektur behauptet keine neue native Buchungsoberfläche. Angemeldete Mehrgeräte-/Fahrtprüfungen und physische Hintergrund-GPS-Prüfungen bleiben ebenfalls erforderlich. Geoapify-Free und neuer Mapbox-Token sind aktiv, permanentes Mapbox-Budget bleibt null; der Reservierungsroutenfix bleibt erhalten. Keine neuen Gebühren, Anbieter, Rechte oder Store-Einreichungen.

APK-Signatur-, Varianten- und Emulatorprüfung sowie Veröffentlichungsnachweise werden nach tatsächlichem Abschluss unten ergänzt.
