# Native Kunden-Fahrtenansicht · 0.6.5 / Build 19

Beim Wechsel in den Hintergrund wurde bisher nur die Antwort einer laufenden Abfrage ungültig. Ihr belegter Abfrageplatz blieb bis zum Abschluss bestehen. Nach der Rückkehr konnte die Ansicht deshalb bis zum alten Timeout warten, obwohl eine neue Verbindung verfügbar war.

Der Controller beendet und löst jetzt ausschließlich laufende Leseanfragen beim Hintergrundwechsel, Verlassen oder Beginn einer Stornierung. Beim Zurückkehren startet unmittelbar eine frische Anfrage. Eine verspätet abgeschlossene, verlassene Abfrage darf weder den Platz einer neueren Abfrage freigeben noch weitere überlappende Abfragen auslösen. Bekannte Fahrten bleiben sichtbar, solange der neue Stand lädt.

Der gemeinsame native API-Client unterstützt dazu ein optionales AbortSignal. Vorab abgebrochene Anfragen senden nichts; nach Transport und JSON-Decodierung wird die Abbruchentscheidung erneut geprüft. Abbruch wird von Timeout und Netzfehler unterschieden, und der Listener wird nach Abschluss entfernt. Kontositzung, eigene HTTPS-Origin, Bearer-Authentifizierung und Rechte bleiben erhalten. Ein tatsächlicher API-Rechtefehler bleibt ein NativeApiError.

Stornierungen sind Schreibvorgänge und erhalten kein Lifecycle-Abbruchsignal. Ein Wechsel in den Hintergrund bedeutet nicht, dass eine bereits gesendete Änderung auf dem Server rückgängig wird. Erst die tatsächliche Serverantwort bestätigt die Stornierung; Wischbestätigung und vorhandene Fehler-/Wiederholungslogik bleiben erhalten.

## Prüfungen

312 Tests bestanden. Zwei neue Controller-Regressionstests scheitern nachweislich im vorherigen Stand: sofortige neue Abfrage trotz ungelöster alter Anfrage, und Schutz des neu belegten Abfrageplatzes vor deren verspätetem finally. Ein weiterer Test prüft tatsächlich abgebrochene Leseanfragen bei unverändert weiterlaufender Stornierung. Vier API-Client-Tests prüfen Vorab-Abbruch, Transportabbruch ohne falschen Offlinefehler, Abbruch während JSON-Decodierung und Listener-Aufräumen einschließlich echter API-Fehler. Die vorhandenen tatsächlichen React-Native-Komponententests bestehen ebenfalls.

Web- und Mobile-TypeScript sowie gezieltes Lint für die geänderten Module und Tests bestanden. Die bekannten übrigen App.tsx-Lintmeldungen sind kein vollständig grünes Gesamt-App-Lint. Kein Production-Konto, Fahrzeug, GPS-Punkt oder Buchungsdatensatz wurde für diese Tests geändert.

## APK und Grenzen

Nur die Kunden-App wird in diesem Schritt als interne Version 0.6.5 / Build 19 gebaut. Fahrer-App und bisherige APK-Dateien bleiben 0.6.4 / Build 18. Die native Änderung benötigt ein Kunden-APK-Update; eine Website-Veröffentlichung ersetzt keine auf Handys installierte APK.

Die vollständige native Kunden-Adressauswahl, Buchung und Live-Karte bleiben offen. Diese Korrektur behauptet keine neue native Buchungsoberfläche. Angemeldete Mehrgeräte-/Fahrtprüfungen und physische Hintergrund-GPS-Prüfungen bleiben ebenfalls erforderlich. Geoapify-Free und neuer Mapbox-Token sind aktiv, permanentes Mapbox-Budget bleibt null; der Reservierungsroutenfix bleibt erhalten. Keine neuen Gebühren, Anbieter, Rechte oder Store-Einreichungen.

Die Kunden-APK ist gebaut und auf Paketkennung de.luxoreride.customer.preview, Version 0.6.5 / Build 19, Runtime-Variante, ARM64-Bundle, nicht debuggbaren Stand, Backup-Sperre, eingeschränkte Berechtigungen und APK-Signatur geprüft. Sie fordert keine Fahrer-Hintergrundortung an. Die Test-Signatur entspricht der bisherigen APK: SHA-256 fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c. Kein neuer Signierschlüssel oder Store-Build.

| Datei in mobile/artifacts | Bytes | SHA-256 |
| --- | ---: | --- |
| Luxore-Ride-Test-0.6.5.apk | 55544848 | d1716548a888a8bdfa513d19466caad9c5528f43891a84c6c758aece92bc5fa1 |

Als Update von 0.6.4 ohne Deinstallation im isolierten Emulator installiert. Drei kalte Kunden-Starts mit jeweils lebendem Prozess, nativem Startbildschirm und ohne Fatal-/ReactNativeJS-Absturz geprüft. Screenshot: outputs/native-read-recovery/customer-emulator-start.png. Das ist kein angemeldeter Fahrten-/Buchungstest und kein Nachweis auf einem physischen Handy.

Synchronisierte Konfliktkopien blockierten den ursprünglichen Android-Build. 1.316 ausschließlich automatisch erzeugte Dateien unter mobile/node_modules/*/android/build wurden unverändert nach work/native-read-recovery/generated-conflict-backup verschoben; die Synchronisation erzeugte danach neue Kopien. Der tatsächliche erfolgreiche Build verwendet daher einen separaten temporären Quellordner und frisch aus dem vorhandenen eingefrorenen Mobile-Lockfile installierte Abhängigkeiten außerhalb des synchronisierten Arbeitsverzeichnisses. Alle 21 direkten Paketversionen stimmen mit dem vorher geprüften Stand überein. Keine ursprünglichen Paketquellen, Schlüssel oder Geschäftsdaten gelöscht. Der endgültige Gradle-Build besteht mit einem Worker; alle 312 Tests bestehen auch nach der Abhängigkeitsprüfung. Für künftige Android-Builds diesen unabhängigen Buildordner nutzen und Sicherungssymlinks außerhalb des von Gradle untersuchten Quellbaums halten.

## GitHub-/Vercel-Veröffentlichung

Quellbasis 8a2e4f1, öffentlicher GitHub-Commit 99f4d537a77cbb07d143cb672a655e6fe54b5c95. Archiv mit 432 Dateien, 7.648.948 Bytes, SHA-256 15963782e23cb0c0e8754de9fccdaa0ef4d23c6a43521e98696a0616e31fafb2. Archiv, SOURCE-VERSION und README bytegenau mit dem öffentlichen Stand abgeglichen. Keine APKs, Signierschlüssel, Umgebungsgeheimnisse oder untracked ROADMAP-Kopie im Quellarchiv. Der saubere Produktionsbuild des tatsächlichen Archivs besteht.

Vercel 9cxEu5UKETNwb9oy8SH4AaEUkusq zeigt Ready / Latest / Current Production unter luxoreride.de. Nachweis: outputs/native-read-recovery/vercel-production-ready.png. Live-Health bestätigt databaseConnected/accountsReady/bookingConfigured true; anonyme Konto-API ohne Konto oder Betreiberrecht, registrationReady true. Kunden-, Fahrer- und Dispositionsseite HTTP 200. Keine Production-Testfahrt oder Daten-/Rechteänderung. Der ergänzende Nachweiscommit ändert keinen Runtime-Code und keine bereits veröffentlichten Archivbytes.


## Geschützter interner Download und nächster Schritt

Gespeicherter unveröffentlichter Kunden-APK-Entwurf: https://github.com/0711hany-source/luxore-ride-website/releases/tag/untagged-1b15b5efd28acd591adb. GitHub zeigt genau eine APK und denselben tatsächlichen Asset-SHA-256 wie die geprüfte lokale Datei. Nachweis: outputs/native-read-recovery/private-apk-download.png. Bestehendes berechtigtes GitHub-Konto erforderlich; keine öffentliche APK-Veröffentlichung, neue Personenrechte oder Löschung älterer Downloads. Der Fahrer-Download 0.6.4 bleibt unverändert im bisherigen Entwurf. Kein E-Mail-Versand in diesem Durchlauf.

Kunden-Test-App als Update ohne Deinstallation auf dem Unternehmenshandy installieren und angemeldete Fahrtenansicht einschließlich Hintergrundwechsel, langsamer Verbindung und bestätigter Stornierung prüfen. Danach native Kunden-Adressauswahl und Route umstellen. Der isolierte Emulator wurde nach der Startprüfung beendet. Die Fünf-Stunden-Automation bleibt ACTIVE und berücksichtigt Kunden-Version 0.6.5, unveränderte Fahrer-Version 0.6.4, 312 Tests, echte Prüfgrenzen und den getrennten Android-Buildordner.
