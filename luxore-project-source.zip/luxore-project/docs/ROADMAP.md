# Nächste Schritte

1. Die vorbereitete Freischaltung und Betreiberzuordnung nach konkreter Bestätigung speichern; neuen GitHub-/Vercel-Stand und reale Datenbankverbindung prüfen. Neustart mit neuen Profilen ist bestätigt, der Altbestand bleibt unangetastet.
2. Erste Betreiberanmeldung per E-Mail-Code auf luxoreride.de durchführen. Profilname/Telefon ergänzen, Flotte, Mitarbeiter und Fahrzeuge einrichten; Fahrer einzeln prüfen und freigeben. Kein Kennzeichen allein erteilt Rechte.
3. Beide internen Android-Apps 0.5.0 einmal installieren und Konto, Fahrzeug-Speicherung, Buchung, Annahme, Fahrtabschluss und Kassieren auf getrennten realen Geräten prüfen.
4. Hintergrundortung, gesperrten Bildschirm, externe Navigation, Rückkehr und Neustart auf den Unternehmenshandys prüfen. Straßennahen Pfeil und Latenz anhand echter GPS-Aufnahmen verbessern.
5. Die eingebetteten Karten-, Fahrt- und Flottenansichten schrittweise in gemeinsame native Komponenten überführen. Premium-Gesten und feste Fenster auf beiden Apps erhalten.
6. Vor kommerziellem Start geeigneten Vercel-Tarif, Reservierungsscheduler, Betriebsüberwachung, Backups/Wiederherstellung, Rechtsangaben und Zahlungsintegration fertigstellen. Kein kostenpflichtiger Wechsel ohne konkrete Autorisierung.
7. Offizielle Android-Store-Builds; danach iOS. Keine Store-Verfügbarkeit vor erfolgreicher Freigabe behaupten. Eine spätere Altdatenzusammenführung muss neue Daten erhalten.
