## Vorbereitung des offiziellen Starts – 06.10.2026

Der Nutzer hat eigene Registrierung/Anmeldung, eine geschützte Betreiber-Gesamtübersicht, Store-Vorbereitung und Veröffentlichung der neuen Website beauftragt. Die Veröffentlichungssperre ist nach seiner Änderung der lokalen Berechtigungen aufgehoben; der offizielle Sites-Quellablauf lässt sich wieder öffnen.

Website, `/konto`, `/betreiber`, Hilfe-/Datenschutz-/Impressumsseiten sowie Android-/iOS-Konfiguration und Store-Texte umgesetzt. Betreiberadresse: operator@example.com. Die E-Mail-Anbindung ist vorbereitet, aber ohne Versanddienst bleibt Registrierung ausdrücklich inaktiv. Der vorhandene ChatGPT-Betreiberzugang dient dem Übergang; eigene Luxóre-Konten benötigen nachweislich bestätigte E-Mails. Details, Grenzen und Aktivierung: [OFFICIAL-LAUNCH.md](OFFICIAL-LAUNCH.md).

171 Logik-/API-/Oberflächentests und der bestehende lokale Mehrgeräte-Buchungstest bestanden. Neue Laufzeitänderungen erst nach erfolgreichem Build/Deployment als online melden. Nächste Schritte: E-Mail-Domain und Versandzugang im Unternehmensbesitz aktivieren; vollständige Betreiberangaben nachreichen (auf der genannten Website fehlen Inhabername/Rechtsform); echte Android-Betriebsprüfung, unabhängige Reservierungsaktivierung, Produktionssignierung und Store-Konten. Keine ungeprüfte Store-Einreichung oder kostenpflichtige Kontoeröffnung.

# LUXORÉ RIDE – Arbeitsstand und nächste Schritte

Vorgabe: zuerst Unternehmenswebsite, danach Android, anschließend iOS. Der Nutzer hat die Weiterarbeit inzwischen auf alle fünf Stunden mit kurzem deutschem Update geändert. Neuester Auftrag: beide Apps im selben Premium-Design stabilisieren und alle Fenster fest im sichtbaren Bildschirm halten; insbesondere Fahrzeug hinzufügen war außerhalb des bedienbaren Bereichs. Der ursprüngliche Speicherfehler am Fahrerhandy bleibt ein offener Gerätetest. Bestehende öffentliche Freigabe erhalten; keine kostenpflichtigen Konten oder Store-Einreichungen aus einer pauschalen Freigabe ableiten.

## Aktueller Stand – 06.10.2026

### Mapbox-Kosten, flüssiger Pfeil und Android-Wiederaufnahme – 06.10.2026

Neuester Auftrag hat Vorrang: unnötige Mapbox-Kosten, springende Navi-Darstellung und Standortverlust nach App-Wechsel korrigieren; danach veröffentlichen. Adressvorschläge sind jetzt temporär und werden nicht gespeichert. Gewählte Adressen erhalten permanente Speicherrechte; permanente Antworten werden 30 Tage wiederverwendet und gleichzeitige Abfragen gebündelt. Letzte Ziele lösen keine erneute Geokodierung aus. Grenzen für diese Site: 2.000 temporäre Suchabfragen/Tag und standardmäßig 200 neue permanente Abfragen/Tag, letztere über `MAPBOX_PERMANENT_DAILY_LIMIT` einstellbar. Dies begrenzt nicht sämtliche Mapbox-Kontokosten.

Eigener Navi-Pfeil überbrückt verlässliche Ein-Sekunden-Messungen kurz auf der bestätigten Straßenlinie, ohne Kurven zu schneiden; begrenztes Auslaufen und Korrektur bei Stillstand. Tatsächliche GPS-Positionen/Preise unverändert. Android 0.4.3 hält frische Hintergrundposition schichtgebunden vor, richtet die Vordergrund-Watch beim Wiederöffnen neu ein, verhindert alte Status-/Startantworten und stellt einen beendeten WebView-Renderer begrenzt wieder her. Beide internen Test-APKs gebaut und geprüft; einmaliges APK-Update erforderlich. Noch kein Gerätetest.

52 Tests, beide Typprüfungen, Produktionsbuild und lokaler Mehrgeräte-Buchungsablauf bestanden. Erneute Veröffentlichung trotz Netzwerk-/Git-Freigabe automatisch an der sicheren stdin-Übergabe abgelehnt. Site weiterhin Stand 39; Kostenbegrenzung und neue Web-Navigation noch nicht live. Vorübergehende Abschaltung kostenpflichtiger serverseitiger Mapbox-Abfragen wurde als Wahl angeboten; keine Antwort/keine Live-Abschaltung. Details und Grenzen: [COST-GPS-REVIEW.md](COST-GPS-REVIEW.md).

Die öffentliche Site ist unter https://luxore-ride-frankfurt.lucky-goose-6238.chatgpt.site erreichbar. Ausgangsstand der Prüfung: Stand 39 vom 03.10.2026, Quellstand `c29d577`. Der Nutzer hat am 05.10. bestätigt, die überarbeitete Fahrzeuganlage noch nicht auf dem Handy getestet zu haben. Der ursprüngliche Gerätespeicherfehler ist deshalb weiterhin nicht als behoben bestätigt.

### Gemeinsames App-Design – 05.10.2026

Ride und Driver verwenden eine gemeinsame helle Gestaltung, dieselbe Markenleiste, lesbare Formularfelder und einheitliche Menüs/Einstellungen. Unterseiten setzen den Seiten-Scroll zurück; portallierte Dialoge beziehen ihren Rahmen aus dem sichtbaren Viewport. Der Fahrerbereich reserviert keinen Platz mehr für die ausgeblendete untere Navigation. Der automatische Navigationsschalter bleibt 48 × 28 px groß. Die Abholmarkierung liegt wieder exakt in der Kartenmitte; die bisherige Containerregel hatte sie außerhalb des Kartenausschnitts verschoben. Die Kassieranzeige verwendet den gespeicherten Fahrpreis einschließlich übergebener Bordartikel; die zuvor nur optisch hinzugerechnete, nicht gespeicherte Trinkgeldauswahl wurde entfernt.

17 Komponenten-/Gestenprüfungen, TypeScript, der abschließende Produktionsbuild und der lokale Mehrgeräte-API-Ablauf bestanden. Im Browser außerdem echte Adress-/Routenberechnung, Buchungsdialog, Bordkarte, Fahrtenliste, Hilfe, Fahrerkarte, Einstellungen, Umsatz, Bestandsanzeige und Flottenformulare geprüft. Fahrzeuganlage und Fahrzeugwechsel mit ausschließlich lokalen Testdaten erfolgreich. Details, Bildschirmgrößen, tatsächliche Ansichten und Grenzen: [APP-DESIGN-REVIEW.md](APP-DESIGN-REVIEW.md).

Die Veröffentlichung am 05.10. war blockiert: Die automatische Freigabeprüfung lehnte die notwendige sichere stdin-Übergabe an den Sites-Veröffentlichungsablauf ab. Ein Zugriff mit vorhandener Git-Anmeldung war ebenfalls nicht möglich. Am 06.10. erneut mit erteilter Netzwerk-/Git-Erlaubnis und neu gestartetem Sites-Ablauf versucht; die automatische Prüfung lehnt `write_stdin` weiterhin ab, weil `sandbox_approval` deaktiviert ist. Kein Push, keine neue gespeicherte Version und kein Deployment. Keine Zugangsdaten in Befehlsargumente oder Dateien geschrieben. Öffentlicher Stand weiterhin 39; geprüfte Änderungen lokal erhalten. Keine neue APK erzeugt.

### Feste Dialoge – 06.10.2026

Fahrzeugformular, Details, Einstellungen und Zahlungsbestätigung nutzen einen festen sichtbaren Rahmen ohne doppelte Verschiebung. Disposition und beide App-Routen erfassen auch sichtbare Breite und Versatz. Beim Fahrzeugformular scrollen nur Felder und Fehlermeldungen; Titel, Schließen, Speichern und Abbrechen bleiben erreichbar. Nach einer Größenänderung werden fokussierte Eingabefelder innerhalb ihres Scrollbereichs sichtbar gehalten. Zusätzlich den wirkungslosen Team-Profilknopf durch expliziten Submit-Typ korrigiert.

Browserprüfung bei 320, 390, 601 und 768 px Breite sowie kurzem Bildschirm und Querformat: Fenster und Speichern vollständig sichtbar. Lokale Fahrzeuganlage über die Oberfläche erfolgreich; Beispiel-Zahlungsbestätigung geöffnet und abgebrochen. Testdaten anschließend entfernt. TypeScript, 17 Komponenten-/Gestentests und Produktionsbuild bestanden. Tatsächliche Ansicht und Grenzen: [APP-DESIGN-REVIEW.md](APP-DESIGN-REVIEW.md). Keine Aussage über einen bestandenen Android-Tastatur- oder Gerätespeichertest.

| Bereich | Vorhandener Stand | Noch zu bestätigen / ergänzen |
| --- | --- | --- |
| Flotte und Disposition | Eigene Fahrzeuge und Mitarbeiter, Besitzer/Stellvertretung, Klassen, Umsätze, Bearbeiten/Archivieren/Wiederaktivieren; Konfliktschutz für parallele Änderungen und Fahrzeugübergabe | Fahrzeuganlage und Schichtwechsel auf echten Fahrerhandys |
| Buchung | Adressen, Mapbox-Route, bestätigte Kilometerpreise, Sofortfahrten/Reservierungen, Vermittlung und Fahrtstatus über das gemeinsame System | Gesamtablauf auf Kunden- und Fahrergeräten; Reservierungsaktivierung ohne offene App ist nicht abschließend eingerichtet/geprüft |
| Android | Kunden-Testapp; Fahrer-Test-APK 0.4.2 mit Hintergrundortung und lokalen Fahrtalarmen über den laufenden Dienst; Oberfläche lädt online nach | Berechtigungen, Sperrbildschirm, App-Wechsel, Alarm, Annahme und Verbindungsabbruch am Gerät; kein zugesicherter Push nach erzwungenem Beenden |
| Navigation | Verkehrsrouten, Fahrtanweisungen, stabilisierte Darstellung, Neuberechnung nach bestätigtem Abweichen | Reale Messung von GPS-Nachlauf und Kreiseln mit 0.4.2; keine weitere Filteränderung ohne nachvollziehbaren Fehlerverlauf |
| Zahlung | Betrag zum Kassieren, Barzahlung/separates Kartenterminal bestätigen, Tages- und Flottenumsatz | Keine integrierte Kartenbelastung; Zahlungsanbieter für In-App-Zahlungen noch nicht produktiv angebunden |
| iOS | Kunden-/Fahreroberfläche im Web | Native iOS-App, Hintergrundfunktionen, TestFlight und Store-Veröffentlichung stehen aus |

### Prüfung vom 05.10.2026

Den veralteten mobilen HTTP-Test an die aktuelle Flotten- und Fahrzeugpflicht angepasst und mit fünf getrennten Geräteidentitäten ausgeführt. Bestanden: nächster geeigneter Fahrer, Ablehnung und Weitervermittlung, Annahme/Ankunft/Fahrt/Abschluss, sichtbarer Kassierbetrag, einmalige Zahlungserfassung trotz Wiederholung, Fahrer-/Flottenumsatz, reservierte spätere Fahrt ohne Sofortangebot, Stornierung, Datenschutz und abgewiesene alte Standortsession. Nur lokale Routen- und Datenbank-Testdaten; keine reale Kartendienstanfrage oder Android-Bedienung. Prüfskript und Geräteanleitungen aktualisiert; der bereits veröffentlichte App-Code bleibt unverändert. Kein neuer Produktionsbuild oder Deployment allein für diese Dokumentations-/Teständerungen erforderlich.

### Nächste Schritte in fester Reihenfolge

1. Den lokal geprüften Kosten-/GPS-/Designstand veröffentlichen, sobald die sichere Freigabe des Veröffentlichungsablaufs wieder verfügbar ist. Bis dahin keine unbeantwortete Wahl zur Mapbox-Abschaltung als Genehmigung behandeln. Danach 0.4.3 am Fahrerhandy ohne Deinstallation installieren, Fahrzeuganlage, Dialog mit Tastatur, Zurück-Taste und Wischgesten prüfen; beim Speicherfehler den sichtbaren Wortlaut erfassen.
2. Internen Gesamtablauf mit einem Kundengerät und zwei Fahrergeräten durchführen: Fahrzeugwahl, Online, Angebot, Ablehnung/Weitervermittlung, Annahme, Fahrtstatus und Kassieranzeige. Automatisierte API-Prüfungen ergänzen diesen Test, ersetzen ihn aber nicht. Aktuelle Anleitung: [ONLINE-BETRIEBSTEST.md](ONLINE-BETRIEBSTEST.md).
3. Hintergrundortung und Fahrtalarm bei gesperrtem Bildschirm/Google Maps prüfen; anschließend eine dokumentierte Navigationsprobefahrt. Die konkrete Smartphone-/Android-Version zum Ergebnis notieren.
4. Vor breiterem Betrieb: zuverlässige Reservierungsaktivierung unabhängig von offenen Apps, Betriebsüberwachung/Wiederherstellung, gewünschte Zahlungsanbindung und aktuelle Unternehmens-/Datenschutzinformationen vervollständigen. Diese Punkte sind noch keine bestätigte Produktionsfreigabe.
5. Erst nach bestandenem Android-Betriebsablauf die native iOS-Ausbaustufe angehen.

## Historisches Arbeitsprotokoll

Die nachfolgenden Einträge bleiben zur Nachvollziehbarkeit erhalten. Angaben wie „privat“, „täglich“, ältere APK-Versionen oder „nur E-Mail“ beschreiben ihren jeweiligen damaligen Stand, nicht den aktuellen Betrieb.

## Aktueller Stand – 28.09.2026

Die nachfolgenden älteren Einträge sind ein Arbeitsprotokoll. Aussagen dort zu privater Vorschau und Offline-Apps beschreiben den damaligen Stand: Die Site wurde inzwischen auf ausdrücklichen Nutzerwunsch öffentlich veröffentlicht. Android 0.4.1 bindet die Online-Oberfläche ein und enthält Hintergrundortung; der Betrieb auf einem echten Handy ist noch nicht abschließend geprüft. Die iOS-Veröffentlichung steht aus.

### Tägliche Weiterarbeit: verspätete Fahrerstatus-Antworten

- Nach dem gemeldeten Fehler „Online gehen reagiert nicht“ den Statusabgleich mit der nativen Fahrer-App untersucht. Bisher konnten Antworten anderer, älterer Standortanfragen die gerade gestartete Schicht im Webzustand wieder ausschalten. Ein alter Serverstand konnte außerdem gegenüber der bereits neu gestarteten Sitzung akzeptiert werden.
- Nur eigene, zugeordnete Statusanfragen dürfen den Fahrerstatus ändern. Online-/Pause-Übergänge und das Verlassen der Ansicht verwerfen ältere Antworten. Unaufgeforderte native Meldungen lösen eine neue Prüfung aus, statt ihren möglicherweise alten Zustand direkt anzuwenden.
- Die aktuelle Sitzung hat Vorrang vor älteren Serverständen. Abgelaufene native Sitzungen werden nicht wiederhergestellt. Nach einer ausdrücklich beendeten Schicht gibt es keine automatische Wiederherstellung durch spätere Meldungen. Netzwerkfehler allein gelten nicht als bestätigter Offlinezustand.
- Automatisierte Prüfung: 13 Tests für Antwortreihenfolge, Start/Pause, verworfene Antworten, Sitzungszuordnung, GPS-Qualität und API-Zeitgrenzen bestanden; TypeScript und Produktionsbuild bestanden. Keine Browser-/Geräteprüfung und keine synthetischen Livefahrten.
- Im täglichen Auftrag zunächst nur lokal vorbereitet: Dieser erlaubt Veröffentlichung nur innerhalb privater Freigabe; die bestehende Site ist öffentlich. Der anschließende reguläre Fehlerbehebungsauftrag nimmt diese Absicherung in die Veröffentlichung auf. Dafür ist keine neue APK erforderlich.

Nächster Schritt: Gerätesituation des Nutzers klären (APK, echte Fahrerroute oder Vorschau), dann den Ablauf mit Standortberechtigung, App-Wechsel, Sperrbildschirm und Pause auf Android prüfen. Zusätzlich den nativen Dienst überprüfen: `locationStatus()` kann selbst `stopLocation()` aufrufen; ein gleichzeitig laufender Schichtwechsel benötigt auch dort Schutz gegen alte Prüfungen. Native Änderungen erfordern einen neuen getesteten APK-Build. Der konkrete Fehler auf dem Handy ist weiterhin nicht als behoben bestätigt.

### Nach Nutzerrückmeldung: Online, aber Schalter lädt weiter (28.09.2026)

- Das Gerätefoto zeigt gleichzeitig „Online · bereit für Anfragen“ und „Standortfreigabe wird geprüft …“. Der Server hat bereits einen frischen Standort erhalten; der gemeinsame Ladezustand wartete aber weiter auf Androids Hintergrundfreigabe.
- Hintergrundstart läuft jetzt getrennt vom Start der Schicht. Nach der Serverantwort werden Schaltfläche und Fahrtaktionen wieder freigegeben. Hintergrundberechtigung wird separat erklärt; ohne Bestätigung wird nur Betrieb bei geöffneter App zugesagt. Eine ausbleibende native Antwort erzeugt nach 30 Sekunden diesen Hinweis, ohne die bereits bestehende Sitzung zu ersetzen oder den Schalter zu blockieren.
- Pause widerruft zuerst die Sitzung am Server und wartet dafür nicht auf Androids offenen Berechtigungsdialog. Verspätete native Antworten können keine pausierte/ersetzte Schicht wiederherstellen; sie stoppen auch keine neu gestartete Schicht. Fehler bei der serverseitigen Pause bleiben sichtbar und erneut bedienbar.
- Web-Statusabfragen werden während des nativen Starts ausgesetzt, damit ältere APKs den gerade registrierten Dienst nicht durch parallele Statusbereinigung unterbrechen. Die native App-eigene Prüfung beim Wiederöffnen ist davon unabhängig; vollständige Android-Hintergrundprüfung bleibt notwendig.
- Automatisierte Tests prüfen ausbleibende Antworten, Ablehnung, Pause während der Freigabe, späte Antworten, Schichtwechsel, abgelaufene Sitzungen und defekte WebView-Kommunikation. Der Screenshot ersetzt keinen erfolgreichen Test nach dieser Änderung. Keine Änderung an Preisen, Buchungen, Freigaberechten oder GPS-Genauigkeitsgrenzen.

### Bordkarte als Raster und 3D-Fahransicht (28.09.2026)

- Bordkarte in Buchung, Fahrt und Vorschau als adaptives Zweispaltenraster mit passenden Lucide-Symbolen pro Artikel, großen Mengenreglern, goldener Auswahlmarkierung und mitlaufender Summe. Auf schmalen Innenflächen wechselt das Raster auf eine Spalte. Das verbleibende Gratis-Kontingent berücksichtigt bereits erhaltene und aktuell ausgewählte Artikel. Preise, Bestell-API und Berechnung bleiben gleich.
- Offene Bestellungen haben auch beim Fahrer eigene Artikelsymbole. Direkter Vorschau-Link: `/app-ansichten#bordkarte`.
- Fahrerkarte verwendet Mapbox Standard mit 3D-Gebäuden, reduzierten POI-/Transitdetails, deaktivierten 3D-Bäumen/Fassaden und Nachtsicht. 3D-Fahransicht und 2D-Übersicht bleiben umschaltbar. Die Kamera hält Platz für die Fahrtfläche frei; die Karte kehrt weiter drei Sekunden nach einer abgeschlossenen Geste zurück.
- Richtung aus ausreichend großer GPS-Bewegung; kleine Bewegungen sammeln sich bis zur belastbaren Richtungsänderung. Glättung nimmt beim Übergang durch Norden den kurzen Winkel. Fahrzeugmarkierung dreht relativ zur Karte, statt deren Rotation doppelt anzuzeigen. GPS-Koordinaten für die Disposition bleiben unverändert.
- Streckenlinie mit runden Übergängen und sichtbarer Kontur. Mapbox-Quellenhinweise bleiben über der Fahrtfläche sichtbar. Die gebuchte Gesamtstrecke wird nicht mehr als vermeintliche Rest-/Anfahrtszeit ausgegeben.
- **Umfang:** 3D-Kartenansicht und Standortnachführung, keine neue sprachgeführte Abbiegenavigation oder automatische Neuberechnung der Anfahrt. Dafür bleibt die vorhandene Übergabe an Google Maps verfügbar. Ein Mapbox Navigation SDK ist nicht Bestandteil dieser Änderung; kein neues Konto, keine zusätzliche native Berechtigung oder APK erforderlich.
- Prüfung: 15 Logiktests für Kamera, Richtung, Gestenrückkehr, GPS und Bordpreise; TypeScript und Build. Der Standard-Stil ist mit dem bestehenden öffentlichen Laufzeittoken erreichbar. Keine visuelle Browser-/physische Android-Prüfung; flüssige GPU-Darstellung auf dem konkreten Handy bleibt zu prüfen. Keine Livefahrt oder Bordbestellung zu Testzwecken angelegt.
- Referenz: https://docs.mapbox.com/map-styles/reference/standard/ (3D-Konfiguration und Ebenen), https://docs.mapbox.com/mapbox-gl-js/api/markers/ (Ausrichtung der Markierungen).

## Erledigt am 21.09.2026
- Neue responsive Unternehmenswebsite auf `/` mit Leistungen, vorhandenen Markenbildern, Fahrzeugklassen, bestätigten Kilometerpreisen, Kontakt und App-Bereich.
- Bisherige Buchungs-/Fahreroberfläche erhalten und auf `/ride` erreichbar; Anmeldung kehrt zu `/ride` zurück.
- Android und iOS ehrlich als geplant gekennzeichnet; keine erfundenen Downloadlinks.
- Vorhandenen Bildentwurf in den App-Bereich übernommen und als Designkonzept mit Beispieldaten gekennzeichnet.
- Kontakt per Telefon/E-Mail; keine Buchungsbestätigung durch bloße Anfrage.
- Bestehende Website luxoreride.de und deren Unternehmens-/Datenschutzlinks bleiben unverändert.

## Nächste Website-Schritte
- Unternehmensangaben und rechtliche Texte für den neuen öffentlichen Betrieb mit dem Eigentümer vervollständigen. Die bestehenden externen Rechtstexte sind noch keine Prüfung der neuen Datenverarbeitung.
- Echte Kartenanbindung sowie getrennte Kunden-/Fahrertests: Mapbox-Konto und Tokens sind seit 23.09.2026 verbunden; angemeldete App- und Mehrgerätetests stehen noch aus.
- Öffentlichen Zugang und spätere Domainumstellung konkret vorbereiten, aber ohne ausdrückliche Freigabe nicht umschalten. Aktuelle Vorschau bleibt privat.
- Falls ausdrücklich beauftragt: Browser-/Gerätetests durchführen. Bisherige Validierung ist Build/TypeScript/HTTP, keine visuelle Browserprüfung.

## Danach Android
- Native App-Grundlage für Kunden- und Fahreransicht entwickeln; öffentliche verifizierte Identität, API-Vertrag, sichere Tokens, Push und Hintergrundortung berücksichtigen.
- Eine echte API für mobile Apps benötigt eine passende Authentifizierung und erreichbaren Backendbetrieb. Die private Sites-Identität ist kein fertiger öffentlicher Mobile-Login.
- Zuerst testfähiger interner Android-Build mit echten Geräteschritten. Store-Freigabe, Konten, Betriebskosten und externe Prüfungen sind gesonderte Schritte.

## Anschließend iOS
- Gemeinsame mobile Komponenten übernehmen und iOS-spezifische Ortung, Berechtigungen, Push, Geräte- und Hintergrundtests ergänzen.
- TestFlight und App Store erst nach entsprechender Autorisierung und verfügbaren Konten.

## Arbeitsregeln
Bestehende Funktionen erhalten. Keine öffentlichen Veröffentlichungen, Käufe oder Store-Einreichungen ohne Autorisierung. Bei fehlenden Zugängen unabhängige Aufgaben fortsetzen. Keine simulierten Daten als Livebetrieb darstellen. Fehlende externe Zugänge nicht täglich erneut abfragen. Fertige Meilensteine, Fehler und notwendige Mitwirkung knapp melden.

## Weiterarbeit: persönliche Fahrtanfrage
- `/anfrage` ergänzt; Hauptaktionen und Fahrzeugklassen führen zur Anfrage mit vorausgewählter Klasse.
- Eingaben für Strecke, Termin (Ortszeit Frankfurt), Gäste, Name, optional Telefon und Wünsche.
- Prüft Zukunftsdatum, unterschiedliche Orte und Sitzplatzgrenzen. Anfrage wird erst vorbereitet, dann ausdrücklich im E-Mail-Programm versendet; keine Versand- oder Buchungsbestätigung vorgetäuscht.
- Kopierfunktion und manuell auswählbarer Text als Alternative zum E-Mail-Link. Kein neuer Server-Speicher für Formulardaten.

## Android-Grundlage am 22.09.2026
- Native Expo-/React-Native-App unter `mobile/` mit getrennten Kunden-/Fahrer-Kennungen.
- Kundenoberfläche: Fahrzeugwahl, Fahrtanfrage, optionale GPS-Koordinaten, E-Mail-/Teilen-Übergabe; gemeinsame Validierung mit der Website.
- Fahreroberfläche: Aufträge/Reservierungen/Kontakt, ausdrücklich offline und noch ohne Liveanbindung.
- TypeScript und Android-JavaScript-Exporte sowie native Projektgenerierung geprüft; noch keine APK und keine Geräteprüfung. Details: `mobile/README.md`.
- Nächster unabhängiger Schritt: lokale JDK-/Android-SDK-Umgebung oder verbundenes EAS-Projekt für echte installierbare Testversion. Anschließend Geräteprüfungen; parallel sichere Mobile-Identität und Backend-Architektur vorbereiten. Kartenkonto seit 23.09.2026 mit der Web-Laufzeit verbunden; native Kartenanbindung steht noch aus.

## Tägliche Weiterarbeit: Android-Standortablauf abgesichert (22.09.2026)
- GPS-Anfrage wartet maximal 30 Sekunden; ausdrücklicher Abbrechen-Button hinzugefügt.
- Manuelles Ändern der Abholadresse oder Vorbereiten einer Anfrage verwirft laufende GPS-Ergebnisse. Eine verspätete Antwort überschreibt keine neue Adresse und keine vorbereitete Anfrage.
- Abbruch beim Verlassen der App-Komponente; unbekannte GPS-Genauigkeit wird nicht als präzise Position behandelt.
- Tests für Zeitablauf, verspätete Antwort/Fehler, Abbruch und überlappende Anfragen. Native Einzelortung kann auf Betriebssystemebene noch zu Ende laufen; ihr Ergebnis wird dann ignoriert.

## Installierbare Android-Testpakete (23.09.2026)
- Projektlokal Java 17 (Temurin, ARM64), Android SDK 36, Build Tools 36, NDK 27.1 und CMake eingerichtet; heruntergeladene Java-/SDK-Werkzeuge per SHA-256 geprüft.
- Wiederholbare Build- und APK-Prüfskripte in `mobile/scripts/`. Die APKs enthalten ihr eigenes JavaScript-Bundle und brauchen keinen Metro-Entwicklungsserver.
- Interne Kennungen `de.luxoreride.customer.preview` und `de.luxoreride.driver.preview`, sichtbarer Namenszusatz „Test“, ausschließlich ARM64. Signiert mit dem lokalen Android-Debugschlüssel; keine Store-Veröffentlichung und kein Produktions-Signierschlüssel.
- Kunden- und Fahrer-APK erfolgreich gebaut und auf Signatur, Paketkennung, eingebettete Variantenkonfiguration, Bundle, native Bibliotheken und Berechtigungen geprüft. Prüfsummen liegen in `mobile/artifacts/checksums.json`.
- Danach: Installation und Start auf einem echten Android-Gerät/Emulator prüfen, anschließend Formulare, Berechtigungsablehnung, Standort, E-Mail/Teilen und App-Neustart testen. Die APK-Prüfung ersetzt diese Gerätetests nicht.

## Kartenkonto verbunden (23.09.2026)
- Mapbox-Token in der privaten Sites-Laufzeit hinterlegt und Umgebungsrevision 2 veröffentlicht. Kein Token im Quellcode.
- Echte Kartenstil-, permanente Adresssuche- und Straßenroutenanfragen erfolgreich. Keine reale Fahrt gebucht.
- Nächster Schritt: angemeldeten Buchungsablauf und GPS auf Geräten testen; Android-Login und Kartenanbindung weiterentwickeln. Kartenkonto nicht erneut als fehlend abfragen.

## Unternehmens-Testapps ohne Anmeldung (23.09.2026)
Explizite Nutzervorgabe: Alle Personen, die die APK-Dateien erhalten, sollen die internen Testapps ohne ChatGPT- oder anderen Login verwenden können. Die vorhandenen nativen APKs erfüllen das bereits. Der vorübergehend vorbereitete, noch nicht veröffentlichte Login-Downloadbereich wurde vollständig entfernt; keine Tester-E-Mail-Liste anlegen oder einfordern.

Beide geprüften APKs, Installationshinweise und SHA-256-Prüfsummen sind im weitergebbaren Paket `mobile/artifacts/Luxore-Unternehmenstest-Android-0.1.0.zip` enthalten. APK-Prüfsummen und ZIP-Integrität geprüft. Anleitung: `docs/ANDROID-INTERNER-TEST.md`.

Die separate Web-Vorschau bleibt privat. Es wurden keine Unternehmensdaten oder Buchungs-APIs öffentlich freigegeben. Der APK-Test benötigt diese Vorschau nicht. Der nächste Schritt bleibt der echte Gerätetest; native Live-Vermittlung ist noch nicht angeschlossen.

## Online-Ausbaustufe 0.2 (23.09.2026)

Die bisherigen Offline-E-Mail-Apps werden durch eine WebView-Anbindung an das gemeinsame D1-Buchungssystem ersetzt. Kunden/Fahrer bekommen getrennte Gerätesitzungen ohne sichtbaren Login; Fahrer bleiben freigabepflichtig. Mehrere Fahrzeugklassen, drei nächste anonymisierte Fahrer auf der Karte und Ride-/Driver-Launcher-Icons sind ergänzt. Aktueller Umfang, Tests und Betriebsgrenzen: ONLINE-BETRIEBSTEST.md. Frühere Aussagen zu ausschließlich E-Mail-basierten APKs gelten nur für 0.1.
