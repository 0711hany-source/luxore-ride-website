# Nächste Schritte

1. Für offiziellen Betrieb einen kommerziell geeigneten Hostingtarif oder eine ausdrücklich gewählte Alternative klären; kostenlos unbegrenzte Kontingente nicht zusagen. Die permanente Adresssuche ist ohne positives Budget deaktiviert; GPS-/Kartenpunkte können ohne Geokodierung gewählt werden.
2. Die vorbereitete Freischaltung und Betreiberzuordnung nach konkreter Bestätigung speichern; neuen GitHub-/Vercel-Stand und reale Datenbankverbindung prüfen. Neustart mit neuen Profilen ist bestätigt, der Altbestand bleibt unangetastet.
3. Erste Betreiberanmeldung per E-Mail-Code auf luxoreride.de durchführen. Profilname/Telefon ergänzen, Flotte, Mitarbeiter und Fahrzeuge einrichten; Fahrer einzeln prüfen und freigeben. Wiederholte Flottenanlage nach Verbindungsabbruch ist jetzt lokal geprüft und erzeugt keine zweite Flotte. Kein Kennzeichen allein erteilt Rechte.
4. Beide internen Android-Apps 0.5.1 einmal installieren und Konto, Fahrzeug-Speicherung, Buchung, Annahme, Fahrtabschluss und Kassieren auf getrennten realen Geräten prüfen. Kontoabfrage blockiert die Wiederaufnahme der Fahrerortung nicht mehr; Gerätebeweis bleibt offen.
5. Hintergrundortung, gesperrten Bildschirm, externe Navigation, Rückkehr und Neustart auf den Unternehmenshandys prüfen. Straßennahen Pfeil und Latenz anhand echter GPS-Aufnahmen verbessern.
6. Die eingebetteten Karten-, Fahrt- und Flottenansichten schrittweise in gemeinsame native Komponenten überführen. Premium-Gesten und feste Fenster auf beiden Apps erhalten.
7. Vor kommerziellem Start geeigneten Vercel-Tarif, Reservierungsscheduler, Betriebsüberwachung, Backups/Wiederherstellung, Rechtsangaben und Zahlungsintegration fertigstellen. Kein kostenpflichtiger Wechsel ohne konkrete Autorisierung.
8. Offizielle Android-Store-Builds; danach iOS. Keine Store-Verfügbarkeit vor erfolgreicher Freigabe behaupten. Eine spätere Altdatenzusammenführung muss neue Daten erhalten.
