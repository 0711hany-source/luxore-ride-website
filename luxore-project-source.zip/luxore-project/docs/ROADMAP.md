# Nächste Schritte

Konten und Buchungen sind konkret freigegeben und aktiviert. Live-Datenbankverbindung und zugestellte Betreiber-Code-E-Mail sind bestätigt. Authentifizierte Betreiber-Flottenansicht mit drei Fahrzeugen ist sichtbar; keine weitere Freischaltungsbestätigung verlangen.

7. Oktober, Abend: Health prüft zusätzlich die Buchungs-/Adresstabellen einschließlich `attribution`, ohne Konten bei einer fehlenden Buchungsmigration als ausgefallen auszugeben. Vier neue Integrationstests mit echten SQLite-Migrationen; insgesamt 223 Tests bestanden. Flottennavigation verwendet auf schmalen Ansichten einzeilige Beschriftungen und behält 76 Pixel hohe Bedienflächen. Keine neue Migration oder APK für diesen Web-Schritt erforderlich.

1. Kostenlose Adresssuche mit einem ausdrücklich gewählten Anbieter einrichten; `docs/ADDRESS-SEARCH.md` beschreibt die vorbereitete Geoapify-Free-Anbindung. Ohne Schlüssel bleibt neue Textauswahl gesperrt. Für offiziellen Betrieb einen kommerziell geeigneten Hostingtarif oder eine ausdrücklich gewählte Alternative klären; kostenlos unbegrenzte Kontingente nicht zusagen. Die permanente Adresssuche ist ohne positives Budget deaktiviert; GPS-/Kartenpunkte können ohne Geokodierung gewählt werden.
2. Aktivierten Stand erhalten und Betrieb prüfen. Neustart mit neuen Profilen ist bestätigt, der Altbestand bleibt unangetastet.
3. Bestehende Betreiberanmeldung auf luxoreride.de erhalten. Profilname/Telefon ergänzen, Flotte, Mitarbeiter und Fahrzeuge einrichten; Fahrer einzeln prüfen und freigeben. Wiederholte Flottenanlage nach Verbindungsabbruch ist jetzt lokal geprüft und erzeugt keine zweite Flotte. Kein Kennzeichen allein erteilt Rechte.
4. Beide internen Android-Apps 0.6.1 einmal installieren und Konto, Fahrzeug-Speicherung, Buchung, Annahme, Fahrtabschluss und Kassieren auf getrennten realen Geräten prüfen. Kontoabfrage blockiert die Wiederaufnahme der Fahrerortung nicht mehr; Gerätebeweis bleibt offen.
5. Hintergrundortung, gesperrten Bildschirm, externe Navigation, Rückkehr und Neustart auf den Unternehmenshandys prüfen. Straßennahen Pfeil und Latenz anhand echter GPS-Aufnahmen verbessern.
6. Die native Fahreransicht auf realen Geräten prüfen; vollständige native Kundenbuchung und erweiterte Disposition als Nächstes umstellen. Premium-Gesten und feste Fenster auf beiden Apps erhalten.
7. Vor kommerziellem Start geeigneten Vercel-Tarif, Reservierungsscheduler, Betriebsüberwachung, Backups/Wiederherstellung, Rechtsangaben und Zahlungsintegration fertigstellen. Kein kostenpflichtiger Wechsel ohne konkrete Autorisierung.
8. Offizielle Android-Store-Builds; danach iOS. Keine Store-Verfügbarkeit vor erfolgreicher Freigabe behaupten. Eine spätere Altdatenzusammenführung muss neue Daten erhalten.

## 8. Oktober · Direkter nativer Fahrerbereich

Fahrer-Cockpit, Mapbox-3D-Karte, Fahrzeugwechsel, Fahrtangebote und Statusgesten, Bargeld-/Terminalbestätigung, Tagesumsatz, Fahrzeugverwaltung/Team und Bordbestand sind nativ implementiert. Der Fahrerzweig öffnet keine eingebettete Fahrer-Webseite mehr. Die gesicherte eigene Kontositzung und Rechte bleiben erhalten. Kontoprofil ist offline sitzungsgebunden wiederherstellbar; Standortwiederaufnahme bleibt unabhängig von der Kontoantwort. GPS-Vordergrundmessungen speisen denselben Hintergrunddienst mit begrenzten, nicht überlappenden Uploads. Keine Production-Ortung/Schicht oder Testfahrt erfunden.

234 Tests bestehen einschließlich echter React-Komponenten mit isolierten Test-API/GPS-Adaptern: direkter Einstieg ohne eingebetteten Fahrer, natives Fahrzeugformular mit erfolgreicher Speicherung, native Bestandskorrektur und ausschließlich vollständige Wischannahme. Das ist kein physischer Android-GPS-Nachweis. Kein Android-Handy ist per ADB angeschlossen. Priorität: 0.6.1 als Update installieren und Schichtstart, Bildschirm sperren, externe Navigation, Rückkehr, GPS-Latenz und Akku prüfen. Anschließend native Kundenbuchung und vollständige native Disposition/Betreiberaktionen. Details in `NATIVE-DRIVER-060.md`.


## 8. Oktober · Startschutz und Adressauswahl 0.6.1

Mapbox-Telemetrie hat vor der Tokeninitialisierung eine native MapView angelegt. Der echte Android-SDK-Test bestätigt die MapboxConfigurationException ohne Token und erfolgreiche Konstruktion nach dessen Initialisierung. Kartenmodul wird erst innerhalb einer montierten Fehlergrenze mit aktivem Bildschirm und Token geladen. Initialisierung ist serialisiert, abgebrochene Ansichten und Wiederholungen sind geprüft. Fahrer-APK hat drei kalte Starts im AOSP-Emulator bestanden, Kunden-APK ebenfalls gestartet; keine native Fatal-/JS-Fehlermeldung. Kein physischer GPS- oder authentifizierter kompletter Schichtbeweis. 245 Tests bestanden. APKs 0.6.1 / Build 15 ersetzen die Startempfehlung für 0.6.0; Details und Hashes in ANDROID-STARTUP-061.md.

Adressvorschläge stehen direkt inline; Auswahl per Tippen und Tastatur sowie Fehlerkorrektur getestet. Lokaler 390×844-Browser bestätigt Auswahl beider Adressen und alle Kilometerpreise mit synthetischem kostenlosen Anbieter. Geoapify-Registrierung ist vorbereitet; konkrete Vertrags-/E-Mail-Freigabe angefragt, noch kein Konto/Schlüssel eingerichtet. Mapbox-Permanent-Budget bleibt 0. Neue dauerhafte Textauswahl live bleibt deshalb bis Anbieter-Einrichtung gesperrt. Den tatsächlichen Blocker nicht als erledigt ausgeben.
