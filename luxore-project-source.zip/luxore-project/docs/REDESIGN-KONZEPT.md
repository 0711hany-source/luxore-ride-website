# Redesign-Konzept LUXORÉ Ride / LUXORÉ Driver („Apple-like“, Android + iOS)

Stand 14.11.2026 · nur Analyse und Konzept, kein Code geändert. Zeilenangaben = Stand beim Lesen (`mobile/src` wird parallel bearbeitet, Zeilen können sich verschieben). „Nicht geprüft“ heißt: im Code nicht nachgesehen oder nur auf einem Gerät feststellbar.

## 1. Bestandsaufnahme Code

**Native Apps (`mobile/`, eine Codebasis, zwei Varianten über `APP_VARIANT`)**
- Expo SDK 57, React Native 0.86.3, React 19.2.3, Karten `@rnmapbox/maps` 10.3.7, Symbole `lucide-react-native`.
- Vorhanden: `expo-location`, `expo-task-manager`, `expo-notifications`, `expo-secure-store`, `react-native-safe-area-context`, `react-native-svg`, `react-native-webview`.
- **Fehlt:** `react-native-reanimated`, `react-native-gesture-handler`, `expo-haptics`, `expo-blur`, jede Navigations-Bibliothek, Bottom-Sheet-Bibliothek, Datums-Auswahl, `expo-local-authentication`, Schrift-Paket.
- Navigation: ein einziger Zustand `screen` in `App.tsx:88` (12 Werte). Kein Verlauf: Zurück (Pfeil, Android-Taste `App.tsx:184`, Randwischen `App.tsx:282`) springt immer zur Startseite, nie eine Ebene zurück. Screens werden per `display:'none'` versteckt statt gestapelt; keine Übergangsanimation.
- Zustand: pro Bereich eine eigene Controller-Klasse mit `useSyncExternalStore` (`customer-booking.ts`, `customer-live.ts`, `customer-trips.ts`, `operations.ts`, `fleet-*.ts`); Abfragen per Intervall (5 s Fahrer/Live, 10 s Fahrten, 15 s Disposition). Diese Logik ist sauber von der Oberfläche getrennt – gut für ein Redesign.
- Gesten heute: `SwipeAction.tsx` (Wischen zum Bestätigen, `PanResponder` + `Animated`), Fahrer-Sheet mit 2 Stellungen (`DriverScreen.tsx`, PanResponder), Kunden-Live-Sheet mit 2 Stellungen **ohne Animation** (`CustomerLiveScreen.tsx:150,216` – Höhe springt), Randwischen in `App.tsx:282`. Kein Pull-to-Refresh, keine Listen-Wischaktionen, kein Long-Press, keine Haptik (0 Treffer für Vibration/Haptics).
- Dialoge: 11 × `Modal` (teils `pageSheet`, teils `fullScreen`), 3 × `Alert.alert`.
- Echt nativ: alle Kunden-Screens (Buchung, Adresse, Kartenpunkt, Live, Fahrten, Bordkarte), Fahrer (Schicht, Angebot, Fahrt, Kassieren, Umsatz), Flotte, Disposition, Einladungen, Bestand, Anmeldung. **WebView** (`RideWorkspace.tsx`) wird nur noch in der Kunden-App für Sonderpfade (z. B. Betreiberübersicht) geladen; die Fahrer-App rendert sie nicht mehr (`App.tsx:604`).
- Server-Adresse fest auf `https://luxoreride.de` (`account-client.ts:3`, `location-service.ts:15`, `webview-session.ts:3`, `RideWorkspace.tsx:34`): die Apps sprechen immer mit der Live-Seite; ein Redesign lässt sich auf dem Handy nicht gegen die lokale Testdatenbank prüfen.

**Web-App (`app/mobility/*`)**
- `workspace.tsx` (1362 Zeilen) und `driver.tsx` (1213) als Hauptdateien, Stile in `app-design.css` (975) und `globals.css` (5157).
- Gesten-Bausteine sind dort **weiter** als nativ: Sheet mit drei Rastpunkten peek/half/full (`sheet-motion.ts`), Seitenwischen (`gesture.tsx`), Wischen zum Schließen (`use-dismiss-gesture.ts`), Zurück-Stapel (`back-stack.ts`), Wischknopf mit Tastatur-/Screenreader-Bedienung (`swipe-action.tsx:26,77`).
- Fachlogik (Preise, Status, Bordkarte, Navigation) liegt in `lib/` und wird von beiden Seiten importiert; die Oberfläche ist doppelt gebaut (Web und nativ).

**iOS-Tauglichkeit**
- Vorbereitet: `app.config.ts` nennt `platforms: ['android','ios']`, Bundle-Kennungen, Standort-Texte, `isIosBackgroundLocationEnabled`. `eas.json` hat nur Android-Profile; es gibt keinen `ios/`-Ordner, nie gebaut.
- Android-spezifisch im Code: Fahrtalarm prüft einen Android-Benachrichtigungskanal – auf iOS gibt es keinen, `alertStatus()` meldet dort dauerhaft „aus“ (`offer-alerts.ts:32–34`); Texte „Android-Berechtigungen“, „Android-Einstellungen“ (`DriverScreen.tsx`, `RideWorkspace.tsx`, `offer-alerts.ts:100`); Apple Karten wird als Navigationsziel ausgefiltert (`DriverScreen.tsx:478`); Platzhaltertexte „in der Android-App verfügbar“ (`CustomerMap.tsx`, `PointMap.tsx`, `DriverMap.tsx`); Zurück nur über Android-Taste sauber; `userInterfaceStyle: 'light'` fest.
- Blocker für einen iOS-Bau (außerhalb des Codes): Apple-Entwicklerkonto, Mac-Build bzw. EAS, Mapbox-iOS-Einrichtung (nicht geprüft), Hintergrund-Standort-Freigabe durch Apple-Prüfung, Push (APNs). Kein Push-Server vorhanden (Problemliste).

## 2. Bestandsaufnahme Design/UX je Screen

Übergreifend: 24 verschiedene Schriftgrößen (10–43), 25 verschiedene Radien (2–32), Abstände frei gewählt; `theme.ts` kennt `radius`/`space`, aber kein Screen nutzt sie. Knopf, Zeile, Eingabefeld sind je Datei neu gebaut. Kopfzeile zeigt auf jedem Screen dieselbe Marke statt eines Titels. Ladezustand überall nur ein Kreisel, keine Platzhalter (Skeletons). Fehler als roter Fließtext im Inhalt. Kein Dunkelmodus. Englische Fassung nicht vorbereitet (Texte fest im Code).

| Screen | Befund |
| --- | --- |
| Kunde Start (`App.tsx`) | Reine Begrüßungsseite mit Bild und drei Kacheln; ein Tipp mehr bis zur Buchung. „Menü“ und „Konto“ als zwei Tabs plus Zahnrad oben = dreifacher Zugang. |
| Zieleingabe (`CustomerBookingScreen`, `NativeAddressPicker`) | Kein Kartenbild; Adresssuche als Vollbild-Modal mit eigener Kopfzeile; kein Autofokus, keine letzten Ziele/Favoriten; „Punkt auf Karte“ und „Mein Standort“ als drei Textlinks untereinander. Startblockade „Gespeicherte Anfrage …“ (`:236`) mit zwei Textlinks statt klarer Auswahl. |
| Reservierung | Datum/Uhrzeit als Tippfelder „TT.MM.JJJJ“/„HH:MM“ (`:334`) – fehleranfällig, kein Kalender/Rad. |
| Klassenwahl + Checkout | Alles in einer langen Scrollseite: Route → Klassen → Komfort → Bordkarte (alle Produkte) → Name/Telefon → Wischknopf weit unten. Preis der gewählten Klasse steht nicht fest sichtbar. Produktbilder kommen aus dem Netz ohne Platzhalter (`:530`). |
| Live-Fahrt (`CustomerLiveScreen`) | Karte + Sheet, aber Sheet springt, keine Ankunftszeit/Minutenanzeige (nur „Fahrerposition verfügbar“), Status nur als Wort, Tab-Leiste ausgeblendet und Zurück führt zur Startseite. |
| Fahrten (`CustomerTripsScreen`) | Karten-Liste, Details als Sheet – gute Basis. Kein Pull-to-Refresh, Storno nur tief im Detail. Leerzustand vorhanden. |
| Bordservice (`CustomerBoardScreen`) | Eigenes Modal über dem Live-Screen; inhaltlich doppelt zur Bordkarte im Checkout. |
| Konto/Anmeldung (`AccountPanel` in `App.tsx:759ff.`) | Registrierung und Anmeldung in einem Formular; Code-Feld ein einzelnes Textfeld; 60-s-Sperre inzwischen mit Zähler im Code (`retryAt`), Zeitüberschreitung beim Code-Versand führt zu einem langen Erklärtext. |
| Fahrer Standby (`DriverScreen`) | Karte + Sheet (2 Stellungen). „Online gehen“ zeigt minutenlang nur „Schicht wird geprüft …“: die Schritte (Standort erlauben → Server → Hintergrunddienst → Benachrichtigung → Status) haben einzeln Fristen bis 60/120 s, aber keine Schrittanzeige. |
| Angebot | Im selben Sheet, Countdown nur als Text „NEUE FAHRT · 23 S“, kein Ring/Balken, kein Vollbild, keine Haptik; Ablehnen als kleiner Textlink. |
| Fahrt-Status | Wischknopf je Status – gut. Bordbestellungen mit je eigenem Wischknopf schieben die Hauptaktion nach unten. |
| Kassieren | Zwei Wischknöpfe untereinander (bar / Terminal) – Verwechslungsgefahr; Betrag groß, aber ohne Zusammenfassung der Fahrt. |
| Umsatz | Modal mit Summe und Liste; keine Wochen-/Monatssicht. |
| Flotte/Team/Disposition | `OperationsScreen` 963 Zeilen, lange Scrollseiten, Aktionen in Modals und System-Alerts gemischt; Aktualisieren über Symbolknopf. |

## 3. Code-Qualität – Wesentliches

1. **Kein Navigationsverlauf** – `App.tsx:184,282`: Zurück verwirft immer alles bis „Start“ (z. B. Fahrtdetails → Live → zurück landet auf Start). Größtes Hindernis für „Apple-like“.
2. **Randwisch-Erkenner wird bei jedem Render neu erzeugt** und liegt auf dem ganzen Bildschirm (`App.tsx:282–296`); er konkurriert mit Karte, Sheets und Wischknöpfen (Konflikte auf dem Gerät nicht geprüft).
3. **„Online gehen“** (`DriverScreen.tsx:373–425`): `foregroundPermission()` (`:389`) und `startLocation()` (`:401`) laufen ohne Gesamtfrist; die Summe der Einzel­fristen in `location-service.ts:289–386` kann mehrere Minuten betragen, währenddessen ist der Knopf nur „busy“. Gewünscht: Gesamtfrist + sichtbare Schritte + Abbrechen.
4. **iOS: Fahrtalarm immer „aus“** – `offer-alerts.ts:32–34` verlangt einen Android-Kanal.
5. **Zieleingabe-Blockade** – `customer-booking.ts:114–128`: schlägt das Lesen des Gerätespeichers fehl, bleibt `restoring` wahr; der Ausweg „Ohne gespeicherte Anfrage fortfahren“ erscheint nur als Textlink (`CustomerBookingScreen.tsx:236–252`).
6. **Fest verdrahtete Live-Adresse** (siehe 1) – keine Test-/Staging-Umschaltung; jede Geräteprüfung trifft Live-Daten.
7. **Sehr große Dateien**: `App.tsx` 1256 (Navigation + Start + Menü + Anmeldung + Stile), `DriverScreen.tsx` 1133 (Karte, Schicht, Angebot, Fahrt, Kassieren, Umsatz, Fahrzeugwahl, Navigationseinstellungen), `OperationsScreen.tsx` 963, `CustomerBookingScreen.tsx` 758. Müssen vor dem Redesign zerlegt werden.
8. **Doppelte Oberflächen-Logik** Web ↔ nativ (Sheet-Rastpunkte, Wischknopf-Schwelle: Web 95 %, nativ 88 % – `swipe-confirmation.ts` vs. `SwipeAction.tsx:57`); die reinen Regeln aus `app/mobility/sheet-motion.ts`, `swipe-confirmation.ts` lassen sich nativ mitbenutzen.
9. **Wischknopf nativ ohne Alternative für Screenreader/Schalter** (`SwipeAction.tsx:79–82`: nur Label, keine `accessibilityActions`); Web hat sie.
10. **Kleinigkeiten**: veraltete Ersatz-Versionsnummer `App.tsx:569`; zwei Wischknöpfe teilen sich einen `busy`-Zustand beim Kassieren (`DriverScreen.tsx:649–667`); doppelte Ordner `mobile/android 2`, `mobile/android 4`, `pnpm-lock 2.yaml` (Altlasten, nicht geprüft ob benutzt); nur 1 Testordner unter `mobile/tests`.

## 4. Neudesign-Konzept

### 4.1 Designsprache
- **Schrift**: Systemschrift (San Francisco auf iOS, Roboto auf Android) für alles Bedienbare; Georgia/Serif nur für die Wortmarke. Feste Skala (Größe/Zeilenhöhe/Gewicht): Großer Titel 34/41/700 · Titel 1 28/34/700 · Titel 2 22/28/600 · Überschrift 17/22/600 · Text 17/24/400 · Nebentext 15/20/400 · Fußnote 13/18/400 · Etikett 11/13/600 Großbuchstaben mit Sperrung. Beträge mit Tabellenziffern. Schriftvergrößerung des Systems zulassen (bis 1,3-fach getestet).
- **Farben**: unverändert Tinte #151719, Papier #f9f8f5, Gold #b99a60 (Schmuck), Goldtext #7a5f30, Linien/Grau aus `theme.ts`. Gold bleibt Akzent: genau eine goldene Hauptaktion pro Screen. Statusfarben nur in Chips. Dunkelmodus als zweite Palette (Tinte als Grund, Papier als Text, Gold hell) – Vorschlag.
- **Flächen**: Grund Papier; Karten weiß mit 1-px-Linie statt harter Schatten; schwebende Elemente (Sheet, Tab-Leiste, Kopfzeile über Karte) mit Unschärfe-Material (iOS Blur; Android halbtransparentes Papier 92 % als gleichwertiger Ersatz) und weichem Schatten (y 8, Radius 24, 8 % Tinte).
- **Radien**: 4 Werte – 8 (Chips/Felder klein), 14 (Knöpfe/Felder), 20 (Karten), 28 (Sheets oben), Pille für Wischknopf. `theme.ts` um `xl` ergänzen und überall nutzen.
- **Abstände**: 4er-Raster aus `theme.ts`; Seitenrand 20, Kartenabstand 12, Abschnittsabstand 32; Tipp-Ziele ≥ 48.
- **Symbole**: eine Familie – Lucide bleibt (bereits installiert), einheitlich 24 px, Strich 1,75; keine Apple-Symbole (SF Symbols sind Apple-lizenziert).
- **Bewegung**: Federn statt fester Dauer – Standard (Dämpfung 20, Steifigkeit 220, kein Nachschwingen), Sheet (Dämpfung 28, Steifigkeit 300), Betonung/Erfolg (Dämpfung 14, Steifigkeit 180, leichtes Nachschwingen). Ein-/Ausblenden 180 ms, Bildschirmwechsel 320 ms. „Bewegung reduzieren“ des Systems: nur Überblenden.
- **Haptik**: leicht = Auswahl/Rastpunkt erreicht; mittel = Wischknopf rastet am Ende ein; Erfolg = Server bestätigt (Buchung, Annahme, Kassiert); Warnung = Angebot läuft ab (letzte 5 s einmal); Fehler = Aktion abgelehnt. Nie für reines Scrollen.

### 4.2 Navigationsmodell
- **Kunde: Karte zuerst.** Ein Hauptbildschirm = Karte + Bottom-Sheet mit drei Rastpunkten (klein ≈ 96 pt, mittel ≈ 45 %, groß ≈ 92 %). Buchung läuft als Schritte im Sheet (Wohin → Klasse → Bestätigen → Live). Darunter Tab-Leiste mit 3 Tabs: **Fahrt · Fahrten · Konto** (Menü und Konto zusammengelegt). Während einer aktiven Fahrt bleibt die Tab-Leiste sichtbar.
- **Fahrer: Karte zuerst.** Karte + Sheet (dieselben drei Rastpunkte), oben schwebend Tagesumsatz-Chip und Online-Schalter. Tab-Leiste: **Fahren · Umsatz · Flotte · Konto** (Flotte nur mit Rolle).
- **Stapel-Navigation je Tab** mit echtem Verlauf: Zurück per Randwischen (iOS-Systemgeste, Android vorausschauende Zurück-Geste/Taste), große Titel, die beim Scrollen in die Kopfzeile schrumpfen.
- **Sheets statt Dialoge**: Details, Auswahl, Formulare als modale Sheets (ziehbar, mit Griff, Schließen durch Herunterziehen – außer während einer laufenden Aktion). System-Alert nur für endgültig zerstörende Rückfragen.

### 4.3 Gesten-Katalog
| Geste | Wofür | Alternative (Barrierefreiheit) |
| --- | --- | --- |
| Sheet ziehen (3 Rastpunkte) | Mehr Karte / mehr Details | Griff antippen wechselt Rastpunkt; Screenreader-Aktion „Vergrößern/Verkleinern“ |
| Wischen zum Bestätigen (bleibt) | Fahrt anfragen, annehmen, Status, Kassieren, Stornieren, Übergabe | Screenreader-Aktion „Bestätigen“ + Doppeltipp-und-Halten 1 s; Schwelle einheitlich 90 % |
| Randwischen | Eine Ebene zurück | Zurück-Knopf oben links, Android-Taste |
| Herunterziehen in Listen | Fahrten, Umsatz, Disposition, Flotte aktualisieren | automatische Aktualisierung bleibt; Knopf im Menü |
| Zeile seitlich wischen | Fahrten: „Stornieren“ öffnet Bestätigungs-Sheet (nicht direkt ausführen); Flotte: Fahrzeug archivieren | dieselben Punkte im Long-Press-Menü und im Detail |
| Long-Press | Kontextmenü: Adresse als Favorit, Fahrt teilen, Ziel erneut buchen | „Mehr“-Knopf (…) an der Zeile |
| Antippen der Karte | Sheet auf klein | – |
| Zwei Finger / Zoomen | nur Karte | Plus/Minus-Knöpfe (Vorschlag) |

Regel gegen Konflikte: Wischknopf und Karte nehmen Gesten exklusiv; Randwischen ist auf Screens mit Karte auf die äußeren 20 pt begrenzt.

### 4.4 Moderne Funktionen (alles **Vorschläge**, nichts davon existiert heute)
| Vorschlag | Aufwand | Backend nötig? |
| --- | --- | --- |
| Zuletzt genutzte Ziele (nur auf dem Gerät gespeichert) | klein | nein |
| Gespeicherte Orte „Zuhause/Arbeit/Favoriten“ | mittel | nein (Gerät) / ja, wenn geräteübergreifend |
| Echter Datum-/Uhrzeit-Wähler für Reservierungen | klein | nein |
| Ankunftszeit in Minuten im Live-Sheet | mittel | nicht geprüft (ob der Server eine Zeit liefert) |
| Fahrt teilen (Link mit Status) | mittel–groß | ja (öffentlicher, ablaufender Link) |
| Biometrie-Sperre (Face ID/Fingerabdruck) beim Öffnen | klein | nein |
| Dunkelmodus | mittel | nein |
| Push bei Statuswechsel (Kunde) und Angebot (Fahrer) | groß | ja (Firebase/APNs, steht schon in der Problemliste) |
| Live-Aktivität (iOS-Sperrbildschirm) / laufende Benachrichtigung (Android) mit Fahrtstatus | groß | ja (Push) + nativer iOS-Zusatz |
| Startbildschirm-Widget „Nächste Fahrt“ | groß | nein, aber nativer Zusatz je Plattform |
| Haptik + Ton beim Angebot, Vollbild-Angebot | klein | nein |
| Englisch/Deutsch-Umschaltung | mittel | nein |

### 4.5 Zielbilder (von oben nach unten)
1. **Kunde · Start/Wohin**: Karte vollflächig mit eigenem Standort. Oben links Kontokreis, oben rechts Standortknopf. Sheet mittel: großer Titel „Wohin?“, Suchfeld (Tippen → Sheet groß, Tastatur auf, Autofokus), Umschalter Jetzt/Später, darunter „Zuletzt“ und Favoriten als Zeilen. Zustände: ohne Standortfreigabe ruhiger Hinweis mit Knopf; offline Banner oben; offene Anfrage → Karte „Offene Anfrage prüfen“ mit zwei klaren Knöpfen (Erneut bestätigen / Verwerfen) statt Blockade.
2. **Kunde · Adresse/Kartenpunkt**: Sheet groß mit zwei Feldern (Abholort, Ziel) übereinander, Ergebnisliste darunter, erste Zeile „Auf Karte wählen“, zweite „Mein Standort“. Kartenwahl: Sheet klein, fester Pin in der Mitte, Adresse live im Sheet, Hauptknopf „Übernehmen“. Laden: 3 Skeleton-Zeilen; leer: „Keine Treffer – Punkt auf Karte wählen“.
3. **Kunde · Klassenwahl**: Karte zeigt Route; Sheet mittel mit Strecke/Dauer als Chip, drei Klassenzeilen (Bild, Name, Plätze, Preis rechts), gewählte Zeile mit Goldrand. Hauptknopf „Weiter mit Business · 28,78 €“ fest am Sheet-Fuß. Preis lädt → Skeleton im Preisfeld; Fehler → Zeile „Preis nicht verfügbar · Erneut“.
4. **Kunde · Bestätigen (Checkout)**: Sheet groß, Abschnitte als Zeilen mit Pfeil (Abholzeit, Fahrgast, Komfortwünsche, Bordkarte) – jede öffnet ein eigenes kleines Sheet; Summe und Hinweis „Zahlung beim Fahrer“; am Fuß fest der Wischknopf „Fahrt anfragen“. Nach Erfolg: Haptik + Übergang in Live.
5. **Kunde · Live-Fahrt**: Karte mit Route und Fahrzeug. Sheet klein: Status + Minuten; mittel: Fortschrittsleiste (Angefragt → Zugesagt → Angekommen → Unterwegs → Angekommen), Chauffeur-Karte mit Anruf-Knopf, Fahrzeug/Kennzeichen groß; groß: Adressen, Preis, Bordkarte, „Fahrt stornieren“ (öffnet Sheet mit Wischknopf), Sicherheit (112). Verbindung weg: Banner „Stand von 14:32“, Daten bleiben.
6. **Kunde · Fahrten**: großer Titel „Fahrten“, Segmente Anstehend/Vergangen, Kartenzeilen mit Status-Chip; Herunterziehen aktualisiert; Tippen → Detail-Sheet; Leerzustand mit Bild und Knopf „Fahrt planen“.
7. **Anmeldung**: drei kurze Seiten statt eines Formulars – E-Mail → (nur neu) Name/Telefon/Datenschutz → Code. Code als 6 Kästchen mit automatischem Einfügen; darunter „Neuen Code in 0:47“ als deaktivierter Knopf mit Zähler; unklarer Versand: „Code kann schon unterwegs sein – bitte Postfach prüfen“ und Eingabe erlauben, sobald technisch möglich (hängt an der parallel laufenden Fehlerbehebung).
8. **Fahrer · Standby**: Karte; oben Umsatz-Chip „Heute 184 €“ und Statuschip (Offline/Online/GPS sucht). Sheet mittel: Fahrzeugzeile, großer Online-Knopf. Beim Online-Gehen eine sichtbare Schrittliste mit Haken (Standort ✓ → Anmeldung ✓ → Hintergrunddienst … → Fertig), Gesamtfrist, „Abbrechen“. Fehler nennen den Schritt und bieten „Erneut“/„Einstellungen öffnen“.
9. **Fahrer · Angebot**: Sheet fährt automatisch auf groß, Ring-Countdown um den Preis, Abholort/Ziel mit Entfernung, Wünsche als Chips; am Fuß Wischknopf „Fahrt annehmen“, darüber Sekundärknopf „Ablehnen“. Haptik + Ton beim Erscheinen. Abgelaufen: Sheet schließt mit Hinweis-Toast.
10. **Fahrer · Fahrt und Kassieren**: Sheet klein zeigt nächste Abbiegung/Ziel; mittel: Fahrgast, Anrufen, „Navigation öffnen“, Bordbestellungen als einklappbare Zeile mit Zähler; am Fuß immer **ein** Wischknopf für den nächsten Status. Kassieren: großer Betrag, Fahrtzusammenfassung, Auswahl Bar/Terminal als Segment, dann **ein** Wischknopf „Zahlung bestätigen“. Danach Erfolgsbild und zurück zu Standby.
(Flotte/Team/Disposition: gleiche Bausteine – Listen mit großem Titel, Detail-Sheets, Wischknopf für Freigaben; eigene Etappe.)

### 4.6 Komponenten-Bibliothek (zuerst bauen, unter `mobile/src/ui/`)
`Screen` (großer Titel, Zurück, sicherer Bereich) · `Sheet` (3 Rastpunkte, Griff, Blur) · `ModalSheet` · `Button` (primär/sekundär/Text/zerstörend, Ladezustand) · `SwipeToConfirm` (Nachfolger von `SwipeAction`, mit Haptik und Screenreader-Aktion) · `ListRow` (Symbol, Titel, Detail, Wert, Pfeil) · `TextField` + `CodeField` · `SegmentedControl` · `StatusChip` · `Banner`/`Toast` (offline, Fehler, Erfolg) · `Skeleton` · `EmptyState` · `TabBar` · `Countdown` (Ring) · `Stepper` (Menge) · `ProgressSteps` · Typografie-Bausteine (`Title`, `Body`, `Caption`). Tokens: `theme.ts` um Schrift-Skala, Schatten, Federn, Haptik-Namen erweitern.

## 5. Umsetzungsplan in Etappen

Für alle Etappen gilt: Preis-, Buchungs-, Zahlungs- und Rechte-Logik (`lib/`, `app/api/`, Controller-Klassen) bleibt unverändert; nur Darstellung und Bedienung. Jede Etappe endet mit `tsc`, Tests, neuem APK-Paar und Durchspielen auf dem Handy. Neue native Pakete = neuer APK-Bau zwingend (kein Nachladen möglich); iOS-Bau erst mit Apple-Entwicklerkonto.

| Etappe | Inhalt | Dateien | Neue Pakete | Risiko | Prüfung |
| --- | --- | --- | --- | --- | --- |
| 0 Fundament | Tokens erweitern, `ui/`-Bibliothek, kleine Musterseite in der App (nur im Testbau) | `theme.ts`, neu `ui/*` | `react-native-reanimated`, `react-native-gesture-handler`, `expo-haptics`, `expo-blur` (Versionen per `expo install` passend zu SDK 57 – nicht geprüft) | Bau bricht durch native Pakete; Mapbox + Gesten-Bibliothek zusammen | Musterseite auf dem Handy: Sheet, Wischknopf, Haptik |
| 1 Navigation | `App.tsx` zerlegen (Start, Menü, Anmeldung in eigene Dateien), Stapel + Tabs, echtes Zurück | `App.tsx`, neu `navigation/*`, `screens/*` | Navigations-Bibliothek (Entscheidung A/B unten) | Zustände, die heute durch `display:none` erhalten bleiben (laufende Abfragen, Fahrer-GPS) | Jeder Weg hin und zurück; Android-Taste; Benachrichtigung öffnet Angebot |
| 2 Anmeldung | 3-Seiten-Ablauf, Code-Kästchen, Zähler | `AccountPanel` → eigene Datei | – | Abhängig von paralleler Fehlerbehebung | Registrieren/Anmelden mit echtem Code |
| 3 Kunde Buchung | Karte-zuerst, Sheet-Schritte, Datumswähler, zuletzt genutzte Ziele | `CustomerBookingScreen`, `NativeAddressPicker`, `NativeMapPointPicker` | Datumswähler-Paket | Kartenkosten (mehr Kartenaufrufe – Budgetregel beachten); Tastatur + Sheet | Buchung Jetzt und Später bis „angefragt“ |
| 4 Kunde Live + Fahrten | Sheet mit Rastpunkten, Fortschritt, Pull-to-Refresh, Storno-Sheet | `CustomerLiveScreen`, `CustomerTripsScreen`, `CustomerBoardScreen` | – | Gestenkonflikt Karte/Sheet | Testfahrt aus Kundensicht |
| 5 Fahrer Kern | `DriverScreen` zerlegen: Standby, Online-Schritte, Angebot, Fahrt, Kassieren, Umsatz | `DriverScreen` → 6 Dateien | – | Höchstes Risiko (Schicht/GPS/Alarm dürfen sich nicht ändern) | Komplette Probefahrt Fahrer + Kunde, gesperrter Bildschirm |
| 6 Flotte/Disposition/Bestand | Listen, Detail-Sheets, einheitliche Dialoge | `OperationsScreen`, `FleetScreen`, `StockScreen`, Dialoge | – | Viele Rollen/Rechte-Ansichten | Mit Besitzer- und Fahrerkonto |
| 7 Feinschliff | Dunkelmodus, Leer-/Fehlerzustände, Schriftvergrößerung, Screenreader, Englisch-Vorbereitung | alle | – | Kontraste | Prüfliste je Screen |
| 8 iOS | Android-Texte neutralisieren, Fahrtalarm für iOS, Apple Karten zulassen, iOS-Bauprofile, Test auf iPhone | `offer-alerts.ts`, `DriverScreen`, `eas.json`, `app.config.ts` | – | Apple-Prüfung Hintergrundstandort | TestFlight auf echtem iPhone |
| 9 Web-App angleichen | dieselben Rastpunkte, Abstände, Texte in `app/mobility/*` | `workspace.tsx`, `driver.tsx`, `app-design.css` | – | groß (zweite Oberfläche) | Browser 375 px |

Reihenfolge-Empfehlung: 0 → 1 → 3 → 4 → 5 → 2 → 6 → 7 → 8 → 9. Etappen 0–1 sind Voraussetzung für alles.

### Entscheidungen für den Inhaber (einfach)
1. **A oder B – Kunden-Start:** A) Karte mit Suchfeld sofort beim Öffnen (wie große Fahrdienste), oder B) wie heute erst eine Begrüßungsseite mit Bild? *(Empfehlung A)*
2. **Ja/Nein – Dunkelmodus:** Soll es zusätzlich eine dunkle Ansicht geben (mehr Aufwand in jeder Etappe)?
3. **Ja/Nein – neue Bausteine einbauen:** Dürfen vier bis sechs neue technische Pakete für flüssige Gesten, Vibration und Unschärfe aufgenommen werden? Folge: Apps müssen neu gebaut und neu installiert werden. *(ohne sie ist „Apple-like“ nicht erreichbar)*
4. **A oder B – Reihenfolge:** A) erst die Kunden-App fertig, dann Fahrer; oder B) erst die Fahrer-App? *(Empfehlung A – weniger Risiko für den Schichtbetrieb)*
5. **Ja/Nein – iPhone jetzt vorbereiten:** Soll schon ein Apple-Entwicklerkonto (99 $/Jahr, laut Apple) beantragt werden, damit die iPhone-Fassung am Ende getestet werden kann?

Offen/nicht geprüft: Verhalten auf echten Geräten, Mapbox unter iOS, Verträglichkeit der neuen Pakete mit SDK 57/RN 0.86, ob der Server eine Ankunftszeit liefert, Flotten-/Bestands-Screens nur überflogen.
