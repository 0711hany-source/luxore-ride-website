# Native Ortung bei Alarm-API-Fehlern · Fahrer 0.8.1 / Build 35

## Nachgewiesener Fehler und Korrektur

locationStatus las den nativen Benachrichtigungsstatus ohne Fehlertrennung. Wenn Android/Expo beim Anlegen des Alarmkanals, Lesen der Benachrichtigungsberechtigung oder Lesen des Kanals einen Fehler lieferte, schlug die gesamte GPS-Statusabfrage fehl. resumeLocation konnte den nativen Dienst erfolgreich wiederherstellen und anschließend trotzdem ohne Status enden. startLocation wartete außerdem vor der eigentlichen Ortung auf requestAlerts; dessen Fehler brach einen sonst gültigen Standortstart ab. Der Fahrerablauf konnte deshalb den bestätigten Online-Start wieder zurücknehmen, obwohl keine Standortberechtigung fehlte. Abgelehnte Benachrichtigungsberechtigungen waren schon vorher kein Ortungsverbot.

Nur die Benachrichtigungs-Statusabfrage wird jetzt abgefangen: enabled:false, sound:false, unavailable:true. Keine erfundene Alarm-/Tonverfügbarkeit; GPS-active, sessionId, Ablauf und gültiger Positionscache stammen weiterhin aus der tatsächlichen Freigabe, Standortberechtigung und dem tatsächlichen Dienststatus. Fehler der optionalen requestAlerts-Abfrage verhindern den Standortstart nicht. Danach gelten dieselben echten Standortfehler, Berechtigungen, Lifecycle-/Speicherguards und Rollbackregeln. Der eigene Testalarm bleibt unverändert ausdrücklich fehlschlagend, wenn die Benachrichtigungs-API nicht funktioniert. Keine Änderung an Alarmplanung, Wischbestätigungen, Qualitätsfiltern, Upload, Rohkoordinaten, Rechten, API oder Datenbankschema.

## Tatsächliche Verhaltenstests

Neun neue Tests führen den tatsächlichen location-service und das tatsächliche offer-alerts-Modul aus, mit isolierten Expo-Location-/Notifications-/TaskManager-/SecureStore-Adaptern und abgefangenem fetch. Sieben scheitern im bisherigen Standortdienst, alle bestehen korrigiert:

- Je ein Fehler beim Kanal-Anlegen, Berechtigungslesen und Kanallesen erhält aktiven GPS-Status und kennzeichnet den Alarmstatus als unbekannt/nicht verfügbar.
- Wiederaufnahme startet den vorher beendeten nativen Dienst und erhält frischen eigenen Positionscache trotz Alarm-API-Fehler; keine neue Berechtigungsanfrage.
- Fehler beim ausdrücklichen nativen Alarmberechtigungsdialog blockiert gültigen GPS-Start nicht; keine automatische Alarmplanung.
- Pause löscht Capability/Cache, beendet GPS und meldet stop mit ursprünglichem Token trotz fehlgeschlagener Alarmbereinigung (bestehender Kontrollfall).
- Fehlende Hintergrundstandortberechtigung bleibt bei Wiederaufnahme gesperrt, auch mit Alarmfehler.
- Echte GPS-Startfehler bleiben Fehler und rollen Credentials mit Server-Stopp zurück, auch bei Alarmfehler.
- Ausdrücklicher Testalarm meldet Alarm-API-Fehler und plant nichts (bestehender Kontrollfall).

Die Tests erzeugen keine echte Production-Schicht, Position, Alarme, Fahrten oder Rechteänderung. Reale angemeldete Unternehmensgeräte-, Ton-, Hersteller-, Straßen- und Hintergrund-GPS-Prüfungen bleiben offen. Diese Korrektur fängt zurückgewiesene Aufrufe ab; hängende native Promises werden dadurch nicht zeitlich begrenzt. Kein Versprechen zu OS-Zustellzeit oder rückwirkendem Verhindern bereits begonnener Töne.

Kunde bleibt 0.6.9 / Build 23. Fahrer benötigt neue APK 0.8.1 / Build 35. Interner geschützter GitHub-Entwurf, keine öffentliche Binary-/Store-Freigabe; Website-Update installiert keine App auf Nutzerhandys. 564 Tests, beide TypeScript-Prüfungen, gezieltes Lint/Format und diff-Prüfung bestanden. Gradle-Build außerhalb synchronisierter Quellen in 4m 21s; unveränderte 21 direkte Paketversionen einschließlich Entwicklungsabhängigkeiten und Lockfile, 85 Runtime-/Asset-/Konfigurationsdateien im vollständigen Importbaum bytegenau abgeglichen. Bestehendes Signaturzertifikat SHA-256 fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c, unveränderte Manifest-Berechtigungen und Variantenprüfung bestanden.

APK 56217992 Bytes, SHA-256 0523214dc37e6f92d1bd5241f47c0a18cb154ebfc30b95f036ee69b64d67e410. Update über 0.8.0 ohne Deinstallation im isolierten Emulator und drei anonyme Kaltstarts ohne Absturz bestanden. Dies ist kein angemeldeter physischer GPS-/Ton-/Schichtnachweis. Emulator anschließend beendet. Exakter Archivbuild bestanden: 7,9 Sekunden Kompilierung, 4,8 Sekunden TypeScript. 

## Veröffentlichung

Runtime bb457dd70cf2fb44afb98fa6b223ccb97ca822b6, GitHub 946170ed351909871f17eb85cdc6753ee84a4992. Alle drei öffentlichen Paketdateien bytegenau; Archiv 523 Dateien, 7934485 Bytes, SHA-256 b292ca2dfa89bcc0b3e9d3052951cc60a524e30ca5552bd846a81a28a0f04cc0. Vercel 2WP6oSjgzaY3znGoMrKtwBi3sFmC Ready/Latest/Current Production luxoreride.de, exakter GitHub-Commit und success-Status bestätigt. Fünf reine health/account/Kunden-/Fahrer-/Dispositions-GETs liefern HTTP 200, Datenbank/Konten/Buchung bereit.

Prüfungen liegen lokal unter work/native-notification-recovery-081, sichtbarer Nachweis unter outputs/native-notification-recovery-081/vercel-ready.png. Nachträgliche Veröffentlichungsevidenz verändert den geprüften Runtime-/Archivstand nicht.


Geschützter APK-Entwurf https://github.com/0711hany-source/luxore-ride-website/releases/tag/untagged-f1c226ea0a2f5611dc3f bestätigt: Draft mit genau einem Anhang Luxore-Driver-Test-0.8.1.apk, angezeigter SHA-256 stimmt mit lokaler Datei überein. Nachweis outputs/native-notification-recovery-081/apk-draft.png. Keine öffentliche Release-/Store-Veröffentlichung. Nächster unabhängiger Schritt: konkurrierende native Stopp-/Neustart-/Wiederaufnahmeaufrufe bei verzögerten Dienstantworten auf einen tatsächlich reproduzierten Fehler prüfen; bestehende Alarmfehler-Trennung nicht erneut implementieren.
