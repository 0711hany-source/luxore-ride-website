# Adresssuche und kostenlose Alternative

7. Oktober 2026: Beim Tippen erscheinen Vorschläge nach 600 ms Pause ab drei Zeichen. Neue Eingaben brechen alte Clientanfragen ab; verspätete Ergebnisse verändern keine aktuelle Auswahl. Suche per Enter/Schaltfläche bleibt möglich. Mapbox-Vorschläge verwenden Autocomplete; ihre temporären Daten werden nicht gespeichert.

Die gemeldete Fehlermeldung entsteht bei der Bestätigung neuer Textadressen, weil `MAPBOX_PERMANENT_DAILY_LIMIT=0` kostenpflichtige permanente Mapbox-Abfragen verhindert. Diesen Schutz nicht ohne konkretes Kostenbudget entfernen. Karten-/Gerätekoordinaten und bereits gespeicherte Adressen funktionieren weiterhin. Live-Speicherung neuer Textadressen ist ohne konfigurierten alternativen Anbieter weiterhin gesperrt.

## Geoapify-Free-Anbindung · am 9. Oktober aktiviert

Der Server verwendet Geoapify erst mit `GEOAPIFY_API_KEY` im geschützten Produktionsenvironment. Kein API-Schlüssel im Browser, keine kostenpflichtige Ausweichabfrage bei Störungen. Ein separates Projekt und einen ausschließlich hier verwendeten Free-Schlüssel einrichten. Am 9. Oktober hat der Nutzer sein bereits angemeldetes Geoapify-Konto zur Einrichtung bereitgestellt. Das eigene Luxóre-Projekt ist im Free-Tarif angelegt und sein Schlüssel als geschütztes Production-Secret gespeichert. Keine neuen Vertragsbedingungen durch den Agenten akzeptiert, kein kostenpflichtiger Tarif gewählt.

Geoapify Free bietet laut Anbieter 3.000 Credits täglich, kommerzielle Nutzung mit vorgeschriebener Attribution, keine Kreditkarte. Die App begrenzt eigene externe Abfragen auf 2.500 pro UTC-Tag und vier pro Sekunde. Weitere Nutzung desselben Providerkontos ist außerhalb dieses Zählers und muss im Providerkonto geprüft werden. Die vorhandene globale Vorschlagsgrenze von 2.000 täglich bleibt bestehen. Es gibt kein kostenlos unbegrenztes Kontingent.

Vorschläge werden aus dem Autocomplete-Endpunkt gelesen. Eine serverseitig validierte Auswahl muss innerhalb von 25 m eines Ergebnisses liegen; beliebige Clientkoordinaten werden nicht als bestätigte Textadresse gespeichert. Lizenzierte Ergebnisse dürfen fünf Minuten wiederverwendet werden, Anfragen teilen eine Cache-Lease. Mapbox und Geoapify verwenden getrennte Cache-Schlüssel. Geoapify-Herkunftsangaben bleiben mit Ort und Fahrtroute erhalten; bestehende Orte bleiben unverändert (`attribution` ist nullable). UI zeigt Geoapify/OpenStreetMap-Attribution.

Prüfung: `tests/geocoding-cost.test.mjs` deckt temporäre Daten, dauerhaftes Mapbox-Budget, kostenlose Auswahl/Angebot, Cache, Herkunftsangaben, Quoten und Ausfälle ohne kostenpflichtigen Fallback ab. Reale Providerprüfung erst nach Einrichtung. Keine Providerantworten als produktionsgeprüft ausgeben, wenn nur Testfixtures verwendet wurden.

Quellen: https://www.geoapify.com/pricing/ · https://www.geoapify.com/geocoding-api/ · https://www.geoapify.com/terms-and-conditions/ · https://apidocs.geoapify.com/docs/geocoding/address-autocomplete/ · https://docs.mapbox.com/api/search/geocoding/

Lokale Browserprüfung bei 390 × 844 bestanden: Vorschläge öffnen ohne Suchknopf; Abholung und Ziel aus eigenen Testfixtures bestätigt; Route und alle drei Kilometerpreise angezeigt. Bei langsamer älterer Anfrage bleiben neue Eingabe und deren Treffer erhalten. Kein echtes Providerkonto und keine Live-Fahrt verwendet. Die Anbieterentscheidung ist weiter offen.

Live-Nachweis nach Veröffentlichung: Am 7. Oktober 2026 öffnet die Kundenansicht auf luxoreride.de beim Tippen von „Opernplatz Frankfurt“ automatisch echte Mapbox-Treffer. Keine Auswahl oder Buchung dabei ausgelöst. Herkunftsspalte ist in Turso Production vorhanden; Migration 0018 und Dateihash geprüft. Die kostenlose alternative Adressbestätigung bleibt bis Anbieterwahl/Konto/Schlüssel offen.


8. Oktober 2026: Die Trefferliste wird jetzt direkt unter dem Eingabefeld gerendert, ohne losgelösten Portal-Popup. ARIA-Combobox mit Pfeiltasten/Enter/Escape, eindeutigen Feld-IDs, sichtbaren Optionen und serverseitig bestätigter Auswahl. Während der Bestätigung keine doppelte Auswahl; gescheiterte Bestätigung setzt keinen Ort und zeigt keine widersprüchliche Treffer-Statusmeldung. Neue Eingabe entfernt den alten Fehler. Bei konfiguriertem Geoapify werden auch GPS/Kartenpunkte trotz Mapbox-Permanent-Budget 0 über den kostenlosen Anbieter aufgelöst. Ohne Anbieter bleiben die bisherigen kostenlosen neutralen GPS-/Kartenpunkte erhalten.

Lokaler Produktionsbuild-Browser bei 390×844 mit isolierter Datenbank und Providerfixture bestätigt automatische Vorschläge, Abholung und Ziel, 21 km / 25 min und Preise 52,50 € / 73,50 € / 63,00 €. Das ist kein Live-Anbieter-Nachweis. Neue konkrete Geoapify-Vertrags-/E-Mail-Freigabe wurde angefragt; keine Nutzungsbedingungen akzeptiert, kein Schlüssel erstellt und kein kostenpflichtiges Mapbox-Budget eingeschaltet.


## 9. Oktober · Mapbox mit kostenfreier Geoapify-Ersatzsuche

Der Nutzer hat einen neuen öffentlichen Mapbox-Token geliefert und Geoapify ausdrücklich als Fallback gewünscht. MAPBOX_ACCESS_TOKEN und MAPBOX_PUBLIC_TOKEN in Production verwenden den neuen Token; kein Token im Repository gespeichert. Mapbox bleibt zuständig für Karte, Verkehr und Straßenrouten. GEOAPIFY_API_KEY liegt nur als geschütztes Production-Secret vor; der Schlüssel wird nicht im Browser oder in APKs ausgeliefert. Das dedizierte Geoapify-Projekt zeigt Free / 3.000 Credits täglich / 0 USD monatlich. Keine Zahlungsdaten oder Tarifwechsel eingerichtet. Eigene Grenzen bleiben 2.500 externe Geoapify-Abfragen pro UTC-Tag, vier pro Sekunde und 2.000 Vorschlagssuchen täglich.

Der gemeinsame Serveradapter verwendet Mapbox zuerst, wenn ein ausdrücklich positives permanentes Adressbudget vorliegt. Bei fehlendem Dienst, Anbieterfehlern einschließlich ungültigem JSON, leeren Treffern oder ausgeschöpftem Budget übernimmt ausschließlich der konfigurierte kostenlose Geoapify-Dienst. Validierungsfehler und laufende Cache-Leases wechseln den Anbieter nicht. Beide Dienste ausgefallen: ehrlicher Fehler und keine gespeicherte Adresse; keine kostenpflichtige Ausweichabfrage.

Production behält MAPBOX_PERMANENT_DAILY_LIMIT=0. Deshalb ist Mapbox für neue dauerhaft bestätigte Textadressen nicht verfügbar und die Ersatzsuche übernimmt bereits Vorschläge und Auswahl. Damit stammen Vorschlagskoordinaten und lizenzierte Bestätigung aus demselben Dienst. Temporäre Mapbox-Daten werden nicht als eigene Daueradressen gespeichert; die bestehende 25-m-Auswahlprüfung und Herkunftsangaben bleiben erhalten. Dies ist kein unbegrenztes Gratis-Kontingent.

298 Tests bestanden, darunter fünf neue Integrationstests für Mapbox-Vorrang bei ausdrücklich freigegebenem Testbudget, Auth-/Rate-/Netz-/Formatfehler, leere Treffer, verbrauchtes Budget, konkurrierende Bestätigung und Ausfall beider Dienste. Web-TypeScript und gezieltes Lint bestanden. Keine Migration, Änderung von Fahrer-/Flottenrechten oder neue APK notwendig; der Server stellt die Suche für vorhandene Web-/App-Versionen bereit. Vorherige Abschnitte dokumentieren den historischen Zustand; die frühere Geoapify-Zustimmungssperre ist jetzt durch die bereitgestellte Anmeldung und Einrichtung überholt.

### Tatsächliche Veröffentlichung und Live-Prüfung

Quellstand `5d763c2`; das geprüfte Archiv enthält 426 Dateien, 7.632.520 Bytes und SHA-256 `5d5627922612706f1c3221c729e5948ad9700bca68d64e71217bd492c2e63cf3`. GitHub-Commit `6dcb5289a4f327b069ec682680bb98951c248093` enthält die drei Upload-Dateien bytegleich. Vercel `4PVQUuXLQfGkeTBsmjXKLRSRVhdR` ist Ready / Latest / Current Production unter luxoreride.de. Produktionsbuild aus dem tatsächlichen Archiv, Web- und Mobile-TypeScript sowie 298 Tests bestanden.

Live im normalen Kundenbrowser: „Opernplatz 1, Frankfurt am Main“ liefert automatisch vier echte Geoapify-Vorschläge. „Frankfurt Flughafen Terminal 1“ liefert fünf Vorschläge. Alte Oper und Flughafen Terminal 1 sind ohne Sperrmeldung bestätigt, der Routenknopf ist bedienbar. Nach Neuladen mit aktueller Konfiguration: Mapbox-Karte mit Route und beiden Markierungen sichtbar, ca. 21 Minuten / gerundet 21 km; Business 52,61 €, First Class 73,65 €, Van 63,13 €. Die Preisberechnung verwendet die ungerundete Routendistanz. Keine Fahrt gebucht und kein Fahrer alarmiert. Screenshot: outputs/geoapify-activation/live-route-prices.png. Dies ist eine Desktop-Browserprüfung, keine neue physische Handy-/GPS-Prüfung.

Eine normale anonyme Test-Gerätesitzung bestätigt den Hash des neuen öffentlichen Mapbox-Tokens und mapsReady=true; der private Geoapify-Schlüssel wird nicht im Konfigurationsendpunkt zurückgegeben. Konten-/Datenbank-/Buchungsbereitschaft sowie Kunden-, Fahrer- und Dispositionsseiten liefern HTTP 200. Ein bereits vor dem Tokenwechsel geöffnetes Kartenfenster zeigte zunächst einen Verbindungsfehler; nach erneutem Laden ist die neue Karte tatsächlich sichtbar. Bestehende App-/Browserfenster daher einmal neu öffnen.

Die geplante Aktualisierung des bestehenden Fünf-Stunden-Automationsprompts wurde vom App-Werkzeug mit „requires approval, but approval policy is never“ abgelehnt. Keine Konfigurationsdatei als Umgehung geändert. Bei kommenden Durchläufen gilt der hier dokumentierte aktuelle Anbieterzustand: Geoapify ist eingerichtet und aktiv; keine erneute Konto-/Vertragszustimmung verlangen.
