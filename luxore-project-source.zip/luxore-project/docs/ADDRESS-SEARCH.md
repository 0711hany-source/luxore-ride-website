# Adresssuche und kostenlose Alternative

7. Oktober 2026: Beim Tippen erscheinen Vorschläge nach 600 ms Pause ab drei Zeichen. Neue Eingaben brechen alte Clientanfragen ab; verspätete Ergebnisse verändern keine aktuelle Auswahl. Suche per Enter/Schaltfläche bleibt möglich. Mapbox-Vorschläge verwenden Autocomplete; ihre temporären Daten werden nicht gespeichert.

Die gemeldete Fehlermeldung entsteht bei der Bestätigung neuer Textadressen, weil `MAPBOX_PERMANENT_DAILY_LIMIT=0` kostenpflichtige permanente Mapbox-Abfragen verhindert. Diesen Schutz nicht ohne konkretes Kostenbudget entfernen. Karten-/Gerätekoordinaten und bereits gespeicherte Adressen funktionieren weiterhin. Live-Speicherung neuer Textadressen ist ohne konfigurierten alternativen Anbieter weiterhin gesperrt.

## Vorbereitete Geoapify-Free-Anbindung

Der Server verwendet Geoapify erst mit `GEOAPIFY_API_KEY` im geschützten Produktionsenvironment. Kein API-Schlüssel im Browser, keine kostenpflichtige Ausweichabfrage bei Störungen. Ein separates Projekt und einen ausschließlich hier verwendeten Free-Schlüssel einrichten. Die Bestätigung für eine Anbieterwahl ist noch ausstehend; Vertragsannahme und tatsächliches Konto nicht als erledigt darstellen.

Geoapify Free bietet laut Anbieter 3.000 Credits täglich, kommerzielle Nutzung mit vorgeschriebener Attribution, keine Kreditkarte. Die App begrenzt eigene externe Abfragen auf 2.500 pro UTC-Tag und vier pro Sekunde. Weitere Nutzung desselben Providerkontos ist außerhalb dieses Zählers und muss im Providerkonto geprüft werden. Die vorhandene globale Vorschlagsgrenze von 2.000 täglich bleibt bestehen. Es gibt kein kostenlos unbegrenztes Kontingent.

Vorschläge werden aus dem Autocomplete-Endpunkt gelesen. Eine serverseitig validierte Auswahl muss innerhalb von 25 m eines Ergebnisses liegen; beliebige Clientkoordinaten werden nicht als bestätigte Textadresse gespeichert. Lizenzierte Ergebnisse dürfen fünf Minuten wiederverwendet werden, Anfragen teilen eine Cache-Lease. Mapbox und Geoapify verwenden getrennte Cache-Schlüssel. Geoapify-Herkunftsangaben bleiben mit Ort und Fahrtroute erhalten; bestehende Orte bleiben unverändert (`attribution` ist nullable). UI zeigt Geoapify/OpenStreetMap-Attribution.

Prüfung: `tests/geocoding-cost.test.mjs` deckt temporäre Daten, dauerhaftes Mapbox-Budget, kostenlose Auswahl/Angebot, Cache, Herkunftsangaben, Quoten und Ausfälle ohne kostenpflichtigen Fallback ab. Reale Providerprüfung erst nach Einrichtung. Keine Providerantworten als produktionsgeprüft ausgeben, wenn nur Testfixtures verwendet wurden.

Quellen: https://www.geoapify.com/pricing/ · https://www.geoapify.com/geocoding-api/ · https://www.geoapify.com/terms-and-conditions/ · https://apidocs.geoapify.com/docs/geocoding/address-autocomplete/ · https://docs.mapbox.com/api/search/geocoding/

Lokale Browserprüfung bei 390 × 844 bestanden: Vorschläge öffnen ohne Suchknopf; Abholung und Ziel aus eigenen Testfixtures bestätigt; Route und alle drei Kilometerpreise angezeigt. Bei langsamer älterer Anfrage bleiben neue Eingabe und deren Treffer erhalten. Kein echtes Providerkonto und keine Live-Fahrt verwendet. Die Anbieterentscheidung ist weiter offen.

Live-Nachweis nach Veröffentlichung: Am 7. Oktober 2026 öffnet die Kundenansicht auf luxoreride.de beim Tippen von „Opernplatz Frankfurt“ automatisch echte Mapbox-Treffer. Keine Auswahl oder Buchung dabei ausgelöst. Herkunftsspalte ist in Turso Production vorhanden; Migration 0018 und Dateihash geprüft. Die kostenlose alternative Adressbestätigung bleibt bis Anbieterwahl/Konto/Schlüssel offen.


8. Oktober 2026: Die Trefferliste wird jetzt direkt unter dem Eingabefeld gerendert, ohne losgelösten Portal-Popup. ARIA-Combobox mit Pfeiltasten/Enter/Escape, eindeutigen Feld-IDs, sichtbaren Optionen und serverseitig bestätigter Auswahl. Während der Bestätigung keine doppelte Auswahl; gescheiterte Bestätigung setzt keinen Ort und zeigt keine widersprüchliche Treffer-Statusmeldung. Neue Eingabe entfernt den alten Fehler. Bei konfiguriertem Geoapify werden auch GPS/Kartenpunkte trotz Mapbox-Permanent-Budget 0 über den kostenlosen Anbieter aufgelöst. Ohne Anbieter bleiben die bisherigen kostenlosen neutralen GPS-/Kartenpunkte erhalten.

Lokaler Produktionsbuild-Browser bei 390×844 mit isolierter Datenbank und Providerfixture bestätigt automatische Vorschläge, Abholung und Ziel, 21 km / 25 min und Preise 52,50 € / 73,50 € / 63,00 €. Das ist kein Live-Anbieter-Nachweis. Neue konkrete Geoapify-Vertrags-/E-Mail-Freigabe wurde angefragt; keine Nutzungsbedingungen akzeptiert, kein Schlüssel erstellt und kein kostenpflichtiges Mapbox-Budget eingeschaltet.
