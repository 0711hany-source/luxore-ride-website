# Unternehmensreferenz – luxoreride.de

Vom Auftraggeber am 18.09.2026 als Informationsquelle genannt. Öffentlich sichtbare Inhalte am selben Tag abgerufen. Referenz für die weitere Umsetzung; keine automatische Aktivierung von Tarifen oder rechtlichen Texten.

Quellen: https://luxoreride.de/ und https://luxoreride.de/impressum.html

## Marke und Angebot
- Website-Schreibweise: LUXORÉ RIDE. Bisherige Nutzervorgabe/Prototyp: Luxóre Ride. Am 18.09.2026 hat der Auftraggeber die Website-Schreibweise LUXORÉ RIDE bestätigt.
- Premium-Chauffeur-/Limousinenservice mit Standort Frankfurt am Main.
- Flughafentransfers, Businessfahrten, europäische Langstrecken, Tagesbuchungen und Angebote für Hotels/Unternehmen.
- Women-to-Women-Service: weibliche Fahrgäste können eine Chauffeurin anfragen. In der App als Verfügbarkeitsanfrage mit bestätigter Zuweisung umsetzen; keine automatisierte Garantie.

## Auf der Website angegebene Flotte
| Klasse | Fahrzeug | Gäste | Gepäck |
| --- | --- | --- | --- |
| First Class | Mercedes S-Klasse | 3 | 2 |
| Business | Mercedes E-Klasse oder Audi A6 | 4 | 2 |
| Van | Mercedes V-Klasse | 6 | 6 |

WLAN wird für alle aufgeführten Fahrzeuge genannt. Die Website nennt im Preisbereich die Van-Klasse „First Class Van“. Der bisherige App-Arbeitstitel „Premium“ entspricht nicht wortgleich der Website-Klasse „Business“; Die Oberfläche verwendet nun Business Class; der gespeicherte Schlüssel premium bleibt zur Kompatibilität mit bestehenden Testfahrten erhalten.

## Veröffentlichte Preise, noch nicht als App-Tarif freigegeben
| Klasse | Transferangabe | Kilometerpreis |
| --- | --- | --- |
| Business Class | 75 EUR | 2,50 EUR |
| First Class | 95 EUR | 3,50 EUR |
| First Class Van | 85 EUR | 3,00 EUR |

Der Kilometerrechner nennt 15 EUR Mindestpreis. Nicht eindeutig beschrieben sind die Bezugsstrecke der Transferpreise sowie das Verhältnis von Transferpauschale, Kilometerberechnung und Mindestpreis. Keine additive Formel daraus ableiten. Website bezeichnet Preise als brutto inklusive 19 % MwSt.; steuerliche Behandlung vor verbindlicher Rechnungslogik prüfen lassen.

Website nennt kostenfreie Stornierung bis 24 Stunden vor Abholung und danach den vereinbarten Preis. Inklusive Wartezeit: Flughafen/Linienflüge 60 Minuten nach Landung, andere Abholorte 15 Minuten; anschließend 40 EUR je angefangene halbe Stunde. Diese Angaben sind Quellennotizen, noch keine implementierten AGB oder Abrechnungsregeln.

## Öffentlicher Geschäftskontakt
- booking@luxoreride.de
- +49 160 5083829
- Gerhart-Hauptmann-Ring 224, 60439 Frankfurt am Main
- Website nennt Erreichbarkeit rund um die Uhr und elektronische Zahlungsmethoden, ohne konkrete Zahlungsanbieter.

Betreiberrechtsform, vertretungsberechtigte Person, tatsächliche Einsatzfahrzeuge und Freigaben sind damit noch nicht verifiziert. Steuer-/Identifikationsnummern werden hier nicht dupliziert. Rechtstexte und Kundenstimmen nicht ungeprüft in die App übernehmen.
