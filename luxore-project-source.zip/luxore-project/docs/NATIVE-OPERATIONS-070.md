# Native Disposition · Fahrer 0.7.0 / Build 24

## Abgeschlossener Oberflächenschritt

Der Fahrer-Menüpunkt „Flotte & Disposition“ öffnet jetzt eine eigene native Übersicht statt ausschließlich des Fahrzeugformulars. Serverseitig erlaubte Flotten sind einzeln wählbar; Team, Tagesumsatz, offener Betrag und aktuelle Anfragen/Reservierungen sind nach dieser Flotte gefiltert. Besitzer-/Stellvertretungsrolle kommt aus den tatsächlichen Flotten-IDs. Fahrzeuge gehören weiterhin genau einer Flotte; „Fahrzeuge & Flotte“ öffnet den vorhandenen nativen Fahrzeugbereich mit dessen Speicherung. Keine neue Profil-/Fahrzeugzuordnung oder Berechtigung wird automatisch vergeben.

Ein festes natives Vollbild-Fahrerfenster zeigt Profil, Fahrzeug und Freigabe. Bestätigung ausschließlich mit vollständigem Wischen, ohne Tippen-Ersatz. Rücknahme bei Online-Schicht, aktivem GPS-Sitzungsbezug, laufender Fahrt oder offener Abschlusszahlung ist in der Oberfläche gesperrt; der vorhandene atomare Server prüft aktuelle Rechte, Konten und Einsatzstatus nochmals. Nach verlorener Antwort darf nur dieselbe gewünschte Änderung erneut ausdrücklich bestätigt werden. Ein neuer Serverstand mit dem gewünschten Status löst die Unsicherheit ohne weiteren Schreibvorgang. Keine automatische Freigabe oder Wiederholung.

## Lade-/Schreibverhalten und Grenzen

`OperationsController` bindet die Übersicht an die Konto-/Bildschirminstanz. Tatsächliche GETs auf operations und fleets(period=today) verwenden AbortSignal. Alte Leseantworten/finally-Blöcke können keine neueren Anfragen freigeben oder Daten überschreiben. Hintergrund und verborgener Tab stoppen Reads/Polls, Rückkehr lädt sofort; Polling alle 15 Sekunden nur im aktiven Vordergrund. Netzfehler erhalten den bekannten Stand, sperren Änderungen. 401/403 entfernen sichtbare Team-/Fahrtdaten. Änderungen nur aus einem weniger als 30 Sekunden alten vollständigen Stand; der Sekundentakt sperrt auch ohne neue Antwort.

Bestätigende POSTs werden nicht als Leseanfragen abgebrochen. Sperre verhindert parallele Änderung; Serverantwort entscheidet über Erfolg. Zeitüberschreitung/unklare Antwort hält die ursprüngliche beabsichtigte Änderung in dieser Bildschirminstanz, bis serverseitig geklärt oder gleichartig wiederholt. Es gibt keine Hintergrundautomatik und keinen dauerhaft gespeicherten Freigabeauftrag; nach Prozessneustart wird zuerst der Serverstand gelesen. Kontowechsel verwirft die vorherige Ansicht; verspätete Antworten schreiben nicht in die neue Instanz. Die vorhandene native Fahrer-GPS-Ortung wird durch Wechsel in Disposition nicht umkonfiguriert.

Die bestehenden Operations-GETs liefern bis zu 200 Profile und die jüngsten 200 Fahrten. Erreichen die Listen diese Grenze, weist die Oberfläche auf den begrenzten Ausschnitt hin. Tagesumsatz kommt aus der eigenen ungekappten Server-Summenabfrage für den Berliner Tag. Nicht zugeordnete Profile, Flottengründung, Mitarbeiterzuordnung, Einladungen und Stellvertretungsänderung bleiben in der bestehenden eigenen Web-Disposition; vollständige native Teamverwaltung ist noch offen. Fahrzeugverwaltung bleibt nativ. Keine neuen Zugriffsrechte, Anbieterbudgets, Datenbankmigrationen, Production-Testfreigaben/-fahrten oder Löschungen.

## Prüfungen

Neun Controller-Tests: Initial-/Fremdprofil-/Alters-/Hintergrundsperre, Transportabbruch/alte finally-Blöcke, Netzverlust und Rechteentzug, Schreiben im Hintergrund/Parallelität/fehlende Optimistik, identische Wiederholung, Lese-Reconciliation, bekannte Ablehnung/uneindeutige Bestätigung, Einsatz-/Zahlungssperren und Kontodispose. Drei echte React-Native-Komponententests: Flottenfilter/Tagesumsatz/festes Fahrerfenster, vollständige Wischbestätigung ohne Tippen, tatsächlich abgebrochene API-Reads/Rechteentzug sowie Einstieg aus dem echten App-Menü und separater Fahrzeugbereich. Insgesamt 425 Tests, beide TypeScript-Prüfungen sowie gezieltes Lint und Formatprüfung für die neuen Module bestanden. Finale APK-/Veröffentlichungsnachweise stehen unten.

Lokale echte Komponenten-Vorschau mit ausdrücklich synthetischem Team: 390×844-Übersicht und 390×640-Fahrerfenster ohne äußeren horizontalen/vertikalen Überlauf. Wischknopf im kleinen Fenster auf y=559–613 erreichbar; Inhalt scrollt innerhalb des Fensters. Screenshots outputs/native-operations/team-preview.png und profile-preview.png. Kein angemeldeter Production-Fahrer wurde verändert. Neue native Oberfläche benötigt Fahrer-APK 0.7.0 / Build 24; Kunden-APK bleibt 0.6.9 / Build 23. Physische angemeldete Schicht-, Mehrgeräte-/Bestell- und Hintergrund-GPS-Prüfungen bleiben offen. Website-Updates installieren keine APK auf Handys.

Danach angemeldete echte Geräteprüfung und weitere native Teamverwaltung; straßennahe Navigation/Hintergrund-GPS bleiben nach echter Fahrtaufnahme zu prüfen. Keine vollständige Produktionsreife oder Store-Freigabe behaupten.


## APK-/Emulator-Nachweis

Fahrer-APK mobile/artifacts/Luxore-Driver-Test-0.7.0.apk, 56144224 Bytes, SHA-256 `2bb03fd1307a6c6749d73bac1dec700904d9bdfdf5e31bfca0e14b47a34d54bf`. Paket de.luxoreride.driver.preview, Build 24, unveränderte interne Testsignatur `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c`. Standalone ARM64, nicht debuggbar, Designvorschau/Backup aus, erforderliche Fahrer-Hintergrund-/Alarmberechtigungen erhalten; Mikrofon/Overlay gesperrt. 49 Runtime-/Konfigurationsquellen bytegenau mit dem außerhalb des synchronisierten Quell-/Abhängigkeitsordners gebauten Stand abgeglichen. Paketversionen unverändert. Finale JS-Bundle-Aufgabe ausdrücklich mit Fahrer-/Internal-Umgebung wiederholt; APK-Konfiguration zusätzlich geprüft.

Als Update mit install -r ohne Deinstallation über den isolierten Emulatorstand 0.6.4 / Build 18 installiert. Drei kalte Fahrer-Starts ohne Android-Fatal-/JS-Exception, nativer anonymer Start bestätigt. Nachweis outputs/native-operations/driver-emulator-start.png; work/native-operations/emulator-result.json. Keine angemeldete echte SDK-/Schicht-/Teamfreigabe oder physische GPS-Prüfung, keine Installation auf Nutzerhandys. Kunden-APK unverändert 0.6.9 / Build 23.


## Quellveröffentlichung und Live-Prüfung

Lokaler Runtime-/Paketierungscommit `d0b9bb3`, GitHub-Commit `e193d545441e6946fd4a472cb81257e79d120976`. Drei Artefakte bytegenau mit GitHub abgeglichen. Archiv: 479 Dateien, 7.785.171 Bytes, SHA-256 `046334fb0efdaa8568f4702c46e9b03d45a4df2a76bb314c09a499cd1c01d4a4`. Private Schlüssel, APKs, work/outputs und persönliche ROADMAP-Kopie sind ausgeschlossen. Genau dieses Archiv besteht den frischen Next.js-Produktionsbuild. Diese nachträgliche Dokumentation verändert keine veröffentlichten Runtime-/Archivbytes.

Im bestehenden Vercel-Projekt gezielt Production für den geprüften main-Commit e193d54 erzeugt. Deployment `4eUS2W1b1E1T8Ftm2JqoevCDqbfr` bestätigt Ready / Production, aktuelle Domain luxoreride.de und Quelle e193d54. Nachweis outputs/native-operations/vercel-ready.png. Fünf reine GET-Prüfungen nach Ready liefern HTTP 200: Health bestätigt databaseConnected/accountsReady/bookingConfigured, Konto anonym registrationReady ohne Kontodaten/Betreiberrechte, Kunden-/Fahrerseite und Disposition. Kein Production-Schreibtest.

Gespeicherter GitHub-Entwurf [LUXORÉ Driver 0.7.0 · Interne Disposition](https://github.com/0711hany-source/luxore-ride-website/releases/tag/untagged-c3daa18c360719d6ccb4) bestätigt Draft mit genau einem Asset Luxore-Driver-Test-0.7.0.apk. Der tatsächlich von GitHub angezeigte Asset-SHA-256 entspricht der lokal geprüften APK (`2bb03fd1307a6c6749d73bac1dec700904d9bdfdf5e31bfca0e14b47a34d54bf`). Nachweis outputs/native-operations/private-apk-download.png. Bestehende berechtigte GitHub-Anmeldung erforderlich, keine öffentliche APK-/Store-Freigabe oder neue Zugriffsrechte. Vorherige APK-Entwürfe erhalten.

Automation ACTIVE alle fünf Stunden mit 425 Tests, Fahrer 0.7.0 und Kunde 0.6.9. Nächste Entwicklung: weitere native Teamverwaltung oder konkrete Geräte-/Flottenfehler, physische angemeldete Schicht-/Mehrgeräte-/Hintergrund-GPS-Prüfungen weiter offen. Lokaler Layoutserver und isolierter Emulator beendet, temporäre Layouttabs geschlossen, temporäre Viewport-Overrides zurückgesetzt.
