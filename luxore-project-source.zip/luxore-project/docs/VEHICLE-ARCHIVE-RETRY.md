# Fahrzeugarchivierung bei unterbrochener Verbindung

8. Oktober 2026: Der gemeinsame Fahrzeug-Endpunkt meldete beim erneuten Archivieren HTTP 409, obwohl die erste Anfrage bereits erfolgreich gespeichert war. Kunden mit verlorener Serverantwort konnten so einen erfolgreichen Vorgang für fehlgeschlagen halten. Der Regressionstest reproduziert den Fehler im vorherigen Stand (409 statt 200).

Nach einer nicht ausgeführten Archivänderung liest der Server den aktuellen Datensatz im bestehenden Flotten-Rechtebereich. Ist das Fahrzeug bereits mit genau demselben Grund archiviert, bestätigt er den gespeicherten Stand mit `replayed:true`. Die Wiederholung führt keine zusätzlichen Schreibaktionen aus. Ein anderer Archivgrund, ein fehlendes Fahrzeug oder ein Fahrzeug einer anderen Flotte bleibt ein Konflikt; zwischenzeitliche Angaben werden nicht überschrieben.

Vier zusätzliche Integrationstests verwenden den tatsächlichen Fahrzeug-Endpunkt, den echten Flotten-Rechtefilter und alle SQLite-Migrationen. Sie prüfen verlorene Antworten, unveränderten Archivzeitpunkt, erhaltene Fahrerfreigabe, Fahrthistorie und Bordbestand, Flottentrennung sowie Sperren während Schicht, Fahrt und offener Zahlung. Ein erzwungener Fehler beim Lösen der Fahrerzuordnung nimmt die gesamte Archivtransaktion zurück; nach Behebung lässt sich erneut speichern.

Prüfstand: 273 Tests bestanden; Web-TypeScript und gezieltes Lint bestanden. Der saubere veröffentlichbare Quellstand wird vor Veröffentlichung als Next.js-Produktionsbuild geprüft. Keine Migration oder neue APK erforderlich: Website und die bestehende native Fahrer-App verwenden denselben Endpunkt. Keine echten Fahrzeuge archiviert oder Testfahrten in Production erzeugt.

Grenzen: Dies ist die Bestätigung eines bereits archivierten Stands, keine automatische erneute Archivierung nach zwischenzeitlicher Wiederaktivierung. Physische Schicht-/Hintergrund-GPS-Tests mit APK 0.6.2 bleiben offen. Die neue Textadressbestätigung bleibt bis zur konkret angefragten Geoapify-Vertrags-/Konto-Zustimmung und Einrichtung gesperrt; das permanente Mapbox-Kostenbudget bleibt null.

Nächster Schritt: Fahrzeug hinzufügen, auswählen, Schicht starten, kassieren und Fahrzeugwechsel mit APK 0.6.2 auf den Unternehmenshandys prüfen; anschließend native Kundenbuchung und erweiterte Disposition ausbauen. Bei erteilter Geoapify-Zustimmung hat die reale Adressaktivierung Vorrang.

## Veröffentlichungsnachweis

Der saubere Archivbuild mit Next.js 16.4.0 ist erfolgreich (Kompilierung 7,1 s, TypeScript 4,9 s). Lokale Quellbasis `be2e94fbcb146bb5ccaf52ae1676f52a2a2a4f9e`; Archiv mit 418 Dateien, 7.601.015 Bytes und SHA-256 `11d42131b17eaad320703afe7ac1cc91d38ca134a4588904c59becaf1dc7a714`. Keine APKs, Schlüssel, privaten Environment-Dateien, Work-/Output-Dateien oder lokale Cloud-Konfliktkopie veröffentlicht.

Veröffentlicht im bestehenden Repository als `ff8774140327b7b44323513aa32555ef9037a10a`. Archiv, Versionsnachweis und unveränderte README bytegenau mit GitHub verglichen. Vercel-Deployment `Gjdo5n9zPqHYGuYkEXxwB3nYNNaV` zeigt Ready, Latest, Current und Production mit luxoreride.de sowie genau diesem Commit. Live-Health liefert HTTP 200 mit `databaseConnected:true`, `accountsReady:true`, `bookingConfigured:true`; anonyme Kontoabfrage zeigt `registrationReady:true`, keine Betreiberrechte. Kunden-, Fahrer- und Dispositionsseiten liefern HTTP 200. Nachweis: `outputs/fleet-archive-retry/vercel-ready.png`. Keine echten Fahrzeugdaten zum Nachweis geändert. Diese ergänzende Dokumentation ändert keinen Runtime-Code.
