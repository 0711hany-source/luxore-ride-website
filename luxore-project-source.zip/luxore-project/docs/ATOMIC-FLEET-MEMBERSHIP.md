# Teamzuordnung und Flottenzugriff gemeinsam speichern · 13. Oktober 2026

## Problem und abgeschlossener Schritt

Der bisherige remove_member-Endpunkt prüfte die Leitungsberechtigung vor einem getrennten Schreibbatch. Wurde die Stellvertretung inzwischen regulär aufgehoben, konnte der alte Zugriff trotzdem einen Mitarbeiter entfernen. assign prüfte das Bestehen der Zielflotte ebenfalls vor dem Schreibbatch; eine inzwischen gelöschte Zielflotte konnte eine verwaiste Zuordnung hinterlassen. Beide Vorgänge speicherten bisher keinen Betreiber-Audit.

`lib/mobility/fleet-membership.ts` verbindet die aktuellen Berechtigungs-/Kontenprüfungen mit Mitgliedschaft, Rücksetzung der Fahrerzuordnung, Rücknahme offener Angebote und echtem Audit in einer libSQL-Schreibtransaktion. Entfernen prüft die aktuelle konkrete Besitzer-/Stellvertretermitgliedschaft oder bestehenden Plattformbetreiberzugriff innerhalb der Transaktion. Zuordnen bleibt ausschließlich dem vorhandenen Plattformbetreiber vorbehalten; die Zielflotte muss dann tatsächlich bestehen. Gesperrte oder zur Löschung vorgemerkte Akteure dürfen nicht ändern. Inaktive Zielkonten dürfen keine neue Flottenzuordnung erhalten, können aber berechtigt von ihrer bisherigen Flotte gelöst werden. Alte gültige Identitäten ohne Kontodatensatz bleiben kompatibel.

Alle bisherigen Leitungs-/Einsatzsperren bleiben: Besitzer oder Stellvertretung können nicht umgehängt/entfernt werden, andere Fahrer nur offline, ohne GPS-Sitzung, aktive Fahrt oder offene Abschlusszahlung. Bestehende identische Zuordnung bleibt eine unveränderte Bestätigung und stoppt keine spätere Fahrzeugauswahl, Freigabe oder GPS-Schicht; kein doppelter Audit. Eine tatsächliche Zuordnung erhält Name, Telefon und ursprüngliche Profilanlage; bisherige Fahrzeug-/Klassen-/Freigabezuordnung wird wie vorher zurückgesetzt. Fahrzeuge selbst bleiben unverändert in ihrer ursprünglichen Flotte, ebenso ihre Bestände und Fahrtgeschichte. Personal ohne Fahrerprofil bleibt zuordenbar und entfernbar.

Audit-, Profil- oder Speicherfehler rollen den ganzen Vorgang zurück. Entfernen einer bereits gelösten oder inzwischen fremd zugeordneten Person bleibt ein Konflikt, keine dauerhaft gespeicherte Auftragsquittung und keine automatische Hintergrundwiederholung. Der bestehende Webclient nutzt unveränderte Aktionen und Antworten. Die Vorgänge vergeben keine neuen Plattformrechte.

## Prüfungen

Zehn echte Endpunkt-/libSQL-Tests mit allen Migrationen, tatsächlichem SQLite-Adapter und echter Audit-Funktion: Audit-/Fahrerresetfehler mit vollständigem Rücklauf für Zuordnung und Entfernung; identische Zuordnung nach späterem GPS-Schichtstart; konkrete Besitzer-/Stellvertreter-/Betreiberscopes und fremde Flotte; legitimer Stellvertretungsentzug an der Schreibgrenze; Zielflottenlöschung an der Schreibgrenze; gesperrte Akteure/Ziele und zulässige Ablösung; Online-/GPS-/Fahrt-/Zahlungssperren; Schutz von Besitzer/Stellvertretung; Profil-/Rollen-/Flottenvalidierung und Mitarbeiter ohne Fahrerprofil.

Ein isoliert geladenes unverändertes altes Endpunktmodul scheitert an sechs der zehn Prüfungen. Vier bestehende Guards bestehen vorher und bleiben erhalten. Externe Änderungen werden im alten Stand vor dem Batch und im neuen Stand vor der Transaktion eingespeist; Runtime-Dateien bleiben für den Vergleich unverändert. Korrigiert bestehen alle zehn. Insgesamt 455 Tests, Web-/Mobile-TypeScript und gezieltes Lint/Diff-Prüfung bestanden. Testdaten ausschließlich lokal und synthetisch.

## Grenzen und nächster Schritt

Keine Migration oder neue APK erforderlich: Kunde 0.6.9 / Build 23, Fahrer 0.7.0 / Build 24 unverändert. Keine Production-Mitarbeiter, Rechte, Fahrzeuge, Bestände, GPS-Schichten, Einladungen oder Fahrten geändert. Native Einladungs-/Teamzuordnungsoberfläche bleibt nächste Entwicklung; sie ist durch diesen Serverfix noch nicht fertiggestellt. Reale angemeldete Geräte-, Hintergrund-GPS- und Mehrgeräteprüfungen bleiben offen. Keine Installation auf Nutzerhandys oder Produktionsreife behaupten.

## Veröffentlichung

Nachweise werden nach geprüftem Archivbuild und bestätigter Veröffentlichung ergänzt.
