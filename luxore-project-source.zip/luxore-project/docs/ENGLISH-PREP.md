# Englisch vorbereiten (nur Bestandsaufnahme, kein Code)

Stand der Zählung: grobe `grep`-Zahlen, keine Zusage zu Umfang oder Termin.

## Wo die deutschen Texte liegen
- Alle Texte stehen direkt im Quelltext (TSX/TS), es gibt keine Übersetzungsdateien, kein i18n-Paket.
  `app/layout.tsx` setzt fest `<html lang="de">`.
- Zeilen mit Umlauten/ß in `app`, `lib`, `mobile/src` (nur .ts/.tsx): ca. 1160 Zeilen in 133 Dateien.
- Schwerpunkte (Zeilen mit Umlauten):
  - Website/Rechtliches: `app/page.tsx` (~48), `app/datenschutz/page.tsx` (~65), `app/impressum/page.tsx`, `app/hilfe/page.tsx` (~27), `app/anfrage/`.
  - Web-App Kunde/Fahrer: `app/mobility/*.tsx` (u. a. `workspace`, `driver`, `inventory`, `fleets`, `refreshments`; je 15–40), `app/workspace.tsx` (~36), `app/konto/screen.tsx`, `app/app-ansichten/showcase.tsx`.
  - Portale: `app/betreiber/console.tsx` (~55), `app/disposition`, `app/team`, `app/betrieb`.
  - Native Apps: `mobile/src/*.tsx` (u. a. `OperationsScreen`, `DriverScreen`, `App`, `CustomerBookingScreen`; je 20–35), dazu `mobile/store/` (Store-Texte, nicht gezählt).
- Server-Fehlermeldungen und Mailtexte: `lib/**` und `app/api/**` (nicht einzeln gezählt, bei Umsetzung prüfen).
- Rechtstexte (Datenschutz, Impressum, AGB) nur mit rechtlicher Prüfung übersetzen.

## Datum, Zahl und Währung
- Formatierung ist fest auf `de-DE` bzw. EUR gesetzt: ca. 13 Aufrufe von `toLocaleString`/`toLocaleDateString`/
  `toLocaleTimeString('de-DE')` und `Intl.NumberFormat('de-DE', …EUR)`; `toLocaleLowerCase('de')` an wenigen Stellen.
- Hauptstellen: `lib/ride-domain.ts`, `lib/mobility/time.ts`, `lib/inquiry.ts`, `app/mobility/workspace.tsx`,
  `app/mobility/{inventory,driver-offer,safety,checkout}.tsx`, `app/workspace.tsx`, `app/betreiber/console.tsx`,
  `mobile/src/{CustomerTripsScreen,StockScreen,OperationsScreen,DriverScreen,…}.tsx`.
- Das Zeichen „€“ steht in ca. 20 Zeilen als Text; ein weiterer `toFixed(2)`-Aufruf formatiert Zahlen ohne Locale.
- Zeitzone und Preise sind fachlich festgelegt; nur die Darstellung darf sich ändern, nie der Betrag.

## Empfohlener kleiner Weg
1. Zuerst ein gemeinsames Format-Modul (eine Datei in `lib/`, auch von `mobile/` nutzbar) mit
   `formatMoney`, `formatDate`, `formatTime`, `formatNumber`, die das Locale als Parameter nehmen
   (Standard `de-DE`). Danach die ca. 13 Aufrufe darauf umstellen. Verhalten für Deutsch bleibt gleich.
2. Dann Texte als Schlüssel in zwei Wörterbuchdateien (`de`, `en`) – schlicht, ohne schweres Paket,
   oder ein kleines etabliertes Paket, falls der Aufwand es rechtfertigt (vorher bewerten).
3. Mit einem kleinen, in sich geschlossenen Bereich beginnen (z. B. Buchungsablauf der Kunden-App),
   nicht mit dem ganzen Bestand. Rechtstexte und Mailtexte zuletzt.
4. Web: Sprache aus Einstellung/Browser wählen und `lang` am `<html>` setzen. Native Apps: Gerätesprache
   lesen (Expo-Localization wäre zu prüfen), Auswahl in den Einstellungen speichern.
5. Bestehende Tests, die deutsche Texte per Textsuche prüfen, vorher erfassen, damit sie nicht überraschend brechen.

## Offen / zu klären
- Ob Englisch für Kunden, Fahrer, Portale oder nur Website gewünscht ist.
- Wer die englischen Texte freigibt (Marke, Rechtliches).
- Ob Stores und SEO-Texte zweisprachig geführt werden sollen.
