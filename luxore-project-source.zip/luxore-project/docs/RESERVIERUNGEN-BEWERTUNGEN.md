# Reservierungen für Fahrer, Profilbild, Bewertungen

Stand: 15.11.2026 · nur Server und Web, lokal gebaut, nichts veröffentlicht. Die nativen Apps (LUXORÉ Ride, LUXORÉ Driver) bekommen diese Funktionen später; alle Schnittstellen dafür stehen unten.

**Voraussetzung für den Upload:** Migration `drizzle/0021_reservations_ratings.sql` muss auf der Live-Datenbank eingespielt sein, **bevor** der neue Code läuft (siehe „Offene Punkte“).

## 1. Reservierungen für Fahrer

### Regeln
- Eine Reservierung (Status `reserved`) ist **offen**, solange kein Fahrer sie übernommen hat und die Abholung mehr als 15 Minuten entfernt ist (bestehende Vorlaufzeit `RESERVATION_LEAD_MS`).
- **Wer sieht was:** Ein Fahrer sieht offene Reservierungen nur, wenn er freigegeben ist, ein aktives Fahrzeug seiner Flotte gewählt hat und die Klasse der Reservierung zu diesem Fahrzeug passt – dieselbe Eignung wie bei der Sofortvergabe. Dazu: Fahrer, Fahrzeug und Flotte dürfen nicht gesperrt sein (`mobility_suspensions`), und der Fahrer ist nicht selbst der Kunde. Online sein muss er dafür nicht.
- **Vorrang der eigenen Flotte:** Der Betreiber wählt im Betreiberportal („Reservierungen & Bewertungen“ → „Eigene Flotte“) eine Flotte. Deren Fahrer sehen alles Passende sofort. Fahrer anderer Flotten sehen eine Reservierung erst, wenn sie seit mindestens **2 Stunden** angelegt ist **oder** die Abholung in weniger als **3 Stunden** liegt. Ist keine eigene Flotte gewählt, sehen alle sofort alles Passende. Was ein Fahrer nicht sieht, kann er auch nicht übernehmen.
- **Vor dem Übernehmen** zeigt die Liste nur: Abholort, Ziel, Datum/Uhrzeit, Strecke, Fahrzeit, Preis, Klasse, Gäste/Gepäck der Klasse, Fahrtwünsche (Temperatur, Ruhe, Musik) und vorbestellte Bordartikel. Kein Name, keine Telefonnummer, keine Kundenkennung, keine Kundenbewertung.
- **Übernehmen** (Wischbestätigung): ein einziger Schreibzugriff entscheidet. Wischen zwei Fahrer gleichzeitig, gewinnt genau einer; der andere liest „Diese Reservierung wurde gerade von einem anderen Fahrer übernommen.“ (409). Danach ist die Reservierung fest diesem Fahrer, seiner Flotte und seinem aktuellen Fahrzeug zugeteilt.
- **Keine Überschneidung:** Ein Fahrer kann keine zweite Reservierung übernehmen, die sich mit einer eigenen überschneidet. Belegt ist die Zeit von der Abholung bis Abholung + Fahrzeit + **30 Minuten**.
- **Nach dem Übernehmen** sieht der Fahrer Name und Telefonnummer des Fahrgasts (wie bei einer angenommenen Fahrt) und dessen Bewertung. Der Kunde sieht in seinen Fahrten „Chauffeur bestätigt“ mit Name, Fahrzeug, Kennzeichen, Profilbild und Bewertung – keine Telefonnummer des Fahrers vor der Fahrt.
- **Abgeben:** Der Fahrer kann bis **90 Minuten** vor der Abholung zurückgeben. Danach nur noch die Leitung seiner Flotte oder der Betreiber („Zuteilung aufheben“, jederzeit solange die Reservierung nicht aktiv ist). Abgegebene Reservierungen sind sofort wieder offen.
- **Aktivierung (15 Minuten vorher):** Das erste Fahrtangebot geht an den zugeteilten Fahrer – ohne Entfernungsgrenze, sonst mit denselben Bedingungen wie jedes Angebot (online, aktueller und genauer Standort, passendes aktives Fahrzeug, keine laufende Fahrt, keine offene Zahlung). Ist er nicht online, lehnt er ab oder reagiert er nicht in der Angebotsfrist (25 Sekunden), läuft die normale Suche wie bisher (nächster passender Fahrer zuerst). Eine Reservierung, die niemand übernommen hat, verhält sich exakt wie vorher.
- **„Zuteilung prüfen“ (Abnahme 15.11.2026):** Passt der Fahrer nach der Übernahme nicht mehr – nicht mehr freigegeben, Fahrer/Fahrzeug/Flotte gesperrt, Flotte gewechselt, kein aktives Fahrzeug, Klasse des aktuellen Fahrzeugs passt nicht –, bleibt die Zuteilung bestehen, wird aber markiert: Flottenleitung und Betreiber sehen den Chip „Zuteilung prüfen“ mit Grund, der Fahrer sieht unter „Meine“ einen Hinweis. Ist der Fahrer nicht freigegeben oder gesperrt, werden ihm Name, Telefonnummer und Bewertung des Fahrgasts nicht mehr geliefert, bis das geklärt ist. Abgeben kann er weiterhin. Eine automatische Rückgabe gibt es bewusst nicht (eine kurze Sperre, z. B. wegen einer fälligen Wochenkontrolle, würde sonst Reservierungen verlieren). Bei der Aktivierung gilt unverändert: passt er dann nicht, läuft die normale Suche.
- Preise, Preisberechnung, Zahlung und Stornierung sind unverändert. Storniert der Kunde, bleibt die Zuteilung in der Datenbank stehen, hat aber keine Wirkung mehr.

### Zeitwerte (eine Stelle: `lib/mobility/reservations.ts`)
| Konstante | Wert | Bedeutung |
|---|---|---|
| `FOREIGN_FLEET_MIN_AGE_MS` | 2 Std. | fremde Flotten sehen ab diesem Alter |
| `FOREIGN_FLEET_PICKUP_WINDOW_MS` | 3 Std. | … oder ab dieser Nähe zur Abholung |
| `RELEASE_DEADLINE_MS` | 90 Min. | Abgabefrist des Fahrers |
| `OVERLAP_BUFFER_MS` | 30 Min. | Abstand zwischen zwei Reservierungen |

### Wo in der Oberfläche
- Fahrer-Web-App `/mobile/driver`: Karte „Reservierungen“ im Startblatt → Seite mit „Offen“ und „Meine“; Übernehmen per Wischknopf, Abgeben mit Rückfrage.
- Kunden-Web-App: „Meine Fahrten“ zeigt „Chauffeur bestätigt“; in der Fahrt die Karte mit Bild, Name, Bewertung, Fahrzeug.
- `/disposition`: „Reservierungen und Fahrer“ (wer hat übernommen, Zuteilung aufheben). Flottenleitung sieht die Reservierungen ihrer Fahrer, der Betreiber alle kommenden.
- `/betreiber` → „Reservierungen & Bewertungen“: eigene Flotte, alle Reservierungen, Bewertungsübersicht.

## 2. Profilbild der Fahrer
- Ein Bild je Fahrer in der vorhandenen Fotoablage `mobility_images` (`owner_type='driver'`, `owner_id=<Fahrer-ID>`, `slot='profile'`). Gleiche Grenzen wie bei Papieren: im Browser verkleinert (längste Seite 1600 px, JPEG), höchstens 400 KB, Typ wird am Inhalt erkannt. Ein neues Bild ersetzt das alte.
- Hochladen: der Fahrer selbst (Fahrer-Web-App → „Auto“ → „Meine Papiere“ bzw. `/pruefung`), außerdem die Leitung seiner Flotte und der Betreiber (`/disposition` → „Prüfung“ → Fahrer).
- Sehen dürfen es: der Fahrer, die Leitung seiner Flotte, der Betreiber – und ein Kunde nur, solange eine eigene Fahrt oder Reservierung diesem Fahrer zugeteilt ist (laufende Fahrt, übernommene Reservierung, abgeschlossene Fahrt bis 14 Tage danach). Geprüft wird über die Buchung; wer die Adresse errät, bekommt 404.
- **Pflicht:** „Profilbild fehlt“ ist ein Pflichtpunkt der bestehenden Bereitschaftsprüfung. Bei eingeschalteter Prüfpflicht kann der Fahrer ohne Bild nicht online gehen; bei ausgeschalteter Prüfpflicht (Standard) erscheint nur der Hinweis. Das Bild wird nicht eigens vom Betreiber freigegeben.

## 3. Bewertungen
- Nach abgeschlossener Fahrt bewertet der Kunde den Fahrer und der Fahrer den Kunden: 1 bis 5 ganze Sterne, dazu freiwillig ein Kommentar bis 300 Zeichen.
- Genau eine Bewertung je Fahrt und Seite. Nur die beiden Beteiligten. Nur abgeschlossene Fahrten. Nur innerhalb von **14 Tagen** nach Fahrtende. Danach nicht änderbar und nicht löschbar.
- **Fahrerbewertung für Kunden:** Durchschnitt mit einer Nachkommastelle und Anzahl, aber erst ab **3** Bewertungen; darunter steht „Neu“. Es gibt keine Platzhalterwerte.
- **Kundenbewertung:** sichtbar für Betreiber und Flottenleitung; für den Fahrer erst, wenn die Fahrt seine ist (übernommene Reservierung, angenommene oder laufende Fahrt) – nicht in der offenen Liste und nicht im Angebot.
- **Kommentare** sind nie öffentlich: nur Betreiber (alle) und Flottenleitung (Kommentare über eigene Fahrer; Kommentare über Fahrgäste aus Fahrten der eigenen Flotte).
- Regeln an einer Stelle: `lib/mobility/rating-rules.ts` (`RATING_WINDOW_MS`, `RATING_PUBLIC_MIN`, `RATING_COMMENT_MAX`).
- Oberfläche: Kunde in der Abschlussansicht der Fahrt; Fahrer in „Jetzt kassieren“ und unter „Umsatz → Letzte Fahrten“ („Fahrgast bewerten“); Betreiber unter „Reservierungen & Bewertungen“.

## 4. Datenmodell (Migration 0021, nur Ergänzungen)
`mobility_bookings`, neue Spalten (alle leer erlaubt):
| Spalte | Inhalt |
|---|---|
| `assigned_driver_id` | Fahrer, der die Reservierung übernommen hat |
| `assigned_fleet_id` | seine Flotte zum Zeitpunkt der Übernahme |
| `assigned_vehicle_id` | sein Fahrzeug zum Zeitpunkt der Übernahme |
| `assigned_at` | Zeitpunkt der Übernahme (ms) |

Index `idx_booking_assigned_driver (assigned_driver_id, status)`. Die bestehenden Spalten `driver_id`, `fleet_id`, `vehicle_id` werden weiterhin erst bei der Annahme des Fahrtangebots gesetzt.

Neue Tabelle `mobility_ratings`: `id`, `booking_id`, `rater_role` (`customer` | `driver`), `rater_id`, `subject_id`, `stars` (1–5), `comment` (leer erlaubt), `created_at`; eindeutig je (`booking_id`, `rater_role`); Indizes auf (`subject_id`, `rater_role`, `created_at`) und `rater_id`.

`mobility_settings`: Schlüssel `own_fleet_id` (Flotten-ID oder leer).
`mobility_images`: neue Verwendung `owner_type='driver'`, `slot='profile'` (keine Schemaänderung).
`mobility_events`: neue Aktionen `reservation.claimed`, `reservation.released`, `reservation.unassigned`.
Betreiber-Protokoll: `reservations.own_fleet`, `reservations.own_fleet_cleared`.

Kontolöschung: Profilbild wird gelöscht, übernommene Reservierungen werden wieder offen, eigene Kommentare werden geleert (Sterne bleiben).

## 5. Schnittstellen
Alle unter `/api/mobility/…`, Anmeldung wie bisher (Sitzungs-Cookie; die nativen Apps nutzen ihren bestehenden Weg). Fehler immer als `{ "error": "<deutscher Satz>" }` mit passendem Status. Zeiten in Millisekunden, Preise in Cent.

### `GET reservations` – Tafel des Fahrers
```json
{
  "ready": true,
  "reason": null,
  "open": [ReservationCard],
  "mine": [OwnReservation],
  "rules": { "releaseMinutes": 90, "bufferMinutes": 30, "foreignFleetAfterMinutes": 120, "foreignFleetBeforePickupMinutes": 180 },
  "serverTime": 1794746239199
}
```
`ready=false` mit `reason`, wenn das Profil nicht freigegeben ist, eine Sperre besteht (Fahrer, Fahrzeug, Flotte) oder kein aktives Fahrzeug gewählt ist (`open` dann leer; `mine` bleibt in allen Fällen sichtbar). Neu: `needsVehicle` (`true` nur, wenn die Fahrzeugwahl das Problem löst – dann den Knopf „Fahrzeug wählen“ zeigen).

`ReservationCard`:
```json
{ "id": "…", "pickup": "Hauptbahnhof, Frankfurt am Main", "destination": "Flughafen Frankfurt, Terminal 1",
  "scheduledAt": 1794900000000, "distanceMeters": 11511, "durationSeconds": 900, "price": 2878,
  "service": "premium", "className": "Business Class", "capacity": "4 Gäste · 2 Koffer",
  "wishes": ["Lieber Ruhe"], "boardOrder": null, "conflict": false }
```
`boardOrder` ist ein fertiger Text der vorbestellten Bordartikel („Anzahl × Name, …“) oder `null`.
`conflict=true`: überschneidet sich mit einer eigenen Reservierung (Übernehmen würde mit 409 abgelehnt).

`OwnReservation` = `ReservationCard` (ohne `conflict`) plus
```json
{ "assignedAt": 1794746000000, "releaseUntil": 1794894600000,
  "riderName": "…", "riderPhone": "…", "riderRating": { "average": 4.5, "count": 2 } }
```
`riderRating` ist `null`, wenn der Fahrgast noch nie bewertet wurde. `releaseUntil` = Abholung − 90 Minuten.
Neu (additiv): `"check": "<Satz>" | null` – Hinweis „Zuteilung prüfen“ für den Fahrer; `"contactHidden": true|false` – bei `true` sind `riderName`, `riderPhone`, `riderRating` `null` (Fahrer nicht freigegeben oder gesperrt).

### `POST reservations`
| Anfrage | Wer | Antwort |
|---|---|---|
| `{ "action": "claim", "id": "<Buchung>" }` | Fahrer | `200 { "ok": true }` (bei wiederholtem Wischen zusätzlich `"replayed": true`) · `404` nicht sichtbar/nicht passend · `409` schon vergeben, nicht mehr offen (storniert/aktiviert), Überschneidung oder beginnt in Kürze |
| `{ "action": "release", "id": "…" }` | zugeteilter Fahrer | `200 { "ok": true }` · `409` nach der 90-Minuten-Frist oder nicht (mehr) zugeteilt |
| `{ "action": "unassign", "id": "…" }` | Flottenleitung der zugeteilten Flotte, Betreiber | `200 { "ok": true }` · `403` kein Leitungsrecht · `409` nicht dieser Flotte zugeteilt |
| `{ "action": "own-fleet", "fleetId": "<Flotte>" \| null }` | nur Betreiber | `200 { "ok": true, "ownFleetId": "…" \| null }` · `403` · `404` Flotte unbekannt |

### `GET reservations?scope=staff` – Disposition
Flottenleitung: Reservierungen, die Fahrer der eigenen Flotte übernommen haben. Betreiber: alle kommenden Reservierungen (offen und übernommen). `403` für alle anderen.
```json
{ "operator": true, "serverTime": 0, "rules": { … },
  "reservations": [ { …ReservationCard, "createdAt": 0, "riderName": "…", "riderRating": null,
      "assigned": { "driverId": "…", "driverName": "…", "fleetId": "…", "fleetName": "…", "vehicle": "E-Klasse", "plate": "F-LX 1", "at": 0 } } ] }
```
`assigned` ist `null` bei offenen Reservierungen. Neu (additiv): `assigned.check` – `null` oder der Grund für „Zuteilung prüfen“ als Satz.

### `GET reservations?scope=settings` – nur Betreiber
`{ "ownFleetId": "…" | null, "fleets": [{ "id": "…", "name": "…" }], "rules": { … } }`

### `GET bookings` (erweitert, Kunde)
- Jede Buchung trägt `chauffeur`: bei `status="reserved"` und übernommener Reservierung
  `{ "name": "…", "vehicle": "E-Klasse", "plate": "F-LX 1", "photo_id": "<Bild-ID>" | null, "rating": { "average": 4.7, "count": 12 } | null }`, sonst `null`. `rating=null` heißt „Neu“ (weniger als 3 Bewertungen).
- `driver` (zugewiesener Fahrer) trägt bei angenommenen/laufenden Fahrten und bis 14 Tage nach Abschluss zusätzlich `photo_id` und `rating` (gleiche Bedeutung).
- Neu auf oberster Ebene: `"ratings": { "<Buchungs-ID>": 4 }` – die Sterne, die dieser Kunde schon vergeben hat.

- Die internen Felder `assigned_driver_id`, `assigned_fleet_id`, `assigned_vehicle_id`, `assigned_at` werden in keiner Buchungsantwort mehr ausgeliefert (Kunde, Fahrtangebot, Fahrerverlauf, Disposition); der Kunde bekommt `chauffeur`, die Leitung die Reservierungsansicht.

### `GET driver` (erweitert, Fahrer)
Neu: `"profilePhotoId": "<Bild-ID>" | null`, `"ratings": { "<Buchungs-ID>": 5 }` (selbst vergebene Sterne), `"riderRatings": { "<Buchungs-ID>": { "average": 4.5, "count": 2 } | null }` für die eigenen angenommenen/laufenden Fahrten.

### `GET ratings`
`{ "given": { "<Buchungs-ID>": 4 }, "rules": { "windowDays": 14, "publicFrom": 3, "commentMax": 300 } }` – nur die eigenen vergebenen Sterne.

### `POST ratings`
Anfrage `{ "bookingId": "…", "stars": 1–5, "comment": "optional, höchstens 300 Zeichen" }`. Die Seite (Kunde oder Fahrer) ergibt sich aus der Fahrt.
Antwort `201 { "ok": true, "role": "customer" | "driver", "stars": 4 }`.
`400` ungültige Sterne/Kommentar zu lang · `404` Fahrt unbekannt oder nicht beteiligt · `409` Fahrt nicht abgeschlossen, Frist von 14 Tagen abgelaufen oder schon bewertet.

### `GET ratings?scope=staff[&fleetId=…]` – Flottenleitung, Betreiber
```json
{ "operator": true, "rules": { … },
  "drivers":   [ { "id": "…", "name": "…", "fleetName": "…", "count": 3, "average": 4.3, "comments": [ { "stars": 5, "comment": "…", "createdAt": 0 } ] } ],
  "customers": [ { "id": "…", "name": "…", "count": 1, "average": 2, "comments": [ … ] } ] }
```
Hier stehen die echten Werte ohne die 3er-Schwelle. Je Person die letzten 5 Kommentare. `403` für alle anderen und für eine fremde `fleetId`.

### Profilbild: `images` (erweitert)
- Hochladen: `POST images?ownerType=driver&ownerId=<Fahrer-ID>&slot=profile`, Bilddaten roh im Körper (JPEG/PNG/WebP, höchstens 400 KB). Antwort `201 { "id": "<Bild-ID>", "bytes": 12345 }`. Ersetzt ein vorhandenes Bild. `404`, wenn der Aufrufer weder der Fahrer noch Leitung seiner Flotte noch Betreiber ist; `413` zu groß; `415` kein Bild.
- Ansehen: `GET images?id=<Bild-ID>` (wie bei Papieren). `404` für alle ohne Recht – auch für Kunden ohne zugeteilte Fahrt bei diesem Fahrer.
- Die Bild-ID kommt aus `GET driver` (`profilePhotoId`), `GET compliance` (`profilePhotoId`; in `?scope=fleet` je Fahrer), `GET bookings` (`chauffeur.photo_id`, `driver.photo_id`).

### `GET compliance` (erweitert)
`driver.requirements` kann „Profilbild fehlt“ enthalten; neu `profilePhotoId`.

## 6. Tests
`tests/reservations-ratings.test.mjs` (echte Routen auf echter SQLite-Datenbank mit allen Migrationen): Sichtbarkeit nach Fahrzeugklasse, Sperren, Vorrang eigene Flotte (2 Std. / 3 Std.), keine Kundendaten vor Übernahme, Übernahme-Wettlauf, Überschneidung, Abgabefrist 90 Minuten und Aufheben durch Leitung/Betreiber, Aktivierung mit Rückfall in die normale Vergabe (abgelehnt, abgelaufen, offline, beschäftigt, nicht mehr freigegeben, nicht übernommen), „Zuteilung prüfen“ (Freigabe, Sperren, Fahrzeug, Klasse, Flottenwechsel) samt ausgeblendetem Kontakt, keine internen Zuteilungs-IDs in Antworten, Rechte beim Übernehmen/Abgeben/Aufheben (fremde Rollen, Wiederholung, aktivierte Reservierung), Sterne außerhalb 1–5 und falsche Typen, Profilbild-Zugriff des Kunden endet bei Abgabe/Aktivierung/Storno, Kundensicht „Chauffeur bestätigt“, Bewertungsregeln, Sichtbarkeit ab 3, Kommentar-Rechte, Kundenbewertung erst nach Übernahme, Profilbild-Rechte, Profilbild als Pflichtpunkt.

## 7. Offene Punkte
- **Reihenfolge beim Upload:** erst Migration 0021 auf die Live-Datenbank, dann der Code. Ohne 0021 bleiben Health-Prüfung, Buchen, Fahrtansicht und Sofortvergabe funktionsfähig (die neuen Abfragen dort sind abgesichert); die neuen Schnittstellen `reservations`/`ratings` und die Kontolöschung im Betreiberportal schlagen aber fehl.
- **Women to Women** gibt es bisher nur als Anfrage per E-Mail; an der Buchung ist nichts gespeichert. Die Tafel kann deshalb keinen Hinweis zeigen und nicht danach filtern. Sobald der Wunsch an der Buchung steht, gehört er in `reservationCard` und in die Eignungsregel.
- **Gäste/Gepäck** werden je Buchung nicht erfasst; gezeigt wird die Kapazität der Klasse („bis zu …“).
- **Offene Produktfrage für Hanan – Telefonnummer vor der Fahrt:** Der zugeteilte Fahrer sieht Name und Telefonnummer ab der Übernahme (Vorgabe „wie bei einer angenommenen Fahrt“). Ein Fahrer könnte übernehmen, die Nummer lesen und wieder abgeben; das Protokoll (`reservation.claimed` / `reservation.released`) zeigt das, verhindert es aber nicht. Alternative: Nummer erst kurz vor der Abholung zeigen (z. B. 2 Stunden vorher; eine Stelle in `ownReservations`). Nicht entschieden, nichts geändert.
- **Fahrer wechselt nach der Übernahme das Fahrzeug, wird gesperrt oder verliert die Freigabe:** Die Zuteilung bleibt stehen und wird markiert („Zuteilung prüfen“, siehe Regeln). Der Kunde sieht in dieser Zeit weiterhin „Chauffeur bestätigt“ – offen, ob das in diesem Fall ausgeblendet werden soll. Eine automatische Rückgabe gibt es nicht; Leitung/Betreiber heben die Zuteilung auf. Die Markierung wird beim Laden berechnet; eine Benachrichtigung an die Leitung gibt es nicht.
- **Sperre während laufender Fahrt (bestehendes Verhalten, nicht geändert):** Wer bei der Sperre gerade fährt, bleibt online; die Sperre greift erst beim nächsten Schichtbeginn. Bis dahin kann er Fahrtangebote bekommen – auch das erste Angebot einer übernommenen Reservierung.
- **Fahrtangebot zeigt den Namen des Fahrgasts** (bestehendes Verhalten aller Angebote, nicht geändert): Wer ein Angebot bekommt, sieht den Namen schon vor der Annahme, die Telefonnummer nicht.
- **Zugeteilter Fahrer ist 15 Minuten vorher nicht online:** Die Fahrt geht sofort in die normale Suche (Vorgabe). Eine Erinnerung an den Fahrer (Push) gibt es noch nicht.
- **Kein Zeitgeber:** Reservierungen werden weiterhin nur aktiv, wenn `/api/mobility/tick` aufgerufen wird (bestehender offener Punkt der Problemliste).
- **Kunde wird nicht benachrichtigt**, wenn ein Chauffeur übernimmt oder abgibt; er sieht es beim Öffnen der Fahrt.
- **Profilbild ohne Prüfung** durch den Betreiber; Datenschutzerklärung um Profilbild und Bewertungen ergänzen (Recht).
- **Native Apps:** Reservierungstafel, Profilbild-Upload, Sterne-Eingabe und „Chauffeur bestätigt“ sind dort noch nicht gebaut.
- Per Hand geprüft am 15.11.2026 (lokal, 375 px; Betreiberseite zusätzlich 1280 px): Profilbild-Upload (Datei per Skript in das Dateifeld gelegt, nicht über den Auswahldialog des Betriebssystems), Sterne in „Jetzt kassieren“ und unter „Letzte Fahrten“, „Abgeben“, „Zuteilung aufheben“ und „Zuteilung prüfen“ in `/disposition`, eigene Flotte speichern, Aktivierung über `/api/mobility/tick` mit Fahrer offline und online. Nicht geprüft: echte Handys, Kamera-Aufnahme, Rückfall auf einen zweiten Fahrer im Browser (lokal gibt es nur einen freigegebenen Testfahrer; durch Tests abgedeckt).

## Entscheidungen von Hanan (15.11.2026, nach der Abnahme)

- **Telefonnummer des Kunden:** Der Fahrer bekommt sie erst, wenn er „angekommen“ markiert hat (Status `arrived`, danach `riding`). Nicht bei Annahme einer Fahrt und nie bei einer nur übernommenen Reservierung (`mine[].riderPhone` ist immer `null`). Der Name bleibt wie beschrieben. Umsetzung: `hydrate` in `lib/mobility/bookings.ts`, `ownReservations` in `lib/mobility/reservations.ts`.
- **Women-to-Women sowie Gäste/Gepäck** werden an der Buchung nicht gespeichert und nicht in der Reservierungsliste geführt. Die Liste zeigt weiter nur die Kapazität der Klasse.
