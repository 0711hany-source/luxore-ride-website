# Regionale Fahrervermittlung · 9. Oktober 2026

Fahrtanfragen und Adresswahl sind deutschland-/europaweit möglich. Sofortvermittlung benötigt einen freigegebenen, freien und online befindlichen Fahrer mit aktuellem Standort, passender Fahrzeugklasse und aktiver Fahrzeugzuordnung innerhalb von 50 km Luftlinie. Die Nähe ist keine Straßen-Anfahrtszeit; Reservierungen sind ohne Fahrerzusage nicht bestätigt. Der automatische Reservierungsscheduler und physische Mehrgeräte-Fahrttests bleiben offen.

## Behobener Fehler

Die bisherigen Abfragen für Angebote und die drei anonymen Kartenfahrzeuge verwendeten `LIMIT 200`, bevor sie nach Entfernung filterten und sortierten. Dadurch konnte eine Anfrage in Berlin keinen Fahrer sehen, wenn die ersten 200 freigegebenen Fahrer in Frankfurt standen. Auch bei mehr als 200 Fahrern in derselben Region konnte der tatsächlich nächste Fahrer fehlen.

Beide Abfragen begrenzen Kandidaten jetzt zuerst auf ein geografisches Rechteck um den Abholort, das den vollständigen 50-km-Kreis umfasst. Innerhalb dieser Region gibt es keinen willkürlichen Kandidatenzahl-Abbruch. Anschließend werden wie bisher die exakte Großkreisentfernung, der 50-km-Radius und eine deterministische Reihenfolge nach Fahrer-ID angewendet. Die SQL-Vorauswahl benötigt keine SQLite-Mathematikerweiterung und berücksichtigt auch Datumsgrenze und Pole. Keine Frankfurt-Grenze, Tarifänderung, Rechteausweitung, Migration oder neue APK erforderlich.

Freigabe, Klassen, aktuelle und hinreichend genaue GPS-Daten, Flotten-/Fahrzeugzuordnung, belegte Fahrer, offene Angebote und noch nicht kassierte Fahrten werden weiterhin gefiltert. Die Anzeige gibt weiterhin nur drei auf ein Raster gerundete Koordinaten ohne Fahreridentität oder Kennzeichen zurück. Angebote werden weiterhin nacheinander vermittelt; keine zweite Bestätigung per Tippen eingeführt.

## Prüfungen

Vier neue Regressionstests mit echten SQLite-Migrationen scheitern am vorherigen Stand und bestehen nach der Korrektur: Vermittlung und Kartenanzeige nach mehr als 200 entfernten Fahrern sowie Auswahl der nächsten Fahrer hinter mehr als 200 näherungsweise lokalen Kandidaten. Die API-Tests prüfen außerdem Offline-/Freigabe-/GPS-/Klassen-/Flottenfilter und Datenminimierung. Zwei weitere SQL-Tests prüfen den vollständigen Suchkreis mit je 360 Punkten für Berlin, München, Hamburg, Süddeutschland, beide Seiten der Datumsgrenze und beide Polregionen sowie den Ausschluss entfernter deutscher Städte.

Insgesamt 304 Tests, TypeScript und gezieltes Lint bestanden. Diese Tests sind synthetisch und ersetzen keine reale Fahrerzusage, Schicht oder Standortprüfung. Produktionsdaten und Fahrerstatus bleiben unverändert. Sehr große örtliche Flotten benötigen weiterhin Lastmessungen; die Korrektur ist kein Beleg für unbegrenzte Skalierung. Nächster Schritt: native Kundenbuchung ausbauen und mit den vorhandenen APKs 0.6.4 auf getrennten echten Geräten Schicht, Vermittlung und Hintergrund-GPS prüfen.

Der bestehende Fünf-Stunden-Automationsprompt wurde erfolgreich auf Geoapify-Free, den neuen Mapbox-Token, die farbige Kundenkarte und den tatsächlichen Entwicklungsstand berichtigt. Rhythmus, Zielchat und Benachrichtigungswunsch bleiben unverändert. Die früher dokumentierte Werkzeug-Sperre bei dieser Aktualisierung ist damit behoben.
