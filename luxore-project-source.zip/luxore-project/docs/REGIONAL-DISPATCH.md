# Regionale Fahrervermittlung · 9. Oktober 2026

Fahrtanfragen und Adresswahl sind deutschland-/europaweit möglich. Sofortvermittlung benötigt einen freigegebenen, freien und online befindlichen Fahrer mit aktuellem Standort, passender Fahrzeugklasse und aktiver Fahrzeugzuordnung innerhalb von 50 km Luftlinie. Die Nähe ist keine Straßen-Anfahrtszeit; Reservierungen sind ohne Fahrerzusage nicht bestätigt. Der automatische Reservierungsscheduler und physische Mehrgeräte-Fahrttests bleiben offen.

## Behobener Fehler

Die bisherigen Abfragen für Angebote und die drei anonymen Kartenfahrzeuge verwendeten `LIMIT 200`, bevor sie nach Entfernung filterten und sortierten. Dadurch konnte eine Anfrage in Berlin keinen Fahrer sehen, wenn die ersten 200 freigegebenen Fahrer in Frankfurt standen. Auch bei mehr als 200 Fahrern in derselben Region konnte der tatsächlich nächste Fahrer fehlen.

Beide Abfragen begrenzen Kandidaten jetzt zuerst auf ein geografisches Rechteck um den Abholort, das den vollständigen 50-km-Kreis umfasst. Innerhalb dieser Region gibt es keinen willkürlichen Kandidatenzahl-Abbruch. Anschließend werden wie bisher die exakte Großkreisentfernung, der 50-km-Radius und eine deterministische Reihenfolge nach Fahrer-ID angewendet. Die SQL-Vorauswahl benötigt keine SQLite-Mathematikerweiterung und berücksichtigt auch Datumsgrenze und Pole. Keine Frankfurt-Grenze, Tarifänderung, Rechteausweitung, Migration oder neue APK erforderlich.

Freigabe, Klassen, aktuelle und hinreichend genaue GPS-Daten, Flotten-/Fahrzeugzuordnung, belegte Fahrer, offene Angebote und noch nicht kassierte Fahrten werden weiterhin gefiltert. Die Anzeige gibt weiterhin nur drei auf ein Raster gerundete Koordinaten ohne Fahreridentität oder Kennzeichen zurück. Angebote werden weiterhin nacheinander vermittelt; keine zweite Bestätigung per Tippen eingeführt.

## Prüfungen

Vier neue Regressionstests mit echten SQLite-Migrationen scheitern am vorherigen Stand und bestehen nach der Korrektur: Vermittlung und Kartenanzeige nach mehr als 200 entfernten Fahrern sowie Auswahl der nächsten Fahrer hinter mehr als 200 näherungsweise lokalen Kandidaten. Die API-Tests prüfen außerdem Offline-/Freigabe-/GPS-/Klassen-/Flottenfilter und Datenminimierung. Zwei weitere SQL-Tests prüfen den vollständigen Suchkreis mit je 360 Punkten für Berlin, München, Hamburg, Süddeutschland, beide Seiten der Datumsgrenze und beide Polregionen sowie den Ausschluss entfernter deutscher Städte.

Insgesamt 304 Tests, TypeScript und gezieltes Lint bestanden. Diese Tests sind synthetisch und ersetzen keine reale Fahrerzusage, Schicht oder Standortprüfung. Produktionsdaten und Fahrerstatus bleiben unverändert. Sehr große örtliche Flotten benötigen weiterhin Lastmessungen; die Korrektur ist kein Beleg für unbegrenzte Skalierung. Nächster Schritt: native Kundenbuchung ausbauen und mit den vorhandenen APKs 0.6.4 auf getrennten echten Geräten Schicht, Vermittlung und Hintergrund-GPS prüfen.

Der bestehende Fünf-Stunden-Automationsprompt wurde erfolgreich auf Geoapify-Free, den neuen Mapbox-Token, die farbige Kundenkarte und den tatsächlichen Entwicklungsstand berichtigt. Rhythmus, Zielchat und Benachrichtigungswunsch bleiben unverändert. Die früher dokumentierte Werkzeug-Sperre bei dieser Aktualisierung ist damit behoben.

## Veröffentlichungsnachweis

Quellstand f84d5ef; Archiv mit 430 Dateien / 7.641.102 Bytes / SHA-256 a7cc37731b099f84508c802181ff933406b9f4501afd750a6bd5ab118a52310f. Das tatsächliche Archiv hat den Produktionsbuild bestanden. GitHub-Commit 098be1ccc4332a4da143a3118b08380f37ccf787 enthält die drei Upload-Dateien bytegleich. Vercel HrgdRUdd7ZmZbSu8k5tDMs553vnU ist Ready / Latest / Current Production unter luxoreride.de. Screenshot: outputs/dispatch-region/vercel-production-ready.png.

Live mit einer gewöhnlichen anonymen Test-Gerätesitzung: echte Geoapify-Vorschläge und bestätigte Auswahl Brandenburger Tor → Berlin Hauptbahnhof, Mapbox-Straßenroute 2.284 m / 597 s und korrekt jeweils 15 € Mindestpreis. Der eigene Nearby-Endpunkt antwortet mit HTTP 200 und aktuell null verfügbaren Fahrern. Keine Profile, Schichten oder Buchungen erzeugt, keine Fahrer alarmiert. Nur öffentliche Sehenswürdigkeiten als Testadressen verwendet. Health, Konto sowie Kunden-/Fahrer-/Dispositionsseiten liefern HTTP 200. Konten, Datenbank und Buchungskonfiguration sind bereit. Die große synthetische Fahrerzahl wurde ausschließlich lokal geprüft; diese Veröffentlichung ist kein realer Schicht-/Hintergrund-GPS-Nachweis.
