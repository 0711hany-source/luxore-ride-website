# LUXORÉ RIDE

## Verbindlicher Produktumfang
Frankfurt am Main. Start mit dem eigenen Unternehmen; später Partnerunternehmen.
Fahrgast- und Fahrer-Apps für iOS und Android, Webbuchung, Disposition. Premium und First Class als getrennte Klassen. Name vom Auftraggeber bestätigt.

## Stand 0.1 – private Entwicklungsumgebung
Responsive Webansichten für Buchung, Fahrerablauf und Disposition. D1-Persistenz für authentifizierte Testkonten, serverseitige Berechnung von Beispielpreisen, geprüfte Fahrtzustände, atomarer Statuswechsel und kontoabhängiger Datenzugriff. Keine tatsächliche Vermittlung. Keine Karten, Geocodierung, GPS-Verfolgung, Zahlungsabwicklung, echten Fahrerzugänge oder nativen Apps. Orte sind eine feste Testauswahl. Preise sind frei gewählte Testwerte und keine freigegebenen Tarife. Fahrer- und Dispositionsansicht sind ausdrücklich Simulationen desselben Testkontos, keine Rollenberechtigungen.

## Zielarchitektur und nächste Umsetzung
- Gemeinsame versionierte API und Domänenmodelle, getrennte React-Native/Expo-Apps für Fahrgast und Fahrer; native Builds und reale Geräteprüfung erforderlich.
- Eigener Identity-Provider für externe Kunden, Fahrer und Personal; Sites/ChatGPT-Identität dient nur dieser privaten Entwicklungsumgebung. Kein ungeprüftes Vertrauen in HTTP-Identitätsheader außerhalb des Sites-Dispatchers.
- Organisationen, Mitgliedschaften, Personalrollen, Fahrer, Fahrzeuge und Nachweise mit serverseitigen Berechtigungen. Die operator_id dieser Testdaten ist nur ein Platzhalter pro Testkonto. Echte Partnerzugehörigkeiten benötigen Membership-Tabellen und isolierte Abrechnung.
- Geocodierung, Routen und serverseitige Angebote mit Ablaufdatum; Geld ausschließlich in Cent; veröffentlichte Tarifversionen je Fahrzeugklasse.
- Fahrerfreigabe, Schichtstatus und atomare Zuweisung; keine Mehrfachannahme desselben Auftrags oder gleichzeitigen aktiven Fahrten pro Fahrer. Ereignisprotokoll, Idempotenz und Wiederholbarkeit für alle Zahlungen und Buchungen.
- Standortübertragung mit ausdrücklicher Geräteberechtigung, sparsamer Speicherung, Echtzeitkanal, Offline-/Wiederverbindungslogik und Push-Mitteilungen.
- Zahlungsanbieter, Zahlungsautorisierung, Erfassung, Rückerstattung, Belege; spätere Partnerauszahlungen über dafür geeignetes Anbieterprodukt.
- Disposition, Kundenservice, Änderungsprotokolle, Überwachung, Wiederherstellung und Lasttests.

## Vor einem echten Betriebsstart offen
Unternehmensdaten und tatsächliches Betriebsmodell; verbindliche Fahrzeug- und Serviceanforderungen; Tarife, Storno-/Wartebedingungen und Servicezeiten; Rechts-/Datenschutzprüfung für das konkrete Modell; Karten-, Zahlungs-, SMS-/Push- und Store-Konten. Sicherheitsprüfung, Datenschutzkonzept, Löschfristen, Backup-Restore-Test, Barrierefreiheit, Geräte- und Feldtests sowie betriebliche Supportprozesse. Diese Punkte sind Anforderungen zur weiteren Klärung, keine Rechtsberatung oder bestätigte Zulassungsfähigkeit.

Die private Testversion ist nicht produktionsreif und darf nicht als öffentlicher Fahrdienst betrieben werden.

## Aktualisierung 0.2
Marke LUXORÉ RIDE bestätigt. Modernisierte Oberfläche mit übernommenen Website-Fahrzeugbildern; Business Class (bestehender Schlüssel premium), First Class und First Class Van. In neuen Testfahrten werden die veröffentlichten Transferangaben 75/95/85 EUR als explizite Richtwerte gespeichert, ohne Kilometerberechnung oder Streckenpreisversprechen. Bestehende Datensätze behalten ihre gespeicherten Preise. Serviceübersicht, Women-to-Women-Kontakt, Tarifübersicht und Unternehmenslinks ergänzt. Keine native App oder echte Vermittlung dadurch aktiviert.

## Aktualisierung 0.3
Der Kunde hat am 19.09.2026 die Kilometerpreise 2,50/3,50/3,00 EUR, mindestens 15 EUR und ohne Transferpauschale bestätigt. Die neue, getrennte Routen-/Vermittlungsimplementierung ersetzt die v0.2-Testbuchung. Maßgeblicher Stand und offene Betriebsanforderungen: [MOBILITY-SETUP.md](MOBILITY-SETUP.md). Frühere Standbeschreibungen oben sind historisch.
