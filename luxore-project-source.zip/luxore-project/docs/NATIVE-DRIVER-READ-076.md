# Native Fahrer-/Routenaktualisierung · Fahrer 0.7.6 / Build 30

## Reproduzierte Fehler

Die bisherige DriverScreen behielt einen laufenden Fahrer-GET beim Hintergrund- oder Seitenwechsel. Rückkehr startete wegen pollBusy keinen neuen Abruf, bis die alte Anfrage endete; deren Antwort konnte inzwischen veraltete Fahrzeug-/Fahrtdaten anzeigen. Die Kartenkonfiguration hatte keine eigene Antwortzuordnung. Eine alte finally-Freigabe konnte nach einer neuen Abfrage wiederum parallele Folgeabrufe erlauben.

Routenabfragen verwendeten eine über Phasenwechsel geteilte Busy-Sperre und einen gemeinsamen 20-Sekunden-Zeitstempel. Ein vorheriger angenommener Fahrtabschnitt blockierte dadurch die sofortige neue Route beim Fahrtstart oder nach Hintergrundrückkehr. Kontowechsel behielten denselben Komponentenstand, und aktuelle 401/403-Fehler ließen bekannte Fahrtdaten zunächst sichtbar.

## Korrektur

DriverScreen besitzt jetzt einen nach Anmeldetoken getrennten Workspace. Fahrerstatus, Kartenkonfiguration und guidance haben jeweils einen eigenen AbortController und prüfen die konkrete aktuelle Anfrage vor Anwendung/Abschluss. Die tatsächlichen nativeApi-Aufrufe sind an deren AbortSignal gebunden. Reads und Fünf-Sekunden-Poll laufen nur bei sichtbarem Fahrer-Cockpit im Vordergrund. Bei Hintergrund, verborgener Seite oder Unmount werden nur diese Reads abgebrochen und sofort für einen neuen Abruf freigegeben. Rückkehr lädt Fahrerstatus und Konfiguration direkt neu; alte Antworten und finally-Blöcke ändern keine neuere Anfrage.

Guidance wird beim Phasen-, Sichtbarkeits- oder Schreibzustandswechsel verworfen. Eine neue Phase beginnt ohne geerbte Busy-/Wartezeitsperre; innerhalb derselben aktiven Phase bleiben mindestens 20 Sekunden zwischen Versuchen und der bestehende 25-Sekunden-Poll erhalten. Antworten müssen exakt zur Fahrt/Phase und zur aktuellen Anfrage gehören. Die guidance-API ist technisch ein POST, semantisch aber eine Routen-Leseabfrage. Ein bereits im Backend angekommener Routenabruf kann trotz Clientabbruch weiterhin Anbieterbudget verbrauchen; keine neuen Kontingente oder kostenpflichtigen APIs aktiviert.

Vor Schicht-/Fahrt-/Zahlungs-/Bord-Schreibvorgängen werden alte Reads invalidiert. Der bestätigende POST erhält kein Sichtbarkeits-Abbruchsignal und darf im Hintergrund zu Ende gehen. Nach Abschluss wird nur im sichtbaren Vordergrund neu gelesen; andernfalls sofort bei Rückkehr. Keine automatischen Write-Wiederholungen, keine neue Freigabe, keine GPS-/Berechtigungsänderung. Bei aktuellen 401/403 entfernt die Ansicht alte Fahrt-/Karten-/Fortschrittsdaten; bestehender nativer Schichtdienst und seine serverseitigen Rechte bleiben unabhängig. Das GPS-Verhalten aus 0.7.5, Rohkoordinaten, Kartenstil, bestehende Wischbestätigungen und Kamerarückkehr bleiben erhalten.

## Tests und Grenzen

Acht neue tatsächliche React-Native-Komponententests binden den echten account-client und prüfen dessen fetch-Signale mit isolierten nativen Adaptern. Alle acht scheitern mit dem unveränderten vorherigen DriverScreen und bestehen mit der Korrektur. Geprüft: Hintergrund/Rückkehr, Seitenverbergen, alte finally-Blöcke und Polls, Fahrtphasenwechsel, Guidance-Rückkehr ohne alte Wartezeit, vollständig gewischter Fahrt-POST im Hintergrund, Kontowechsel sowie aktuelle 401/403. Der native Standortdienst wird dabei nicht gestoppt. Gesamtstand **526 bestandene Tests**, beide TypeScript-Prüfungen und gezieltes Lint/Format erfolgreich.

Fahrer 0.7.6 / Build 30 benötigt ein APK-Update. Kunde 0.6.9 / Build 23 unverändert. Keine neue Migration oder echte Production-Fahrt/Schicht-/Team-/Leitungs-/Freigabeänderung. Anonyme Emulatorstarts ersetzen keinen angemeldeten SDK-/Fahrt-/Mehrgeräte-/Herstellerakku-/Hintergrund-GPS- oder Straßenbeweis. Nächster Schritt angemeldete Unternehmensgeräteprüfung und konkreter Navigationsfehler; verbleibende native Besitzerübergabe danach mit erwartetem altem Besitzer und Serverklärung nach verlorener Antwort.

## Android-Nachweis

Fahrer 0.7.6 / Build 30 mit unveränderten Abhängigkeiten außerhalb synchronisierter Quellen gebaut. 71 Runtime-/Asset-/Konfigurationsdateien bytegenau mit dem Buildbaum verglichen. SDK-Prüfung: de.luxoreride.driver.preview, eigenständiger Bundle, ARM64, interne Variante, nicht debuggable, deaktiviertes Backup und bestehende Berechtigungen. Signatur unverändert `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c`. APK 56.204.724 Bytes; SHA-256 `ef09f0560276bed26bb8fdcdcebc1919940d4ae49260e0e6c1af045829426249`.

Im isolierten Emulator über 0.7.5 ohne Deinstallation aktualisiert; drei kalte Starts mit lebendem Prozess und nativer anonymer Startoberfläche ohne Fatal-/ReactNativeJS-Absturz. Kein angemeldeter echter Karten-/Fahrt-/Hintergrund-GPS-Beweis. Kunde 0.6.9 / Build 23 unverändert. Nicht als auf Nutzerhandys installiert darstellen.
