# Apple / iOS – Vorbereitung (Stand 14.11.2026)

Kurz: Der Code ist für iOS vorbereitet. Gebaut wurde noch **keine** iOS-App – dafür fehlen Apple-Konto und Xcode bzw. EAS. Auf einem iPhone ist nichts geprüft.

## Was im Code bereit ist
- Kennungen: `de.luxoreride.customer` (LUXORÉ Ride) und `de.luxoreride.driver` (LUXORÉ Driver); Test-Varianten mit `.preview`.
- Baunummer iOS = Android-`versionCode` (eine Quelle in `mobile/app.config.ts`).
- Standort-Texte auf Deutsch. Ride: nur „Beim Verwenden“. Driver: zusätzlich „Immer“ und Hintergrundmodus `location`.
- Keine unnötigen Rechte: kein Face-ID-Text, kein Hintergrund-Abruf; Ride ohne Push-Recht.
- Verschlüsselungs-Angabe (`ITSAppUsesNonExemptEncryption: false`), Sprache Deutsch, Privacy-Manifest mit den Gründen aus den installierten Paketen.
- App-Texte: auf dem iPhone steht „Einstellungen“ / „Immer“ statt „Android“. Apple Karten ist auf dem iPhone als Navigation wählbar. Fahrtalarm prüft auf iOS die Mitteilungs-Erlaubnis.
- `mobile/eas.json`: iOS in allen vier Profilen, dazu `customer-simulator` und `driver-simulator`.
- Geprüft ohne Xcode: `expo prebuild --platform ios` läuft für beide Apps durch; der iOS-Programmcode bündelt (`expo export --platform ios`).

## Was Hanan / die Inhaberin tun muss
1. **D-U-N-S-Nummer** für das Unternehmen besorgen (bei Dun & Bradstreet; über die Apple-Seite kostenlos anfragbar – Dauer nicht geprüft).
2. **Apple Developer Program als Unternehmen** beitreten (developer.apple.com/programs/enroll). Kosten laut Apple 99 US-$ pro Jahr. Die Person, die anmeldet, wird „Account Holder“ und muss für das Unternehmen unterschreiben dürfen – also die Inhaberin oder mit ihrer Vollmacht. (Hinweis: kostenpflichtig → braucht ihre Freigabe.)
3. Im Entwickler-Konto zwei **App-IDs** anlegen: `de.luxoreride.customer`, `de.luxoreride.driver` (für Driver: Push Notifications aktivieren).
4. In **App Store Connect** zwei Apps anlegen: „LUXORÉ Ride“ und „LUXORÉ Driver“ (Sprache Deutsch, je eine eigene SKU). Ob die Namen noch frei sind, ist nicht geprüft.
5. Hanan als Nutzer mit Rolle „Admin“ oder „App Manager“ einladen.
6. Bauen (Weg A oder B), nach **TestFlight** laden, intern testen (bis 100 interne Tester laut Apple, ohne Apple-Prüfung).
7. Erst danach: Store-Seite ausfüllen und zur Prüfung einreichen – nur nach ausdrücklicher Freigabe.

## Zwei Bauwege
**A – Xcode auf diesem Mac**
- Plus: kostenlos, alles lokal, iPhone-Simulator zum Ansehen, keine Wartezeit.
- Minus: sehr großer Download aus dem App Store; aktuell nur ca. 36 GB frei – das ist knapp (Xcode + Simulator + Bauordner). Zusätzlich muss CocoaPods installiert werden. Ob die macOS-Version zur aktuellen Xcode-Version passt: nicht geprüft.

**B – EAS Build (Expo-Cloud)**
- Plus: kein Xcode nötig, kein Speicherplatz; Expo erstellt Zertifikate und Profile nach Anmeldung mit dem Apple-Konto. Befehl später z. B. `eas build --platform ios --profile driver-production`.
- Minus: Expo-Konto nötig; der Quellcode wird zu Expo hochgeladen (braucht Freigabe). Kostenloser Tarif mit Wartezeit und Monatskontingent – **laut Expo, vor Nutzung prüfen**. Kein Simulator auf diesem Mac zum Ansehen.
- TestFlight braucht das Profil `…-production` (Store-Verteilung). `…-preview` ist für einzeln registrierte Test-iPhones gedacht.

## Worauf Apple bei der Prüfung besonders achtet
- **Hintergrund-Standort (Driver):** Apple will sehen, warum „Immer“ nötig ist. Text ist ehrlich formuliert (nur während der Schicht). Meist wird ein kurzes Video oder eine Erklärung verlangt.
- **Kontolöschung:** muss in der App erreichbar sein. Heute gibt es sie auf der Website (`/konto`); ein direkter Weg aus den Apps dorthin ist **nicht geprüft / vermutlich offen**.
- **Datenschutzangaben** in App Store Connect (Standort, E-Mail, Name, Telefon …) müssen zur Datenschutzerklärung passen – Rechtstext, von der Inhaberin zu bestätigen.
- **Anmeldung für Prüfer:** Die Apps nutzen E-Mail-Codes. Apple braucht einen Testzugang, der ohne fremdes Postfach funktioniert (Demo-Konto mit festem Code o. Ä.) – gibt es noch nicht.
- **Sign in with Apple** ist nicht nötig, weil es nur die eigene Anmeldung per E-Mail-Code gibt.
- Die Fahrer-App ist nur für freigegebene Chauffeure nutzbar – das in den Prüfhinweisen erklären.

## Was für iOS noch fehlt
- Echter Bau und Test auf einem iPhone (Karte, Schicht, Hintergrund-Standort bei gesperrtem Bildschirm, Fahrtalarm mit Ton).
- Push über Apple (APNs): Es gibt keinen Push-Server. Der Fahrtalarm kommt heute nur, solange die App im Hintergrund per Standort wach bleibt.
- Mapbox auf iOS: laut installierter Paket-Doku ist kein Download-Schlüssel mehr nötig; der öffentliche Kartenschlüssel wie bei Android. Nicht am echten Bau geprüft. Privacy-Manifest des Mapbox-SDK: nicht prüfbar (kommt erst beim Bau).
- Screenshots 6,7″ / 6,9″, App-Symbole (Auswahl offen), Store-Texte, Altersfreigabe.
- Im Web-Teil der App (eingebettete Seiten) fehlt auf dem iPhone ein Zurück-Schritt innerhalb der Seite; der Pfeil oben führt zur Startseite. Kommt mit der neuen Navigation (Etappe 1).
- Kontolöschung direkt aus der App, Testzugang für Apple-Prüfer.
