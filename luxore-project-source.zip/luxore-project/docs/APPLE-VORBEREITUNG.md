# Apple / iOS – Vorbereitung (Stand 14.11.2026)

Kurz: Der Code ist für iOS vorbereitet. Gebaut wurde noch **keine** iOS-App – dafür fehlen Apple-Konto und Xcode bzw. EAS. Auf einem iPhone ist nichts geprüft.

## Was im Code bereit ist
- Kennungen: `de.luxoreride.customer` (LUXORÉ Ride) und `de.luxoreride.driver` (LUXORÉ Driver); Test-Varianten mit `.preview`.
- Baunummer iOS = Android-`versionCode` (eine Quelle in `mobile/app.config.ts`).
- Standort-Texte auf Deutsch. Ride: nur „Beim Verwenden“. Driver: zusätzlich „Immer“ und Hintergrundmodus `location`.
- Keine unnötigen Rechte: kein Face-ID-Text, kein Hintergrund-Abruf; Ride ohne Push-Recht.
- Verschlüsselungs-Angabe (`ITSAppUsesNonExemptEncryption: false`), Sprache Deutsch, Privacy-Manifest mit den Gründen aus den installierten Paketen.
- App-Texte: auf dem iPhone steht „Einstellungen“ / „Immer“ statt „Android“. Apple Karten ist auf dem iPhone als Navigation wählbar. Fahrtalarm prüft auf iOS die Mitteilungs-Erlaubnis.
- `mobile/eas.json`: iOS in allen vier Profilen, dazu `customer-simulator` und `driver-simulator`.
- Geprüft ohne Xcode: `expo prebuild --platform ios` läuft für beide Apps durch; der iOS-Programmcode bündelt (`expo export --platform ios`).

## Was Hanan / die Inhaberin tun muss
1. **D-U-N-S-Nummer** für das Unternehmen besorgen (bei Dun & Bradstreet; über die Apple-Seite kostenlos anfragbar – Dauer nicht geprüft).
2. **Apple Developer Program als Unternehmen** beitreten (developer.apple.com/programs/enroll). Kosten laut Apple 99 US-$ pro Jahr. Die Person, die anmeldet, wird „Account Holder“ und muss für das Unternehmen unterschreiben dürfen – also die Inhaberin oder mit ihrer Vollmacht. (Hinweis: kostenpflichtig → braucht ihre Freigabe.)
3. Im Entwickler-Konto zwei **App-IDs** anlegen: `de.luxoreride.customer`, `de.luxoreride.driver` (für Driver: Push Notifications aktivieren).
4. In **App Store Connect** zwei Apps anlegen: „LUXORÉ Ride“ und „LUXORÉ Driver“ (Sprache Deutsch, je eine eigene SKU). Ob die Namen noch frei sind, ist nicht geprüft.
5. Hanan als Nutzer mit Rolle „Admin“ oder „App Manager“ einladen.
6. Bauen (Weg A oder B), nach **TestFlight** laden, intern testen (bis 100 interne Tester laut Apple, ohne Apple-Prüfung).
7. Erst danach: Store-Seite ausfüllen und zur Prüfung einreichen – nur nach ausdrücklicher Freigabe.

## Zwei Bauwege
**A – Xcode auf diesem Mac**
- Plus: kostenlos, alles lokal, iPhone-Simulator zum Ansehen, keine Wartezeit.
- Minus: sehr großer Download aus dem App Store; aktuell nur ca. 36 GB frei – das ist knapp (Xcode + Simulator + Bauordner). Zusätzlich muss CocoaPods installiert werden. Ob die macOS-Version zur aktuellen Xcode-Version passt: nicht geprüft.

**B – EAS Build (Expo-Cloud)**
- Plus: kein Xcode nötig, kein Speicherplatz; Expo erstellt Zertifikate und Profile nach Anmeldung mit dem Apple-Konto. Befehl später z. B. `eas build --platform ios --profile driver-production`.
- Minus: Expo-Konto nötig; der Quellcode wird zu Expo hochgeladen (braucht Freigabe). Kostenloser Tarif mit Wartezeit und Monatskontingent – **laut Expo, vor Nutzung prüfen**. Kein Simulator auf diesem Mac zum Ansehen.
- TestFlight braucht das Profil `…-production` (Store-Verteilung). `…-preview` ist für einzeln registrierte Test-iPhones gedacht.

## Worauf Apple bei der Prüfung besonders achtet
- **Hintergrund-Standort (Driver):** Apple will sehen, warum „Immer“ nötig ist. Text ist ehrlich formuliert (nur während der Schicht). Meist wird ein kurzes Video oder eine Erklärung verlangt.
- **Kontolöschung:** muss in der App erreichbar sein. Heute gibt es sie auf der Website (`/konto`); ein direkter Weg aus den Apps dorthin ist **nicht geprüft / vermutlich offen**.
- **Datenschutzangaben** in App Store Connect (Standort, E-Mail, Name, Telefon …) müssen zur Datenschutzerklärung passen – Rechtstext, von der Inhaberin zu bestätigen.
- **Anmeldung für Prüfer:** Die Apps nutzen E-Mail-Codes. Apple braucht einen Testzugang, der ohne fremdes Postfach funktioniert (Demo-Konto mit festem Code o. Ä.) – gibt es noch nicht.
- **Sign in with Apple** ist nicht nötig, weil es nur die eigene Anmeldung per E-Mail-Code gibt.
- Die Fahrer-App ist nur für freigegebene Chauffeure nutzbar – das in den Prüfhinweisen erklären.

## Was für iOS noch fehlt
- Echter Bau und Test auf einem iPhone (Karte, Schicht, Hintergrund-Standort bei gesperrtem Bildschirm, Fahrtalarm mit Ton).
- Push über Apple (APNs): Es gibt keinen Push-Server. Der Fahrtalarm kommt heute nur, solange die App im Hintergrund per Standort wach bleibt.
- Mapbox auf iOS: laut installierter Paket-Doku ist kein Download-Schlüssel mehr nötig; der öffentliche Kartenschlüssel wie bei Android. Nicht am echten Bau geprüft. Privacy-Manifest des Mapbox-SDK: nicht prüfbar (kommt erst beim Bau).
- Screenshots 6,7″ / 6,9″, App-Symbole (Auswahl offen), Store-Texte, Altersfreigabe.
- Im Web-Teil der App (eingebettete Seiten) fehlt auf dem iPhone ein Zurück-Schritt innerhalb der Seite; der Pfeil oben führt zur Startseite. Kommt mit der neuen Navigation (Etappe 1).
- Kontolöschung direkt aus der App, Testzugang für Apple-Prüfer.


## Stand 18.11.2026 abends: Entwicklerprogramm aktiv

- Hanan hat das Apple Developer Program (Einzelperson) abgeschlossen; die Willkommens-Mail von App Store Connect kam am 18.11.2026 um 19:10.
- Das Team hat dieselbe Kennung wie vorher das kostenlose „Personal Team“ (`5YUS239NXN`), ist jetzt aber ein bezahltes Team: Der Bau mit `IOS_FREE_SIGNING=0` bekommt ein Profil mit einem Jahr Laufzeit und dem Push-Recht. Xcodes Zwischenspeicher zeigt noch „Personal Team“ an – das ist nur die alte Anzeige.
- Testfassungen auf Hanans iPhone: `IOS_FREE_SIGNING=0 IOS_TEAM=5YUS239NXN bash mobile/scripts/build-ios-device.sh <customer|driver> "iPhone von Hany"` (in `~/LuxoreRide-Bau`, ohne vorangestellten CommandLineTools-PATH).

## Weg zu TestFlight (noch nichts hochgeladen)

1. **Store-Paket bauen** (Claude, erst nach Hanans Ja, weil Xcode dabei im Apple-Konto zwei App-Kennungen und ein Verteilungszertifikat anlegt): `IOS_TEAM=5YUS239NXN bash mobile/scripts/build-ios-store.sh customer` und danach `driver`. Ergebnis: `.ipa` in `~/LuxoreRide-Bau/ios-store-<variante>/export/`. Das Skript lädt nichts hoch.
2. **App-Einträge anlegen** (Hanan, in appstoreconnect.apple.com → Apps → „+“ → Neue App), je einmal:
   - Plattform iOS, Name „LUXORÉ Ride“ bzw. „LUXORÉ Driver“, Primäre Sprache Deutsch.
   - Bundle-ID: `de.luxoreride.customer` bzw. `de.luxoreride.driver` (stehen nach Schritt 1 in der Auswahl).
   - SKU: `luxore-ride` bzw. `luxore-driver`. Benutzerzugriff: Voller Zugriff.
   - Ist ein Name vergeben, eine Variante wählen (z. B. „LUXORÉ Ride Chauffeur“) und Claude Bescheid geben.
3. **Hochladen** (Claude, nur nach ausdrücklicher Freigabe für genau diesen Upload). Danach verarbeitet Apple den Bau (meist 10–30 Minuten).
4. **Tester einladen** (Hanan): App Store Connect → TestFlight → Interne Tests → Gruppe anlegen, sich selbst und weitere Personen des Teams hinzufügen. Interne Tester brauchen keine Apple-Prüfung. Externe Tester (bis 10.000) brauchen eine kurze Beta-Prüfung und den Prüfer-Zugang (`docs/PLAY-CONSOLE-SCHRITTE.md`, Abschnitt 7).
5. Für die Veröffentlichung im App Store zusätzlich: Screenshots 6,9″, Datenschutzangaben, Altersfreigabe, Prüfhinweise mit Prüfer-Zugang, Begründung für den Hintergrund-Standort der Fahrer-App.

Push-Mitteilungen: Das Recht ist in der Fahrer-App jetzt signiert, aber es gibt noch keinen Push-Versand (Firebase-Projekt fehlt, siehe `docs/PUSH-EINRICHTUNG.md`).
