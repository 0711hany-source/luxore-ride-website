# Mapbox-Kosten und Android-Wiederaufnahme – 06.10.2026

Nutzerbericht: Mapbox meldet permanentes Geokodierungskontingent, Navi-Pfeil springt wieder, beim App-Wechsel gehen Karte/GPS verloren. Anschließender Auftrag: geprüften Stand veröffentlichen.

## Kostenbefund und Korrektur

Die bisherige Adresssuche setzte für sämtliche Vorwärts-/Rückwärtsabfragen `permanent=true` und speicherte alle Treffer. Permanente Geokodierung hat laut aktueller Mapbox-Preisseite kein kostenloses Kontingent und beginnt bei 5 USD je 1.000 Anfragen. Temporäre Geokodierung hat derzeit 100.000 kostenlose Anfragen je Monat; temporäre Ergebnisse dürfen nicht dauerhaft gespeichert oder gecacht werden. Eine automatische GPS→Geokodierungsschleife wurde im App-Code nicht gefunden: Suche, aktueller Abholort und Pin-Bestätigung waren Benutzeraktionen. Zuletzt verwendete Ziele lösten allerdings unnötig eine weitere Rückwärtsabfrage aus. Test-/andere App-Nutzung und die zeitversetzte Monatsabrechnung können ebenfalls Kontoverbrauch verursachen; tatsächliche Kontozahlen/Rechnungen wurden nicht eingesehen.

- Textsuche fordert temporäre Vorschläge an und legt diese nicht in `mobility_places`, Angeboten, Buchungen oder dem Geokodierungscache ab.
- Erst die bewusste Auswahl bestätigt die Adresse über permanente Geokodierung. Der bestätigte Treffer muss zur gewählten Position passen (höchstens 25 m Abweichung); sonst erneute Auswahl. Während der Bestätigung bleibt die alte Adresse nicht buchbar. GPS-Abholung/Pin sind bereits bewusste Auswahl und bleiben permanente, speicherbare Ergebnisse.
- Permanentes Ergebnis wird für 30 Tage wiederverwendet, mit normalisiertem, gehashtem Abfrageschlüssel. Mehrere Geräte mit derselben Adresse verursachen keine zusätzliche permanente Anfrage. Eine Datenbank-Lease verhindert gleichzeitige doppelte kostenpflichtige Abfragen; Fehler geben die Lease wieder frei.
- Eigene zuletzt verwendete Ziele verwenden die schon gespeicherte Adresse ohne neue Mapbox-Abfrage.
- Globale Grenzen für **diese Site**: 2.000 Suchvorschläge und standardmäßig 200 neue permanente Abfragen pro UTC-Tag. `MAPBOX_PERMANENT_DAILY_LIMIT` lässt sich als Sites-Laufzeitvariable zwischen 0 und 10.000 setzen. 0 blockiert neue permanente Abfragen; Cache und vorhandene Adressen bleiben verfügbar. Ausgeschöpfte Limits liefern einen verständlichen Fehler. Zähler reserviert auch fehlgeschlagene Provider-Versuche konservativ; kein automatischer gebührenpflichtiger Retry.
- Diese Grenzen sind kein Gesamtkostenlimit des Mapbox-Kontos. Kartenladen, Matching, Verkehrsrouten, andere Projekte/Token-Nutzer und bestehende Rechnungen haben eigene Abrechnung. Bereits entstandener Verbrauch wird dadurch nicht rückgängig gemacht.
- Neue Migration `0016_late_doctor_faustus.sql` ergänzt ausschließlich `mobility_geocodes`; keine Änderung bestehender Buchungs-/Fahrzeugdaten.

Referenzen: [Mapbox-Preise](https://www.mapbox.com/pricing), [Speicherung von Geokodierungsergebnissen](https://docs.mapbox.com/api/search/geocoding/), [Rechnungen und Abrechnung](https://docs.mapbox.com/accounts/guides/invoices/).

## Navi-Darstellung

Die schnelle Darstellung erreichte einen neuen Standort bisher innerhalb von höchstens 280 ms, stand dann aber bis zur nächsten GPS-Messung still. Das konnte trotz kurzem Nachlauf als Springen erscheinen. Die Kunden-Nachführung bleibt unverändert.

Für den eigenen Fahrer-Pfeil wird jetzt ausschließlich bei verlässlichem Ein-Sekunden-Takt, Genauigkeit ≤15 m, gültiger Geschwindigkeit/Fahrtrichtung und passender künftiger Routenlinie eine kurze Bewegung auf dieser Straße dargestellt. Richtung muss zum Straßensegment passen; der Pfeil schneidet keine Kurve ab. Die Vorhersage endet nach spätestens 1,2 Sekunden und höchstens rund 23 m zusätzlicher Darstellung (maximal 25 m/s, Einholen der Messung berücksichtigt). Bei Stillstand, fehlender Telemetrie, unpassender Straße oder langsamem GPS-Takt keine Vorhersage. Eine neue Messung korrigiert aus der bereits dargestellten Position ohne Teleport. Die tatsächlichen GPS-Daten für Vermittlung, Fahrtstatus und Preis bleiben unverändert. Reale GPS-Nachlauf-/Kreiselmessung am Handy steht aus.

## Android 0.4.3 / Code 8

- Hintergrunddienst bewahrt den letzten frischen Standort im verschlüsselten Gerätespeicher, an die aktuelle Schicht gebunden, auch wenn dessen Serverupload wegen Netzverlust scheitert. Status liefert ihn an die Webansicht zurück; alte/ungenaue/fremde Schichtstände werden nicht als frisch übernommen. Pause löscht ihn.
- Status ist lesend und beendet keine gerade gestartete Schicht. Native Dienst-/Speicheränderungen werden serialisiert; neuere Übergänge verwerfen wartende Starts. Ein alter Uploadfehler darf keine neu begonnene Schicht stoppen.
- Beim Verlassen der Vordergrundansicht wird nur deren GPS-Watch beendet; der gesonderte Hintergrunddienst bleibt bestehen. Beim Wiederöffnen wird die Vordergrund-Watch neu eingerichtet, eine hängende Einzelabfrage verworfen und der frische Hintergrundstand übernommen. Eine langsamere alte GPS-Antwort überschreibt keinen neueren Standort.
- Ein unterbrochener Dienst wird beim Wiederöffnen mit bestehender gültiger Schichtfreigabe und vorhandener Berechtigung wieder eingerichtet. Keine automatische Online-Schaltung ohne gültige Freigabe. Der Hintergrundtakt bleibt fünf Sekunden, Vordergrundtakt eine Sekunde.
- Nach Beendigung des Android-WebView-Renderers wird die WebView neu erzeugt. Höchstens eine automatische Wiederherstellung je Minute verhindert eine Endlosschleife; weitere Abstürze bieten bewusstes erneutes Verbinden. Gespeicherte Fahrten, Flottenzuordnung, Gerätecookie und native Schicht bleiben unabhängig vom Renderer. Nicht gespeicherte Formularentwürfe sind bei einem Renderer-/Prozessverlust nicht als erhalten zugesichert.
- Beide internen ARM64-Test-APKs gebaut: `mobile/artifacts/Luxore-Driver-Test-0.4.3.apk` und `mobile/artifacts/Luxore-Ride-Test-0.4.3.apk`. Paketkennungen bleiben `.preview`; Fahrer-Signatur identisch zu 0.4.2. Über bestehende App installieren, ohne Deinstallation/Datenlöschung. Diese native Änderung benötigt ein einmaliges APK-Update und kommt nicht allein durch Nachladen der Website.

## Nachweise und Grenzen

TypeScript für Web und Mobile, Produktionsbuild, 52 Logik-/Komponenten-/Diensttests und kompletter lokaler Buchungs-/Kassierablauf mit fünf getrennten Geräteidentitäten bestanden. Die Geokodierungstests nutzen den tatsächlichen API-Code mit ausschließlich synthetischen Providerantworten, keine kostenpflichtigen Mapbox-Aufrufe. Geprüft: temporäre Speicherung verhindert, permanenter Cache/Budget/Lease, fehlerhafte Auswahl, Preise trotz ausgeschöpftem Neuadressbudget, Kurvenweg, begrenztes Auslaufen, Stillstand, GPS-Antwortreihenfolge, Status während Start, Wiederaufnahme/Pause-Rennen und frischer Hintergrundstand trotz Netzverlust. APK-Build, eingebettete Varianten/Versionen, Berechtigungen und Signaturen geprüft.

Kein physischer Android-/Emulatortest, keine Store-Einreichung und kein nativer iOS-Ausbau. Hersteller-Energiesparen und erzwungenes Beenden können Dienste weiterhin stoppen; durchgehender Betrieb ist auf dem tatsächlichen Fahrergerät noch nicht bestätigt. Die angefragte installierte APK-Version steht noch aus.

## Veröffentlichung

Die Site ist weiterhin öffentlich auf Stand 39. Der erneute sichere Sites-Versuch nach Netzwerk-/Git-Freigabe scheiterte an der automatischen Ablehnung von `write_stdin` (`sandbox_approval` deaktiviert). Keine Zugangsdaten in Dateien/Befehlsargumente geschrieben; kein Push, keine neue gespeicherte Site-Version und kein Deployment. Neue Kostenbegrenzung, feste Fenster und Navi-Darstellung wirken deshalb **noch nicht auf der öffentlichen Site**. Die native APK ist lokal verfügbar.

Dem Nutzer wurde die Wahl angeboten, bis zur Veröffentlichung die serverseitigen Mapbox-Abfragen vorübergehend abzuschalten. Das pausiert neue Adresssuchen/Preisberechnungen und damit neue Buchungen. Ohne konkrete Antwort dazu keine Live-Laufzeitvariable verändert.

Nächste Schritte: sichere Veröffentlichung nach Behebung der Freigabeblockade; gegebenenfalls ausdrücklich gewünschte vorläufige Abfragepause; 0.4.3 auf Fahrerhandy installieren und mit zweitem Gerät aktive Fahrt, fünf Minuten Sperrbildschirm, App-Wechsel, Netzverlust/Rückkehr, GPS-Aktualität und Pause prüfen. Anschließend Mapbox-Kontoverbrauch mit den tatsächlichen Rechnungsposten vergleichen.
