# Android-Anmeldung zur Fahreransicht · 0.5.3 / Build 13

Der Geräte-Screenshot zeigt nach „Schicht & Fahrten öffnen“ die JSON-Antwort `Anfrageursprung nicht erlaubt`. Die Ursache liegt in der Android-WebView-POST-Quelle: Die installierte react-native-webview-Version verwendet für POST `view.postUrl`, bevor eigene Header übernommen werden. Ihre Typdokumentation weist ausdrücklich darauf hin, dass eigene Header auf Android nur für GET unterstützt werden. Dadurch fehlen Origin und die native Bearer-Anmeldung bei der alten App-Sitzungsbrücke.

Die gemeinsame native Quellfunktion verwendet jetzt GET und übermittelt das verifizierte Konto ausschließlich im Authorization-Header. In der URL steht nur der freigegebene Zielpfad. Die Serverbrücke verlangt weiterhin einen gültigen, nicht abgelaufenen Kontozugang, setzt ein HttpOnly-/SameSite-Strict-/Secure-Cookie und leitet nur zu vier eigenen Ansichten weiter. Cookie-only-Aufrufe, fremde Origins, Cross-Site-Anfragen, gesperrte Konten und externe Weiterleitungen bleiben abgewiesen. Bestehende POST-Aufrufe behalten ihre Origin-Prüfung; keine globale Ausnahme oder Administratorumgehung hinzugefügt.

Native HTTP-Fehler beim Anmeldeschritt werden jetzt vom Wiederverbindungsbildschirm erfasst, statt eine rohe JSON-Seite offen zu lassen. Die Vordergrund-GPS-Subscription reagiert außerdem auf den Wechsel zwischen Betreiber- und Fahreransicht, während der unabhängige Hintergrunddienst erhalten bleibt.

Der Nutzer hat den Audi A6 ausdrücklich gewählt. Die vorhandene Betreiberanmeldung ist bereits als Fahrer freigegeben, der eigenen Flotte zugeordnet und das Fahrzeug wurde über die normale Live-Auswahl zugewiesen. Fahreransicht zeigt „Audi A6 · HG IV 777“ und „Online gehen“. Es wurde keine künstliche GPS-Position hochgeladen und keine reale Schicht vom Rechner gestartet.

225 automatisierte Tests bestanden, einschließlich der tatsächlichen GET-Serverbrücke mit der nativen Quellfunktion und echten SQLite-Kontositzungen. Web- und mobile TypeScript sowie Next.js-Produktionsbuild geprüft. Alte generierte Next-Dev-Typkopien wurden beim lokalen Build in `work/generated-next-dev-before-053` erhalten; keine Geschäftsdateien gelöscht.

Die Korrektur ist nativ: Beide internen APKs müssen einmal auf 0.5.3 aktualisiert werden. Konten und Rechte ändern sich dadurch nicht. Ein vollständiger Gerätestest mit der aktualisierten Fahrer-App, GPS-Freigabe, Schichtstart, Sperrbildschirm und Rückkehr bleibt erforderlich. Dies ist keine Store-Veröffentlichung und kein Nachweis eines bereits funktionierenden nativen Online-Updates.
