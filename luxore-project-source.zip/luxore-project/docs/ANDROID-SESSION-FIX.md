# Android-Anmeldung zur Fahreransicht · 0.5.3 / Build 13

Der Geräte-Screenshot zeigt nach „Schicht & Fahrten öffnen“ die JSON-Antwort `Anfrageursprung nicht erlaubt`. Die Ursache liegt in der Android-WebView-POST-Quelle: Die installierte react-native-webview-Version verwendet für POST `view.postUrl`, bevor eigene Header übernommen werden. Ihre Typdokumentation weist ausdrücklich darauf hin, dass eigene Header auf Android nur für GET unterstützt werden. Dadurch fehlen Origin und die native Bearer-Anmeldung bei der alten App-Sitzungsbrücke.

Die gemeinsame native Quellfunktion verwendet jetzt GET und übermittelt das verifizierte Konto ausschließlich im Authorization-Header. In der URL steht nur der freigegebene Zielpfad. Die Serverbrücke verlangt weiterhin einen gültigen, nicht abgelaufenen Kontozugang, setzt ein HttpOnly-/SameSite-Strict-/Secure-Cookie und leitet nur zu vier eigenen Ansichten weiter. Cookie-only-Aufrufe, fremde Origins, Cross-Site-Anfragen, gesperrte Konten und externe Weiterleitungen bleiben abgewiesen. Bestehende POST-Aufrufe behalten ihre Origin-Prüfung; keine globale Ausnahme oder Administratorumgehung hinzugefügt.

Native HTTP-Fehler beim Anmeldeschritt werden jetzt vom Wiederverbindungsbildschirm erfasst, statt eine rohe JSON-Seite offen zu lassen. Die Vordergrund-GPS-Subscription reagiert außerdem auf den Wechsel zwischen Betreiber- und Fahreransicht, während der unabhängige Hintergrunddienst erhalten bleibt.

Der Nutzer hat den Audi A6 ausdrücklich gewählt. Die vorhandene Betreiberanmeldung ist bereits als Fahrer freigegeben, der eigenen Flotte zugeordnet und das Fahrzeug wurde über die normale Live-Auswahl zugewiesen. Fahreransicht zeigt „Audi A6 · HG IV 777“ und „Online gehen“. Es wurde keine künstliche GPS-Position hochgeladen und keine reale Schicht vom Rechner gestartet.

225 automatisierte Tests bestanden, einschließlich der tatsächlichen GET-Serverbrücke mit der nativen Quellfunktion und echten SQLite-Kontositzungen. Web- und mobile TypeScript sowie Next.js-Produktionsbuild geprüft. Alte generierte Next-Dev-Typkopien wurden beim lokalen Build in `work/generated-next-dev-before-053` erhalten; keine Geschäftsdateien gelöscht.

Die Korrektur ist nativ: Beide internen APKs müssen einmal auf 0.5.3 aktualisiert werden. Konten und Rechte ändern sich dadurch nicht. Ein vollständiger Gerätestest mit der aktualisierten Fahrer-App, GPS-Freigabe, Schichtstart, Sperrbildschirm und Rückkehr bleibt erforderlich. Dies ist keine Store-Veröffentlichung und kein Nachweis eines bereits funktionierenden nativen Online-Updates.

## Abgeschlossener Build und Veröffentlichung

Beide internen APKs erfolgreich gebaut und mit `verify-android-preview.sh` geprüft: Build 13, korrekte getrennte `.preview`-Kennungen, ARM64, Standalone-Bundle, nicht debuggable, passende unveränderte Standort-/Alarmberechtigungen. Signatur SHA-256 `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c` stimmt mit 0.5.2 überein; Update ohne vorherige Deinstallation möglich. Beim Kundenbuild aufgetretene beschädigte generierte Gradle-Skriptcaches wurden unter `work/gradle-cache-before-053` erhalten und neu erzeugt; abschließender Build erfolgreich.

| Interne Datei | Bytes | SHA-256 |
| --- | --- | --- |
| `mobile/artifacts/Luxore-Driver-Test-0.5.3.apk` | 31.914.248 | `8863d1ef55eb0d3c34308efaa5c938ad2ceb2a8626b66c628b9480ebe277a9f5` |
| `mobile/artifacts/Luxore-Ride-Test-0.5.3.apk` | 31.942.228 | `d2c64f01d60e88b2bdd188353573438ab0d12bdaf34a88e968b7073791fc61f4` |

GitHub `f4453e1c5c67fc6e49f84dc176ae608ae7ba0630` veröffentlicht den geprüften lokalen Basiscommit `125538b`; Quellarchiv, Version und README bytegenau abgeglichen. 391 Dateien, 7.570.975 Bytes, Archiv SHA-256 `f70bbc2fef8bed40094228d1ac2911e18baf438c2b7e9ed953c0d8551c0f80b9`. APKs und private Dateien wurden nicht öffentlich hochgeladen. Vercel `3JfuRzYdioa3SRwmWFxSFAxHuo93` bestätigt Ready / Production / luxoreride.de.

Live-Guardprüfungen: GET ohne Anmeldeheader liefert 401 ohne Cookie; fremder Origin und alte POST-Anfrage ohne Origin liefern weiterhin 403 ohne Cookie. Health HTTP 200 mit allen Bereitschaftsfeldern true. Fahrer-Seite liefert die neue Deployment-ID. Eigene authentifizierte Browseransicht bestätigt HG IV 777, Audi A6 und „Online gehen“. Kein tatsächlicher GPS-Schichtstart aus dem Browser ausgeführt. Nachweise: `work/android-bridge-053-live-checks.json`, `outputs/android-session-053/driver-live.png`, `outputs/android-session-053/vercel-ready.png`. Die gesicherte neue App-Brücke wurde lokal mit echten SQLite-Sitzungen erfolgreich getestet; die APK muss noch auf dem Unternehmenshandy geprüft werden.
