# Atomarer authentifizierter Schichtstart · 17. Oktober 2026

## Nachgewiesene Fehler

POST /api/mobility/driver mit action:online prüfte die Identität und das freigegebene Fahrerprofil vor der asynchronen Vorbereitung nativer Credentials. Eine danach gesetzte Kontosperre oder Löschvormerkung verhinderte den eigentlichen Start nicht. Ein verzögerter Start konnte außerdem eine inzwischen neu gestartete Session samt gültiger Capability wieder ersetzen oder eine inzwischen beendete alte Session neu eröffnen. Die bestehende Batch-Anlage hielt Session und Capability zwar bereits zusammen, schützte aber nicht den ursprünglich gelesenen Sessionstand.

## Änderung

lib/mobility/driver-online.ts bereitet UUID, nativen Token und Hash weiterhin vor jeder Mutation vor. Anschließend liest ein libSQL-Schreibzugriff den aktuellen eigenen Kontostatus, die Fahrerfreigabe und session_id erneut. Ein vorhandenes nicht aktives Konto oder entzogene Fahrerfreigabe bleibt 403. Eine gegenüber der vorgelagerten Fahrerabfrage geänderte Session bleibt 409 ohne eigene Mutation, auch wenn die neue Schicht vor dem ersten GPS-Punkt noch online=0 ist. NULL wird als tatsächlicher fehlender Sessionwert verglichen. Die Zielidentität stammt weiterhin ausschließlich aus der Anmeldung, nicht aus driverId im Body.

Im selben Schreibzugriff erfolgt das bestehende Update mit aktuellem aktivem Fahrzeug, tatsächlicher Flottenmitgliedschaft und erwartetem Sessionwert. Sessionrotation, Zurücksetzen der bisherigen Standortanzeige und Löschen/Neuanlegen der nativen Capability committen gemeinsam. Ein SQL-Fehler rollt sämtliche Schritte zurück; die vorherige gültige Freigabe bleibt erhalten. Kein automatischer Retry. Ein später ausdrücklich neu angeforderter Start liest den dann aktuellen Sessionstand und darf weiterhin erneuern. Gültige Altidentitäten ohne lokalen Accountdatensatz, Webstarts ohne nativen Token sowie Wiederherstellung bei bestehender zugeordneter Fahrt bleiben kompatibel.

Fahrerprofil, Freigabe, Fahrzeugauswahl, Flotten-/Teamrechte, Angebote, Fahrten und Zahlungsgeschichte werden nicht verändert. Wie bislang werden bei einem erfolgreichen Start lat/lng/location_at geleert und online erst durch einen gültigen GPS-Punkt gesetzt. Die bestehende Bereinigung bereits abgelaufener Capabilities bleibt erhalten; fremde gültige Capabilities bleiben bestehen. Die separat abgesicherten Stop-/GPS-/Alarmabläufe bleiben unverändert. Keine neue API, Migration, Abhängigkeit oder APK.

## Prüfungen

16 neue Tests rufen den tatsächlichen Endpunkt mit echtem sqliteDatabase/libSQL-Adapter und sämtlichen vorhandenen Migrationen auf. Sieben scheitern im bisherigen Endpunkt: nachträgliche Kontosperre/Löschvormerkung, Status bei entzogener Freigabe, zwischenzeitliche Ersatzsession/Pause und zwei echte überlappende Startanfragen mit verzögerter Hashvorbereitung (Erststart aus NULL und Erneuerung). Native und Webanfragen prüfen die aktuellen Guards. Kontrollfälle decken gültige Starts, fremde Identitäten im Body, unveränderte Rechte/Geschichte, drei tatsächliche SQL-Abbruchtrigger samt Rollback/ausdrücklichem späteren Start, Hashfehler, Altidentität, spätere Erneuerung mit bestehender Fahrt und fremde gültige Capability ab.

Die bisherigen sieben Start-/GPS-Tests erhalten ihre Qualitäts-, Hash-, Fahrzeug- und Rollbackprüfungen; der überholte konkurrierende Start erwartet nun 409, die aktuellste erfolgreich gestartete Capability lädt weiterhin GPS hoch. Der vorhandene synthetische SQLite-Adapter unterstützt dafür zusätzlich den Transaktionsaufruf. Die neuen Endpunktprüfungen verwenden den echten libSQL-Adapter.

Gesamtstand: 647 Tests bestanden, beide TypeScript-Prüfungen und gezieltes Lint/Format erfolgreich. Exakter Archivbuild und Veröffentlichung werden nach Abschluss unten belegt.

## Grenzen und nächster Schritt

Der Vergleich schützt den während dieser Anfrage gelesenen Sessionwert. Er führt keine dauerhaft gespeicherte Start-/Pauseversion oder Auftragsquittung ein; eine vollständige zwischenzeitliche Start-/Pausefolge zurück zu NULL ist dadurch nicht als eigener Übergang erkennbar. Spätere ausdrücklich neu angeforderte Starts dürfen weiterhin erneuern. Eine verlorene HTTP-/Commitantwort bleibt möglicherweise unklar; es gibt keine automatische Wiederholung oder Garantie, dass eine Antwort noch die gegenwärtige Schicht beschreibt. Es wurde keine Production-Schicht, Position, Fahrt, Alarm oder Rechteänderung ausgelöst.

Kunden-APK 0.6.9 / Build 23 und Fahrer-APK 0.8.5 / Build 39 bleiben unverändert. Bestehende Signatur-/APK-/Emulatornachweise stammen vom zuvor geprüften Build, keine neue Geräteinstallation oder physische Prüfung. Angemeldete Mehrgeräte-/Straßen-/Hersteller-/Hintergrundprüfungen bleiben offen. Nächster unabhängiger Schritt: den tatsächlichen authentifizierten driver/heartbeat-GPS-Ablauf lokal bei nachträglicher Kontosperre und Dispatch-/Speicherfehlern prüfen. Abgeschlossene Start-/Stop-/Bereinigungsabläufe nicht erneut implementieren.
