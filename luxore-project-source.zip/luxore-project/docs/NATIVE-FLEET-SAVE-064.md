# Native Fahrzeug-Speicherung · 0.6.4 / Build 18

Die native Flottenansicht verhindert, dass ein verspätetes Neuladen den gerade gespeicherten Fahrzeugstand wieder überdeckt. Jede Listenabfrage erhält eine Revision. Vor einem Schreibvorgang, bei neuerer Abfrage und beim Verlassen wird der vorherige Stand ungültig. Bei Kontowechsel wird die gesamte Ansicht einschließlich Fahrzeugentwurf neu erstellt; alte Antworten erscheinen nicht im neuen Konto.

Der Erfolg einer Fahrzeugänderung und das anschließende Neuladen werden getrennt behandelt. Erst die bestätigte Serverantwort schließt das Formular und zeigt „Fahrzeug gespeichert“, „Fahrzeug wieder aktiviert“ oder die Archivierungsbestätigung. Scheitert anschließend das Lesen, bleiben bisher bekannte Fahrzeuge sichtbar, die Speicherung wird weiterhin bestätigt und ein ausdrücklich auf die Liste bezogener Fehler bietet erneutes Laden an. Ein fehlgeschlagener Schreibvorgang erhält dagegen den offenen Entwurf und dieselbe Wiederholungs-ID; Mehrfachbetätigung sendet keine zweite gleichzeitige Speicherung. Die bestehenden serverseitigen Flottenrechte, Kennzeichenprüfung, Optimistic-Lock- und Idempotenzprüfungen bleiben erhalten.

Das Fahrzeugformular verwendet ein festes natives Modal, SafeAreaView, scrollbaren Inhalt und Tastaturausgleich. Oberer Schließen-Knopf, Felder, Klassenauswahl und Speichern gehören vollständig zum Dialog. Eine Serverantwort einer verlassenen Ansicht setzt keinen nachfolgenden Kontostand zurück.

## Prüfungen

293 Tests bestanden. Vier neue Tests mit den tatsächlichen React-Native-Komponenten prüfen verspätete Vor-Speicher-Abfragen, bestätigte Speicherung bei anschließendem Lesefehler einschließlich Wiederherstellung ohne erneutes Schreiben, fehlgeschlagene/doppelte Schreibversuche mit gleichem Entwurf/Request-ID und Konto-Wechsel mit alter ausstehender Antwort. Alle vier scheitern nachweislich mit dem vorherigen FleetScreen; die Safe-Area-Prüfung wurde für diesen Gegenvergleich ausgeklammert, damit die tatsächlichen Logikfehler erreicht werden.

Web- und Mobile-TypeScript sowie gezieltes Lint für FleetScreen, Konfiguration und neue Tests bestanden. App.tsx enthält weiterhin die zuvor dokumentierten sechs Lint-Meldungen; kein vollständig grünes App-Lint behaupten. Die Testausführung benötigt Node 24 mit --experimental-transform-types für bestehende TypeScript-Parameter-Properties.

Die echten nativen Komponenten wurden mit isolierten synthetischen Fahrzeugen über React Native Web auf 390×844 geprüft. Formular, Klassenwahl und bestätigtes Fahrzeug sind sichtbar; document.scrollWidth = innerWidth = 390. Bilder: outputs/fleet-save-064/native-vehicle-form.png und native-save-confirmed.png. Keine Geschäftsdaten, echten Fahrerpositionen oder Provideranfragen dafür verwendet. Diese Darstellung ersetzt keinen Android-Tastatur-/Gerätetest.

## Grenzen und nächster Schritt

Keine Geschäftsdatensätze, Rechte, Migrationen, Geokodierungsbudgets oder Store-Freigaben geändert. Neue Textadressbestätigung bleibt wegen Mapbox-Permanent-Budget null und ausstehender konkreter Geoapify-Vertrags-/Konto-Zustimmung gesperrt. Bestehende Konten/Buchungen sind bereits aktiviert; keine erneute Freischaltung verlangen. Der Betreiber bleibt dem bestätigten Audi A6 HG IV 777 zugeordnet.

Die Flottenkorrektur ist nativ und benötigt eine neue APK-Installation. Kundenbuchungsformular und Live-Karte bleiben eingebettet. Angemeldeten Fahrzeug-/Schichtablauf, gesperrten Bildschirm, externe Navigation und Hintergrund-GPS auf Unternehmensgeräten prüfen; danach vollständige native Kundenbuchung und erweiterte Disposition. Vercel Hobby bleibt vor offiziellem kommerziellem Start zu klären. Interne APKs sind keine Store-Versionen.
