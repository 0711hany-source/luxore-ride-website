# Native Fahrzeug-Speicherung · 0.6.4 / Build 18

Die native Flottenansicht verhindert, dass ein verspätetes Neuladen den gerade gespeicherten Fahrzeugstand wieder überdeckt. Jede Listenabfrage erhält eine Revision. Vor einem Schreibvorgang, bei neuerer Abfrage und beim Verlassen wird der vorherige Stand ungültig. Bei Kontowechsel wird die gesamte Ansicht einschließlich Fahrzeugentwurf neu erstellt; alte Antworten erscheinen nicht im neuen Konto.

Der Erfolg einer Fahrzeugänderung und das anschließende Neuladen werden getrennt behandelt. Erst die bestätigte Serverantwort schließt das Formular und zeigt „Fahrzeug gespeichert“, „Fahrzeug wieder aktiviert“ oder die Archivierungsbestätigung. Scheitert anschließend das Lesen, bleiben bisher bekannte Fahrzeuge sichtbar, die Speicherung wird weiterhin bestätigt und ein ausdrücklich auf die Liste bezogener Fehler bietet erneutes Laden an. Ein fehlgeschlagener Schreibvorgang erhält dagegen den offenen Entwurf und dieselbe Wiederholungs-ID; Mehrfachbetätigung sendet keine zweite gleichzeitige Speicherung. Die bestehenden serverseitigen Flottenrechte, Kennzeichenprüfung, Optimistic-Lock- und Idempotenzprüfungen bleiben erhalten.

Das Fahrzeugformular verwendet ein festes natives Modal, SafeAreaView, scrollbaren Inhalt und Tastaturausgleich. Oberer Schließen-Knopf, Felder, Klassenauswahl und Speichern gehören vollständig zum Dialog. Eine Serverantwort einer verlassenen Ansicht setzt keinen nachfolgenden Kontostand zurück.

## Prüfungen

293 Tests bestanden. Vier neue Tests mit den tatsächlichen React-Native-Komponenten prüfen verspätete Vor-Speicher-Abfragen, bestätigte Speicherung bei anschließendem Lesefehler einschließlich Wiederherstellung ohne erneutes Schreiben, fehlgeschlagene/doppelte Schreibversuche mit gleichem Entwurf/Request-ID und Konto-Wechsel mit alter ausstehender Antwort. Alle vier scheitern nachweislich mit dem vorherigen FleetScreen; die Safe-Area-Prüfung wurde für diesen Gegenvergleich ausgeklammert, damit die tatsächlichen Logikfehler erreicht werden.

Web- und Mobile-TypeScript sowie gezieltes Lint für FleetScreen, Konfiguration und neue Tests bestanden. App.tsx enthält weiterhin die zuvor dokumentierten sechs Lint-Meldungen; kein vollständig grünes App-Lint behaupten. Die Testausführung benötigt Node 24 mit --experimental-transform-types für bestehende TypeScript-Parameter-Properties.

Die echten nativen Komponenten wurden mit isolierten synthetischen Fahrzeugen über React Native Web auf 390×844 geprüft. Formular, Klassenwahl und bestätigtes Fahrzeug sind sichtbar; document.scrollWidth = innerWidth = 390. Bilder: outputs/fleet-save-064/native-vehicle-form.png und native-save-confirmed.png. Keine Geschäftsdaten, echten Fahrerpositionen oder Provideranfragen dafür verwendet. Diese Darstellung ersetzt keinen Android-Tastatur-/Gerätetest.

## Grenzen und nächster Schritt

Keine Geschäftsdatensätze, Rechte, Migrationen, Geokodierungsbudgets oder Store-Freigaben geändert. Neue Textadressbestätigung bleibt wegen Mapbox-Permanent-Budget null und ausstehender konkreter Geoapify-Vertrags-/Konto-Zustimmung gesperrt. Bestehende Konten/Buchungen sind bereits aktiviert; keine erneute Freischaltung verlangen. Der Betreiber bleibt dem bestätigten Audi A6 HG IV 777 zugeordnet.

Die Flottenkorrektur ist nativ und benötigt eine neue APK-Installation. Kundenbuchungsformular und Live-Karte bleiben eingebettet. Angemeldeten Fahrzeug-/Schichtablauf, gesperrten Bildschirm, externe Navigation und Hintergrund-GPS auf Unternehmensgeräten prüfen; danach vollständige native Kundenbuchung und erweiterte Disposition. Vercel Hobby bleibt vor offiziellem kommerziellem Start zu klären. Interne APKs sind keine Store-Versionen.

## Tatsächliche APK- und Emulatorprüfung

Beide APKs 0.6.4 / Build 18 sind gebaut und auf ARM64-Bundle, Runtime-Variante, Paketkennung, eingeschränkte Berechtigungen, Backup-Sperre und Signatur geprüft. Die Signatur entspricht 0.6.3 (SHA-256 fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c). Kunden-App ohne Fahrer-Hintergrundberechtigungen; Fahrer-App mit bestehender Hintergrundortung/Foreground-Service/Fahrtalarmen. Beide als Updates ohne Deinstallation im isolierten Emulator installiert. Kunden- und Fahrer-Startbildschirm tatsächlich geladen; Fahrer drei kalte Starts. Keine Fatal-/ReactNativeJS-Absturzmeldungen. Der echte installierte Mapbox-SDK-Starttest bestätigt erwartete ConfigurationException ohne Token und erfolgreiche MapView-Konstruktion/-Freigabe nach Initialisierung. Kein echter Provideraufruf oder Standort dafür verwendet. Nach dem Instrumentierungstest Fahrer-App erneut normal gestartet und lebender Prozess bestätigt.

Der Build war wegen synchronisierter Konfliktkopien in generierten Abhängigkeits-Caches blockiert. 10.075 automatisch generierte Konfliktdateien wurden unverändert unter work/fleet-save-064/generated-conflict-backup gesichert. Beide APKs anschließend aus den bytegenau abgeglichenen Projektquellen im temporären Buildordner erzeugt. Keine Quell-, Schlüssel- oder Geschäftsdateien gelöscht.

| Datei in mobile/artifacts | Bytes | SHA-256 |
| --- | ---: | --- |
| Luxore-Ride-Test-0.6.4.apk | 55543864 | b9b4d4a8ce36b597231f8f252bbf128c271f32977e47043394771dde587a4140 |
| Luxore-Driver-Test-0.6.4.apk | 55515880 | e48b598e7b8b98ada0be4cba8cbc3f7b21c5268d0b393e162a4077210c6d9639 |

Ältere APKs bleiben erhalten. Diese Startprüfung ist kein angemeldeter Flotten-/Schichttest und kein physischer Hintergrund-GPS-Nachweis. Der Emulator wurde anschließend beendet.

## GitHub-/Vercel-Veröffentlichung

Quellbasis d161e8e, öffentlicher GitHub-Commit 7ad83b5f276d156702d8990e141f33ff165dddcd. Quellarchiv mit 425 Dateien, 7.627.447 Bytes, SHA-256 edb8707e3ff47e770221c3f3284dcb5210ceb0da3ad916b1e489915dae79a692. Archiv, SOURCE-VERSION und README bytegenau mit dem öffentlichen Stand abgeglichen. Keine APKs, Signierschlüssel, Umgebungsgeheimnisse oder untracked ROADMAP-Kopie veröffentlicht. Tatsächlicher sauberer Next.js-Archivbuild bestanden. Vercel 7wqCa4vnNeBf3V72jtmNNLGBDvjB zeigt Ready / Latest / Current Production unter luxoreride.de. Nachweis: outputs/fleet-save-064/vercel-production-ready.png. Der separate Nachweis-/Dokumentationscommit ändert keinen Runtime-Code; öffentliche Quellbasis bleibt d161e8e.

Live-Health nach Veröffentlichung bestätigt databaseConnected/accountsReady/bookingConfigured true; Konto-API anonym ohne Konto oder Betreiberrecht, registrationReady true. Kunden-, Fahrer- und Dispositionsseite HTTP 200. Geschützter interner Download-Entwurf mit zwei APKs: https://github.com/0711hany-source/luxore-ride-website/releases/tag/untagged-a08d174d75226697f878. Beide von GitHub angezeigten Asset-SHA-256 stimmen mit den lokalen geprüften Dateien überein. Keine öffentliche APK-Veröffentlichung oder zusätzliche Personenzugriffe; bestehendes berechtigtes GitHub-Konto erforderlich. Ältere Entwürfe/Links unverändert. Bild: outputs/fleet-save-064/private-apk-downloads.png. Kein neuer E-Mail-Versand in diesem Durchlauf. Fünf-Stunden-Automation auf 0.6.4, native Flottenkorrektur und 293 Tests berichtigt; Rhythmus unverändert. README-Testbefehl im lokalen Nachweiscommit um die erforderliche TypeScript-Transformation ergänzt.
