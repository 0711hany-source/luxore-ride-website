# Schichtgebundene native Alarmplanung · Fahrer 0.8.0 / Build 34

Eine tatsächliche Lücke erlaubte noch die Planung eines alten Fahrtalarms, wenn Pause oder Schichtwechsel während nativer Berechtigungs-/Kanalprüfung oder während des Entfernens eines alten Alarms erfolgten. Der gemeinsame Controller prüfte die Freigabe vor und nach present, konnte die dazwischen liegenden nativen Wartezeiten aber nicht absichern. Auch der vom Ortungsdienst übergebene Prüfcallback erkannte eine erneuerte Capability derselben sessionId oder einen bereits begonnenen neuen Start vor dem Speichern der neuen Freigabe nicht.

Der Controller reicht seinen tatsächlichen isCurrent-Callback jetzt bis in die native present-Funktion. Diese prüft nach der Berechtigungs-/Kanalabfrage und nach dem Entfernen des alten Alarms erneut die aktuelle Freigabe, unmittelbar vor einem neuen scheduleNotificationAsync-Aufruf. Die bestehende ursprüngliche Deadline und Zwei-Sekunden-Grenze werden weiterhin erst nach diesen Wartezeiten geprüft. Der Callback des Ortungsdienstes verlangt zusätzlich die ursprüngliche LocationLifecycle-Version und exakt denselben nativeToken neben sessionId und Ablaufzeit. So invalidiert bereits der Beginn einer Pause oder eines neuen Starts alte Antworten, auch bevor neue geschützte Daten gespeichert sind.

Das betrifft ausschließlich die Gültigkeit alter Alarmarbeit. Kein GPS-Rohpunkt, Cachefilter, Fahrten-/Schicht-Schreibvorgang, keine Berechtigung oder Plattform-/Flottenrolle wird verändert. Neue gültige Schichten können danach weiterhin melden; Reihenfolge, einmalige Alarme und Ablaufprüfung bleiben erhalten. Kein neuer Provider oder Server-/Datenbankschritt.

## Prüfungen und Grenzen

Sechs zusätzliche Verhaltenstests in den tatsächlichen nativen Alarm-/Ortungsdienstmodulen mit isolierten Expo-Notifications-/Location-/TaskManager-/SecureStore-Adaptern, kontrollierter Uhr und abgefangenem fetch. Fünf scheitern vorher und bestehen mit der Korrektur:

- Pause während nativer Berechtigungsprüfung: kein alter Planungsaufruf und keine gespeicherte Zustellbestätigung.
- Schichtwechsel während nativer Alarmbereinigung: ebenso keine alte Planung.
- Eine neue gültige Schicht meldet anschließend, ohne vorher den alten Alarm einzuplanen.
- Tatsächlicher Upload-Prüfcallback lehnt erneuerten Token derselben sessionId ab.
- Begonnener neuer Start invalidiert den alten Callback bereits während ausstehender Berechtigungsantwort und unverändert altem gespeicherten Record.
- Bereits begonnene native Planung wird nach Pause weiterhin bereinigt, ohne seenId zu speichern; zwei tatsächliche native Entfernungsaufrufe geprüft.

Die Prüfung liegt vor dem nativen Planungsaufruf. Ein bereits vom Betriebssystem angenommener Aufruf kann erst nach dessen Abschluss bereinigt werden; kein rückwirkendes Verhindern eines bereits begonnenen Tons oder garantierte OS-Zustellzeit behaupten. Tatsächliche angemeldete Ton-/Hersteller-/Schicht-/Mehrgeräte-/Straßen-/Hintergrund-GPS-Prüfungen bleiben offen. Alle Tests lokal/synthetisch, keine Production-Alarme, Schichten, Punkte, Fahrten oder fremde Änderungen ausgelöst.

555 Tests, beide TypeScript-Prüfungen sowie gezieltes Lint und Format bestanden. Fahrer-APK 0.8.0 / Build 34 außerhalb synchronisierter Quellen mit unverändertem Lockfile und allen 21 direkten Paketversionen gebaut (Gradle 3m 27s). Der vollständige Importbaum mit 85 Runtime-/Asset-/Konfigurationsdateien ist bytegenau abgeglichen. Bestehendes Signaturzertifikat SHA-256 fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c und Manifest-Berechtigungen unverändert; Variantenprüfung bestanden.

APK: 56217840 Bytes, SHA-256 2b5653839c48c9a4dc836b91ecfa7f90b890de3c2bf9f6f52c28cb6d38ed8166. Im isolierten Emulator als Update über 0.7.9 ohne Deinstallation installiert; drei anonyme Kaltstarts ohne Absturz. Kunde unverändert 0.6.9 / Build 23. APK ausschließlich geschützter interner GitHub-Entwurf, keine öffentliche Binary-/Store-Freigabe oder Installation auf Nutzerhandys. Website-Veröffentlichung installiert keine APK.

Exakter Archivbuild bestanden (7,0 Sekunden Kompilierung, 4,6 Sekunden TypeScript). Nächster unabhängiger Schritt: Pause/Wiederaufnahme der nativen Standortfreigabe bei Fehlern der Benachrichtigungs-APIs auf einen konkret reproduzierbaren Fehler prüfen; keine erneute Implementierung der abgeschlossenen Deadline-/Schichtbindung.


## Veröffentlichung und Nachweise

Runtime 30690533b1e93ee1d7f96344933d5aa1d1360af6, öffentliches GitHub e06464400a510d3aa7963ca933bc6a5648e22e90. Alle drei öffentlichen Paketdateien bytegenau verglichen; Archiv 521 Dateien, 7928014 Bytes, SHA-256 2d5a310284e377f26974f1ff3b92bba0947f52046a4fab59704d0e068cad3ec1. Vercel FdFAWhsAyagJWgcwJUJQiUh388wx als Ready/Latest/Current Production unter luxoreride.de mit diesem Commit bestätigt, GitHub-Status success. Fünf reine health/account/Kunden-/Fahrer-/Dispositions-GETs liefern 200; Datenbank/Konten/Buchung bereit. Nachträgliche Dokumentation dieser Veröffentlichung verändert Runtime und geprüftes öffentliches Archiv nicht.

Lokal abgelegte Prüfungen unter work/native-offer-session-080, sichtbarer Deploymentnachweis unter outputs/native-offer-session-080/vercel-ready.png. Emulator nach drei Starts beendet. Physische angemeldete Prüfungen bleiben offen.

Geschützter interner APK-Entwurf: https://github.com/0711hany-source/luxore-ride-website/releases/tag/untagged-e95332eb1b8f53167793. Nach zwei fehlgeschlagenen GitHub-Speicherübertragungen ist der Anhang im gespeicherten Entwurf erfolgreich hochgeladen. GitHub zeigt den identischen SHA-256-Digest am tatsächlichen Anhang; Nachweis outputs/native-offer-session-080/apk-draft.png. Keine öffentliche Release-Veröffentlichung.
