# Native Kunden-Live-Karte: Datenfluss · 11. Oktober 2026

## Abgeschlossener Baustein

`mobile/src/customer-live.ts` enthält einen kontogebundenen, ausschließlich lesenden `CustomerLiveController` und die reine Darstellungsregel `customerMapSnapshot`. Dieser Baustein ist noch nicht in App.tsx angeschlossen; die installierten Apps verwenden weiterhin die vorhandene Kunden-Live-Webansicht. Keine neue APK erzeugt, keine sichtbare Kartenumstellung als ausgeliefert darstellen.

Eine ausdrücklich gewählte Fahrt bleibt ausgewählt, auch wenn sie endet. Fehlt sie in der eigenen Serverliste, wird niemals ersatzweise eine andere Fahrt angezeigt. Ohne ausdrückliche Auswahl wird die neueste aktive eigene Fahrt gewählt. Antworten mit fremdem Eigentümer werden ausgeschlossen. Hintergrundwechsel und Fahrtauswahl brechen alte Leseanfragen ab; Rückkehr startet sofort neu. Ein alter finally-Block kann keine neuere Anfrage freigeben. Disposal löscht den Stand und verwirft verspätete Antworten.

Der bestätigte Fahrtstatus wird vor der optionalen Umgebungssuche veröffentlicht. Die drei anonymisierten Fahrzeugpunkte werden nur beim Status requesting über bookingId und tatsächliche Fahrzeugklasse angefragt, ohne Identität/Telefon oder Zusatzfelder zu übernehmen. Fehler oder Wechsel der Fahrt entfernen alte Umgebungspunkte. Reservierung, Stornierung, Abschluss und fehlende Verfügbarkeit erhalten weder Live-Fahrerpunkt noch Kontaktfreigabe. Bei Netzverlust bleiben bekannte Details lesbar; Live- und Kontaktanzeigen werden ausgesetzt. 401/403 in beiden Lesewegen löschen auch bekannte Fahrtdetails vollständig.

Bestätigte ältere Fahrtstände dürfen einen bereits neueren Status nicht zurücksetzen. Ältere Telemetrie desselben zugeordneten Fahrers darf dessen Marker nicht zurückbewegen; die restlichen aktuellen Fahrtfelder werden trotzdem übernommen. Live-GPS benötigt passende Fahrer-ID, gültige Koordinaten, Genauigkeit 0–100 m und Zeitpunkt innerhalb von 45 Sekunden, höchstens fünf Sekunden in der Zukunft. Der letzte erfolgreiche Fahrtstand und Umgebungspunkte verfallen für Live-Anzeigen nach 20 Sekunden. Die Serverzeit aus dem vorhandenen Bookings-Endpunkt wird mit der lokalen Empfangszeit gekoppelt, damit eine um Stunden abweichende Handyzeit keinen aktuellen Fahrer versteckt. Rückwärts springende lokale Zeit sperrt Live bis zur nächsten erfolgreichen Antwort.

## Integrationsvertrag für den nächsten Schritt

- StrictMode-Effect-Cleanup stoppt nur setActive(false); eine entsorgte Instanz nicht wiederverwenden. Pro Konto/Sitzung eine eigene Controller-Instanz: bei Kontowechsel alte Instanz stoppen und entsorgen; keine Übernahme alter Profile oder Fahrten.
- `bookings(signal)` über `nativeApi('bookings', token, undefined, undefined, signal)` an den bestehenden eigenen Server binden. Antwort enthält bookings und serverTime.
- `nearby(body, signal)` über `nativeApi('nearby', token, body, undefined, signal)` binden. Dies ist trotz POST eine reine Leseabfrage und darf beim Verlassen abgebrochen werden.
- Bildschirm/AppState steuern setActive; sichtbare Ansicht höchstens alle fünf Sekunden aktualisieren. Keine Hintergrund-Polls oder eigenen Kunden-GPS-Schreibvorgänge durch diesen Baustein. Die Umgebungssuche bleibt mit zwölf regelmäßigen Aufrufen pro Minute unter dem bestehenden Limit 25; manuelle Wiederholungen müssen separat begrenzt werden.
- Die Darstellung regelmäßig mit der aktuellen lokalen Zeit neu ableiten, damit alte Marker auch ohne neue Antwort verschwinden. Nicht nur den gecachten Rohstand zeichnen. Keine künstlichen Ankunftszeiten oder Simulation echter Fahrzeuge.
- Helle native Streets-v12-Karte mit vorhandener Route, Abhol-/Zielpunkt, zugeordnetem Fahrer beziehungsweise drei ungefähren Suchfahrzeugen anschließen. Bestehenden SDK-Import-/Token-/Startschutz erhalten. Bei aktiver Fahrt Fahrerinfo, Sicherheitszugang und Bordkarte einplanen; Stornierung weiter ausschließlich durch vollständiges Wischen.

## Prüfungen und Grenzen

16 neue Controller-/Darstellungsprüfungen: eigene/fehlende Fahrtauswahl, fahrtspezifische Umgebungssuche, maximal drei anonyme Punkte, Hintergrund/Rückkehr, verspätete Antworten und finally-Blöcke, Auswahlwechsel während Umgebungssuche, Netzverlust/Erholung, 401/403 auch nach erfolgreicher Fahrtabfrage, End-/Reservierungsstatus, veraltete/future/ungenaue/fremde GPS-Punkte, älterer Fahrtstatus, ältere Telemetrie bei weiterhin neuen Fahrtfeldern, Disposal, ungültige Listen und Serverzeit sowie um sechs Stunden abweichende Handyzeit. Synthetische Antworten, keine Production-Daten oder Testfahrt.

Die native Kunden-Kartenoberfläche, Gesten, tatsächlicher Mapbox-SDK-Lauf und angemeldete physische Mehrgeräteprüfung sind damit noch nicht umgesetzt/geprüft. GPS-Punktglättung auf der Kundenkarte bleibt Aufgabe der Kartendarstellung; dieser Datenbaustein behauptet keine Navigation oder künstliche Bewegung. Er enthält keine Schreibaktionen und kann keine Buchung stornieren oder erzeugen. Kunden-APK bleibt 0.6.7 / Build 21, Fahrer-APK 0.6.4 / Build 18. Keine Migration oder Anbieter-/Tarif-/Budgetänderung.

Alle 382 Tests sowie Web-/Mobile-TypeScript und gezieltes Lint für den neuen Baustein und seine Tests bestanden. ## Veröffentlichungsnachweis

Lokaler Quell-Commit `65e7f76eebdb25a0edba6034182e8027294cee07`; GitHub `b43406dd3deef3a31ebac6834fa3b96119955691` im bestehenden Repository. Drei veröffentlichte Quellartefakte bytegenau geprüft. Archiv: 458 Dateien, 7.722.591 Bytes, SHA-256 `159f61bab69e9739536ac15f87a8c20644b9c3df41672775b6df060b9e6a2a13`. Exakter paketierter Quellstand bestand einen frischen Next.js-Produktionsbuild.

Vercel bestätigt Ready / Latest / Current Production unter luxoreride.de für `4dkH66Um5PMxZM33vZNcF3yRv9Lu` mit dieser GitHub-Quelle. Screenshot: `outputs/customer-live-state/vercel-ready.png`. Der neue native Baustein ist im veröffentlichten Quellarchiv enthalten, wird aber noch von keiner App-Oberfläche verwendet; Website-Veröffentlichung installiert keine APK.

Fünf reine Live-Leseprüfungen bestehen mit HTTP 200: Health (Datenbank verbunden, Konten/Buchungen bereit), anonyme Konto-API (Registrierung bereit, kein Konto/keine Betreiberrechte), Kunden-App, Fahrer-App und Disposition. Keine Production-Testfahrt, -GPS-Abfrage einer echten Fahrt oder Profiländerung. Die Automation bleibt ACTIVE alle fünf Stunden und kennt den offenen nächsten Integrationsschritt. Diese nachträgliche Dokumentation ändert keinen veröffentlichten Runtime-Code.
