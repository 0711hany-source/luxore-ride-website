# Stornierung nach verlorener Antwort · 10. Oktober 2026

## Fehler und Korrektur

Wenn die Stornierung bereits gespeichert war und ihre Antwort auf dem Handy verloren ging, antwortete die Wiederholung mit HTTP 409 statt die gespeicherte Stornierung zu bestätigen. Bei zwei Aufrufen im selben Millisekunden-Zeitfenster konnte außerdem die zeitbasierte Event-Bedingung einen zweiten Stornierungs-Protokolleintrag erzeugen.

Der Kunden-Buchungsendpunkt verwendet jetzt eine libSQL-Schreibtransaktion. Nur eine tatsächliche Änderung aus reserved/requesting/accepted/arrived setzt den Stornierungszeitpunkt, entfernt Kundenortung, zieht offene Fahrerangebote zurück und schreibt ein Event. Bei keiner Änderung wird innerhalb desselben Schreibzugriffs ausschließlich eine bereits stornierte Fahrt desselben angemeldeten Kunden bestätigt. Die Wiederholung verändert weder Zeitstempel, Angebote noch Historie. Fremde/fehlende Fahrten sowie riding/completed/unavailable bleiben mit derselben allgemeinen HTTP-409-Meldung gesperrt. Ein Fehler beim Protokolleintrag rollt die gesamte Änderung einschließlich Angebot und Kundenortung zurück.

## Prüfungen

Sechs neue Integrationstests verwenden den tatsächlichen Buchungsendpunkt, den tatsächlichen libSQL-Adapter und sämtliche lokalen SQL-Migrationen. Geprüft: verlorene Antwort und erneuter Aufruf im selben Millisekunden-Zeitfenster; späterer unveränderter Replay; Eigentümertrennung/fehlende Fahrt; nicht stornierbare Status; atomarer Rücklauf durch erzwungenen Event-Fehler; alle vier erlaubten Ausgangsstatus. Drei Regressionstests scheitern im vorherigen Stand mit 409 statt 200 und bestehen mit der Korrektur. Gesamt 342 Tests bestanden, Web-TypeScript und gezieltes Lint für Endpunkt/Test bestanden.

Keine tatsächliche Production-Fahrt oder Stornierung, Konto-/Fahrzeug-/GPS-Datenänderung, Migration, neue Rechte, Anbieterbudgets oder Gebühren. Diese Serveränderung wirkt auch mit den vorhandenen Apps; keine neue APK nötig. Kunden-APK bleibt 0.6.6 / Build 20, Fahrer-APK 0.6.4 / Build 18. Angemeldete physische Mehrgeräte-/Schicht-/Hintergrund-GPS-Prüfungen bleiben offen. Nächster nativer Schritt: Kunden-Live-Karte und freie Kartenpunktwahl.
