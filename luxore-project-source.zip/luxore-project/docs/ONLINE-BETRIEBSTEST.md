# Aktueller interner Betriebstest – 05.10.2026

Die Site ist öffentlich erreichbar; Kunden und Fahrer verwenden ihre eigenen Gerätesitzungen ohne ChatGPT-Anmeldung. Die Disposition bleibt für freigegebene Flottenbesitzer, Stellvertretungen und den Plattformbetreiber geschützt. Fahrzeuge gehören jeweils einer Flotte. Nur deren freigegebene Fahrer können sie auswählen. Das ist ein interner Teststand, keine bestätigte Produktionsreife.

## Welche Version verwenden?

- Fahrer: `mobile/artifacts/Luxore-Driver-Test-0.4.2.apk`. Über die bisherige Fahrer-Testapp installieren, nicht vorher deinstallieren oder App-Daten löschen. Dadurch bleibt die Gerätezuordnung erhalten. Die Versionsänderung ist für die nativen GPS-Verbesserungen erforderlich.
- Kunde: Kunden-Testapp 0.3.1 kann weiterverwendet werden. Paket: `mobile/artifacts/Luxore-Unternehmenstest-Android-0.3.1.zip`.
- Flottenkorrekturen vom 01.–03.10. sind Änderungen der Online-Oberfläche und des Servers. Dafür die App vollständig schließen und neu öffnen; keine neue APK nötig.
- Fahrer 0.4.2 enthält Hintergrundortung und lokale Fahrtalarme über den laufenden Standortdienst. Das ist kein unabhängiger FCM-/APNs-Pushdienst. Nach erzwungenem Beenden, bei fehlendem GPS oder unterbrochener Verbindung sind zeitnahe Alarme nicht zugesichert.
- Eine native iOS-App ist noch nicht veröffentlicht. Die Weboberflächen sind im Browser erreichbar.

## Gerätetest in dieser Reihenfolge

Benötigt: ein Kundengerät, zwei Fahrergeräte und Zugriff der Flottenleitung auf die Disposition. Namen, Klasse, Kennzeichen und erlaubte Standort-/Benachrichtigungsrechte vor dem Test kontrollieren. Der folgende Ablauf ist ein bewusst koordinierter interner Test; er erzeugt in der veröffentlichten App tatsächliche gespeicherte Buchungen.

| Schritt | Aktion | Erwartetes Ergebnis |
| --- | --- | --- |
| 1. Fahrzeuganlage | Disposition → eigene Flotte → Fahrzeuge → Auto hinzufügen; Modell, Kennzeichen und mindestens eine Klasse angeben | Erfolgsmeldung; Fahrzeug bleibt nach erneutem Öffnen in der richtigen Flotte sichtbar. Bei Fehler bleiben die Eingaben erhalten und eine konkrete Meldung erscheint. |
| 2. Fahrzeugwahl | Beide freigegebenen Fahrer wählen jeweils ein unterschiedliches Fahrzeug ihrer Flotte | Ausgewähltes Auto und seine Klassen stimmen; ein bereits belegtes Auto kann der andere Fahrer nicht gleichzeitig übernehmen. |
| 3. Online | Standortrechte auf jedem Fahrerhandy prüfen und online gehen | Nach frischem Standort online; keine endlose Ladeanzeige. Standort wird in der Disposition aktuell dargestellt. |
| 4. Bestellung | Kunde gibt Abholung/Ziel ein, prüft Route und Kilometerpreis, wählt Klasse sowie Wünsche und bestellt | Eine Buchung entsteht direkt. Während der Suche werden nur tatsächlich verfügbare passende Fahrer angezeigt; bis zu drei, näherungsweise ohne persönliche Daten. |
| 5. Weitervermittlung | Der zuerst benachrichtigte Fahrer lehnt ab | Dasselbe Angebot wird diesem Fahrer nicht erneut zum Annehmen angezeigt; es geht an den nächsten geeigneten freien Fahrer. |
| 6. Annahme | Zweiter Fahrer nimmt über die vorgesehene Wischgeste an | Kunde sieht diesen Fahrer und Status. Der erste Fahrer kann die Fahrt nicht mehr übernehmen. Wünsche sind beim zugeordneten Fahrer sichtbar. |
| 7. Fahrt | Ankunft, Fahrtbeginn und Abschluss durchführen | Kunden- und Fahrerstatus passen zusammen. Am Ende erscheint der zu kassierende Betrag. Während der Fahrt ist ein Fahrzeugwechsel gesperrt. |
| 8. Zahlung | Kassieranzeige prüfen; Zahlung erst nach tatsächlichem Eingang als bar bzw. separates Terminal bestätigen | Einmalige Erfassung, korrekter Tages-/Flottenumsatz. Ein erneuter Bestätigungsversuch erhöht den Umsatz nicht. Keine automatische Kartenbelastung durch diesen Knopf. |
| 9. Übergabe | Fahrer geht offline und gibt das Auto frei; anderer Mitarbeiter übernimmt es | Fahrzeugwechsel möglich. Eine alte Freigabe für den vorherigen Fahrer kann das Auto nicht dem neuen Fahrer entziehen. |
| 10. Reservierung | Separate Fahrt für einen späteren Termin anlegen, danach bei Bedarf stornieren | Sie bleibt zunächst reserviert und erscheint nicht sofort als Sofortfahrtangebot. Keine zugesicherte Reservierungsaktivierung ohne laufende Abrufe bzw. gesondert verifizierten Zeitplaner. |

## Hintergrund und Navigation gesondert prüfen

Mit Fahrer 0.4.2 die Berechtigungen „Genauer Standort“, Hintergrundstandort und Benachrichtigungen kontrollieren. „Alarm testen“ ist nur ein Testhinweis, keine Fahrt. Danach während einer koordinierten internen Anfrage fünf Minuten Sperrbildschirm und anschließend Google Maps testen: Standortaktualität in der Disposition, Angebotsalarm, Öffnen und aktueller Angebotsstatus. Pause muss die Standortübertragung beenden. Netz aus/an und Rückkehr in die App gesondert prüfen.

Für die Navigation Start aus dem Stand, Geradeausfahrt, Abbiegen und Kreisel dokumentieren. Handy-Modell, Android-Version, installierte APK-Version, ungefähre Uhrzeit und beobachteten GPS-Nachlauf festhalten. Die Benutzerangaben bestätigen bisher einen Test in der Android-Fahrer-APK, aber noch keinen erfolgreichen Gesamt-/Hintergrundtest nach allen Korrekturen.

## Was bereits automatisiert geprüft wird

`tests/fleet-api-local.py` prüft zwei getrennte Flotten, Fahrzeuganlage und Wiederholung, konkurrierende Änderungen, Mehrfachklassen, exklusive Auswahl, Fahrerfreigabe/Übergabe, Archivieren/Wiederaktivieren, Rollen und historische Umsätze. `tests/mobile-api-local.py` ergänzt den Kundenablauf mit zwei Fahrerzugängen, Ablehnung und Weitervermittlung, Annahme bis Fahrtabschluss, Zahlung und Reservierungstrennung. Diese Tests verwenden ausschließlich lokale, isolierte Geräteidentitäten und synthetische Routen; sie verändern keine produktiven Buchungen. Sie prüfen keine Android-Gesten, Gerätesensoren oder reale Mapbox-Verkehrsqualität.

Am 05.10.2026 ist der erweiterte mobile HTTP-Gesamtablauf erfolgreich durchgelaufen. Die Flottentests sind zuletzt am 03.10. nach den veröffentlichten Korrekturen bestanden; sie wurden bei dieser reinen Test-/Dokumentationsaktualisierung nicht unnötig erneut ausgeführt.

## Noch offen vor breiterem Betrieb

Der Nutzer hat die neue Fahrzeuganlage am 05.10.2026 noch nicht getestet. Außerdem fehlen bestätigte Mehrgeräte-/Hintergrundtests, unabhängige Reservierungsaktivierung, Wiederherstellung eines Zugangs nach Verlust der Gerätedaten und eine produktive In-App-Zahlungsanbindung. Die internen Android-Pakete sind keine Play-Store-Releases; iOS/TestFlight bleibt anschließend vorgesehen.

## Ergebnis festhalten

Pro Schritt: bestanden / Fehler / nicht getestet. Bei Fehlern den genauen Text, App-/Geräteversion und die unmittelbar vorherigen Schritte festhalten. Ein Screenshot ohne Kundendaten kann helfen. Die ursprüngliche Meldung „Speichern funktioniert nicht“ ist ohne erneuten Gerätetest weiterhin nicht als konkret behoben bestätigt.

---

# Historisches Protokoll: Online-Betriebstest 0.2 – 23.09.2026

Die folgenden Angaben beschreiben nur den damaligen Stand. Für aktuelle Tests gilt die Anleitung oben; insbesondere Flottenrechte und Android-Hintergrundfunktionen wurden seitdem erweitert.

## Installieren und ausprobieren

Die Android-Apps 0.2 ersetzen einmalig die bisherigen Offline-Anfrage-APKs. Die Paketnamen und der interne Test-Signaturschlüssel bleiben gleich. Künftig lädt die App die Online-Oberfläche beim Öffnen vom Server. Änderungen an nativen Funktionen/Berechtigungen und am Launcher-Icon benötigen weiterhin eine neue APK. Kein Expo-Konto ist für diese WebView-Ausbaustufe erforderlich.

- Kunde: `/mobile/customer`, eigene langlebige Gerätesitzung ohne ChatGPT-Anmeldung. Freie Adresssuche, GPS-Abholung, echte Mapbox-Straßenroute, Kilometerpreis, Klasse, Name und Telefonnummer, Buchung direkt in der Datenbank.
- Fahrer: `/mobile/driver`, eigene Gerätesitzung. Fahrerprofil mit einer oder mehreren Klassen einreichen. Betreiber prüft Name, Telefon, Fahrzeug, Kennzeichen und beantragte Klassen, bevor er freigibt.
- Disposition: `/disposition`. Nur der konfigurierte Betreiber erhält Verwaltungszugriff. Hier bleibt die Betreiber-Anmeldung geschützt; Kunden und Fahrer brauchen sie nicht.
- Freigegebener Fahrer schaltet Standortübertragung ein und lässt App/Fahreransicht geöffnet. Es werden nur GPS-Positionen mit höchstens 100 m Ungenauigkeit akzeptiert.
- Kunde sucht Sofortfahrt. Bis zu drei nächste passende, freie Fahrer erscheinen als Fahrzeugmarkierungen. Vor der Zuweisung ungefähr gerastert (ca. 200–330 m), ohne Namen, Kennzeichen oder Telefonnummer. Keine simulierten Fahrzeuge, keine erfundenen Verfügbarkeiten. Nächste nach Luftlinie, nicht Anfahrtszeit.
- Angebot geht einzeln zum nächsten Fahrer (25 Sekunden). Ablehnung/Timeout führt zum nächsten Kandidaten. Annahme, Ankunft, Fahrtbeginn und Abschluss werden gemeinsam gespeichert. Abruf alle drei Sekunden, GPS etwa alle zehn Sekunden.
- Zugewiesener Fahrer und Kunde sehen die Kontaktdaten während der aktiven Fahrt. Route, Preis und Status werden serverseitig geprüft. Keine E-Mail wird zur Buchung benötigt.
- Zahlung beim Fahrer. Keine integrierte Kartenbelastung oder Zahlungsabrechnung.

## Grenzen dieser ersten nutzbaren Ausbaustufe

- Kein verlässlicher Hintergrundbetrieb oder Push bei gesperrtem Bildschirm. Fahrer-App geöffnet und Bildschirm eingeschaltet lassen. Nach veralteter Position gibt es keine neuen Angebote.
- Reservierungen liegen getrennt von Sofortfahrten in der Datenbank. Aktivierung ab 15 Minuten vorher erfolgt durch laufende Kunden-/Fahrer-/Dispositionsabrufe. Noch kein unabhängiger Zeitplaner; Disposition offen halten. Reservierung erst durch Fahrerzuweisung bestätigt.
- Gerätesitzung läuft nach 180 Tagen ab. Löschen der App-Daten/Neuinstallation löscht den Zugriff auf bisherige Buchungen bzw. das Fahrerprofil. Ein neues Fahrerprofil muss erneut freigegeben werden. Noch keine Konto-Wiederherstellung.
- Test-APKs sind intern mit dem bisherigen Debug-Testschlüssel signiert, keine Play-Store-Releases. Android ARM64, mindestens Android 7. Kein physischer Mehrgeräte-/GPS-Test durchgeführt; kein Nachweis für Produktionsreife.
- iOS-App noch nicht gebaut; Web-App nutzbar im Browser.

## Technische Prüfung

- Echte lokale HTTP-API-Tests mit drei getrennten Cookie-Jars: Sitzung ohne Login, Origin-Schutz, Sitzungsablauf, Eigentümertrennung, Betreiberrechte, Fahrerfreigabe, mehrere Klassen, anonyme Näherungsmarker, vollständiger Buchungs-/Fahrtstatusablauf.
- SQLite-Tests: Preisberechnung, atomare Annahme, Angebote/Timeout, doppelte Zuordnung ausgeschlossen, Reservierungstrennung, mehrere Klassen, Änderung der Berechtigung vor Annahme.
- Keine synthetischen Fahrten oder Fahrer werden auf der veröffentlichten Datenbank angelegt.

## Zugriff

Öffentlicher Zugang ist für die ausdrücklich gewünschten Apps ohne ChatGPT-Anmeldung nötig. Einzelne Buchungen, Fahrerprofile, Angebote und Disposition bleiben serverseitig berechtigt. Die APK enthält keinen Betreiber- oder Sites-Bypass-Schlüssel. Geräteschlüssel stehen nur im HttpOnly-Cookie; Datenbank speichert SHA-256-Hashes.

## Veröffentlichung verifiziert

23.09.2026: Öffentlicher Aufruf beider App-Routen HTTP 200 ohne ChatGPT-Anmeldung. Neue Gerätesitzung HTTP 201, eigene Konfiguration HTTP 200, Zugriff auf Disposition als Gast HTTP 403. Echte Mapbox-Adresssuche und Route: Opernplatz 1 bis Hugo-Eckener-Ring 1, 21.067 m, Business 52,67 €, First 73,73 €, Van 63,20 €. Keine Fahrt im veröffentlichten System gebucht. Kunden- und Fahrer-APK 0.2.0, Paket/Version/Signatur/ARM64-Bundle geprüft. ZIP inklusive Installation und SHA-256-Prüfsummen erstellt. Physischer Gerätetest weiterhin offen.
