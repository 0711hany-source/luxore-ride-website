# Atomare Fahrerfreigabe in der Disposition · 12. Oktober 2026

## Problem und Korrektur

Die Fahrerfreigabe beziehungsweise Rücknahme und offene Angebotsrücknahme wurden bisher zuerst gespeichert. Scheiterte der anschließende Protokolleintrag, erhielt die App HTTP 500 trotz veränderter Freigabe. Die Dispositionsberechtigung und Kontosperre waren außerdem außerhalb des eigentlichen Schreibzugriffs gelesen.

POST /api/mobility/operations speichert jetzt innerhalb einer libSQL-Schreibtransaktion: aktuelle Dispositionsberechtigung lesen, aktiven Kontostatus der Leitung prüfen, Zielkonto und Flottenmitgliedschaft prüfen, Freigabe ändern, offene Angebote bei Rücknahme zurückziehen und Audit speichern. `operatorScope` kann den gleichen Transaktions-Datenbankzugang verwenden; bestehende Aufrufer behalten die bisherige Standardverbindung. Ein Speicher-/Auditfehler rollt alle Änderungen zurück. Der mutierende SQL-Guard prüft zusätzlich den aktuellen Ziel-Kontostatus bei neuer Freigabe. Keine neue Freigabe für gesperrte oder zur Löschung vorgemerkte Konten.

Wiederholte identische Freigabe bestätigt den vorhandenen Zustand ohne Auditduplikat und ohne eine bestehende Online-/GPS-Schicht zu stoppen. Besitzer und Stellvertreter bleiben auf ihre bestehende Flotte beschränkt; normale Mitarbeiter erhalten keine Dispositionsrechte. Der bestehende Betreiberzugang behält seinen Umfang. Rücknahme bleibt bei Online-Schicht, laufender Fahrt oder offener Abschlusszahlung gesperrt. Keine echte Freigabe, Rechtezuordnung, Fahrt, Profil-/Fahrzeugänderung oder E-Mail in Production ausgelöst. Bestehende Konten, Flotten, Fahrzeuge, Altbestand und Freigaben bleiben unverändert.

## Prüfungen

Sieben zusätzliche tatsächliche Endpunkt-/libSQL-Prüfungen verwenden den echten SQLite-Adapter und die echte Audit-Funktion mit isolierter Identität: fehlgeschlagener Audit-INSERT bei Freigabe, Rücknahme und Angebotsrücknahme; erfolgreiche identische Wiederholung; Besitzer-/Stellvertreter-/Betreiberscope und fremde Flotte; Erhalt der aktiven Online-/GPS-Schicht bei wiederholter Freigabe; Einsatz-/Zahlungssperren; gesperrtes Ziel-/Leitungskonto, fehlendes Profil und ungültige Anfrage; Entzug der Stellvertretung vor dem Schreibzugriff. Der vorherige Endpunkt scheitert an vier dieser sieben Prüfungen; korrigiert bestehen alle sieben. Baseline wird in einem isolierten Testmodul geladen, keine Runtime-Datei dafür ersetzt.

Gesamtstand 413 Tests; Web-/Mobile-TypeScript, gezieltes Lint und Formatprüfung bestanden. Tests greifen auf synthetische lokale Datensätze zu und erteilen keine realen Freigaben. Kein neues Datenbankschema oder neue APK nötig: Kunden-APK bleibt 0.6.9 / Build 23, Fahrer-APK bleibt 0.6.4 / Build 18. Der frische Build des exakt veröffentlichten Quellarchivs ist bestanden; Veröffentlichungsnachweise unten. Physische angemeldete Mehrgeräte-/Bestell- und Fahrer-Hintergrund-GPS-Prüfungen bleiben offen; erweiterte native Disposition ist damit nicht vollständig implementiert.

Danach sichtbare native Disposition für die bestehenden Freigabe-/Teamabläufe ausbauen oder konkrete Flottenfehler schließen. Reale Einsatz-, Bestands-/Zahlungs- und Hintergrund-GPS-Prüfungen auf Unternehmenshandys sind weiterhin erforderlich.


## Veröffentlichungsnachweis

Lokaler Runtime-Commit `7e111d0`, öffentlicher GitHub-Commit `704cec70ff02813c83b0c2cd52af75ae189c3081`. Alle drei veröffentlichten Artefakte bytegenau abgeglichen. Archiv: 474 Dateien, 7.767.136 Bytes, SHA-256 `b4466a96a437a8cd78df81f42583f9ecea9a9cba67ce8396093acaa58092b872`. Vercel `Gm8mWbJRuRmHyBEGpg6V5HC72dc2` bestätigt Ready / Production mit dieser Quelle und luxoreride.de; Nachweis outputs/driver-approval/vercel-ready.png. Fünf reine GET-Prüfungen liefern HTTP 200: Health bestätigt databaseConnected/accountsReady/bookingConfigured; anonyme Kontoabfrage registrationReady ohne Konto/Betreiberrechte; Kunden-/Fahrerseite und Disposition erreichbar. Anonyme Operations-GET bleibt HTTP 401 ohne Geschäftsdatenausgabe. Keine Production-Schreibprüfung. Automation ACTIVE alle fünf Stunden mit 413 Tests. Diese nachträgliche Dokumentation verändert keine veröffentlichten Runtime- oder Archivbytes.
