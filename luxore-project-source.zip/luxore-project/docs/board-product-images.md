# Bordkarte: Produktbilder

Erstellt am 29.09.2026 mit dem integrierten Imagegen-Tool. Generische Produktabbildungen, keine Zusage einer bestimmten Marke. Transparente PNGs, für die App auf 480 × 480 Pixel verkleinert; Alpha erhalten.

Speicherort: `public/board-products/<id>.png`

## Verwendete Prompts

### water.png

Use case: product-mockup. Create ONE premium photorealistic product cutout for a German chauffeur app snack menu. A single sealed 500 ml clear still mineral water bottle with a pale blue cap and a small elegant pale blue label reading only STILL. Square canvas, single product centrally framed fully visible occupying about 78% of image height, consistent front three-quarter studio camera, soft natural highlights, appetising realistic material detail. TRUE TRANSPARENT BACKGROUND with alpha channel, no floor, no colored rectangle, no backdrop, no baked checkerboard, no cast shadow outside the product. This must be product photography, not an icon, drawing, or app screen. No watermark. Output one separate image.

### sparkling.png

Use case: product-mockup. Create ONE premium photorealistic product cutout for a German chauffeur app snack menu. A single sealed 500 ml clear sparkling mineral water bottle with a green cap and a small elegant green label reading only SPRUDEL, fine bubbles in the water. Square canvas, single product centrally framed fully visible occupying about 78% of image height, consistent front three-quarter studio camera, soft natural highlights, appetising realistic material detail. TRUE TRANSPARENT BACKGROUND with alpha channel, no floor, no colored rectangle, no backdrop, no baked checkerboard, no cast shadow outside the product. This must be product photography, not an icon, drawing, or app screen. No watermark. Output one separate image.

### cola.png

Use case: product-mockup. Create ONE premium photorealistic product cutout for a German chauffeur app snack menu. A single sealed 330 ml aluminium cola can, rich red body with simple clean white lettering COLA, no other brand. Square canvas, single product centrally framed fully visible occupying about 78% of image height, consistent front three-quarter studio camera, soft natural highlights, appetising realistic material detail. TRUE TRANSPARENT BACKGROUND with alpha channel, no floor, no colored rectangle, no backdrop, no baked checkerboard, no cast shadow outside the product. This must be product photography, not an icon, drawing, or app screen. No watermark. Output one separate image.

### cola-zero.png

Use case: product-mockup. Create ONE premium photorealistic product cutout for a German chauffeur app snack menu. A single sealed 330 ml aluminium sugar-free cola can, matte charcoal black body with red accent and clean lettering COLA ZERO, no other brand. Square canvas, single product centrally framed fully visible occupying about 78% of image height, consistent front three-quarter studio camera, soft natural highlights, appetising realistic material detail. TRUE TRANSPARENT BACKGROUND with alpha channel, no floor, no colored rectangle, no backdrop, no baked checkerboard, no cast shadow outside the product. This must be product photography, not an icon, drawing, or app screen. No watermark. Output one separate image.

### apple.png

Use case: product-mockup. Create ONE premium photorealistic product cutout for a German chauffeur app snack menu. A single sealed 330 ml clear apple spritzer bottle filled with pale golden juice, green cap and simple green label reading APFEL. Square canvas, single product centrally framed fully visible occupying about 78% of image height, consistent front three-quarter studio camera, soft natural highlights, appetising realistic material detail. TRUE TRANSPARENT BACKGROUND with alpha channel, no floor, no colored rectangle, no backdrop, no baked checkerboard, no cast shadow outside the product. This must be product photography, not an icon, drawing, or app screen. No watermark. Output one separate image.

### energy.png

Use case: product-mockup. Create ONE premium photorealistic product cutout for a German chauffeur app snack menu. A single sealed 250 ml slim aluminium energy drink can, silver body with deep blue panel, clean lettering ENERGY, no other brand. Square canvas, single product centrally framed fully visible occupying about 78% of image height, consistent front three-quarter studio camera, soft natural highlights, appetising realistic material detail. TRUE TRANSPARENT BACKGROUND with alpha channel, no floor, no colored rectangle, no backdrop, no baked checkerboard, no cast shadow outside the product. This must be product photography, not an icon, drawing, or app screen. No watermark. Output one separate image.

### pretzels.png

Use case: product-mockup. Create ONE premium photorealistic product cutout for a German chauffeur app snack menu. A small elegant clear snack pouch of thin golden salted pretzel sticks, a few realistic salt crystals visible, with several sticks lying diagonally in front. No text or logos. Square canvas, single product centrally framed fully visible occupying about 78% of image height, consistent front three-quarter studio camera, soft natural highlights, appetising realistic material detail. TRUE TRANSPARENT BACKGROUND with alpha channel, no floor, no colored rectangle, no backdrop, no baked checkerboard, no cast shadow outside the product. This must be product photography, not an icon, drawing, or app screen. No watermark. Output one separate image.

### trail-mix.png

Use case: product-mockup. Create ONE premium photorealistic product cutout for a German chauffeur app snack menu. A small clear snack pouch of trail mix with almonds, cashews and raisins, a few nuts arranged in front. No text or logos. Square canvas, single product centrally framed fully visible occupying about 78% of image height, consistent front three-quarter studio camera, soft natural highlights, appetising realistic material detail. TRUE TRANSPARENT BACKGROUND with alpha channel, no floor, no colored rectangle, no backdrop, no baked checkerboard, no cast shadow outside the product. This must be product photography, not an icon, drawing, or app screen. No watermark. Output one separate image.

### fruit-bar.png

Use case: product-mockup. Create ONE premium photorealistic product cutout for a German chauffeur app snack menu. A single compact fruit and oat snack bar in a partially peeled simple cream wrapper, showing rich dates, berry pieces and oats, angled slightly diagonally. No text or logos. Square canvas, single product centrally framed fully visible occupying about 78% of image height, consistent front three-quarter studio camera, soft natural highlights, appetising realistic material detail. TRUE TRANSPARENT BACKGROUND with alpha channel, no floor, no colored rectangle, no backdrop, no baked checkerboard, no cast shadow outside the product. This must be product photography, not an icon, drawing, or app screen. No watermark. Output one separate image.

### cookies.png

Use case: product-mockup. Create ONE premium photorealistic product cutout for a German chauffeur app snack menu. A small clear snack pouch of miniature golden chocolate chip cookies, with two cookies in front. No text or logos. Square canvas, single product centrally framed fully visible occupying about 78% of image height, consistent front three-quarter studio camera, soft natural highlights, appetising realistic material detail. TRUE TRANSPARENT BACKGROUND with alpha channel, no floor, no colored rectangle, no backdrop, no baked checkerboard, no cast shadow outside the product. This must be product photography, not an icon, drawing, or app screen. No watermark. Output one separate image.

