# Ablaufzeit nativer Fahrtalarme · Fahrer 0.7.9 / Build 33

Ein nachgewiesener Zeitfehler konnte ein bereits abgelaufenes Fahrtangebot erneut als nativen Alarm einplanen. Im gemeinsamen serialisierten Alarmcontroller wurde die verbleibende Dauer vor einer zweiten asynchronen Prüfung der Standortfreigabe berechnet. Deren Wartezeit fehlte anschließend. Zusätzlich wartete die tatsächliche native Benachrichtigungsfunktion nach ihrer letzten Fristprüfung noch auf das Entfernen des bisherigen Alarms und plante danach ohne erneute Prüfung.

Die Freigabeprüfung nach dem Lesen des geschützten Zustands steht jetzt vor der Berechnung der Restdauer. Damit gehen auch deren Wartezeiten in die bereits vorhandene konservative Serverzeit-/Roundtrip-/Queue-Berechnung ein. Sie schützt zudem die folgenden Rücknahme-/Speicherwirkungen nach dem asynchronen Lesen. Die native Funktion hält die ursprüngliche daraus abgeleitete Deadline fest und prüft nach Abschluss des Entfernens erneut: höchstens zwei Sekunden Restzeit oder bereits abgelaufen bedeutet keinen neuen scheduleNotificationAsync-Aufruf. Eine nicht dargestellte Meldung erhält keine neue seenId.

Aktuelle gültige Angebote erzeugen bei parallelen Antworten weiterhin nur einen Alarm; ältere Serverantworten können eine neuere Rücknahme nicht aufheben. Kanal, Ton, Vibration, Berechtigungen, Server-Angebotsdauer, GPS-Rohdaten, Cache, Freigaben und Fahrt-/Schicht-Schreibvorgänge bleiben unverändert. Keine neuen Provider oder API-Aufrufe.

## Prüfungen und Grenzen

Sechs neue Tests verwenden die tatsächlichen offer-alert-policy- und offer-alerts-Module mit kontrollierter Uhr und isolierten Expo-Notifications-/SecureStore-Adaptern. Vier Regressionen scheitern im bisherigen Quellstand und bestehen mit der Korrektur:

- Nach langsamer erneuter Freigabeprüfung bereits abgelaufenes Angebot wird nicht dargestellt.
- Eine noch gültige Restdauer wird um genau diese Wartezeit gekürzt.
- Während des nativen Entfernens abgelaufenes Angebot erzeugt keinen neuen nativen Planungsaufruf.
- Auch genau zwei Sekunden Restzeit nach dem Entfernen bleiben gesperrt.
- Zwei parallele gültige Antworten erzeugen weiterhin einen tatsächlichen nativen Planungsaufruf.
- Neuere Rücknahme verhindert weiterhin einen Alarm aus verspäteter älterer Antwort.

Die Prüfung geschieht vor Übergabe an das Betriebssystem. Bereits begonnene native Aufrufe und tatsächliche Ton-/Hintergrund-/Herstellerreaktionen bleiben Gegenstand physischer Geräteprüfungen. Die vorhandene Ablaufbereinigung bleibt best effort; keine garantierte zeitgenaue OS-Zustellung behaupten. Kein echter Production-Alarm, Angebot, GPS-Punkt oder Fahrt ausgelöst. Keine Layoutänderung oder zusätzliche visuelle Vorschau nötig.

Neue Fahrer-APK 0.7.9 / Build 33 erforderlich; Kunde unverändert 0.6.9 / Build 23. 549 Tests, beide TypeScript-Prüfungen, gezieltes Lint und Format bestanden. Kein Datenbankschritt oder neue Berechtigung. Angemeldete physische SDK-/Mehrgeräte-/Schicht-/Straßen-/Hintergrund-GPS-Prüfungen bleiben offen; keine Installation auf Nutzerhandys oder Produktionsreife behaupten.

## Android-Nachweis · 15. Oktober

Fahrer 0.7.9 / Build 33 außerhalb synchronisierter Quell-/Abhängigkeitsordner mit unveränderten 21 direkten installierten Paketversionen, Lockfile und bestehender Signatur gebaut. 85 Runtime-/Asset-/Konfigurationsdateien einschließlich sämtlicher gemeinsamer Imports stimmen bytegenau überein. Gradle erfolgreich in 3m26s. Varianten-/Standalone-/ARM64-Prüfung bestanden; Berechtigungen exakt wie 0.7.8. Zertifikat SHA-256 fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c unverändert. APK 56.217.524 Bytes, SHA-256 aeb1e4d3f3c6a00dd17e88c7f14168ed54332cd70db84c946f373f578f3d6845.

Update über 0.7.8 ohne Deinstallation im isolierten Emulator und drei anonyme Kaltstarts mit laufendem Prozess ohne fatale Android-/React-Native-Fehler bestanden. Kein angemeldeter Angebots-/Ton-/Schicht-/SDK-Ablauf oder physischer GPS-Test. APK bleibt geschützter interner GitHub-Entwurf, keine öffentliche Binary-/Store-Freigabe. Kunde unverändert 0.6.9 / Build 23. Keine Production-Alarme, Fahrten, Schichten oder Migration.

## Veröffentlichungsnachweis

Runtime-Quellstand `051cdc4de033cc0d9aba948e763580ce8fcbcfa6`, öffentlicher GitHub-Commit `555e24121f3c0fb3e877cd7700d6558f2afc7eb7`. Quellarchiv, SOURCE-VERSION.txt und README.md bytegleich zurückgelesen. Archiv: 520 Dateien, 7.923.664 Bytes, SHA-256 `ca5ae3f01b9ece39dd1aeea93287338d6696b3728f6d60af40fcec009610f84b`. Beide tatsächlichen Alarmmodule, Regressionstests und vorhandenen nativen Runtime-/Shared-Dateien im Archiv exakt geprüft; keine APKs, Schlüssel, Environment-Secrets oder persönliche Konfliktkopie enthalten. Produktionsbuild genau dieses Archivs erfolgreich: 7,5s Kompilierung, 5,2s TypeScript.

Vercel `818E9mtyFwTkoFQHtTPSkEcxuiuV` ist Ready / Latest / Current Production für luxoreride.de und den genannten Commit, GitHub-Status success. Fünf reine Live-GETs für health, account, Kunden-/Fahrerbereich und Disposition liefern 200; Datenbank/Konten/Buchung bereit. Keine echte Schicht, Position, Einladung, Fahrt oder Production-Benachrichtigung ausgelöst.

Geschützter APK-Entwurf: https://github.com/0711hany-source/luxore-ride-website/releases/tag/untagged-03e3e742263428062b36. GitHub bestätigt den Asset-Digest `aeb1e4d3f3c6a00dd17e88c7f14168ed54332cd70db84c946f373f578f3d6845`. Screenshotnachweise: outputs/native-offer-deadline-079/apk-draft.png und vercel-ready.png. Emulator nach Update/Startprüfung beendet. Dieser nachträgliche Nachweis ändert keinen veröffentlichten Runtime-Code oder das geprüfte Archiv. Als nächster unabhängiger Schritt aktuelle Standortfreigabe während asynchroner nativer Benachrichtigungsarbeit bei Pause/Schichtwechsel auf einen weiteren tatsächlich reproduzierbaren Fehler prüfen. Physische angemeldete Ton-/OS-/Mehrgeräte-/Straßen-/Hintergrund-GPS-Prüfungen bleiben offen.
