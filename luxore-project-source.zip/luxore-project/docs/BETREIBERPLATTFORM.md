# Betreiberplattform: Abrechnung, Flottenantrag, Papiere, Wochenkontrolle, Sperren

Stand: 15.11.2026 · nur Server und Web (lokal gebaut, nichts veröffentlicht). Die nativen Apps bekommen diese Funktionen später.

## 1. Servicepauschale und Wochenabrechnung
- Für jede **abgeschlossene und kassierte** Fahrt berechnet die Plattform der Flotte **15 % des Fahrpreises** (je Fahrt kaufmännisch auf Cent gerundet). Bordprodukte zählen nicht mit. Der Kundenpreis ändert sich nicht.
- Der Satz steht an einer Stelle: `SERVICE_FEE_BPS` in `lib/mobility/settlement.ts`.
- Eine Woche läuft von **Montag 00:00 bis Sonntag 24:00 Uhr** (Frankfurter Zeit). Eine Fahrt gehört in die Woche, in der sie **kassiert** wurde.
- Die Abrechnung wird immer aus den Fahrten berechnet; es gibt keine zweite Buchführung.
- Überall steht: „Abrechnungsübersicht – keine Rechnung im steuerlichen Sinn“. Es wird keine Umsatzsteuer berechnet.

**Betreiber** (`/betreiber` → „Abrechnung“): Woche wählen, alle Flotten mit Summen und Status sehen, Flotte antippen → Fahrer aufklappen → jede Fahrt. „CSV herunterladen“ exportiert die Woche. „Zahlungseingang vermerken“ (zweimal tippen) setzt die Woche auf **bezahlt** und friert ihre Summen ein; „Zahlung zurücknehmen“ macht das rückgängig. Das geht erst, wenn die Woche vorbei ist.

**Flottenbesitzer/Stellvertreter** (`/disposition` → Flotte → „Einnahmen“): offene Servicepauschale, Wochen und Monate, je Woche bis zur einzelnen Fahrt. Nur die eigene Flotte.

**Fahrer** (Fahrer-Web-App → „Umsatz“ → „Meine Einnahmen“): heute, diese Woche, dieser Monat; bar und Terminal getrennt; Liste der eigenen Fahrten. Keine Aussage zum Lohn.

## 2. Bewerbung als Partnerflotte
- Seite `/partner` (Link auch unter „Mein Konto“). Nur mit angemeldetem Konto.
- Angaben: Firmenname, Rechtsform, Anschrift, Ansprechpartner, Telefon, Steuernummer/USt-ID (freiwillig). Die 15 % und die wöchentliche Abrechnung müssen angehakt werden.
- Danach lädt der Antragsteller die Gewerbeanmeldung/Genehmigung als Foto hoch.
- Betreiber: `/betreiber` → „Prüfung & Sperren“ → „Flottenanträge“. **Annehmen** legt die Flotte über den bestehenden Gründungsweg an, der Antragsteller wird Besitzer. **Ablehnen** verlangt einen Grund.
- Der bisherige Weg (Betreiber legt eine Flotte direkt an) bleibt.

## 3. Papiere mit Foto
| Für | Pflicht | Freiwillig |
|---|---|---|
| Fahrer | Führerschein, Personenbeförderungsschein | Ausweis |
| Fahrzeug | Fahrzeugschein, Versicherungsnachweis, Konzession/Genehmigungsurkunde, HU-Nachweis | – |
| Flotte | Gewerbeanmeldung/Genehmigung | – |

- Hochladen: Flottenleitung für Fahrzeuge, Fahrer und Flotte (`/disposition` → „Prüfung“); Fahrer für eigene Papiere (Fahrer-Web-App → „Auto“ → „Meine Papiere“).
- Je Papier bis zu 4 Fotos, Nummer freiwillig, Ablaufdatum (Pflicht bei Führerschein, P-Schein, Konzession, HU).
- Fotos werden auf dem Gerät verkleinert (längste Seite 1600 px, JPEG, höchstens 400 KB) und in der vorhandenen Datenbank gespeichert. Kein öffentlicher Link: Ein Foto sieht nur der Betreiber, die Leitung der betroffenen Flotte und der Fahrer für eigene Papiere.
- Prüfen: nur der Betreiber, unter „Prüfung offen“. Freigeben (Ablaufdatum kann korrigiert werden) oder Ablehnen mit Grund. Ohne Foto keine Freigabe.
- Ein gültiges geprüftes Papier bleibt gültig, auch wenn schon ein neues zur Prüfung eingereicht ist.
- Löschen: Wird ein Konto gelöscht, verschwinden seine Papiere und Fotos mit. Bei einem archivierten Fahrzeug können Papiere, Kontrollen und Fotos gelöscht werden.

## 4. Wochenkontrolle der Fahrzeuge
- Alle **7 Tage** je Fahrzeug: Außen vorne/hinten/links/rechts, Innenraum sauber, Ausstattung, Reifen, Licht – je Punkt „In Ordnung“ oder „Mangel“ (mit kurzer Notiz). Fotos: vier Seiten und Innenraum. Kilometerstand freiwillig.
- Durchführen: Flottenleitung (`/disposition` → „Prüfung“ → Fahrzeug) oder der Fahrer des Fahrzeugs (Fahrer-Web-App → „Auto“ → „Wochenkontrolle“).
- Ergebnis „ohne Mangel“ oder „mit Mangel“. Ein Mangel erscheint rot bei Flotte und Betreiber („Fahrzeuge mit Mangel“). Nur eine Kontrolle **ohne Mangel** zählt als bestanden.
- Der Verlauf je Fahrzeug ist einsehbar.

## 5. Sperren
- **Betreiber** sperrt Fahrer, Fahrzeug oder ganze Flotte mit Grund und gibt wieder frei (`/betreiber` → „Prüfung & Sperren“ → „Flotte ansehen“ bzw. „Aktive Sperren“).
- **Flottenleitung** sperrt eigene Fahrer und Fahrzeuge und gibt sie wieder frei, kann aber eine Sperre des Betreibers nicht aufheben.
- Eine Sperre gilt immer, auch wenn die Prüfpflicht aus ist. Wer gesperrt ist, kann nicht online gehen. Eine laufende Fahrt wird nie abgebrochen; ohne laufende Fahrt und offene Zahlung endet die Schicht sofort.
- Der Verlauf zeigt wer, wann und warum.
- Kontosperre, Fahrerfreigabe und Archivieren von Fahrzeugen funktionieren unverändert weiter.

## 6. Prüfpflicht einschalten (Betreiber)
Die Prüfpflicht ist nach dem Einspielen **AUS**. Solange sie aus ist, sind fehlende Papiere und Kontrollen nur Hinweise – niemand wird automatisch gesperrt.

So einschalten:
1. `/betreiber` → „Prüfung & Sperren“ → unten „Flotte ansehen“: je Flotte prüfen, ob Papiere geprüft und Kontrollen gültig sind.
2. Oben im Kasten „Prüfpflicht“ auf „Prüfpflicht einschalten …“ tippen, Hinweis lesen, „Jetzt verbindlich einschalten“.

Ab dann kann eine neue Schicht nur beginnen, wenn
- die Pflichtpapiere von Fahrer, Fahrzeug und Flotte geprüft und nicht abgelaufen sind und
- die letzte Kontrolle ohne Mangel höchstens 7 Tage alt ist.

Der Fahrer sieht den genauen Grund, z. B. „Wochenkontrolle für F-LX 1001 fällig“ oder „Personenbeförderungsschein abgelaufen am 31.01.2027“. Laufende Fahrten und Schichten werden nicht beendet; geprüft wird beim nächsten Online-Gehen. 14 Tage vor Ablauf eines Papiers und 3 Tage vor fälliger Kontrolle erscheinen Hinweise. Ausschalten geht jederzeit am selben Knopf.

## Technik in Kürze
Migration `drizzle/0020_operator_platform.sql` (7 neue Tabellen, nichts Bestehendes geändert). Logik: `lib/mobility/settlement.ts`, `compliance.ts`, `images.ts`. Routen: `app/api/mobility/{settlements,earnings,fleet-applications,documents,images,inspections,suspensions,compliance}`. Tests: `tests/operator-platform.test.mjs`.

## Noch offen (Recht/Datenschutz – nur benannt)
Vertrag über die Servicepauschale mit den Flotten · Datenschutzerklärung um Papiere/Ausweisfotos ergänzen · Aufbewahrungs- und Löschfristen für Fotos und Kontrollen · ob Ausweisfotos überhaupt gespeichert werden sollen.
