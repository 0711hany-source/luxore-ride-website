# Native Besitzerübergabe · Fahrer 0.7.7 / Build 31

Die bestehende native Disposition öffnet ein festes Vollbildfenster zur Besitzerübergabe. Der bestehende Server erlaubt diese Aktion ausschließlich dem vorhandenen Plattformbetreiber; gewöhnliche Besitzer und Stellvertretungen erhalten dadurch keine neuen Rechte. Auswahl, Hinweise und Bestätigung verwenden dieselbe aktuelle Operations-Momentaufnahme wie Fahrerfreigabe, Stellvertretung und Teamverwaltung.

## Auswahl und Bestätigung

Zielpersonen stammen aus der tatsächlichen ungekürzten Mitarbeiterliste von GET fleets: derselben Flotte zugeordnet, tatsächliches Fahrerprofil, freigegeben, ohne die vom Server berechnete can_remove-Einsatzsperre. Besitzer anderer gelieferter Flotten und der bisherige Besitzer sind ausgeschlossen. Die eventuell auf 200 gekürzte Operations-Fahrerliste ist keine Voraussetzung für das Auffinden einer Zielperson. Gelieferte aktive Fahrer-/Fahrt-/Zahlungssperren werden zusätzlich berücksichtigt. Auch ein belegtes altes Besitzerprofil sperrt die Auswahl. Der atomare Server prüft Kontostatus, Flottenbesitz sowie sämtliche Online-/GPS-/Fahrt-/Zahlungssperren erneut.

Nur vollständiges Wischen sendet transfer_owner, fleetId, previousOwnerId, ownerId und confirmed:true. Die bestätigte Auswahl bindet den damaligen bisherigen Besitzer; ein neuer GET schreibt ihn niemals in eine offene Anfrage um. Kein Tippen bestätigt. Mitarbeiter, Fahrzeuge, Bestände, Freigaben und Fahrtgeschichte werden nicht lokal verändert. Wird die Stellvertretung Besitzer, übernimmt der bestehende Server ihre Rollenbereinigung atomar mit dem Audit. Keine optimistische Besitzer-/Stellvertretungsänderung.

## Verlorene Antwort und Lebenszyklus

OperationsController teilt die Schreibsperre mit Freigabe, Stellvertretung und Mitgliedschaft; eine offene/unklare Gründung sperrt die Operations-Momentaufnahme ebenfalls. Aktiver Vordergrund, tatsächlicher Plattformbetreiberzugriff, weniger als 30 Sekunden alter Stand und keine laufende/verfehlte Leseanfrage sind Voraussetzung. Bestätigende POSTs besitzen kein AbortSignal einer Leseanfrage und überleben einen Hintergrundwechsel; alte GET-Antworten/finally-Blöcke können keinen neueren Stand überschreiben. Der bestehende nach Anmeldetoken getrennte Workspace schützt Kontowechsel.

Nach fehlender oder uneindeutiger Antwort zuerst GET, niemals automatischer POST-Retry. Ein erfolgreicher aktueller GET mit dem gewünschten Besitzer bestätigt den aktuellen Zustand ohne zweiten POST. Zeigt GET weiterhin den erwarteten alten Besitzer, erlaubt nur dieselbe ausdrücklich gewischte Auswahl einen neuen Versuch. Ein dritter Besitzer oder eine fehlende Flotte sperrt diese Übergabe. Auch eine erneute Übermittlung bleibt am alten Besitzer-Guard des Servers gebunden; diese Aktion ist keine dauerhaft gespeicherte idempotente Auftragsquittung.

Ein aktueller autorisierter GET erlaubt das Beenden der lokalen Prüfung ausschließlich per Wischen. Das sendet keinen POST und storniert keine möglicherweise noch unterwegs befindliche Serveranfrage; der Dialog benennt diese Grenze. Ein Lesefehler oder 401/403 erlaubt weder Retry noch Prüfungsabschluss. Entzogene Rechte entfernen die alte Datenansicht. Eine bestätigte Speicherung bleibt trotz anschließendem Leseproblem als Erfolg erhalten; weitere Änderungen warten auf einen frischen Stand.

Die offene Besitzerprüfung lebt nur im kontogetrennten Workspace, nicht dauerhaft in SecureStore. Nach Prozessneustart wird zuerst der aktuelle Serverstand geladen, kein alter Übergabeauftrag automatisch fortgesetzt. Nach Konto-/Rechteverlust erfolgt keine automatische Wiederaufnahme. Eine aktuelle Zustandsbestätigung beweist nicht, welcher Vorgang diesen Zustand erzeugt hat.

## Prüfungen und Grenzen

- Acht neue Controllerprüfungen: tatsächliche Scopes/ungekürzte Zielauswahl, alter Besitzer und gemeinsame Schreibsperre, Hintergrundbestätigung, GET vor identischem Retry, GET-Bestätigung ohne zweiten POST, dritte/fehlende Flotte und lokale Beendigung, bestätigte Speicherung trotz Lesefehler, Rechteentzug und veraltete Antworten/Dispose.
- Drei tatsächliche React-Native-Komponententests über OperationsScreen und echten account-client/fetch-Pfad: Personenfilter, vollständige versus unvollständige Geste und exakter POST; verlorene Antwort/gesperrter Retry/konfliktgebundene lokale Beendigung; kein Einstieg für normale Flottenbesitzer.
- Gesamtstand 537 Tests bestanden. Web- und Mobile-TypeScript, gezieltes Lint und Format bestanden.
- Lokale Vorschau verwendet die echten Komponenten mit gekennzeichneten synthetischen Flottendaten. 390 × 844 und 390 × 640 ohne äußeren horizontalen Überlauf; feste Fußfläche, auch beide Konfliktgesten bei 640 Pixeln sichtbar. Kein tatsächlicher Production-Transfer.

Neue Fahrer-APK 0.7.7 / Build 31 erforderlich, Kunde bleibt 0.6.9 / Build 23. Android-Signatur und Paketversionen bleiben erhalten. Android-Build und Emulatornachweise sind unten bestätigt. Keine Migration oder Production-Leitungsänderung. Angemeldete physische Unternehmensgeräte-, SDK-, Mehrgeräte- und Hintergrund-GPS-Prüfungen bleiben offen. Keine Installation auf Nutzerhandys oder Produktionsreife behaupten.

## Android-Nachweis · 15. Oktober

Fahrer 0.7.7 / Build 31 außerhalb des synchronisierten Quell-/Abhängigkeitsordners gebaut. Nach fehlenden Dateien im temporären Verzeichnis wurden die Abhängigkeiten mit dem bestehenden eingefrorenen Lockfile wiederhergestellt und der vollständige lokale Importbaum kopiert. Alle 21 direkten installierten Paketversionen und das Lockfile sind unverändert; 85 Runtime-/Asset-/Konfigurationsdateien einschließlich 13 gemeinsam genutzter Web-/Domainmodule stimmen bytegenau überein. Keine Bibliotheksaktualisierung oder neue API. Abschließender Gradle-Build erfolgreich (1m42s).

Varianten-/Standalone-/ARM64-/Berechtigungsprüfung bestanden; Berechtigungen exakt wie 0.7.6. Bestehende Zertifikats-SHA-256 fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c bestätigt. APK 56.217.428 Bytes, SHA-256 f51df0764c6c3222e31c739c70d327779832ba4709ba2428f0254e20e99f7122. Als Update über Fahrer 0.7.6 ohne Deinstallation im isolierten Emulator installiert; drei anonyme Kaltstarts mit laufendem Prozess ohne fatalen Android-/React-Native-Fehler. Kein angemeldeter Besitzertransfer/SDK-Test und keine physische Geräteprüfung. APK bleibt geschützter interner GitHub-Entwurf, keine öffentliche Binary-/Store-Freigabe. Kunde bleibt 0.6.9 / Build 23.
