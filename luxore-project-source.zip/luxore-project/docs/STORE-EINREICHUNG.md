# Store-Einreichung – Stand und Prüfliste

Stand 14.11.2026. Nichts ist hochgeladen. Hochladen nur nach ausdrücklicher Freigabe von Hanan.

## Was technisch bereitliegt (Google Play)

- Store-Pakete bauen: `cd mobile && bash scripts/build-android-store.sh customer` (danach `driver`), prüfen mit `bash scripts/verify-android-store.sh <variante>`.
- Ergebnis: `mobile/artifacts/luxore-customer-store.aab` und `luxore-driver-store.aab` (App-Bundle, arm64 + armv7, Paketnamen `de.luxoreride.customer` / `de.luxoreride.driver`, Namen „LUXORÉ Ride“ / „LUXORÉ Driver“ ohne „Test“). Die Musterseite des Neudesigns ist darin nicht sichtbar.
- Upload-Schlüssel: `mobile/.toolchain/store-signing/` (Schlüsseldatei und Kennwortdatei, nicht in Git). **Sicher aufbewahren.** Geht er verloren, muss bei Google ein neuer Upload-Schlüssel beantragt werden (möglich, solange „Play App Signing“ aktiv ist – das ist bei neuen Apps Standard).
- Store-Texte (Entwurf): `mobile/store/STORE-LISTINGS-DE.md`.
- Öffentliche Seiten, die der Store verlangt, gibt es im Projekt: `/datenschutz`, `/hilfe`, `/konto` (Kontolöschung), `/impressum`.

## Was vor dem Hochladen fehlt

| Punkt | Wer | Stand |
| --- | --- | --- |
| Google-Play-Entwicklerkonto (einmalig 25 $ laut Google; als Unternehmen mit D-U-N-S-Nummer; ein privates Konto müsste erst 14 Tage mit 12 Testern testen) | Inhaberin (Geld, Identitätsprüfung) | offen |
| Apple-Entwicklerkonto (99 $/Jahr laut Apple) | Inhaberin | offen; iPhone-Fassung wurde noch nie gebaut |
| Fehler „Online gehen lädt endlos“ in der Fahrer-App | Gerätetest Hanan + Claude | offen – ohne das ist die Fahrer-App nicht einreichbar |
| Gerätetest der aktuellen Fassung (Buchung bis Kassieren auf zwei Handys) | Hanan | offen |
| Live-Server aktualisieren (Sicherheitsupdate, Registrierung langsam/Fehlermeldung, Geoapify-Schlüssel) – die Apps sprechen mit luxoreride.de | Freigabe Hanan, ein gesammelter Upload | offen |
| App-Symbole (Richtung A–D) und Store-Grafiken: Symbol 512 px, Titelgrafik 1024 × 500, mind. 2 echte Screenshots je App | Auswahl Hanan, dann Claude | offen |
| Versionsnummer für den Store (jetzt 0.7.2 / 0.8.9; üblich wäre 1.0.0) | Hanan | offen |
| Datenschutzerklärung, AGB, Stornoregeln rechtlich geprüft; Angaben zur Datensicherheit im Store (Standort, Name, E-Mail, Telefon) | Inhaberin / Fachanwalt | offen |
| Begründung Hintergrund-Standort für Google (Formular + kurzes Video der Fahrer-App) | Claude bereitet Text vor, Video vom Gerät | offen |
| Testzugang für die Store-Prüfer (Kunde und freigegebener Fahrer auf dem Live-System) | Hanan | offen |
| Hosting für kommerziellen Betrieb (Vercel Hobby reicht nicht), Push für Fahrer, Zeitgeber für Reservierungen, Backups | Budget Inhaberin | offen (siehe Problemliste) |
| Neudesign Etappen 1–9 | Claude | nur Etappe 0 fertig; für eine erste Einreichung nicht zwingend |

## Empfohlener Weg

1. APKs 0.7.2 / 0.8.9 auf zwei Handys testen, „Online gehen“ klären.
2. Ein gesammelter Upload der Website (nach Freigabe).
3. Play-Konto anlegen lassen; zuerst **interner Test** im Play Store (bis 100 Tester, keine Prüfung der Store-Seite nötig) mit den AAB-Paketen.
4. Symbole, Screenshots, Rechtstexte fertigstellen, dann geschlossener Test und Produktion.
5. iPhone erst danach.
