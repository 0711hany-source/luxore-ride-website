# Atomarer nativer Server-Stopp · 16. Oktober 2026

## Reproduzierte Fehler

POST /api/mobility/location las die Capability vor dem Anfragekörper und verwendete diese Momentaufnahme für einen späteren Stop-Batch. Ein zwischenzeitlich erneuerter Token derselben Session, entzogene Fahrerfreigabe, inaktives Fahrzeug oder abgelaufene Capability konnten dadurch noch einen Stopp erlauben. Bei inzwischen anderer Schicht konnte der alte Batch zwar die session_id nicht überschreiben, aber deren pending-Angebote zurückziehen, wenn die neue Schicht vor ihrem ersten GPS-Upload noch online=0 war. Der Endpunkt bestätigte dann trotzdem ok:true.

Zusätzlich lief dispatch nach dem bereits committed Stop-Batch ohne getrennte Fehlerbehandlung. Ein Fehler dieser Queue-Aktualisierung lieferte HTTP 500, obwohl Fahrer bereits offline, Capability gelöscht und Angebote zurückgenommen waren. Die native App musste dies trotz tatsächlich gespeicherter Pause als unbestätigt behandeln.

## Änderung

lib/mobility/native-stop.ts prüft den aktuellen token_hash mit aktueller Zeit, exakter Fahrer-/Session-Verknüpfung, bestehender Fahrerfreigabe und tatsächlicher aktiver Fahrzeug-/Flottenmitgliedschaft erneut innerhalb desselben libSQL-Schreibzugriffs wie Offline-Schaltung, Löschen dieser Capability und Rücknahme der pending-Angebote. Gleiche nativeSessionSql wie die vorgelagerte Prüfung, keine erweiterten Rechte. Entzogene, ersetzte oder abgelaufene Freigabe ergibt 401 ohne eigene Mutation; die neuere Session/Capability/Angebotslage bleibt erhalten. Schreibfehler rollen alle drei Schritte zurück; kein ok vor Commit. Eine danach ausdrücklich wiederholte Anfrage kann mit unverändertem gültigem Token nach behobenem Speicherfehler erfolgreich sein.

Erst nach bestätigtem Commit folgt die bisherige Vermittlungsaktualisierung mit aktueller Zeit. Ein Fehler wird als „Native pause dispatch refresh failed“ im Serverlog sichtbar und ändert die bereits gespeicherte Pausenbestätigung nicht in HTTP 500. Die Antwort ok:true bestätigt ausschließlich den committed Stopp der ursprünglichen Capability und ihre Angebotsrücknahme. Sie bestätigt weder die gesamte Queue-Neuvermittlung noch den Zustand einer späteren neuen Schicht. Eine spätere normale Dispatch-Ausführung kann die Queue wieder bearbeiten; kein neuer Hintergrundauftrag oder automatischer Stop-Retry.

Der gewöhnliche Standort-/GPS-Uploadpfad, dessen Qualitäts-/Zeitprüfung, Rate-Limit, CAS-Guard und anonymisierte Angebotsantwort sind unverändert. Bestehende Rollen, Fahrzeugauswahl, Rohkoordinaten, Fahrerfreigabe, Buchungs-/Fahrtgeschichte und Flottenzuordnung bleiben erhalten. Der authentifizierte driver/offline-Endpunkt ist ein eigener Ablauf und mit diesem Schritt nicht umgebaut.

## Tatsächliche Endpunkt-/libSQL-Prüfungen

Elf neue Tests laden den tatsächlichen location-Endpunkt, tatsächlichen Stop-Code und tatsächlichen dispatch gegen den bestehenden sqliteDatabase-Adapter mit einer echten isolierten libSQL-In-Memory-Datenbank und sämtlichen Projektmigrationen. Nur Server-Kontext/Hash-Zuordnung sind isolierte Testadapter. Die Race-Injektion findet nach der realen vorgelagerten Berechtigungsabfrage statt, vor der erneuten Prüfung im Schreibzugriff.

- Gültiger Stopp: offline, Session entfernt, Capability gelöscht und Angebot rejected; Freigabe/Fahrzeug/Koordinaten/Team/Fahrt bleiben erhalten. Wiederholung des danach entzogenen Tokens bleibt 401, keine erfundene dauerhafte Quittung.
- Zwischen erster Abfrage und Schreibzugriff erneuerter Token derselben Session, neue Schicht vor erstem GPS, entzogene Freigabe, inaktives Fahrzeug oder abgelaufene Capability: jeweils 401 und bytegleich erhaltene aktuelle Datensätze.
- Tatsächliche SQL-Triggerfehler bei Fahrer-Update, Capability-Löschung und Angebotsrücknahme: HTTP 500 und vollständiger Rollback; ausdrücklicher Retry nach Entfernen des Testfehlers erfolgreich.
- Tatsächlicher Dispatch-Speicherfehler nach Commit: HTTP 200 mit ok:true und bereits bestätigter konsistenter Pause; Fehler protokolliert.
- Unbekannter nativer Token: 401 ohne Mutation.

Sechs der elf Tests scheitern mit dem alten Endpunkt; alle elf bestehen korrigiert. Gesamtstand 613 Tests, beide TypeScript-Prüfungen, gezieltes Lint/Format und diff-Prüfung bestanden. Next.js-16.4-Route-Handler-Dokumentation im installierten Paket vor Änderung gelesen. Kein neuer Datenbankschritt und keine neue APK: Kunde bleibt 0.6.9 / Build 23, Fahrer bleibt 0.8.5 / Build 39. Android-Nachweise stammen unverändert vom zuvor geprüften 0.8.5-Build; hier kein neuer Emulator-/Gerätenachweis.

## Grenzen und nächster Schritt

Netzverlust nach dem Servercommit bleibt für den Client unklar; diese Änderung ergänzt keine dauerhafte Stop-Quittung, Wiederholung unter bereits widerrufenem Token oder automatische Wiederholung. Datenbank-/Commit-Transportfehler können ebenfalls unklar bleiben. Es gibt keine neue garantierte Dispatch-Wiederholung und keinen direkten nativen OS-Stopp durch den Server. Physische angemeldete Unternehmensgeräte-/Mehrprozess-/Hersteller-/Straßen-/Ton-/Hintergrund-GPS-Prüfungen bleiben offen. Keine Production-Schicht, Position, Alarme, Fahrt oder Rechteänderung ausgelöst.

Nächster unabhängiger Schritt: den bestehenden authentifizierten driver/offline-Ablauf lokal bei alter Session, konkurrierendem Neustart und Dispatch-/Speicherfehlern prüfen und einen konkreten Fehler absichern. Nicht diesen abgeschlossenen nativen Capability-Stopp erneut implementieren.

Archivbuild und Veröffentlichungsnachweise folgen nach tatsächlicher Prüfung.
