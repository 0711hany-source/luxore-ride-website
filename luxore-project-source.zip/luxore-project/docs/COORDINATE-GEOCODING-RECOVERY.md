# Kartenpunkte bei ausgefallener Adresssuche · 11. Oktober 2026

## Fehler und Änderung

Bei aktiviertem Geoapify-Free wurde die Umwandlung von GPS-/Kartenkoordinaten in eine Straßenbezeichnung ebenfalls durch das externe Kontingent begrenzt. Die Fehlermeldung empfahl die Kartenwahl, diese scheiterte aber erneut am gleichen Dienst. Leere Reverse-Ergebnisse ergaben zusätzlich eine nicht bestätigbare Auswahl.

Der bestehende Places-Endpunkt behandelt die Bezeichnung eines vom Nutzer selbst angegebenen gültigen Karten-/GPS-Punkts als optional. Bei Geokodierungsfehlern 429, 502, 503 oder 504 sowie leeren Reverse-Ergebnissen speichert er die angegebenen Koordinaten mit eigener neutraler Bezeichnung. Keine erfundene Straße, keine Anbieterherkunft und kein temporärer Textvorschlag werden übernommen. Erfolgreiche Reverse-Ergebnisse behalten Bezeichnung und Herkunft; ein Kartenpunkt behält immer seine ausdrücklich gewählten Koordinaten.

Authentifizierung, öffentliche und kontogebundene Anfragegrenzen sowie Koordinatenprüfung erfolgen vorher. Gleichzeitige Cache-Prüfung (409), unerwartete Datenbankfehler und fehlgeschlagene Orts-Speicherung bleiben Fehler. Eine ID wird erst nach erfolgreicher Speicherung zurückgegeben. Textsuche und Textauswahl erhalten weiterhin ihre tatsächlichen Anbieterfehler. Es entstehen weder neue Fahrer-/Fahrtrechte noch automatische Fahrten.

## Prüfung

Neun zusätzliche Endpunkt-/SQLite-Regressionstests verwenden die echten Geokodierungsadapter und alle Migrationen mit synthetischen Anbieterantworten. Im unveränderten Endpunkt scheiterten sechs der neuen Tests; nach der Korrektur bestehen alle 28 Tests dieser Datei und insgesamt 366 Tests. Geprüft: tatsächliche Tageskontingentsperre vor externem Aufruf, Anbieter-429, Netzverlust, ungültige und leere Antworten, exakte gespeicherte GPS-/Kartenkoordinaten einschließlich Eigentümer und leerer Herkunft, daraus erzeugtes Streckenangebot, weiterhin gesperrte Textbestätigung, Authentifizierung, Limits, ungültige Koordinaten, konkurrierende Cache-Lease und Datenbank-/Speicherfehler. Bestehende Tests prüfen weiterhin lizenzierte erfolgreiche Ergebnisse und verhindern bezahlte Geokodierung.

Web-TypeScript und gezieltes Lint für Endpunkt und Tests bestanden. Kein Production-Testpunkt, keine Testfahrt, keine Migration, kein Anbieter-/Tarif-/Budgetwechsel. Das permanente Mapbox-Budget bleibt null; die Geoapify-Free-Grenzen bleiben erhalten. Diese Serveränderung verbessert Website und bestehende Apps ohne neue APK. Kunden-APK bleibt 0.6.7 / Build 21, Fahrer-APK 0.6.4 / Build 18.

## Grenzen und nächster Schritt

Diese Korrektur macht keinen ausgefallenen Kartendarstellungs- oder Routendienst verfügbar. Ohne bestätigte Straßenbezeichnung erscheint eine neutrale Standort-/Punktbezeichnung. Ein gültiger Punkt garantiert weder eine befahrbare Route noch einen verfügbaren Fahrer. Die native Kunden-Live-Karte sowie angemeldete physische Mehrgeräte-, Schicht- und Hintergrund-GPS-Prüfungen bleiben offen. Verlust einer bereits gespeicherten Ortsantwort kann weiterhin einen zusätzlichen Ortsdatensatz bei manueller Wiederholung erzeugen.

## Veröffentlichung

Runtime-Commit lokal: `2d3557b83335421ae3d5c3d3e5de38b582be98da`. GitHub: `2fad52a709192cc7dfa20fa1ebdca973b012fd7b` im bestehenden Repository `0711hany-source/luxore-ride-website`. Drei Quellartefakte wurden bytegenau am öffentlichen Commit geprüft. Quellarchiv: 455 Dateien, 7.712.624 Bytes, SHA-256 `fc40fa2798ab8f118c9be4fc39817f80ac4c11e7a3769960c9143d1d00235915`. Der exakt paketierte Quellstand bestand einen frischen Next.js-16.4-Produktionsbuild.

Vercel bestätigt Ready / Latest / Current Production für `HUwT4qqmvtX9aieqJ8hjDH6pQCoX`, mit dieser GitHub-Quelle und luxoreride.de. UI-Nachweis: `outputs/coordinate-geocoding-recovery/vercel-ready.png`. Der GitHub-Status-Hook war zum Zeitpunkt des bytegenauen Abgleichs noch pending; die Vercel-Detailseite selbst bestätigt den abgeschlossenen Produktionsstand.

Fünf reine Live-Leseprüfungen bestanden mit HTTP 200: Health (Datenbank verbunden, Konten und Buchungen bereit), anonyme Konto-API (Registrierung bereit, kein Konto und keine Betreiberrechte), Kunden-App, Fahrer-App und Disposition. Keine Production-Ortsbestätigung oder Testfahrt ausgelöst. Keine neue APK nötig. Die Automation bleibt ACTIVE alle fünf Stunden mit dem aktualisierten Prüfstand und der offenen nativen Kunden-Live-Karte. Diese nachträgliche Dokumentation verändert keinen Runtime-Code.
