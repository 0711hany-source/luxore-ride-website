# Native Kartenpunktwahl · Kunden-App 0.6.7 / Build 21

## Abgeschlossener Entwicklungsschritt

Das native Buchungsformular öffnet für Abholort und Ziel einen festen nativen Vollbilddialog mit Safe-Area, Markenheader, heller Mapbox-Streets-v12-Karte, goldener Mittelpunktmarkierung und Zoomsteuerung. Der Bildschirm öffnet keine eingebettete Webseite. Ein vorhandener bestätigter Ort startet auf Straßenmaßstab, andernfalls die Europaübersicht. Der gewählte Mittelpunkt bleibt beim Hintergrundwechsel erhalten. In dieser ausdrücklich manuellen Auswahl wird die Karte nicht nach drei Sekunden zurückgesetzt; die automatische Rückkehr in der Fahrer-Navigation bleibt unverändert.

Bestätigung ist erst nach geladenen Kartendaten, beendeter Kamerabewegung und Zoomstufe mindestens 14 möglich. Während Verschieben/Zoomen entstehen keine eigenen Adress-/Geokodierungsanfragen; Mapbox lädt weiterhin Kartendaten. Erst die ausdrückliche Bestätigung ruft den bestehenden eigenen `places`-Endpunkt mit `kind:pin` auf. Dieser bestätigt und speichert den vom Nutzer gewählten Koordinatenpunkt; eine mögliche Straßenbezeichnung stammt aus der vorhandenen begrenzten Anbieteranbindung. Anbieterbudgets, Rechte und Gebühreneinstellungen werden nicht verändert. Die Auswahl ist keine Fahrtannahme: Die eigentliche Buchung bleibt ausschließlich durch vollständiges Wischen bestätigbar.

## Stabilität und Grenzen

Das SDK wird erst innerhalb einer montierten Fehlergrenze mit aktivem Bildschirm und öffentlichem Token geladen. `MapStartup` initialisiert den Token vor Telemetrie und vor jeder MapView-Konstruktion. Import-, Initialisierungs- und Ladefehler bieten einen Wiederholungsweg; nach 20 Sekunden wird erfolgloses Kartenladen sichtbar behandelt. Lizenzhinweise und Mapbox-Logo bleiben zugänglich.

Nur Konfigurations-Leseanfragen werden bei Hintergrundwechsel abgebrochen. Veraltete Antworten können weder neuere Konfiguration noch deren Ladezustand überschreiben. Eine bereits gestartete Punktbestätigung wird nicht durch Lifecycle-Wechsel abgebrochen; ihre tatsächliche Serverantwort wird erst im Vordergrund an den Buchungsentwurf geliefert. Kontowechsel trennt die Sitzung und übernimmt keine alte Antwort. Fehlgeschlagene Bestätigung erhält den gewählten Mittelpunkt. Die serverseitige Ortsanlage besitzt weiterhin keine Wiederholungs-ID: Bei verlorener Antwort und bewusster Wiederholung kann ein zusätzlicher gespeicherter Ort entstehen, jedoch keine Fahrtbuchung. Es wird kein unbestätigter Vorschlag zur Buchung verwendet.

Die Kunden-Live-Karte nach Buchung bleibt noch eingebettet. Erweiterte Disposition/Betreiberverwaltung bleibt im eigenen Portal. Physische Android-GPS-, angemeldete Kartenwahl-/Mehrgeräte- und Fahrer-Hintergrundprüfungen bleiben offen. Keine Production-Testfahrt oder Ortung erzeugt, keine neuen Konten, Rechte, bezahlten Tarife oder Store-Einreichungen.

## Prüfstand

15 zusätzliche Tests; insgesamt 357 Tests bestanden. Echte native React-Komponententests öffnen den Dialog, wählen beide Kartenpunkte, bestätigen sie über den isolierten API-Adapter und berechnen ein Angebot ausschließlich mit den gespeicherten IDs. Geprüft sind Straßenmaßstab/Ladezustand/Bewegung, keine Geokodierung beim Verschieben, doppelte Bestätigung, Netzfehler/Wiederholung, Vordergrundrückkehr, Kontowechsel, StrictMode, SDK-Importfehler und Token-vor-MapView-Reihenfolge. Die SDK-/Serverantworten dieser Komponententests sind isoliert, kein physischer Gerätebeweis.

Web-/Mobile-TypeScript und gezieltes Lint bestanden. Der gesamte bestehende App-Lint wird nicht als fehlerfrei behauptet. Lokale echte Bildschirmkomponente auf 390 × 844 und 390 × 640 geprüft, Scrollbreite jeweils 390, Bestätigung vollständig innerhalb des Viewports. Die Karte der Layoutvorschau ist eine ausdrücklich gekennzeichnete synthetische Skizze; sie ist kein Beweis für echte native Kartendaten. Screenshot: `outputs/native-map-point/picker-preview.png`.

Kunden-APK 0.6.7 / Build 21 gebaut, Signatur und Runtime-Variante geprüft und im isolierten Emulator als Update über 0.6.6 ohne Deinstallation installiert. Drei kalte Starts ohne native Fatal-/JS-Abstürze bestanden. Veröffentlichung wird nach Abschluss gesondert nachgewiesen. Website-Updates installieren keine APK auf Unternehmenshandys. Fahrer-APK bleibt unverändert 0.6.4 / Build 18.

Nächster Schritt: native Kunden-Live-Karte und angemeldete physische Geräteprüfung.

## APK-Nachweis

Datei: `mobile/artifacts/Luxore-Ride-Test-0.6.7.apk`, 56.109.048 Bytes, SHA-256 `b38ad9d8915c538f28e615548e0386e2eed2521ce7a8415b6101559666c62345`. Paket `de.luxoreride.customer.preview`, ARM64, Standalone-Bundle, nicht debuggbar, Designvorschau aus, Backup aus, keine Fahrer-Hintergrundortung, Mikrofon- oder Overlay-Berechtigung. Unveränderte interne Test-Signatur SHA-256 `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c`. Keine offizielle Store-Signatur behauptet.

Isolierter Quellbaum mit unveränderten vorhandenen Abhängigkeitsversionen; sieben Runtime-/Konfigurationsdateien bytegenau mit den tatsächlich gebauten Quellen verglichen. Android-Release-Build erfolgreich. Emulator-Update von 0.6.6 und drei Starts geprüft; Screenshot `outputs/native-map-point/customer-emulator-start.png`. Diese Startprüfung ist anonym: Die neue native Kartenwahl wurde durch Komponenten-/Controller-Tests geprüft, jedoch nicht als angemeldeter echter SDK-Kartendialog im Emulator oder auf einem Unternehmenshandy.
