# App gestures, settings and vehicle creation

## Vehicle creation fix

The shared Base UI button defaults to `type="button"`. The vehicle and new-fleet forms did not explicitly request `type="submit"`, so pressing their primary action did not submit the form. Both now declare the type. The extracted vehicle form is server-rendered with the actual UI components in the regression test, which verifies the resulting enabled/disabled submit control and preserved input values/errors.

A synchronous save lock prevents duplicate submissions. Inputs and dialog dismissal are blocked while saving. On a successful POST the dialog closes and confirms the saved vehicle even if the subsequent list read fails. List errors are separated from validation errors, with a retry that reads the list without repeating the create request. Each list response is scoped to its fleet and obsolete reads cannot overwrite a newer read. Existing server authorization, exclusive assignments, duplicate-plate checks and archive rules remain in force.

## Gestures and settings

Customer and driver ride sheets share direct pointer movement, velocity-aware stops, pointer cancellation and keyboard arrows. Only handles resize sheets; the content scrolls independently. Page swipes lock their axis, reject multi-touch and ignore controls, maps, nested swipe containers and portal content. During route selection a right swipe returns to the preceding booking step rather than switching to unrelated tabs.

One history guard serves nested app surfaces. Back closes the highest-priority open layer only, including settings, menu, checkout, pickup map, safety and vehicle dialogs. Callback changes do not add history entries. The hidden driver component remains mounted for location tracking but does not consume navigation gestures.

Settings have icon-led navigation choices and an automatic-open switch for drivers. Customers can adjust the existing temperature, conversation and music fields for their next request. Customer preferences remain the current request draft; only the driver's navigation preference is saved on the device. Settings/checkout can be pulled down by the top handle; the menu has a left-drag handle on its right edge. Close buttons and keyboard access remain available. Existing swipe-only trip acceptance is untouched.

## Multi-tab refresh

A 429 response to `tick` can mean another open tab already advanced dispatch. It no longer prevents booking/driver reads. Other errors remain visible. Hidden tabs stop workspace polling and refresh when visible again. Native location/offer service code is unchanged.

## Verification

- 20 focused Node tests: gesture direction/distance/axis ownership, layered Back/history lifecycle, real rendered vehicle form controls, client timeout/cancellation/429 handling, sheet stops, location authorization, navigation links.
- Local HTTP fleet suite: actual create/select/archive, duplicate plates, exclusive concurrent assignment, cross-fleet access, transfer, outstanding rides/payments, revenue and history.
- TypeScript, lint on changed files and production build.
- No browser-driven visual test or physical Android/iPhone touch test performed in this turn. Actual touch feel, keyboard/safe-area layout and external navigation handoff still require a device check.

No schema migration or replacement APK is required for these hosted web changes.
