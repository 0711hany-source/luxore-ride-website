# Native Adressauswahl · 10. Oktober 2026

Abgeschlossener Baustein für die vollständige native Kundenbuchung: `NativeAddressPicker` und `AddressSearchController`. Der Baustein ist noch nicht in `App.tsx` eingebunden. Kunden-APK bleibt 0.6.5 / Build 19, Fahrer-APK 0.6.4 / Build 18. Keine neue APK gebaut oder auf Nutzergeräten installiert. Das bestehende Buchungsformular und die Kunden-Live-Karte bleiben eingebettet.

## Verhalten

Das feste native Vollbildfenster verwendet Safe-Area, Tastaturausgleich, eine scrollbare Trefferliste und dieselben weißen, dunklen und goldenen Farben wie die bestehenden nativen Ansichten. Lange Adressen und Anbieterherkunft umbrechen. Suche ab drei Zeichen mit 600 ms Verzögerung; höchstens 256 Zeichen und zehn sichtbare Treffer. Die eigene HTTPS-API wird mit dem geschützten Kontotoken verwendet, ohne eingebettete Webseite oder Anbieter-Schlüssel im Baustein.

Temporäre Vorschläge werden nicht auf dem Gerät gespeichert oder als bestätigte Buchungsadresse verwendet. Erst die tatsächliche Antwort auf `kind: selected` liefert die dauerhaft bestätigte, dem Konto zugeordnete Adresse. Eingabeänderungen verwerfen eine frühere Auswahl sofort. Veraltete Suchantworten und deren Abschlussblöcke können neuere Treffer oder Ladezustände nicht überschreiben. Kontowechsel und Schließen verwerfen den bisherigen Suchzustand. Fehler bleiben sichtbar und wiederholbar; Anbieter- und Kontingentfehler werden nicht als erfolgreiche Adresse ausgegeben.

Beim Wechsel in den Hintergrund werden nur Vorschlagssuchen abgebrochen. Bereits abgeschickte Adressbestätigungen laufen bis zur Serverantwort weiter; deren Ergebnis wird erst bei Rückkehr in den Vordergrund an den Buchungsbildschirm übergeben. Eine Antwort für ein inzwischen geschlossenes Fenster oder anderes Konto wird dort nicht übernommen. Bestehende serverseitige Anbieterwahl, Geoapify-Kontingente und Mapbox-Permanent-Budget null bleiben unverändert.

## Prüfungen

- Acht neue Controller-Tests: Verzögerung/Eingabegrenzen, überholte Antworten, Hintergrund und Rückkehr, tatsächliche Bestätigung, geänderte Eingaben, ungültige Antworten, Kontingentfehler/Wiederholung und Entsorgung des Zustands.
- Vier echte React-Native-Komponententests: festes Fenster und Anbieterherkunft, Schließen während Suche, Bestätigung im Hintergrund und Kontowechsel während Bestätigung. Nur Plattformprimitive und eigene HTTP-Antworten sind synthetisch; die Suchkomponente, Steuerung und der native API-Client werden tatsächlich ausgeführt.
- Gesamtsuite: 324 Tests bestanden. Web-/Mobile-TypeScript und gezieltes Lint für die vier neuen Dateien bestanden.
- Echte Komponente über React Native Web mit ausschließlich lokalen Testantworten auf 390 × 844 geprüft. Dokumentbreite 390, kein horizontaler Überlauf; Auswahl liefert erst den bestätigten Testpunkt. Nachweise: `outputs/native-address-search/picker-preview.png` und `confirmed-preview.png`.

Diese Vorschau ist kein Android-Gerätenachweis und keine Production-Buchung. Keine realen Adressen bestätigt, Fahrzeuge oder Rechte geändert, Fahrer online gesetzt oder Fahrten ausgelöst. Die bereits bekannte physische Android-Schicht-/Hintergrund-GPS-Prüfung bleibt offen.

Nächster Schritt: Baustein in einen vollständig nativen Buchungsablauf mit Abholort/Ziel, Reservierungszeit, Streckenangebot, Klasse und tatsächlicher Buchungsbestätigung integrieren. Anschließend Kunden-APK bauen und angemeldeten Ablauf auf Unternehmensgeräten prüfen. Der einzelne Baustein ersetzt die bestehende funktionsfähige Buchung noch nicht.
