# Navigationseinstellungen und getrennte Flotten

Stand: 29.09.2026.

## Fahrerablauf

Menü → Einstellungen bietet Standard (Luxóre-Karte), Waze, Apple Maps und Google Maps. Auswahl und „Automatisch öffnen“ sind gerätespezifische, nicht autoritative lokale Einstellungen. Keine Kontoverbindung oder API-Schlüssel für diese Links erforderlich.

Nur eine vom Server bestätigte Fahrtannahme öffnet die Abholung; nur ein bestätigter Übergang zu „riding“ öffnet das Ziel. Polling, Rückkehr zur App, Ankunft und Fahrtende öffnen keine zusätzliche Route. Abgelehnte/abgelaufene Angebote schließen ein vorsorglich geöffnetes Browserfenster. Standard verkleinert das Fahrtblatt für mehr Karte. Manuelles Öffnen bleibt im Fahrtmenü möglich.

Die vorhandene Fahrer-APK übergibt HTTPS-Links bereits über React Native Linking. Deshalb ist für diese Änderung keine neue APK erforderlich. Ein Browser kann Pop-ups blockieren; dann bleibt der manuelle Link sichtbar und ein Hinweis erscheint. Apple Maps und die anderen Anbieter können noch eine Bestätigung in ihrer App verlangen. Standard ist die bisherige Luxóre-Karte, kein vollständiges Sprach-Navigations-SDK.

Offizielle Linkspezifikationen:
- https://developers.google.com/maps/documentation/urls/get-started
- https://developers.google.com/waze/deeplinks
- https://developer.apple.com/library/archive/featuredarticles/iPhoneURLScheme_Reference/MapLinks/MapLinks.html

## Flottenregeln

- Ein Fahrzeug gehört genau zur beim Anlegen ausgewählten Flotte. Fahrer sehen und wählen nur aktive Fahrzeuge ihrer Flotte, unabhängig davon, welcher Mitarbeiter das Fahrzeug angelegt hat.
- Neue Fahrer geben Name und Telefonnummer an. Fahrzeuge und Klassen werden zentral in der Flotte verwaltet; das frühere frei eingetragene Profilfahrzeug berechtigt nicht mehr zum Onlinegehen.
- Freigabe allein genügt nicht zum Onlinegehen: Ein reales, aktives Fahrzeug und eine gültige Mitgliedschaft sind erforderlich. Dieselbe Prüfung schützt Angebote, Annahme und native GPS-Updates.
- Ein Fahrzeug hat höchstens einen Fahrer. Gleichzeitige Auswahlen werden atomar entschieden. Die Leitung kann ein Fahrzeug für die nächste Schicht freigeben, solange der Fahrer offline ist, keine Standortsession läuft, keine aktive Fahrt und keine offene abgeschlossene Zahlung bestehen.
- Wiederholte Fahrerfreigabe lässt eine bestehende Schicht und Standortsession unverändert. Zurücknehmen ist erst nach Schichtende und Abrechnung möglich.
- Mitarbeiterwechsel zu einer anderen Flotte entfernt die Fahrzeugwahl und verlangt erneute Fahrerfreigabe. Historische Fahrten/Umsätze behalten ihren gespeicherten Flotten- und Fahrzeugbezug.
- Einladungen können keine andere Mitgliedschaft überschreiben; ein Beitritt übernimmt keine alte Fahrerfreigabe. Bestehende Konten, Fahrzeuge oder Flotten werden nicht pauschal umgehängt.
- Kennzeichen werden beim Anlegen unabhängig von Leerzeichen/Bindestrichen auf bestehende aktive Fahrzeuge geprüft. Verkaufte Autos bleiben mit ihrer Historie archiviert.
- Flottenmitglieder zeigen aktuellen Freigabestatus und gewähltes Kennzeichen. Fahrzeugbelegungen aktualisieren sich alle zehn Sekunden; Änderungen werden zusätzlich serverseitig geprüft.

Keine Schemaänderung oder Datenmigration. Vorhandene Profile ohne gültige Zuordnung müssen über ihre Flottenleitung zugeordnet werden und ein Fahrzeug wählen.

## Validierung

26 gezielte Node-Tests für Links/Zielwechsel, Vermittlung, Flottenberechtigung, Schichtzustand und native Standortberechtigung. Erweiterte lokale HTTP-Tests prüfen zwei Flotten, Einladungsbeitritt, fremde Fahrzeugauswahl, parallele Fahrzeugwahl, Freigabe/Verkauf, offene Zahlungen und unveränderte historische Umsätze. Standort-HTTP-Test prüft die bestehende native Berechtigungskette mit Flottenfahrzeug. TypeScript, gezieltes Linting und Produktionsbuild.

Noch am echten Gerät zu prüfen: Übergabe an jede installierte Navi-App, deren Startbestätigung und Rückkehr zur laufenden Luxóre-Schicht. Keine echten Kundenfahrten für Tests angelegt.
