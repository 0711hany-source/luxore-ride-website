# Eigenständiger Betrieb

Ziel: Unternehmenswebsite, API, eigene Konten und beide Apps ausschließlich unter https://luxoreride.de auf dem vorhandenen GitHub-/Vercel-Projekt. Next.js 16.4 / Node.js 24, unabhängige SQLite-kompatible libSQL-Datenbank. Keine Fremdanmeldung und kein Ersatzserver auf einer früheren Testplattform.

## Aktueller Schritt · 7. Oktober 2026

Der Nutzer hat ausdrücklich einen Neustart mit neuen Profilen bestätigt. Der bisherige Datenbestand und die alte Umgebung bleiben unverändert erhalten. Die Datenübernahme ist deshalb keine Voraussetzung mehr für diesen Neustart; eine spätere Zusammenführung benötigt einen gesonderten, geprüften Ablauf und darf keine neuen Profile überschreiben.

Turso Production ist mit 18 Migrationen und 21 Geschäftstabellen eingerichtet. Resend `luxore-account-mail` ist im kostenlosen Tarif ausschließlich mit Vercel Production verbunden. `luxoreride.de` ist für den Versand verifiziert, DKIM und `send`-SPF/MX sind vorhanden; die IONOS-Empfangseinträge der Hauptdomain bleiben erhalten. Native Integration liefert `RESEND_API_KEY` und `RESEND_EMAIL_DOMAIN` geschützt. Die Anwendung verwendet daraus `konto@luxoreride.de`; keine Schlüssel in Git, Chat oder APK. Anmeldecodes sind auf 90 pro UTC-Tag und 2.800 pro Kalendermonat begrenzt, unter dem gewählten Resend-Kontingent. Versandversuche zählen konservativ mit.

`LUXORE_ACCOUNTS_ENABLED`, `LUXORE_BOOKING_ENABLED`, Betreiberadresse und der bereits bereitgestellte öffentliche Karten-Token sind im Produktivdialog vorbereitet, aber noch nicht gespeichert. Die konkrete Freigabe hierfür ist ausstehend. Bis dahin bleibt die Online-Vermittlung ehrlich im Umstellungsmodus; eine verifizierte Versanddomain allein bestätigt weder eine zugestellte E-Mail noch eine erfolgreiche Betreiberanmeldung. Keine alten Ersatzserver verwenden.

Die internen Android-Apps 0.5.0 / Build 10 haben gemeinsame native Start-, Konto- und Menüoberflächen. Account-Sitzungen werden geschützt im Gerätespeicher gespeichert. Für die bestehenden Karten-, Fahrt-, Flotten- und Betreiberoberflächen wird weiterhin eine eingebettete Ansicht verwendet; das Produkt ist noch nicht vollständig nativ. Ein HTTP-only-Cookie wird über eine begrenzte eigene POST-Brücke gesetzt, ohne Anmeldetoken in URLs oder Seiten-JavaScript. Ein einmaliges APK-Update ist erforderlich. Physische Android-Prüfungen und Store-Freigaben sind weiterhin offen.

Prüfungen dieses Schritts: 196 Tests bestanden, Next.js-Produktionsbuild erfolgreich. Zwei zusätzliche Tests verhindern eine falsche App-Variante durch Build-Zwischenspeicher. Ein lokaler API-Fahrtablauf über fünf getrennte Gerätesitzungen bestätigt Flottenrechte, Klassen, Angebotsweitergabe, Fahrtabschluss und Kassieren. Native Oberflächen werden zusätzlich im Browser aus den echten React-Native-Komponenten geprüft; dies ersetzt keinen Android-Gerätetest.

**Kommerzieller Betrieb:** Das aktuelle Vercel-Team verwendet Hobby. Laut https://vercel.com/docs/plans/hobby ist dieser Tarif ausschließlich für nicht kommerzielle persönliche Nutzung vorgesehen. Für den offiziellen Fahrdienst ist ein geeigneter Tarif erforderlich; kein kostenpflichtiger Wechsel wurde vorgenommen. App-Store-/Play-Store-Hinweise bleiben „Bald verfügbar“.

Die folgenden Veröffentlichungsnachweise beschreiben ältere Stände; die aktuelle Entscheidung zum Neustart hat die damalige Pflicht zur vorherigen Migration ersetzt.

## Veröffentlichung und Prüfnachweis · 6./7. Oktober 2026

Die unabhängige Next.js-Version ist auf dem bestehenden Vercel-Projekt veröffentlicht. Domain: https://luxoreride.de. GitHub-Commit: `f249b85824f00e505f333b9c3ae25c59c24b5eeb` im Repository `0711hany-source/luxore-ride-website`. Vercel bestätigt „Deployment has completed“: https://vercel.com/luxoreride/luxore-ride-website/35veXNgZqauCn7LZnxfCKvB7gjtX. Der tatsächlich ausgelieferte HTML-Stand enthält diese Deployment-ID und die abschließenden Texte zur App-Verfügbarkeit. Fahrtanfragen führen während der Einrichtung zum persönlichen Kontakt.

Das veröffentlichte Quellarchiv entspricht dem lokalen Runtime-Commit `ff268d206e8e02cf4853850b3ab1332e9fad91e0`. 352 Dateien, 9.836.222 Bytes, SHA-256 `f8d10a87a2ff68788d69a298747ed293cee8324d29fda9fc3041685bdc9250da`. Die übertragenen Dateien wurden bytegenau mit GitHub abgeglichen. Die nachträgliche Dokumentation dieses Prüfnachweises ändert keinen veröffentlichten Runtime-Code.

Prüfungen: 175 Tests bestanden, TypeScript für Web und Mobile sowie Next.js-Produktionsbuild erfolgreich. Vollständige lokale Mehrgeräte-Fahrt und atomarer Import eines synthetischen Bestands über 21 Tabellen bestanden; dabei wurden keine echten Bestandsdaten übertragen. Die Live-Seiten für Kunden, Fahrer, Disposition, Konto, Betreiber, Kontakt, Hilfe und Datenschutz antworten auf der eigenen Domain. Alte `.html`-Weiterleitungen zeigen auf eigene Seiten. Vier Fahrzeug-/Markenbilder und zwei Stylesheets laden erfolgreich. `/api/health` liefert bewusst HTTP 503 mit `bookingConfigured:false`; die Session-API nimmt ohne Datenbank keine Buchungssitzung an. Die eigene Konto-API bleibt anonym mit `registrationReady:false`; fremde Identitätsheader erteilen keinen Kontozugang. Aktive eigene Textdateien und geprüftes Live-HTML enthalten keine früheren Plattformmarken oder Testdomain-Verweise.

Live-Nachweise: `docs/design-review/independent-company-live.png` und `docs/design-review/independent-account-live.png`. Physische Android-GPS-/Hintergrundprüfungen und iOS-Store-Freigaben wurden damit nicht durchgeführt.

Beide internen Android-APKs 0.4.4 / Build 9 sind gebaut, signaturgeprüft und verwenden ausschließlich die Unternehmensdomain. Die Signaturen entsprechen 0.4.3; das Update kann die bisherigen internen Apps ersetzen:

| App | Datei in `mobile/artifacts` | SHA-256 |
| --- | --- | --- |
| Kunde | `Luxore-Ride-Test-0.4.4.apk` | `6a4565d1e6bf54cc1ba73d84cbed7db6323dcae9c54702a46db38b9c550782ab` |
| Fahrer | `Luxore-Driver-Test-0.4.4.apk` | `943c32360b30ecdfbf08ca0dfe5a437e8f4009ee9d8a2f11f081a5d4f85b6d41` |

Damals nächster Schritt: vollständigen privaten Altbestand übernehmen und Versand konfigurieren. Dieser Plan ist durch den bestätigten Neustart mit erhaltenem Altbestand und die inzwischen verifizierte Versanddomain überholt. Bisherige Testumgebung erst nach gesicherter Datenübernahme stilllegen. Der Nutzer muss die neuen APKs einmal installieren; die Veröffentlichung aktualisiert keine bereits installierten alten Binärdateien. Keine neuen kostenpflichtigen Konten, Verträge oder Store-Einreichungen vorgenommen.

## Einrichtung der Datenbank

1. Eine SQLite-/libSQL-Datenbank im Unternehmenskonto bereitstellen, beispielsweise Turso/libSQL in einer geeigneten europäischen Region. Alternativ ein eigener Node-Server mit dauerhafter SQLite-Datei, Backups und Betriebsüberwachung. Eine temporäre Vercel-Datei ist keine dauerhafte Datenbank.
2. Im bestehenden Vercel-Projekt unter **Storage → Create Database → Turso** die native Verbindung einrichten. Vor „Accept and Create“ ist die konkrete Zustimmung zu Vercel-/Turso-Bedingungen und zur Weitergabe der Vercel-Konto-ID, E-Mail und Nutzungsdaten nötig. Danach nur den ausdrücklich bestätigten kostenlosen Tarif und eine geeignete europäische Region wählen. Keine kostenpflichtigen Optionen aktivieren. Die native Integration liefert `TURSO_DATABASE_URL` und `TURSO_AUTH_TOKEN` geschützt; Anwendung, Migration und Import erkennen diese direkt. Alternativ `DATABASE_URL` und `DATABASE_AUTH_TOKEN` verwenden. Eine explizite eigene URL hat Vorrang und verwendet niemals versehentlich den Token einer anderen Integration. Keine Schlüssel in Chat, Git oder öffentliche Archive schreiben.
3. Schema mit `node scripts/migrate-database.mjs` im getrennten Betriebsprozess anwenden. Migrationen werden mit Prüfsumme und atomarer Transaktion protokolliert; Wiederholung verändert angewendete Migrationen nicht.
4. Einen vollständigen privaten SQLite-Export des bisherigen Datenbestands herstellen. Während des tatsächlichen Umzugs Schreibzugriffe kontrolliert pausieren. Tabellenansichten mit gekürzten JSON-/Textwerten genügen nicht als Export. Im aktuellen Schritt wurde kein vollständiger Live-Export durchgeführt.
5. `node scripts/import-database.mjs /privater/pfad/bestand.sqlite` gegen eine leere Ziel-Datenbank ausführen. Der Import überschreibt keine vorhandenen Profile und übernimmt Buchungen, Flotten, Fahrzeuge, Konten, Bestand und Protokolle mit vorhandenen IDs. Er prüft die Dateiintegrität, hält eine konsistente Quelltransaktion und vergleicht vor Commit typisierte SHA-256-Inhaltsprüfsummen jeder Tabelle. Große Ganzzahlen, Binärwerte und vollständige Texte bleiben erhalten; Text wird bytegenau gebunden und SQL-seitig geprüft, damit eingebettete Nullzeichen nicht vom lokalen Treiber abgeschnitten werden. Unbekannte Geschäftstabellen und unterschiedliche Spalten werden vor dem Schreiben zurückgewiesen, damit keine Felder stillschweigend verlorengehen. Die Prüfsummen gelten vor dem absichtlichen Zurücksetzen alter Online-Zustände und Angebote. Die Buchungsaktivierung bleibt gesperrt. Bei fehlenden Tabellen, Inhaltsabweichungen oder Konflikten rollt die gesamte Transaktion zurück.
6. Fahreridentitäten auf der neuen Domain den übernommenen Mitarbeiterprofilen zuordnen und überprüfen. Alte Browsercookies sind an die alte Domain gebunden; deren Vorhandensein darf nicht angenommen werden. Ein Kennzeichen allein ist kein Identitätsnachweis. Fahrten, Reservierungen, offene Beträge, Flottenbesitz und Klassenfreigaben kontrollieren.
7. Erst nach erfolgreichen Live-Prüfungen `LUXORE_BOOKING_ENABLED=true` setzen und die neue Vercel-Version veröffentlichen. Ohne diese Freigabe ist der Produktionsserver im Umstellungsmodus, auch wenn eine Datenbank-URL hinterlegt wurde.
8. Die bisherige Testumgebung anschließend stilllegen und Daten gemäß dem bestätigten Aufbewahrungs-/Löschkonzept entfernen. Dieser Schritt ist noch offen; alte Umgebungen und bereits installierte frühere APKs lassen sich nicht durch einen Website-Commit löschen oder aktualisieren.

### Stand der konkreten Einrichtung · 7. Oktober 2026

Nach ausdrücklicher Zustimmung des Nutzers zu Marketplace-/Turso-Bedingungen wurde `luxore-ride-production` im bestehenden Unternehmenskonto angelegt. Tarif: Starter, 0 USD/Monat, ohne kostenpflichtige Optionen. Region: EU West / Irland (`aws-eu-west-1`, Marketplace `dub1`); Frankfurt war im angebotenen Regionsdialog nicht verfügbar. Native Verbindung ausschließlich mit Production von `luxore-ride-website`; Development, Preview und automatische Deployment-Zweige bleiben unverbunden. Vercel hinterlegt `TURSO_DATABASE_URL` und `TURSO_AUTH_TOKEN` als sensitive Servervariablen. Schlüssel wurden weder angezeigt noch in Git/Chat kopiert. Delete Protection ist eingeschaltet, Reads/Writes bleiben erlaubt, ATTACH ausgeschaltet.

Alle 18 Migrationen wurden über die SQL-Konsole im leeren Cloud-Speicher angewendet. Die anschließende Cloud-Abfrage bestätigt 18 Einträge in `_luxore_migrations`, 18 mit den lokalen Migrationen übereinstimmende SHA-256-Prüfsummen, 21 Geschäftstabellen und insgesamt 0 Geschäftsdatenzeilen. Es wurden keine echten Kunden-/Fahrer-/Fahrtdaten übertragen und keine Testprofile angelegt. Der vollständige private Altdatenexport fehlt weiterhin. Der Import bleibt gegen eine leere Geschäftsdatenbank ausführbar. Ein optionaler SQLite-Sicherungsdownload über das Dashboard lieferte noch keine herunterladbare Datei; Wiederherstellung und externe Sicherungen sind weiterhin offen.

Die Anwendung, Migration und Import erkennen die native Turso-Verbindung. 187 Tests und der Next.js-Produktionsbuild bestanden, darunter vollständiger Import über 21 Geschäftstabellen, Erhalt von Flottenrechten, Klassen und vereinnahmten Preisen, Abbruch bei unbekannten Feldern, Verhinderung einer Überschreibung, atomarer Rücklauf bei Trigger-/Constraintfehlern und exakter Umgang mit 64-Bit-Zahlen/Binärwerten/Texten. Der Umstellungsmodus bleibt bis zur Bestandsdatenübernahme, Identitätszuordnung und Live-Prüfung aktiv; `LUXORE_BOOKING_ENABLED` wurde nicht gesetzt. Der E-Mail-Versand bleibt unkonfiguriert.

### Veröffentlichung der nativen Verbindung · 7. Oktober 2026

GitHub-Commit `d62816dc1817748e7bfbb94d41e91dc9b9f37307` veröffentlicht die native Turso-Anbindung und den abgesicherten Import. Vercel bestätigt Production Ready für https://vercel.com/luxoreride/luxore-ride-website/4zXCj5QMwRCAXHHUz4qBGhsK27kk; luxoreride.de verwendet dieses Deployment. README, Quellarchiv und Versionsdatei wurden bytegenau mit dem öffentlichen Git-Commit abgeglichen. Archiv: 355 Dateien, 9.844.893 Bytes, SHA-256 `ecf3cd9f64f52f8a65f907af01795d43156e220d20f9b31af545c4eb29b6d9e9`, lokaler Basiscommit `460f7b1`.

Live-Prüfung: Unternehmensseite, Kunden-/Fahrer-App, Disposition und Konto liefern HTTP 200 ohne frühere Plattformverweise; App-Verfügbarkeit bleibt „Bald verfügbar“. `/api/health` liefert weiterhin den beabsichtigten HTTP 503 mit `bookingConfigured:false`. Dies ist keine fehlgeschlagene Datenbankeinrichtung: Der Produktionsschalter bleibt bis zum sicheren Umzug ausgeschaltet. Native Variablen sind durch die Integration vorhanden; reguläre Geschäfts-API-Abfragen sind vor Aktivierung weiterhin gesperrt. Echte Buchungen und eine Serverabfrage über die Geschäfts-API wurden auf dieser Cloud-Datenbank noch nicht getestet. Private Nachweise: `work/turso-production-live-checks.json`, `outputs/database-setup/turso-schema-verified.png` und `outputs/database-setup/vercel-database-deployment.png`. Diese Dokumentation ergänzt den Nachweis nach Veröffentlichung; sie verändert keinen ausgelieferten Runtime-Code.

## Eigene Konten

Anmeldung ausschließlich mit verifiziertem Luxóre-E-Mail-Code. Keine Übernahme fremder Identitätsheader oder Administratorrechte aus App-Eingaben. `LUXORE_ADMIN_EMAIL` im geschützten Vercel-Runtime auf die bestätigte Betreiberadresse setzen. Für E-Mails `RESEND_API_KEY` und verifiziertes `LUXORE_MAIL_FROM` bereitstellen. Native Resend-Verbindung und Versanddomain sind inzwischen eingerichtet. Der erste Login mit der konfigurierten Betreiberadresse legt erst nach erfolgreichem E-Mail-Code ein Betreiberkonto an. Sein Fahrereintrag bleibt ungeprüft; Profilname und Telefonnummer sind anschließend zu ergänzen. Neue Fahrer/Flotten bleiben bis zur betrieblichen Prüfung ungeprüft.

## GitHub / Vercel

Das bestehende Repository enthält das öffentliche Projektarchiv und `vercel-bootstrap.mjs`. Der Build stellt daraus den geprüften Next.js-Projektbaum her. Root-Paket, pnpm-Lockdatei und Arbeitsbereichskonfiguration werden separat eingecheckt; Vercel erkennt pnpm automatisch und baut die unabhängige Anwendung mit den festgelegten Abhängigkeiten. Keine Weiterleitungen zu fremden Testdomains. Alte `.html`-Links werden auf eigene Seiten umgeleitet; das bestehende Unternehmensimpressum bleibt unter `/impressum.html` erhalten. Anwendung, Datenbank und E-Mail-Schlüssel bleiben getrennt.

Die bisherige Git-Historie bleibt erhalten; frühere Revisionen sind keine aktuelle Betriebsanleitung. Private Sicherungen in ignorierten Arbeitsverzeichnissen werden nicht hochgeladen. Website-Publikation allein bestätigt weder eine vorhandene Datenbank noch eine aktivierte Vermittlung.

## Android / iOS

Version 0.5.0 / Build 10 startet mit nativen Oberflächen und verwendet ausschließlich luxoreride.de für Konto-API, eingebettete Fahrtansichten, Standort und Fahrtalarme. Einmalig die neuen APKs installieren; alte APKs enthalten ihre frühere feste Adresse. Keine automatische Änderung alter Binärdateien behaupten. Interne APKs behalten `.preview` und interne Signierung, Store-Apps getrennte offizielle Kennungen. Android-Geräteprüfung und iOS-Build-/Geräte-/Store-Freigaben stehen weiter aus.

## Weitere Voraussetzungen

Dauerhafte Reservierungsaktivierung durch einen vertrauenswürdigen Scheduler, Betriebsüberwachung, Backups/Wiederherstellung, vollständige rechtliche Betreiberangaben, Dienstleistervereinbarungen und ggf. Kartenzahlungsanbindung vor offiziellem Start fertigstellen. Store-Hinweise bleiben „Bald verfügbar“.
