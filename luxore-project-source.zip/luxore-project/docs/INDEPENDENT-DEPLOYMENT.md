# Eigenständiger Betrieb

Ziel: Unternehmenswebsite, API, eigene Konten und beide Apps ausschließlich unter https://luxoreride.de auf dem vorhandenen GitHub-/Vercel-Projekt. Next.js 16.4 / Node.js 24, unabhängige SQLite-kompatible libSQL-Datenbank. Keine Fremdanmeldung und kein Ersatzserver auf einer früheren Testplattform.

## Aktueller Schritt

Runtime, Datenbankadapter, Login, Web-/Mobile-Adressen und Veröffentlichungspaket umgestellt. Die Datenbanktransaktionen erhalten Fahrzeug-Speicherung, parallele Fahrtannahme, Bordbestand und unveränderliche Abrechnung. Die Unternehmenswebsite bleibt aktiv. Die Online-Vermittlung bleibt vorerst im Umstellungsmodus: eine unabhängige dauerhafte Datenbank ist noch nicht vorhanden und Bestandsdaten wurden noch nicht übertragen. Bis dahin keine neuen Online-Buchungen annehmen und keine vermittelten Fahrer vortäuschen.

## Einrichtung der Datenbank

1. Eine SQLite-/libSQL-Datenbank im Unternehmenskonto bereitstellen, beispielsweise Turso/libSQL in einer geeigneten europäischen Region. Alternativ ein eigener Node-Server mit dauerhafter SQLite-Datei, Backups und Betriebsüberwachung. Eine temporäre Vercel-Datei ist keine dauerhafte Datenbank.
2. `DATABASE_URL` und `DATABASE_AUTH_TOKEN` als geschützte Vercel-Umgebungswerte hinterlegen. Keine Schlüssel in Chat, Git oder öffentliche Archive schreiben. Gebühren/Verträge wurden nicht abgeschlossen.
3. Schema mit `node scripts/migrate-database.mjs` im getrennten Betriebsprozess anwenden. Migrationen werden mit Prüfsumme und atomarer Transaktion protokolliert; Wiederholung verändert angewendete Migrationen nicht.
4. Einen vollständigen privaten SQLite-Export des bisherigen Datenbestands herstellen. Während des tatsächlichen Umzugs Schreibzugriffe kontrolliert pausieren. Tabellenansichten mit gekürzten JSON-/Textwerten genügen nicht als Export. Im aktuellen Schritt wurde kein vollständiger Live-Export durchgeführt.
5. `node scripts/import-database.mjs /privater/pfad/bestand.sqlite` gegen eine leere Ziel-Datenbank ausführen. Der Import überschreibt keine vorhandenen Profile und übernimmt Buchungen, Flotten, Fahrzeuge, Konten, Bestand und Protokolle mit vorhandenen IDs. Er prüft Zeilenzahlen, setzt alte Online-Zustände zurück und lässt die Buchungsaktivierung gesperrt. Bei fehlenden Tabellen oder Konflikten rollt die gesamte Transaktion zurück.
6. Fahreridentitäten auf der neuen Domain den übernommenen Mitarbeiterprofilen zuordnen und überprüfen. Alte Browsercookies sind an die alte Domain gebunden; deren Vorhandensein darf nicht angenommen werden. Ein Kennzeichen allein ist kein Identitätsnachweis. Fahrten, Reservierungen, offene Beträge, Flottenbesitz und Klassenfreigaben kontrollieren.
7. Erst nach erfolgreichen Live-Prüfungen `LUXORE_BOOKING_ENABLED=true` setzen und die neue Vercel-Version veröffentlichen. Ohne diese Freigabe ist der Produktionsserver im Umstellungsmodus, auch wenn eine Datenbank-URL hinterlegt wurde.
8. Die bisherige Testumgebung anschließend stilllegen und Daten gemäß dem bestätigten Aufbewahrungs-/Löschkonzept entfernen. Dieser Schritt ist noch offen; alte Umgebungen und bereits installierte frühere APKs lassen sich nicht durch einen Website-Commit löschen oder aktualisieren.

## Eigene Konten

Anmeldung ausschließlich mit verifiziertem Luxóre-E-Mail-Code. Keine Übernahme fremder Identitätsheader oder Administratorrechte aus App-Eingaben. `LUXORE_ADMIN_EMAIL` im geschützten Vercel-Runtime auf die bestätigte Betreiberadresse setzen. Für E-Mails `RESEND_API_KEY` und verifiziertes `LUXORE_MAIL_FROM` bereitstellen. Versandzugang noch nicht eingerichtet. Neue Fahrer/Flotten bleiben bis zur betrieblichen Prüfung ungeprüft.

## GitHub / Vercel

Das bestehende Repository enthält das öffentliche Projektarchiv und `vercel-bootstrap.mjs`. Der Build stellt daraus den geprüften Next.js-Projektbaum her. Root-Paket, pnpm-Lockdatei und Arbeitsbereichskonfiguration werden separat eingecheckt; Vercel erkennt pnpm automatisch und baut die unabhängige Anwendung mit den festgelegten Abhängigkeiten. Keine Weiterleitungen zu fremden Testdomains. Alte `.html`-Links werden auf eigene Seiten umgeleitet; das bestehende Unternehmensimpressum bleibt unter `/impressum.html` erhalten. Anwendung, Datenbank und E-Mail-Schlüssel bleiben getrennt.

Die bisherige Git-Historie bleibt erhalten; frühere Revisionen sind keine aktuelle Betriebsanleitung. Private Sicherungen in ignorierten Arbeitsverzeichnissen werden nicht hochgeladen. Website-Publikation allein bestätigt weder eine vorhandene Datenbank noch eine aktivierte Vermittlung.

## Android / iOS

Version 0.4.4 / Build 9 verwendet ausschließlich luxoreride.de für WebView, Standort und Fahrtalarme. Einmalig die neuen APKs installieren; alte APKs enthalten ihre frühere feste Adresse. Keine automatische Änderung alter Binärdateien behaupten. Interne APKs behalten `.preview` und interne Signierung, Store-Apps getrennte offizielle Kennungen. Android-Geräteprüfung und iOS-Build-/Geräte-/Store-Freigaben stehen weiter aus.

## Weitere Voraussetzungen

Dauerhafte Reservierungsaktivierung durch einen vertrauenswürdigen Scheduler, Betriebsüberwachung, Backups/Wiederherstellung, vollständige rechtliche Betreiberangaben, Dienstleistervereinbarungen und ggf. Kartenzahlungsanbindung vor offiziellem Start fertigstellen. Store-Hinweise bleiben „Bald verfügbar“.
