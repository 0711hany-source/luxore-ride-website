# Native Stellvertretungswahl · Fahrer 0.7.2 / Build 26

## Abgeschlossener Schritt

Die native Disposition öffnet ein festes Vollbildfenster für die Stellvertretung der konkret gewählten Flotte. Nur deren Besitzer oder der vorhandene Plattformbetreiber sehen die Steuerung. Wählbar sind tatsächlich vom fleets-Endpunkt gelieferte Mitarbeiter derselben Flotte, einschließlich Personal ohne Fahrerprofil; der Besitzer und fremde Flottenmitarbeiter sind ausgeschlossen. Keine Stellvertretung hebt die vorhandene Wahl auf. Gesperrte Zielkonten prüft der bestehende atomare Server erneut; deren Kontostatus ist in dieser Übersicht nicht enthalten. Die Besitzer-/Stellvertretungszuordnung selbst wird ausschließlich aus den Server-IDs gelesen.

Auswahl und Aufhebung bestätigen Nutzer ausschließlich per vollständiger Wischgeste, ohne Tippen-Ersatz. Bestehende Flotte, Besitzer, Fahrerfreigaben, Fahrzeuge und GPS-Schichten bleiben erhalten. Der vorhandene deputy-Endpunkt prüft aktuelle Konten-/Leitungsrechte und Mitarbeiterzugehörigkeit im selben libSQL-Schreibzugriff wie Änderung und Audit; kein neuer Endpunkt oder Datenbankschritt. Native Funktionsbereitstellung ist keine tatsächliche Production-Rechteänderung.

Der ältere Codebeitritt im nativen Fahrzeugbereich war noch per Tippen möglich. Dieser Schreibweg ist entfernt: der dortige Einstieg öffnet nun ausschließlich die vorhandene native Einladungsseite mit Wischbestätigung. Kein zweiter Beitritts-Schreibweg und keine eingebettete Fahrer-Webseite.

## Lifecycle und Bestätigung

OperationsController verwendet dieselbe kontogebundene Lese-/Schreibsperre für Fahrerfreigabe und Stellvertretung. Eine ausstehende oder unklare Änderung sperrt die andere Aktion. Der tatsächliche fleets-GET bindet Mitarbeiter, userId und canManage an die vorhandene abortierbare Momentaufnahme. Änderung nur im aktiven Vordergrund aus einem höchstens 30 Sekunden alten, vollständig geladenen Stand. Hintergrund beendet ausschließlich Reads/Polls; bestätigende POSTs laufen bis zur tatsächlichen Antwort. Alte Antworten/finally und Kontodispose bleiben abgesichert. Keine optimistische Wahl oder automatische Wiederholung.

Bei verlorener Antwort darf ausschließlich dieselbe ausdrückliche Wahl erneut bestätigt werden. Eine frische Momentaufnahme mit gewünschter Stellvertretung bestätigt den aktuellen Stand ohne zusätzlichen POST. Das ist Zustandsbestätigung, keine dauerhaft gespeicherte Auftragsquittung. Identische bestätigte Wahl ist in der Oberfläche gesperrt; Änderung anderer Flotten bleibt bei offener Wahl gesperrt. Kein dauerhaft gespeicherter Stellvertretungsauftrag nach Prozessneustart, dann zuerst aktuellen Stand lesen. Bekannte Ablehnung behauptet keinen Erfolg. Bei verlorenem Besitzerrecht ist die Steuerung gesperrt/verborgen; 401/403 entfernen die Daten. Aufheben einer vorhandenen Stellvertretung bleibt auch möglich, wenn deren Profil in dieser Liste fehlt.

## Prüfungen und Grenzen

Sechs neue Controller-Tests: Besitzer-/Betreiber-/Fremdflottenscope, frischer Stand und Hintergrund; Schreibbestätigung/Parallelität ohne GPS-Reset; gleicher Retry und Lese-Reconciliation; gegenseitige Sperre mit Fahrerfreigabe und Aufhebung fehlenden Altprofils; bekannte Ablehnung/uneindeutige Antwort; Rechteentzug und Kontodispose. Drei tatsächliche React-Native-Komponententests: feste Teamwahl und vollständige Wischwahl/-aufhebung, reiner Stellvertreter ohne Besitzersteuerung und identische Wiederholung nach 503, Fahrzeug-Fallback ohne Codefeld/Beitritts-POST. Insgesamt 475 Tests bestanden; bestehende native Dispositions-/Buchungs-/Fahrzeugprüfungen erhalten.

Lokale echte Komponenten-Vorschau mit ausschließlich synthetischen Personen bei 390×844 und 390×640: feste Vollbildwahl, kein äußerer horizontaler Überlauf, Wischfläche im kleinen Fenster y=559–613 erreichbar. UI-Geste erzeugt nur eine synthetische lokale Serverantwort. Keine Production-Freigabe, Stellvertretungswahl, Einladung, Buchung, Fahrzeug-/Bestands-/GPS-Änderung. Keine Gebühren, neuen Anbieterrechte oder Store-Einreichung.

Neue Fahrer-APK 0.7.2 / Build 26 erforderlich; Kunde bleibt 0.6.9 / Build 23. Physische angemeldete Team-/Mehrgeräte-/Schicht-/Hintergrund-GPS-Prüfungen bleiben offen. Keine Installation auf Nutzerhandys oder Produktionsreife behaupten. Native Teamzuordnung und Flottengründung sind weiter offen. Als nächstes die native Mitarbeiterzuordnung/Entfernung mit bestehenden Betreiber-/Besitzer-/Stellvertreterscopes abschließen oder konkrete Gerätefehler bearbeiten.

## APK und Veröffentlichung

Fahrer-APK mobile/artifacts/Luxore-Driver-Test-0.7.2.apk: 56166024 Bytes, SHA-256 `a77b91f1e9880f10d3b6e2b127d416216e019f2dcbcb27c6192fce4f2437de8b`. Paket de.luxoreride.driver.preview / Build 26 mit unveränderter interner Signatur `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c`. Standalone ARM64, nicht debuggbar, Designvorschau/Backup aus, bestehende Alarm-/Hintergrundstandortberechtigungen erhalten, Mikrofon/Overlay gesperrt. 51 Runtime-/Konfigurationsquellen bytegenau mit dem außerhalb des synchronisierten Quell-/Abhängigkeitsordners gebauten Stand abgeglichen; Paketversionen unverändert. Finaler Fahrer-/Internal-JS-Bundlebuild ausdrücklich wiederholt, Release-Assemblierung erfolgreich.

Im isolierten Emulator als Update über 0.7.1 / Build 25 ohne Deinstallation installiert, drei Kaltstarts ohne Android-Fatal-/JS-Exception bestanden. Anonymer nativer Start; keine angemeldete tatsächliche Team-/SDK-/Schicht- oder physische GPS-Prüfung. Nachweis outputs/native-deputy/driver-emulator-start.png und work/native-deputy/emulator-result.json. Keine Installation auf Nutzerhandys. Beide TypeScript-Prüfungen, gezieltes Lint, Format- und Diff-Prüfung bestanden.

Geschützte APK-Download- und Quellveröffentlichungsnachweise werden nach bestätigter Veröffentlichung ergänzt.
