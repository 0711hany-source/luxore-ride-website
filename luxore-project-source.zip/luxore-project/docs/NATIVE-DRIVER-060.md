# Direkte native Fahrer-App · 0.6.0 / Build 14

8. Oktober 2026: Der Nutzer meldet Abstürze und fehlendes GPS beim Öffnen einer zweiten App-Oberfläche. Die Fahrer-APK startet nach eigener Anmeldung jetzt direkt im nativen Cockpit. Der Fahrerzweig von `mobile/src/App.tsx` mountet `RideWorkspace` nicht; die Website wird nicht in einer zweiten Fahrer-WebView geöffnet.

## Umgesetzt

- Native Mapbox-Karte: @rnmapbox/maps 10.3.7, Mapbox Android SDK 11.23.1. Heller Straßenstil, 3D-Gebäude, native Route und eigener goldener Navigationspfeil. Logo und Herkunftshinweis bleiben sichtbar. Zusätzliche SDK-Telemetrie ist deaktiviert.
- Kontinuierliche Vordergrundortung direkt über Expo Location, ohne JavaScript-Brücke zu einer Webseite. Die angefragte Sekundentaktung ist eine Betriebssystemanforderung, keine garantierte Messfrequenz. Uploads sind auf höchstens einen je drei Sekunden begrenzt und überlappen nicht; der bestehende unabhängige Hintergrunddienst bleibt aktiv.
- Frischen Hintergrundstandort und bestehende Schicht beim Zurückkehren wieder aufnehmen. Kontoprofil in SecureStore sitzungsgebunden wiederherstellen, ohne bei Netzwerkproblemen das Konto zu löschen. Änderungen und Rechte bleiben serverseitig geprüft.
- Native Schicht-/GPS-Anzeige unterscheidet Offline, fehlende Freigabe, veraltetes GPS, Verbindungsprüfung und bestätigte Online-Präsenz. Kein endloser GPS-Einstiegsbildschirm. Native Karte wird beim Hintergrundwechsel/anderen Menüseiten freigegeben; Standortdienst läuft unabhängig weiter. Eine Karten-JS-Ausnahme wird lokal abgefangen und bietet Wiederherstellung; native GPU-/Betriebssystemabstürze werden dadurch nicht generell ausgeschlossen.
- Karten-Sheet am Griff nach unten wischen, um mehr Karte zu sehen; automatisch wieder folgen nach drei Sekunden ohne Kartengeste. Bestehende begrenzte, straßennahe `NavigationMotion(true)` statt Sprung zwischen Browser-Pins. Rohe Standortmessungen für Vermittlung bleiben unverändert. Verkehrsrouten nur für eigene aktive Fahrten, ohne vereinbarten Preis zu ändern.
- Direkte native Fahrzeugauswahl mit Flotten-/Belegungs-/Schicht-/Zahlungsgrenzen. Native Fahrzeugformulare mit festem Dialog, Tastaturausgleich, normalisierten Feldern, stabiler Speicher-ID und serverseitiger Konfliktprüfung. Bearbeiten/Archivieren/Wiederherstellen verwenden die bestehenden API-Rechte.
- Fahrtangebot mit Abholung, Ziel, Preis, Bordbestellung und Fahrtwünschen; Annahme ausschließlich durch vollständiges Wischen. Ebenso Fahrtstatus, Übergabe und Zahlung, ohne zusätzliche Tippannahme. Bargeld oder externes Terminal erst nach tatsächlichem Kassieren bestätigen.
- Tagesumsatz, Fahrthistorie und Gesamtumsatz je Flotte/Fahrer. Teamübersicht ist nativ; weitergehende Mitarbeiter-/Betreiberaktionen bleiben im eigenen Portal.
- Nativer Bordbestand: 24 Kühlplätze, Snackkapazität, Ist/Soll/Meldeschwelle/Platzbedarf, revisionsgeschützte Zählung, Eigenverbrauch, Einkaufsliste zum Teilen und bewusstes Nachfüllbestätigen. Entwürfe bleiben bei Serverkonflikt erhalten; Neuladen/Auto wechseln fragt vor Verwerfen.

## Prüfungen

234 automatisierte Tests bestanden. Neue Tests prüfen Schicht-/Fahrzeuggrenzen, nicht überlappende GPS-Uploads, sitzungsgebundenen Offline-Profilcache und sichere native API-Query-Parameter. Echte React-Komponenten werden mit isolierten Testadaptern gerendert: direkter Fahrer-Einstieg ohne WebView, erfolgreiche Fahrzeug-Speicherung in der gewählten Flotte, native Anfangsbestands-Speicherung und Wischannahme ohne Tippalternative. Diese Adapter senden keine synthetischen Positionen oder Geschäftsdaten an Production und ersetzen keinen Android-Gerätetest.

Web- und mobile TypeScript bestanden. Neue native Module bestehen die gezielte Lintprüfung; zwei dokumentierte PanResponder-Ausnahmen betreffen ausschließlich den React-Compiler, der die gespeicherten imperativen Event-Referenzen als Render-Zugriffe bewertet. Die übrigen Regeln bleiben aktiv. Beide vollständigen Android-Release-Assemblierungen, Manifestprüfung, deaktiviertes Debugging, ARM64-Bibliotheken, eigenständiges Bundle und Signaturprüfung bestanden. In der Fahrer-APK sind `libmapbox-common.so` und `libmapbox-maps.so` sowie die nativen Bord-/Fahrzeugtexte enthalten.

| Interner Build | Bytes | SHA-256 |
| --- | ---: | --- |
| Luxore-Driver-Test-0.6.0.apk | 55.490.192 | c11c97958cf5d0dadd07c5156129b40102d4fbbcdce6780bbeca840957c22cdb |
| Luxore-Ride-Test-0.6.0.apk | 55.518.176 | 52b1ddae0630863850e581d60664732c8e6844d779120b84649c536adceefbb6 |

Beide internen `.preview`-Kennungen und Signatur `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c` bleiben gleich. Als Update installieren, nicht vorher deinstallieren. Interne Debug-Schlüssel-Signatur ist keine Store-Signatur; beide APKs sind nicht debuggable. Kunden-APK verlangt weiterhin keinen Fahrer-Hintergrundstandort. Keine Binärdateien, Keystores, Tokens oder privaten Zugangsdaten im öffentlichen Quellenarchiv.

## Noch offen

ADB meldet kein angeschlossenes Gerät. Darum sind echter Schichtstart, physische GPS-Kadenz/-Latenz, OEM-Akkumanagement, externe Navigation, gesperrter Bildschirm, Wiederaufnahme und native GPU-Stabilität noch nicht bewiesen. Der Fahrer braucht in Android den genauen Standort und für die Schicht „Immer zulassen“. Erzwungenes Beenden oder entzogene Berechtigungen können die Ortung unterbrechen.

Kundenbuchung ist weiterhin eingebettet. Vollständige native Kundenkarte/-Buchung, erweiterte Disposition und Betreiberfreigaben folgen. Die bestehende Betreiberrolle und der gewählte Audi wurden nicht neu vergeben oder verändert. Kein künstlicher Live-Schichtstart, keine Fahrt und keine Zahlung angelegt. Native Online-Updates, iOS und Store-Einreichung sind nicht aktiviert. Bestehende kommerzielle Hosting-/Suchanbieter-Voraussetzungen bleiben in der Roadmap; keine neue kostenpflichtige Verbindung oder Migration eingerichtet.
