# Nativer Capability-GPS-Upload · 17. Oktober 2026

## Nachgewiesene Fehler

POST /api/mobility/location prüfte die native Capability vor Body-/Rate-Limit-Arbeit. Eine danach gesetzte Kontosperre oder Löschvormerkung wurde im GPS-Update und beim späteren Lesen von Angebotsmetadaten nicht berücksichtigt. Bestehende SQL-Guards schützten bereits gegen viele alte/abgelaufene Tokens, andere Sessions und entzogene Fahrer-/Fahrzeugrechte; deren Anfragen erhielten jedoch weiter 200/updated:false statt einer erkennbar beendeten Freigabe.

Ein SQL-Fehler im tatsächlichen Dispatch oder anschließendem Angebotslesen lieferte außerdem 500, obwohl der GPS-Punkt bereits committed war. Beim Lesen darf ein Fehler nicht als offer:null erfunden werden: Das wäre für den nativen Alarmcontroller eine bestätigte Angebotsrücknahme.

## Änderung

lib/mobility/native-upload.ts liest die aktuelle Capability samt Session, Fahrerfreigabe, Ablauf, aktivem Fahrzeug/Flottenmitgliedschaft und aktuellem Kontostatus erneut unter derselben libSQL-Schreibsperre wie den GPS-Punkt. Hash, eigene Fahrer-ID und Session müssen mit dem vorgelagert gelesenen Ziel übereinstimmen. Eine inzwischen ungültige Freigabe bleibt 401 ohne GPS-/Queueänderung, auch nach asynchroner Rate-Limit-Arbeit. Der Ablauf wird mit aktueller Serverzeit im Schreibzugriff geprüft. Gültige Altidentitäten ohne lokalen Accountdatensatz bleiben kompatibel. Bereits im bestehenden Speicher-SQL und beim Angebotslesen gilt zusätzlich die aktuelle Kontosperre.

Die bisherigen Rohkoordinaten-/Genauigkeits-/erforderlichen Zeitstempelregeln bleiben erhalten. Alte oder doppelte Punkte einer weiterhin gültigen Freigabe liefern 200/updated:false und keinen Dispatch; neue gültige Punkte speichern wie bisher den Gerätezeitstempel als location_at. Bestehender Rate-Limit-Aufruf native-location/90 bleibt an derselben Stelle vor dem GPS-Schreibzugriff; ein Versuch kann deshalb bereits gezählt sein, bevor ein anschließender Freigabeentzug erkannt wird. Kein zusätzlicher Retry oder alter Punktestau.

Nach committed neuem Punkt läuft der bestehende Dispatch getrennt. Fehler werden protokolliert und verfälschen die GPS-Bestätigung nicht. Anschließend liest die vorhandene SQL-Abfrage weiterhin nur aktuelle opaque Angebots-ID/Ablaufzeit, mit aktueller Konto-/Capability-/Session-/Fahrer-/Fahrzeugprüfung. Ein erfolgreicher leerer Read liefert weiterhin offer:null. Bei einem tatsächlichen Lesefehler wird offer dagegen ausgelassen; ok:true/updated/serverTime bestätigen ausschließlich das GPS-Ergebnis. Der unveränderte native parseAlertReply der Fahrer-APK 0.8.5 verwirft eine Antwort ohne offer als Alarmantwort, sodass keine erfundene Rücknahme oder neue Meldung entsteht. Vorhandene lokale Alarmfristen laufen nach ihren bestehenden Regeln weiter. Späterer gewöhnlicher gültiger Upload kann wieder tatsächliche Angebotsdaten liefern.

Ein GPS-Speicherfehler bleibt Fehler und überspringt Dispatch/Angebotslesen. Konto-/Freigabewiderruf nach dem Commit kann bereits gespeicherten Punkt nicht rückwirkend entfernen; das spätere Angebotslesen ist trotzdem erneut kontogeschützt. Keine globale Queue-Erfolgsgarantie. Native Capability-Pause und ihre bisherige nativeSessionSql bleiben unverändert, ebenso authentifizierter Heartbeat und abgeschlossene Start-/Stop-/Bereinigungsabläufe. Profil, Freigabe, Fahrzeugauswahl, Teamrechte und Geschichte werden durch den GPS-Schreibschritt nicht zurückgesetzt. Keine neue Route, Migration, Berechtigung, Abhängigkeit oder APK.

## Prüfungen

19 neue Tests rufen den tatsächlichen Endpunkt mit echtem sqliteDatabase/libSQL-Adapter, vorhandenen Migrationen und tatsächlichem Dispatch auf. 14 scheitern im bisherigen Stand: Kontosperre/Löschvormerkung, erkennbarer Freigabeentzug bei mehreren Capability-/Session-/Fahrzeugänderungen, Kontosperre während Rate-Limit-Arbeit, zwei echte Dispatch-SQL-Abbruchtrigger, Angebotsdaten nach Kontosperre und tatsächlicher SQL-Lesefehler durch lokal umbenannte synthetische Angebotstabelle. Der letzte Fall bindet den unveränderten tatsächlichen nativen Parser ein und bestätigt, dass eine reine GPS-Quittung keine Alarmantwort ergibt.

Kontrollen sichern Rohpunkt-/Identitätsbindung, unveränderte Capabilities/Rechte/Geschichte, ausschließlich opaque Angebotsmetadaten, alte/doppelte Punkte ohne Dispatch, Altidentität, bestehenden Rate-Limit-Aufruf samt Ablehnung, erforderlichen Zeitstempel und Genauigkeit. Ein echter Trigger im GPS-Update belegt unveränderten Bestand und späteren ausdrücklich gesendeten gültigen Folgepunkt. Bestehende native Stopp-/Start-/Qualitäts-/Alarmtests bleiben Teil der gesamten Suite.

Gesamtstand nach Prüfabschluss: 681 Tests, beide TypeScript-Prüfungen und gezieltes Lint/Format. Exakter Archivbuild und Veröffentlichung werden unten belegt.

## Grenzen und nächster Schritt

GPS-Bestätigung gilt nur für diesen damaligen Schreibzugriff, weder als aktuelle dauerhafte Schichtquittung noch als Queue-/Angebotsgarantie. Der bestehende native Client erkennt Fehler beim Metadatenlesen durch die fehlende vollständige Alarmantwort, zeigt dadurch jedoch keinen neuen eigenen Angebots-Lesefehlerhinweis. Vorhandene Alarme werden bei unbekanntem Read nicht ausdrücklich zurückgenommen; sie unterliegen weiter ihren lokalen Fristen. Netz-/Commit-Transportfehler können unklar bleiben, langsame Body-/Speicher-/native Promises erhalten keine zusätzliche Zeitgrenze. Keine neue physische Navigation, Ton-/OS-Zustellgarantie oder Mehrprozessprüfung.

Kunden-APK 0.6.9 / Build 23 und Fahrer-APK 0.8.5 / Build 39 unverändert. Android-/Signatur-/Emulatornachweise stammen weiterhin vom zuvor geprüften Build; keine neue Geräteinstallation. Keine Production-Schicht, Position, Fahrt, Alarm oder Rechteänderung ausgelöst. Physische angemeldete Geräte-/Mehrgeräte-/Hersteller-/Straßen-/Hintergrundprüfungen bleiben offen.

Nächster unabhängiger Schritt: den tatsächlichen nativen GPS-Antwort-/Alarmdatenfluss bei überlappenden Antworten mit fehlenden Angebotsmetadaten lokal auf einen reproduzierbaren Reihenfolgefehler prüfen; diese Upload-/Start-/Stopguards nicht erneut implementieren.
