# Offizieller Start – Stand 06.10.2026

## Umgesetzt

- Unternehmenswebsite mit bestätigten Fahrzeugklassen, freigegebenen Kilometerpreisen, Geschäftskontakt und ehrlichen „Bald verfügbar“-Hinweisen für App Store und Google Play. Keine falschen Store-Downloadlinks und keine erfundenen Kundenbewertungen.
- `/konto`: getrennte Registrierung für Fahrgäste, Fahrer und Flotten; Anmeldung mit einmaligem E-Mail-Code; Profilpflege, Abmelden und Kontolöschanfrage. Eigene Luxóre-Anmeldung ohne ChatGPT für Fahrgäste/Fahrer.
- `/betreiber`: nicht in der öffentlichen Navigation verlinkt und von Indexierung ausgeschlossen. Jeder Datenzugriff und jede Änderung benötigt serverseitig das freigegebene Betreiberkonto. Flottenleiter bekommen dadurch keine Gesamtverwaltungsrechte.
- Betreiberübersicht: Tagesumsatz (Berlin-Zeit), aktuelle Fahrer, offene Fahrerprüfungen, offene Kassierbeträge, Flotten-/Fahrzeug-/Kontenzahlen, laufende Fahrten und Reservierungen; Profilfilter/Suche/Seitenwechsel, Fahrergenehmigungen, bestehende Flottenverwaltung und Änderungsprotokoll. Die Flottenleitung kann der Betreiber bewusst an einen anderen freigegebenen, abgerechneten Mitarbeiter derselben Flotte übertragen; veraltete Zustände und fremde Flotten werden abgewiesen.
- Serverkonfiguration für den Betreiber: `LUXORE_ADMIN_EMAIL=operator@example.com` (vom Nutzer bestätigt). Bestehender ChatGPT-Betreiberzugang bleibt als Übergang zugänglich; ein verifiziertes eigenes Luxóre-Konto dieser Adresse erhält später ebenfalls Betreiberzugriff. Kein öffentlicher Bootstrap-Code und kein selbst auswählbarer Administratorstatus.
- Android-Store-Profile für beide Apps in `mobile/eas.json`, stabile getrennte Paketkennungen ohne `.preview`, iOS-Kennungen und verständliche Standortbegründungen vorbereitet. Interne Android-APKs behalten ihre bisherigen Kennungen und Signatur.
- GitHub-Prüfworkflow vorbereitet. Eine Browseranmeldung bei GitHub stellt noch keine Git-Push-Anmeldung oder verknüpfte Repository-Veröffentlichung her. Der Workflow wurde noch nicht auf GitHub ausgeführt.

## Eigene Registrierung: noch nicht aktiv

Der Nutzer hat ausdrücklich noch keinen E-Mail-Versanddienst. Implementiert ist die REST-Anbindung an Resend; es wurde kein Konto erstellt, kein Bezahlvertrag abgeschlossen und keine echte E-Mail zu Testzwecken versandt.

1. Ein Resend-Konto im Unternehmensbesitz einrichten und die Absenderdomain verifizieren.
2. Einen nur für den Versand geeigneten API-Schlüssel erstellen; nicht in Chatnachrichten oder Git speichern.
3. `RESEND_API_KEY` als Sites-Secret und `LUXORE_MAIL_FROM` als verifizierten Absender hinterlegen, beispielsweise einen tatsächlich freigegebenen Absender unter luxoreride.de.
4. Die gespeicherte Website-Version mit der neuen Laufzeitrevision erneut veröffentlichen.
5. Echte Registrierung, Zustellung/Spamordner, Codeablauf, Anmelden auf einem zweiten Gerät und Betreiberzugang prüfen. Danach die Hinweise zum noch fehlenden Versand aktualisieren.

Bis dahin zeigt die Oberfläche die Einschränkung, der Codeversand antwortet 503 und speichert keine Registrierungsdaten. Bestehende Gastbuchungen und interne Fahrergeräte funktionieren weiterhin. Die Aktivierung allein ist keine automatische Freigabe aller Konten für den Fahrdienst.

## Authentifizierung und Migration

- 6-stellige Codes, 10 Minuten, höchstens fünf Versuche; einmalige atomare Einlösung, Codehash mit zufälliger Challenge-ID. Keine Codes in Antworten/Protokollen.
- Begrenzung je E-Mail und vertrauenswürdigem IP-Header sowie global; ein neuer Code erst nach einer Minute. Tagesmaximum 200 Versandversuche für diese Site. Fehlversuche zählen konservativ mit; das ist kein Konto-weites Kostenlimit bei Resend.
- Kontositzung mit 256 Bit Zufall, SHA-256-Hash in D1, HttpOnly/Secure/SameSite-Cookie, 30 Tage. Gesperrte Konten scheitern bereits an der Identitätsprüfung. Fremde Benutzer-IDs und Rollen aus dem Client erzeugen keine Rechte.
- Ein bestätigtes neues Konto kann die nachgewiesene, noch freie Gerätesitzung übernehmen. Dadurch bleiben bestehende Fahrer-/Flottenzuordnungen und Fahrthistorien erhalten. Alte Gastschlüssel dieses Kontos werden widerrufen. Bereits existierende Konten werden anhand ihrer bestätigten E-Mail wiederhergestellt; unterschiedliche Profile werden nicht still zusammengeführt.
- Anmelden unter anderer Identität, Profiländerung, Abmelden, Sperren und Löschen lassen keine laufenden Kunden-/Fahrerfahrten oder offenen Fahrerzahlungen zurück. Eine gestartete Schicht muss zuerst pausiert werden.
- Neue Fahrer-/Flottenkonten erzeugen nur ein ungeprüftes Fahrerprofil. Flottenzuordnung, behördliche Unterlagen, Fahrzeuge und Fahrerfreigabe bleiben gesonderte betriebliche Schritte.

## Löschablauf

Die Kontolöschung kann direkt in der App angefordert werden. Eine erfolgreiche Anfrage sperrt das Konto, beendet alle Sitzungen, widerruft native Standortschlüssel und storniert spätere eigene Reservierungen. Der Betreiber erhält eine Löschwarteschlange. Die Abschlussaktion entfernt Konto, temporäre Challenges, gespeicherte Adressen und Angebote und anonymisiert persönliche Felder der verbleibenden Betriebsdaten. Bei Flottenbesitzern ist zuerst die Leitung zu übertragen.

Dies ist ein funktionierender Bearbeitungsablauf, noch kein Nachweis der vollständigen Store-/Datenschutzfreigabe: Bearbeitungsfrist, Datenkategorien mit gesetzlicher Aufbewahrung, Löschung in Backups und konkrete Dienstleistervereinbarungen sind verbindlich festzulegen. Belege mit gesetzlicher Aufbewahrung werden nicht pauschal gelöscht. Die Store-Prüfung verlangt eine verständliche tatsächliche Löschmöglichkeit, nicht nur einen E-Mail-Link.

## Externe Voraussetzungen für die offiziellen Apps

- Google Play Console und Apple Developer-Konten in Unternehmensbesitz, Identitäts-/Unternehmensverifikation und produktive Signierung. Keine Einreichung oder Gebührenzahlung vorgenommen.
- EAS/Expo-Projekte für **beide** Paketvarianten verbinden; keine erfundene Projekt-ID oder Apple-Team-ID verwenden. Laufzeit-/OTA-Erweiterungen erfordern einen passenden nativen Build; Web-Oberflächen werden bereits durch die gemeinsame Website aktualisiert.
- Echte Android-Tests einschließlich Batterie-/Herstellereinstellungen und Hintergrundortung. iOS braucht eigene Berechtigungs-, Ortungs-, Alarm- und Gerätetests; eine konfigurierte Bundle-ID ist keine fertige iOS-App.
- Store-Privacy-/Data-Safety-Angaben, Android-Hintergrundstandort-Erklärung und echtes Review-Testkonto erst nach freigegebenem Ablauf einreichen.
- Ausfallsichere Reservierungsaktivierung unabhängig von offenen Apps, Betriebsüberwachung, Wiederherstellung und Datensicherung einrichten. Das derzeitige Dispatch-Tick-Protokoll benötigt dafür einen externen vertrauenswürdigen Scheduler; allein die offenen Apps sind keine ausreichende Betriebsabsicherung.
- Kartenzahlungsanbieter und Zahlungsbedingungen anbinden, sofern Kartenzahlungen angeboten werden sollen. Derzeit werden keine Kartenzahlungen verarbeitet.

## Unternehmensangaben

Startseite und Impressum von luxoreride.de am 06.10.2026 erneut geprüft. Öffentlich auffindbar: LUXORÉ RIDE, Gerhart-Hauptmann-Ring 224, 60439 Frankfurt am Main, +49 160 5083829, booking@luxoreride.de; Fahrzeug-/Serviceangaben wie in WEBSITE-REFERENCE.md.

Kein eindeutiger vollständiger Inhabername und keine Rechtsform auf diesen Seiten. Keine Person aus einem Testfahrerprofil als rechtlichen Betreiber erfinden. Das alte Impressum verwendet noch TMG und den früheren OS-Plattform-Hinweis; nicht als aktualisierte Rechtsprüfung übernehmen. Neue Datenschutzinformationen beschreiben die Online-Datenverarbeitung, sind aber noch mit den vollständigen Betreiberangaben, Aufbewahrungsfristen und Dienstleistervereinbarungen abzugleichen.

## Referenzen

- https://resend.com/docs/api-reference/emails/send-email
- https://developer.apple.com/support/offering-account-deletion-in-your-app/
- https://support.google.com/googleplay/android-developer/answer/13327111
- https://support.google.com/googleplay/android-developer/answer/9799150
- https://www.gesetze-im-internet.de/ddg/__5.html
- https://eur-lex.europa.eu/eli/reg/2016/679/oj?locale=de
- https://docs.expo.dev/build/eas-json/

## Prüfung und Veröffentlichung

171 automatisierte Tests bestanden, darunter acht neue Prüfungen der echten Konto-/Betreiber-APIs mit isolierter SQLite-Datenbank und synthetischem E-Mail-Provider. Der lokale Mehrgeräte-Buchungsablauf bleibt erfolgreich. Web-/Mobile-TypeScript sowie die produktiven Android-/iOS-Konfigurationen beider Varianten geprüft; vier JavaScript-Exporte (beide Apps, beide Plattformen) erfolgreich. Dies ersetzt weder native Store-Builds noch Geräteprüfungen.

Lokale Sichtprüfung von Kontoseite und Betreiberkonsole auf Smartphone-/Desktopbreite; Fahrzeugdialog erreichbar und innerhalb des sichtbaren Fensters. Screenshot `docs/design-review/operator-desktop.jpg` zeigt lokale Testdaten, keine echten Betriebsumsätze. Website-Build und Veröffentlichung erfolgen durch den offiziellen Sites-Ablauf; erst ein erfolgreicher Deployment-Status bestätigt, dass diese Änderungen online sind.

Veröffentlichung am 06.10.2026, 20:08 UTC bestätigt: Version 40, Quellcommit `7efa7df257ea380ce8b0f80ec5bc10700a08331a`, Laufzeitrevision 4, Status `succeeded`. Online unter https://luxore-ride-frankfurt.lucky-goose-6238.chatgpt.site. Deployment-ID: `appgdep_6ac5551b263481919586d94d356f79d3`. Diese nachträgliche Veröffentlichungsliste dokumentiert den bestätigten Stand; sie verändert die veröffentlichte Anwendung nicht. luxoreride.de/DNS, E-Mail-Versand, GitHub-Repository und Store-Veröffentlichungen wurden nicht umgestellt oder aktiviert.
