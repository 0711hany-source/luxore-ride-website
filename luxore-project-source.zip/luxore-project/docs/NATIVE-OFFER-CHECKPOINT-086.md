# Native Alarm-Reihenfolge ohne Angebotsmetadaten · Fahrer 0.8.6 / Build 40

## Nachgewiesener Fehler

Der Server kann seit dem getrennten nativen GPS-Speicher-/Angebotsleseablauf einen tatsächlich gespeicherten GPS-Punkt bestätigen, während Angebotsdaten wegen eines Lesefehlers unbekannt bleiben. offer fehlt dann absichtlich; offer:null wäre eine erfundene Rücknahme. Fahrer 0.8.5 ignorierte diese gesamte Antwort einschließlich ihres neueren Serverzeitpunkts. Eine verspätete ältere vollständige Antwort konnte dadurch anschließend noch einen neuen nativen Fahrtalarm auslösen.

## Änderung

Der tatsächliche location-service verwendet jetzt parseLocationAlertUpdate. Vollständige bisherige Alarmantworten laufen weiter durch den unveränderten strengen parseAlertReply. Eine GPS-Bestätigung ohne eigene offer-Eigenschaft wird zusätzlich nur bei ok:true, booleschem updated und endlichem numerischem serverTime als Reihenfolgegrenze angenommen. Fehlende Quittung, ungültige Felder oder ausdrücklich vorhandene defekte Angebotsdaten setzen keine solche Grenze.

Der bestehende serialisierte Alarmcontroller prüft für diese Grenze dieselbe aktuelle Standortfreigabe, liest den geschützten schichtgebundenen Alarmstand und speichert nur den neueren checkedAt-Wert. Kein dismiss, present oder neuer seenId; bestehender Alarm und seine ursprüngliche lokale Frist bleiben unverändert. Eine anschließend eintreffende ältere oder gleich alte vollständige Antwort kann keinen neuen Alarm mehr auslösen. Spätere vollständige neue Antworten und ausdrücklich gelieferte offer:null-Rücknahmen bleiben nutzbar. Auch updated:false kann eine aktuelle GPS-Bestätigung mit unbekannten Angebotsdaten sein.

Bestehende Lifecycle-/Session-/Token-/Ablaufprüfungen am tatsächlichen Upload und bei jeder nativen Alarmplanung bleiben erhalten. Deadline-/Roundtrip-/Queue-Abzüge, Zweitprüfung nach nativer Alarmbereinigung, Dedup, Ton/Vibration/Kanal, Berechtigungen, Roh-GPS/Qualitätsfilter und Netzcache unverändert. Keine Abbrüche oder automatische Wiederholung bestätigender Schicht-/Fahrtwrites, keine neue API, Serveränderung, Migration oder Rechteausweitung.

## Prüfungen

Sechs neue Tests binden den tatsächlichen location-service, Vordergrund- und TaskManager-Uploads, echten Alarmcontroller und tatsächliche offer-alerts mit isolierten Expo-Location-/TaskManager-/SecureStore-/Notifications-Adaptern und kontrolliertem fetch ein. Vier scheitern im bisherigen Code: zwei überlappende Antworten (updated true/false), bestehender nativer Alarm mit verspätetem anderem Angebot und der fehlende neue Zeitstand vor einer gültigen Folgeantwort.

Kontrollen bestätigen unveränderten vorhandenen Alarm/seenId ohne zusätzliche native Entfernung, gültige spätere Angebote und echte Rücknahmen, Zurückweisung defekter oder nicht quittierter Payloads sowie keinen Zustandswechsel nach verspäteter alter Capability-Antwort in einer neuen Schicht. 687 Tests insgesamt, beide TypeScript-Prüfungen und gezieltes Lint/Format bestanden.

## Grenzen

Die Grenze ist erst nach erfolgreicher Freigabeprüfung und geschützter Speicherung wirksam. Bereits begonnene native Alarmarbeit beziehungsweise ans OS übergebene Planung kann nicht rückwirkend ungeschehen werden; keine sofortige Ton-/OS-Stoppgarantie. Ein Speicherfehler bleibt Fehler; ohne gespeicherte Grenze gibt es keinen dauerhaft bestätigten neueren Alarmstand. Unbekannte Angebotsdaten erzeugen weiterhin keinen zusätzlichen sichtbaren Lesefehlerhinweis und bestätigen weder Angebot noch Rücknahme. Bestehende lokale Alarmfristen bleiben maßgeblich. Keine neue Begrenzung hängender nativer/Body-/Speicher-Promises.

Physische angemeldete Ton-/Geräte-/Mehrprozess-/Hersteller-/Straßen-/Hintergrund-GPS-Prüfungen bleiben offen. Sämtliche neuen Testdaten und HTTP-Antworten sind lokal synthetisch; keine Production-Schicht, Position, Fahrt, Alarme oder Rechteänderung ausgelöst.

## Android und Veröffentlichung

Fahrer-APK 0.8.6 / Build 40 benötigt ein internes Update auf dem Gerät. Kunden-APK 0.6.9 / Build 23 bleibt unverändert; Website-Updates installieren keine APK. Android-Build außerhalb synchronisierter Quellen in 6m 7s (394 Tasks) erfolgreich. Alle 86 Runtime-/Asset-/Konfigurationsdateien einschließlich tatsächlicher gemeinsamer Imports nach dem Build bytegenau geprüft; alle 21 direkten installierten Paketversionen und das Lockfile unverändert. Vorhandenes Signaturzertifikat SHA-256 fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c und Manifest-Berechtigungen unverändert. APK: 56.221.840 Bytes / SHA-256 66e58f32bf255872caf4e72a480bcf5b2eacb3d89f96c4d2796b5bfd73946e6b. Update über 0.8.5 ohne Deinstallation im isolierten Emulator und drei anonyme Kaltstarts ohne Absturz bestanden; Loginansicht geprüft, Emulator beendet. Keine physische angemeldete Prüfung. Veröffentlichungsnachweis folgt nach Abschluss unten. Nur geschützter interner GitHub-Entwurf, keine öffentliche Binary-/Store-Freigabe.

Nächster unabhängiger Schritt: den tatsächlichen nativen Alarmcontroller bei unterbrochener SecureStore-Speicherung und danach eintreffenden älteren Antworten lokal auf einen konkret reproduzierbaren Fehler prüfen; diese GPS-/Alarm-Reihenfolgegrenze und abgeschlossene Start-/Stop-/Uploadguards nicht erneut implementieren.
