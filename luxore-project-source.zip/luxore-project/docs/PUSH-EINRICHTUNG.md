# Push an Fahrer einrichten: „Eine Fahrtanfrage wartet. Bitte online gehen.“

Stand: 14.11.2026. Der Code ist fertig vorbereitet, aber **ausgeschaltet**, bis die Schritte unten erledigt sind. Ohne Einrichtung passiert nichts: keine Nachricht, kein Fehler, keine Verzögerung bei Buchungen.

## Was die Funktion macht

- Ein Kunde stellt eine Anfrage (sofort, oder eine Reservierung wird fällig) und **kein freier Chauffeur dieser Klasse ist online**.
- Dann bekommen die **freigegebenen Fahrer mit aktivem Fahrzeug dieser Klasse, die offline sind**, eine Nachricht auf das Handy: „Eine Fahrtanfrage wartet. Bitte online gehen.“
- In der Nachricht stehen **keine Kundendaten**, keine Adresse, kein Preis.
- Jeder Fahrer bekommt **höchstens eine solche Nachricht alle 10 Minuten**.
- Tippen auf die Nachricht öffnet LUXORÉ Driver (Startansicht).
- Der bisherige Alarm für Fahrtangebote (wenn der Fahrer online ist) bleibt unverändert.

## Was gebraucht wird

Ein kostenloses Firebase-Projekt von Google (Tarif „Spark“, für Nachrichten fallen keine Kosten an). Daraus entstehen zwei Dinge:

1. eine Datei `google-services.json` – sie kommt **in die Fahrer-App** (beim Bau der APK),
2. ein Dienstkonto-Schlüssel – daraus kommen **drei Werte auf den Server**.

Beides sind Zugangsdaten. Nicht per Chat verschicken, nicht ins Repository legen.

## Schritt 1: Firebase-Projekt anlegen

1. https://console.firebase.google.com öffnen und mit dem Google-Konto des Betriebs anmelden.
2. „Projekt hinzufügen“ → Name z. B. `luxore-ride` → Google Analytics kann ausgeschaltet bleiben → „Projekt erstellen“.
3. Die **Projekt-ID** notieren (Zahnrad → Projekteinstellungen → „Projekt-ID“, z. B. `luxore-ride-1a2b3`).

## Schritt 2: Die Fahrer-App im Projekt anmelden

1. In den Projekteinstellungen unter „Meine Apps“ auf das Android-Symbol klicken.
2. Android-Paketname: `de.luxoreride.driver` → „App registrieren“. Die übrigen Felder können leer bleiben.
3. **Noch einmal** „App hinzufügen“ → Android → Paketname: `de.luxoreride.driver.preview` (das sind die Test-APKs).
4. Erst danach die Datei `google-services.json` herunterladen. Sie muss **beide** Paketnamen enthalten; sonst bricht der Bau der Test-APK ab.
5. Die Schritte „Firebase SDK hinzufügen“ in der Konsole können übersprungen werden; das erledigt der Bau.

## Schritt 3: Datei in das Projekt legen

Die Datei umbenennen und hier ablegen:

```
mobile/google-services.driver.json
```

- Die Datei steht in `mobile/.gitignore` und wird nicht committet.
- Liegt die Datei dort, baut `bash scripts/build-android-preview.sh driver` die Fahrer-App **mit** Push. Liegt sie nicht dort, wird die App genau wie bisher gebaut.
- Die Kunden-App (LUXORÉ Ride) bekommt nie Push.

## Schritt 4: Dienstkonto-Schlüssel erzeugen

1. Firebase-Konsole → Zahnrad → Projekteinstellungen → Reiter „Dienstkonten“.
2. „Neuen privaten Schlüssel generieren“ → eine `.json`-Datei wird heruntergeladen. Sicher aufbewahren, nicht ins Projekt legen.
3. Aus dieser Datei werden drei Werte gebraucht:

| Name auf dem Server | Feld in der Schlüsseldatei |
| --- | --- |
| `FCM_PROJECT_ID` | `project_id` |
| `FCM_CLIENT_EMAIL` | `client_email` |
| `FCM_PRIVATE_KEY` | `private_key` (der ganze Text von `-----BEGIN PRIVATE KEY-----` bis `-----END PRIVATE KEY-----`) |

Falls die Konsole fragt: Die „Firebase Cloud Messaging API (V1)“ muss aktiviert sein (Projekteinstellungen → Cloud Messaging). Bei neuen Projekten ist sie es normalerweise.

## Schritt 5: Werte eintragen

**Lokal auf dem Mac** – in die Datei `.env.local` drei Zeilen ergänzen (der Schlüssel in Anführungszeichen, die `\n` so lassen, wie sie in der Datei stehen):

```
FCM_PROJECT_ID=luxore-ride-1a2b3
FCM_CLIENT_EMAIL=firebase-adminsdk-xxxxx@luxore-ride-1a2b3.iam.gserviceaccount.com
FCM_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nMIIE...\n-----END PRIVATE KEY-----\n"
```

Danach den lokalen Server neu starten.

**Live (Vercel)** – erst nach ausdrücklicher Freigabe von Hanan: Vercel → Projekt → Settings → Environment Variables → dieselben drei Namen für „Production“ anlegen. Wirksam wird es erst mit dem nächsten Upload/Bau. Dabei muss auch die neue Datenbanktabelle angelegt werden (Migration `0019_driver_push_tokens.sql`, Befehl `pnpm db:migrate` gegen die Live-Datenbank – ebenfalls nur nach Freigabe).

Fehlt einer der drei Werte oder ist der Schlüssel unvollständig, bleibt die Funktion still ausgeschaltet.

## Schritt 6: Testen

1. Datei aus Schritt 3 ablegen, neue Fahrer-APK bauen und auf einem Android-Handy installieren.
2. In LUXORÉ Driver als freigegebener Fahrer anmelden und Benachrichtigungen erlauben (die Abfrage kommt wie bisher beim Einschalten der Fahrtangebots-Benachrichtigungen).
3. Die App einmal schließen und wieder öffnen. Dabei meldet sie ihr Gerät am Server an.
4. Der Fahrer bleibt **offline**. Sein Fahrzeug muss für die Klasse freigegeben sein, die gleich angefragt wird.
5. Mit einem Kundenkonto eine Sofortfahrt dieser Klasse anfragen.
6. Erwartet: Innerhalb weniger Sekunden erscheint auf dem Fahrer-Handy „Eine Fahrtanfrage wartet. Bitte online gehen.“ Tippen öffnet die App.
7. Sofort eine zweite Anfrage stellen: Es darf **keine** zweite Nachricht kommen (10-Minuten-Sperre).

Wichtig für den Test: Die App spricht mit dem Server, für den sie gebaut ist. Die APKs sprechen mit `https://luxoreride.de`. Ein Test auf dem Handy geht also erst, wenn Server-Teil und Werte live sind – oder mit einem eigens gegen einen Testserver gebauten Paket.

## Was geprüft ist und was nicht

Geprüft (automatische Tests auf dem Mac, ohne echtes Firebase):

- Auswahl der Empfänger (nur freigegebene, offline, passende Klasse, aktives Fahrzeug, nicht in einer Fahrt).
- 10-Minuten-Sperre je Fahrer.
- Ohne die drei Werte passiert nichts.
- Nur ein angemeldeter, freigegebener Fahrer kann sein eigenes Gerät anmelden (Kunde: abgelehnt, ohne Anmeldung: abgelehnt).
- Die Anmeldung bei Google wird korrekt signiert; die Nachricht enthält keine Kundendaten.
- Ungültig gewordene Geräteadressen werden gelöscht.
- Fahrer-App und Server lassen sich ohne Firebase-Datei fehlerfrei bauen bzw. prüfen.

**Ungeprüft** (geht nur mit echtem Firebase-Projekt und Handy):

- Ob Google die Nachricht wirklich annimmt und zustellt.
- Ob der Bau der APK mit `google-services.driver.json` durchläuft.
- Ob das Handy die Nachricht bei geschlossener App, im Stromsparmodus und bei gesperrtem Bildschirm zuverlässig zeigt (hängt auch vom Hersteller ab).
- Ob Tippen auf die Nachricht auf jedem Gerät die Startansicht öffnet.
- iPhone: nicht vorbereitet. Dafür wären zusätzlich ein Apple-Entwicklerkonto und ein APNs-Schlüssel in Firebase nötig.

## Bekannte Grenzen

- Die Nachricht wird ausgelöst, wenn eine Anfrage angelegt wird und wenn der Zeitgeber (`/api/mobility/tick`) läuft. Für fällige Reservierungen gibt es noch keinen eigenen Zeitgeber auf dem Server (siehe Problemliste); bis dahin wird eine Reservierung erst zur Anfrage, wenn irgendeine App geöffnet ist.
- Eine Sofortanfrage wird nach 3 Minuten ohne Annahme als „Kein Fahrer verfügbar“ beendet. Der Fahrer muss also innerhalb dieser Zeit online gehen. Ob diese Frist verlängert werden soll, entscheidet Hanan.
- Je Fahrer ist ein Gerät gespeichert (das zuletzt angemeldete). Beim Abmelden wird es entfernt.
- Die Datenschutzerklärung nennt Firebase bisher nicht. Vor dem Einschalten im Live-Betrieb prüfen lassen (Rechtstexte wurden nicht geändert).
