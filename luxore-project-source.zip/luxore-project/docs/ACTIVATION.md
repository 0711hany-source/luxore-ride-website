# Aktivierung und erster Betriebstest

Stand: 7. Oktober 2026. Kostenloses Turso und Resend sind ausschließlich mit Production verbunden, Datenbankschema und Versanddomain geprüft. Die konkrete Bestätigung für Produktivschalter und Betreiberzuordnung steht aus. Keine echte Betreiberanmeldung oder zugestellte Anmelde-E-Mail nachgewiesen. Alter Bestand bleibt beim bestätigten Neustart erhalten.

## Nach bestätigter Freischaltung

1. Geschützt in Vercel Production `LUXORE_ACCOUNTS_ENABLED=true`, `LUXORE_BOOKING_ENABLED=true`, `LUXORE_ADMIN_EMAIL` auf die vom Betreiber bestätigte Adresse sowie dessen bereits bereitgestellten öffentlichen Mapbox-Token setzen. Keine Resend-/Turso-Schlüssel anzeigen oder manuell kopieren. Neue geprüfte Version veröffentlichen.
2. `/api/health` muss tatsächlich Datenbankzugriff bestätigen (`databaseConnected`, `accountsReady`, `bookingConfigured`). Konto-API muss anonym `registrationReady:true` liefern, ohne private Profile auszugeben. Einrichtung alleine gilt nicht als Fahrttest.
3. https://luxoreride.de/konto?weiter=/betreiber öffnen, **Anmelden** wählen und die bestätigte Betreiberadresse eingeben. Den erhaltenen Code nur dort selbst eingeben. Erst erfolgreiche Verifizierung erzeugt beim ersten Betreiberlogin dessen Konto. Andere neue Nutzer wählen **Registrieren**.
4. Betreiberprofil mit tatsächlichem Namen und Telefon vervollständigen. In der Betreiberübersicht neue Fahrer-/Flottenprofile prüfen, Freigaben und Zuordnungen vornehmen. Ein Betreiberkonto wird nicht automatisch als Fahrer freigegeben.
5. Flotte und Fahrzeuge anlegen, Klassen und Mitarbeiterzuordnung prüfen. Fahrzeug-Speicherung nach vollständigem Schließen und erneutem Öffnen der App kontrollieren. Ohne freigegebenen Fahrer/zugeordnetes Fahrzeug keine Vermittlung erwarten.
6. Neue Kunden-/Fahrer-APK installieren. Mit zwei realen Geräten vollständigen Ablauf durchführen: Suche, Angebot per Wischen, Annahme, Anfahrt, Abholung, Fahrt, Abschluss und tatsächlich kassierter Betrag. Keine Annahme allein durch Tippen hinzufügen.
7. Fahrerortung während gesperrtem Bildschirm und externer Navigation prüfen, anschließend Rückkehr und Neustart. GPS-Latenz und Pfeilbewegung auf echten Aufnahmen beurteilen.

## Vor offiziellem Start

Vercel Hobby ist für persönliche nicht kommerzielle Projekte vorgesehen: https://vercel.com/docs/plans/hobby. Geeigneten kommerziellen Tarif bestätigen; keine kostenpflichtige Umstellung vorgenommen. Backups und Wiederherstellung, Scheduler für Reservierungen, Betriebskontrolle, Rechtsangaben und ggf. Kartenzahlungen abschließen. Interne APKs sind keine Store-Veröffentlichung. Native Karten-/Fahrtansichten, physische Geräteprüfung und iOS bleiben offen.
