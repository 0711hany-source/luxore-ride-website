# Aktivierung und erster Betriebstest

Stand: 7. Oktober 2026. Kostenloses Turso und Resend sind ausschließlich mit Production verbunden, Datenbankschema und Versanddomain geprüft. Die konkrete Bestätigung ist erteilt und die Produktionsschalter einschließlich Betreiberadresse sind gespeichert. Live-Health bestätigt Datenbank, Konten und Buchungskonfiguration. Eine erste Betreiber-Anmelde-E-Mail ist laut Resend zugestellt; die authentifizierte Betreiber-Flottenansicht mit drei Fahrzeugen ist inzwischen im Live-Browser sichtbar. Keine weitere Freischaltungsbestätigung verlangen. Alter Bestand bleibt beim bestätigten Neustart erhalten.

## Aktivierter Stand und erster Betriebstest

1. Erledigt: Vercel Production verwendet `LUXORE_ACCOUNTS_ENABLED=true`, `LUXORE_BOOKING_ENABLED=true`, die bestätigte Betreiberadresse und den bereitgestellten öffentlichen Mapbox-Token. `MAPBOX_PERMANENT_DAILY_LIMIT=0` hält permanente Geokodierungsanfragen ausgeschaltet. Geschützte native Resend-/Turso-Verbindungen bleiben erhalten.
2. Erledigt: `/api/health` liefert HTTP 200 mit `databaseConnected:true`, `accountsReady:true`, `bookingConfigured:true`. Konto-API liefert anonym `registrationReady:true`, `account:null` und `isAdmin:false`. Die Seiten zeigen das Aktivierungsdeployment. Dies ist kein vollständiger realer Fahrttest.
3. https://luxoreride.de/konto?weiter=/betreiber öffnen, **Anmelden** wählen und die bestätigte Betreiberadresse eingeben. Den erhaltenen Code nur dort selbst eingeben. Erst erfolgreiche Verifizierung erzeugt beim ersten Betreiberlogin dessen Konto. Andere neue Nutzer wählen **Registrieren**.
4. Betreiberprofil mit tatsächlichem Namen und Telefon vervollständigen. In der Betreiberübersicht neue Fahrer-/Flottenprofile prüfen, Freigaben und Zuordnungen vornehmen. Ein Betreiberkonto wird nicht automatisch als Fahrer freigegeben.
5. Flotte und Fahrzeuge anlegen, Klassen und Mitarbeiterzuordnung prüfen. Fahrzeug-Speicherung nach vollständigem Schließen und erneutem Öffnen der App kontrollieren. Ohne freigegebenen Fahrer/zugeordnetes Fahrzeug keine Vermittlung erwarten.
6. Neue Kunden-/Fahrer-APK 0.6.0 / Build 14 installieren. Mit zwei realen Geräten vollständigen Ablauf durchführen: Suche, Angebot per Wischen, Annahme, Anfahrt, Abholung, Fahrt, Abschluss und tatsächlich kassierter Betrag. Keine Annahme allein durch Tippen hinzufügen.
7. Fahrerortung während gesperrtem Bildschirm und externer Navigation prüfen, anschließend Rückkehr und Neustart. GPS-Latenz und Pfeilbewegung auf echten Aufnahmen beurteilen.

## Vor offiziellem Start

Die Bereitschaftsprüfung liest seit dem 7. Oktober zusätzlich die für Adressen, Angebote und Buchungen benötigten Tabellen und die Herkunftsspalte. Fehlt die additive Adressmigration, liefert `/api/health` HTTP 503 und `bookingConfigured:false`; funktionierende Konten bleiben unabhängig davon als bereit erkennbar. Die Prüfung liest keine Geschäftsdatensätze und ersetzt keinen vollständigen realen Fahrttest. Migrationen weiterhin vor dem jeweiligen Code-Deployment ausführen.

Vercel Hobby ist für persönliche nicht kommerzielle Projekte vorgesehen: https://vercel.com/docs/plans/hobby. Geeigneten kommerziellen Tarif bestätigen; keine kostenpflichtige Umstellung vorgenommen. Backups und Wiederherstellung, Scheduler für Reservierungen, Betriebskontrolle, Rechtsangaben und ggf. Kartenzahlungen abschließen. Interne APKs sind keine Store-Veröffentlichung. Native Fahrerkarte/-Fahrtsteuerung sind in 0.6.0 implementiert; vollständige native Kundenbuchung, erweiterte Disposition, physische Geräteprüfung und iOS bleiben offen.
