# Android-Startabsturz · interne Version 0.6.1

8. Oktober 2026. Nutzer meldet: Fahrer-App 0.6.0 schließt sich sofort nach dem Antippen. Ein echtes Telefon ist nicht angeschlossen; diese Prüfung verwendet einen isolierten AOSP-ARM64-Emulator mit Android 36.

## Befund und Korrektur

Der bisherige NativeDriverMap-Effekt rief `Mapbox.setTelemetryEnabled(false)` vor `setAccessToken` auf. Der installierte SDK-Wrapper `RNMBXModule.kt` erzeugt für Telemetrie im nativen UI-Thread eine `MapView`. Der echte SDK-Konstruktortest bestätigt ohne Token eine `MapboxConfigurationException`, während die Konstruktion nach Tokeninitialisierung funktioniert. Eine React-Fehlergrenze kann diesen nativen Absturz nicht abfangen.

0.6.1 wartet auf die native Tokeninitialisierung und setzt erst dann Telemetrie. Wiederholte Kartenmontagen verwenden dieselbe erfolgreiche Initialisierung; laufende Initialisierungen werden serialisiert. Abgebrochene Ansichten lösen keine Telemetrie-Konstruktion aus, fehlgeschlagene Initialisierung vergiftet spätere Versuche nicht. Das Mapbox-Modul wird außerdem erst nach der App-Registrierung innerhalb einer montierten Fehlergrenze und mit aktivem Bildschirm/Token geladen. Fehlgeschlagener JavaScript-Modulimport lässt den Fahrerbereich offen und bietet eine echte Wiederholung. Fehlgeschlagene Tokeninitialisierung zeigt ebenfalls eine sichtbare Wiederholung statt endloser Vorbereitung. Ein abgebrochener Tokenwechsel darf den vorherigen Bereit-Zustand nicht wiederverwenden; dies ist gesondert geprüft.

## Tatsächlich geprüft

- 245 Projekttests einschließlich Initialisierungsreihenfolge, Abbruch, Wiederholung, Serialisierung, verzögertem SDK-Import und auffangbarem Modulfehler.
- Mobile und Web TypeScript, gezielter Lint; Webpack-Produktionsbuild. Lokales Turbopack wurde durch Portbeschränkung der Umgebung verhindert; unterstützter Webpack-Build erfolgreich.
- Beide ARM64-APKs erfolgreich gebaut; Manifest, eigenständiger Bundle, eingeschränkte Berechtigungen, Version/Build und Signatur geprüft.
- Vorherige 0.6.0 startet im frischen **nicht angemeldeten** Emulator ebenfalls. Der gesamte individuelle Absturz mit gespeichertem Betreiberprofil ist damit nicht vollständig reproduziert. Native SDK-Konstruktion ohne Token ist separat tatsächlich reproduziert.
- Fahrer-APK 0.6.1 als Update installiert, drei kalte Starts, jeweils lebender App-Prozess und aktive MainActivity; React startet, kein AndroidRuntime-FATAL-/ReactNativeJS-Fehler im geprüften Protokoll. Kunden-APK 0.6.1 ebenfalls mit lebendem Prozess gestartet.
- SDK-Probe verwendet einen synthetischen Schlüssel; kein echtes Providerkonto, keine bezahlte Abfrage, kein Standort-/Fahrten-/Kontoschreibzugriff. Kein vollständiger angemeldeter Kartendarstellungs-, Schicht- oder physischer Hintergrund-GPS-Nachweis.

Reproduzierbare SDK-Prüfung nach Installation der internen Fahrer-APK in einem isolierten Emulator: `bash mobile/scripts/test-android-map-startup.sh emulator-5554`. Der Test lehnt physische Geräteseriennummern ab. Starten und Auswahl eines SDK-Images setzt die bereits akzeptierte Android-SDK-Lizenz voraus; keine zusätzlichen Google-API-Vertragsbedingungen akzeptiert.

## APKs und Update

Interne Tests, keine Store-Version. Gleiche Paket-IDs und Testsignatur wie bisher: Update **ohne Deinstallation** möglich; vorhandene eigene Anmeldung bleibt erhalten.

| APK | Bytes | SHA-256 |
| --- | ---: | --- |
| Luxore-Driver-Test-0.6.1.apk | 55.495.996 | `fc1a28ffd28d245c3288a84ceb662a9e0bb2793365507736633bd3718c06967f` |
| Luxore-Ride-Test-0.6.1.apk | 55.523.984 | `f4b67d4aa9b40739e103301347059afc4b31f450a4b9677db14eda6f6843372b` |

Version 0.6.1, Android Build 15, Pakete `de.luxoreride.driver.preview` und `de.luxoreride.customer.preview`. Zertifikat SHA-256: `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c`.

Nächster Schritt: diese Fahrer-APK auf dem betroffenen Telefon installieren und Start mit dem vorhandenen Betreiberprofil, Karte und Schicht prüfen. Bei erneutem unmittelbarem Beenden ist das echte Geräte-Absturzprotokoll notwendig; nicht durch Abmelden, Löschen der Appdaten oder einen eingebetteten Fahrerbereich kaschieren.

Lokaler Build-Hinweis: Eine automatisch erzeugte Cloud-Konfliktdatei `ActivityEventListener 2.dex` blockierte die Gradle-Cacheprüfung. Ausschließlich der erzeugte Expo-Core-Transform-Cache wurde gesichert und neu generiert; anschließend APK-Build erfolgreich. Keine Geschäftsdaten oder Projektquelldateien gelöscht.
