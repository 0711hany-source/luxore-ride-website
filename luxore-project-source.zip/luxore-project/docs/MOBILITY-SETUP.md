# LUXORÉ RIDE – Routen und Vermittlung, Version 0.3

## Implementierter Stand
- Drei Schritte: freie Adresssuche oder Standortauflösung → Route und Fahrzeugpreis → Fahrtstatus.
- Bestätigte Tarife: Business 250 Cent/km, First Class 350 Cent/km, Van 300 Cent/km; mindestens 1500 Cent. Berechnung über serverseitige Straßenroutenmeter, auf einen Cent gerundet. Keine Transferpauschale, keine vom Client übernommene Preis-/Distanzangabe.
- Mapbox Geocoding v6 mit permanent=true (da Buchungsadressen gespeichert werden); Directions driving-traffic. Keine öffentliche Demo-Routing-API und keine Ersatzroute bei Ausfall. Ohne Konto/Schlüssel sind Suche und neue Buchungen ausdrücklich gesperrt. Direkte Mapbox-Anfragen für Kartenstil, permanente Adresssuche und Straßenroute wurden am 23.09.2026 erfolgreich geprüft; ein vollständiger angemeldeter Browser-/Mehrgerätetest steht noch aus.
- Gespeicherte, fünf Minuten gültige Angebote. Idempotente Buchung je Angebot, eindeutige aktive Kundenfahrt.
- Getrennte Fahrerprofile, serverseitige Freigabe, Online-Sitzungen, Standortmeldungen und Statusberechtigungen. Der Kunde kann keine Fahreraktionen auslösen. Historische /api/rides-Schreibzugriffe sind stillgelegt; alte Daten bleiben erhalten.
- Fahrerwahl nach geografischer Entfernung (Haversine, **nicht** Anfahrts-ETA), passender Klasse und frischem GPS. Aktuell maximal 50 km Radius; maximal 200 geeignete Kandidaten werden betrachtet. Freigabe, Online-Status, GPS-Alter unter 45 Sekunden und Genauigkeit bis 100 Meter erforderlich. Eigene Fahrten werden nicht angeboten.
- Je Fahrer und Fahrt maximal ein offenes Angebot; 25 Sekunden Antwortzeit. Ablehnung, Zeitablauf oder Offline-Status führen zum nächsten Fahrer. Nach drei Minuten ohne Annahme wird die Suche beendet. Atomare Annahme und eindeutige Datenbankindizes verhindern doppelte Vergabe.
- Reservierungen: 30 Minuten bis 90 Tage im Voraus; Fahrersuche ab 15 Minuten vor Abholung. Eine Reservierung ohne zugewiesenen Fahrer ist nicht als bestätigt dargestellt.
- Zustandspolling alle drei Sekunden, GPS-Heartbeat alle zehn Sekunden in geöffneter Fahreransicht. Keine WebSocket-/Push-Infrastruktur und keine native Hintergrundortung. Offline-Sitzungen verhindern verspätete Reaktivierung durch alte GPS-Anfragen.
- Zugewiesene Kunden sehen Fahrername, Telefonnummer, Fahrzeug, Kennzeichen und frische Fahrerposition. Optionaler Kundenstandort nur innerhalb einer zugewiesenen aktiven Fahrt. Standortfreigabe kann beendet werden.
- Sicherheit: bewusst ausgelöster Telefonlink 112, Firmenkontakt, Kopieren/Teilen von Fahrtdaten; kein automatischer Notruf, keine Sicherheitszentrale, kein öffentlicher Trackinglink.

## Kartenverbindung – Stand 23.09.2026
Der vom Eigentümer bereitgestellte öffentliche Mapbox-Token ist als MAPBOX_PUBLIC_TOKEN und serverseitig als MAPBOX_ACCESS_TOKEN in der privaten Sites-Laufzeit hinterlegt. Die Umgebungsrevision 2 ist veröffentlicht. Keine Tokens im Repository gespeichert.

Direkte Providerprüfungen: Kartenstil HTTP 200, Geocoding v6 mit permanent=true HTTP 200 und Directions driving-traffic mit Code Ok. Beispielroute Opernplatz 1 → Hugo-Eckener-Ring 1: 21.067 Straßenmeter und 1.375 Sekunden zum Testzeitpunkt; keine verbindliche Fahrtdauer. Keine Fahrt gebucht. Private API bleibt hinter Anmeldung; der reine Site-Zugangstoken erzeugt keine Benutzeridentität. Vollständige angemeldete Web-App- und Gerätetests fehlen weiterhin. Die vorhandenen Android-APKs wurden dadurch nicht verändert.

## Konfiguration und weitere Voraussetzungen
1. Mapbox-Konto ist verbunden. Für das dauerhafte Speichern geocodierter Adressen muss Permanent Geocoding im Konto nutzbar sein (laut Mapbox hinterlegte Kreditkarte oder Enterprise-Vertrag erforderlich).
2. MAPBOX_ACCESS_TOKEN serverseitig als Sites-Secret setzen. Nicht im Quellcode, Browser oder Chat veröffentlichen.
3. Separaten MAPBOX_PUBLIC_TOKEN mit pk.-Präfix und URL-Einschränkung für die Site sowie passende lokale Entwicklungsadresse bereitstellen. Dieser Token ist für die Kartenanzeige öffentlich; keine geheimen Scopes zulassen.
4. LUXORE_ADMIN_EMAIL ist für den privaten Site-Eigentümer serverseitig hinterlegt. Es gilt ausschließlich die vom Sites-Dispatcher bestätigte Identität. Direkte Deployments ohne diesen Dispatcher benötigen einen eigenen verifizierenden Identity-Layer. Partnerunternehmen/Mandanten sind noch nicht implementiert.
5. Die Site bleibt ausschließlich für den Eigentümer freigegeben. Für Tests auf zwei Geräten braucht es separate freigegebene Nutzerkonten. Neue Fahrer können sich nach zugelassenem Site-Zugriff registrieren und müssen von der Disposition freigegeben werden. Öffentliche Kundenregistrierung/Apple-/Google-Login sind nicht implementiert.
6. Hintergrundausführung: POST /api/mobility/tick kann durch einen externen Scheduler mit Authorization: Bearer DISPATCH_SECRET ausgelöst werden. **Kein Scheduler ist eingerichtet.** Aktuell treiben angemeldete aktive Webansichten die Vermittlung an. Ohne geöffnete App laufen Reservierungsaktivierung und Angebotswechsel nicht verlässlich im Hintergrund. Ein privater Site-Dispatcher kann externe HTTP-Aufrufe zusätzlich blockieren; vor Scheduler-Einrichtung den gewählten Hosting-/Worker-Pfad festlegen und testen.

## Lokale Entwicklung und Tests
- pnpm dev. Der lokale Sites-Login läuft über /signin-with-chatgpt.
- .dev.vars ist ignoriert und enthält nur leere Kartenwerte und die lokale Test-Adminidentität seedy@sites.test. .env.example zeigt die Schlüssel ohne echte Secrets.
- Migrationen 0001–0003 erweitern die frühere Datenbank additiv. 0000 bleibt unverändert.
- node --experimental-strip-types --test tests/mobility.test.ts: Tarife, zeitliche Trennung, Ablehnung, Ablauf, Fremdannahme, Abbruch und Eindeutigkeitsregeln mit echter SQLite-Ausführung der Dispatcher-Abfragen.
- python3 tests/mobility-api-local.py: lokale API-Prüfungen mit synthetischen gespeicherten Routenangeboten. Diese prüfen die API, nicht den externen Kartendienst; Testdaten werden nur lokal angelegt und nach erfolgreichem Test entfernt.

## Grenzen vor einem Livebetrieb
Angemeldete Web-App-/GPS-/Mehrgerätetests, öffentliche Identität, Zahlungen, Hintergrunddispatcher, mobile Push-Mitteilungen, native iOS-/Android-Fahrer-App und Betriebskonzept fehlen. Standortfälschung auf kompromittierten Geräten wird nicht verhindert. Fahrerzulassung und Nachweise werden nicht automatisiert verifiziert. Reservierungsgarantien, Ausfallbehandlung während aktiver Fahrt und Benachrichtigungen müssen für den echten Betrieb weiter ausgearbeitet werden. Die private Version ist keine Produktionsfreigabe.

## Primärquellen
- https://docs.mapbox.com/api/search/geocoding/ (permanente Speicherung, Forward/Reverse)
- https://docs.mapbox.com/api/navigation/directions/ (Straßenroute, Distanz, Verkehr)
- https://docs.mapbox.com/mapbox-gl-js/guides/get-started/ (Kartendarstellung)
- https://www.bbk.bund.de/DE/Warnung-Vorsorge/Vorsorge/Gesundheit-und-Hygiene/Erste-Hilfe-und-Notruf/erste-hilfe-und-notruf_node.html (112)
