# Gemeinsames App-Design – 05.10.2026

Auftrag: Kunden- und Fahrer-App durchgehend prüfen, optisch zusammenführen und vorhandene Buchungs-, Fahrzeug- und GPS-Funktionen erhalten.

## Ergebnis

- Gemeinsame weiße Flächen, Anthrazit und dezente Goldakzente; dieselbe Markenleiste bleibt auch auf Unterseiten sichtbar. Ride und Driver bleiben eindeutig unterscheidbar.
- Helles Menü mit passenden Symbolen, klare Schließen-/Zurück-Steuerung und kurze Hilfeseite anstelle der Unternehmenswerbung innerhalb der Apps. Die Disposition erscheint im Menü mit entsprechender Berechtigung.
- Einheitliche lesbare Felder, Schalter, Fahrzeugauswahl, Umsätze und leere Listen. Fahrer-Umsatz und Bestandsseite haben eine erkennbare Rückkehr zum Cockpit.
- Der Fahrerbereich nutzt die volle verfügbare Kartenhöhe; kein freier Streifen für die versteckte untere Navigation.
- Buchungsdialog und weitere App-Dialoge teilen den sichtbaren Viewport. Nach Seitenwechsel wird der alte Seiten-Scroll nicht übernommen. Bei geöffneter Tastatur wird die vom Browser gemeldete sichtbare Höhe verwendet; die native Android-Tastatur ist noch am Gerät zu prüfen.
- Der Navigationsschalter wurde von der Text-Flexregel gestreckt. Jetzt feste 48 × 28 px und korrekte Position des Schalters auch im eingeschalteten Zustand.
- Die Abholmarkierung war wegen `.pickup-map > div` aus dem sichtbaren Kartenausschnitt verschoben. Die Markierung und ihr Mittelpunkt liegen nun genau im Kartenmittelpunkt. Während des Kartenstarts erscheint ein Ladehinweis; der vorhandene Neuverbinden-Ablauf bleibt bestehen.
- Die Bordkarte innerhalb der Buchung besitzt keine zweite schwebende Summe mehr. Die feste Gesamtsumme gehört zum Buchungsabschluss.
- Der Kassierbetrag entspricht dem gespeicherten Betrag. Die bisherige Trinkgeldauswahl hatte nur die Anzeige verändert, nicht die serverseitige Erfassung. Entfernt, bis Trinkgeld tatsächlich durchgängig gespeichert und abgerechnet werden kann. Barzahlung und separates Kartenterminal bleiben erhalten.
- Annahme per Wischgeste hat weiterhin keine zusätzliche Tipp-Annahme. Dialogwischen startet am Griff, nicht beim Scrollen oder Bewegen der Karte.

## Prüfungen

Lokaler In-App-Browser mit bestehenden Komponenten und isolierter Testflotte; keine Buchung oder Änderung in der öffentlichen Betriebsdatenbank.

| Bereich | Nachweis |
| --- | --- |
| Kundenstart, Menü, Fahrtenliste, Hilfe | Optisch geprüft; Markenleiste bleibt sichtbar, lesbare leere Liste und Kontaktinformationen |
| Adresssuche und Preise | Reale Mapbox-Abfrage von Opernplatz zum Hauptbahnhof; 2,3 km, ca. 8 Minuten, bestätigte Mindestpreise |
| Klassenwahl und Buchungsdialog | Bei 390 × 844 und 320 × 640 px vollständig innerhalb des sichtbaren Rahmens, kein seitlicher Überlauf; keine reale Buchung abgesendet |
| Bordkarte | Produkte mit freigestellten Bildern, Mengen, Freimengen und Aufpreisen; keine Überlagerung der Buchungssumme |
| Abholort auf Karte | Geladene Karte und sichtbare Markierung; gemessene Abweichung ihres Mittelpunkts vom Kartenmittelpunkt: 0 px horizontal/vertikal; Herunterwischen schließt den Dialog |
| Fahrerkarte und Einstellungen | Helle Karte, Fahrtfläche durch Herunterwischen eingeklappt; Einstellungen durch Herunterwischen geschlossen |
| Kleine Einstellungen | Bei 320 × 640 px Dialog 320 × 624 px, Start bei y=16 px; Inhalte intern scrollbar, Seitenbreite 320 px |
| Fahrer-Unterseiten | Umsatz, Fahrzeugauswahl und Bestandsanzeige optisch geprüft; Umstieg auf ein anderes verfügbares Fahrzeug erfolgreich |
| Flotte in der App | Fahrzeugformular bedient und gespeichert; lokales Testfahrzeug erscheint als zweites Fahrzeug der Testflotte |
| Tablet | Kundenstart bei 768 × 1024 px geprüft; Dokumentbreite und Scrollbreite jeweils 768 px |
| Gesten und Komponenten | 17 Tests für Richtungsentscheidung, unbeabsichtigtes Wischen, Dialog-/Zurück-Ebenen, Fahrerfläche, Formularfehler und Kassierbetrag bestanden |
| Produktionsprüfung | TypeScript und abschließender Produktionsbuild bestanden; keine neuen Datenbankmigrationen oder nativen Abhängigkeiten |
| Gemeinsame API | Vollständiger lokaler Ablauf mit fünf getrennten Geräteidentitäten: Freigabe, Mehrklassenfahrzeuge, nächste Fahrer, Ablehnung/Weitergabe, Annahme, Fahrt, Abschluss, einmalige Zahlung, Fahrer-/Flottenumsatz, Reservierung und alte Standortsession |

Die tatsächlichen Browseransichten liegen in [design-review](design-review/). Synthetische Kennzeichen und der GPS-Berechtigungshinweis in den Bildern kennzeichnen den lokalen Test. Es wurden keine realen Fahrerpositionen oder Betriebsumsätze für Bilder verwendet.

Die lokale Design-Testflotte, beide Testfahrzeuge und ihre abhängigen Daten wurden nach der Prüfung wieder entfernt. Der temporäre Browser-Tab wurde geschlossen und die Bildschirmgrößenänderung zurückgesetzt. Der lokale Entwicklungsserver ließ sich in dieser Sitzung wegen einer Prozessberechtigung nicht beenden; die öffentliche Site ist davon unabhängig.

## Noch offen

Die Browserprüfung ersetzt keinen Gerätetest: Android-Tastatur, System-Zurück-Taste, native Gesten, Standortberechtigungen, GPS in Bewegung und Hintergrundbetrieb mit gesperrtem Bildschirm sind anschließend zu prüfen. Der Nutzer hat die Fahrzeuganlage am Handy noch nicht erneut getestet. Sicherheitsschaltflächen wurden im Quellcode geprüft; kein Notruf, Supportanruf oder Teilen echter Fahrtdaten ausgelöst. Keine native iOS-Prüfung, neue APK oder Store-Einreichung.

Die Veröffentlichung am 05.10. war blockiert: Die automatische Freigabeprüfung verweigerte die sichere Übergabe an den Sites-Veröffentlichungsablauf. Der anschließende Zugriff ohne neue Zugangsdaten hatte keine vorhandene Git-Anmeldung. Der Designstand blieb lokal; der öffentliche Ausgangsstand 39 blieb erhalten.

## Feste Fenster und erreichbare Fahrzeuganlage – 06.10.2026

Nutzerbericht: „Fahrzeug hinzufügen“ steht oben rechts außerhalb des bedienbaren Bereichs; Fenster sollen fest im Bildschirm bleiben.

- Die widersprüchlichen Positionierungen der Dialoge durch einen gemeinsamen festen Rahmen ersetzt. Unabhängige CSS-Verschiebungen werden zurückgesetzt. Fahrzeugformular, Details, Einstellungen und Zahlungsbestätigung folgen demselben sichtbaren Viewport: am Handy unten, auf breiteren Bildschirmen mittig.
- Sichtbare Breite und horizontale Verschiebung werden zusätzlich zu Höhe und oberem Versatz erfasst. Das gilt auch für die Disposition außerhalb der mobilen App-Routen.
- Beim Fahrzeugformular bleiben Titel, Schließen, Speichern und Abbrechen außerhalb des scrollenden Feldbereichs. Nach einer Größenänderung wird ein fokussiertes Eingabefeld nur innerhalb seines eigenen Scrollbereichs sichtbar gemacht.
- Bei der lokalen Vorbereitung außerdem einen wirklichen Fehler im Teamformular gefunden: „Profil einreichen“ hatte keinen Submit-Typ und löste keine Übermittlung aus. Expliziter Submit-Typ ergänzt und Profilanlage im Browser erfolgreich geprüft.

### Nachweise

| Prüfung | Ergebnis |
| --- | --- |
| Fahrzeugfenster: 320 × 640, 390 × 844, 601 × 640, 768 × 640 px | Fenster und Speichern vollständig innerhalb des sichtbaren Bereichs, kein horizontaler Überlauf |
| Kurzer Bildschirm: 390 × 450 px | Fenster bei y=24 px, Höhe 426 px; Speichern erreichbar; fokussiertes Kennzeichen durch internes Scrollen sichtbar |
| Querformat: 844 × 390 px | Fenster 480 × 366 px bei x=182/y=12 px; Speichern vollständig sichtbar |
| Einstellungen und Zahlungsbestätigung: 601 × 640 px | Beide Fenster vollständig sichtbar; Beispielzahlung ausschließlich geöffnet und abgebrochen |
| Tatsächliches Speichern | Synthetisches Fahrzeug „F TEST 303“ per Oberfläche gespeichert und in der lokalen Testflotte angezeigt |
| Abschlussprüfung | TypeScript, 17 Komponenten-/Gestentests, `git diff --check` und Produktionsbuild bestanden |

Die tatsächliche Ansicht steht unter [design-review/vehicle-fixed-window.jpg](design-review/vehicle-fixed-window.jpg). Testprofil, Testflotte, Testfahrzeug und abhängige lokale Daten wurden entfernt; keine Buchung angelegt. Temporärer Browser-Tab geschlossen, Bildschirmgrößenänderung zurückgesetzt. Keine Veränderung an Navigation, Preisen, Buchungs-API oder nativer APK.

Die kurze Bildschirmhöhe simuliert weniger verfügbaren Platz, ersetzt jedoch keinen Test der Android-Tastatur. Der ursprüngliche Gerätespeicherfehler bleibt bis zum tatsächlichen Handytest unbestätigt.

Veröffentlichung am 06.10. erneut blockiert: Nach erneuter Erlaubnis für Netzwerk und Git-Metadaten und mit einem neu gestarteten Sites-Ablauf lehnte die automatische Freigabeprüfung weiterhin `write_stdin` ab (`sandbox_approval` ist deaktiviert). Dadurch konnte das kurzlebige Quellrepository-Credential nicht über den vorgeschriebenen sicheren Eingabekanal übergeben werden. Kein Push, keine neue gespeicherte Version und kein Deployment erfolgt; die öffentliche Site bleibt auf Stand 39. Zugangsdaten wurden nicht in Dateien oder Befehlsargumenten gespeichert. Der geprüfte neue Quellstand bleibt lokal erhalten. Nächster Schritt: sichere Veröffentlichung nach Behebung dieser Freigabeblockade, danach Fahrzeuganlage, Tastatur, Zurück-Taste und Wischgesten auf dem Fahrerhandy prüfen.
