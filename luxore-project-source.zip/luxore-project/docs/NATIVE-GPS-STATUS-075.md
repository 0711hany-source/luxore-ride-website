# Native GPS-Statusreihenfolge · Fahrer 0.7.5 / Build 29

## Reproduzierter Fehler

Der tatsächliche useDriverGps-Hook konnte verspätete resumeLocation-Antworten ungeachtet einer neueren Statusabfrage anzeigen. Ein alter aktiver Status stellte nach bestätigter Pause die alte sessionId wieder her; eine alte inaktive Antwort löschte umgekehrt eine inzwischen neu bestätigte Schichtanzeige. Nach Hintergrundwechsel und Rückkehr konnte eine vorherige Antwort außerdem den zurückgekehrten Status oder die zugehörige Cacheposition überschreiben. Die tatsächlichen nativen Standortberechtigungen wurden damit nicht geändert, aber die Anzeige und shiftState konnten einen falschen Offline-/Schichtzustand erhalten.

## Korrektur

GPS-Statusabfragen besitzen jetzt unabhängig vom kontinuierlichen Standortwatcher einen eigenen LocationRequest. Nur die aktuellste Abfrage darf sessionId oder Cacheposition auf den Hook anwenden, und nur solange die Ansicht lebt und die App im Vordergrund ist. Neustart, Hintergrundwechsel und Unmount invalidieren ausstehende Statusanzeigen. Ein alter Abschluss oder Fehler beendet keine neue Abfrage. Die Statusantwort wird weiterhin an den ausdrücklichen Aufrufer zurückgegeben; native Servicewiederherstellung oder bestätigende Schicht-Schreibvorgänge werden nicht als Leseanfragen abgebrochen.

Der bestehende native Dienst erhält seine eigene serialisierte Lifecycle-/Credential-Prüfung. Hintergrundortung läuft weiter, während der Vordergrundwatcher im Hintergrund entfernt wird; bei Rückkehr wird er erneut geöffnet. Bestehende GPS-Qualitäts-/Cache-/Netzverlust-/Uploadregeln bleiben erhalten. Keine Rohkoordinaten verschoben, keine neue Geokodierung, keine automatische Schichtfreigabe, kein zweiter Standortdienst und keine neuen Berechtigungen. Die imperative Ownership des Hooks ist wie bestehende native Kamera-/Gestenfunktionen ausdrücklich von Compiler-Memoisierung ausgenommen.

## Nachweis und Grenzen

Sechs neue Tests mounten den tatsächlichen Hook mit React-Test-Renderer und isolierten nativen Standort-/AppState-/Serviceadaptern. Fünf reproduzieren den Fehler mit dem unveränderten vorherigen Hook und bestehen mit der Korrektur. Geprüft: alte aktive/inaktive Antwort nach neuerer Pause/Schicht, Hintergrund/Rückkehr und Watcherfreigabe, Antwort im Hintergrund, alte Fehler/Abschlüsse gegenüber einer neueren Abfrage sowie ausdrücklicher GPS-Neustart. Native Location-Service-Tests bleiben erfolgreich. Insgesamt 518 Projekttests, beide TypeScript-Prüfungen und gezieltes Lint bestanden.

Korrektur ist in Fahrer 0.7.5 / Build 29 integriert und benötigt ein APK-Update; Kunde 0.6.9 / Build 23 unverändert. Kein neuer Datenbankschritt und keine Production-Fahrt/Schicht-/Team-/Leitungs-/Freigabeänderung. Kein realer Straßen-, Akku-/Hersteller-, angemeldeter Mehrgeräte- oder Hintergrund-GPS-Nachweis. Nächster Schritt: konkreten angemeldeten Gerätefehler prüfen und Navigation-/Routenwiederherstellung im Vordergrund weiter absichern; physische Unternehmensgeräteprüfung bleibt erforderlich.

## Android-Nachweis

Fahrer 0.7.5 / Build 29 außerhalb synchronisierter Quellen/Abhängigkeiten mit bestehenden Paketversionen gebaut. 71 Runtime-/Asset-/Konfigurationsdateien bytegenau mit dem Buildbaum verglichen. SDK-Prüfung bestätigt Paket de.luxoreride.driver.preview, eigenständigen Bundle, ARM64, interne Variante, deaktiviertes Backup und bestehende Rechte. Signatur unverändert: `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c`. APK 56.203.564 Bytes, SHA-256 `1ebfb0f129ed6b9fa59350be81a94281cb7eb40415549680bd2008e8b7e3a9ca`.

Update über 0.7.4 ohne Deinstallation im isolierten Emulator, drei kalte Starts mit lebendem Prozess und nativer anonymer Startoberfläche, ohne Fatal-/ReactNativeJS-Absturz. Kein angemeldeter Hintergrund-/Straßen-/Schichtbeweis. Kunde 0.6.9 / Build 23 unverändert; keine Installation auf Nutzerhandys behaupten.
