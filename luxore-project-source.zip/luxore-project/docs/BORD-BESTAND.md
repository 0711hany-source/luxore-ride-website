# Bordbestand und Einkauf

Stand: 29.09.2026

In der Fahrer-App unter **Bestand**, in der Flottenansicht unter **Bordbestand & Einkauf der Flotte**. Während einer Fahrt ist die Bestandsverwaltung auch in der Bordbestellung aufklappbar. Bedienung im Stand.

## Einrichten

Einmal den tatsächlichen Anfangsbestand zählen und speichern. Ohne Erstzählung wird kein vorhandener Vorrat angenommen. Eine Übergabe an Fahrgäste benötigt einen erfassten Fahrzeugbestand.

Vorgeschlagene Sollmengen: 3 stilles Wasser, 3 Sprudel, 4 Cola, 4 Cola Zero, 2 Apfelschorle, 2 Energy. Die beiden 0,5-l-Wasserflaschen belegen standardmäßig je zwei Kühlplätze; die anderen Getränke je einen. Das ergibt 24 Kühlplätze. Dies ist eine Planungshilfe, keine Zusage zur Passform eines bestimmten Kühlschranks. Platzbedarf und Sollmengen lassen sich ändern. Für Snacks sind acht Plätze und zunächst je zwei Packungen pro Sorte vorgesehen.

## Nachfüllen

Die Meldeschwelle ist für Getränke zunächst 1, für Snacks 0. Sobald ein aktiver Artikel diese Schwelle erreicht, erscheint im geöffneten Fahrer-Cockpit **Bitte jetzt einkaufen**. Der Fahrerstatus aktualisiert den Hinweis mit dem bestehenden App-Polling. Dies sind In-App-Hinweise, keine Hintergrund-Pushnachrichten oder terminierten Erinnerungen.

Die Liste enthält alle Fehlmengen bis zum Sollbestand, auch wenn nur eine Sorte dringend ist. Die Liste kann kopiert oder als Textdatei heruntergeladen werden. Abhaken setzt die vorgeschlagene Kaufmenge; tatsächliche Teilmengen lassen sich ändern. Erst **Gekauft & eingeräumt bestätigen** erhöht den Bestand. Ein neuer Einkaufsstand wird von der gespeicherten Bestandsrevision abgeleitet; bei zwischenzeitlichen Änderungen muss aktualisiert werden.

## Verbrauch und Korrekturen

Eine bestätigte Übergabe zieht nur die übergebene Menge ab. Kundenanfragen und nicht verfügbare Artikel verändern den Bestand nicht. Bestand und Fahrpreis werden in derselben D1-Transaktion geändert; eine doppelte Bestätigung wird durch Bestellrevision und Bestandsrevision abgewehrt.

**Für mich entnommen** dokumentiert den Eigenverbrauch mit Fahrername, Zeit und optionaler Notiz. Dieser Verbrauch beeinflusst den Fahrpreis nicht. **Bearbeiten** erlaubt Istbestand, Sollmengen, Meldeschwellen und Platzbedarf; jede Korrektur benötigt einen Grund. Bewegungen werden dauerhaft protokolliert, die Oberfläche zeigt die letzten 25 an.

Fahrer greifen auf ihr freigegebenes aktuelles Fahrzeug zu. Flottenbesitzer und Stellvertreter verwalten Fahrzeuge ihrer Flotte. Fremde Fahrzeuge sind serverseitig gesperrt. Bei Fahrzeugwechsel bleibt der Bestand beim Fahrzeug.

## Validierung

Domänentests prüfen Kapazität, Meldeschwellen, Fehlmengen und ungültige Entnahmen. Lokale HTTP-Tests prüfen Zugriffsschutz, parallelen Eigenverbrauch, veraltete Nachfüllungen, doppelte Übergaben, Bestand und Endpreis inklusive Bordzuschlägen. Testdaten werden ausschließlich lokal angelegt und anschließend gelöscht.
