# Europaweite Kartenpunkte und Streckenangebote

8. Oktober 2026. Kartenansichten ohne vorhandene Position beginnen in einer Europaübersicht. Bereits ausgewählte Orte, Fahrerrichtung, aktive Routen und GPS-Nachführung behalten ihren bisherigen Vorrang. Die Auswahlkarte bietet „Europa“ und „Punkt vergrößern“. Bestätigung erst ab Straßenmaßstab (Zoom 13), nach beendeter Kartenbewegung. Die bestehende Drei-Sekunden-Rückkehr hält den gewählten Kartenmittelpunkt und passt die Rückkehrskala an Übersicht beziehungsweise Straßenansicht an.

Mapbox- und Geoapify-Vorwärtssuche haben keine feste Frankfurt-Bevorzugung und keine Länderbeschränkung. Straße, Hausnummer, Ort und Land eingeben. Der neue `forward-global:`-Cachebereich verhindert die Wiederverwendung früherer Frankfurt-bevorzugter Ergebnisse; vorhandene Cachezeilen und gespeicherte Benutzeradressen werden nicht gelöscht. Herkunftsangaben, Anbieterquoten und Sperre kostenpflichtiger permanenter Mapbox-Abfragen bleiben erhalten.

Die gemeinsame serverseitige Strecken-/Preisvalidierung erlaubt jetzt bis 10.000 km statt 2.000 km. Kilometerpreise und Mindestpreis bleiben unverändert; Berechnung erfolgt aus der tatsächlich zurückgegebenen Straßenroute. Keine Luftlinien-Ersatzpreise, keine automatische Buchung unbefahrbarer Insel-/Kontinentalverbindungen. Mapbox Driving Traffic bleibt mit Zeitbezug und Ausschluss unbefestigter Straßen aktiv; Verkehrsdaten sind nur im vom Anbieter abgedeckten Gebiet vorhanden. Quellen: https://docs.mapbox.com/api/navigation/directions/ und https://docs.mapbox.com/api/search/geocoding/.

Die Europaübersicht ist keine Zusage einer überall vorhandenen Flotte. Sofortvermittlung verlangt wie bisher freigegebene Fahrzeuge, aktuelle GPS-Daten und einen Fahrer innerhalb von 50 km des Abholpunkts. Reservierungen sind zunächst vorgemerkt und erst mit Fahrerannahme zugesagt. Flottenrechte und Authentifizierung unverändert.

## Tatsächliche Grenzen

Neue Textadressbestätigung bleibt live bis zur konkret freizugebenden Einrichtung des kostenlosen Geokodierungsanbieters gesperrt. Europaweite direkte Kartenpunkte funktionieren ohne Geokodierung. Keine neuen Anbieterbedingungen, Kostenbudgets oder Tarife akzeptiert. Routen- und Länderabdeckung hängen vom Kartendienst ab. Kein europaweites Fahrerangebot, keine rechtliche Betriebsgenehmigung und keine physische GPS-Prüfung behauptet.

## Prüfung

Isolierte SQLite-Integration mit allen Migrationen und echten Orts-/Angebots-/Buchungs-Endpunkten: Portugal-/Finnland-Kartenpunkte, 3.500-km-Anbieterfixture, alle drei bestätigten Kilometerpreise, Sofort- und Reservierungsbuchung, idempotente Wiederholung, keine bezahlte Geokodierung. Fehlende Straßenroute und Überschreitung der Obergrenze erzeugen weder Angebot noch Buchung. Separater echter Dispatch-Test: ein Frankfurter Fahrer erhält keine Pariser Anfrage; ein zulässiger lokaler Pariser Fahrer erhält und akzeptiert sie. Beide Suchanbieter ohne Orts-/Länderfilter geprüft. Die Streckenfixture ist kein echter Nachweis der befahrbaren Portugal-Finnland-Verbindung.

Webänderung: die bestehende Kunden-APK lädt die aktualisierte Buchungsoberfläche. Unveränderte native Fahrer-APK 0.6.1; keine neue APK erstellt oder auf Nutzergeräten installiert.

## Veröffentlichungsnachweis

265 Tests bestanden, Web-TypeScript und gezieltes Lint bestanden. Endgültiger isolierter Build des tatsächlichen Vercel-Quellarchivs: Kompilierung 7,9 s, TypeScript 5,4 s. Mobile Browserprüfung 390×844 mit echtem Mapbox-Stil: Überblick sperrt Bestätigung, Straßenzoom entsperrt nach Bewegungsende, Europa-Rückkehr sperrt erneut. Bei Wechsel zwischen 390×844 und 1024×768 passt ein ResizeObserver die Kartenfläche an und hält Markierung/Kartenmitte zusammen.

Lokaler Quellstand `6856fb949bac65550aae1bc6aceb9be526f37449` auf GitHub `80a60526ed7ccd9969b78366c8b349e0662eac51` veröffentlicht. 416 Quell-/Dokumentationsdateien, 7.590.959 Bytes, Archiv-SHA-256 `86d22238b97989b4f1659c9e4f7d1ec29c4425694372a019b0a3f88ef13ac529`. Quellarchiv und Versionsdatei bytegenau aus dem öffentlichen Commit zurückgelesen. Keine APKs, privaten Umgebungsdateien, Signierdateien oder persönliche Konfliktkopie veröffentlicht.

Vercel `FJ7EL2mkVHXdfjfaRshWknyZKgp5` bestätigt Ready / Latest / Production und luxoreride.de. Live-Health HTTP 200 mit Datenbank, Konten und Buchungskonfiguration bereit; anonyme Kontoantwort ohne Administratorrecht, Kunden-/Fahrer-/Dispositionsseiten HTTP 200. Die veröffentlichte Suchoberfläche liefert für „Rue de Rivoli, Paris, France“ tatsächliche Pariser Mapbox-Vorschläge. Keine neue Adresse bestätigt und keine reale Fahrt oder Schicht angelegt. Nachweise in `outputs/europe-booking/` und `work/europe-booking/`.

Geoapify-Konto wurde nicht angelegt: automatische Freigabeprüfung hat den Übergang zur Kontoerstellung wegen der ausstehenden konkreten Anbieter-/Vertragszustimmung abgelehnt. Konkrete Freigabe für kostenlose Einrichtung, E-Mail-Übermittlung und Bedingungen erneut als offene Frage angezeigt. Kein Umgehen der Ablehnung und kein kostenpflichtiges Mapbox-Geokodieren.
