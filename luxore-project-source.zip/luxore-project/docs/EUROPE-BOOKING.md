# Europaweite Kartenpunkte und Streckenangebote

8. Oktober 2026. Kartenansichten ohne vorhandene Position beginnen in einer Europaübersicht. Bereits ausgewählte Orte, Fahrerrichtung, aktive Routen und GPS-Nachführung behalten ihren bisherigen Vorrang. Die Auswahlkarte bietet „Europa“ und „Punkt vergrößern“. Bestätigung erst ab Straßenmaßstab (Zoom 13), nach beendeter Kartenbewegung. Die bestehende Drei-Sekunden-Rückkehr hält den gewählten Kartenmittelpunkt und passt die Rückkehrskala an Übersicht beziehungsweise Straßenansicht an.

Mapbox- und Geoapify-Vorwärtssuche haben keine feste Frankfurt-Bevorzugung und keine Länderbeschränkung. Straße, Hausnummer, Ort und Land eingeben. Der neue `forward-global:`-Cachebereich verhindert die Wiederverwendung früherer Frankfurt-bevorzugter Ergebnisse; vorhandene Cachezeilen und gespeicherte Benutzeradressen werden nicht gelöscht. Herkunftsangaben, Anbieterquoten und Sperre kostenpflichtiger permanenter Mapbox-Abfragen bleiben erhalten.

Die gemeinsame serverseitige Strecken-/Preisvalidierung erlaubt jetzt bis 10.000 km statt 2.000 km. Kilometerpreise und Mindestpreis bleiben unverändert; Berechnung erfolgt aus der tatsächlich zurückgegebenen Straßenroute. Keine Luftlinien-Ersatzpreise, keine automatische Buchung unbefahrbarer Insel-/Kontinentalverbindungen. Mapbox Driving Traffic bleibt mit Zeitbezug und Ausschluss unbefestigter Straßen aktiv; Verkehrsdaten sind nur im vom Anbieter abgedeckten Gebiet vorhanden. Quellen: https://docs.mapbox.com/api/navigation/directions/ und https://docs.mapbox.com/api/search/geocoding/.

Die Europaübersicht ist keine Zusage einer überall vorhandenen Flotte. Sofortvermittlung verlangt wie bisher freigegebene Fahrzeuge, aktuelle GPS-Daten und einen Fahrer innerhalb von 50 km des Abholpunkts. Reservierungen sind zunächst vorgemerkt und erst mit Fahrerannahme zugesagt. Flottenrechte und Authentifizierung unverändert.

## Tatsächliche Grenzen

Neue Textadressbestätigung bleibt live bis zur konkret freizugebenden Einrichtung des kostenlosen Geokodierungsanbieters gesperrt. Europaweite direkte Kartenpunkte funktionieren ohne Geokodierung. Keine neuen Anbieterbedingungen, Kostenbudgets oder Tarife akzeptiert. Routen- und Länderabdeckung hängen vom Kartendienst ab. Kein europaweites Fahrerangebot, keine rechtliche Betriebsgenehmigung und keine physische GPS-Prüfung behauptet.

## Prüfung

Isolierte SQLite-Integration mit allen Migrationen und echten Orts-/Angebots-/Buchungs-Endpunkten: Portugal-/Finnland-Kartenpunkte, 3.500-km-Anbieterfixture, alle drei bestätigten Kilometerpreise, Sofort- und Reservierungsbuchung, idempotente Wiederholung, keine bezahlte Geokodierung. Fehlende Straßenroute und Überschreitung der Obergrenze erzeugen weder Angebot noch Buchung. Separater echter Dispatch-Test: ein Frankfurter Fahrer erhält keine Pariser Anfrage; ein zulässiger lokaler Pariser Fahrer erhält und akzeptiert sie. Beide Suchanbieter ohne Orts-/Länderfilter geprüft. Die Streckenfixture ist kein echter Nachweis der befahrbaren Portugal-Finnland-Verbindung.

Webänderung: die bestehende Kunden-APK lädt die aktualisierte Buchungsoberfläche. Unveränderte native Fahrer-APK 0.6.1; keine neue APK erstellt oder auf Nutzergeräten installiert.
