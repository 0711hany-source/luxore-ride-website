# Fahrzeugbilder und App-Icons — 0.5.2

7. Oktober 2026: Das Modell bestimmt die Darstellung, unabhängig von der Reihenfolge oder Anzahl freigegebener Klassen. Die real beobachtete Flotte enthält Audi A6, Mercedes Benz E-Klasse und Mercedes Benz V-KLasse. Die vorhandenen E-/S-/V-Klasse-Bilder bleiben verfügbar; Audi A6 erhält eine eigene transparente SVG-Illustration. Fahrzeugwechsel, Flottenliste und Kunden-Fahrtkarte verwenden denselben Resolver.

Noch unbekannte Modelle bekommen unmittelbar eine beschriftete schematische Darstellung für Limousine, Van, SUV, Kombi oder Coupé. Diese ist kein modellspezifisches Foto. Weitere präzise Modellillustrationen können ergänzt werden, ohne Fahrzeugdaten und Klassen zu ändern. Fahrzeugnamen werden sicher als Text gerendert, wiederholte SVGs besitzen unterschiedliche Gradient-IDs.

App-Icons: gemeinsames selbst gezeichnetes L-Monogramm mit Straßenkurve, Ride in Champagner auf Graphit, Driver umgekehrt. Eigene SVG-Quellen, 1024px opake Store-Exporte, adaptive Vordergründe und monochrome Android-Ebene. Keine externe Grafikdienst-/Schriftabhängigkeit. `node scripts/render-app-icons.mjs` erzeugt alle Varianten und das gemeinsame Favicon.

Interne Android-APKs 0.5.2 / Build 12 sind keine Store-Releases. Einmal über die bestehenden Testapps installieren; das Launcher-Icon wird nicht durch Website-Updates ersetzt. Start/Konto/Menü sind nativ, Karten-/Fahrt-/Flottenbereiche weiterhin eingebettet. Reale Launcher-, GPS- und Hintergrundprüfung bleibt offen.

Prüfungen: Modellauflösung, sichere Textausgabe und SVG-IDs; exportierte Deckkraft/Größe, identische Glyphenmasken und Android-Sicherheitskreis; APK-Kennung, Variante, Bundle, Berechtigungen und Signatur. Neue Rollen/Berechtigungen oder Fahrzeugdaten werden durch die Bildänderung nicht angelegt.

Abschlussprüfung vor Veröffentlichung: 219 automatisierte Tests bestanden, Web-TypeScript und mobile TypeScript bestanden, Next.js-Produktionsbuild mit Webpack bestanden. Turbopack scheiterte lokal an einer gesperrten internen Portbindung; die tatsächliche Vercel-Übersetzung wird nach Veröffentlichung separat kontrolliert. Beide APKs gebaut und verifiziert; Signatur entspricht 0.5.1. Mobile Browserprüfung bei 390 × 844: automatische Vorschläge, Auswahl, Kilometerangebot (21 km: 52,50 / 73,50 / 63,00 Euro) und verspätete Antwort mit synthetischem lokalen Provider geprüft. Keine echte Fahrt oder Flottenänderung dabei ausgelöst. Live-Nachweis folgt nach Deployment.

## Tatsächlich veröffentlichter Stand

GitHub `572bc3245cc2bb960e4fb4cd1d4ae6d7dd360baa`, Vercel `924Kw4xXYLk7Kzb1xZditYYudrw2`: Ready / Production / Current Domain luxoreride.de im Browser bestätigt. Öffentliches Quellpaket entspricht bytegenau dem lokalen Paket; SHA-256 `8c960430b4c0b20e371dd3443831cc26421c26ae7464f96af2192edf8ccb2511`. Quelle basiert auf lokalem Commit `525d8ed`.

Live-Health HTTP 200: Datenbank verbunden, eigene Konten und Buchungskonfiguration bereit. Anonymer Kontoaufruf erhält keine Betreiberrechte. Ride-/Driver-PNGs, Audi-SVG und Favicon stimmen bytegenau; Favicon und Apple-Touch-Metadaten sind aktiv. Echte Mapbox-Vorschläge erscheinen auf luxoreride.de beim Tippen ohne Suchknopf. Live-Flotte zeigt alle drei vorhandenen Modelle mit unterschiedlichen Bildern; keine Fahrzeuge oder Rollen verändert.

Die additive Migration `0018_gorgeous_changeling.sql` wurde im bestehenden Turso-Production-SQL-Editor ausgeführt und mit ihrem echten Dateihash registriert: 19 Migrationen, neue nullable Herkunftsspalte vorhanden, Hash übereinstimmend. Vorhandene Fahrzeug-/Kontobestände blieben erhalten. Screenshot-/Prüfartefakte bleiben privat unter `outputs/verification-0.5.2` und `work/branding-052-live-checks.json`.

Geoapify bleibt unkonfiguriert: neue dauerhafte Textauswahl weiterhin ohne freigegebenen Anbieter oder kostenpflichtiges Mapbox-Budget nicht möglich. Keine kostenlose unbegrenzte Nutzung zusagen. Beide APKs 0.5.2 sind intern signiert; tatsächlicher Android-Launcher und Hintergrundnavigation müssen auf Geräten geprüft werden.
