# Fahrzeugbilder und App-Icons — 0.5.2

7. Oktober 2026: Das Modell bestimmt die Darstellung, unabhängig von der Reihenfolge oder Anzahl freigegebener Klassen. Die real beobachtete Flotte enthält Audi A6, Mercedes Benz E-Klasse und Mercedes Benz V-KLasse. Die vorhandenen E-/S-/V-Klasse-Bilder bleiben verfügbar; Audi A6 erhält eine eigene transparente SVG-Illustration. Fahrzeugwechsel, Flottenliste und Kunden-Fahrtkarte verwenden denselben Resolver.

Noch unbekannte Modelle bekommen unmittelbar eine beschriftete schematische Darstellung für Limousine, Van, SUV, Kombi oder Coupé. Diese ist kein modellspezifisches Foto. Weitere präzise Modellillustrationen können ergänzt werden, ohne Fahrzeugdaten und Klassen zu ändern. Fahrzeugnamen werden sicher als Text gerendert, wiederholte SVGs besitzen unterschiedliche Gradient-IDs.

App-Icons: gemeinsames selbst gezeichnetes L-Monogramm mit Straßenkurve, Ride in Champagner auf Graphit, Driver umgekehrt. Eigene SVG-Quellen, 1024px opake Store-Exporte, adaptive Vordergründe und monochrome Android-Ebene. Keine externe Grafikdienst-/Schriftabhängigkeit. `node scripts/render-app-icons.mjs` erzeugt alle Varianten und das gemeinsame Favicon.

Interne Android-APKs 0.5.2 / Build 12 sind keine Store-Releases. Einmal über die bestehenden Testapps installieren; das Launcher-Icon wird nicht durch Website-Updates ersetzt. Start/Konto/Menü sind nativ, Karten-/Fahrt-/Flottenbereiche weiterhin eingebettet. Reale Launcher-, GPS- und Hintergrundprüfung bleibt offen.

Prüfungen: Modellauflösung, sichere Textausgabe und SVG-IDs; exportierte Deckkraft/Größe, identische Glyphenmasken und Android-Sicherheitskreis; APK-Kennung, Variante, Bundle, Berechtigungen und Signatur. Neue Rollen/Berechtigungen oder Fahrzeugdaten werden durch die Bildänderung nicht angelegt.

Abschlussprüfung vor Veröffentlichung: 219 automatisierte Tests bestanden, Web-TypeScript und mobile TypeScript bestanden, Next.js-Produktionsbuild mit Webpack bestanden. Turbopack scheiterte lokal an einer gesperrten internen Portbindung; die tatsächliche Vercel-Übersetzung wird nach Veröffentlichung separat kontrolliert. Beide APKs gebaut und verifiziert; Signatur entspricht 0.5.1. Mobile Browserprüfung bei 390 × 844: automatische Vorschläge, Auswahl, Kilometerangebot (21 km: 52,50 / 73,50 / 63,00 Euro) und verspätete Antwort mit synthetischem lokalen Provider geprüft. Keine echte Fahrt oder Flottenänderung dabei ausgelöst. Live-Nachweis folgt nach Deployment.
