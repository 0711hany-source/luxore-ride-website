# Flottenverwaltung · 01.10.2026

## Anlass und Diagnose

Der Nutzer meldet erneut, dass das Speichern eines neuen Fahrzeugs nicht funktioniert, und wünscht eine vollständigere Flottenverwaltung. Eine konkrete Fehlermeldung liegt nicht vor. Der vorhandene lokale HTTP-Test konnte die Fahrzeuganlage bereits vor dieser Änderung erfolgreich ausführen. Der genaue Fehler auf seinem Android-Gerät ist deshalb noch nicht reproduziert; das Folgende ist eine geprüfte Überarbeitung des Speicherablaufs und der tatsächlich fehlenden Verwaltungsfunktionen, keine Behauptung einer bestätigten Gerätefehlerursache.

## Fahrzeuganlage und Bearbeitung

Das Formular validiert Modell, Kennzeichen und Klassen mit demselben Parser wie der Server. Fehler erscheinen direkt im Formular und das erste fehlerhafte Feld erhält den Fokus. Die native Browservalidierung blockiert das Absenden nicht mehr ohne sichtbaren App-Hinweis. Ein fehlendes Klassenhäkchen erzeugt einen verständlichen Hinweis statt eines wirkungslos deaktivierten Speichern-Knopfs. Leerzeichen und mobile Bindestrichvarianten werden normalisiert; mehrere Klassen sind möglich. Eingegebene Daten bleiben bei Fehlern erhalten. Das mobile Formular öffnet sich am unteren Bildschirmrand, kann scrollen und hat einen sichtbaren Aktionsbereich.

Neue Fahrzeuge erhalten für denselben Speicherentwurf eine wiederverwendbare Anfrage-ID. Geht die Antwort verloren, liefert die Wiederholung dasselbe gespeicherte Fahrzeug zurück. Auch gleichzeitige identische Anfragen erzeugen höchstens ein Auto. Fremde oder anders belegte IDs berechtigen zu keiner Änderung. Änderungen der Eingaben erzeugen eine neue Anfrage-ID. Eine erfolgreiche Anlage bleibt als Erfolg sichtbar, wenn nur das anschließende Laden der Liste fehlschlägt.

Die Flottenleitung und ihre Stellvertretung können aktive Fahrzeuge bearbeiten. Modell, Kennzeichen und Klassen werden beim zugeordneten Fahrer gemeinsam aktualisiert. Das ist nur offline, ohne aktive Standortsession, laufende Fahrt oder offene abgeschlossene Zahlung möglich. Die Liste zeigt den Sperrgrund. Verkaufte oder vorübergehend stillgelegte Autos können mit einem Grund archiviert und später wieder aktiviert werden. Eine aktive Doppelbelegung desselben Kennzeichens verhindert die Wiederaktivierung. Die Fahrzeug-ID und frühere Buchungssnapshots bleiben erhalten. Ein Fahrzeug wird durch Bearbeiten nicht in eine andere Flotte verschoben.

## Flotte und Team

Die Oberfläche zeigt eine ausgewählte Flotte mit vier Bereichen: Fahrzeuge, Team, Umsätze und Bordbestand. Der Besitzer kann den Flottennamen ändern. Die Auswahl bleibt bei Aktualisierung und Umbenennung erhalten. Umsatzzahlen eines vorherigen Zeitraums werden während eines neuen Ladevorgangs nicht mit einer falschen Zeitraumüberschrift gezeigt.

Besitzer und Stellvertretung können ausgeschiedene Mitarbeiter aus ihrer eigenen Flotte entfernen, sofern keine Schicht, laufende Fahrt oder offene Zahlung dagegensteht. Das entfernt die Fahrzeugwahl und Fahrerfreigabe; Profil und historische Umsätze bleiben bestehen. Besitzer können nicht entfernt werden; bei Stellvertretern muss zuerst die Stellvertretung aufgehoben werden. Ein späterer Beitritt per gültiger Einladung erfordert wieder eine Fahrerfreigabe. Fremde Flotten bleiben serverseitig getrennt. Ein gleichzeitiger Wechsel der Mitgliedschaft verhindert das Speichern einer veralteten Stellvertreterauswahl.

## Prüfung und Grenzen

- 15 gezielte Node-Tests: gemeinsamer Formularparser, mobile Eingaben, Mehrfachklassen, tatsächliche Submit-Controls der UI-Komponenten, sichtbare Fehler, Bearbeitungsmodus, Flottenbesitzer-Provisionierung und bestehende Zurück-/Wischgesten.
- Erweiterter lokaler HTTP-Test mit isolierten Geräteidentitäten, zwei Flotten und synthetischen Fahrten: Fahrzeuganlage inklusive gleichzeitigem Wiederholungsversuch, doppelte Kennzeichen, fremde Änderungen, Bearbeiten mit Fahrerabgleich, exklusive parallele Fahrzeugwahl, Sperren während Fahrt und Kassieren, Archiv/Wiederaktivierung mit Kennzeichenkonflikt, Besitzer-/Stellvertreterrechte, Umbenennen, Entfernen/Wiederbeitritt, Flottenwechsel, unveränderte historische Fahrpreise/Fahrzeugdaten/Umsätze.
- Typprüfung, gezieltes Lint und Produktionsbuild erfolgreich. Die erweiterten HTTP-Tests sind einschließlich gleichzeitiger Anlage und Mehrklassen-Abgleich bestanden.
- Keine Schemaänderung, kein neues Konto, keine Änderung an der nativen APK. Keine echten Kundenfahrten oder produktiven Flottendaten als Testdaten verändert.
- Keine visuelle Browserprüfung und kein Android-Touchtest durchgeführt. Das Öffnen der lokalen Vorschau wurde angefordert, vom App-Werkzeug aber nur als „queued“ bestätigt; die Interaktion auf dem konkreten Fahrerhandy bleibt zu prüfen.

## Nächster Schritt

Auf dem Fahrerhandy ein neues Flottenfahrzeug speichern, die Rückmeldung prüfen und es vor Schichtbeginn auswählen. Bei erneutem Fehlschlag ist die genaue nun sichtbar angezeigte Fehlermeldung nötig, um Gerätezugang, Validierung und Netzwerk eindeutig zu unterscheiden. Danach den vollständigen Buchungs-/Fahrt-/Kassiervorgang mit zwei Fahrergeräten prüfen.


## Gleichzeitige Fahrzeugänderungen · 03.10.2026

Beim Öffnen des Bearbeitungsformulars bleiben Modell, Kennzeichen und gespeicherte Klassen als ursprünglicher Datenstand erhalten. Die Aktualisierung der Liste ersetzt den offenen Entwurf nicht. Beim Speichern vergleicht der Server diesen Stand zunächst beim Lesen und nochmals in der atomaren Datenbankänderung. Ändern Besitzer und Stellvertretung dasselbe Fahrzeug gleichzeitig unterschiedlich, wird eine Änderung gespeichert; die zweite erhält HTTP 409. Fahrzeug und zugeordneter Fahrer behalten zusammen den gespeicherten Stand. Ein unveränderter Wiederholungsversuch mit bereits gespeicherten Zieldaten liefert Erfolg, ohne den Datensatz erneut zu verändern.

Das Formular zeigt einen Hinweis und lässt die eigenen Eingaben stehen. „Aktuelle Daten laden“ ersetzt den Entwurf erst auf ausdrücklichen Klick; direkt davor steht der Hinweis auf den Verlust ungespeicherter Eingaben. Laden und Speichern sperren weitere Aktionen bis zur Antwort oder zum bestehenden Zeitlimit. Alte geöffnete Bearbeitungsformulare ohne ursprünglichen Datenstand erhalten einen Hinweis zum Neuladen. Die Anlage neuer Fahrzeuge bleibt damit kompatibel. Klassenwerte müssen jetzt echte gültige Zeichenketten sein; verschachtelte Arrays und andere Typen werden abgewiesen.

Prüfung: 16 gezielte Node-Tests einschließlich Konfliktanzeige, gesperrtem Ladezustand, Formular und ungültiger Klassenwerte bestanden. Der erweiterte lokale HTTP-Test besteht mit parallelen Änderungen von Besitzer und Stellvertretung, genau einem Gewinner, unveränderten Daten nach veraltetem Speicherversuch, sicherer Wiederholung und erfolgreichem Speichern nach Neuladen. Die bisherigen Flotten-, Fahrzeug-, Fahrt- und Umsatzprüfungen laufen im selben Test mit. Typprüfung, gezieltes Lint und Produktionsbuild sind erfolgreich abgeschlossen. Keine Schemaänderung oder neue APK. Keine Browser-/Android-Interaktionsprüfung; die Einschränkung zur ursprünglichen Fehlermeldung oben bleibt bestehen.

## Sichere Fahrzeugfreigabe beim Fahrerwechsel · 03.10.2026, zweiter Durchlauf

Ein konkreter Übergabefehler wurde vor der Korrektur im lokalen HTTP-Test nachgestellt: Die Flottenleitung öffnet „Freigeben“ für Fahrer A. A gibt das Auto selbst frei, B übernimmt es, und die Leitung bestätigt den alten Dialog. Die bisherige Freigabe anhand der Fahrzeug-ID allein entfernte dann B (HTTP 200). Der neue Regressionstest scheiterte genau an diesem Ablauf.

Die Freigabe überträgt jetzt zusätzlich den im Dialog angezeigten Fahrer. Die Datenbank löst die Zuordnung nur atomar für diese Kombination aus Auto und Fahrer und weiterhin ausschließlich ohne Schicht, laufende Fahrt oder offene Zahlung. Übernimmt zwischenzeitlich ein anderer Fahrer, erhält die Leitung einen verständlichen Konflikthinweis; die Liste wird aktualisiert, der offene Dialog wird nicht still auf einen anderen Fahrer umgestellt. Eine Wiederholung nach verlorener Antwort ist erfolgreich, solange das Auto bereits frei ist. Wurde es inzwischen neu vergeben, kann dieser verspätete Wiederholungsversuch den anderen Fahrer nicht entfernen. Alte offene Oberflächen ohne Fahrerbezug müssen die Liste neu laden. Eventuelle ausstehende Angebote werden nur nach tatsächlich erfolgter Freigabe für den betroffenen Fahrer zurückgezogen.

Prüfung: Der erweiterte lokale HTTP-Test ist nach der Korrektur bestanden, einschließlich Fahrerwechsel unter einem offenen Freigabedialog, fehlendem Fahrerbezug, identischer Wiederholung und verspäteter Wiederholung nach Neuvergabe. Bestehende Prüfungen für Anlage, parallele Bearbeitung, exklusive Fahrzeugwahl, Klassen, Flottenrechte, historische Umsätze und abgeschlossene Zahlungen laufen ebenfalls durch. Typprüfung und Produktionsbuild erfolgen zusätzlich vor Veröffentlichung. Keine Schemaänderung, keine neue APK und keine produktiven Testfahrten. Der Hintergrunddurchlauf öffnet keine Browservorschau und ersetzt keinen Test auf zwei echten Android-Geräten.

Nächster Schritt: Schichtwechsel und Fahrzeuganlage auf zwei Fahrergeräten prüfen; bei erneutem Speicherfehler den konkreten sichtbaren Fehlertext erfassen. Danach die verbleibenden realen GPS-Abweichungen und den Navigationsverlauf am Gerät prüfen, statt weitere Filter ohne Messdaten zu verändern.
