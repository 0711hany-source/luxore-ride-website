# Native Flotteneinladungen · Fahrer 0.7.1 / Build 25

## Abgeschlossener Oberflächenschritt

Die Fahrer-App enthält eine eigene feste Einladungsseite: erreichbar über App-Menü > Flotteneinladungen und aus der nativen Disposition. Code einlösen und Team einladen sind native Register, kein eingebettetes Webportal. Die Leitung wählt ausschließlich tatsächlich vom Server gelieferte Flotten, deren Besitzer-/Stellvertretungs-ID zum aktuellen Konto passt. Ein Code wird nur nach vollständiger Serverbestätigung angezeigt, ist selektierbar, enthält Ablaufzeit und kann über die native Teilen-Auswahl weitergegeben werden. Keine Nachricht wird automatisch versandt.

Erstellen und Beitreten werden ausschließlich durch vollständiges Wischen bestätigt, ohne Tippen-Ersatz. Der Code wird getrimmt und großgeschrieben, sein Format geprüft; tatsächliche Einladungsgültigkeit, Konten, Flottenrechte und Einsatzstatus entscheidet weiterhin der bestehende atomare Server. Eine erfolgte Antwort bestätigt den Beitritt, anschließend eigener Einstieg zum Fahrerbereich. Kein automatisches Online-Gehen oder automatische Fahrerfreigabe. Vorhandenes Fahrerprofil, Offline-/GPS-/Fahrt-/Zahlungssperren bleiben erforderlich.

## Lifecycle und Grenzen

FleetInvitationsController ist kontogebunden. Die echte fleets-Leseanfrage verwendet AbortSignal; Hintergrund/verborgene Seite beendet Reads, Vordergrund lädt neu. Alte Antworten und finally-Blöcke können keine neuen Anfragen freigeben oder Leitungsdaten überschreiben. 403 auf fleets bedeutet für normale Fahrer fehlenden Leitungszugang, verhindert aber den eigenen Codebeitritt nicht. 401 löscht Einladungs-/Leitungsdaten und sperrt Aktionen bis erneuter Anmeldung. Erstellung braucht einen bestätigten Leitungsstand unter 30 Sekunden; sichtbarer Sekundentakt sperrt die Geste auch bei hängender Antwort. Kein Poll im Hintergrund.

Schreibvorgänge werden nicht durch Lifecycle-Reads abgebrochen. Keine optimistische Bestätigung, keine parallelen Änderungen. Unklare Antwort sperrt andere Vorgänge und erlaubt nur dieselbe ausdrückliche Wiederholung: beim Beitritt derselbe normalisierte Code, bei Erstellung dieselbe Flotte mit sichtbarem Hinweis auf einen möglichen zusätzlichen Code. Keine automatische Wiederholung. Einladungs-/Beitrittszustand bleibt nur in dieser Seiteninstanz, kein dauerhaft gespeicherter Auftrag und keine Wiederaufnahme nach Prozessneustart. Kontowechsel/unmount verwirft die bisherige Ansicht; verspätete Bestätigungen gehen nicht in das neue Konto über. 409/sonstige bekannte Ablehnung behauptet keinen Erfolg. Codeablauf und entzogene Leitung sperren Teilen/weitere Erstellung entsprechend dem aktuellen Stand; der Server prüft bei Annahme erneut.

Weitere native Teamzuordnung, Stellvertretungswahl und Flottengründung bleiben offen. Bestehende Fahrzeuge, Betreiberfahrzeug Audi A6 HG IV 777, Konten, Rechte, Anbieterbudgets und Altbestand unverändert. Keine neue Datenbankmigration, Production-Einladung, Freigabe, Testfahrt, E-Mail, Gebühr oder Store-Einreichung.

## Prüfungen

Acht Controller-Tests: aktuelle eigene Leitungsflotte/Alters-/Formatsperre, alte Read-/finally-Antworten, 403/401/Netzfehler, Schreiben im Hintergrund/Parallelität, identischer ausdrücklicher Beitrittsretry, unklare Erstellung/Antwortvalidierung, bekannte Ablehnung/entzogene Leitung und Kontodispose. Drei tatsächliche React-Native-Komponententests prüfen native Flottenwahl und vollständige Geste ohne Tippen, Codeeingabe/Serverbestätigung über Hintergrund sowie den echten App-Menüeinstieg ohne Fahrer-WebView. Insgesamt 466 Tests bestanden. Beide TypeScript-Prüfungen, gezieltes Lint, Format- und Diff-Prüfung bestanden.

Lokale echte Komponenten-Vorschau mit ausdrücklich synthetischen Daten bei 390×844 und 390×640: kein äußerer horizontaler Überlauf, Inhalte scrollen innerhalb der festen Seite, Wischfläche im kleinen Fenster auf y=559–613 erreichbar. Tatsächliche vollständige UI-Wischgeste erzeugt ausschließlich eine lokale synthetische Bestätigung; keine Production-Anfrage. Nachweise outputs/native-invites/create-preview.png und result-preview.png. Dies ist kein angemeldeter physischer Android-Nachweis.

Kunden-APK bleibt unverändert 0.6.9 / Build 23. Fahreränderung benötigt das neue Update 0.7.1 / Build 25; ein Website-Update installiert keine APK auf Nutzerhandys. Angemeldete echte Einladungs-/Mehrgeräte-/Fahrt-/Hintergrund-GPS-Prüfungen bleiben offen. Keine Produktionsreife behaupten.

## APK und Veröffentlichung

Fahrer-APK mobile/artifacts/Luxore-Driver-Test-0.7.1.apk: 56159352 Bytes, SHA-256 `26f98e84f092e31a67e6f0c5a5480a9a61bf368a7b242cee2fc12717b0bd55dc`. Paket de.luxoreride.driver.preview / Build 25; unveränderte interne Signatur `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c`. Standalone ARM64, nicht debuggbar, Designvorschau/Backup aus, vorhandene Alarm-/Hintergrundstandortberechtigungen erhalten, Mikrofon/Overlay gesperrt. 51 Runtime-/Konfigurationsquellen bytegenau mit dem außerhalb des synchronisierten Quell-/Abhängigkeitsordners gebauten Stand verglichen; Paketversionen unverändert. Finales Fahrer-/Internal-JS-Bundle ausdrücklich neu gebaut, anschließend Release-Assemblierung erfolgreich. TypeScript-Formatkorrektur änderte keine APK-Bytes.

Im isolierten Emulator zunächst als Update über installierte 0.7.0 / Build 24 ohne Deinstallation installiert; endgültige APK erneut über denselben 0.7.1-Stand aktualisiert und drei Kaltstarts ohne Android-Fatal-/JS-Exception bestanden. Anonymer nativer Start, keine angemeldete echte Einladungs-/SDK-/Schichtprüfung. Nachweis outputs/native-invites/driver-emulator-start.png und work/native-invites/emulator-result.json. Keine Installation auf Nutzerhandys, Kunden-APK 0.6.9 unverändert.

Quellveröffentlichungs- und geschützte APK-Downloadnachweise folgen nach bestätigtem Deployment.
