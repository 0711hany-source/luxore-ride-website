# Flotteneinladungen zuverlässig speichern · 13. Oktober 2026

## Abgeschlossener Schritt

Ein bereits erfolgreicher Beitritt meldete bei Wiederholung desselben Codes einen Konflikt. Einladungserstellung prüfte Leitungsrechte vor dem getrennten Schreiben; Kontosperren und Mitgliedschaft der einladenden Leitung wurden dabei nicht erneut geprüft. Beide Aktionen erzeugten bisher keinen Audit.

`createFleetInvite` und `joinFleet` prüfen nun aktuelle Flottenrechte, Mitgliedschaft und aktive Konten im gleichen libSQL-Schreibzugriff wie Speicherung und echten Audit. Einladungen bleiben 24 Stunden gültig; die Zeitprüfung erfolgt nach dem Hashen innerhalb des Schreibzugriffs. Nur Besitzer oder Stellvertretung der konkreten Flotte mit aktueller Mitgliedschaft dürfen einladen, auch ein Plattformbetreiber erhält dadurch keine zusätzlichen Einladungsrechte. Alte Identitäten ohne Kontodatensatz behalten das bisherige Verhalten. Gesperrte oder zur Löschung vorgemerkte Konten können weder einladen noch beitreten.

Ein gültiger Code bestätigt eine bereits bestehende Mitgliedschaft derselben Flotte unverändert. Fahrzeug, spätere Fahrerfreigabe, Rolle und laufende GPS-Schicht bleiben erhalten; kein zweiter Audit. Das bestätigt den aktuellen Mitgliedschaftsstand und ist keine dauerhaft gespeicherte Quittung eines bestimmten Einladungsvorgangs. Abgelaufene Codes, inzwischen verlorene Leitungsrechte oder gesperrte Konten bleiben auch bei Wiederholung gesperrt.

Ein neuer Beitritt erhält alle bisherigen Sperren: vorhandenes Fahrerprofil, keine fremde Flottenmitgliedschaft oder eigene Leitungsrolle, offline, ohne GPS-Sitzung, aktive Fahrt oder offene Abschlusszahlung. Neue Mitgliedschaft, Rücksetzung alter Fahrzeug-/Freigabezuordnung, Rücknahme offener Angebote und Audit speichern gemeinsam. Audit-/Speicherfehler rollen alles zurück. Einladungserstellung speichert Bereinigung abgelaufener Codes, neuen Hash und Audit ebenfalls gemeinsam; ein fehlgeschlagener Schreibzugriff gibt keinen nutzbaren Code zurück. Nur SHA-256-Hashes werden gespeichert, keine Klartextcodes im Audit.

## Prüfungen und Grenzen

Zehn tatsächliche Endpunkt-/libSQL-Prüfungen mit allen Migrationen, echtem SQLite-Adapter und echter Audit-Funktion: verlorene Antwort mit späterer Freigabe/Online-Schicht; Audit-/Fahrerresetfehler und Wiederholung; ungültige Codes, fehlende Profile, fremde Flotte und Leitungsrolle; abgelaufene oder widerrufene Einladungen; gesperrte Konten; Online-/GPS-/Fahrt-/Zahlungssperren; Ablauf an der tatsächlichen Schreibgrenze; bestehende Mitarbeiterrolle und gelöste Null-Zuordnung; atomare Einladungserstellung sowie Besitzer-/Stellvertreter-/Fremdflottenscope.

Der isoliert geladene alte Endpunkt und alte Einladungsbaustein scheitern an sieben der zehn Prüfungen; drei bestehende Guards bestehen vorher und bleiben erhalten. Runtime-Dateien werden für den Vergleich nicht ausgetauscht. Korrigiert bestehen alle zehn. Insgesamt 445 Tests, Web-/Mobile-TypeScript, gezieltes Lint und Diff-Prüfung bestanden. Ausschließlich synthetische lokale Daten; keine Production-Einladungen, Freigaben, Fahrten oder Konten geändert.

Keine Migration oder neue APK erforderlich. Kunde bleibt 0.6.9 / Build 23, Fahrer 0.7.0 / Build 24. Das eigene Webportal nutzt die bestehenden Aktionen. Native Einladungserstellung/-annahme und weitere Teamzuordnung sind noch nicht als neue Oberfläche umgesetzt und folgen als nächster Schritt. Keine automatische Wiederholung einer Einladungserstellung: eine verlorene Erstellungsantwort kann bei erneutem Aufruf einen weiteren Code erzeugen. Der bestätigende Beitritt ist unter den oben genannten Gültigkeitsbedingungen wiederholbar. Angemeldete physische Mehrgeräte-, Schicht- und Hintergrund-GPS-Prüfungen bleiben offen.

## Veröffentlichung

Der exakte Archivbuild und die Live-Nachweise werden nach erfolgreicher Veröffentlichung ergänzt.
