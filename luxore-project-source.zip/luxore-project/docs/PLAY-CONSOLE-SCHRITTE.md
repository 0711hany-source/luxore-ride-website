# Google Play Console – Schritt für Schritt

Stand 18.11.2026. Das Entwicklerkonto ist angelegt und bezahlt (Meldung Hanan). Claude lädt nichts hoch; die Schritte in der Play Console macht Hanan selbst oder gibt jeden Upload einzeln frei. Texte unten sind Entwürfe – rechtliche Angaben (Datensicherheit, Händlerangaben) vor dem Absenden mit der Inhaberin abstimmen.

## Dateien

- `Luxore-Ride-Store-<Version>.aab` und `Luxore-Driver-Store-<Version>.aab` in der Ablage „LUXORE Store-Pakete“.
- Store-Texte: `mobile/store/STORE-LISTINGS-DE.md`.

## 1. Zwei Apps anlegen (je einmal für Ride und Driver)

„App erstellen“ →
- Name: `LUXORÉ Ride` bzw. `LUXORÉ Driver`
- Standardsprache: Deutsch (Deutschland)
- App oder Spiel: App
- Kostenlos oder kostenpflichtig: Kostenlos
- Erklärungen (Richtlinien, US-Exportgesetze) bestätigen – das ist eine Zustimmung, die nur Hanan/Inhaberin geben kann.

## 2. Erst der interne Test (empfohlen)

Menü „Testen → Interner Test“ → „Neuen Release erstellen“:
- Bei der ersten Datei fragt Google nach „Play App Signing“ → annehmen (Standard).
- Die `.aab`-Datei hochladen, Release-Name wird automatisch gesetzt.
- Versionshinweise: `Erste Testfassung.`
- Unter „Tester“ eine E-Mail-Liste anlegen (bis 100 Google-Konten), Einladungslink kopieren und an die Tester geben.

Der interne Test braucht keine Store-Seite und keine Prüfung. Die App kommt so in wenigen Minuten über den Play Store auf die Test-Handys.

## 3. Privates Konto: geschlossener Test vor der Veröffentlichung

Falls das Konto ein privates Konto ist, verlangt Google vor „Produktion“ einen geschlossenen Test mit mindestens 12 Testern, die 14 Tage am Stück angemeldet bleiben. Die Play Console zeigt das auf der Startseite der App an. Ein Firmenkonto braucht das nicht.

## 4. Angaben unter „App-Inhalte“ (Entwurf der Antworten)

| Formular | Ride | Driver |
| --- | --- | --- |
| Datenschutzerklärung | https://luxoreride.de/datenschutz | gleich |
| App-Zugriff | „Zugriff eingeschränkt“: Anmeldung per E-Mail-Code. Testzugang für die Prüfer nötig (siehe unten) | gleich, zusätzlich freigegebener Fahrer mit Fahrzeug |
| Werbung | Nein, keine Werbung | Nein |
| Altersfreigabe (Fragebogen) | Kategorie „Dienstprogramm/Produktivität/Sonstiges“; keine Gewalt, keine Glücksspiele; Nutzer können miteinander schreiben (Chat Kunde–Fahrer): Ja; Standort wird geteilt: Ja | gleich |
| Zielgruppe | ab 18 Jahren | ab 18 Jahren |
| Nachrichten-App | Nein | Nein |
| Behörden-App, Finanzfunktionen, Gesundheit | Nein | Nein |
| Kontolöschung | https://luxoreride.de/konto | gleich |

### Datensicherheit (Entwurf – vor dem Absenden rechtlich bestätigen lassen)

- Daten werden erhoben: Ja. Verschlüsselte Übertragung: Ja. Nutzer können Löschung verlangen: Ja (Link oben).
- Weitergabe an Dritte: In der Play-Definition zählt die Verarbeitung durch Dienstleister (Hosting, Karten, E-Mail-Versand) nicht als Weitergabe. Ob darüber hinaus weitergegeben wird, muss die Inhaberin bestätigen.

| Datenart | Ride | Driver | Zweck |
| --- | --- | --- | --- |
| Name | ja | ja | App-Funktionen, Kontoverwaltung |
| E-Mail-Adresse | ja | ja | Anmeldung, Kontoverwaltung |
| Telefonnummer | ja (falls angegeben) | ja | App-Funktionen |
| Genauer Standort | ja, nur bei geöffneter App und freiwillig | ja, auch im Hintergrund während der Schicht | App-Funktionen (Abholort, Vermittlung, Anfahrt) |
| Fotos | Profilbild (freiwillig) | Profilbild, Fotos für die Prüfung | App-Funktionen |
| Nachrichten in der App | Chat mit dem Fahrer | Chat mit dem Kunden | App-Funktionen |
| Adressen/Fahrten (Sonstige Nutzerinhalte bzw. Kaufverlauf) | ja | ja | App-Funktionen |
| Zahlungsdaten | nein (keine Online-Zahlung) | nein | – |
| Werbe-ID, Analyse, Absturzberichte an Dritte | nein | nein | – |

### Standort im Hintergrund (nur Driver)

Formular „Berechtigungen für Standort“:
- Hauptfunktion: „Vermittlung von Fahrten an Chauffeure während einer gestarteten Schicht.“
- Begründung: „LUXORÉ Driver übermittelt den Standort des Chauffeurs nur während einer von ihm gestarteten Schicht, damit Fahrtanfragen dem nächsten freien Fahrzeug angeboten und Kunden die Anfahrt angezeigt werden können – auch wenn der Bildschirm aus ist oder eine Navigations-App im Vordergrund läuft. Mit dem Beenden der Schicht endet die Ortung. Eine dauerhafte Mitteilung zeigt die laufende Ortung an.“
- Video (max. 30 s, YouTube-Link nicht gelistet): Schicht starten → Hinweis und Berechtigungsdialog → App in den Hintergrund → Mitteilung sichtbar → Schicht beenden. Muss auf einem echten Gerät aufgenommen werden (Hanan).

## 5. Store-Eintrag (für geschlossenen Test und Produktion)

- Texte aus `mobile/store/STORE-LISTINGS-DE.md` (Kurzbeschreibung max. 80 Zeichen, Beschreibung max. 4000).
- App-Symbol 512 × 512 und Titelgrafik 1024 × 500 liegen in `mobile/store/graphics/` (Kopie in der Ablage „LUXORE Store-Pakete/Grafiken“). Mindestens 2 Handy-Screenshots je App fehlen noch – am besten echte Bildschirmfotos vom Android-Handy (Hanan).
- Kategorie: „Karten & Navigation“ oder „Reisen & Lokales“ (Auswahl Hanan). Kontakt-E-Mail und Website eintragen.

## 6. Was vor „Produktion“ noch fehlt

- Testzugang für die Prüfer: gebaut (18.11.2026), aber aus – siehe Abschnitt 7. Wirkt erst nach dem nächsten Server-Upload und nachdem Hanan die zwei Werte in Vercel eingetragen hat.
- Erledigt: Store-Texte nennen kein Einsatzgebiet (wie der Starttext der Apps); Version 1.0.0 (Entscheidung Hanan 18.11.).
- Rechtstexte und Datensicherheitsangaben geprüft – Inhaberin.
- Push für Fahrer, kommerzielles Hosting – siehe `docs/STORE-EINREICHUNG.md`.

## 7. Prüfer-Zugang (für Google Play und App Store)

Die Prüfer müssen sich anmelden können, ohne ein Postfach von uns zu haben. Dafür gibt es den Prüfer-Zugang: Für wenige hinterlegte Adressen gilt ein fester sechsstelliger Code; es wird keine Mail verschickt. Ohne die zwei Einstellungen ist er ausgeschaltet.

So wird er eingeschaltet (macht Hanan selbst, nach dem Server-Upload):

1. Zwei Adressen ausdenken, die es als Postfach nicht geben muss, z. B. `pruefer-kunde@luxoreride.de` und `pruefer-fahrer@luxoreride.de`.
2. In Vercel → Projekt → Settings → Environment Variables eintragen:
   - `LUXORE_REVIEW_EMAILS` = beide Adressen, mit Komma getrennt (höchstens 6).
   - `LUXORE_REVIEW_CODE` = sechs Ziffern, kein einfaches Muster (nicht 123456, nicht 111111). Den Code nirgends sonst verwenden.
3. Neu ausliefern lassen (Vercel → Deployments → Redeploy), damit die Werte gelten.
4. In den Apps mit jeder Adresse einmal „Registrieren“ wählen (Kunde bzw. Fahrer) und den Code eingeben.
5. Den Prüf-Fahrer wie jeden Fahrer behandeln: in eine Flotte einladen, Fahrzeug zuordnen, freigeben. Achtung: Ein freigegebener, online geschalteter Prüf-Fahrer bekommt echte Fahrtanfragen – am besten eine eigene Prüf-Flotte ohne echte Fahrzeuge im Einsatz.
6. Adresse und Code im Store-Formular „App-Zugriff“ (Google) bzw. „App Review Information“ (Apple) eintragen, dazu der Satz: „Anmeldung: Adresse eingeben, ‚Code per E-Mail erhalten‘ antippen, dann den genannten Code eingeben. Es wird keine E-Mail benötigt.“
7. Nach bestandener Prüfung beide Werte in Vercel wieder löschen und neu ausliefern.

Sicherheit: Es gelten dieselben Grenzen wie für jede Anmeldung (5 Versuche je Code, ein Code pro Minute, 8 Codes pro Tag und Adresse). Die Betreiber-Adresse kann nie Prüfer-Adresse sein. Jede Anmeldung über diesen Weg steht im Betreiber-Protokoll als „Prüfer-Zugang angemeldet“.
