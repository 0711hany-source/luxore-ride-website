# Reservierungsroute und Kartenkonfiguration · 9. Oktober 2026

## Ursache und Korrektur

Die Adresssuche funktionierte über Geoapify. Der anschließende Reservierungspreis scheiterte an Mapbox Directions: JavaScript `toISOString()` sendete eine UTC-Zeit mit Millisekunden als `depart_at`. Mapbox akzeptiert hier UTC-Zeiten mit ganzen Sekunden, beispielsweise `2026-10-10T10:30:00Z`, und antwortete beim bisherigen Format mit HTTP 422 / `InvalidInput`. Der gemeinsame Provider übersetzte das in die gemeldete allgemeine Kartenkonfigurationsmeldung (HTTP 502). Der Live-Reservierungsendpunkt zeigte denselben Fehler; es fehlte kein neuer Token.

Der gemeinsame Routingadapter entfernt jetzt nur die Millisekunden aus der an Mapbox übertragenen Abfahrtszeit. Das numerische Abholdatum in Angebot, Reservierung und Datenbank bleibt unverändert. Sofortfahrt (`depart_at=now`), Verkehrsprofil `driving-traffic`, normale befahrbare Nebenstraßen, Ausschluss unbefestigter Straßen, Routengeometrie, GPS-/Anfahrtskurs und alle Kilometerpreise bleiben erhalten. Keine zusätzliche Ausweichroute, neue API-Abrechnung, Rechteänderung, Migration oder neue APK.

Vorgabe: https://docs.mapbox.com/api/navigation/directions/ (Optional parameters / depart_at). Keine permanente kostenpflichtige Geokodierung aktiviert; Mapbox-Budget bleibt null, Geoapify übernimmt weiterhin die lizenzierte Textadressbestätigung.

## Geprüfte Konfiguration

Mit einer gewöhnlichen eigenen anonymen Gerätesitzung ist der aktuelle öffentliche Karten-Token ausschließlich im Arbeitsspeicher gelesen worden. Keine Schlüssel in Bericht, Repository oder Screenshots. Direkte Directions-Prüfung mit öffentlichen Berliner Sehenswürdigkeiten: Sofortfahrt HTTP 200; bisherige Reservierungszeit mit Millisekunden HTTP 422 / InvalidInput; identische Reservierung ohne Millisekunden HTTP 200; ebenfalls HTTP 200 für einen Termin in 89 Tagen. Kartentoken und Verkehrsprofil funktionieren. Die farbige Streets-v12-Webkarte und Geoapify-Adresssuche bleiben aktiv.

Ein neuer Test ruft die tatsächlichen Adress-, Angebots- und Buchungsendpunkte mit echten SQLite-Migrationen und dem dokumentierten Mapbox-Zeitvertrag auf. Er scheitert im alten Stand mit genau HTTP 502 und besteht nach der Korrektur. Er prüft zudem, dass der gebuchte Zeitstempel mit Millisekunden erhalten bleibt, die Kilometerpreise richtig sind und ausschließlich lokal eine Reservierung statt einer Sofortfahrt entsteht. 305 Tests, Web-TypeScript und gezieltes Lint bestanden. Keine Production-Reservierung oder Fahrerbenachrichtigung durch den Test erzeugt. Archivbuild, tatsächliche Veröffentlichung und erneuter Website-Reservierungsablauf werden nachfolgend dokumentiert.

## Veröffentlichung und erneuter Live-Ablauf

Quellstand a460f70; Archiv mit 431 Dateien / 7.644.305 Bytes / SHA-256 2f3994233bd21464c6e32e3ab2da590c7ea4e4363203e8839c198bc2c8f9316e. Produktionsbuild des tatsächlichen Archivs bestanden. GitHub 366f3563f8d0e513ce33b4b79b97f6ea8fb08c75 enthält die drei Upload-Dateien bytegleich. Vercel 4GqCLRPVmGKpUuspjxr2gZ5cpbow ist Ready / Latest / Current Production unter luxoreride.de. Kein Tokenwechsel erforderlich.

Der echte Website-Ablauf auf /ride wurde vor und nach Veröffentlichung im selben offenen Formular geprüft: Reservieren, echte Geoapify-Adressvorschläge, Alte Oper → Flughafen Terminal 1, Abholzeit 11. Oktober 2026 um 12:30 Uhr. Vorher erscheint exakt die gemeldete Kartenkonfigurationsmeldung. Nachher gelangt „Route & Preise anzeigen“ zur Klassenwahl, mit farbiger Mapbox-Karte, beiden Markierungen, Straßenroute, ca. 20 Minuten / 21 km und Preisen 52,61 € / 73,65 € / 63,13 €. Keine tatsächliche Reservierung abgeschickt. Screenshots: outputs/reservation-routing/website-before.png und website-reservation-after.png.

Zusätzlicher Live-API-Ablauf mit öffentlichen Berliner Sehenswürdigkeiten: Sofortfahrt, Termin morgen und Termin in 89 Tagen liefern jeweils HTTP 200, die ursprünglichen Abholzeitstempel bleiben unverändert, Route 2.284 m und alle Mindestpreise korrekt. Health, Kontobereitschaft und Kunden-/Fahrer-/Dispositionsseiten sind HTTP 200. Konten, Datenbank und Buchungskonfiguration bereit. Kein echter Schicht-/Fahr-/Hintergrund-GPS-Test; diese Aufgabe betrifft den Website-Karten- und Reservierungsablauf. Der bestehende Automationsprompt ist auf 305 Tests und das korrekte Reservierungszeitformat aktualisiert.
