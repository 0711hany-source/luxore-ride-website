# Reservierungsroute und Kartenkonfiguration · 9. Oktober 2026

## Ursache und Korrektur

Die Adresssuche funktionierte über Geoapify. Der anschließende Reservierungspreis scheiterte an Mapbox Directions: JavaScript `toISOString()` sendete eine UTC-Zeit mit Millisekunden als `depart_at`. Mapbox akzeptiert hier UTC-Zeiten mit ganzen Sekunden, beispielsweise `2026-10-10T10:30:00Z`, und antwortete beim bisherigen Format mit HTTP 422 / `InvalidInput`. Der gemeinsame Provider übersetzte das in die gemeldete allgemeine Kartenkonfigurationsmeldung (HTTP 502). Der Live-Reservierungsendpunkt zeigte denselben Fehler; es fehlte kein neuer Token.

Der gemeinsame Routingadapter entfernt jetzt nur die Millisekunden aus der an Mapbox übertragenen Abfahrtszeit. Das numerische Abholdatum in Angebot, Reservierung und Datenbank bleibt unverändert. Sofortfahrt (`depart_at=now`), Verkehrsprofil `driving-traffic`, normale befahrbare Nebenstraßen, Ausschluss unbefestigter Straßen, Routengeometrie, GPS-/Anfahrtskurs und alle Kilometerpreise bleiben erhalten. Keine zusätzliche Ausweichroute, neue API-Abrechnung, Rechteänderung, Migration oder neue APK.

Vorgabe: https://docs.mapbox.com/api/navigation/directions/ (Optional parameters / depart_at). Keine permanente kostenpflichtige Geokodierung aktiviert; Mapbox-Budget bleibt null, Geoapify übernimmt weiterhin die lizenzierte Textadressbestätigung.

## Geprüfte Konfiguration

Mit einer gewöhnlichen eigenen anonymen Gerätesitzung ist der aktuelle öffentliche Karten-Token ausschließlich im Arbeitsspeicher gelesen worden. Keine Schlüssel in Bericht, Repository oder Screenshots. Direkte Directions-Prüfung mit öffentlichen Berliner Sehenswürdigkeiten: Sofortfahrt HTTP 200; bisherige Reservierungszeit mit Millisekunden HTTP 422 / InvalidInput; identische Reservierung ohne Millisekunden HTTP 200; ebenfalls HTTP 200 für einen Termin in 89 Tagen. Kartentoken und Verkehrsprofil funktionieren. Die farbige Streets-v12-Webkarte und Geoapify-Adresssuche bleiben aktiv.

Ein neuer Test ruft die tatsächlichen Adress-, Angebots- und Buchungsendpunkte mit echten SQLite-Migrationen und dem dokumentierten Mapbox-Zeitvertrag auf. Er scheitert im alten Stand mit genau HTTP 502 und besteht nach der Korrektur. Er prüft zudem, dass der gebuchte Zeitstempel mit Millisekunden erhalten bleibt, die Kilometerpreise richtig sind und ausschließlich lokal eine Reservierung statt einer Sofortfahrt entsteht. 305 Tests, Web-TypeScript und gezieltes Lint bestanden. Keine Production-Reservierung oder Fahrerbenachrichtigung durch den Test erzeugt. Archivbuild, tatsächliche Veröffentlichung und erneuter Website-Reservierungsablauf werden nachfolgend dokumentiert.
