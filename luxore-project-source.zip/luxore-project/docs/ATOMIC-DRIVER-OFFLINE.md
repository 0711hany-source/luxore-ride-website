# Atomarer authentifizierter Schicht-Stopp · 17. Oktober 2026

## Nachgewiesene Fehler

POST /api/mobility/driver mit action:offline bestätigte bislang auch eine falsche oder inzwischen ersetzte sessionId mit ok:true. Der Fahrer-Update wurde dabei zwar durch die Session geschützt, die anschließende Angebotsrücknahme aber nur durch online=0. Ein alter Stopp konnte dadurch Angebote einer neu gestarteten, vor dem ersten GPS-Punkt noch nicht online markierten Schicht zurückziehen. Nach der vorgelagerten Profil-/Identitätsprüfung entzogene Fahrerfreigaben oder Kontosperren wurden nicht im Schreibzugriff erneut geprüft. Die Fahrt-/Zahlungssperre der Oberfläche war am eigentlichen Offline-Schreibzugriff ebenfalls nicht verbindlich.

Zudem blieben native Capability-Datensätze beim authentifizierten Stopp liegen. Ein Dispatchfehler nach bereits committed Offline-Schaltung lieferte HTTP 500; selbst eine unveränderte Wiederholung beziehungsweise Bestätigung nach erfolgreichem nativen Stopp führte erneut Dispatch aus.

## Änderung

lib/mobility/driver-offline.ts liest den aktuellen Kontostatus und freigegebenen eigenen Fahrer innerhalb eines libSQL-Schreibzugriffs. Ein bestehendes gesperrtes/zu löschendes Konto oder nicht mehr freigegebener Fahrer bleibt 403. Gültige Altidentitäten ohne lokalen Accountdatensatz bleiben kompatibel. Die Zielperson stammt ausschließlich aus der authentifizierten Identität, niemals aus einem driverId-Feld des Anfragekörpers.

Bei noch vorhandener Session muss sie exakt mit der erwarteten sessionId übereinstimmen; sonst 409 ohne eigene Mutation. Ein tatsächlicher Schichtübergang wird bei accepted/arrived/riding sowie completed mit completed_at und unbezahltem Betrag gesperrt, auch wenn dieser Einsatz erst nach der Bildschirm-/vorgelagerten Fahrerabfrage entstanden ist. Bezahlte abgeschlossene Geschichte blockiert nicht. Ein inzwischen inaktives/archiviertes ausgewähltes Fahrzeug verhindert den eigenen Stopp nicht; bestehende Start-/Fahrzeugrechte werden nicht erweitert.

Offline-Schaltung, Löschen sämtlicher nativer Capabilities ausschließlich dieser Person/Session und Rücknahme ihrer pending-Angebote speichern gemeinsam. Fehler eines Schritts rollen alles zurück; ausdrückliche identische Wiederholung nach behobenem Speicherfehler bleibt möglich. Fahrzeugauswahl, Fahrerfreigabe, Profil, rohe GPS-Koordinaten, Team, Bestand und Fahrtgeschichte werden durch diesen Übergang nicht zurückgesetzt. Andere Personen mit zufällig gleicher Session-Zeichenfolge verlieren keine Capability.

Ist die eigene freigegebene Person bereits online=0 und session_id=NULL, wird ausschließlich dieser aktuelle Zustand bestätigt: kein Update, keine Tokenlöschung, keine Angebotsrücknahme und kein neuer Dispatch. Das erhält den normalen nativen Ablauf, der zuerst den separat abgesicherten Capability-Stopp ausführt und danach authentifiziert offline bestätigt, sowie ausdrückliche Wiederholung nach verlorener Antwort. Es ist keine dauerhafte Quittung einer bestimmten alten Session. Eine vorhandene neuere Session bleibt dagegen 409, auch bei online=0. Aktuelle Konto-/Freigaberechte gelten ebenfalls für die Zustandsbestätigung.

Nur nach tatsächlich committed Änderung folgt die bestehende globale Dispatch-Aktualisierung. Deren Fehler wird als „Driver offline dispatch refresh failed“ im Serverlog protokolliert und verändert die bereits bestätigte Pause nicht in HTTP 500. ok:true bestätigt den eigenen aktuellen Offlinezustand beziehungsweise den gespeicherten Übergang, keine erfolgreiche Neuvermittlung der gesamten Queue. Kein automatischer Stop-/Dispatch-Retry und keine neue API.

## Tatsächliche Prüfungen

18 neue Endpunkt-/libSQL-Tests laden den tatsächlichen driver-Endpunkt, neuen Stop-Code, echten Dispatch und sqliteDatabase-Adapter mit sämtlichen Projektmigrationen in einer isolierten In-Memory-Datenbank. Nur Identitäts-/Serverkontext und Hash-Zuordnung sind Testadapter. Race-Injektionen ändern echte Datensätze nach der vorgelagerten Fahrerabfrage, bevor der Schreibzugriff prüft.

Geprüft sind gültiger eigener Stopp einschließlich nativer Tokenlöschung und unveränderter Profile/GPS/Geschichte, fremde/falsche Session, neuere noch nicht ortende Schicht, konkurrierender Neustart, entzogene Fahrerfreigabe, gesperrtes Konto, nachträglich angenommene Fahrt, alle drei aktiven Fahrtphasen und unbezahlter Abschluss, bezahlte Geschichte/inaktives Fahrzeug, unveränderte Bestätigung nach nativem Stopp und verlorener Antwort ohne Dispatch, reale Triggerfehler bei Fahrer-/Capability-/Angebots-Schreiben mit Rollback und ausdrücklichem Retry, Dispatch-Speicherfehler nach Commit, Altidentität/ungültige Eingabe, aktive Rechte auch für Offline-Bestätigung und fremde native Capability trotz gleicher Session-Zeichenfolge.

14 der 18 Tests scheitern mit dem ursprünglichen Endpunkt; alle 18 bestehen korrigiert. Gesamtstand 631 Tests. Beide TypeScript-Prüfungen, gezieltes Lint/Format und diff-Prüfung bestanden. Bestehende Next.js-16.4-Route-Handler-Konventionen erhalten.

## Grenzen und nächster Schritt

Bestätigt wird der aktuelle Serverstand, keine dauerhaft gespeicherte Pausenquittung. Netzverlust/Commit-Transportfehler können weiter unklar bleiben; zuerst aktuelle Fahreransicht prüfen, keine automatische Wiederholung. Eine bereits später gestartete Schicht wird nicht rückgängig gemacht. Die separate native Geräte-/Capability-Pause bleibt unverändert und darf zum Beenden der Standortübertragung weiterhin unabhängig erfolgen; eine anschließend bereits offline befindliche Schicht wird nur bestätigt, keine Fahrt abgeschlossen oder Ortung neu gestartet. Keine garantierte Dispatch-Wiederholung oder unmittelbare native OS-Abschaltung durch diesen Serverablauf.

Keine Migration/neue APK: Kunde bleibt 0.6.9 / Build 23, Fahrer bleibt 0.8.5 / Build 39; Android-/Signatur-/Emulatornachweise stammen vom unveränderten vorherigen Build. Keine Production-Schicht, Position, Alarme, Fahrt oder Rechteänderung ausgelöst. Physische angemeldete Unternehmensgeräte-/Mehrgeräte-/Hersteller-/Straßen-/Ton-/Hintergrund-GPS-Prüfungen bleiben offen.

Nächster unabhängiger Schritt: authentifizierten driver/online-Schichtstart lokal bei Kontosperre nach Identitätsprüfung und konkurrierenden Starts untersuchen; vorhandene atomare Session-/Capability-Anlage erhalten. Abgeschlossene Stop-/Ergebnis-/Gerätebereinigung nicht erneut implementieren.

Exakter Archivbuild bestanden: 7,5 Sekunden Kompilierung und 5,1 Sekunden TypeScript.


## Veröffentlichung

Serververöffentlichung atomarer authentifizierter Schicht-Stopp bestätigt: Runtime 4cb948f8576fb9bdc2d4ea129d8b68bfc29ad022, GitHub 96fe052d4f67852bb7b4bb525413b0c0976ec04f. Drei öffentliche Paketdateien bytegenau; Archiv 539 Dateien/7984168 Bytes/SHA-256 4329b7710d6a8791cac5f091a6e193e341d362ed5a97bffbb272d5fe69808be7. Exakter Archivbuild 7,5s Kompilierung/5,1s TypeScript bestanden. Automatischer Vercel-Build erfolgreich: AMU4hgLjoUohrcg45waNJg312gXC Ready/Latest/Current Production für luxoreride.de mit exaktem Commit bestätigt; GitHub-Status success. Fünf reine health/account/Kunden-/Fahrer-/Dispositions-GETs HTTP 200, Datenbank/Konten/Buchung bereit. Keine Migration/neue APK: Kunde 0.6.9 / 23 und Fahrer 0.8.5 / 39 unverändert; Android-/Signatur-/Emulatornachweise stammen vom zuvor geprüften Build, keine neue Geräteinstallation oder physische Prüfung. Keine Production-Schicht, Position, Alarme, Fahrt oder Rechteänderung ausgelöst. Lokale Nachweise work/atomic-driver-offline und outputs/atomic-driver-offline/vercel-ready.png. Persönliche unversionierte docs/ROADMAP 2.md unangetastet. Nächster konkreter Schritt authentifizierten driver/online-Start lokal bei nachträglicher Kontosperre und konkurrierenden Starts prüfen, bestehende atomare Session-/Capability-Anlage erhalten; abgeschlossene Stop-Abläufe nicht erneut implementieren.

Der nachträgliche Dokumentationsnachweis verändert weder den geprüften Runtime-Commit noch das veröffentlichte Archiv. Geschützte APK-Entwürfe bleiben unverändert; keine öffentliche Binary-/Store-Freigabe.
