# Authentifizierter GPS-Heartbeat · 17. Oktober 2026

## Nachgewiesene Fehler

POST /api/mobility/driver mit action:heartbeat prüfte Identität und Fahrerprofil vor dem GPS-Schreibzugriff. Eine danach gesetzte Kontosperre oder Löschvormerkung wurde beim Update nicht erneut berücksichtigt. Bei inzwischen entzogener Fahrerfreigabe verhinderte der vorhandene UPDATE-Guard zwar das Schreiben, lieferte aber lediglich den allgemeinen Sessionkonflikt 409.

Nach erfolgreich gespeichertem GPS-Punkt führte der Endpunkt den tatsächlichen Dispatch aus. Ein dortiger SQL-Fehler ließ die Anfrage mit 500 scheitern, obwohl Koordinaten und online bereits committed waren. Das ist sowohl beim anfänglichen Queue-Aufräumen als auch beim späteren tatsächlichen Angebotsinsert lokal reproduziert.

## Änderung

lib/mobility/driver-heartbeat.ts erhält die bestehende Koordinaten-/Genauigkeitsprüfung und den optionalen Zeitstempel. Ist ein Zeitstempel vorhanden, gelten weiterhin höchstens 30 Sekunden Alter beziehungsweise fünf Sekunden Zukunft und maximal 100 Meter Genauigkeit. Fehlt er beim bisherigen Altclient, bleibt das kompatibel. Rohkoordinaten werden unverändert gespeichert, location_at bleibt wie bisher die serverseitige Anfragezeit; es wird keine neue Punktwarteschlange oder serverseitige Reihenfolgeregel eingeführt.

Im libSQL-Schreibzugriff wird jetzt der aktuelle eigene Kontostatus und die aktuelle Fahrerfreigabe vor dem Update gelesen. Ein vorhandenes nicht aktives Konto oder entzogene Freigabe bleibt 403 ohne GPS- oder Dispatchmutation. Gültige authentifizierte Altidentitäten ohne lokalen Accountdatensatz bleiben kompatibel. Das anschließende Update behält die tatsächliche erwartete Session, aktive Fahrzeugauswahl und Flottenmitgliedschaft als verbindliche SQL-Guards; andere/beendete Session oder ungeeignetes Fahrzeug bleibt 409. Die Identität kommt ausschließlich aus der Anmeldung, nicht aus driverId im Body.

Erst nach erfolgreichem Commit folgt der bestehende Dispatch außerhalb des GPS-Schreibzugriffs. Ein Dispatchfehler wird protokolliert; die tatsächlich gespeicherte Position bleibt mit dem bisherigen JSON ok:true/at bestätigt. Dies bestätigt weder eine erfolgreiche Gesamtqueue noch ein bestimmtes Fahrtangebot. Es gibt keinen neuen automatischen Dispatch-/HTTP-Retry. Ein GPS-Schreibfehler bleibt 500 und überspringt Dispatch. Die reguläre nächste gültige Anfrage kann nach behobenem Fehler wieder arbeiten.

Session-/Capability-Anlage und -Löschung, Profil, Fahrerfreigabe, Fahrzeugauswahl, Flotten-/Teamrechte und Fahrtgeschichte werden durch den GPS-Schreibschritt nicht verändert. Dispatch führt weiterhin seine bestehenden Queue-Änderungen aus. Die neue Prüfgrenze betrifft ausschließlich den authentifizierten driver/heartbeat; der separate native Capability-Upload und abgeschlossene Start-/Stop-/Bereinigungsabläufe bleiben unverändert. Keine neue API, Migration, Berechtigung, Abhängigkeit oder APK.

## Prüfungen

15 neue Tests rufen den tatsächlichen Endpunkt mit echtem sqliteDatabase/libSQL-Adapter, echten Migrationen und tatsächlichem Dispatch auf. Fünf scheitern im bisherigen Endpunkt: spätere Kontosperre/Löschvormerkung, Status bei entzogener Fahrerfreigabe und zwei tatsächliche Dispatch-SQL-Fehler nach gespeichertem Punkt. Weitere Kontrollen erhalten alte/neue Session, Pause, aktives Fahrzeug und Mitgliedschaft, eigene Identität, Rohpunkte, Zeit-/Genauigkeitsgrenzen, Altidentität und fehlenden optionalen Zeitstempel. Ein echter Trigger beim GPS-Update belegt unveränderten Bestand ohne Dispatch und späteren ausdrücklich gesendeten gültigen Punkt. Ein während ausstehendem altem Dispatch neu gestarteter Sessionstand wird vom alten Abschluss nicht überschrieben.

Gesamtstand nach Prüfabschluss: 662 Tests, beide TypeScript-Prüfungen und gezieltes Lint/Format. Exakter Archivbuild und Veröffentlichungsnachweis folgen unten.

## Grenzen und nächster Schritt

ok:true/at bestätigt ausschließlich diesen gespeicherten Punkt zum damaligen Schreibzugriff. Eine später gesperrte Identität oder neue Schicht kann den aktuellen Stand inzwischen ändern. Es gibt keine dauerhafte Quittung, globale Queue-Erfolgsgarantie oder neue Wiederholung. Netzwerk-/Commit-Transportfehler können weiterhin unklar bleiben; langsame Body-/Speicheraufrufe bekommen dadurch keine zusätzliche Frist. Die bisherigen Zeitstempel-/Serverzeit- und clientseitigen GPS-Qualitätsregeln werden nicht erweitert.

Kunden-APK 0.6.9 / Build 23 und Fahrer-APK 0.8.5 / Build 39 unverändert. Die bestehenden Android-/Signatur-/Emulatornachweise stammen vom zuvor geprüften Build; keine neue Installation oder physische angemeldete Prüfung. Keine Production-Schicht, Position, Fahrt, Alarm oder Rechteänderung ausgelöst. Angemeldete Geräte-/Mehrgeräte-/Hersteller-/Straßen-/Hintergrundprüfungen bleiben offen.

Nächster unabhängiger Schritt: den tatsächlichen nativen Capability-GPS-Upload lokal bei nachträglicher Kontosperre und Dispatch-/Speicherfehlern prüfen; native Stopp-/Startguards und diesen authentifizierten Heartbeat nicht erneut implementieren.
