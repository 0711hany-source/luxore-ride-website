# Aktuell: Fahrer-Testversion 0.4.2 und Online-Oberflächen

Stand: 05.10.2026. Die aktuelle Geräteanleitung steht in [ONLINE-BETRIEBSTEST.md](ONLINE-BETRIEBSTEST.md). Die Fahrer-APK 0.4.2 wird über die vorhandene Testapp installiert, ohne deren Daten zu löschen. Kunden-APK 0.3.1 kann weiterverwendet werden. Website-Änderungen laden beim erneuten Öffnen; native Änderungen benötigen eine APK. Die folgenden Hinweise sind ausschließlich das Archiv der früheren Offline-Version 0.1.

LUXORÉ RIDE – Unternehmens-Testpaket 0.1.0
Stand: 23.09.2026

OHNE ANMELDUNG
Beide Apps lassen sich nach der Installation ohne ChatGPT-, Google- oder sonstiges Benutzerkonto öffnen. Wer die APK-Dateien erhält, kann diese Testversionen installieren und benutzen. Es gibt keine Benutzerfreigabe und keinen Login in den Apps.

DATEIEN
luxore-customer-preview-arm64.apk: Kunden-Testapp
luxore-driver-preview-arm64.apk: Fahrer-Testapp
checksums.json: Prüfsummen und technische Angaben

VORAUSSETZUNGEN
Android 7 oder neuer, 64-Bit-ARM-Gerät (ARM64). Kein iPhone.
Je App ca. 26,5 MB Download. Ausreichend Speicher zur Installation bereithalten.

INSTALLATION
1. ZIP entpacken und die gewünschte APK auf das Android-Gerät übertragen (zum Beispiel per USB oder als Datei im Unternehmens-Messenger).
2. APK auf dem Android-Gerät öffnen.
3. Falls Android fragt, die Installation für die benutzte Datei-/Browser-App erlauben. Anschließend kann diese Erlaubnis wieder ausgeschaltet werden.
4. „LUXORÉ Ride Test“ bzw. „LUXORÉ Driver Test“ starten. Beide Apps können gleichzeitig installiert sein.
5. Es ist keine Anmeldung erforderlich und kein Entwicklungsserver nötig.

WAS FUNKTIONIERT
Kunden-App: Fahrzeugklassen und Tarife ansehen; eine Fahrtanfrage eingeben und prüfen; optional die eigenen GPS-Koordinaten übernehmen; den Anfragetext im E-Mail-Programm öffnen oder über den Teilen-Dialog weitergeben.
Fahrer-App: vorbereitete Ansichten für Aufträge, Reservierungen und Kontakt. Sie bleibt offline und empfängt noch keine echten Fahrten.

TESTGRENZEN
Keine Live-Vermittlung, keine Zahlung und keine automatische Buchungsbestätigung. Die Kartenanbindung der privaten Web-App ist in diesen APKs noch nicht enthalten. Die separate private Web-Vorschau kann weiterhin nach einer Anmeldung fragen; sie ist zum Starten oder Testen der installierten Apps nicht erforderlich.
Das Öffnen des E-Mail- oder Teilen-Dialogs versendet noch nichts. Im Test zunächst Beispieldaten verwenden und keine unbeabsichtigten Nachrichten absenden.
Die APKs sind mit einem Android-Testschlüssel signiert und für interne Tests gedacht. Signatur, Paketkennung, Berechtigungen und enthaltene Dateien wurden geprüft. Vollständige Tests auf echten Geräten stehen noch aus.

FEHLER FESTHALTEN
App-Name, Gerätemodell, Android-Version, konkrete Schritte, erwartetes und tatsächliches Ergebnis. Keine echten Kundendaten in Fehlerberichte aufnehmen.

WEITERGABE
Dieses Paket darf innerhalb des Unternehmens an die Testpersonen weitergegeben werden. Wer eine Kopie hat, kann sie ohne Login benutzen; einzelne Kopien lassen sich daher nicht aus der Ferne sperren.
