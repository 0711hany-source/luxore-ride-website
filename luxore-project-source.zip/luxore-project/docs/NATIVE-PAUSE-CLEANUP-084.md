# Native Pausenbereinigung · Fahrer 0.8.4 / Build 38

## Reproduzierter Fehler

stopLocation brach beim ersten zurückgewiesenen lokalen Aufruf ab. Fehler beim Lesen oder Löschen von SecureStore-Daten konnten sowohl weitere lokale Bereinigung als auch nativen Stopp und Servermeldung überspringen. Eine fehlgeschlagene hasStartedLocationUpdatesAsync-Abfrage übersprang den tatsächlichen Stopp; ein fehlgeschlagener nativer Stopp unterdrückte die bereits vorbereitbare Servermeldung. Die seit 0.8.3 geltende laufzeitlokale Upload-Sperre war davon unabhängig wirksam, beendete aber den tatsächlichen nativen Dienst nicht selbst.

## Änderung

Die unbedingte Pause beginnt weiterhin sofort mit der laufzeitlokalen Übertragungssperre. Innerhalb der bestehenden serialisierten Mutationssperre liest sie die ursprüngliche Capability und sammelt lokale Fehler. Capability-Löschung, Positionscache-Löschung, bestehende best-effort Alarmbereinigung und nativer Stopp werden trotz zurückgewiesener vorheriger Schritte weiter versucht. Falls die native Statusabfrage fehlschlägt, wird der tatsächliche Stopp versucht, statt ihn zu überspringen. Bei bestätigtem nicht laufendem Dienst bleibt der bisherige Verzicht auf einen unnötigen Stopp erhalten.

Nach der lokalen Mutationssperre erfolgt die bestehende best-effort Servermeldung ausschließlich mit der vorher gelesenen Capability. Lokale Fehler können diese Meldung nicht mehr unterdrücken. Danach wird der erste lokale Fehler unverändert weitergegeben; kein unvollständiger Gerätestopp wird dadurch als erfolgreich bestätigt. Alarmbereinigungsfehler bleiben wie bisher best effort.

Ist die Capability bei einer unbedingten Pause nicht lesbar, werden die lokalen Lösch-/Stoppversuche dennoch ausgeführt, aber keine Credentials erfunden und kein Server-Aufruf unter fremdem/neuem Token erzeugt. Ein bedingter Stopp einer alten Antwort muss weiterhin Session und ursprüngliche Version verifizieren; bei unbekanntem Ziel darf er keine ungezielte Mutation vornehmen. Alte Serverabschlüsse laufen außerhalb der Mutationssperre und haben danach keine weitere lokale Lösch-/Stoppaktion. Neue Schichten bleiben erhalten.

## Verhaltenstests

Neun neue Tests führen den tatsächlichen Ortungsdienst mit isolierten Expo-Location-/TaskManager-/SecureStore-/Alarmadaptern und abgefangenem fetch aus. Sechs scheitern im alten Dienst, alle bestehen korrigiert:

- Capability-Löschung scheitert: Cache/Alarm/Dienst und ursprüngliche Servermeldung werden trotzdem versucht, Fehler bleibt sichtbar und keine neuen GPS-Uploads.
- Cache-Löschung scheitert: Capability/Dienst und Servermeldung ebenso; fehlgeschlagener Cache wird nicht als gelöscht ausgegeben.
- Capability-Lesen scheitert: unbedingte lokale Bereinigung/OS-Stopp ohne erfundenen Server-Token, Lesefehler bleibt sichtbar.
- Native Statusabfrage scheitert: tatsächlicher Stopp und Servermeldung werden versucht, Statusfehler bleibt sichtbar.
- Nativer Stopp scheitert: Capability/Cache sind entfernt, ursprüngliche Servermeldung wird versucht, OS-Stopp bleibt ausdrücklich unbestätigt.
- Expliziter erneuter Pausenaufruf nach Capability-Löschfehler schließt Bereinigung ab; ein späterer gültiger Start sendet frisch unter neuem Token.
- Alarmbereinigungsfehler verhindert bestehenden erfolgreichen Stopp nicht (Kontrollfall).
- Veraltete erwartete Session/Version darf neuere Schicht nicht mutieren (Kontrollfall).
- Nach lokaler Pause gestartete neue Schicht bleibt bei verspäteter alter Serverantwort erhalten (Kontrollfall).

## Grenzen

Nur zurückgewiesene lokale Aufrufe werden isoliert. Hängende native oder Speicher-Promises erhalten dadurch kein Zeitlimit; es gibt keinen neuen dauerhaft gespeicherten Pauseauftrag und keine mehrprozessfeste Pausequittung. Nicht löschbare Credentials können im Gerätespeicher verbleiben; ein nicht bestätigter nativer Stopp bleibt ein Fehler, der erneute ausdrückliche Pause beziehungsweise Systemberechtigungsprüfung erfordert. Die Servermeldung ist wie zuvor best effort, keine neue Zusicherung einer bestätigten Offline-Änderung bei Netzverlust/HTTP-Ablehnung, kein automatischer Retry. Bereits begonnene native/HTTP-Vorgänge werden nicht abgebrochen. Aktuelle Konten-/Flotten-/Fahrt-/Zahlungsrechte, Qualitäts-/Netzcachefilter und Hintergrundberechtigungen unverändert.

Alle Tests lokal/synthetisch, keine Production-Schicht, Position, Alarme, Fahrt oder Rechteänderung. Keine API/Migration/neuen Provider. Physische angemeldete Unternehmensgeräte-/Mehrprozess-/Hersteller-/Schicht-/Straßen-/Hintergrund-GPS-Prüfungen bleiben offen.

Kunde bleibt 0.6.9 / Build 23. Fahrer benötigt 0.8.4 / Build 38, ausschließlich interner geschützter APK-Entwurf, keine öffentliche Binary-/Store-Freigabe. Website-Update installiert keine APK auf Nutzerhandys. 588 Tests, beide TypeScript-Prüfungen, gezieltes Lint/Format und diff-Prüfung bestanden. Build außerhalb synchronisierter Quellen in 4m 57s, 85 Runtime-/Asset-/Konfigurationsdateien im vollständigen Importbaum bytegenau. Alle 21 direkten installierten Paketversionen/Lockfile unverändert. Bestehendes Zertifikat SHA-256 fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c und Manifest-Berechtigungen unverändert, Variantenprüfung bestanden.

APK 56220096 Bytes, SHA-256 012535bd8e6eff666f5e755ef291081c4cbd5e42609a44bd4d3eb10c56157aef. Update über 0.8.3 ohne Deinstallation im isolierten Emulator, drei anonyme Kaltstarts ohne Absturz. Emulator anschließend beendet, keine angemeldete physische Prüfung. Exakter Archivbuild bestanden: 8,0 Sekunden Kompilierung, 5,2 Sekunden TypeScript.


Geschützter interner APK-Entwurf https://github.com/0711hany-source/luxore-ride-website/releases/tag/untagged-a91216dac8861dec55d2 bestätigt: genau ein tatsächlicher Anhang mit identischem angezeigtem SHA-256. Nachweis outputs/native-pause-cleanup-084/apk-draft.png. Keine öffentliche Binary-/Store-Freigabe.


## Veröffentlichung

Veröffentlichung 0.8.4 bestätigt: Runtime c87d82b4ae3bab1abcfd13333e8c6da8fe58fbf0, GitHub 3be388dd03d051a80c0dc2d75f0aee611cef6357. Drei öffentliche Paketdateien bytegenau; Archiv 529 Dateien/7955584 Bytes/SHA-256 c9d2df308c88b1c640dd66eecf9268e81a314443f1a27d1b8dfb289f149e8b38. Exakter Archivbuild 8,0s Kompilierung/5,2s TypeScript bestanden. Vercel FZVUcPX6akTDTrnrkSwGKSXTTy5z Ready/Latest/Current Production für luxoreride.de mit exaktem Commit bestätigt, GitHub success. Fünf reine health/account/Kunden-/Fahrer-/Dispositions-GETs HTTP 200, Datenbank/Konten/Buchung bereit. Fahrer-APK 0.8.4 / 38 im geschützten internen Entwurf untagged-a91216dac8861dec55d2 mit genau einem tatsächlichen Anhang und identischem angezeigtem SHA-256 012535bd8e6eff666f5e755ef291081c4cbd5e42609a44bd4d3eb10c56157aef, 56220096 Bytes. Unveränderte Signatur/Berechtigungen/21 direkte installierte Paketversionen/Lockfile; vollständiger Importbaum mit 85 Dateien bytegenau. Update über 0.8.3 ohne Deinstallation und drei anonyme Emulator-Kaltstarts bestanden; Emulator beendet. Kunde bleibt 0.6.9 / 23. Keine angemeldete physische Prüfung oder Production-Schicht/Position/Alarme/Fahrt/Rechteänderung. Nachweise work/native-pause-cleanup-084 und outputs/native-pause-cleanup-084, insbesondere vercel-ready.png und apk-draft.png. Persönliche unversionierte docs/ROADMAP 2.md unangetastet. APKs bleiben geschützte interne Entwürfe, niemals öffentlich Publish release wählen. Nächster Schritt tatsächliche Server-Pausenantwort bei Netzverlust/HTTP-Ablehnung konkret prüfen und lokalen GPS-Stopp von bestätigtem Server-Offlinezustand unterscheiden; lokale Pausenbereinigung nicht erneut implementieren.

Dieser nachträgliche Dokumentationsnachweis verändert weder den geprüften Runtime-Commit noch das veröffentlichte Archiv.
